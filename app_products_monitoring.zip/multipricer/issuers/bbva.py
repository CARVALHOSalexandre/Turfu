import datetime
import pandas as pd

from emails.mail_sender import Mailer
from multipricer.models.base_multipricer import *


class MailPricingBBVA(Mailer):
    def __init__(self):
        super().__init__()

        self.to = ["epricer@bbva.com"]
        self.cc = ["exane.structuring@exane.com"]

    def to_issuer_format(self, df):
        # Reformat Autocall Triggers
        for i in range(0, len(df.index)):
            if (
                df.iloc[i].loc["autocall_barrier"] is not None
                and "-" in df.iloc[i].loc["autocall_barrier"]
            ):
                periods = df.iloc[i].loc["autocall_barrier"].split("-")
                df.at[i, "autocall_barrier"] = "/".join(periods)

        # Set Solve For Column
        df["Solve For"] = df["id_solve_for"].apply(
            lambda x: SolveFor.query.filter(SolveFor.id == x).first().code
        )

        # Add Pricer's Columns
        df["ID"] = ""
        df["TimeStamp"] = ""
        df["Status"] = ""
        df["Price"] = df.apply(
            lambda x: -x["offer_price"]
            if Wrappers.query.filter(Wrappers.id == x["id_wrapper"]).first().name
            == "Swap"
            and x["offer_price"]
            else x["offer_price"],
            axis=1,
        )
        df["Product"] = df["id_product"].apply(
            lambda x: Products.query.filter(Products.id == x).first().name
        )
        df["Product"] = df["Product"].apply(
            lambda x: "Autocall Phoenix" if x == "Autocall" else x
        )
        df["Wrapper"] = df["id_wrapper"].apply(
            lambda x: Wrappers.query.filter(Wrappers.id == x).first().name
        )
        df["Currency"] = df["id_currency"].apply(
            lambda x: Currencies.query.filter(Currencies.id == x).first().code
        )
        df["Notional"] = df["notional"].astype(int)
        df["Strike Fixing Date (date / shifter)"] = datetime.datetime.today().strftime(
            "%d/%m/%Y"
        )
        df["Effective Date (date / shifter)"] = "5b"
        df["Expiry / Maturity / Tenor"] = df["months_to_maturity"]
        df["BBG Code 1"] = df["ticker_1"]
        df["BBG Code 2"] = df["ticker_2"]
        df["BBG Code 3"] = df["ticker_3"]
        df["BBG Code 4"] = df["ticker_4"]
        df["BBG Code 5"] = df["ticker_5"]
        df["ER Coupon Type"] = df["is_memory"].apply(
            lambda x: "Snowball" if x is True else "Flat"
        )
        df["ER Trigger (%)*"] = df["autocall_barrier"].apply(
            lambda x: str(x) if x is not None else x
        )
        df["ER Frequency (1m, 2m, 3m, 4m, 6m, 12m)"] = df["id_frequency"].apply(
            lambda x: str(
                Frequencies.query.filter(Frequencies.id == x).first().nb_months
            )
            + "m"
        )
        df["ER Coupon Amount (%) *"] = 0
        df["ER Alternative Coupon (%)"] = 0
        df["ER Non cancelable Periods"] = df["autocall_start_period"].apply(
            lambda x: x - 1 if x is not None else 0
        )
        df["Coupon Type"] = df.apply(
            lambda x: "Fixed Coupon"
            if x["coupon_barrier"] == 0
            else (
                "Total Memory"
                if x["is_memory"] is True
                else (
                    "Fixed Coupon"
                    if x["Product"] == "Reverse Convertible"
                    else "Standard"
                )
            ),
            axis=1,
        )
        df["Frequency (1m, 2m, 3m, 4m, 6m, 12m)"] = df["id_frequency"].apply(
            lambda x: str(
                Frequencies.query.filter(Frequencies.id == x).first().nb_months
            )
            + "m"
        )
        df["Trigger/Strike*"] = df.apply(
            lambda x: (str(x["coupon_barrier"]) + "%") if x["coupon_barrier"] else 0,
            axis=1,
        )
        df["Coupon (%)*"] = df.apply(
            lambda x: (
                x["coupon_level"]
                / (
                    12
                    / Frequencies.query.filter(Frequencies.id == x["id_frequency"])
                    .first()
                    .nb_months
                )
            )
            if x["coupon_level"]
            else None,
            axis=1,
        )
        df["Memory Periods"] = 0
        df["Gearing"] = "Leveraged"
        df["Strike (%)*"] = df["barrier_strike"].astype(float).astype(str)
        df["Barrier Type"] = df["id_barrier_type"].apply(
            lambda x: BarrierTypes.query.filter(BarrierTypes.id == x).first().type
            if x != 4
            else None
        )
        df["Barrier Type"] = df["Barrier Type"].apply(
            lambda x: (
                "At Expiry"
                if x == "European"
                else ("Continuous" if x == "American Continuous" else "Daily")
            )
            if x is not None
            else x
        )
        df["KI Barrier Level (%)*"] = df["barrier_level"].apply(
            lambda x: (str(float(x))) if not pd.isna(x) else 0
        )
        df["Funding Type"] = "Floating Rate"
        df["Freq (1m, 3m, 6m, 12m)"] = df["id_frequency"].apply(
            lambda x: str(
                Frequencies.query.filter(Frequencies.id == x).first().nb_months
            )
            + "m"
        )
        df["Rate / Spread (%)*"] = df["funding_spread"]

        # Reformat Columns
        df.loc[df["Solve For"] == "Reoffer", "Price"] = ""
        df.loc[df["Solve For"] == "Upfront", "Price"] = ""
        df.loc[df["Solve For"] == "Coupon", "Coupon (%)*"] = "?"
        df.loc[df["BBG Code 2"].isnull(), "BBG Code 2"] = ""
        df.loc[df["BBG Code 3"].isnull(), "BBG Code 3"] = ""
        df.loc[df["BBG Code 4"].isnull(), "BBG Code 4"] = ""
        df.loc[df["BBG Code 5"].isnull(), "BBG Code 5"] = ""
        df.loc[df["ER Trigger (%)*"].isnull(), "ER Trigger (%)*"] = ""
        df.loc[df["Trigger/Strike*"].isnull(), "Trigger/Strike*"] = ""
        df.loc[df["Rate / Spread (%)*"].isnull(), "Rate / Spread (%)*"] = ""
        df.loc[df["Rate / Spread (%)*"] == "", "Funding Type"] = ""
        df.loc[df["Rate / Spread (%)*"] == "", "Freq (1m, 3m, 6m, 12m)"] = ""

        # Keep Pricer's Columns
        df = df[
            [
                "ID",
                "TimeStamp",
                "Status",
                "Price",
                "Product",
                "Wrapper",
                "Currency",
                "Notional",
                "Strike Fixing Date (date / shifter)",
                "Effective Date (date / shifter)",
                "Expiry / Maturity / Tenor",
                "BBG Code 1",
                "BBG Code 2",
                "BBG Code 3",
                "BBG Code 4",
                "BBG Code 5",
                "ER Coupon Type",
                "ER Trigger (%)*",
                "ER Frequency (1m, 2m, 3m, 4m, 6m, 12m)",
                "ER Coupon Amount (%) *",
                "ER Alternative Coupon (%)",
                "ER Non cancelable Periods",
                "Coupon Type",
                "Frequency (1m, 2m, 3m, 4m, 6m, 12m)",
                "Trigger/Strike*",
                "Coupon (%)*",
                "Memory Periods",
                "Gearing",
                "Strike (%)*",
                "Barrier Type",
                "KI Barrier Level (%)*",
                "Funding Type",
                "Freq (1m, 3m, 6m, 12m)",
                "Rate / Spread (%)*",
            ]
        ]

        # Convert DataFrame To HTML Table
        replace = {
            "<thead>": "",
            "</thead>": "",
            "<tbody>": "",
            "</tbody>": "",
            "th>": "td>",
        }
        self.content = df.to_html(index=False, na_rep="")
        for key, value in replace.items():
            self.content = self.content.replace(key, value)

    def load_issuer_format(self, body, solve_for, nb_per_year):
        df = pd.read_html(body, header=0)[0]
        results = []
        is_error = []
        id_quote = []
        for i in range(0, len(df.index)):
            if str(df.iloc[i].loc["ID"]) != "nan":
                id_quote.append(str(df.iloc[i].loc["ID"]))
            else:
                id_quote.append(None)
            if df.iloc[i].loc["Status"] == "OK":

                if solve_for == "Coupon":
                    if "," in df.iloc[i].loc["Coupon (%)*"]:
                        df.at[i, "Coupon (%)*"] = (
                            df.iloc[i].loc["Coupon (%)*"].replace(",", ".")
                        )
                    cpn = float(df.iloc[i].loc["Coupon (%)*"][0:-1])
                    cpn_pa = round(cpn * nb_per_year[i], 2)
                    results.append(f"{cpn_pa}%")
                    is_error.append(False)
                elif solve_for == "Upfront":
                    results.append(f"{-round(float(df.iloc[i].loc['Price'][0:-1]),2)}%")
                    is_error.append(False)
                else:
                    if "," in df.iloc[i].loc["Price"]:
                        df.at[i, "Price"] = df.iloc[i].loc["Price"].replace(",", ".")
                    results.append(f"{round(float(df.iloc[i].loc['Price'][0:-1]),2)}%")
                    is_error.append(False)
            else:
                results.append(df.iloc[i].loc["Status"])
                is_error.append(True)
        return results, is_error, id_quote

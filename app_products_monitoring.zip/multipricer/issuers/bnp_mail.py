import datetime
import pandas as pd

from emails.mail_sender import Mailer
from multipricer.models.base_multipricer import *


class MailPricingBNP(Mailer):
    def __init__(self):
        super().__init__()

        self.to = ["quotation.emea@bnpparibas.com"]
        self.cc = [
            "exane.structuring@exane.com",
            # 'jonathan.malka@bnpparibas.com'
        ]

    def to_issuer_format(self, df):
        # Reformat Autocall Triggers
        for i in range(0, len(df.index)):
            if (
                df.iloc[i].loc["autocall_barrier"] is not None
                and "-" in df.iloc[i].loc["autocall_barrier"]
            ):
                periods = df.iloc[i].loc["autocall_barrier"].split("-")
                df.at[i, "autocall_barrier"] = "/".join(periods)

        # Set Solve For Column
        df["Solve For"] = df["id_solve_for"].apply(
            lambda x: SolveFor.query.filter(SolveFor.id == x).first().code
        )

        # Add Pricer's Columns
        df["Product"] = df["id_product"].apply(
            lambda x: Products.query.filter(Products.id == x).first().name
        )
        df["Product"] = df["Product"].apply(
            lambda x: "Autocall+" if x == "Autocall" else "Reverse"
        )
        df["Wrapper"] = df["id_wrapper"].apply(
            lambda x: Wrappers.query.filter(Wrappers.id == x).first().name
        )
        df["Wrapper"] = df["Wrapper"].apply(
            lambda x: "Certificate" if x == "Note" else x
        )
        df["Currency"] = df["id_currency"].apply(
            lambda x: Currencies.query.filter(Currencies.id == x).first().code
        )
        df["Forward Start"] = datetime.datetime.today().strftime("%d.%m.%Y")
        df["Tenor (m)"] = df["months_to_maturity"]
        df["BBG Code 1"] = df["ticker_1"]
        df["BBG Code 2"] = df["ticker_2"]
        df["BBG Code 3"] = df["ticker_3"]
        df["BBG Code 4"] = df["ticker_4"]
        df["BBG Code 5"] = df["ticker_5"]
        df["Strike (%)"] = df["barrier_strike"].apply(
            lambda x: (str(x)) if x is not None else x
        )
        df["Barrier Type"] = df["id_barrier_type"].apply(
            lambda x: (BarrierTypes.query.filter(BarrierTypes.id == x).first().type)
            if x != 4
            else None
        )
        df["KI Barrier (%)"] = df["barrier_level"].apply(
            lambda x: (str(float(x))) if not pd.isna(x) else 0
        )
        df["Early Termination Period"] = df["id_frequency"].apply(
            lambda x: Frequencies.query.filter(Frequencies.id == x).first().code
        )
        df["Early Termination Period"] = df["Coupon Frequency"] = df[
            "Early Termination Period"
        ].apply(lambda x: "Semi-Annually" if x == "Semestrial" else x)
        df["Non Autocallable Period"] = df["autocall_start_period"].apply(
            lambda x: x - 1 if x is not None else 0
        )
        df["Early Termination Level (%)"] = df["autocall_barrier"].apply(
            lambda x: str(x) if x is not None else x
        )
        df["Coupon p.a. (%)"] = df["coupon_level"]
        df["Trigger Level (%)"] = df.apply(
            lambda x: str(x["coupon_barrier"]) if x["coupon_barrier"] else 0, axis=1,
        )
        df["Memory coupon"] = df["is_memory"].apply(
            lambda x: "YES" if x is True else "NO"
        )
        df["Exit Rate p.a. (%)"] = 0
        df["Size"] = df["notional"].astype(int)
        df["Reoffer (%)"] = df.apply(
            lambda x: -x["offer_price"]
            if Wrappers.query.filter(Wrappers.id == x["id_wrapper"]).first().name
            == "Swap"
            and x["offer_price"]
            else x["offer_price"],
            axis=1,
        )
        df["Swap Spread (%)"] = df["funding_spread"]
        df["Swap Index"] = df["id_frequency"].apply(
            lambda x: str(
                Frequencies.query.filter(Frequencies.id == x).first().nb_months
            )
            + "m"
        )

        # Reformat Columns
        df.loc[df["Solve For"] == "Reoffer", "Reoffer (%)"] = ""
        df.loc[df["Solve For"] == "Coupon", "Coupon p.a. (%)"] = ""
        df.loc[df["BBG Code 2"].isnull(), "BBG Code 2"] = ""
        df.loc[df["BBG Code 3"].isnull(), "BBG Code 3"] = ""
        df.loc[df["BBG Code 4"].isnull(), "BBG Code 4"] = ""
        df.loc[df["BBG Code 5"].isnull(), "BBG Code 5"] = ""
        df.loc[df["Barrier Type"].isnull(), "KI Barrier (%)"] = ""
        df.loc[df["Swap Spread (%)"].isnull(), "Swap Spread (%)"] = "0"
        df.loc[df["Barrier Type"] == "American Continuous", "Barrier Type"] = "American"
        df.loc[
            df["Barrier Type"] == "American Daily Close", "Barrier Type"
        ] = "Daily Close"

        if df["Product"].iloc[0] == "Autocall+":
            # Keep Pricer's Columns
            df = df[
                [
                    "Product",
                    "Wrapper",
                    "Currency",
                    "Forward Start",
                    "Tenor (m)",
                    "BBG Code 1",
                    "BBG Code 2",
                    "BBG Code 3",
                    "BBG Code 4",
                    "Strike (%)",
                    "Barrier Type",
                    "KI Barrier (%)",
                    "Early Termination Period",
                    "Non Autocallable Period",
                    "Early Termination Level (%)",
                    "Coupon p.a. (%)",
                    "Trigger Level (%)",
                    "Memory coupon",
                    "Exit Rate p.a. (%)",
                    "Size",
                    "Reoffer (%)",
                    "Swap Index",
                    "Swap Spread (%)",
                ]
            ]
        else:
            # Keep Pricer's Columns
            df = df[
                [
                    "Product",
                    "Wrapper",
                    "Currency",
                    "Forward Start",
                    "Tenor (m)",
                    "BBG Code 1",
                    "BBG Code 2",
                    "BBG Code 3",
                    "BBG Code 4",
                    "Strike (%)",
                    "Barrier Type",
                    "KI Barrier (%)",
                    "Coupon Frequency",
                    "Coupon p.a. (%)",
                    "Size",
                    "Reoffer (%)",
                    "Swap Index",
                    "Swap Spread (%)",
                ]
            ]

        # Convert DataFrame To HTML Table
        replace = {
            "<thead>": "",
            "</thead>": "",
            "<tbody>": "",
            "</tbody>": "",
            "th>": "td>",
        }
        self.content = df.to_html(index=False, na_rep="")
        for key, value in replace.items():
            self.content = self.content.replace(key, value)

    def load_issuer_format(self, body, solve_for, nb_per_year):
        df = pd.read_html(body, header=0)[0]
        results = []
        is_error = []
        id_quote = []
        for i in range(0, len(df.index)):

            if ("BNP Remarks" in df.columns) & ("Price Status" not in df.columns):
                results.append(df.iloc[i].loc["BNP Remarks"])
                is_error.append(True)
                id_quote.append(None)
                continue

            if ("BNP Remarks" not in df.columns) & ("Quote URL" in df.columns):
                id_quote.append(str(df.iloc[i].loc["Quote URL"]))
            else:
                id_quote.append(None)

            if ("BNP Remarks" not in df.columns) & (
                df.iloc[i].loc["Price Status"] == "INDICATIVE"
            ):
                if solve_for == "Coupon":
                    if not pd.isna(df.iloc[i].loc["Coupon p.a. (%)"]):
                        cpn = float(df.iloc[i].loc["Coupon p.a. (%)"])
                        cpn_pa = round(cpn, 2)
                        results.append(f"{cpn_pa}%")
                        is_error.append(False)
                    else:
                        results.append(df.iloc[i].loc["Note"])
                        is_error.append(True)

                else:
                    if not pd.isna(df.iloc[i].loc["Reoffer (%)"]):
                        results.append(
                            f"{round(float(df.iloc[i].loc['Reoffer (%)']), 2)}%"
                        )
                        is_error.append(False)
                    else:
                        results.append(df.iloc[i].loc["Reoffer (%)"])
                        is_error.append(True)
            else:

                if ("BNP Remarks" not in df.columns) & (
                    df.iloc[i].loc["Price Status"] != "INDICATIVE"
                ):
                    if solve_for == "Coupon":
                        results.append(df.iloc[i].loc["Coupon p.a. (%)"])
                        is_error.append(True)
                    else:
                        results.append(df.iloc[i].loc["Reoffer (%)"])
                        is_error.append(True)
                else:
                    results.append(df.iloc[i].loc["BNP Remarks"])
                    is_error.append(True)
        return results, is_error, id_quote

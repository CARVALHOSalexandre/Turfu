from multipricer.models.base_multipricer import *
from utils.basics import *


def set_template(data, tickers_df):

    frequencies = {
        "Monthly": "1M",
        "Quarterly": "3M",
        "Semestrial": "6M",
        "Annually": "1Y",
    }

    barrier_types = {
        "European": "At Maturity",
        "American Continuous": "Continuous",
        "American Daily Close": "Daily Close",
        "None": "None",
    }

    dff_tickers = tickers_df[tickers_df["ticker"] == data.get("ticker_1")]
    tickers = [
        dff_tickers.iloc[0].loc["ticker_sg"]
        if str(dff_tickers.iloc[0].loc["ticker_sg"]) != "nan"
        else dff_tickers.iloc[0].loc["ticker"]
    ]
    if data.get("ticker_2") not in [None, "", " "]:
        dff_tickers = tickers_df[tickers_df["ticker"] == data.get("ticker_2")]
        tickers.append(
            dff_tickers.iloc[0].loc["ticker_sg"]
            if str(dff_tickers.iloc[0].loc["ticker_sg"]) != "nan"
            else dff_tickers.iloc[0].loc["ticker"]
        )
    if data.get("ticker_3") not in [None, "", " "]:
        dff_tickers = tickers_df[tickers_df["ticker"] == data.get("ticker_3")]
        tickers.append(
            dff_tickers.iloc[0].loc["ticker_sg"]
            if str(dff_tickers.iloc[0].loc["ticker_sg"]) != "nan"
            else dff_tickers.iloc[0].loc["ticker"]
        )
    if data.get("ticker_4") not in [None, "", " "]:
        dff_tickers = tickers_df[tickers_df["ticker"] == data.get("ticker_4")]
        tickers.append(
            dff_tickers.iloc[0].loc["ticker_sg"]
            if str(dff_tickers.iloc[0].loc["ticker_sg"]) != "nan"
            else dff_tickers.iloc[0].loc["ticker"]
        )
    if data.get("ticker_5") not in [None, "", " "]:
        dff_tickers = tickers_df[tickers_df["ticker"] == data.get("ticker_5")]
        tickers.append(
            dff_tickers.iloc[0].loc["ticker_sg"]
            if str(dff_tickers.iloc[0].loc["ticker_sg"]) != "nan"
            else dff_tickers.iloc[0].loc["ticker"]
        )

    underlyings = [{"bbgCode": ticker, "strikeType": "On close"} for ticker in tickers]

    currency = (
        Currencies.query.filter(Currencies.id == data.get("id_currency")).first().code
    )

    wrapper = Wrappers.query.filter(Wrappers.id == data.get("id_wrapper")).first().name

    freq_in_months = (
        Frequencies.query.filter(Frequencies.id == data.get("id_frequency"))
        .first()
        .nb_months
    )

    data = {
        "productFamily": "Autocall",
        "commercialName": "AutocallAdvanced1650",
        "basket": {
            "compo": underlyings,
            "type": "Worstof" if len(underlyings) > 1 else "",
        },
        "structureDetails": {
            "nominal": data.get("notional"),
            "premiumCurrency": currency,
        },
        "datesConfig": {
            "delays": {"maturityTenor": f"{data.get('months_to_maturity')}M"},
            "dates": {
                "maturityDate": dt_today()
                + timedelta(days=30 * data.get("months_to_maturity")),
                "strikingDate": dt_today(),
            },
        },
        "finalOption": {
            "optionType": "put",
            "optionStrike": data.get("barrier_strike"),
            "barrier": "Yes" if data.get("id_barrier_type") != 4 else "No",
            "gearing": -100
            if data.get("barrier_strike") != 100
            else -100 / data.get("barrier_strike") * 100,
            "knockInLevel": data.get("barrier_level")
            if data.get("id_barrier_type") != 4
            else data.get("barrier_strike"),
            "useGearing": "No" if data.get("barrier_strike") != 100 else "Yes",
            "barrierStartDate": None
            if data.get("id_barrier_type") != 4
            else (
                dt_today()
                + timedelta(
                    days=30 * data.get("months_to_maturity")
                    if data.get("id_barrier_type") == 1
                    else dt_today()
                )
            ),
            "knockInMonitoring": barrier_types.get(
                BarrierTypes.query.filter(
                    BarrierTypes.id == data.get("id_barrier_type")
                )
                .first()
                .type
            )
            if data.get("id_barrier_type") != 4
            else "None",
        },
        "couponDetails": {
            "conditionalCoupon": data.get("coupon_level"),
            "conditionalCouponBarrier": data.get("coupon_barrier"),
            "isFixedCoupon": "Yes" if data.get("coupon_barrier") == 0 else "No",
            "couponType": "snowball" if data.get("is_memory") == True else "classic",
        },
        "earlyRedemptionBlock": {
            "exitRateCalculation": "includeNonObservedPeriods",
            "triggerLevelER": data.get("autocall_barrier"),
            "frequency": data.get("frequency"),
            "hasKnockOutStartDate": "Yes",
            "exitRate": "0",
            "exitRateMode": "Arithmetic",
            "noKnockOutBefore": f"{freq_in_months * data.get('autocall_start_period')}M",
        },
        "deliveryDetails": {"delivery": "Cash"},
        "wrappingDetails": {"wrappingMode": "CE"},
    }

    return data

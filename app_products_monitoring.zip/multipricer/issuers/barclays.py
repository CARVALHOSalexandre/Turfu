from utils.basics import *
from multipricer.models.base_multipricer import *

import os
import pandas as pd


frequencies = {
    "OnePerYear": {"coeff": 1, "name": "12M"},
    "TwoPerYear": {"coeff": 2, "name": "6M"},
    "FourPerYear": {"coeff": 4, "name": "3M"},
    "OnePerMonth": {"coeff": 12, "name": "1M"},
    "SixPerYear": {"coeff": 6, "name": "2M"},
    "TwelvePerYear": {"coeff": 12, "name": "1M"},
}

barrier_observability = {
    "European": "AtMaturity",
    "US Intraday": "Intraday",
    "Us Close": "CloseOnly",
    "None": "AtMaturity",
}


def downside_params(parameters, performance_type):
    if parameters.get("barrier_type") is None:

        downside = {
            "capitalBase": {"unit": "pct", "value": "100"},
            "option": {
                "type": "Put",
                "performanceType": performance_type,
                "strike": {"unit": "pct", "value": f"{parameters.get('strike')}"},
                "leveraged": "true",
                "observationType": "AtMaturity",
            },
        }

    else:

        downside = {
            "capitalBase": {"unit": "pct", "value": "100"},
            "option": {
                "type": "KIPut",
                "performanceType": performance_type,
                "strike": {"unit": "pct", "value": f"{parameters.get('strike')}"},
                "leveraged": "true" if parameters.get("strike") < 100 else "false",
                "knockin": {
                    "barrier": {
                        "unit": "pct",
                        "value": f"{parameters.get('ki_barrier')}",
                    },
                    "observationType": barrier_observability.get(
                        parameters.get("barrier_type")
                    ),
                    "performanceType": performance_type,
                },
            },
        }

    return downside


def coupon_params(parameters, performance_type):
    return (
        {
            "type": "FixedConditional",
            "fixedConditional": {
                "couponHigh": {
                    "unit": "pct",
                    "value": parameters.get("cpn_level") / parameters.get("nb_obs")
                    if parameters.get("cpn_level")
                    else "SolveFor",
                },
                "barrierHigh": {
                    "unit": "pct",
                    "value": f"{parameters.get('cpn_barrier')}",
                },
                "dayCountBasis": "PerPeriod",
                "frequency": frequencies.get(parameters.get("frequency")).get("name"),
                "performanceType": performance_type,
                "observationType": f"{barrier_observability.get(parameters.get('barrier_type')) if parameters.get('barrier_type') else 'AtMaturity'}",
                "isMemory": "true"
                if parameters.get("cpn_type") == "Memory"
                else "false",
            },
        }
        if parameters.get("cpn_barrier") != 0
        else {
            "type": "FixedCoupon",
            "fixedCoupon": {
                "coupon": {
                    "unit": "pct",
                    "value": parameters.get("cpn_level") / parameters.get("nb_obs")
                    if parameters.get("cpn_level")
                    else "SolveFor",
                },
                "dayCountBasis": "PerPeriod",
                "frequency": frequencies.get(parameters.get("frequency")).get("name"),
            },
        }
    )


def set_template(data, tickers_df):

    frequencies = {
        "Annually": {"coeff": 1, "name": "12M", "api_name": "OnePerYear"},
        "Semestrial": {"coeff": 2, "name": "6M", "api_name": "TwoPerYear"},
        "Quarterly": {"coeff": 4, "name": "3M", "api_name": "FourPerYear"},
        "Monthly": {"coeff": 12, "name": "1M", "api_name": "TwelvePerYear"},
    }

    barrier_types = {
        "European": "European",
        "American Continuous": "Intraday",
        "American Daily Close": "CloseOnly",
        "None": "None",
    }

    dff_tickers = tickers_df[tickers_df["ticker"] == data.get("ticker_1")]
    tickers = [
        dff_tickers.iloc[0].loc["ticker_ric"]
        if str(dff_tickers.iloc[0].loc["ticker_ric"]) != "nan"
        else dff_tickers.iloc[0].loc["ticker"]
    ]
    if data.get("ticker_2") not in [None, "", " "]:
        dff_tickers = tickers_df[tickers_df["ticker"] == data.get("ticker_2")]
        tickers.append(
            dff_tickers.iloc[0].loc["ticker_ric"]
            if str(dff_tickers.iloc[0].loc["ticker_ric"]) != "nan"
            else dff_tickers.iloc[0].loc["ticker"]
        )
    if data.get("ticker_3") not in [None, "", " "]:
        dff_tickers = tickers_df[tickers_df["ticker"] == data.get("ticker_3")]
        tickers.append(
            dff_tickers.iloc[0].loc["ticker_ric"]
            if str(dff_tickers.iloc[0].loc["ticker_ric"]) != "nan"
            else dff_tickers.iloc[0].loc["ticker"]
        )
    if data.get("ticker_4") not in [None, "", " "]:
        dff_tickers = tickers_df[tickers_df["ticker"] == data.get("ticker_4")]
        tickers.append(
            dff_tickers.iloc[0].loc["ticker_ric"]
            if str(dff_tickers.iloc[0].loc["ticker_ric"]) != "nan"
            else dff_tickers.iloc[0].loc["ticker"]
        )
    if data.get("ticker_5") not in [None, "", " "]:
        dff_tickers = tickers_df[tickers_df["ticker"] == data.get("ticker_5")]
        tickers.append(
            dff_tickers.iloc[0].loc["ticker_ric"]
            if str(dff_tickers.iloc[0].loc["ticker_ric"]) != "nan"
            else dff_tickers.iloc[0].loc["ticker"]
        )

    underlyings = [
        {
            "id": ticker,
            "type": "ric",
            "orderType": "MarketOnClose",
            "strikeDate": dt_today().strftime("%Y-%m-%d"),
        }
        for ticker in tickers
    ]

    ccy = Currencies.query.filter(Currencies.id == data.get("id_currency")).first().code
    performance_type = "WorstOf" if len(tickers) > 1 else "SingleAsset"
    frequency = frequencies.get(
        Frequencies.query.filter(Frequencies.id == data.get("id_frequency"))
        .first()
        .code
    )

    num_period = int(data.get("months_to_maturity") * frequency.get("coeff") / 12)

    if (
        Products.query.filter(Products.id == data.get("id_product")).first().name
        == "Autocall"
    ):
        product = "Autocall"
        autocall_start_period = data.get("autocall_start_period")
        atk_barriers = (
            {
                "barrier": [
                    {"unit": "pct", "value": f"{float(data.get('autocall_barrier'))}"}
                    for i in range(0, num_period - autocall_start_period + 1)
                ],
            }
            if data.get("autocall_barrier") and "-" not in data.get("autocall_barrier")
            else {
                "barrier": [
                    {
                        "unit": "pct",
                        "value": f"{float(data.get('autocall_barrier').split('-')[i]) if data.get('autocall_barrier') else 100}",
                    }
                    for i in range(0, len(data.get("autocall_barrier").split("-")))
                ],
            }
        )

    else:
        # autocall_start_period = int(
        #     data.get("months_to_maturity") * frequency.get("coeff") / 12
        # )
        product = "ReverseConvertible"
        autocall_start_period = None
        atk_barriers = None

    params = {
        "barrier_type": barrier_types.get(
            BarrierTypes.query.filter(BarrierTypes.id == data.get("id_barrier_type"))
            .first()
            .type
        )
        if data.get("id_barrier_type") != 4
        else None,
        "strike": data.get("barrier_strike"),
        "ki_barrier": data.get("barrier_level"),
        "cpn_type": "Memory" if data.get("is_memory") else "Digit",
        "cpn_barrier": data.get("coupon_barrier") if data.get("coupon_barrier") else 0,
        "cpn_level": data.get("coupon_level"),
        "frequency": frequency.get("api_name"),
        "atk_barrier": atk_barriers,
        "nb_obs": frequency.get("coeff"),
    }

    downside = downside_params(params, performance_type)
    coupon = coupon_params(params, performance_type)

    template_data = {
        "metaData": {
            "quoteType": "Indicative",
            "barclaysApiVersion": "1.4",
            "clientAppName": "Exane Derivatives Staging",
            "requestUser": os.environ.get("BARCLAYS_API_ID"),
            "clientQuoteId": "Integration",
            "requestDateTime": dt_today("string_timestamp"),
            "callbackURL": None,
        },
        "product": {
            "payoff": product,
            "currency": ccy,
            "tenor": f"{data.get('months_to_maturity')}M",
            "assets": underlyings,
            "settlementType": "cash",
        },
        "keyDates": {
            "strikeDate": dt_today().strftime("%Y-%m-%d"),
            "issueDate": (dt_today() + pd.tseries.offsets.BDay(5)).strftime("%Y-%m-%d"),
            "feePaymentDate": (dt_today() + pd.tseries.offsets.BDay(5)).strftime(
                "%Y-%m-%d"
            ),
        },
        "legalForm": {
            "wrapper": Wrappers.query.filter(Wrappers.id == data.get("id_wrapper"))
            .first()
            .name,
            "tradingMethod": "Percentage",
            "issueSize": {"value": data.get("notional"), "currency": ccy},
            "denomination": {"value": 1000, "currency": ccy},
            "minTradeAmount": {"currency": ccy, "value": 10000},
            "jurisdictions": [
                {
                    "countryCode": "FR",
                    "offerType": "PrivatePlacement",
                    "kidLanguages": ["FR"],
                }
            ],
        },
        "pricing": {
            "fee": {
                "unit": "pct",
                "value": f"{round(100 - data.get('offer_price'), 2) if data.get('offer_price') else 'SolveFor'}",
            },
            "reOffer": {
                "unit": "pct",
                "value": f"{round(data.get('offer_price'), 2) if data.get('offer_price') else 'SolveFor'}",
            },
        },
        "bookingCenter": {
            "primaryCounterpartyCode": os.environ.get("BARCLAYS_API_COUNTERPARTY_CODE"),
            "issuePrice": {"unit": "pct", "value": "100"},
            "notional": {"value": data.get("notional"), "currency": ccy},
        },
        "downside": {**downside},
        "coupon": {**coupon},
        "pricing_id": data.get("id_request"),
    }

    if (
        Products.query.filter(Products.id == data.get("id_product")).first().name
        == "Autocall"
    ):
        callevent = {
            "callEvent": {
                "type": "Autocall",
                "frequency": frequency.get("name"),
                "deferral": autocall_start_period - 1,
                "autocall": {
                    **atk_barriers,
                    "performanceType": performance_type,
                    "observationType": "AtMaturity",
                },
                "rebate": [
                    {"unit": "pct", "value": "100"}
                    for x in range(0, num_period - autocall_start_period + 1)
                ],
            },
        }
        template_data = {**template_data, **callevent}

    return template_data

from emails.mail_sender import Mailer
from multipricer.models.base_multipricer import *

import pandas as pd


class MailPricingLTQ(Mailer):
    def __init__(self):
        super().__init__()

        self.to = ["emp@leonteq.com"]
        self.cc = ["exane.structuring@exane.com"]

    def to_issuer_format(self, df):
        # Reformat Autocall Triggers
        for i in range(0, len(df.index)):
            if (
                df.iloc[i].loc["autocall_barrier"] is not None
                and "-" in df.iloc[i].loc["autocall_barrier"]
            ):
                nc_periods = []
                for j in range(0, df.iloc[i].loc["autocall_start_period"] - 1):
                    nc_periods.append("9999")
                if len(nc_periods) > 0:
                    df.at[i, "autocall_barrier"] = (
                        "-".join(nc_periods) + "-" + df.iloc[i].loc["autocall_barrier"]
                    )
                else:
                    df.at[i, "autocall_barrier"] = df.iloc[i].loc["autocall_barrier"]

        # Set Solve For Column
        df["Solve For"] = df["id_solve_for"].apply(
            lambda x: SolveFor.query.filter(SolveFor.id == x).first().code
        )

        # Add Pricer's Columns
        df["Product"] = df["id_product"].apply(
            lambda x: Products.query.filter(Products.id == x).first().name
        )
        df["Product"] = df["Product"].apply(
            lambda x: "Generic Autocall" if x == "Autocall" else "BRC"
        )
        df["Currency"] = df["id_currency"].apply(
            lambda x: Currencies.query.filter(Currencies.id == x).first().code
        )
        df["BBG Code 1"] = df["ticker_1"]
        df["BBG Code 2"] = df["ticker_2"]
        df["BBG Code 3"] = df["ticker_3"]
        df["BBG Code 4"] = df["ticker_4"]
        df["Put Strike (%)"] = df["barrier_strike"].apply(
            lambda x: (str(x)) if x is not None else x
        )
        df["Coupon barrier (%)"] = df["coupon_barrier"].apply(
            lambda x: (str(x) + " %") if x is not None else x
        )
        df["KO Type"] = "Period End"
        df["KO Barrier (%)"] = df["autocall_barrier"].apply(
            lambda x: (str(x) + " %") if x is not None else x
        )
        df["Coupon p.a. (%)"] = df["coupon_level"]
        df["Coupon type"] = df["is_memory"].apply(
            lambda x: "memory" if x is True else "non-memory"
        )
        df["Upfront / NotePrice (%)"] = df["offer_price"]
        df["Tenor (m)"] = df["months_to_maturity"]
        df["Barrier Type"] = df["id_barrier_type"].apply(
            lambda x: (BarrierTypes.query.filter(BarrierTypes.id == x).first().type)
            if x != 4
            else None
        )
        df["KI Barrier (%)"] = df["barrier_level"].apply(
            lambda x: (str(float(x))) if not pd.isna(x) else 0
        )
        df["Observation Frequency (m)"] = df["id_frequency"].apply(
            lambda x: Frequencies.query.filter(Frequencies.id == x).first().nb_months
        )
        df["OTC"] = df["id_wrapper"].apply(
            lambda x: Wrappers.query.filter(Wrappers.id == x).first().name
        )
        df["OTC"] = df["OTC"].apply(lambda x: "OTC" if x == "Swap" else x)
        df["Issuer"] = "RNL"
        df["Coupon Frequency (m)"] = df["id_frequency"].apply(
            lambda x: Frequencies.query.filter(Frequencies.id == x).first().nb_months
        )

        # Reformat Columns
        df.loc[df["Solve For"] == "Reoffer", "Upfront / NotePrice (%)"] = ""
        df.loc[df["Solve For"] == "Upfront", "Upfront / NotePrice (%)"] = ""
        df.loc[df["Solve For"] == "Coupon", "Coupon p.a. (%)"] = ""
        df.loc[df["BBG Code 2"].isnull(), "BBG Code 2"] = ""
        df.loc[df["BBG Code 3"].isnull(), "BBG Code 3"] = ""
        df.loc[df["BBG Code 4"].isnull(), "BBG Code 4"] = ""
        df.loc[df["KO Barrier (%)"].isnull(), "KO Barrier (%)"] = ""
        df.loc[df["Coupon barrier (%)"].isnull(), "Coupon barrier (%)"] = ""
        df.loc[df["Barrier Type"].isnull(), "KI Barrier (%)"] = ""
        df.loc[df["Barrier Type"].isnull(), "Barrier Type"] = "None"
        df.loc[
            df["Barrier Type"] == "American Continuous", "Barrier Type"
        ] = "Continuous"
        df.loc[
            df["Barrier Type"] == "American Daily Close", "Barrier Type"
        ] = "Daily on close"
        df["Funding Spread (bps)"] = df.apply(
            lambda x: "" if x["OTC"] == "Note" else int(x["funding_spread"] * 100),
            axis=1,
        )

        # Keep Pricer's Columns (depending on the product)
        if df.iloc[0].loc["Product"] == "Generic Autocall":
            df = df[
                [
                    "Product",
                    "Currency",
                    "BBG Code 1",
                    "BBG Code 2",
                    "BBG Code 3",
                    "BBG Code 4",
                    "Put Strike (%)",
                    "Coupon barrier (%)",
                    "KO Type",
                    "KO Barrier (%)",
                    "Coupon p.a. (%)",
                    "Coupon type",
                    "Upfront / NotePrice (%)",
                    "Tenor (m)",
                    "Barrier Type",
                    "KI Barrier (%)",
                    "Observation Frequency (m)",
                    "OTC",
                    "Funding Spread (bps)",
                ]
            ]
        else:
            df = df[
                [
                    "Product",
                    "Currency",
                    "Issuer",
                    "BBG Code 1",
                    "BBG Code 2",
                    "BBG Code 3",
                    "BBG Code 4",
                    "Coupon p.a. (%)",
                    "Coupon Frequency (m)",
                    "Tenor (m)",
                    "Put Strike (%)",
                    "Barrier Type",
                    "KI Barrier (%)",
                    "Upfront / NotePrice (%)",
                ]
            ]

        # Convert DataFrame To HTML Table
        replace = {
            "<thead>": "",
            "</thead>": "",
            "<tbody>": "",
            "</tbody>": "",
            "th>": "td>",
        }
        self.content = df.to_html(index=False, na_rep="")
        for key, value in replace.items():
            self.content = self.content.replace(key, value)

    def load_issuer_format(self, body, solve_for, nb_per_year):
        df = pd.read_html(body, header=0)[0]
        results = []
        is_error = []
        id_quote = []

        # Find quote in email body
        text = "rfq quote reference: <a href="
        start = body.find(text) + len(text)
        quote_id = body[start + 75 : start + 75 + 37]

        for i in range(0, len(df.index)):
            id_quote.append(quote_id)
            if df.iloc[i].loc["Priced?"] == "Yes":
                if solve_for == "Coupon":
                    results.append(f"{df.iloc[i].loc['Coupon p.a. (%)']}%")
                    is_error.append(False)
                else:
                    results.append(f"{df.iloc[i].loc['Upfront / NotePrice (%)']}%")
                    is_error.append(False)
            else:
                results.append(df.iloc[i].loc["message"])
                is_error.append(True)
        return results, is_error, id_quote

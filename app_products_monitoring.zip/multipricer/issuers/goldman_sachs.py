import datetime
import pandas as pd

from emails.mail_sender import Mailer
from multipricer.models.base_multipricer import *


class MailPricingGS(Mailer):
    def __init__(self):
        super().__init__()

        self.to = ["emea-rfq-xpress-inbox@gs.com"]
        self.cc = ["exane.structuring@exane.com"]

    def to_issuer_format(self, df):

        # Reformat Autocall Triggers
        if df["id_wrapper"].iloc[0] == 1:

            for i in range(0, len(df.index)):
                if (
                    df.iloc[i].loc["autocall_barrier"] is not None
                    and "-" in df.iloc[i].loc["autocall_barrier"]
                ):
                    periods = df.iloc[i].loc["autocall_barrier"].split("-")
                    df.at[i, "autocall_barrier"] = "|".join(periods)
                else:
                    df.at[i, "autocall_barrier"] = df.iloc[i].loc["autocall_barrier"]
        else:

            for i in range(0, len(df.index)):
                if (
                    df.iloc[i].loc["autocall_barrier"] is not None
                    and "-" in df.iloc[i].loc["autocall_barrier"]
                ):
                    nc_periods = [
                        "NC"
                        for j in range(0, df.iloc[i].loc["autocall_start_period"] - 1)
                    ]
                    periods = df.iloc[i].loc["autocall_barrier"].split("-")
                    df.at[i, "autocall_barrier"] = " | ".join(nc_periods + periods)
                else:
                    df.at[i, "autocall_barrier"] = df.iloc[i].loc["autocall_barrier"]

        # Set Solve For Column
        df["Solve For"] = df["id_solve_for"].apply(
            lambda x: SolveFor.query.filter(SolveFor.id == x).first().code
        )
        df["Product"] = df["id_product"].apply(
            lambda x: Products.query.filter(Products.id == x).first().name
        )
        # Add Pricer's Columns
        df["Product"] = df[["Product", "id_wrapper"]].apply(
            lambda x: "Autocallable"
            if x[0] == "Autocall" and x[1] == 1
            else "AutocallableSwap"
            if x[0] == "Autocall" and x[1] != 1
            else "Reverse",
            axis=1,
        )
        df["Currency"] = df["id_currency"].apply(
            lambda x: Currencies.query.filter(Currencies.id == x).first().code
        )
        # df["Strike Date"] = datetime.datetime.today().strftime("%d/%m/%Y")
        df["Notional"] = df["notional"].astype(int)
        df["Strike Date"] = ""
        df["Tenor (m)"] = df["months_to_maturity"]
        df["BBG Code 1"] = df["ticker_1"]
        df["BBG Code 2"] = df["ticker_2"]
        df["BBG Code 3"] = df["ticker_3"]
        df["BBG Code 4"] = df["ticker_4"]
        df["BBG Code 5"] = df["ticker_5"]
        df["Underliers"] = df[
            ["ticker_1", "ticker_2", "ticker_3", "ticker_4", "ticker_5"]
        ].values.tolist()
        df["Underliers"] = df["Underliers"].apply(lambda x: " | ".join(filter(None, x)))
        df["Downside Strike (%)"] = df["Strike (%)"] = (
            df["barrier_strike"].astype(float).astype(str)
        )
        df["Barrier Type"] = df["id_barrier_type"].apply(
            lambda x: (BarrierTypes.query.filter(BarrierTypes.id == x).first().type)
            if x != 4
            else None
        )
        df["Barrier Type"] = df["Barrier Type"].apply(
            lambda x: (
                x
                if x == "European"
                else ("Continuous" if x == "American Continuous" else "Daily")
            )
            if x is not None
            else x
        )
        df["Barrier Level (%)"] = df["KI Barrier (%)"] = df[
            ["barrier_level", "Strike (%)"]
        ].apply(lambda x: (str(float(x[0]))) if not pd.isna(x[0]) else x[1], axis=1)
        df["Obsv Period"] = df["id_frequency"].apply(
            lambda x: Frequencies.query.filter(Frequencies.id == x).first().code
        )
        df["Obsv Period"] = df["Early Termination Period"] = df[
            "Coupon Frequency"
        ] = df["Obsv Period"].apply(
            lambda x: "Annual"
            if x == "Annually"
            else "SemiAnnual"
            if x == "Semestrial"
            else x
        )
        df["Observation Date"] = ""
        df["Payment Date"] = ""
        df["Non Autocallable Period"] = df["autocall_start_period"].apply(
            lambda x: x - 1 if x else None
        )
        df["Autocall Trigger (%)"] = df["Early Termination Level (%)"] = df[
            "autocall_barrier"
        ]
        df["Coupon PA (%)"] = df["Coupon p.a. (%)"] = df["coupon_level"]
        df["Coupon Type"] = df["is_memory"].apply(
            lambda x: "Memory Phoenix" if x is True else "Phoenix"
        )
        df["Memory Coupon"] = "Yes" if df["is_memory"].iloc[0] else "No"
        df["Coupon Type"] = df.apply(
            lambda x: "Fixed" if x["Product"] == "Reverse" else x["Coupon Type"],
            axis=1,
        )
        df["Coupon Trigger"] = df["Coupon Trigger (%)"] = df["Trigger Level (%)"] = df[
            "coupon_barrier"
        ].apply(lambda x: x if x else 0)
        df["Redemption Level (%)"] = 0
        df["Upfront Fee (%)"] = df["Reoffer (%)"] = df.apply(
            lambda x: -x["offer_price"]
            if Wrappers.query.filter(Wrappers.id == x["id_wrapper"]).first().name
            == "Swap"
            else x["offer_price"],
            axis=1,
        )
        df["Funding Leg"] = "Yes"
        df["FL Leg Rate Option"] = df["Currency"].apply(
            lambda x: "EUR-EURIBOR-TELERATE" if x == "EUR" else x + "-LIBOR-BBA"
        )
        df["FL Leg Payment Period (m)"] = df["id_frequency"].apply(
            lambda x: Frequencies.query.filter(Frequencies.id == x).first().nb_months
        )
        df["FL Period Dates"] = ""
        df["FL Leg Spread (%)"] = df["funding_spread"]

        # Reformat Columns
        df.loc[df["Solve For"] == "Reoffer", "Reoffer (%)"] = ""
        df.loc[df["Solve For"] == "Upfront", "Upfront Fee (%)"] = ""
        df.loc[df["Solve For"] == "Coupon", "Coupon PA (%)"] = ""
        df.loc[df["Solve For"] == "Coupon", "Coupon p.a. (%)"] = ""
        df.loc[df["Barrier Level (%)"].isnull(), "Barrier Level (%)"] = ""
        df.loc[df["FL Leg Spread (%)"].isnull(), "FL Leg Spread (%)"] = ""
        df.loc[df["BBG Code 2"].isnull(), "BBG Code 2"] = ""
        df.loc[df["BBG Code 3"].isnull(), "BBG Code 3"] = ""
        df.loc[df["BBG Code 4"].isnull(), "BBG Code 4"] = ""
        df.loc[df["BBG Code 5"].isnull(), "BBG Code 5"] = ""

        if df["Product"].iloc[0] == "Autocallable":

            # Keep Pricer's Columns
            df = df[
                [
                    "Product",
                    "Notional",
                    "Currency",
                    "Tenor (m)",
                    "BBG Code 1",
                    "BBG Code 2",
                    "BBG Code 3",
                    "BBG Code 4",
                    "BBG Code 5",
                    "Strike (%)",
                    "Barrier Type",
                    "KI Barrier (%)",
                    "Early Termination Period",
                    "Non Autocallable Period",
                    "Early Termination Level (%)",
                    "Coupon p.a. (%)",
                    "Trigger Level (%)",
                    "Memory Coupon",
                    "Reoffer (%)",
                ]
            ]

        elif df["Product"].iloc[0] == "AutocallableSwap":
            # Keep Pricer's Columns
            df = df[
                [
                    "Product",
                    "Currency",
                    "Strike Date",
                    "Notional",
                    "Tenor (m)",
                    "Underliers",
                    "Downside Strike (%)",
                    "Barrier Type",
                    "Barrier Level (%)",
                    "Obsv Period",
                    "Observation Date",
                    "Payment Date",
                    "Autocall Trigger (%)",
                    "Coupon PA (%)",
                    "Coupon Type",
                    "Coupon Trigger",
                    "Redemption Level (%)",
                    "Upfront Fee (%)",
                    "Funding Leg",
                    "FL Leg Rate Option",
                    "FL Leg Payment Period (m)",
                    "FL Period Dates",
                    "FL Leg Spread (%)",
                ]
            ]
        else:

            # Keep Pricer's Columns
            df = df[
                [
                    "Product",
                    "Notional",
                    "Currency",
                    "Tenor (m)",
                    "BBG Code 1",
                    "BBG Code 2",
                    "BBG Code 3",
                    "BBG Code 4",
                    "BBG Code 5",
                    "Strike (%)",
                    "Barrier Type",
                    "KI Barrier (%)",
                    "Coupon Type",
                    "Coupon Trigger (%)",
                    "Coupon Frequency",
                    "Reoffer (%)",
                    "Coupon p.a. (%)",
                ]
            ]

        # Convert DataFrame To HTML Table
        replace = {
            "<thead>": "",
            "</thead>": "",
            "<tbody>": "",
            "</tbody>": "",
            "th>": "td>",
        }
        self.content = df.to_html(index=False, na_rep="")
        for key, value in replace.items():
            self.content = self.content.replace(key, value)

    def load_issuer_format(self, body, solve_for, nb_per_year):
        df = pd.read_html(body, header=0)[0]
        results = []
        is_error = []
        id_quote = []

        # Check for errors on each request
        for i in range(0, len(df.index)):
            id_quote.append(str(df.iloc[i].loc["Request Id"]))

            # Retrieve data from the OTC formatting
            if "Upfront Fee (%)" in df:
                if solve_for == "Coupon":
                    if not pd.isnull(df.iloc[i].loc["Coupon PA (%)"]):
                        results.append(f"{df.iloc[i].loc['Coupon PA (%)']}%")
                        is_error.append(False)
                    else:
                        results.append(df.iloc[i].loc["SystemRemark"])
                        is_error.append(True)
                else:
                    if not pd.isnull(df.iloc[i].loc["Upfront Fee (%)"]):
                        results.append(f"{df.iloc[i].loc['Upfront Fee (%)']}%")
                        is_error.append(False)
                    else:
                        results.append(df.iloc[i].loc["SystemRemark"])
                        is_error.append(True)
            else:
                if solve_for == "Coupon":
                    if not pd.isnull(df.iloc[i].loc["Coupon p.a. (%)"]):
                        results.append(f"{df.iloc[i].loc['Coupon p.a. (%)']}%")
                        is_error.append(False)
                    else:
                        results.append(df.iloc[i].loc["SystemRemark"])
                        is_error.append(True)
                else:
                    if not pd.isnull(df.iloc[i].loc["Reoffer (%)"]):
                        results.append(f"{df.iloc[i].loc['Reoffer (%)']}%")
                        is_error.append(False)
                    else:
                        results.append(df.iloc[i].loc["SystemRemark"])
                        is_error.append(True)

        return results, is_error, id_quote

from emails.mail_sender import Mailer
from multipricer.models.base_multipricer import *

import numpy as np
import pandas as pd
import re


class MailPricingJPM(Mailer):
    def __init__(self):
        super().__init__()

        self.to = ["jpm_emea_autopricer@jpmorgan.com"]
        self.cc = ["exane.structuring@exane.com", "arnaud.beligond@jpmorgan.com"]

    def to_issuer_format(self, df):
        # Reformat Autocall Triggers
        for i in range(0, len(df.index)):
            if (
                df.iloc[i].loc["autocall_barrier"] is not None
                and "-" in df.iloc[i].loc["autocall_barrier"]
            ):
                periods = df.iloc[i].loc["autocall_barrier"].split("-")[:-1]
                df.at[i, "autocall_barrier"] = "/".join(periods)

        df["step_up_down"] = 0
        # Set Solve For Column
        df["Solve For"] = df["id_solve_for"].apply(
            lambda x: SolveFor.query.filter(SolveFor.id == x).first().code
        )

        # Add Pricer's Columns
        df["Product"] = df["id_product"].apply(
            lambda x: Products.query.filter(Products.id == x).first().name
        )
        df["Product"] = df["Product"].apply(
            lambda x: "Enhanced Phoenix Autocallable"
            if x == "Autocall"
            else "Barrier Reverse Convertible"
        )
        df["Wrapper"] = df["id_wrapper"].apply(
            lambda x: Wrappers.query.filter(Wrappers.id == x).first().name
        )
        df["Currency"] = df["id_currency"].apply(
            lambda x: Currencies.query.filter(Currencies.id == x).first().code
        )
        df["Tenor (m)"] = df["months_to_maturity"]
        df["Settlement Type"] = "CashOrPhysical"
        df["BBG Code 1"] = df["ticker_1"]
        df["BBG Code 2"] = df["ticker_2"]
        df["BBG Code 3"] = df["ticker_3"]
        df["BBG Code 4"] = df["ticker_4"]
        df["BBG Code 5"] = df["ticker_5"]
        df["Strike (%)"] = df["barrier_strike"].astype(float).astype(str)
        df["Barrier Type"] = df["id_barrier_type"].apply(
            lambda x: BarrierTypes.query.filter(BarrierTypes.id == x).first().type
            if x != 4
            else None
        )
        df["Barrier Type"] = df["Barrier Type"].apply(
            lambda x: (
                "European"
                if x == "European"
                else ("Continuous" if x == "American Continuous" else "Daily")
            )
            if x is not None
            else x
        )
        df["KI Barrier (%)"] = df["barrier_level"].apply(
            lambda x: (str(float(x))) if not pd.isna(x) else 0
        )
        df["Early Termination Period"] = df["id_frequency"].apply(
            lambda x: Frequencies.query.filter(Frequencies.id == x).first().code
        )
        df["Early Termination Period"] = df["Early Termination Period"].apply(
            lambda x: "Semi-Annually" if x == "Semestrial" else x
        )
        df["Non Autocallable Period"] = df["autocall_start_period"].apply(
            lambda x: x - 1 if x is not None else 0
        )
        df["Early Termination Level (%)"] = df["autocall_barrier"].apply(
            lambda x: str(x) if x is not None else "9999%"
        )
        df["Early Termination StepUp/Down (%)"] = df["step_up_down"].apply(
            lambda x: str(x) if x is not None else 0
        )
        df["Coupon Period"] = df["Early Termination Period"]
        df["Coupon p.a. (%)"] = df["coupon_level"]
        df["Trigger Level (%)"] = df["coupon_barrier"].apply(
            lambda x: str(x) + "%" if x else "0%"
        )
        df["Memory coupon"] = df["is_memory"].apply(
            lambda x: "YES" if x is True else "NO"
        )
        df["Floating Leg Period"] = df["id_frequency"].apply(
            lambda x: str(
                Frequencies.query.filter(Frequencies.id == x).first().nb_months
            )
            + "M"
            if Frequencies.query.filter(Frequencies.id == x).first().nb_months
            in [1, 3, 6]
            else "6M"
        )
        df["Floating Leg Rate Index"] = df[["Currency", "Floating Leg Period"]].agg(
            lambda x: f"RTI_{x['Floating Leg Period']}_EURIBOR_{x['Currency']}"
            if x["Currency"] == "EUR"
            else f"RTI_{x['Floating Leg Period']}_LIBOR_{x['Currency']}",
            axis=1,
        )
        # lambda x, y: f"RTI_{df['Floating Leg Period'][0]}_EURIBOR_EUR"
        # if x == "EUR"
        # else f"RTI_{df['Floating Leg Period'][0]}_LIBOR_" + x
        df["Floating Spread (%)"] = df["funding_spread"]
        df["Initial Accrual Date"] = ""
        df["Final Accrual Date"] = ""
        df["Reoffer (%)"] = df.apply(
            lambda x: (
                -x["offer_price"] if x["Wrapper"] == "Swap" else x["offer_price"]
            )
            if x["Solve For"] == "Coupon"
            else None,
            axis=1,
        )
        df["Notional"] = df["notional"].astype(int)
        df["Notional"] = df["Notional"].apply(lambda x: "{:,}".format(x))

        # Reformat Columns
        df.loc[df["Solve For"] == "Reoffer", "Reoffer (%)"] = ""
        df.loc[df["Solve For"] == "Upfront", "Reoffer (%)"] = ""
        df.loc[df["Solve For"] == "Coupon", "Coupon p.a. (%)"] = ""
        df.loc[df["BBG Code 2"].isnull(), "BBG Code 2"] = "-"
        df.loc[df["BBG Code 3"].isnull(), "BBG Code 3"] = "-"
        df.loc[df["BBG Code 4"].isnull(), "BBG Code 4"] = "-"
        df.loc[df["BBG Code 5"].isnull(), "BBG Code 5"] = "-"
        df.loc[df["Floating Spread (%)"].isnull(), "Spread (%)"] = "-"
        df.loc[df["Floating Spread (%)"] == "-", "Floating Leg Period"] = "-"
        df.loc[df["Floating Spread (%)"] == "-", "Floating Leg Rate Index"] = "-"
        df.loc[df["Floating Spread (%)"] == "-", "Floating Spread (%)"] = "-"

        if df["Product"].iloc[0] == "Barrier Reverse Convertible":

            df["Early Termination Period"] = df["Non Autocallable Period"] = df[
                "Early Termination Level (%)"
            ] = df["Early Termination StepUp/Down (%)"] = df["Trigger Level (%)"] = df[
                "Memory coupon"
            ] = "-"

        # Keep Pricer's Columns
        df = df[
            [
                "Product",
                "Wrapper",
                "Currency",
                "Tenor (m)",
                "BBG Code 1",
                "BBG Code 2",
                "BBG Code 3",
                "BBG Code 4",
                "BBG Code 5",
                "Strike (%)",
                "Barrier Type",
                "KI Barrier (%)",
                "Early Termination Period",
                "Non Autocallable Period",
                "Early Termination Level (%)",
                "Early Termination StepUp/Down (%)",
                "Coupon Period",
                "Coupon p.a. (%)",
                "Trigger Level (%)",
                "Memory coupon",
                "Floating Leg Period",
                "Floating Leg Rate Index",
                "Floating Spread (%)",
                "Initial Accrual Date",
                "Final Accrual Date",
                "Reoffer (%)",
                "Notional",
            ]
        ]

        if df.iloc[0].loc["Wrapper"] == "Note":
            df = df.drop(
                columns=[
                    "Floating Leg Period",
                    "Floating Leg Rate Index",
                    "Floating Spread (%)",
                    "Initial Accrual Date",
                    "Final Accrual Date",
                ]
            )

        # Convert DataFrame To HTML Table
        replace = {
            "<thead>": "",
            "</thead>": "",
            "<tbody>": "",
            "</tbody>": "",
            "th>": "td>",
        }
        self.content = df.to_html(index=False, na_rep="")
        for key, value in replace.items():
            self.content = self.content.replace(key, value)

    def load_issuer_format(self, body, solve_for, nb_per_year):
        df = pd.read_html(body)[0]
        results = []
        is_error = []
        id_quote = []
        for i in range(0, len(df.index)):
            id = re.findall(r"\d{7}", str(df.iloc[i].loc["Validation"]))
            if id:
                id_quote.append(id[0])
            else:
                id_quote.append("")
            # if "(" in str(df.iloc[i].loc["Validation"]):
            #     id_quote.append(df.iloc[i].loc["Validation"].split("(")[1][0:-1])
            # else:
            #     if "J" in str(df.iloc[i].loc["Validation"]):
            #         id_quote.append(df.iloc[i].loc["Validation"].split("J")[0])
            #     else:
            #         id_quote.append(str(df.iloc[i].loc["Validation"]))
            if solve_for == "Coupon":
                if type(df.iloc[i].loc["Coupon p.a. (%)"]) != str and (
                    str(df.iloc[i].loc["Coupon p.a. (%)"]) in ["nan", "", " "]
                    or df.iloc[i].loc["Coupon p.a. (%)"].astype(str) == "Error"
                ):
                    results.append(df.iloc[i].loc["Validation"])
                    is_error.append(True)
                else:
                    results.append(df.iloc[i].loc["Coupon p.a. (%)"])
                    is_error.append(False)
            elif solve_for == "Upfront":
                if str(df.iloc[i].loc["Reoffer (%)"]) not in ["nan", "", " "]:
                    results.append(f"{-float(df.iloc[i].loc['Reoffer (%)'][0:-1])}%")
                    is_error.append(False)
                else:
                    results.append(df.iloc[i].loc["Validation"])
                    is_error.append(True)
            else:
                if str(df.iloc[i].loc["Reoffer (%)"]) not in ["nan", "", " "]:
                    results.append(df.iloc[i].loc["Reoffer (%)"])
                    is_error.append(False)
                else:
                    results.append(df.iloc[i].loc["Validation"])
                    is_error.append(True)
        return results, is_error, id_quote

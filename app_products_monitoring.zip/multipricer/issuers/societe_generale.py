import numpy as np

from multipricer.models.base_multipricer import *


def set_template(data, tickers_df):

    frequencies = {
        "Monthly": "OnePerMonth",
        "Quarterly": "FourPerYear",
        "Semestrial": "TwoPerYear",
        "Annually": "OnePerYear",
    }

    barrier_types = {
        "European": "European",
        "American Continuous": "USIntraday",
        "American Daily Close": "USClose",
        "None": "None",
    }

    dff_tickers = tickers_df[tickers_df["ticker"] == data.get("ticker_1")]
    tickers = [
        dff_tickers.iloc[0].loc["ticker_sg"]
        if str(dff_tickers.iloc[0].loc["ticker_sg"]) != "nan"
        else dff_tickers.iloc[0].loc["ticker"]
    ]
    if data.get("ticker_2") not in [None, "", " "]:
        dff_tickers = tickers_df[tickers_df["ticker"] == data.get("ticker_2")]
        tickers.append(
            dff_tickers.iloc[0].loc["ticker_sg"]
            if str(dff_tickers.iloc[0].loc["ticker_sg"]) != "nan"
            else dff_tickers.iloc[0].loc["ticker"]
        )
    if data.get("ticker_3") not in [None, "", " "]:
        dff_tickers = tickers_df[tickers_df["ticker"] == data.get("ticker_3")]
        tickers.append(
            dff_tickers.iloc[0].loc["ticker_sg"]
            if str(dff_tickers.iloc[0].loc["ticker_sg"]) != "nan"
            else dff_tickers.iloc[0].loc["ticker"]
        )
    if data.get("ticker_4") not in [None, "", " "]:
        dff_tickers = tickers_df[tickers_df["ticker"] == data.get("ticker_4")]
        tickers.append(
            dff_tickers.iloc[0].loc["ticker_sg"]
            if str(dff_tickers.iloc[0].loc["ticker_sg"]) != "nan"
            else dff_tickers.iloc[0].loc["ticker"]
        )
    if data.get("ticker_5") not in [None, "", " "]:
        dff_tickers = tickers_df[tickers_df["ticker"] == data.get("ticker_5")]
        tickers.append(
            dff_tickers.iloc[0].loc["ticker_sg"]
            if str(dff_tickers.iloc[0].loc["ticker_sg"]) != "nan"
            else dff_tickers.iloc[0].loc["ticker"]
        )

    underlyings = [{"id": ticker, "idType": "Bloomberg"} for ticker in tickers]

    freq_in_months = (
        Frequencies.query.filter(Frequencies.id == data.get("id_frequency"))
        .first()
        .nb_months
    )

    currency = (
        Currencies.query.filter(Currencies.id == data.get("id_currency")).first().code
    )
    wrapper = Wrappers.query.filter(Wrappers.id == data.get("id_wrapper")).first().name
    has_early_redemption_step_down = (
        True
        if data.get("autocall_barrier") and "-" in data.get("autocall_barrier")
        else False
    )

    recall_treshold = None
    step = None
    floor = None
    if has_early_redemption_step_down:
        periods = data.get("autocall_barrier").split("-")
        diff = []
        for j in range(1, len(periods)):
            diff.append(float(periods[j]) - float(periods[j - 1]))
        recall_treshold = float(data.get("autocall_barrier").split("-")[0])
        step = -np.mean(diff)
        floor = float(data.get("autocall_barrier").split("-")[-1])

    solve_for = (
        SolveFor.query.filter(SolveFor.id == data.get("id_solve_for")).first().code
    )

    product = Products.query.filter(Products.id == data.get("id_product")).first().name

    if currency == "EUR":
        swap_reference_rate = f"EIBEUR{freq_in_months}M"
    else:
        swap_reference_rate = f"LIB{currency.upper()}{freq_in_months}M"

    data = {
        "variationParameters": {
            "productType": "Autocall"
            if product == "Autocall"
            else "ReverseConvertible",
            "productSubtype": ("PhoenixPlus" if data.get("is_memory") else "Phoenix")
            if product == "Autocall"
            else "BarrierReverseConvertible",
            "wrapper": wrapper,
            "underlying": underlyings,
            "optionType": "WorstOf" if len(underlyings) > 1 else "Single",
            "currency": currency,
            "offerPrice": data.get("offer_price") if wrapper == "Note" else None,
            "UpfrontFee": data.get("offer_price") if wrapper == "Swap" else None,
            "swapUpFront": data.get("offer_price") if wrapper == "Swap" else None,
            "swapReferenceRate": swap_reference_rate if wrapper == "Swap" else None,
            "swapSpread": data.get("funding_spread") if wrapper == "Swap" else None,
            "maturityValue": {
                "currentValue": {
                    "value": data.get("months_to_maturity"),
                    "unit": "Month",
                }
            },
            "solvingMode": "ConditionalAndRecallCoupons"
            if product == "Autocall" and solve_for == "Coupon"
            else (
                "couponValue"
                if wrapper != "Autocall" and solve_for == "Coupon"
                else ("OfferPrice" if solve_for == "Reoffer" else "SwapUpFront")
            ),
            "remunerationMode": "Reoffer" if wrapper == "Note" else "Upfront",
            "settlementType": "Cash",
            "strikeMode": "Close",
            "notionalAmount": data.get("notional"),
            "strike": data.get("barrier_strike"),
            "kiBarrierType": barrier_types.get(
                BarrierTypes.query.filter(
                    BarrierTypes.id == data.get("id_barrier_type")
                )
                .first()
                .type
            )
            if data.get("id_barrier_type") != 4
            else "None",
            "kiBarrier": data.get("barrier_level")
            if str(data.get("barrier_level")) not in ["nan", "", "None"]
            else 0,
            "couponType": "Memory" if data.get("is_memory") else "Digit",
            "couponFrequency": frequencies.get(
                Frequencies.query.filter(Frequencies.id == data.get("id_frequency"))
                .first()
                .code
            ),
            "couponBarrier": data.get("coupon_barrier"),
            "couponValue": float(data.get("coupon_level")) / (12 / freq_in_months)
            if data.get("coupon_level")
            else None,
            "recallCoupon": float(data.get("coupon_level")) / (12 / freq_in_months)
            if data.get("coupon_level")
            else None,
            "recallStartPeriod": data.get("autocall_start_period"),
            "stepDownStartPeriod": data.get("autocall_start_period"),
            "hasEarlyRedemptionStepDownFeature": has_early_redemption_step_down,
            "step": step,
            "finalThreshold": floor,
            "recallThreshold": recall_treshold,
            "settlementOffset": 5,
            "scheduleDrivenBy": "ValuationDates",
            "scheduleGeneration": "Forward",
            "denomination": 1000,
            "issuePriceDefinition": "Percent",
            "priceType": "Dirty",
        },
        "pricing_id": data.get("id_request"),
    }

    if wrapper == "Swap":
        data.get("variationParameters").pop("offerPrice")
    else:
        data.get("variationParameters").pop("UpfrontFee")
        data.get("variationParameters").pop("swapUpFront")
        data.get("variationParameters").pop("swapReferenceRate")
        data.get("variationParameters").pop("swapSpread")

    if solve_for == "Coupon":
        data.get("variationParameters").pop("couponValue")
        data.get("variationParameters").pop("recallCoupon")

    if not has_early_redemption_step_down:
        data.get("variationParameters").pop("stepDownStartPeriod")
        data.get("variationParameters").pop("hasEarlyRedemptionStepDownFeature")
        data.get("variationParameters").pop("step")
        data.get("variationParameters").pop("finalThreshold")
        data.get("variationParameters").pop("recallThreshold")

    if product != "Autocall":
        try:
            data.get("variationParameters").pop("recallCoupon")
        except KeyError:
            pass
        data.get("variationParameters").pop("recallStartPeriod")
        data.get("variationParameters").pop("couponBarrier")
        data.get("variationParameters").pop("couponType")

    return data

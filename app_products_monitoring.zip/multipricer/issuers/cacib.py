import datetime
import pandas as pd

from emails.mail_sender import Mailer
from multipricer.models.base_multipricer import *


class MailPricingCACIB(Mailer):
    def __init__(self):
        super().__init__()

        self.to = ["EISEmailPricer@ca-cib.com"]
        self.cc = ["exane.structuring@exane.com"]

    def to_issuer_format(self, df):
        # Reformat Autocall Triggers
        for i in range(0, len(df.index)):
            if (
                df.iloc[i].loc["autocall_barrier"] is not None
                and "-" in df.iloc[i].loc["autocall_barrier"]
            ):
                periods = df.iloc[i].loc["autocall_barrier"].split("-")
                df.at[i, "autocall_barrier"] = "/".join(periods)

        # Set Solve For Column
        df["Solve For"] = df["id_solve_for"].apply(
            lambda x: SolveFor.query.filter(SolveFor.id == x).first().code
        )

        # Add Pricer's Columns
        df["Product Type"] = df["id_product"].apply(
            lambda x: Products.query.filter(Products.id == x).first().name
        )
        df["Product Type"] = df["Product Type"].apply(
            lambda x: "Autocallable" if x == "Autocall" else x
        )
        df["Currency"] = df["id_currency"].apply(
            lambda x: Currencies.query.filter(Currencies.id == x).first().code
        )
        df["Wrapper"] = "EMTN"
        df["Tenor"] = df["months_to_maturity"]
        df["BBG Code 1"] = df["ticker_1"]
        df["BBG Code 2"] = df["ticker_2"]
        df["BBG Code 3"] = df["ticker_3"]
        df["BBG Code 4"] = df["ticker_4"]
        df["BBG Code 5"] = df["ticker_5"]
        df["Strike (%)"] = df["barrier_strike"].apply(
            lambda x: (str(x)) if x is not None else x
        )
        df["Barrier Type"] = df["id_barrier_type"].apply(
            lambda x: (BarrierTypes.query.filter(BarrierTypes.id == x).first().type)
            if x != 4
            else None
        )
        df["KI Barrier (%)"] = df["barrier_level"].apply(
            lambda x: (str(float(x))) if not pd.isna(x) else 0
        )
        df["Early Termination Period"] = df["id_frequency"].apply(
            lambda x: Frequencies.query.filter(Frequencies.id == x).first().code
        )
        df["Early Termination Period"] = df["Early Termination Period"].apply(
            lambda x: "Semi-Annually" if x == "Semestrial" else x
        )
        df["Non Autocallable Period"] = df["autocall_start_period"].apply(
            lambda x: x - 1 if x is not None else 0
        )
        df["Early Termination Level (%)"] = df["autocall_barrier"].apply(
            lambda x: str(x) if x is not None else x
        )
        df["Coupon p.a. (%)"] = df["coupon_level"]
        df["Coupon Trigger Level (%)"] = df.apply(
            lambda x: str(x["coupon_barrier"]) if x["coupon_barrier"] else 0, axis=1,
        )
        df["Memory Coupon"] = df["is_memory"].apply(
            lambda x: "YES" if x is True else "NO"
        )
        df["Reoffer (%)"] = df["offer_price"]
        df["Note"] = ""
        df["ID"] = ""

        # Reformat Columns
        df.loc[df["Solve For"] == "Reoffer", "Reoffer (%)"] = ""
        df.loc[df["Solve For"] == "Coupon", "Coupon p.a. (%)"] = ""
        df.loc[df["BBG Code 2"].isnull(), "BBG Code 2"] = ""
        df.loc[df["BBG Code 3"].isnull(), "BBG Code 3"] = ""
        df.loc[df["BBG Code 4"].isnull(), "BBG Code 4"] = ""
        df.loc[df["BBG Code 5"].isnull(), "BBG Code 5"] = ""
        df.loc[df["Barrier Type"].isnull(), "KI Barrier (%)"] = ""
        df.loc[df["Barrier Type"].isnull(), "Barrier Type"] = "No Barrier"
        df.loc[df["Barrier Type"] == "American Continuous", "Barrier Type"] = "American"
        df.loc[
            df["Barrier Type"] == "American Daily Close", "Barrier Type"
        ] = "Daily Close"

        # Keep Pricer's Columns
        df = df[
            [
                "Product Type",
                "Currency",
                "Wrapper",
                "Tenor",
                "BBG Code 1",
                "BBG Code 2",
                "BBG Code 3",
                "BBG Code 4",
                "BBG Code 5",
                "Strike (%)",
                "Barrier Type",
                "KI Barrier (%)",
                "Early Termination Period",
                "Non Autocallable Period",
                "Early Termination Level (%)",
                "Coupon p.a. (%)",
                "Coupon Trigger Level (%)",
                "Memory Coupon",
                "Reoffer (%)",
                "Note",
                "ID",
            ]
        ]

        # Convert DataFrame To HTML Table
        replace = {
            "<thead>": "",
            "</thead>": "",
            "<tbody>": "",
            "</tbody>": "",
            "th>": "td>",
        }
        self.content = df.to_html(index=False, na_rep="")
        for key, value in replace.items():
            self.content = self.content.replace(key, value)

    def load_issuer_format(self, body, solve_for, nb_per_year):
        df = pd.read_html(body)[0]
        df = df[df["Wrapper"] == "EMTN"]
        results = []
        is_error = []
        id_quote = []
        for i in range(0, len(df.index)):
            if str(df.iloc[i].loc["ID"]) != "nan":
                id_quote.append(str(df.iloc[i].loc["ID"]))
            else:
                id_quote.append(None)
            if solve_for == "Coupon":
                if not pd.isna(df.iloc[i].loc["Coupon p.a. (%)"]):
                    cpn = float(df.iloc[i].loc["Coupon p.a. (%)"])
                    cpn_pa = round(cpn, 2)
                    results.append(f"{cpn_pa}%")
                    is_error.append(False)
                else:
                    results.append(df.iloc[i].loc["Note"])
                    is_error.append(True)

            else:
                if not pd.isna(df.iloc[i].loc["Reoffer (%)"]):
                    results.append(f"{round(float(df.iloc[i].loc['Reoffer (%)']),2)}%")
                    is_error.append(False)
                else:
                    results.append(df.iloc[i].loc["Note"])
                    is_error.append(True)
        return results, is_error, id_quote

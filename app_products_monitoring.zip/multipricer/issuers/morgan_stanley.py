import datetime
import pandas as pd

from emails.mail_sender import Mailer
from multipricer.models.base_multipricer import *


class MailPricingMS(Mailer):
    def __init__(self):
        super().__init__()

        self.to = ["Morgan.Stanley.Swiss@morganstanley.com"]

    def to_issuer_format(self, df):
        # Reformat Autocall Triggers
        for i in range(0, len(df.index)):
            if (
                df.iloc[i].loc["autocall_barrier"] is not None
                and "-" in df.iloc[i].loc["autocall_barrier"]
            ):
                periods = df.iloc[i].loc["autocall_barrier"].split("-")
                df.at[i, "autocall_barrier"] = "%;".join(periods)
            elif df.iloc[i].loc["autocall_barrier"] is None:
                # periods = []
                # nb_periods = int(df.iloc[i].loc["months_to_maturity"]) / (
                #     Frequencies.query.filter(
                #         Frequencies.id == int(df.iloc[i].loc["id_frequency"])
                #     )
                #     .first()
                #     .nb_months
                # )
                # for j in range(0, int(nb_periods) - 1):
                #     periods.append("999")
                df.at[i, "coupon_barrier"] = "0"

        # Set Solve For Column
        df["Solve For"] = df["id_solve_for"].apply(
            lambda x: SolveFor.query.filter(SolveFor.id == x).first().code
        )

        # Add Pricer's Columns
        df["Request ID"] = ""
        df["Product"] = "Phoenix Autocall"
        df["Wrapper"] = df["id_wrapper"].apply(
            lambda x: Wrappers.query.filter(Wrappers.id == x).first().name
        )
        df["Issuer"] = "MSBV"
        df["EIS"] = "NO"
        df["Currency"] = df["id_currency"].apply(
            lambda x: Currencies.query.filter(Currencies.id == x).first().code
        )
        df["Size"] = df["notional"].astype(int)
        df["Reoffer (%)"] = df["offer_price"]
        df["Strike Date"] = datetime.datetime.today().strftime("%d-%b-%y")
        df["Tenor (m)"] = df["months_to_maturity"]
        df["BBG Code 1"] = df["ticker_1"]
        df["BBG Code 2"] = df["ticker_2"]
        df["BBG Code 3"] = df["ticker_3"]
        df["BBG Code 4"] = df["ticker_4"]
        df["BBG Code 5"] = df["ticker_5"]
        df["Gearing"] = round(-10000 / df["barrier_strike"], 0)
        df["Gearing"] = df["Gearing"].astype(int).astype(str) + "%"
        df["Strike (%)"] = df["barrier_strike"].astype(float).astype(str) + "%"
        df["KI Barrier (%)"] = df["barrier_level"].apply(
            lambda x: (str(int(x)) + "%") if not pd.isna(x) else 0
        )
        df["Barrier Type"] = df["id_barrier_type"].apply(
            lambda x: (BarrierTypes.query.filter(BarrierTypes.id == x).first().type)
            if x != 4
            else None
        )
        df["Early Termination Period"] = df["id_frequency"].apply(
            lambda x: Frequencies.query.filter(Frequencies.id == x).first().code
        )
        df["Early Termination Level (%)"] = df["autocall_barrier"].apply(
            lambda x: str(x) + "%" if x is not None else "999.00%"
        )
        df["KO Coupon"] = ""
        df["Autocall from Period X"] = df["autocall_start_period"].apply(
            lambda x: x if x is not None else 1
        )
        df["Coupon Frequency"] = df["id_frequency"].apply(
            lambda x: Frequencies.query.filter(Frequencies.id == x).first().code
        )
        df["Trigger Level (%)"] = df["coupon_barrier"].apply(lambda x: str(x) + "%")
        df["nb_periods_pa"] = df["id_frequency"].apply(
            lambda x: 12
            / int(Frequencies.query.filter(Frequencies.id == x).first().nb_months)
        )
        df["Periodic Coupon (%)"] = df.apply(
            lambda x: (round(x["coupon_level"] / x["nb_periods_pa"], 2))
            if x["coupon_level"] is not None
            else None,
            axis=1,
        )
        df["Periodic Coupon (%)"] = df["Periodic Coupon (%)"].astype(str) + "%"
        df["Memory coupon"] = df["is_memory"].apply(
            lambda x: "YES" if x is True else "NO"
        )
        df["Swap Index"] = "3M"
        df["Swap Spread (%)"] = df["funding_spread"]

        # Reformat Columns
        df.loc[df["Solve For"] == "Reoffer", "Reoffer (%)"] = "?"
        df.loc[df["Solve For"] == "Upfront", "Reoffer (%)"] = "?"
        df.loc[df["Solve For"] == "Coupon", "Periodic Coupon (%)"] = "?"
        df.loc[df["BBG Code 2"].isnull(), "BBG Code 2"] = ""
        df.loc[df["BBG Code 3"].isnull(), "BBG Code 3"] = ""
        df.loc[df["BBG Code 4"].isnull(), "BBG Code 4"] = ""
        df.loc[df["BBG Code 5"].isnull(), "BBG Code 5"] = ""
        df.loc[df["KI Barrier (%)"].isnull(), "KI Barrier (%)"] = ""
        df.loc[df["Periodic Coupon (%)"].isnull(), "Periodic Coupon (%)"] = ""
        df.loc[df["Wrapper"] == "Note", "Swap Index"] = "-"
        df.loc[df["Wrapper"] == "Note", "Swap Spread (%)"] = ""
        df.loc[
            df["Barrier Type"] == "American Continuous", "Barrier Type"
        ] = "Continuous"
        df.loc[
            df["Barrier Type"] == "American Daily Close", "Barrier Type"
        ] = "DailyClose"
        df.loc[
            df["Early Termination Period"] == "Semestrial", "Early Termination Period"
        ] = "Semi-Annually"
        df.loc[df["Barrier Type"].isnull(), "Barrier Type"] = "Breached"

        # Keep Pricer's Columns
        df = df[
            [
                "Request ID",
                "Product",
                "Wrapper",
                "Issuer",
                "EIS",
                "Currency",
                "Size",
                "Reoffer (%)",
                "Strike Date",
                "Tenor (m)",
                "BBG Code 1",
                "BBG Code 2",
                "BBG Code 3",
                "BBG Code 4",
                "BBG Code 5",
                "Gearing",
                "Strike (%)",
                "KI Barrier (%)",
                "Barrier Type",
                "Early Termination Period",
                "Early Termination Level (%)",
                "KO Coupon",
                "Autocall from Period X",
                "Coupon Frequency",
                "Trigger Level (%)",
                "Periodic Coupon (%)",
                "Memory coupon",
                "Swap Index",
                "Swap Spread (%)",
            ]
        ]

        # Convert DataFrame To HTML Table
        replace = {
            "<thead>": "",
            "</thead>": "",
            "<tbody>": "",
            "</tbody>": "",
            "th>": "td>",
        }
        self.content = df.to_html(index=False, na_rep="")
        for key, value in replace.items():
            self.content = self.content.replace(key, value)

    def load_issuer_format(self, body, solve_for, nb_per_year):
        df = pd.read_html(body, header=0)[0]
        results = []
        is_error = []
        id_quote = []
        for i in range(0, len(df.index)):
            id_quote.append(str(df.iloc[i].loc["MS ID"]))
            if "Error Information" not in df.columns:
                if solve_for == "Coupon":
                    results.append(df.iloc[i].loc["Coupon Per Annum (%)"][0:-1])
                    is_error.append(False)
                else:
                    try:
                        results.append(df.iloc[i].loc["Reoffer (%)"])
                    except:
                        results.append(df.iloc[i].loc["Upfront (%)"])
                    is_error.append(False)
            else:
                if str(df.iloc[i].loc["Error Information"]) == "nan":
                    if solve_for == "Coupon":
                        results.append(df.iloc[i].loc["Coupon Per Annum (%)"][0:-1])
                        is_error.append(False)
                    else:
                        try:
                            results.append(df.iloc[i].loc["Reoffer (%)"])
                        except:
                            results.append(df.iloc[i].loc["Upfront (%)"])
                        is_error.append(False)
                else:
                    results.append(df.iloc[i].loc["Error Information"])
                    is_error.append(True)
        return results, is_error, id_quote

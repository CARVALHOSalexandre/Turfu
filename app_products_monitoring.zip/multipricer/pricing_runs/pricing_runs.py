from apps.multipricer import send_rfq
from multipricer.models.base_multipricer import *
from local_db_mgt import Issuers
from utils.api_sg import last_opinions_bnpp, SGPricer
from utils.sql import amc_composition, traded_ul
from utils.data_sg import sg_implied_volatilites
from utils.other.docoh import trending_reddit_tickers
from models.base import *
from app import server

import uuid
import time
import datetime
import pandas as pd


def encode(text):
    return text.encode("ascii", "xmlcharrefreplace").decode("utf-8")


def get_pricing_run_params():
    df_last_opinions = last_opinions_bnpp()
    dff_last_opinions = df_last_opinions[df_last_opinions["opinion"] == "Outperform"]
    tickers_last_opinions = dff_last_opinions["ticker"].to_numpy()
    df_apollo = amc_composition(cfin=42048123)
    tickers_apollo = df_apollo["ticker"].to_numpy()
    tickers_recently_traded = traded_ul()
    tickers_reddit = trending_reddit_tickers()
    return {
        encode("🌍 Main Indices"): {
            "tickers": [
                "SPX",
                "SX5E",
                "SMI",
                "CAC",
                "RTY",
                "UKX",
                "NDX",
                "HSCEI",
                "DAX",
                "SD3E",
                "MXEU",
                "MXWO",
                "CS90",
            ],
            "pricing_params": {
                "reoffer": 98,
                "maturity_in_months": 18,
                "cpn_barrier": 90,
                "ki_barrier": 90,
                "currencies": ["EUR", "USD"],
                "issuers": ["BBVA", "JPM", "LTQ", "MS", "SG", "Barclays"],
            },
            "description": "Selection of popular indices",
        },
        encode("🔬 Exane BNPP Opinions"): {
            "tickers": tickers_last_opinions,
            "pricing_params": {
                "reoffer": 98,
                "maturity_in_months": 18,
                "cpn_barrier": 70,
                "ki_barrier": 70,
                "currencies": ["EUR", "USD"],
                "issuers": ["BBVA", "JPM", "LTQ", "MS", "SG", "Barclays"],
            },
            "description": "Last week's top recommendations from Exane BNPP",
        },
        encode("🛰️ Exane Apollo"): {
            "tickers": tickers_apollo,
            "pricing_params": {
                "reoffer": 98,
                "maturity_in_months": 18,
                "cpn_barrier": 70,
                "ki_barrier": 70,
                "currencies": ["EUR", "USD"],
                "issuers": ["BBVA", "JPM", "LTQ", "MS", "SG", "Barclays"],
            },
            "description": "Current components of the index",
        },
        encode("🔔 Momentum"): {
            "tickers": tickers_recently_traded,
            "pricing_params": {
                "reoffer": 98,
                "maturity_in_months": 18,
                "cpn_barrier": 70,
                "ki_barrier": 70,
                "currencies": ["EUR", "USD"],
                "issuers": ["BBVA", "JPM", "LTQ", "MS", "SG", "Barclays"],
            },
            "description": "Stocks traded in Structured Products by our clients in the last 10 BDays",
        },
        encode("📈 Reddit Trends"): {
            "tickers": tickers_reddit,
            "pricing_params": {
                "reoffer": 98,
                "maturity_in_months": 18,
                "cpn_barrier": 70,
                "ki_barrier": 70,
                "currencies": ["EUR", "USD"],
                "issuers": ["BBVA", "JPM", "LTQ", "MS", "SG", "Barclays"],
            },
            "description": "Stocks trending on Reddit over the last week",
        },
        encode("🛢️ Thematic ETFs"): {
            "tickers": [
                "XOP UP",
                "USO UP",
                "XME UP",
                "XBI UP",
                "GDX UP",
                "XHB UP",
                "IYT UF",
                "OIL FP",
                "XLF UP",
                "XLI UP",
                "XLB UP",
                "IYF UP",
                "IYH UP",
                "IYR UP",
                "XLP UP",
                "XLU UP",
                "XLV UP",
                "XLY UP",
            ],
            "pricing_params": {
                "reoffer": 98,
                "maturity_in_months": 18,
                "cpn_barrier": 75,
                "ki_barrier": 75,
                "currencies": ["EUR", "USD"],
                "issuers": ["BBVA", "JPM", "LTQ", "MS", "SG", "Barclays"],
            },
            "description": "Selection of popular macrotrends ETF",
        },
    }


def start_pricing_run():
    server.logger.info(f"Starting new pricing run")
    pricing_params = get_pricing_run_params()
    for theme, theme_params in pricing_params.items():
        params = dict(
            id_protection_type=ProtectionTypes.query.filter(
                ProtectionTypes.type == "PDI"
            )
            .first()
            .id,
            id_product=Products.query.filter(Products.name == "Autocall").first().id,
            id_barrier_type=(
                BarrierTypes.query.filter(BarrierTypes.type == "European").first().id
            ),
            id_wrapper=Wrappers.query.filter(Wrappers.name == "Note").first().id,
            id_solve_for=SolveFor.query.filter(SolveFor.code == "Coupon").first().id,
            id_frequency=Frequencies.query.filter(Frequencies.code == "Quarterly")
            .first()
            .id,
            id_user=1,
            offer_price=theme_params.get("pricing_params").get("reoffer"),
            months_to_maturity=theme_params.get("pricing_params").get(
                "maturity_in_months"
            ),
            barrier_strike=100,
            barrier_level=theme_params.get("pricing_params").get("ki_barrier"),
            coupon_level=None,
            coupon_barrier=theme_params.get("pricing_params").get("cpn_barrier"),
            autocall_barrier=100,
            autocall_start_period=1,
            notional=500000,
            funding_spread=None,
            is_memory=True,
            is_live=False,
            is_auto=True,
            comments=theme,
            timestamp=datetime.datetime.now(),
            ticker_2=None,
            ticker_3=None,
            ticker_4=None,
            ticker_5=None,
        )

        nb_ticker = 0
        params["id_request_email"] = str(uuid.uuid4())
        nb_line = 1
        for ticker in theme_params.get("tickers"):
            params["ticker_1"] = ticker
            nb_ticker += 1

            for currency in theme_params.get("pricing_params").get("currencies"):
                params["tickers_ccy"] = f"{ticker} ({currency})"
                params["id_currency"] = (
                    Currencies.query.filter(Currencies.code == currency).first().id
                )
                params["id_line"] = nb_line
                nb_line += 1

                for issuer in theme_params.get("pricing_params").get("issuers"):
                    params["id_issuer"] = (
                        Issuers.query.filter(Issuers.short_name == issuer).first().id
                    )
                    params["id_request"] = str(uuid.uuid4())
                    insert_request(params)

            # Send Request To All Issuers
            if nb_line >= 10 - len(
                theme_params.get("pricing_params").get("currencies")
            ) or nb_ticker >= len(theme_params.get("tickers")):
                for issuer in theme_params.get("pricing_params").get("issuers"):
                    try:
                        send_rfq(
                            params.get("id_request_email"),
                            Issuers.query.filter(Issuers.short_name == issuer)
                            .first()
                            .id,
                        )
                    except Exception as e:
                        server.logger.exception(
                            f"Pricing Run Send Request Error | {issuer} - {params.get('id_request_email')} | {e}"
                        )
                nb_line = 1
                params["id_request_email"] = str(uuid.uuid4())


def get_run_result(date=datetime.datetime.today()):
    server.logger.info(f"Retrieving {date.strftime('%d/%m/%Y')} Pricing Run Results")
    # Load Request Result Table
    df_results = pd.DataFrame(
        db.session.query(
            PricingResults.id_issuer,
            PricingResults.result,
            PricingResults.tickers_ccy,
            PricingResults.is_best_result,
            PricingResults.is_error,
            PricingResults.comments,
        )
        .filter(PricingResults.timestamp_sent > date - datetime.timedelta(days=1))
        .filter(PricingResults.timestamp_sent < date + datetime.timedelta(days=1))
        .filter(PricingResults.comments != None)
        .all()
    )
    if not df_results.empty:
        df_results["result_parsed"] = df_results.apply(
            lambda x: float(x["result"][0:-1])
            if x["result"] and x["is_error"] == 0
            else 0,
            axis=1,
        )
        df_results = df_results.sort_values(by=["result_parsed"], ascending=False)
        df_results["issuer"] = df_results["id_issuer"].apply(
            lambda x: Issuers.query.filter(Issuers.id == x).first().short_name
        )
        df_results["tickers"] = df_results["tickers_ccy"].apply(
            lambda x: x.split(" (")[0]
        )
        df_results["ccy"] = df_results["tickers_ccy"].apply(
            lambda x: x.split(" (")[1][0:-1]
        )
        df_results = df_results.drop(columns=["id_issuer", "result_parsed"])
        df_results = df_results[
            [
                "issuer",
                "tickers",
                "ccy",
                "result",
                "is_error",
                "is_best_result",
                "comments",
            ]
        ]
        return df_results


def format_run_result(df_results):
    if not df_results.empty:
        run_params = get_pricing_run_params()
        themes = df_results["comments"].unique()
        all_tickers = df_results["tickers"].unique()
        df_name_sg = SGPricer().corresponding_tickers(all_tickers)
        df_last_opinions = last_opinions_bnpp()
        df_last_opinions.drop(columns=["IV_12M_100%"], inplace=True)
        df_vol = sg_implied_volatilites(all_tickers)
        df_sg = pd.merge(df_vol, df_name_sg, on="ticker", how="outer")
        df_sg = pd.merge(df_sg, df_last_opinions, on="ticker", how="outer")
        data = {}
        for theme in themes:
            data[theme] = {}
            # Set Data
            data[theme]["description"] = {}
            data[theme]["universe"] = {}
            params = run_params.get(theme)
            pricing_params = params.get("pricing_params")
            data[theme]["description"]["title"] = params.get("description")
            data[theme]["description"]["currencies"] = pricing_params.get("currencies")
            data[theme]["description"][
                "format"
            ] = f"Autocall, Note, {pricing_params.get('maturity_in_months')} months, Reoffer {pricing_params.get('reoffer')}%, Notional 500,000, Coupons are p.a."
            data[theme]["description"][
                "payoff"
            ] = f"Memory, Quarterly Obs, 100% from Q1, Cpn Barrier {pricing_params.get('cpn_barrier')}%, European Barrier {pricing_params.get('ki_barrier')}%"
            data[theme]["description"]["nb_quotes"] = 0
            # Set Table Data
            dff_theme = df_results[df_results["comments"] == theme]
            tickers = dff_theme["tickers"].unique()
            for ticker in tickers:
                dff_f = dff_theme[dff_theme["tickers"] == ticker]
                data[theme]["universe"][ticker] = [[], [], [], None, "-", "-"]
                i = -1
                for currency in pricing_params.get("currencies"):
                    i += 1
                    dff_ff = dff_f[
                        (dff_f["ccy"] == currency) & (dff_f["is_error"] == False)
                    ]
                    data[theme]["universe"][ticker][0].append("nan")
                    data[theme]["universe"][ticker][1].append("")
                    data[theme]["universe"][ticker][2].append(0)
                    if not dff_ff.empty and True in dff_ff["is_best_result"].to_numpy():
                        result = dff_ff[dff_ff["is_best_result"] == True][
                            "result"
                        ].values[0]
                        issuer = dff_ff[dff_ff["is_best_result"] == True][
                            "issuer"
                        ].values[0]
                        nb_issuers = len(dff_ff.index)
                        if float(result[0:-1]) > 1:
                            data[theme]["universe"][ticker][0][i] = result
                            data[theme]["universe"][ticker][1][i] = f"({issuer})"
                            data[theme]["description"]["nb_quotes"] = (
                                data[theme]["description"]["nb_quotes"] + 1
                            )
                            if nb_issuers > 1:
                                data[theme]["universe"][ticker][2][
                                    i
                                ] = f"({nb_issuers} quotes)"
                            else:
                                data[theme]["universe"][ticker][2][i] = f"(1 quote)"
                # If ticker in SG universe
                if ticker in list(df_sg["ticker"]):
                    dff_sg = df_sg[df_sg["ticker"] == ticker].reset_index()
                    data[theme]["universe"][ticker][3] = (
                        dff_sg["name"][0]
                        if str(dff_sg["name"][0]) not in ["", "nan"]
                        else (
                            dff_sg["name_sg"][0]
                            if str(dff_sg["name_sg"][0]) not in ["", "nan"]
                            else (
                                (
                                    Instrument.query.join(
                                        Codes, Codes.cfcfin == Instrument.ifcfin
                                    )
                                    .filter(Codes.cfcode == ticker)
                                    .first()
                                ).ifnom
                            )
                        )
                    )
                else:
                    r = (
                        Instrument.query.join(Codes, Codes.cfcfin == Instrument.ifcfin)
                        .filter(Codes.cfcode == ticker)
                        .first()
                    )
                    if r:
                        data[theme]["universe"][ticker][3] = r.ifnom
                    else:
                        data[theme]["universe"][ticker][3] = ""
                data[theme]["universe"][ticker][4] = (
                    f"{round(dff_sg['IV_12M_100%'][0] * 100, 1)}%"
                    if str(dff_sg["IV_12M_100%"][0]) not in ["nan", ""]
                    else "-"
                )
                data[theme]["universe"][ticker][5] = (
                    f"{round(dff_sg['upside'][0] * 100, 1)}%"
                    if str(dff_sg["upside"][0]) not in ["nan", ""]
                    else "-"
                )

        return data


def delete_previous_pricing_runs_results():
    server.logger.info("Deleting previous runs requests and results")
    # Delete Requests
    db.session.query(PricingRequests).filter(PricingRequests.is_auto == 1).delete(
        synchronize_session=False
    )
    db.session.commit()
    # Delete Results
    db.session.query(PricingResults).filter(PricingResults.comments is not None).delete(
        synchronize_session=False
    )
    db.session.commit()


def get_pricing_run_data():
    with server.app_context():
        delete_previous_pricing_runs_results()
        start_pricing_run()
        server.logger.info(
            f"{datetime.datetime.now()} - Waiting 1H for all results to arrive"
        )
        time.sleep(3600)
        df = get_run_result()
        json_data = format_run_result(df)
        return json_data


if __name__ == "__main__":
    data = get_pricing_run_data()
    print("Pricing Run Completed")

from local_db_mgt import db
from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    Float,
    DateTime,
    ForeignKey,
)


# Dimension Tables
class Underlyings(db.Model):
    __tablename__ = "underlyings"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, autoincrement=True)
    bbg_ticker = Column(String, nullable=True)
    ric = Column(Integer, nullable=True)
    cfin = Column(Integer, nullable=True)
    id_issuer = Column(Integer, ForeignKey("issuers.id"), nullable=True)


class SolveFor(db.Model):
    __tablename__ = "solve_for"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, autoincrement=True)
    code = Column(String, nullable=True)


class Currencies(db.Model):
    __tablename__ = "currencies"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, autoincrement=True)
    code = Column(String, nullable=True)


class Frequencies(db.Model):
    __tablename__ = "frequencies"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, autoincrement=True)
    code = Column(String, nullable=True)
    nb_months = Column(Integer)


class Wrappers(db.Model):
    __tablename__ = "wrappers"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=True)


class Products(db.Model):
    __tablename__ = "products"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=True)


class BarrierTypes(db.Model):
    __tablename__ = "barrier_types"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, autoincrement=True)
    type = Column(String, nullable=True)


class ProtectionTypes(db.Model):
    __tablename__ = "protection_types"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, autoincrement=True)
    type = Column(String, nullable=True)


# Fact Tables
class PricingRequests(db.Model):
    __tablename__ = "pricing_requests"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, autoincrement=True)
    id_protection_type = Column(
        Integer, ForeignKey("protection_types.id"), nullable=True
    )
    id_product = Column(Integer, ForeignKey("products.id"), nullable=True)
    id_barrier_type = Column(Integer, ForeignKey("barrier_types.id"), nullable=True)
    id_currency = Column(Integer, ForeignKey("currencies.id"), nullable=True)
    id_wrapper = Column(Integer, ForeignKey("wrappers.id"), nullable=True)
    id_frequency = Column(Integer, ForeignKey("frequencies.id"), nullable=True)
    id_solve_for = Column(Integer, ForeignKey("solve_for.id"), nullable=True)
    id_user = Column(String, ForeignKey("user.id"), nullable=True)
    id_issuer = Column(Integer, ForeignKey("issuers.id"), nullable=True)
    id_line = Column(Integer, nullable=True)
    id_request = Column(String, nullable=True)
    id_request_email = Column(String, nullable=True)
    offer_price = Column(Float, nullable=True)
    barrier_strike = Column(Float, nullable=True)
    barrier_level = Column(Float, nullable=True)
    coupon_level = Column(Float, nullable=True)
    coupon_barrier = Column(Float, nullable=True)
    autocall_barrier = Column(String, nullable=True)
    notional = Column(Integer, nullable=True)
    funding_spread = Column(Float, nullable=True)
    months_to_maturity = Column(Integer, nullable=True)
    autocall_start_period = Column(Integer, nullable=True)
    is_memory = Column(Boolean, nullable=True, default=False)
    is_live = Column(Boolean, nullable=True, default=False)
    is_auto = Column(Boolean, nullable=True, default=False)
    timestamp = Column(DateTime, nullable=True)
    ticker_1 = Column(String, ForeignKey("underlyings.id"), nullable=True)
    ticker_2 = Column(String, ForeignKey("underlyings.id"), nullable=True)
    ticker_3 = Column(String, ForeignKey("underlyings.id"), nullable=True)
    ticker_4 = Column(String, ForeignKey("underlyings.id"), nullable=True)
    ticker_5 = Column(String, ForeignKey("underlyings.id"), nullable=True)


class PricingResults(db.Model):
    __tablename__ = "pricing_results"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, autoincrement=True)
    id_issuer = Column(Integer, ForeignKey("issuers.id"), nullable=True)
    id_solve_for = Column(Integer, ForeignKey("solve_for.id"), nullable=True)
    id_line = Column(Integer, nullable=True)
    id_request = Column(
        String, ForeignKey("pricing_requests.id_request"), nullable=True
    )
    id_request_email = Column(
        String, ForeignKey("pricing_requests.id_request"), nullable=True
    )
    id_quote = Column(String, nullable=True)
    tickers_ccy = Column(String, nullable=True)
    result = Column(String, nullable=True)
    comments = Column(String, nullable=True)
    timestamp_sent = Column(
        DateTime, ForeignKey("pricing_requests.timestamp"), nullable=True
    )
    timestamp_received = Column(DateTime, nullable=True)
    is_best_result = Column(Boolean, nullable=True, default=False)
    is_error = Column(Boolean, nullable=True, default=False)


def insert_request(params):
    # Insert Pricing Request
    new_request = PricingRequests(
        id_protection_type=params.get("id_protection_type"),
        id_product=params.get("id_product"),
        id_barrier_type=params.get("id_barrier_type"),
        id_currency=params.get("id_currency"),
        id_wrapper=params.get("id_wrapper"),
        id_solve_for=params.get("id_solve_for"),
        id_frequency=params.get("id_frequency"),
        id_user=params.get("id_user"),
        id_issuer=params.get("id_issuer"),
        id_line=params.get("id_line"),
        id_request=params.get("id_request"),
        id_request_email=params.get("id_request_email"),
        offer_price=params.get("offer_price"),
        months_to_maturity=params.get("months_to_maturity"),
        barrier_strike=params.get("barrier_strike"),
        barrier_level=params.get("barrier_level"),
        coupon_level=params.get("coupon_level"),
        coupon_barrier=params.get("coupon_barrier"),
        autocall_barrier=params.get("autocall_barrier"),
        autocall_start_period=params.get("autocall_start_period"),
        notional=params.get("notional"),
        funding_spread=params.get("funding_spread"),
        is_memory=params.get("is_memory"),
        is_live=params.get("is_live"),
        is_auto=params.get("is_auto"),
        timestamp=params.get("timestamp"),
        ticker_1=params.get("ticker_1"),
        ticker_2=params.get("ticker_2"),
        ticker_3=params.get("ticker_3"),
        ticker_4=params.get("ticker_4"),
        ticker_5=params.get("ticker_5"),
    )
    db.session.add(new_request)
    db.session.commit()

    # Insert Pricing Result
    new_result = PricingResults(
        id_line=params.get("id_line"),
        id_issuer=params.get("id_issuer"),
        id_request=params.get("id_request"),
        id_request_email=params.get("id_request_email"),
        id_solve_for=params.get("id_solve_for"),
        tickers_ccy=params.get("tickers_ccy"),
        comments=params.get("comments"),
        id_quote=None,
        result=None,
        timestamp_sent=params.get("timestamp"),
        timestamp_received=None,
    )
    db.session.add(new_result)
    db.session.commit()

#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pandas as pd
from app import server, CandidatesIsin, db
from local_db_mgt import Issuers

if __name__ == "__main__":
    with server.app_context():
        db.create_all()

        df = pd.read_clipboard()
        data = df.to_dict("records")

        for d in data:

            if d.get("code_exane") != 126262:

                for key, value in d.items():
                    if value == "nan":
                        d[key] = None

                issuer = Issuers(
                    id=d.get("id"),
                    code_exane=d.get("code_exane"),
                    name=d.get("name"),
                    short_name=d.get("short name"),
                    ric_extension_1=d.get("ric 1"),
                    ric_extension_2=d.get("ric 2"),
                    has_web_pricer=d.get("Web pricer"),
                    has_mail_pricer=d.get("mail pricer"),
                )

                db.session.add(issuer)
                db.session.commit()

        candidate = CandidatesIsin(
            isin="FREXI3DVT008",
            long_name="Exane 3D Value Europe RI",
            short_name="Exa 3D Value Eu RI",
            ticker="EXDM3DVT",
            code="3DVT",
            user="bichon_p",
        )
        db.session.add(candidate)
        db.session.commit()

from dash import dcc
from dash import html
import dash_bootstrap_components as dbc

# from dash_extensions import WebSocket


names = ["home", "trades", "products", "excel"]
tools_name = ["jobs"]

header = html.Div(
    [
        # dcc.Input(id="input", autoComplete="off"),
        # html.Div(id="message"),
        html.Div(  # Menu Nav Bar
            dbc.Container(
                [
                    dbc.Row(
                        [
                            dbc.Col(  # Title
                                html.Img(
                                    src="../assets/images/logo.svg",
                                    height="20px",
                                ),
                                id="turfu-title",
                                align="center",
                                width=2,
                            ),
                            dbc.Col(  # Links and search
                                dbc.Row(
                                    [
                                        dbc.Col(  # Links
                                            dbc.Row(
                                                [
                                                    dbc.Col(
                                                        html.A(
                                                            name.capitalize(),
                                                            href=f"/{name}",
                                                            className="h5 link-header",
                                                        ),
                                                        align="center",
                                                        width="auto",
                                                        className="mx-2",
                                                        style={"textAlign": "center"},
                                                    )
                                                    for name in names
                                                ]
                                                + [
                                                    dbc.Col(
                                                        html.A(
                                                            dbc.DropdownMenu(
                                                                [
                                                                    dbc.DropdownMenuItem(
                                                                        "Backtest",
                                                                        href="/backtest",
                                                                        style={
                                                                            "padding": "15px 10px 15px 20px"
                                                                        },
                                                                    ),
                                                                    dbc.DropdownMenuItem(
                                                                        "ISIN Creation",
                                                                        href="/isin",
                                                                        style={
                                                                            "padding": "15px 10px 15px 20px"
                                                                        },
                                                                    ),
                                                                    dbc.DropdownMenuItem(
                                                                        "Jobs",
                                                                        href="/jobs",
                                                                        style={
                                                                            "padding": "15px 10px 15px 20px"
                                                                        },
                                                                    ),
                                                                    dbc.DropdownMenuItem(
                                                                        "Local BDD",
                                                                        href="/bdd",
                                                                        style={
                                                                            "padding": "15px 10px 15px 20px"
                                                                        },
                                                                    ),
                                                                    dbc.DropdownMenuItem(
                                                                        "Logs",
                                                                        href="/logs",
                                                                        style={
                                                                            "padding": "15px 10px 15px 20px"
                                                                        },
                                                                    ),
                                                                    dbc.DropdownMenuItem(
                                                                        "Multipricer",
                                                                        href="/multipricer",
                                                                        style={
                                                                            "padding": "15px 10px 15px 20px"
                                                                        },
                                                                    ),
                                                                    dbc.DropdownMenuItem(
                                                                        "RFQ",
                                                                        href="/rfq",
                                                                        style={
                                                                            "padding": "15px 10px 15px 20px"
                                                                        },
                                                                    ),
                                                                    dbc.DropdownMenuItem(
                                                                        "Stocks",
                                                                        href="/stocks",
                                                                        style={
                                                                            "padding": "15px 10px 15px 20px"
                                                                        },
                                                                    ),
                                                                ],
                                                                label="Tools",
                                                                nav=True,
                                                                in_navbar=True,
                                                                caret=True,
                                                                style={
                                                                    "list-style": "none"
                                                                },
                                                            ),
                                                            className="h5 link-header",
                                                        ),
                                                        width="auto",
                                                        className="mx-2",
                                                        style={"textAlign": "center"},
                                                    ),
                                                ],
                                                justify="end",
                                                align="center",
                                            ),
                                            width=8,
                                            align="center",
                                        ),
                                        dbc.Col(  # Search
                                            dbc.Row(
                                                [
                                                    dbc.Col(
                                                        html.I(
                                                            className="fas fa-search",
                                                            title="Search",
                                                        ),
                                                        id="turfu-search-icon",
                                                        width="auto",
                                                        className="px-4",
                                                    ),
                                                    dbc.Col(
                                                        [
                                                            dbc.Input(
                                                                placeholder="Search",
                                                                type="text",
                                                                id="turfu-search-input",
                                                                list="turfu-list-suggested",
                                                                autoFocus=True,
                                                            ),
                                                            html.Datalist(
                                                                id="turfu-list-suggested"
                                                            ),
                                                        ],
                                                    ),
                                                ],
                                                justify="end",
                                                align="center",
                                                className="g-0",
                                            ),
                                            width=3,
                                        ),
                                    ],
                                    justify="end",
                                ),
                                width=10,
                                align="center",
                            ),
                        ],
                        justify="between",
                        className="w-100",
                    )
                ],
            ),
            className="navbar navbar-expand-lg bg-light py-2",
        ),
        # Notif Managers
        html.Div(id="msg"),
        dbc.Toast(
            id="header-notif-toast",
            is_open=False,
            header="",
            headerClassName="home-notif-header",
            bodyClassName="home-notif-body",
            className="home-notif-toast",
        ),
    ]
)


def turfu_subnav(name, **kwargs):
    if "style" not in kwargs:
        kwargs["style"] = {"maxWidth": "90%"}

    return html.Div(  # Sub Menu with Subtitles
        dbc.Container(
            id={"type": "turfu-subnav", "page": name},
            fluid=True,
            **kwargs,
        ),
        className="borded-card mb-1",
    )


def title_and_search(name, search=None, hide_search=None, hide_title=None, width=None):

    result = dbc.Container(
        [
            dcc.Location(
                id={"type": "url", "page": name}, search=search, refresh=False
            ),
            dbc.Row(
                [
                    dbc.Col(
                        [
                            html.H1(
                                children=name.upper(),
                                style={
                                    "fontFamily": "Roboto",
                                    "fontWeight": 500,
                                    "letterSpacing": "-0.05em",
                                    "fontSize": "100px",
                                }
                                if not hide_title
                                else {"display": "none"},
                                id=f"{name}-title",
                            ),
                            dbc.Fade(
                                html.Div(id=f"{name}-subtitle"),
                                id=f"{name}-subtitle-fade",
                                is_in=False,
                                appear=False,
                                style={"transition": "opacity 100ms ease"},
                            ),
                        ],
                        width=8,
                        # className="borded-card",
                    ),
                    dbc.Col(
                        [
                            dbc.Row(
                                [
                                    dbc.Col(
                                        [
                                            dbc.Spinner(
                                                html.Div(id=f"data-{name}-loader"),
                                                id=f"data-{name}-spinner",
                                                color="primary",
                                                type="grow",
                                                size="lg",
                                            ),
                                        ],
                                        width="auto",
                                    ),
                                    dbc.Col(
                                        [
                                            html.I(
                                                className="fas fa-search",
                                                title="Search",
                                            )
                                        ],
                                        width="auto",
                                    ),
                                    dbc.Col(
                                        [
                                            dbc.Input(
                                                value=search,
                                                placeholder="Search anything",
                                                type="text",
                                                id=f"{name}-search-input",
                                                list=f"{name}-list-suggested",
                                                # autoFocus=True,
                                            ),
                                            html.Datalist(id=f"{name}-list-suggested"),
                                        ],
                                        width=8,
                                    ),
                                ],
                                justify="end",
                                align="center",
                            ),
                        ],
                        width=4,
                        className="d-none" if hide_search else "",
                    ),
                ],
                justify="between",
            ),
        ],
        className="mt-5",
        fluid=True if width else False,
        style={"maxWidth": width} if width else None,
        id=f"{name}-container",
    )
    return result


footer = html.Footer(
    [
        dbc.Container(
            [
                dbc.Row(
                    [
                        dbc.Col(
                            html.P(
                                "© 2021 Turfu | Exane Structuring Toolbox",
                                style={"color": "#7f8c8d", "marginBottom": 0},
                            ),
                            width=6,
                        ),
                        dbc.Col(
                            # dcc.Link(
                            #     "Contact | structuring@exane.com",
                            #     href="mailto:structuring@exane.com?subject=[Turfu]%20",
                            #     target="_blank",
                            #     style={"color": "#7f8c8d", "marginBottom": 0},
                            # ),
                            html.Img(
                                src="../assets/images/logo_turfu.svg",
                                height="30px",
                            ),
                            style={"textAlign": "right"},
                            width=6,
                        ),
                    ],
                    align="center",
                    justify="betweeen",
                    className="h-100",
                )
            ],
            className="h-100",
        )
    ],
    style={
        "bottom": 0,
        "height": "90px",
        "width": "100%",
        "marginTop": "50px",
        "border-top-width": "1px",
        "border-top-style": "solid",
        "border-top-color": "#ecf0f1",
        "backgroundColor": "rgba(255, 255, 255, 1)",
    },
)

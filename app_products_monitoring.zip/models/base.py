from app import db


class Hrix(db.Model):
    __tablename__ = "hrix"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "derives"}
    hixcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Cfin valeur",
    )
    hixdate = db.Column(db.DateTime(), nullable=False, info="Date valeur",)
    hixopen = db.Column(db.Float(), nullable=True, info="Valeur d'ouverture",)
    hixclose = db.Column(db.Float(), nullable=True, info="Valeur de cloture",)
    hixbase = db.Column(db.Numeric(), nullable=True, info="Base indice",)
    hixscript = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        nullable=True,
        info="ID script utilise pour le calcul d'indice",
    )
    hixsessionid = db.Column(
        db.Numeric(9, 0, asdecimal=False),
        nullable=True,
        info="ID session batch qui a calcule l'indice",
    )


class Typeintermediation(db.Model):
    __tablename__ = "typeintermediation"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    ticode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de l'autorisation d'intermédiation",
    )
    tilibelle = db.Column(
        db.String(60), info="Libellé de l'autorisation d'intermédiation"
    )


class Typevalidationattribut(db.Model):
    __tablename__ = "typevalidationattribut"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tvcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code identifiant du sous état de validation",
    )
    tvlibelle = db.Column(db.String(60), info="Libéllé du sous état de validation")


class Typeposition(db.Model):
    __tablename__ = "typeposition"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tpcode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de l'autorisation de position",
    )
    tplibelle = db.Column(db.String(60), info="Libellé de l'autorisation de position")


class Typeproprietaire(db.Model):
    __tablename__ = "typeproprietaire"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tpcode = db.Column(primary_key=True, info="Code du propriétaire")
    tplibelle = db.Column(db.String(60), info="Libellé du propriétaire")


class Typeproprietairevalidation(db.Model):
    __tablename__ = "typeproprietairevalidation"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tvcode = db.Column(primary_key=True, info="Code du propriétaire")
    tvlibelle = db.Column(db.String(60), info="Libellé du propriétaire")


class Typofoinstrumentsjac(db.Model):
    __tablename__ = "typofoinstrumentsjac"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tscode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de la nouvelle typologie sous jacent",
    )
    tslibellesjac = db.Column(
        db.String(200), nullable=False, info="Libellé du type de sous jacent du produit"
    )


class Typofoinstrument(db.Model):
    __tablename__ = "typofoinstrument"
    __bind_key__ = "exane_analyse"
    __table_args__ = (db.CheckConstraint("TICODE>=1000"), {"schema": "exane"})

    ticode = db.Column(primary_key=True, info="Code de la nouvelle typologie FO",)
    tilibelle = db.Column(
        db.String(200), nullable=False, info="Libellé de la nouvelle typologie FO"
    )


class Typofoinstrumentsautorisee(db.Model):
    __tablename__ = "typofoinstrumentsautorisees"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACONTRATINDEFINI Is Not Null AND TACONTRATINDEFINI IN ('O','N')"
        ),
        db.CheckConstraint(
            "TACONTRATLISTE Is Not Null AND TACONTRATLISTE IN ('O','N')"
        ),
        db.CheckConstraint("TACONTRATOTC Is Not Null AND TACONTRATOTC IN ('O','N')"),
        db.CheckConstraint(
            "TACONTRATTITRE Is Not Null AND TACONTRATTITRE IN ('O','N')"
        ),
        db.Index(
            "uk_typofoinstrumentsautorisees",
            "tacodetypoinstrument",
            "tacodetypoinstsjac",
        ),
        {"schema": "exane"},
    )

    tacode = db.Column(
        primary_key=True,
        info="Code d'association de la typologie instrument et de la typologie sous jacent",
    )
    tacodetypoinstrument = db.Column(
        db.ForeignKey(Typofoinstrument.ticode),
        nullable=False,
        info="Code de la typologie instrument cf. EXANE.TYPOFOINSTRUMENT",
    )
    tacodetypoinstsjac = db.Column(
        db.ForeignKey(Typofoinstrumentsjac.tscode),
        info="Code de la typologie sous jacent cf. EXANE.TYPOFOINSTRUMENTSJAC",
    )
    tacontrattitre = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Titre",
    )
    tacontratliste = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Liste",
    )
    tacontratotc = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat OTC",
    )
    tacontratindefini = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Indéfini",
    )

    typofoinstrument = db.relationship(
        "Typofoinstrument",
        primaryjoin="Typofoinstrumentsautorisee.tacodetypoinstrument == Typofoinstrument.ticode",
        lazy=True,
        backref="typofoinstrumentsautorisees",
    )
    typofoinstrumentsjac = db.relationship(
        "Typofoinstrumentsjac",
        primaryjoin="Typofoinstrumentsautorisee.tacodetypoinstsjac == Typofoinstrumentsjac.tscode",
        lazy=True,
        backref="typofoinstrumentsautorisees",
    )


class Typecontrat(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    tctcode = db.Column(db.Integer, primary_key=True)
    tctnom = db.Column(db.String)


class Tpvaleur(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    id = db.Column(db.Integer, primary_key=True)
    tvcode = db.Column(db.Integer)
    tvtypo = db.Column()
    tvnom = db.Column(db.String)
    tvpersonne = db.Column(db.String)
    tvapplication = db.Column()
    tvhorodate = db.Column(db.Date)
    tvflag = db.Column(db.Integer)


class Tpcollection(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    id = db.Column(db.Integer, primary_key=True)
    tccode = db.Column(db.Integer)
    tcref = db.Column()
    tcpersonne = db.Column()
    tcapplication = db.Column()
    tchorodate = db.Column(db.Date)
    tcflag = db.Column(db.Integer)


class Tptypologie(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    id = db.Column(db.Integer, primary_key=True)
    ttcode = db.Column(db.Integer)
    ttnom = db.Column(db.String)
    ttprop = db.Column()
    ttnature = db.Column()
    ttpartition = db.Column()
    ttfille = db.Column()
    ttpersonne = db.Column()
    ttapplication = db.Column()
    tthorodate = db.Column(db.Date)
    ttflag = db.Column(db.Integer)


class Typecoupon(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    tcnum = db.Column(db.Integer, primary_key=True)
    tcnomfr = db.Column(db.String)
    tcnomuk = db.Column(db.String)


class Typeprotection(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    tpnum = db.Column(db.Integer, primary_key=True)
    tpnomfr = db.Column(db.String)
    tpnomuk = db.Column(db.String)


class Typepayoff(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    tflcode = db.Column(db.Integer, primary_key=True)
    tflnom = db.Column(db.String)


class Typeetatdevie(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    tvcode = db.Column(db.Integer, primary_key=True)
    tvlibelle = db.Column(db.String)


class Typediffusion(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    tdcode = db.Column(db.Integer, primary_key=True)
    tdlibelle = db.Column(db.String)


class Typestatut(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    tstcode = db.Column(db.Integer, primary_key=True)
    tstnom = db.Column(db.String)


class Typeinstrument(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    tycode = db.Column(db.Integer, primary_key=True)
    tyfamille = db.Column()
    tynom = db.Column(db.String)
    tyname = db.Column(db.String)


# class Instrument(db.Model):
#     __bind_key__ = "exane_analyse"
#     __table_args__ = {"schema": "exane", "extend_existing": True}
#     ifcfin = db.Column(db.Integer, primary_key=True)
#     ifnom = db.Column(db.String)
#     ifmaj = db.Column(db.Date)
#     ifstatut = db.Column(db.Integer, db.ForeignKey(Typestatut.tstcode))
#     iftype = db.Column(db.Integer, db.ForeignKey(Typeinstrument.tycode))
#     ifpayoff = db.Column(db.Integer, db.ForeignKey(Typepayoff.tflcode))
#     ifcontrat = db.Column(db.Integer, db.ForeignKey(Typecontrat.tctcode))
#     ifproprietaire = db.Column(db.Integer, db.ForeignKey(Typeproprietaire.tpcode))
#     iftypofo = db.Column(db.Integer, db.ForeignKey(Typofoinstrumentsautorisees.tacode))
#
#     statut = db.relationship(Typestatut, backref=db.backref("Instruments", lazy=True))
#     type = db.relationship(Typeinstrument, backref=db.backref("Instruments", lazy=True))
#     payoff = db.relationship(Typepayoff, backref=db.backref("Instruments", lazy=True))
#     contrat = db.relationship(Typecontrat, backref=db.backref("Instruments", lazy=True))
#     proprietaire = db.relationship(
#         Typeproprietaire, backref=db.backref("Instruments", lazy=True)
#     )
#     typofo = db.relationship(
#         Typofoinstrumentsautorisees, backref=db.backref("Instruments", lazy=True)
#     )


class Maturite(db.Model):
    __tablename__ = "maturite"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    mtcode = db.Column(
        primary_key=True, info="Code maturite d'un taux, d'une volatilité",
    )
    mtday = db.Column(info="Maturite en jours")
    mtmonth = db.Column(info="Maturite en mois")
    mtyear = db.Column(info="Maturite en annees")


class Contributeur(db.Model):
    __tablename__ = "contributeur"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    cocode = db.Column(primary_key=True, info="Code contributeur")
    conom = db.Column(db.String(15), info="Nom contributeur")


class Methode(db.Model):
    __tablename__ = "methode"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    mecode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code methode construction de courbe",
    )
    menom = db.Column(
        db.String(15),
        nullable=False,
        info="Nom methode construction courbe, indicateur taux, volatilité",
    )


class Langue(db.Model):
    __tablename__ = "langue"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    lacode = db.Column(primary_key=True, info="code de la langue")
    lanom = db.Column(
        db.String(50), nullable=False, info="libellé francais de la langue"
    )


class Pays(db.Model):
    __tablename__ = "pays"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    pacode = db.Column(primary_key=True, info="Code pays")
    panom = db.Column(db.String(25), nullable=False, info="Nom pays")
    panomfr = db.Column(db.String(25), info="Nom francais pays\t")
    paabrege = db.Column(db.String(3), info="Abrege du pays\t")
    pacodeiso = db.Column(db.String(6))
    palangue = db.Column(
        db.ForeignKey(Langue.lacode),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Langue parlée dans le pays",
    )

    langue = db.relationship(
        "Langue",
        primaryjoin="Pays.palangue == Langue.lacode",
        lazy=True,
        backref="pays",
    )


class Instrument(db.Model):
    __tablename__ = "instruments"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint(
            "IFVALIDATION = 'N' OR IFVALIDATION = 'M' OR IFVALIDATION = 'R' OR IFVALIDATION = 'V'"
        ),
        db.CheckConstraint("ifcfin <> 0"),
        db.Index("idx1_instrument", "ifcfin", "ifpayoff", "iftype"),
        {"schema": "exane"},
    )

    ifcfin = db.Column(primary_key=True, info="Code de l'instrument financier",)
    ifstatut = db.Column(
        db.ForeignKey(Typestatut.tstcode),
        nullable=False,
        index=True,
        info="Code du statut d'un instrument financier",
    )
    iftype = db.Column(
        db.ForeignKey(Typeinstrument.tycode),
        nullable=False,
        index=True,
        info="Code du type d'instrument",
    )
    ifnom = db.Column(db.String(60), nullable=False, info="Nom de l'instrument")
    ifmaj = db.Column(
        db.DateTime, nullable=False, info="Date de mise à jour de l'instrument"
    )
    ifpayoff = db.Column(
        db.ForeignKey(Typepayoff.tflcode),
        index=True,
        server_default=db.FetchedValue(),
        info="type de payoff de l'instrument",
    )
    ifcontrat = db.Column(
        db.ForeignKey(Typecontrat.tctcode),
        index=True,
        server_default=db.FetchedValue(),
        info="type de contrat de l'instrument",
    )
    ifvalidation = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Gere la validation des instruments, toutes les caracteristiques du produit qui peuvent influencer le prix  agissent sur le champ IFVALIDATION",
    )
    ifproprietaire = db.Column(
        db.ForeignKey(Typeproprietaire.tpcode), info="Propriétaire de l'instument",
    )
    iftypofo = db.Column(
        db.ForeignKey(Typofoinstrumentsautorisee.tacode),
        index=True,
        info="Nouvelle typologie Front des produits cf. EXANE.TYPOFOINSTRUMENTSAUTORISEES",
    )

    typecontrat = db.relationship(
        "Typecontrat",
        primaryjoin="Instrument.ifcontrat == Typecontrat.tctcode",
        lazy=True,
        backref="instruments",
    )
    typepayoff = db.relationship(
        "Typepayoff",
        primaryjoin="Instrument.ifpayoff == Typepayoff.tflcode",
        lazy=True,
        backref="instruments",
    )
    typeproprietaire = db.relationship(
        "Typeproprietaire",
        primaryjoin="Instrument.ifproprietaire == Typeproprietaire.tpcode",
        lazy=True,
        backref="instruments",
    )
    typestatut = db.relationship(
        "Typestatut",
        primaryjoin="Instrument.ifstatut == Typestatut.tstcode",
        lazy=True,
        backref="instruments",
    )
    typeinstrument = db.relationship(
        "Typeinstrument",
        primaryjoin="Instrument.iftype == Typeinstrument.tycode",
        lazy=True,
        backref="instruments",
    )
    typofoinstrumentsautorisee = db.relationship(
        "Typofoinstrumentsautorisee",
        primaryjoin="Instrument.iftypofo == Typofoinstrumentsautorisee.tacode",
        lazy=True,
        backref="instruments",
    )


class Devise(Instrument):
    __tablename__ = "devise"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    dvcfin = db.Column(
        db.ForeignKey(Instrument.ifcfin),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    dvpays = db.Column(
        db.ForeignKey(Pays.pacode), nullable=False, index=True, info="Code pays"
    )
    dvcodeiso = db.Column(db.String(3), unique=True)
    dvlibelle = db.Column(db.String(60), info="Libelle de la devise ")

    pays = db.relationship(
        "Pays", primaryjoin="Devise.dvpays == Pays.pacode", lazy=True, backref="devises"
    )


class Nature(db.Model):
    __tablename__ = "nature"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    nacode = db.Column(primary_key=True, info="Code nature")
    nanom = db.Column(db.String(40), nullable=False, info="Nom nature")


class Courbetx(Instrument):
    __tablename__ = "courbetx"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    cbcfin = db.Column(
        db.ForeignKey(Instrument.ifcfin, ondelete="CASCADE"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    cbfwd = db.Column(
        db.ForeignKey(Maturite.mtcode),
        index=True,
        info="Code maturite d'un taux, d'une volatilité",
    )
    cbcontrib = db.Column(
        db.ForeignKey(Contributeur.cocode), index=True, info="Code contributeur"
    )
    cbnature = db.Column(
        db.ForeignKey(Nature.nacode), nullable=False, index=True, info="Code nature",
    )
    cbmethode = db.Column(
        db.ForeignKey(Methode.mecode),
        nullable=False,
        index=True,
        info="Code methode construction de courbe",
    )
    cbdev = db.Column(
        db.ForeignKey(Devise.dvcfin),
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )

    contributeur = db.relationship(
        "Contributeur",
        primaryjoin="Courbetx.cbcontrib == Contributeur.cocode",
        lazy=True,
        backref="courbetxes",
    )
    devise = db.relationship(
        "Devise",
        primaryjoin="Courbetx.cbdev == Devise.dvcfin",
        lazy=True,
        backref="courbetxes",
    )
    maturite = db.relationship(
        "Maturite",
        primaryjoin="Courbetx.cbfwd == Maturite.mtcode",
        lazy=True,
        backref="courbetxes",
    )
    methode = db.relationship(
        "Methode",
        primaryjoin="Courbetx.cbmethode == Methode.mecode",
        lazy=True,
        backref="courbetxes",
    )
    nature = db.relationship(
        "Nature",
        primaryjoin="Courbetx.cbnature == Nature.nacode",
        lazy=True,
        backref="courbetxes",
    )


class Modecot(db.Model):
    __tablename__ = "modecot"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    mocode = db.Column(primary_key=True, info="Code mode cotation")
    monom = db.Column(db.String(20), nullable=False, info="Libelle mode cotation")


class Place(db.Model):
    __tablename__ = "place"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    plcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de la place de cotation",
    )
    plnom = db.Column(db.String(20), nullable=False, info="Nom de la place de cotation")


class Marche(db.Model):
    __tablename__ = "marche"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    macode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du marché de cotation",
    )
    maplace = db.Column(
        db.ForeignKey(Place.plcode),
        nullable=False,
        index=True,
        info="Code de la place de cotation",
    )
    manom = db.Column(db.String(60), nullable=False, info="Nom du marché de cotation")
    mamic = db.Column(db.String(4), info="Code MIC du marché")
    mafininfo = db.Column(info="Code FinInfo du marché")
    mareuter = db.Column(db.String(3), info="Code Reuter du marché")
    macamelot = db.Column(
        db.String(3), info="Préfixe du code Camelot de la place associée."
    )

    place = db.relationship(
        "Place",
        primaryjoin="Marche.maplace == Place.plcode",
        lazy=True,
        backref="marches",
    )


class Calendriersdescription(db.Model):
    __tablename__ = "calendriersdescription"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("CNDefiniParJourOuvre IN ('O','N')"),
        {"schema": "exane"},
    )

    cncode = db.Column(db.Numeric(10, 0, asdecimal=False), primary_key=True)
    cndefiniparjourouvre = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="O Indique si les jours définissant le calendrier sont des jours ouverts de type 33",
    )
    cnnom = db.Column(db.String(256), info="Libellé du calendrier")


class Produit(Instrument):
    __tablename__ = "produits"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    prcfin = db.Column(
        db.ForeignKey(Instrument.ifcfin, ondelete="CASCADE"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    prcourbe = db.Column(
        db.ForeignKey(Courbetx.cbcfin),
        index=True,
        info="Code de l'instrument financier",
    )
    prmodecot = db.Column(
        db.ForeignKey(Modecot.mocode),
        nullable=False,
        index=True,
        info="Code mode cotation",
    )
    prpays = db.Column(
        db.ForeignKey(Pays.pacode), nullable=False, index=True, info="Code pays"
    )
    prmarche = db.Column(
        db.ForeignKey(Marche.macode),
        nullable=False,
        index=True,
        info="Code du marché de cotation",
    )
    prdev = db.Column(
        db.ForeignKey(Devise.dvcfin),
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    prdevnominal = db.Column(
        nullable=False, index=True, info="Code de l'instrument financier",
    )
    prquotite = db.Column(
        db.Numeric(12, 4), nullable=False, info="Quotité minimale de transaction"
    )
    prcalendrier = db.Column(db.ForeignKey(Calendriersdescription.cncode))

    calendriersdescription = db.relationship(
        "Calendriersdescription",
        primaryjoin="Produit.prcalendrier == Calendriersdescription.cncode",
        lazy=True,
        backref="produits",
    )
    courbetx = db.relationship(
        "Courbetx",
        primaryjoin="Produit.prcourbe == Courbetx.cbcfin",
        lazy=True,
        backref="produits",
    )
    devise = db.relationship(
        "Devise",
        primaryjoin="Produit.prdev == Devise.dvcfin",
        lazy=True,
        backref="devise_produits",
    )
    marche = db.relationship(
        "Marche",
        primaryjoin="Produit.prmarche == Marche.macode",
        lazy=True,
        backref="produits",
    )
    modecot = db.relationship(
        "Modecot",
        primaryjoin="Produit.prmodecot == Modecot.mocode",
        lazy=True,
        backref="produits",
    )
    pays = db.relationship(
        "Pays",
        primaryjoin="Produit.prpays == Pays.pacode",
        lazy=True,
        backref="produits",
    )


class Script(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    sccfin = db.Column(db.String, primary_key=True)
    sctype = db.Column()
    scstrike = db.Column()
    scdevstrike = db.Column()
    scparite = db.Column()
    scproportion = db.Column()
    scstatut = db.Column()
    scscript = db.Column(db.String)
    scstatutcontractuel = db.Column()
    scscriptcontractuel = db.Column()


class Dico(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    rowid = db.Column(primary_key=True)
    dccode = db.Column(db.Integer)
    dcentite = db.Column(db.String)
    dcattribut = db.Column(db.String)


class Source(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    socode = db.Column(db.Integer, primary_key=True)
    sonom = db.Column(db.String)
    sotype = db.Column(db.Integer)
    sounicite = db.Column(db.Integer)
    soctrlunique = db.Column(db.Integer)


class Ratconformitetier(db.Model):
    __tablename__ = "ratconformitetiers"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    rgcode = db.Column(primary_key=True)
    rgstatut = db.Column(db.ForeignKey(Typestatut.tstcode))
    rgnote = db.Column(db.String(60))

    typestatut = db.relationship(
        "Typestatut",
        primaryjoin="Ratconformitetier.rgstatut == Typestatut.tstcode",
        lazy=True,
        backref="ratconformitetiers",
    )


class Grpuser(db.Model):
    __tablename__ = "grpuser"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    gucode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code du groupe d'utilisateurs",
    )
    gunom = db.Column(db.String(15), nullable=False, info="Nomdu groupe d'utilisateurs")


class Tier(db.Model):
    __tablename__ = "tiers"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("TITYPE IN ('T','G','P')"),
        db.CheckConstraint("TITYPE IN ('T','G','P')"),
        {"schema": "exane"},
    )

    ticode = db.Column(primary_key=True, info="Code d'une personne physique ou morale",)
    tipays = db.Column(
        db.ForeignKey(Pays.pacode), nullable=False, index=True, info="Code pays"
    )
    tinom = db.Column(
        db.String(60), nullable=False, info="Nom d'une personne physique ou morale"
    )
    timemo = db.Column(db.String(4), nullable=False, info="Abréviation du nom du tiers")
    tisuivi = db.Column(
        db.String(1),
        info="Type de suivi sur une société assuré par un analyste financier",
    )
    titype = db.Column(db.String(1), nullable=False)
    tiappartenance = db.Column(db.ForeignKey(Grpuser.gucode))
    tistatut = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Statut",
    )
    tivaliderdc = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Ce champ ne doit plus être utilisé (remplacé par REFDOC.KYCINFORMATION.KIVALIDERDC)",
    )
    tiratingconf = db.Column(db.ForeignKey(Ratconformitetier.rgcode))
    tipaysrisk = db.Column(
        # db.Numeric(3, 0, asdecimal=False),
        db.ForeignKey(Pays.pacode),
        info="Code pays risque",
    )
    tiformejuridique = db.Column(info="Forme juridique du tiers")
    grpuser = db.relationship(
        "Grpuser",
        primaryjoin="Tier.tiappartenance == Grpuser.gucode",
        lazy=True,
        backref="tiers",
    )
    pays = db.relationship(
        "Pays", primaryjoin="Tier.tipays == Pays.pacode", lazy=True, backref="pay_tiers"
    )
    pays1 = db.relationship(
        "Pays",
        primaryjoin="Tier.tipaysrisk == Pays.pacode",
        lazy=True,
        backref="pay_tiers_0",
    )
    ratconformitetier = db.relationship(
        "Ratconformitetier",
        primaryjoin="Tier.tiratingconf == Ratconformitetier.rgcode",
        lazy=True,
        backref="tiers",
    )


class Contrats(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    ctcfin = db.Column(db.Integer, db.ForeignKey(Instrument.ifcfin), primary_key=True)
    ctpremiumrule = db.Column(db.Integer, db.ForeignKey(Tier.ticode))
    ctmaturite = db.Column(db.Date)
    cthorodate = db.Column(db.Date)
    ctautoexerc = db.Column(db.String)


class Contratotcs(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    cocfin = db.Column(db.Integer, primary_key=True)
    copayeur = db.Column()
    coreceveur = db.Column()
    cocontratcadre = db.Column()
    coagent = db.Column()
    cohorodate = db.Column()
    covalidation = db.Column()
    coreceveurinitial = db.Column()


class Spotinitialmontage(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    simcfin = db.Column(db.Integer, primary_key=True)
    simsjac = db.Column(db.Integer)
    simspotinitial = db.Column(db.Float)
    simspotvalide = db.Column(db.String)


class Barriere(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    barid = db.Column(db.Integer, primary_key=True)
    barcfin = db.Column()
    barsjac = db.Column()
    barniveau = db.Column(db.Float)
    bartype = db.Column()
    bardatelimite = db.Column()
    bardatecreation = db.Column()
    bardatemaj = db.Column()
    barcomment = db.Column()
    barrepresentation = db.Column()


class Composition(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    cpcfin = db.Column(db.Integer, primary_key=True)
    cpsjac = db.Column()
    cpcollect = db.Column()
    cpcoeffajust = db.Column()
    cppoids = db.Column()
    cpquantite = db.Column(db.Float)
    cpcashsettlpart = db.Column()


class Composition_h(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    cphcfin = db.Column(db.Integer, primary_key=True)
    cphsjac = db.Column()
    cphcollect = db.Column()
    cphdate = db.Column(db.Date)
    cphcoeffajust = db.Column()
    cphpoids = db.Column(db.Float)
    cphquantite = db.Column(db.Float)
    cphcashsettlpart = db.Column()


class Pdtcompo(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    pccfin = db.Column(db.Integer, primary_key=True)
    pccollect = db.Column(db.Integer)
    pctyperevenu = db.Column(db.Integer)
    pctypecalcul = db.Column(db.Integer)
    pccalc = db.Column(db.Integer)
    pccalendrier = db.Column(db.Integer)
    pctyperebalancement = db.Column(db.Integer)
    pcindicereference = db.Column(db.Integer)
    pcsensalimcollection = db.Column(db.String)


#
# class Instrumentcomplement(db.Model):
#     __bind_key__ = "exane_analyse"
#     __table_args__ = {"schema": "exane", "extend_existing": True}
#     iccfin = db.Column(db.Integer, primary_key=True)
#     icvalidation = db.Column(db.String)
#     icpropagationvalidation = db.Column(db.Integer)
#     icetatdevie = db.Column(db.Integer)
#     icposition = db.Column(db.Integer)
#     icintermediation = db.Column(db.Integer)
#     icdiffusion = db.Column(db.Integer)
#     icdoublon = db.Column(db.Integer)
#     icaeteenposition = db.Column(db.Integer)
#     icaeteintermedie = db.Column(db.Integer)
#     icvalidationattribut = db.Column(db.Integer)
#     icvalideur = db.Column(db.Integer)


class Instrumentcomplement(db.Model):
    __tablename__ = "instrumentcomplement"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("ICAETEENPOSITION IN (2,1,0)"),
        db.CheckConstraint("ICAETEINTERMEDIE IN (1,0)"),
        db.CheckConstraint("ICDOUBLON IN (1,0)"),
        db.CheckConstraint("ICValidation in ('N', 'M', 'R', 'C', 'V', 'A')"),
        {"schema": "exane"},
    )

    iccfin = db.Column(
        primary_key=True,
        info="CFIN sur le quel porte les informations complémentaires",
    )
    icvalidation = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="N : Non validé | M : Modifié | R : Refusé Non Validé | C : Refusé Non Conforme | V : Validé | A : A modifier",
    )
    icpropagationvalidation = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="0 : Pas de propagation du status de validation | 1 : Propagation du status de validation",
    )
    icetatdevie = db.Column(
        db.ForeignKey(Typeetatdevie.tvcode), info="Etat de vie de l'instrument."
    )
    icposition = db.Column(
        db.ForeignKey(Typeposition.tpcode),
        info="Définit si l'instrument peut être en position.",
    )
    icintermediation = db.Column(
        db.ForeignKey(Typeintermediation.ticode),
        info="Définit si l'instrument peut être intermédié.",
    )
    icdiffusion = db.Column(
        db.ForeignKey(Typediffusion.tdcode),
        info="Définit si l'instrument peut être diffusé.",
    )
    icdoublon = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        info="Définit si l'instrument est un doublon (1 si oui 0 sinon).",
    )
    icaeteenposition = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        info='Définit si l\'instrument est ou a étéen position (1 si "en position", 2 si "a été" 0 si "jamais en pos").',
    )
    icaeteintermedie = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Définit si l'instrument a été en intermédié (1 si oui 0 sinon).",
    )
    icvalidationattribut = db.Column(
        db.ForeignKey(Typevalidationattribut.tvcode),
        info="Sous statut de validation : Validé Non Conforme, Conforme gestion... (liaison avec les scripts)",
    )
    icvalideur = db.Column(
        db.ForeignKey(Typeproprietairevalidation.tvcode),
        info="Code du propriétaire du statut de validation (cf. TYPEPROPRIETAIREVALIDATION)",
    )

    typediffusion = db.relationship(
        "Typediffusion",
        primaryjoin="Instrumentcomplement.icdiffusion == Typediffusion.tdcode",
        lazy=True,
        backref="instrumentcomplements",
    )
    typeetatdevie = db.relationship(
        "Typeetatdevie",
        primaryjoin="Instrumentcomplement.icetatdevie == Typeetatdevie.tvcode",
        lazy=True,
        backref="instrumentcomplements",
    )
    typeintermediation = db.relationship(
        "Typeintermediation",
        primaryjoin="Instrumentcomplement.icintermediation == Typeintermediation.ticode",
        lazy=True,
        backref="instrumentcomplements",
    )
    typeposition = db.relationship(
        "Typeposition",
        primaryjoin="Instrumentcomplement.icposition == Typeposition.tpcode",
        lazy=True,
        backref="instrumentcomplements",
    )
    typevalidationattribut = db.relationship(
        "Typevalidationattribut",
        primaryjoin="Instrumentcomplement.icvalidationattribut == Typevalidationattribut.tvcode",
        lazy=True,
        backref="instrumentcomplements",
    )
    typeproprietairevalidation = db.relationship(
        "Typeproprietairevalidation",
        primaryjoin="Instrumentcomplement.icvalideur == Typeproprietairevalidation.tvcode",
        lazy=True,
        backref="instrumentcomplements",
    )


class Alien(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    alcfin = db.Column(db.Integer)
    alsjac = db.Column(db.Integer)
    altype = db.Column()
    almaj = db.Column(db.Date, primary_key=True,)
    alparite = db.Column()
    alproportion = db.Column()


class Typelien(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    tlcode = db.Column(primary_key=True)
    tlnom = db.Column()


class Cotation(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    cotcfin = db.Column(db.Integer, db.ForeignKey(Produit.prcfin), primary_key=True)
    cotmarche = db.Column(db.Integer, db.ForeignKey(Marche.macode), primary_key=True)
    cotstatut = db.Column(db.Integer, db.ForeignKey(Typestatut.tstcode))


class Last(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    lacfin = db.Column(db.Integer, primary_key=True)
    lamarche = db.Column(db.Integer, primary_key=True)
    ladate = db.Column(db.DateTime)
    lapriclos = db.Column(db.Float)
    lapriopen = db.Column(db.Float)
    laprimoypond = db.Column(db.Float)
    lapo = db.Column(db.Float)
    lavolqute = db.Column(db.Float)
    lavolcapi = db.Column(db.Float)
    ladatepr = db.Column(db.Date)
    lapriclospr = db.Column(db.Float)
    lapriopenpr = db.Column(db.Float)
    laprimoypondpr = db.Column(db.Float)
    lapopr = db.Column(db.Float)
    lavolqutepr = db.Column(db.Float)
    lavolcapipr = db.Column(db.Float)
    lahigh = db.Column(db.Float)
    lahighpr = db.Column(db.Float)
    lalow = db.Column(db.Float)
    lalowpr = db.Column(db.Float)
    labid = db.Column(db.Float)
    laask = db.Column(db.Float)
    labidpr = db.Column(db.Float)
    laaskpr = db.Column(db.Float)
    ladatecotation = db.Column(db.Date)


class Codes(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    cfcfin = db.Column(db.Integer, db.ForeignKey(Instrument.ifcfin), primary_key=True)
    cfsource = db.Column(db.Integer, db.ForeignKey(Source.socode), primary_key=True)
    cfmarche = db.Column(db.Integer, db.ForeignKey(Marche.macode), primary_key=True)
    cftype = db.Column(db.Integer, primary_key=True)
    cfcode = db.Column(db.String, primary_key=True)
    cfmodecot = db.Column(db.String, db.ForeignKey(Modecot.mocode))
    cfdesc = db.Column(db.String)
    cfstatut = db.Column(db.Integer)
    cfmarge = db.Column(db.Integer)
    cfcoeff = db.Column(db.Integer)
    cfrecup = db.Column(db.Integer)
    cfhorodate = db.Column(db.Date)


class Typecross(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tccode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="code type du cross"
    )
    tclibelle = db.Column(db.String(60), info="Libellé du type du cross")


class Crosshistorique(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    chcfin = db.Column(
        db.ForeignKey(Instrument.ifcfin),
        primary_key=True,
        nullable=False,
        info="cfin cross",
    )
    chdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="date de valeur du cross"
    )
    chvaleur = db.Column(db.Float, nullable=False, info="valeur du cross")
    chtype = db.Column(
        db.ForeignKey(Typecross.tccode),
        primary_key=True,
        nullable=False,
        info="source du cross",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Crosshistorique.chcfin == Instrument.ifcfin",
        lazy=True,
        backref="crosshistorique",
    )
    typecros = db.relationship(
        "Typecross",
        primaryjoin="Crosshistorique.chtype == Typecross.tccode",
        lazy=True,
        backref="crosshistorique",
    )


class Typedatarecup(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    trcode = db.Column(db.Integer, primary_key=True)
    trnom = db.Column(db.String)
    trcoeff = db.Column()
    trdata = db.Column(db.String)


class Codif(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    cfcfin = db.Column(db.Integer, db.ForeignKey(Instrument.ifcfin), primary_key=True)
    cfsource = db.Column(db.Integer, db.ForeignKey(Source.socode), primary_key=True)
    cftype = db.Column(
        db.Integer, db.ForeignKey(Typedatarecup.trcode), primary_key=True
    )
    cfcode = db.Column(db.String, primary_key=True)
    cfmodecot = db.Column(db.Integer, db.ForeignKey(Modecot.mocode))
    cfstatut = db.Column(db.Integer)
    cfmarge = db.Column(db.Integer)
    cfrecup = db.Column(db.Integer)


class Collection(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    # id = db.Column(db.Integer, primary_key=True)
    clcollect = db.Column(
        db.Integer, db.ForeignKey(Instrument.ifcfin), primary_key=True
    )
    clsjac = db.Column(db.Integer, db.ForeignKey(Instrument.ifcfin), primary_key=True)
    cldatein = db.Column(db.Date, primary_key=True)
    cldateout = db.Column(db.Date)
    cltypecollect = db.Column()
    cldiviseur = db.Column()


class Typelevier(db.Model):
    __tablename__ = "typelevier"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tlvcode = db.Column(primary_key=True)
    tlvlibelle = db.Column(db.String(32))


class Typebarriere(db.Model):
    __tablename__ = "typebarriere"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tbacode = db.Column(primary_key=True)
    tbalibelle = db.Column(db.String(32))


class Typesjcemisstructuree(db.Model):
    __tablename__ = "typesjcemisstructuree"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tsecode = db.Column(primary_key=True, info="Code du type sjc")
    tselibelle = db.Column(db.String(60), info="Type sous-jacent")


class Typeclient(db.Model):
    __tablename__ = "typeclient"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tccode = db.Column(primary_key=True, info="Code type client")
    tclibelle = db.Column(db.String(60), nullable=False, info="Libellé type client")
    tclibelle_unique = db.Column(
        db.String(4000), unique=True, server_default=db.FetchedValue()
    )


class Typestatutdiffusioncsd(db.Model):
    __tablename__ = "typestatutdiffusioncsd"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    sdcode = db.Column(
        db.String(2),
        primary_key=True,
        info="Code du statut diffusion CSD (Dépositaire Central, ex EuroClear)",
    )
    sdlibelle = db.Column(
        db.String(60),
        nullable=False,
        info="Libellé statut diffusion CSD (Dépositaire Central, ex EuroClear)",
    )
    sdlibelle_unique = db.Column(
        db.String(4000), unique=True, server_default=db.FetchedValue()
    )


class Typeattributfamille(db.Model):
    __tablename__ = "typeattributfamille"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tafcode = db.Column(primary_key=True)
    taflibelle = db.Column(db.String(60), nullable=False)


class Typeupside(db.Model):
    __tablename__ = "typeupside"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tunum = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du type d'Upside",
    )
    tunomfr = db.Column(db.String(60), nullable=False)
    tunomuk = db.Column(db.String(60))


class Typefamillefond(db.Model):
    __tablename__ = "typefamillefonds"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tfdcode = db.Column(primary_key=True)
    tfdattribut = db.Column(db.ForeignKey(Typeattributfamille.tafcode))
    tfdlibelle = db.Column(db.String(60))

    typeattributfamille = db.relationship(
        "Typeattributfamille",
        primaryjoin="Typefamillefond.tfdattribut == Typeattributfamille.tafcode",
        lazy=True,
        backref="typefamillefonds",
    )


class Emisstructuree(Instrument):
    __tablename__ = "emisstructuree"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("ESCALLABLE is null or ( ESCALLABLE in ('O','N') )"),
        db.CheckConstraint("ESCALLABLE is null or ( ESTYPESETTLEMENT in (1,2) )"),
        db.CheckConstraint("ESCALLABLE is null or ( ESTYPESETTLEMENT in (1,2) )"),
        db.CheckConstraint("ESESTFLUX IN ('O','N')"),
        db.CheckConstraint("ESFREQUENCE >= 1 AND ESFREQUENCE <= 8"),
        db.CheckConstraint("ESINDEX is null or ( ESINDEX in ('O','N') )"),
        {"schema": "exane"},
    )

    escfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    estprotect = db.Column(
        db.ForeignKey(Typeprotection.tpnum), info="Type de protection"
    )
    estupside = db.Column(db.ForeignKey(Typeupside.tunum), info="Type d'Upside")
    estcoupon = db.Column(db.ForeignKey(Typecoupon.tcnum), info="Type de coupon")
    escallable = db.Column(
        db.String(1), server_default=db.FetchedValue(), info="Es callable"
    )
    esindex = db.Column(
        db.String(1), server_default=db.FetchedValue(), info="est Indexation"
    )
    descriptif_fr = db.Column(db.String(1024), info="Description longue FR")
    descriptif_uk = db.Column(db.String(1024), info="Description longue UK")
    libelle_fr = db.Column(db.String(255), info="Libelle court FR")
    libelle_uk = db.Column(db.String(255), info="Libelle court UK")
    esscogestion = db.Column(db.ForeignKey(Tier.ticode))
    esdistrib = db.Column(db.ForeignKey(Tier.ticode))
    esmulti = db.Column(db.String(1), server_default=db.FetchedValue())
    escadrefiscal = db.Column(db.ForeignKey(Typefamillefond.tfdcode))
    esgestion = db.Column(db.Numeric(3, 0, asdecimal=False))
    esprofil = db.Column(db.Numeric(3, 0, asdecimal=False))
    espayoff = db.Column(db.String(4000))
    esbarriere = db.Column(db.ForeignKey(Typebarriere.tbacode))
    esmontantcoupon = db.Column(
        db.Numeric(8, 4), info="Montant annuel initial (en % du nominal)"
    )
    eslevier = db.Column(db.ForeignKey(Typelevier.tlvcode))
    estspread = db.Column(db.Numeric(10, 3), info="Spread Bid/Ask")
    esfrequence = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="FrÃ©ence pour le montant du coupon (Annuel=1, Semestriel=2, Trimestriel=3, Mensuel=4, In Fine=5, Bi-mensuel=6,Quadrimestriel=7,Bimestriel=8)",
    )
    esproccoupon = db.Column(db.DateTime, info="Date prochain coupon")
    esnumcoupon = db.Column(info="Nombre de coupons payés")
    esextype = db.Column(db.String(1), info="Exercice Américain ou Européen")
    esrembanticip = db.Column(
        db.DateTime, info="Date de remboursement par anticipation"
    )
    estypesjc = db.Column(
        db.ForeignKey(Typesjcemisstructuree.tsecode), info="Code du type sjc"
    )
    estypesettlement = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        info="Type de Settlement (Physical=1, Cash=2)",
    )
    escouponannualise = db.Column(db.Numeric(8, 4), info="Montant coupon annualisé")
    esestflux = db.Column(
        db.String(1),
        info="Cette colonne n'est plus utilisee, elle est remplacee par MFSSTFLUX de MARGEFLUXSTRUCTURE",
    )
    esmargeflux = db.Column(
        info="Cette colonne n'est plus utilisee, elle est remplacee par MFSMARGEFLUX de MARGEFLUXSTRUCTURE",
    )
    esupfrontfee = db.Column(db.Numeric(8, 4), info="Montant Upfront Fee (DF)")
    esannualfee = db.Column(db.Numeric(8, 4), info="Montant Annual Fee (SF)")
    estypeclient = db.Column(db.ForeignKey(Typeclient.tccode), info="Type du client")
    esstatutdiffusioncsd = db.Column(
        db.ForeignKey(Typestatutdiffusioncsd.sdcode),
        info="Statut diffusion CSD (Dépositaire Central, ex EuroClear)",
    )
    esexplicationstatutdiffcsd = db.Column(
        db.String(4000),
        info="Explication du statut de diffusion CSD (Dépositaire Central, ex EuroClear)",
    )
    esdatemajstatutdiffcsd = db.Column(
        db.DateTime,
        info="Date maj statut diffusion CSD (Dépositaire Central, ex EuroClear)",
    )
    esstrike = db.Column(info="Strike")
    esdevstrike = db.Column(db.ForeignKey(Devise.dvcfin), info="Devise du strike")
    esprotectionbarrier = db.Column(info="Valeur barrière de protection")
    escoupon = db.Column(
        db.Numeric(18, 7), info="Valeur nominale du coupon payé par le crescendo"
    )
    esparite = db.Column(db.Numeric(11, 5), info="Parité")
    esproportion = db.Column(db.Numeric(11, 5), info="Proportion")

    typebarriere = db.relationship(
        "Typebarriere",
        primaryjoin="Emisstructuree.esbarriere == Typebarriere.tbacode",
        lazy=True,
        backref="emisstructurees",
    )
    typefamillefond = db.relationship(
        "Typefamillefond",
        primaryjoin="Emisstructuree.escadrefiscal == Typefamillefond.tfdcode",
        lazy=True,
        backref="typefamillefond_typefamillefond_emisstructurees",
    )
    devise = db.relationship(
        "Devise",
        primaryjoin="Emisstructuree.esdevstrike == Devise.dvcfin",
        lazy=True,
        backref="emisstructurees",
    )
    tier = db.relationship(
        "Tier",
        primaryjoin="Emisstructuree.esdistrib == Tier.ticode",
        lazy=True,
        backref="tier_emisstructurees",
    )
    # typefamillefond1 = db.relationship(
    #     "Typefamillefond",
    #     primaryjoin="Emisstructuree.esgestion == Typefamillefond.tfdcode",
    #     lazy=True,
    #     backref="typefamillefond_typefamillefond_emisstructurees_0",
    # )
    typelevier = db.relationship(
        "Typelevier",
        primaryjoin="Emisstructuree.eslevier == Typelevier.tlvcode",
        lazy=True,
        backref="emisstructurees",
    )
    # typefamillefond2 = db.relationship(
    #     "Typefamillefond",
    #     primaryjoin="Emisstructuree.esprofil == Typefamillefond.tfdcode",
    #     lazy=True,
    #     backref="typefamillefond_typefamillefond_emisstructurees",
    # )
    # tier1 = db.relationship(
    #     "Tier",
    #     primaryjoin="Emisstructuree.esscogestion == Tier.ticode",
    #     lazy=True,
    #     backref="tier_emisstructurees_0",
    # )
    typestatutdiffusioncsd = db.relationship(
        "Typestatutdiffusioncsd",
        primaryjoin="Emisstructuree.esstatutdiffusioncsd == Typestatutdiffusioncsd.sdcode",
        lazy=True,
        backref="emisstructurees",
    )
    typecoupon = db.relationship(
        "Typecoupon",
        primaryjoin="Emisstructuree.estcoupon == Typecoupon.tcnum",
        lazy=True,
        backref="emisstructurees",
    )
    typeprotection = db.relationship(
        "Typeprotection",
        primaryjoin="Emisstructuree.estprotect == Typeprotection.tpnum",
        lazy=True,
        backref="emisstructurees",
    )
    typeupside = db.relationship(
        "Typeupside",
        primaryjoin="Emisstructuree.estupside == Typeupside.tunum",
        lazy=True,
        backref="emisstructurees",
    )
    typeclient = db.relationship(
        "Typeclient",
        primaryjoin="Emisstructuree.estypeclient == Typeclient.tccode",
        lazy=True,
        backref="emisstructurees",
    )
    typesjcemisstructuree = db.relationship(
        "Typesjcemisstructuree",
        primaryjoin="Emisstructuree.estypesjc == Typesjcemisstructuree.tsecode",
        lazy=True,
        backref="emisstructurees",
    )


class Histo(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    hocfin = db.Column(db.Integer, db.ForeignKey(Produit.prcfin), primary_key=True)
    hodate = db.Column(db.Date)
    hoopen = db.Column(db.Float)
    hoclose = db.Column(db.Float)
    houpper = db.Column(db.Float)
    hodown = db.Column(db.Float)
    hovolume = db.Column(db.Float)
    hocapi = db.Column(db.Float)


class Historiques(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    hocfin = db.Column(db.Integer, primary_key=True)
    homarche = db.Column()
    hodate = db.Column(db.Date)
    hoopen = db.Column(db.Float)
    hoclosbrut = db.Column(db.Float)
    hoclose = db.Column(db.Float)
    houpper = db.Column(db.Float)
    hodown = db.Column(db.Float)
    hovolume = db.Column(db.Float)
    hocapi = db.Column(db.Float)
    hobid = db.Column(db.Float)
    hoask = db.Column(db.Float)


class Emission(Produit):
    __tablename__ = "emission"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("EMKIBI IN ('Y','N')"),
        db.CheckConstraint("EMOPENEND IN ('Y','N')"),
        db.CheckConstraint("EMTYPETRADING IN ('C','F')"),
        db.Index("idx1_emission", "emcfin", "emissuer"),
        {"schema": "exane"},
    )

    emcfin = db.Column(
        db.ForeignKey(Produit.prcfin, ondelete="CASCADE"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    emissuer = db.Column(
        db.ForeignKey(Tier.ticode),
        nullable=False,
        index=True,
        info="Code d'une personne physique ou morale",
    )
    emtype = db.Column(db.String(1), info="Emission (P)ublique ou privée(X)")
    emdate = db.Column(db.DateTime, info="Date de l'émission de l'instrument")
    empaiement = db.Column(
        db.DateTime, info="Date initiale de calcul des intérêts sur l'instrument"
    )
    emnominal = db.Column(db.Float, info="Valeur du nominal")
    emnomieuro = db.Column(info="Nominal marche en euro")
    emprix = db.Column(db.Float, info="Prix d'emission")
    emspread = db.Column(info="Spread à l'émission")
    emnomport = db.Column(db.String(1), info="Type souscription")
    emprixpoint = db.Column(server_default=db.FetchedValue(), info="Prix du point")
    emcapiinit = db.Column(db.Float, info="Capitalisation initiale")
    emprime = db.Column(info="Prime d'emission")
    emrdt = db.Column(info="Rendement à maturité")
    emmaturite = db.Column(db.DateTime, info="Echeance ou maturité de l'instrument")
    emcapigarantie = db.Column(info="Capital garanti")
    emdatestrike = db.Column(db.DateTime, info="Date du strike")
    emopenend = db.Column(
        db.String(1), info="Definit si l'emission est un OpenEnd ou pas (Null <=> N)"
    )
    emtypetrading = db.Column(
        db.String(1), info="Mode de cotation : Continu ou Fixing "
    )
    emkibi = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Knock-In By Issuer pour répliquer la liste intraday",
    )

    tier = db.relationship(
        "Tier",
        primaryjoin="Emission.emissuer == Tier.ticode",
        lazy=True,
        backref="emissions",
    )


class Agence(db.Model):
    __tablename__ = "agence"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    agcode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code agence de notation",
    )
    agnom = db.Column(db.String(20), nullable=False, info="Nom agence de notation")


class Typescale(db.Model):
    __tablename__ = "typescale"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tstype = db.Column(primary_key=True, info="Type scale")
    tsnom = db.Column(db.String(20), info="Scale")


class Typenote(db.Model):
    __tablename__ = "typenote"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tnnote = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de la note attribuée par une agence de rating",
    )
    tnagence = db.Column(
        db.ForeignKey(Agence.agcode),
        nullable=False,
        index=True,
        info="Code agence de notation",
    )
    tnrating = db.Column(db.String(20), nullable=False, info="Code du rating")
    tnhorizon = db.Column(
        db.String(4), info="Spécifie si le rating attribué est CT ou LT"
    )
    tnsignif = db.Column(
        db.String(20),
        info="Signification de la note attribuée par une agence de rating",
    )
    tntype = db.Column(db.ForeignKey(Typescale.tstype))
    tnratingordre = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        info="Ordonnancement du code du rating au sein d'une agence",
    )

    agence = db.relationship(
        "Agence",
        primaryjoin="Typenote.tnagence == Agence.agcode",
        lazy=True,
        backref="typenotes",
    )
    typescale = db.relationship(
        "Typescale",
        primaryjoin="Typenote.tntype == Typescale.tstype",
        lazy=True,
        backref="typenotes",
    )


class Typesecteur(db.Model):
    __tablename__ = "typesecteurs"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tsecode = db.Column(primary_key=True, info="Code de la nomenclature des secteurs",)
    tsenom = db.Column(
        db.String(15), nullable=False, info="Libellé de la nomenclature des secteurs"
    )


class Secteur(db.Model):
    __tablename__ = "secteur"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    secode = db.Column(primary_key=True, info="Code secteur")
    setype = db.Column(
        db.ForeignKey(Typesecteur.tsecode),
        nullable=False,
        index=True,
        info="Code de la nomenclature des secteurs",
    )
    senom = db.Column(db.String(250), nullable=False, info="Nom du secteur")
    sename = db.Column(db.String(250), nullable=False, info="Nom du secteur en anglais")
    seordre = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="Ordre de presentation d'un secteur au sein d'une nomenclature",
    )
    selevel = db.Column(info="Niveau de composition du secteur")
    senote = db.Column(
        db.ForeignKey(Typenote.tnnote),
        index=True,
        info="Code de la note attribuée par une agence de rating",
    )
    seabrege = db.Column(db.String(20))

    typenote = db.relationship(
        "Typenote",
        primaryjoin="Secteur.senote == Typenote.tnnote",
        lazy=True,
        backref="secteurs",
    )
    typesecteur = db.relationship(
        "Typesecteur",
        primaryjoin="Secteur.setype == Typesecteur.tsecode",
        lazy=True,
        backref="secteurs",
    )


class Hsectorisation(db.Model):
    __tablename__ = "hsectorisation"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    hstiers = db.Column(
        db.ForeignKey(Tier.ticode, ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code d'une personne physique ou morale",
    )
    hscode = db.Column(
        db.ForeignKey(Secteur.secode),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code secteur",
    )
    hsdatein = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Date d'entrée d'une société dans un secteur d'activité",
    )
    hsdateout = db.Column(
        db.DateTime, info="Date de sortie d'une société dans un secteur d'activité"
    )

    secteur = db.relationship(
        "Secteur",
        primaryjoin="Hsectorisation.hscode == Secteur.secode",
        lazy=True,
        backref="hsectorisations",
    )
    tier = db.relationship(
        "Tier",
        primaryjoin="Hsectorisation.hstiers == Tier.ticode",
        lazy=True,
        backref="hsectorisations",
    )


class ModeReglement(db.Model):
    __tablename__ = "mode_reglement"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    mrcode = db.Column(
        db.String(1), primary_key=True, info="Code du mode de réglement."
    )
    mrlibelle = db.Column(
        db.String(60), nullable=False, info="Libéllé du mode de réglement."
    )


class Derives(Produit):
    __tablename__ = "derives"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("DECFIN<>DESJAC"),
        db.CheckConstraint("DECFIN<>DESJAC"),
        {"schema": "exane"},
    )

    decfin = db.Column(
        db.ForeignKey(Produit.prcfin, ondelete="CASCADE"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    desjac = db.Column(
        db.ForeignKey(Instrument.ifcfin),
        index=True,
        info="Code de l'instrument financier",
    )
    dereg = db.Column(
        db.ForeignKey(ModeReglement.mrcode), info="Libelle du mode de reglement"
    )
    decouv = db.Column(db.String(1), info="Type de couverture")
    deassim = db.Column(db.String(1), info="Type d'assimilation")
    desoulteuro = db.Column(db.Numeric(8, 2), info="Soulte Euro")
    deappelmarge = db.Column(
        db.Enum("O", "N"),
        server_default=db.FetchedValue(),
        info="Précise si le derive fonctionne avec appel de marge et non pas avec une prime (O/N)",
    )

    mode_reglement = db.relationship(
        "ModeReglement",
        primaryjoin="Derives.dereg == ModeReglement.mrcode",
        backref="derives",
    )
    instrument = db.relationship(
        "Instrument",
        primaryjoin="Derives.desjac == Instrument.ifcfin",
        backref="derives",
    )


class Volinstr(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    id = db.Column(db.Integer, primary_key=True)
    vicfin = db.Column(db.Integer)
    vimaturite = db.Column(db.Integer)
    vitype = db.Column(db.Integer)
    videv = db.Column(db.Integer, db.ForeignKey(Devise.dvcfin))
    vigroupe = db.Column(db.Integer)
    viposition = db.Column(db.Integer)
    vivolat = db.Column(db.Float)


class VTypologie(db.Model):
    __tablename__ = "v_typologie"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    rowid = db.Column(primary_key=True, autoincrement=True)
    code_valeur_typee = db.Column(
        db.Numeric(12, 0, asdecimal=False),
        nullable=False,
        info="Valeur typée (Produit, Opérations, Paramètre...)",
    )
    horodate_typologie = db.Column(
        db.DateTime, nullable=False, info="Horodatage de la typologie"
    )
    flag_typologie = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="Flag état de la typologie",
    )
    code_valeur_typologie = db.Column(
        nullable=False, info="Code interne de la typologie",
    )
    libelle_typologie = db.Column(
        db.String(60), nullable=False, info="Libéllé de la typologie"
    )
    code_famille_typologie = db.Column(
        nullable=False, info="Code interne de la famille de typologie",
    )
    libelle_famille_typologie = db.Column(
        db.String(100), nullable=False, info="Libéllé de la famille de typologie"
    )
    nature_famille_typologie = db.Column(
        db.String(1),
        nullable=False,
        info="Code de la nature de la typologie (Instrument/opération..)",
    )
    libelle_nature_famille_typo = db.Column(
        db.String(10),
        info="Libéllé de la nature de la typologie (Instrument/ Opération...)",
    )
    partition_famille_typologie = db.Column(
        db.String(1),
        nullable=False,
        info="Etat de partitionnement de la famille de la typologie",
    )
    code_proprietaire_famille_typo = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        nullable=False,
        info="Code interne du propriétaire de la typologie",
    )
    libelle_propriet_famille_typo = db.Column(
        db.String(60), nullable=False, info="Libéllé du propriétaire de la typologie."
    )


class VTypofoLibelle(db.Model):
    __tablename__ = "v_typofo_libelles"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    rowid = db.Column(primary_key=True, autoincrement=True)
    code_typo = db.Column(db.Numeric(9, 0, asdecimal=False), nullable=False)
    libelle_deduit = db.Column(db.String(403))
    code_typo_instrument = db.Column(nullable=False)
    libelle_typo_instrument = db.Column(db.String(200), nullable=False)
    code_typo_sjac = db.Column(db.Numeric(3, 0, asdecimal=False))
    libelle_typo_sjac = db.Column(db.String(200))
    autorise_contrat_titre = db.Column(db.String(1))
    autorise_contrat_liste = db.Column(db.String(1))
    autorise_contrat_otc = db.Column(db.String(1))
    autorise_contrat_indefini = db.Column(db.String(1))


class V_tauxchange_euro_ref(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane", "extend_existing": True}
    id = db.Column(db.Integer, primary_key=True)
    tcrcfin = db.Column(db.Integer)
    tcrlibcross = db.Column(db.String)
    tcrdateref = db.Column(db.Date)
    tcrpriclos = db.Column(db.Integer)
    tcrdevnominal = db.Column(db.Integer)


class Idxtypeoperation(db.Model):
    __tablename__ = "idxtypeoperation"
    __table_args__ = {"schema": "derives"}

    xtocode = db.Column(db.Float, primary_key=True, info="Identifiant de l operation",)
    xtolibelle = db.Column(db.String(200), info="Nom de l operation")


class Idxtypereinvest(db.Model):
    __tablename__ = "idxtypereinvest"
    __table_args__ = {"schema": "derives"}

    xtrcode = db.Column(
        db.Float, primary_key=True, info="Identifiant du type de reinvestissement",
    )
    xtrlibelle = db.Column(db.String(200), info="Description du reinvestissement")


class Idxoperation(db.Model):
    __tablename__ = "idxoperations"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.Index(
            "uk_idxcompofixe", "xocfin", "xosj", "xodate", "xotype", "xotypereinvest"
        ),
        {"schema": "derives"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    xocfin = db.Column(
        db.ForeignKey(Instrument.ifcfin),
        nullable=False,
        info="cfin de l indice (ou du panier)",
    )
    xosj = db.Column(
        db.ForeignKey(Instrument.ifcfin), index=True, info="cfin du sous jacent",
    )
    xodatesaisie = db.Column(db.DateTime, nullable=False, info="date de saisie")
    xodate = db.Column(db.DateTime, nullable=False, info="date d effet de l operation")
    xotype = db.Column(
        db.ForeignKey(Idxtypeoperation.xtocode),
        nullable=False,
        info="type de l operation",
    )
    xotypereinvest = db.Column(
        db.ForeignKey(Idxtypereinvest.xtrcode), info="type de reinvestissement",
    )
    xomontant = db.Column(db.Float)
    xodev = db.Column(db.Float, info="devise")
    xocommentaire = db.Column(db.String(450), info="commentaire")
    xosjcible = db.Column(db.Float)

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Idxoperation.xocfin == Instrument.ifcfin",
        backref="instrument_idxoperations",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Idxoperation.xosj == Instrument.ifcfin",
        backref="instrument_idxoperations_0",
    )
    idxtypeoperation = db.relationship(
        "Idxtypeoperation",
        primaryjoin="Idxoperation.xotype == Idxtypeoperation.xtocode",
        backref="idxoperations",
    )
    idxtypereinvest = db.relationship(
        "Idxtypereinvest",
        primaryjoin="Idxoperation.xotypereinvest == Idxtypereinvest.xtrcode",
        backref="idxoperations",
    )


class Idxattributs(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "derives", "extend_existing": True}
    xacfin = db.Column(db.String, db.ForeignKey(Instrument.ifcfin), primary_key=True)
    xatypeattribut = db.Column(db.Integer)
    xadatedb = db.Column(db.Date)
    xadatefin = db.Column()
    xavaleurnum = db.Column()
    xavaleurdate = db.Column()
    xavaleurbool = db.Column()
    xavaleurstring = db.Column(db.String)
    xadatesaisie = db.Column(db.Date)


class Baction(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "derives", "extend_existing": True}
    accfin = db.Column(db.String, db.ForeignKey(Instrument.ifcfin), primary_key=True)
    acdate = db.Column(db.Date)
    acnom = db.Column(db.String)
    acmktcap = db.Column(db.Float)
    acrdtnetdiv_next = db.Column(db.Float)
    acrdtbrutdiv_next = db.Column(db.Float)


class Hactions(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "derives", "extend_existing": True}
    hacfin = db.Column(db.String, db.ForeignKey(Instrument.ifcfin), primary_key=True)
    hadate = db.Column(db.Date)
    hamktcap = db.Column(db.Float)
    hacodesect = db.Column(db.Integer)
    hardtnetdiv_next = db.Column(db.Float)
    hardtbrutdiv_next = db.Column(db.Float)


class Bcaspsj(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "derives", "extend_existing": True}
    id = db.Column(db.Integer, primary_key=True)
    cjcfin = db.Column(db.String)
    cjdeltapct = db.Column(db.Float)
    cjcfinsj = db.Column(db.String)
    cjdate = db.Column(db.Date)
    cjrcvolatility = db.Column(db.Float)
    cjrcspot = db.Column(db.Float)
    cjrcdelta = db.Column(db.Float)
    cjrcgamma = db.Column(db.Float)
    cjrcvega = db.Column(db.Float)
    cjrcvegaweighted = db.Column(db.Float)
    cjrc = db.Column(db.Float)


class Bstrspecifique(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "derives", "extend_existing": True}
    id = db.Column(db.Integer, primary_key=True)
    cscfin = db.Column(db.String)
    csmodeut = db.Column()
    csprofilgcp = db.Column()
    cstypepricer = db.Column()
    csindic = db.Column()
    csdate = db.Column(db.Date)
    csvaleurindic = db.Column()
    csflag_etat = db.Column()


class Hsmiles(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "derives", "extend_existing": True}
    rowid = db.Column(primary_key=True)
    smcfin = db.Column(db.Integer, db.ForeignKey(Instrument.ifcfin))
    smmarche = db.Column(db.Integer, db.ForeignKey(Marche.macode))
    smdate = db.Column(db.Date)
    smdatematu = db.Column(db.Date)
    smnbjours = db.Column(db.Integer)
    smforward = db.Column(db.Float)
    smvatm = db.Column(db.Float)
    smsmile = db.Column(db.Float)
    smcurve = db.Column(db.Float)
    smerreur = db.Column(db.Float)
    smnbdata = db.Column(db.Integer)
    smnboptim = db.Column(db.Integer)
    smflag_etat = db.Column(db.Integer)
    smncode = db.Column(db.Integer)


class Afsecteur(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "analyse", "extend_existing": True}
    secfin = db.Column(db.Integer, primary_key=True)
    setypesecteur = db.Column(db.Integer)
    seordre = db.Column(db.Integer)
    senomfrancais = db.Column(db.String)
    senomanglais = db.Column(db.String)
    seopinion = db.Column(db.Integer)
    seindice = db.Column(db.Integer, primary_key=True)


class Afopinion(db.Model):
    __tablename__ = "afopinions"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("OPCODE IN (0, 1, 2, 4, 8)"),
        {"schema": "analyse"},
    )

    opcode = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        primary_key=True,
        server_default=db.FetchedValue(),
        info="Code opinion",
    )
    oplibellefr = db.Column(db.String(40), info="Libellé français")
    oplibellegb = db.Column(db.String(40), info="Libellé anglais")
    oplibellecourtfr = db.Column(db.String(10))
    oplibellecourtgb = db.Column(db.String(10))


class Afsociete(Instrument):
    __tablename__ = "afsociete"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("SOOPINIONVALEUR IN (0, 1, 2, 4, 8)"),
        db.CheckConstraint("SORESULTAT12M BETWEEN 1 AND 12"),
        db.CheckConstraint("SORESULTAT6M BETWEEN 1 AND 12"),
        {"schema": "analyse"},
    )

    socfin = db.Column(
        db.ForeignKey(Instrument.ifcfin), primary_key=True, info="Code société"
    )
    sotypesecteur = db.Column(
        nullable=False, server_default=db.FetchedValue(), info="Type de secteur",
    )
    sodevise = db.Column(
        nullable=False, server_default=db.FetchedValue(), info="Devise de suivi",
    )
    sounite = db.Column(
        nullable=False,
        server_default=db.FetchedValue(),
        info="Unité par défaut de la société",
    )
    sodevisecompte = db.Column(
        nullable=False, server_default=db.FetchedValue(), info="Code devise de comptes",
    )
    sopdesc = db.Column(db.String(40), nullable=False, info="Nom de la société")
    socodesuivi = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Code type de suivi",
    )
    soanalysteprincipal = db.Column(
        nullable=False, server_default=db.FetchedValue(), info="Analyste principal",
    )
    soindiceref = db.Column(
        nullable=False, server_default=db.FetchedValue(), info="Indice de référence",
    )
    sosicovam = db.Column(db.Numeric(6, 0, asdecimal=False), info="Code sicovam")
    sopays = db.Column(nullable=False, server_default=db.FetchedValue(),)
    soreuter = db.Column(db.String(8), info="Code reuter")
    sotopval = db.Column(db.String(6), info="Code topval")
    sost_guide = db.Column(
        db.String(1), server_default=db.FetchedValue(), info="Drapeau stock guide"
    )
    sonote = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Opinion",
    )
    sosmall_st_guide = db.Column(
        db.String(1), server_default=db.FetchedValue(), info="Drapeau small stock guide"
    )
    soopinionvaleur = db.Column(
        db.ForeignKey(Afopinion.opcode), server_default=db.FetchedValue()
    )
    soobjhaut = db.Column(db.Float, info="Objectif cours haut")
    soobjbas = db.Column(info="Objectif cours bas")
    soflottant = db.Column(
        db.Numeric(7, 2),
        server_default=db.FetchedValue(),
        info="Pourcentage de flottant",
    )
    sotypemult = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Type de multiple",
    )
    somultiple = db.Column(db.Numeric(7, 2), info="Multiple")
    sostrucfi = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Note de structure financière",
    )
    somanagement = db.Column(
        db.String(1), server_default=db.FetchedValue(), info="Note de management"
    )
    sorisquespec = db.Column(
        db.String(1), server_default=db.FetchedValue(), info="Risque spécifique"
    )
    sobigmidcap = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Définit si la société est de type Big ou Mid",
    )
    soresultat6m = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Mois du résultat semestriel",
    )
    soresultat12m = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Mois du résultat annuel",
    )
    sosensibdollar = db.Column(
        db.Numeric(9, 3),
        server_default=db.FetchedValue(),
        info="Sensibilité à une hausse de 10% du cross devise dollar",
    )
    sosensibtaux = db.Column(
        db.Numeric(9, 3),
        server_default=db.FetchedValue(),
        info="Sensibilité à une hausse de 1% des taux",
    )
    sosensibvolume = db.Column(
        db.Numeric(9, 3),
        server_default=db.FetchedValue(),
        info="Sensibilité à une hausse de 1% des volumes",
    )
    sotypesensib = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="0(C) consolidation, 1(X) exportation",
    )
    sosensibdevise = db.Column(
        db.Numeric(9, 3),
        server_default=db.FetchedValue(),
        info="Sensibilité à une baisse de 10% de la devise",
    )
    sopath = db.Column(db.String(80), info="Répertoire de stockage")
    sofile = db.Column(db.String(100), info="Fichier par défaut")
    sourl = db.Column(db.String(160), info="Addresse du site internet")
    sotypesociete = db.Column(server_default=db.FetchedValue())
    sotypegrille = db.Column(db.Numeric(3, 0, asdecimal=False))
    sotypevalo = db.Column(db.Numeric(2, 0, asdecimal=False))
    sovaluegrowth = db.Column(db.Numeric(2, 0, asdecimal=False))
    sodatemodif = db.Column(db.DateTime)
    sotauxltg = db.Column(db.Numeric(9, 3))
    sourlgb = db.Column(db.String(160))
    sourlprive = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    soaffecteopsecteur = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    sodilutionflag = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    anneedepartfichesoc = db.Column(db.Numeric(4, 0, asdecimal=False))
    anneefinfichesoc = db.Column(db.Numeric(4, 0, asdecimal=False))
    publierfichesoc = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    somailclient = db.Column(db.String(255))
    soflottantddv = db.Column(db.Numeric(7, 2))
    sodatemodifcdc = db.Column(db.DateTime)
    socodechamp1 = db.Column()
    socodechamp2 = db.Column()
    socodechamp3 = db.Column()
    sotypepublication = db.Column(db.Numeric(2, 0, asdecimal=False))
    sogroupcomp = db.Column(db.String(40))
    sogroupcompgb = db.Column(db.String(40))
    socodechamp4 = db.Column()
    socodechamp5 = db.Column()
    sochamplibreaff1 = db.Column()
    sochamplibreaff2 = db.Column()
    sochamplibreaff3 = db.Column()
    sochamplibreaff4 = db.Column()
    sochamplibreaff5 = db.Column()
    sodesccourt = db.Column(db.String(15))
    socodechamp6 = db.Column()
    socodechamp7 = db.Column()
    socodechamp8 = db.Column()
    socodechamp9 = db.Column()
    socodechamp10 = db.Column()
    soclasse = db.Column(db.Numeric(3, 0, asdecimal=False))
    socoefdebr = db.Column(db.Numeric(3, 0, asdecimal=False))
    sonotevoldebr = db.Column(db.Numeric(6, 2))
    sonotedispdebr = db.Column(db.Numeric(6, 2))
    sonotecycldebr = db.Column(db.Numeric(6, 2))
    sonoteincertdebr = db.Column(db.Numeric(6, 2))
    sonotecashconvdebr = db.Column(db.Numeric(6, 2))
    sofacteurajustdebr = db.Column(db.Numeric(6, 2))
    solevierfinancierdebr = db.Column(db.Numeric(6, 2))
    sotauxisdebr = db.Column(db.Numeric(6, 2))
    sodatedernieresereinguecorr = db.Column(db.DateTime)
    sodatedernieresereingue = db.Column(db.DateTime)
    soparamnotederisque = db.Column(db.Numeric(1, 0, asdecimal=False))
    soprecisiongrille = db.Column(db.Numeric(1, 0, asdecimal=False))
    sotypegraph = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Détermine le type de graphique pour la grille 14 ans (normal ou logarithmique)",
    )
    sotypecroissorg = db.Column(db.String(2))
    soanalysteprincipal2 = db.Column(nullable=False, server_default=db.FetchedValue(),)
    sotypebt = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Type de la base titres 0 = Sake 1 = Excel",
    )

    opinion = db.relationship(
        "Afopinion",
        primaryjoin="Afsociete.soopinionvaleur == Afopinion.opcode",
        lazy=True,
        backref="afsociete",
    )


class Afstoxx_sectors_link(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "analyse", "extend_existing": True}
    codestoxx = db.Column(db.Integer, primary_key=True)
    codeexane = db.Column(db.Integer, primary_key=True)
    startdate = db.Column(db.Date, primary_key=True)
    enddate = db.Column(db.Date)


class Afstoxx_sectors(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "analyse", "extend_existing": True}
    code = db.Column(db.Integer, primary_key=True)
    shortlabel = db.Column(db.String)
    longlabel = db.Column(db.String)
    opinion = db.Column()
    codeds = db.Column(db.Integer)
    updatedate = db.Column(db.Date)


class Afhistoopinionvaleur(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "analyse", "extend_existing": True}
    rowid = db.Column(primary_key=True)
    hovcfin = db.Column(db.Integer)
    hovdate = db.Column(db.Date)
    hovoldopinion = db.Column(db.Integer)
    hovnewopinion = db.Column(db.Integer)
    hoperfabs = db.Column(db.Float)
    hovdatediffusion = db.Column(db.Date)


class Afhistoopinionsecteur(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "analyse", "extend_existing": True}
    rowid = db.Column(primary_key=True)
    hoscfin = db.Column(db.Integer)
    hosdate = db.Column(db.Date)
    hosoldopinion = db.Column(db.Integer)
    hosnewopinion = db.Column(db.Integer)


class Afhistoobjectifcours(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "analyse", "extend_existing": True}
    rowid = db.Column(primary_key=True)
    occfin = db.Column(db.Integer)
    ocdatemodif = db.Column(db.Date)
    ocobjectif = db.Column(db.Float)
    socoeff = db.Column(db.Float)
    ocupside = db.Column(db.Float)


class Afratioshisto(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "analyse", "extend_existing": True}
    rowid = db.Column(primary_key=True)
    rhcfin = db.Column(db.Integer)
    rhdate = db.Column(db.Date)
    rhexefiscal = db.Column(db.Integer)
    rhve = db.Column(db.Float)
    rhcapi = db.Column(db.Float)
    rhpeavtsl = db.Column(db.Float)
    rhpeaprsvl = db.Column(db.Float)
    rhpcfpa = db.Column(db.Float)
    rhpanpa = db.Column(db.Float)
    rhvesurca = db.Column(db.Float)
    rhvesurebitda = db.Column(db.Float)
    rhvesurebit = db.Column(db.Float)
    rhnbtitresdiluemoyen = db.Column(db.Float)
    rhnbtitresreelfinexe = db.Column(db.Float)
    rhfcfyield = db.Column(db.Float)
    rhrendementnet = db.Column(db.Float)


class Scriptcoupon(db.Model):
    __tablename__ = "scriptcoupons"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "derives"}

    sccfin = db.Column(
        db.ForeignKey(Instrument.ifcfin),
        primary_key=True,
        nullable=False,
        info="Cfin de l instrument",
    )
    scindex = db.Column(primary_key=True, nullable=False, info="Id du coupon",)
    scdate = db.Column(db.DateTime, nullable=False, info="Date de ficing du coupon")
    scamount = db.Column(nullable=False, info="Montant du coupon")
    scconstatpast = db.Column(info="DateConstat Est Elle Passee")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Scriptcoupon.sccfin == Instrument.ifcfin",
        backref="scriptcoupons",
    )


class Rkvendeurcircus(db.Model):
    __tablename__ = "rkvendeurcircus"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    vccode = db.Column(primary_key=True)
    vcnom = db.Column()
    vcprenom = db.Column(db.String(60))
    vccodefront = db.Column(db.String(6))
    vcidcrm = db.Column(info="Identifiant CRM")
    vcloginad = db.Column(db.String(25), info="Login AD")
    vcflag = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Etat du vendeur",
    )
    vciddeskcrm = db.Column(info="Identifiant du desk dans la CRM")
    vcnomdeskcrm = db.Column(db.String(50), info="Nom du desk dans la CRM")


class Rkuser(db.Model):
    __tablename__ = "rkuser"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    ususer = db.Column(primary_key=True, info="Code User")
    usgroupe = db.Column(info="Code Groupe (cf table RKGROUPE)")
    usnom = db.Column(db.String(30), info="Nom du user")
    uspw = db.Column(db.String(8), info="Mot de passe du user")
    usflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    usadnom = db.Column(
        db.String(30), info="Login de l'utilisateur dans l'Active Directory"
    )


class Rkoperation(db.Model):
    __tablename__ = "rkoperation"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint(" optypevolcker IN ('C', 'M', 'J', 'K', 'T') "),
        db.CheckConstraint("OPDATE = TRUNC(OPDATE) AND OPDATERL = TRUNC(OPDATERL)"),
        db.CheckConstraint("OPDATE = TRUNC(OPDATE) AND OPDATERL = TRUNC(OPDATERL)"),
        # db.Index("idx_rkoperation_externalref", "opsysteme", "opexternalref"),
        db.Index("idx_rkoperation_date_book", "opdate", "opbook"),
        db.Index("idx_rkoperation_datenegobook", "opdatenego", "opbook"),
        {"schema": "risque"},
    )

    opbook = db.Column(db.Numeric(5, 0, asdecimal=False), info="Code sous-portefeuille")
    opcfin = db.Column(index=True, info="Code du produit")
    opticket = db.Column(db.String(12), info="Numero de ticket")
    opcompte = db.Column(db.Numeric(5, 0, asdecimal=False), info="Code compte")
    opuser = db.Column(db.ForeignKey(Rkuser.ususer), info="Code user")
    opquantite = db.Column(info="Quantite")
    opmontant = db.Column(db.Float, info="Montant")
    opdev = db.Column(info="Devise du montant")
    opotype = db.Column(info="Code type d operation")
    opdaterl = db.Column(db.DateTime, info="Date de reglement livraison")
    opmoderl = db.Column(info="Code mode de reglement livraison")
    opfrais = db.Column(info="Montant de frais")
    opcptie = db.Column(info="Code contrepartie")
    opdate = db.Column(db.DateTime, info="Date de la negociation")
    ophorodate = db.Column(db.DateTime, info="Date/heure de création de l'opération.")
    opstatut = db.Column(info="Status de la negociation")
    opcours = db.Column(db.Float, info="Cours de la negociation")
    opchange = db.Column(info="Taux de change lors de la negociation")
    opmontantcc = db.Column(info="Montant du coupon couru")
    opflag = db.Column(info="Flag de suppression")
    opquantitebroker = db.Column(db.Numeric(17, 4))
    opprixbroker = db.Column()
    opquantitehedge = db.Column()
    opprixhedge = db.Column()
    optiers = db.Column()
    opprovenance = db.Column(db.String(1))
    opportef = db.Column()
    opgenerateur = db.Column()
    opstyle = db.Column(db.String(1))
    opquotite = db.Column(db.Numeric(12, 4))
    optypesaisie = db.Column()
    opcommentaire = db.Column(db.String(256))
    opvendeur = db.Column(db.ForeignKey(Rkvendeurcircus.vccode))
    opmargevendeur = db.Column()
    opmargetrader = db.Column()
    opinformation = db.Column()
    opnumero = db.Column(
        primary_key=True, info="Id de la table à renseigner. automatiquement pour Next",
    )
    opannule = db.Column(info="Id de l'opé contrepassée, peut être NULL",)
    oporigine = db.Column(
        index=True, info="Id de l'opé qui est remplacée, peut être NULL",
    )
    opdatenego = db.Column(
        db.DateTime, info="Date de négociation de l'opé, peut être NULL"
    )
    opnumechange = db.Column()
    opcfinreference = db.Column()
    opvalidation = db.Column(db.String(1))
    opmaj = db.Column(
        db.DateTime, index=True, info="Date/heure de mise à jour de l'opération."
    )
    optypecotation = db.Column(
        db.String(1),
        info="Type de cotation (indique si on doit inclure ou non le montant du coupon couru)",
    )
    opmodecotation = db.Column(info="Devise ou % du nominal")
    # opcouponpaye = db.Column(db.ForeignKey('risque.rkcouponspayes.cpcode'), index=True, info='N° du coupon payé')
    opversion = db.Column(
        info="Numéro de version de l'opération (Nb de changements / UPDATE)",
    )
    opparentid = db.Column(
        index=True,
        info="Parent complex deal ID if this deal is aggregated with at least another deal or complex deal",
    )
    opnominal = db.Column(info="Nominal de l instrument de l operation")
    # opsysteme = db.Column(db.ForeignKey('risque.rksystem.syid'), info='Systeme ayant cree l operation')
    opexternalref = db.Column(
        db.String(36),
        server_default=db.FetchedValue(),
        info="External reference of the deal",
    )
    opexporttomoflag = db.Column(info="Export to MO Flag for simple deal")
    opbrokertiersprincipal = db.Column(info="Third-party as principal Broker")
    opbrokertierssecondaire = db.Column(info="Third-party as secondary broker")
    opcptietiersprincipal = db.Column(info="Third-party as principal Counterparty")
    opcptietierssecondaire = db.Column(info="Third-party as principal Counterparty")
    opmarche = db.Column(db.String(15), info="Market place of the transaction")
    opentite = db.Column(
        info="Colonne denormalisee de la table risque.rkbudget pour permettre le partitionnement",
    )
    optcsstate = db.Column(info="TCS state for simple deal")
    opmostate = db.Column(info="MO state for simple deal")
    opmontantbrut = db.Column(info="Gross amount")
    opmontantttfi = db.Column(info="Montant de la TTF Italienne")
    oputi = db.Column(
        db.String(52),
        info="Code UTI de la transaction (identificant externe du contrat - Projet EMIR)",
    )
    opmoreconciliation = db.Column(
        info="The reconciliation state received from external application (ex. Examatch)",
    )
    opdiscount = db.Column(
        info="Montant de la decote concedee sur le produit de la transaction",
    )
    opestflux = db.Column(
        db.String(1), info="Definit si le produit de la transaction est un flux"
    )
    opmargeflux = db.Column(
        info="Montant total (marge, commission, decote) genere avant emission du produit de la transaction",
    )
    opcommissionechelonnee = db.Column()
    opetatpolmarge = db.Column(info="Etat de la politique de marge")
    opmargecontrib = db.Column(
        info="Marge de contribution de l'instrument d'un deal avec vendeur",
    )
    opinitiateur = db.Column(info="Initiateur de l execution electronique")
    opexecannulraison = db.Column(
        info="Justification trading pour l'annulation d'une execution",
    )
    opinitialfrontoperator = db.Column(info="Createur de l'operation")
    opyoshiid = db.Column(
        db.String(50),
        index=True,
        info="Identifiant complet de l'execution de la requete Yoshi",
    )
    opdatecreation = db.Column(
        db.DateTime, info="Date de creation a la milliseconde de l'operation"
    )
    opdatemodif = db.Column(
        db.DateTime,
        info="Date de dernier modification a la milliseconde de l'operation",
    )
    opexecutionvenuemic = db.Column(
        db.String(4), info="Execution venue broker MIC code"
    )
    opyoshictpyid = db.Column(info="Yoshi counterparty id")
    opsoulte = db.Column()
    optypevolcker = db.Column(db.String(1), info="Typologie Volcker de l'operation")
    opcommissionia = db.Column(info="Prix theorique de l Index advisor")
    opordercategory = db.Column(db.String(50), info="Categorie d'ordre (Yoshi,...)")
    opindexcfin = db.Column()
    opidadvisoroperation = db.Column(db.String(100))
    optransfertype = db.Column(db.Numeric(1, 0, asdecimal=False))

    sales = db.relationship(
        Rkvendeurcircus,
        primaryjoin="Rkoperation.opvendeur == Rkvendeurcircus.vccode",
        backref="rkoperations",
    )

    user = db.relationship(
        Rkuser,
        primaryjoin="Rkoperation.opuser == Rkuser.ususer",
        backref="rkoperations",
    )

    # rkcouponspaye = db.relationship('Rkcouponspaye', primaryjoin='Rkoperation.opcouponpaye == Rkcouponspaye.cpcode', backref='rkoperations')
    # rksystem = db.relationship('Rksystem', primaryjoin='Rkoperation.opsysteme == Rksystem.syid', backref='rkoperations')


class Rkfamilleop(db.Model):
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque", "extend_existing": True}
    rowid = db.Column(primary_key=True)
    focode = db.Column()
    fonom = db.Column()
    foflag = db.Column()


class Rkscriptindicateur(db.Model):
    __tablename__ = "rkscriptindicateurs"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    sidate = db.Column(primary_key=True, nullable=False, info="Date de pricing.")
    sicfin = db.Column(
        # db.ForeignKey(Instrument.ifcfin),
        primary_key=True,
        nullable=False,
        info="Cfin du produit.",
    )
    sicle = db.Column(primary_key=True, nullable=False, info="Clé de l'indicateur.")
    sitype = db.Column(nullable=False, info="Type de l'indicateur.")
    sivaleur = db.Column(db.Float, nullable=False, info="Valeur de l'indicateur.")

    # instrument = db.relationship(
    #     "Instrument",
    #     primaryjoin="Rkscriptindicateur.sicfin == Instrument.ifcfin",
    #     backref="rkscriptindicateurs",
    # )


class Prprofil(db.Model):
    __tablename__ = "prprofil"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("PREFERENCE = 0 or PREFERENCE = 1"),
        db.CheckConstraint("PREFERENCE = 0 or PREFERENCE = 1"),
        {"schema": "risque"},
    )

    pprofil = db.Column(primary_key=True)
    pgroupe = db.Column()
    pnom = db.Column(db.String(60))
    preference = db.Column(nullable=False, server_default=db.FetchedValue())
    psnapshot = db.Column(
        db.Enum("N", "O"),
        server_default=db.FetchedValue(),
        info="Le profil effectue un cliché des nappes chaque jours (ex : 1004,1001,1002).",
    )


class Rktypemodepricing(db.Model):
    __tablename__ = "rktypemodepricing"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    mpcode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code du mode de pricing.",
    )
    mplibelle = db.Column(db.String(30), info="Libéllé du mode de pricing.")


class Rktypeindicateur(db.Model):
    __tablename__ = "rktypeindicateur"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    ticode = db.Column(primary_key=True)
    tilibelle = db.Column(db.String(30))
    tiflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class Rkpricing(db.Model):
    __tablename__ = "rkpricing"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "uk_pricing_rkpricin",
            "prdate",
            "prprofil",
            "prcfin",
            "prparent",
            "prmode",
            "prflag",
        ),
        {"schema": "risque"},
    )

    prnumero = db.Column(
        db.Numeric(12, 0, asdecimal=False),
        primary_key=True,
        info="Numéro de la requête de pricing",
    )
    prdate = db.Column(db.DateTime, nullable=False, info="Date de pricing")
    prprofil = db.Column(
        db.ForeignKey(Prprofil.pprofil), nullable=False, info="Profil de pricing"
    )
    prparent = db.Column(
        db.ForeignKey(Instrument.ifcfin),
        nullable=False,
        index=True,
        info="Cfin du père",
    )
    prcfin = db.Column(
        db.ForeignKey(Instrument.ifcfin), nullable=False, index=True, info="Cfin pricé"
    )
    prmode = db.Column(
        db.ForeignKey(Rktypemodepricing.mpcode),
        nullable=False,
        index=True,
        info="Mode de pricing",
    )
    prflag = db.Column(nullable=False, info="Etat de la ligne")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Rkpricing.prcfin == Instrument.ifcfin",
        backref="instrument_rkpricings",
        lazy=True,
    )
    rktypemodepricing = db.relationship(
        "Rktypemodepricing",
        primaryjoin="Rkpricing.prmode == Rktypemodepricing.mpcode",
        backref="rkpricings",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Rkpricing.prparent == Instrument.ifcfin",
        backref="instrument_rkpricings_0",
        # lazy="dynamic",
    )
    prprofil1 = db.relationship(
        "Prprofil",
        primaryjoin="Rkpricing.prprofil == Prprofil.pprofil",
        backref="rkpricings",
    )


class Rkpricingresultat(Rkpricing):
    __tablename__ = "rkpricingresultats"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(primary_key=True, autoincrement=True)
    prnumero = db.Column(
        db.ForeignKey(Rkpricing.prnumero, ondelete="CASCADE"),
        nullable=False,
        index=True,
        info="Numéro de la requête de pricing",
    )
    prindicateur = db.Column(
        db.ForeignKey(Rktypeindicateur.ticode),
        nullable=False,
        index=True,
        info="Code de l'indicateur",
    )
    praxe1 = db.Column(
        index=True,
        info="Axe de projection pour les indicateurs vectoriels et matriciels",
    )
    praxe2 = db.Column(
        index=True, info="Axe de projection pour les indicateurs matriciels",
    )
    prvaleur = db.Column(db.Float, info="Valeur de l'indicateur")

    rktypeindicateur = db.relationship(
        "Rktypeindicateur",
        primaryjoin="Rkpricingresultat.prindicateur == Rktypeindicateur.ticode",
        backref="rkpricingresultats",
    )
    rkpricing = db.relationship(
        "Rkpricing",
        primaryjoin="Rkpricingresultat.prnumero == Rkpricing.prnumero",
        backref="rkpricingresultats",
    )


class Rktypeop(db.Model):
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque", "extend_existing": True}
    rowid = db.Column(primary_key=True)
    tootype = db.Column(db.Integer)
    tolibelle = db.Column(db.String)
    toflag = db.Column(db.Integer)
    tofamille = db.Column(db.Integer)
    toactif = db.Column(db.String)


class Rkdefbigbook(db.Model):
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque", "extend_existing": True}
    id = db.Column(db.Integer, primary_key=True)
    dbbigbook = db.Column(db.Integer)
    dbbook = db.Column(db.Integer)
    dbordre = db.Column(db.Integer)
    dbnom = db.Column(db.String)
    dbbooktype = db.Column(db.Integer)
    dbstatus = db.Column(db.Integer)
    dbflag = db.Column(db.Integer)


class Rkbigbook(db.Model):
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque", "extend_existing": True}
    id = db.Column(db.Integer, primary_key=True)
    bbbigbook = db.Column(db.Integer)
    bbbudget = db.Column(db.Integer)  # Type a verifier
    bbtype = db.Column(db.Integer)
    bbnom = db.Column(db.String)


class Rkbudget(db.Model):
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque", "extend_existing": True}
    id = db.Column(db.Integer, primary_key=True)
    bgbudget = db.Column(db.Integer)
    bgcodebud = db.Column(db.String)
    bgentite = db.Column(db.Integer)


class Rkpnl(db.Model):
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque", "extend_existing": True}
    id = db.Column(db.Integer, primary_key=True)
    pldate = db.Column(db.Date)
    plbook = db.Column(db.Integer)
    plcfin = db.Column(db.Integer)
    plprofil = db.Column()
    pldev = db.Column()
    plpljour = db.Column()
    plplcumul = db.Column()
    plfraisjour = db.Column()
    plfraiscumul = db.Column()
    plsolde = db.Column()
    plprixtheo = db.Column()
    plecartvalojour = db.Column()
    plecartvalocumul = db.Column()
    plecartvalodev = db.Column()
    plmontantcc = db.Column()
    plcapi = db.Column()
    plchangehisto = db.Column()


class VCfinMarges(db.Model):
    __bind_key__ = "exane_contrib"
    __table_args__ = {"schema": "crs", "extend_existing": True}
    rowid = db.Column(primary_key=True)
    cfin = db.Column(db.String)
    date_cours = db.Column(db.Date)
    prix_theorique = db.Column(db.Float)
    bid = db.Column(db.Float)
    ask = db.Column(db.Float)
    marge_bid_vente = db.Column(db.Float)
    marge_ask_vente = db.Column(db.Float)
    marge_bid_cp = db.Column(db.Float)
    marge_ask_cp = db.Column(db.Float)
    event = db.Column()


class VMargesInitiales(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "crs", "extend_existing": True}
    rowid = db.Column(primary_key=True)
    cfin = db.Column(db.Integer)
    marge_initiale_bid = db.Column(db.Float)
    marge_initiale_ask = db.Column(db.Float)
    date_maj_marge_bid = db.Column(db.Date)
    loginid_marge_bid = db.Column()
    date_maj_marge_ask = db.Column()
    loginid_marge_ask = db.Column()


class HwarDrEx(db.Model):
    __tablename__ = "hwar_dr_ex"
    __bind_key__ = "exane_contrib"
    __table_args__ = (
        db.Index("idx_hwar_dr_ex_hxcfin_hxdate", "hxcfin", "hxdate"),
        {"schema": "crs"},
    )

    rowid = db.Column(primary_key=True, autoincrement=True)
    hxdate = db.Column(db.DateTime, info="Date insertion")
    hxcfin = db.Column(info="Code instrument")
    hxprofil = db.Column(info="Profil de pricing")
    hxevent = db.Column(db.String(1), info="Evenement : Update / Closing")
    hxuser = db.Column(db.String(64), info="Utilisateur")
    hxhost = db.Column(db.String(64), info="Host")
    hxtheo = db.Column(info="Prix theorique")
    hxbid = db.Column(info="Bid")
    hxask = db.Column(info="Ask")
    hxmargebid_v = db.Column(info="Marge vente BID")
    hxmargeask_v = db.Column(info="Marge vente ASK")
    hxmargebid_cp = db.Column(info="Marge trading BID")
    hxmargeask_cp = db.Column(info="Marge trading ASK")
    hxmode = db.Column(
        db.String(1), info="Sales / Trading ( non renseigné pour les cours de cloture )"
    )
    hxhorodate = db.Column(db.DateTime)


class IntradayDer(db.Model):
    __tablename__ = "intraday_der"
    __bind_key__ = "exane_contrib"
    __table_args__ = (
        # db.Index("idx_intraday_der_cfin_stamp", "iddcfin", "iddstamp"),
        {"schema": "crs"},
    )

    rowid = db.Column(primary_key=True, autoincrement=True)
    iddstamp = db.Column(db.DateTime, info="Time stamp du flux sur cfin")
    iddcfin = db.Column(db.Integer, info="Code instrument financier")
    iddbid = db.Column(db.Float, info="Bid du cfin en l'instant du timestamp")
    iddask = db.Column(db.Float, info="Ask du cfin en l'instant du timestamp")
    iddpxtheo = db.Column(
        db.Float, info="Prix theorique du cfin en l'instant du timestamp"
    )
    iddminbid = db.Column(db.Float, info="Min du bid lors de la derniere periode")
    iddmaxbid = db.Column(db.Float, info="Max du bid lors de la derniere periode")
    iddminask = db.Column(db.Float, info="Min du ask lors de la derniere periode")
    iddmaxask = db.Column(db.Float, info="Max du ask lors de la derniere periode")
    iddminpxtheo = db.Column(
        db.Float, info="Min du prix theorique lors de la derniere periode"
    )
    iddmaxpxtheo = db.Column(
        db.Float, info="Max du prix theorique lors de la derniere periode"
    )


class Hindivol(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "derives", "extend_existing": True}
    hivcfin = db.Column(db.Integer, db.ForeignKey(Instrument.ifcfin), primary_key=True)
    hivmarche = db.Column(db.Integer)  # db.ForeignKey(Marche.macode), primary_key=True
    hivdate = db.Column(db.Date, primary_key=True)
    hivvol = db.Column(db.Float)


class Hsurface(db.Model):
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "derives", "extend_existing": True}
    sucfin = db.Column(db.Integer, db.ForeignKey(Instrument.ifcfin), primary_key=True)
    sudate = db.Column(db.Date, primary_key=True)
    sudatematu = db.Column(db.Date, primary_key=True)
    sustatusdatematu = db.Column(db.Date, primary_key=True)
    sustrike = db.Column(db.Float, primary_key=True)
    sustatutstrike = db.Column(primary_key=True)
    suvi = db.Column(db.Float)
    suvmodele = db.Column()
    suvmodeleobj = db.Column()
    suvsmile = db.Column()
    suflag_etat = db.Column()


class IdxIndictrs(db.Model):
    """Signals on given Cfins +1 or -1"""

    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "derives", "extend_existing": True}
    indcfin = db.Column(db.Integer, db.ForeignKey(Instrument.ifcfin), primary_key=True)
    inddate = db.Column(db.Date, primary_key=True)
    indname = db.Column(db.String, primary_key=True)
    indvalue = db.Column(db.Float)
    inddatevalue = db.Column(db.Date)
    indstringvalue = db.Column(db.String)


class Volimpl(db.Model):
    """Option levels and volatilities, format Schering ML 180 Put"""

    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "derives", "extend_existing": True}
    vocfin = db.Column(db.Integer, db.ForeignKey(Instrument.ifcfin), primary_key=True)
    lcorr = db.Column()
    lvlt = db.Column()
    lvct = db.Column()
    moy_vi = db.Column()
    moy_vlt = db.Column()
    moy_vct = db.Column()
    ect_vi = db.Column()


class ExternalField(db.Model):
    """
    TBD
    """

    __bind_key__ = "exane_contrib"
    __table_args__ = {"schema": "contribnext", "extend_existing": True}
    id = db.Column(db.String, primary_key=True)


class ExternalInstrument(db.Model):
    """
    TBD
    """

    __bind_key__ = "exane_contrib"
    __table_args__ = {"schema": "contribnext", "extend_existing": True}
    instrument_cfin = db.Column(db.Integer, primary_key=True)
    ric = db.Column(db.String)
    bid_field_id = db.Column(db.String, db.ForeignKey(ExternalField.id))
    ask_field_id = db.Column(db.String, db.ForeignKey(ExternalField.id))
    last_field_id = db.Column(db.String)
    mid_field_id = db.Column(db.String, db.ForeignKey(ExternalField.id))
    open_time = db.Column(db.Date)
    close_time = db.Column(db.Date)


class ExternalInstrumentClose(db.Model):
    __bind_key__ = "exane_contrib"
    __table_args__ = {"schema": "contribnext", "extend_existing": True}
    id = db.Column(db.Integer, primary_key=True)
    cfin = db.Column(db.Integer)
    ric = db.Column(db.String)
    bid = db.Column(db.Float)
    ask = db.Column(db.Float)
    last = db.Column(db.Float)
    timestamp = db.Column(db.Date)


class Closer_shredder_h(db.Model):
    __bind_key__ = "exane_contrib"
    __table_args__ = {"schema": "contribnext", "extend_existing": True}
    rowid = db.Column(primary_key=True)
    request_id = db.Column(db.String)
    instrument_valuedate = db.Column(db.Date)
    instrument_cfin = db.Column()
    bid = db.Column()
    ask = db.Column()
    last = db.Column()
    price_timestamp = db.Column(db.DateTime)


class Margin(db.Model):
    __bind_key__ = "exane_contrib"
    __table_args__ = {"schema": "contribnext", "extend_existing": True}
    rowid = db.Column(primary_key=True)
    CFIN = db.Column()
    MARGIN_PROFILE = db.Column()
    order = db.Column()
    CALCULATION_METHOD = db.Column()
    MARGIN_COMMENT = db.Column()
    END_DATE = db.Column()
    START_DATE = db.Column()
    TYPE = db.Column()
    UNARY_OPERATOR = db.Column()
    CURRENCY_CFIN = db.Column()
    INDICATOR_CASTOR_ID = db.Column()
    UNDERLYING_CFIN = db.Column()


class BidMargin(db.Model):
    __bind_key__ = "exane_contrib"
    __table_args__ = {"schema": "contribnext", "extend_existing": True}
    rowid = db.Column(primary_key=True)
    cfin = db.Column()
    margin_profile = db.Column()
    order = db.Column()
    end_value = db.Column()
    formula = db.Column()
    named_type = db.Column()
    start_value = db.Column()


class Nolast(Instrument):
    __tablename__ = "nolast"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    lacfin = db.Column(
        db.ForeignKey(Instrument.ifcfin, ondelete="CASCADE"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    ladate = db.Column(db.DateTime, nullable=False, info="LADATE")
    lapriclos = db.Column(info="LAPRICLOS")
    lapriopen = db.Column(info="LAPRIOPEN")
    laprimoypond = db.Column(info="LAPRIMOYPOND")
    lapo = db.Column(db.Numeric(16, 5), info="LAPO")
    lavolqute = db.Column(db.Numeric(18, 2), info="LAVOLQUTE")
    lavolcapi = db.Column(db.Numeric(18, 2), info="LAVOLCAPI")
    ladatepr = db.Column(db.DateTime, info="LADATEPR")
    lapriclospr = db.Column(info="LAPRICLOSPR")
    lapriopenpr = db.Column(info="LAPRIOPENPR")
    laprimoypondpr = db.Column(info="LAPRIMOYPONDPR")
    lapopr = db.Column(db.Numeric(16, 2), info="LAPOPR")
    lavolqutepr = db.Column(db.Numeric(18, 2), info="LAVOLQUTEPR")
    lavolcapipr = db.Column(db.Numeric(18, 2), info="LAVOLCAPIPR")
    lahigh = db.Column()
    lahighpr = db.Column()
    lalow = db.Column()
    lalowpr = db.Column()


class Ask_margin(db.Model):
    __bind_key__ = "exane_contrib"
    __table_args__ = {"schema": "contribnext", "extend_existing": True}
    rowid = db.Column(primary_key=True)
    cfin = db.Column()
    margin_profile = db.Column()
    order = db.Column()
    end_value = db.Column()
    formula = db.Column()
    named_type = db.Column()
    start_value = db.Column()


class IdxauditIndexEvent(db.Model):
    __bind_key__ = "exane_analyse"
    __tablename__ = "idxaudit_index_event"
    __table_args__ = {"schema": "derives"}

    idasessionid = db.Column(
        primary_key=True, nullable=False, index=True, info="id de la session",
    )
    idacfin = db.Column(
        db.ForeignKey(Instrument.ifcfin),
        nullable=False,
        index=True,
        info="cfin de l indice",
    )
    idavaluedate = db.Column(db.DateTime, nullable=False, index=True, info="value date")
    idaeventype = db.Column(db.Float, nullable=False, info="type event")
    idamontant = db.Column(db.Float, info="montant")
    idacfinsource = db.Column(
        db.ForeignKey(Instrument.ifcfin), index=True, info="cfin source"
    )
    idacross = db.Column(db.Float, info="Cross used")
    idaid = db.Column(db.Float, info="Identifiant technique de la piste d'audit",)

    # instrument = db.relationship(
    #     "Instrument",
    #     primaryjoin="IdxauditIndexEvent.idacfin == Instrument.ifcfin",
    #     backref="instrument_idxaudit_index_events",
    # )
    # instrument1 = db.relationship(
    #     "Instrument",
    #     primaryjoin="IdxauditIndexEvent.idacfinsource == Instrument.ifcfin",
    #     backref="instrument_idxaudit_index_events_0",
    # )
    # appsession = db.relationship(
    #     "Appsession",
    #     primaryjoin="IdxauditIndexEvent.idasessionid == Appsession.asidsession",
    #     backref="idxaudit_index_events",
    # )


class Rkcube(db.Model):
    __bind_key__ = "exane_risque"
    __tablename__ = "rkcube"
    __table_args__ = {"schema": "risque"}

    cudategeneration = db.Column(db.DateTime, nullable=False, index=True)
    cucode = db.Column(db.Float, primary_key=True)
    cudatecalcul = db.Column(db.DateTime)
    cucfinproduit = db.Column(db.Float, nullable=False, index=True)
    cusommediv = db.Column(db.Float, nullable=False)
    cucubecomplet = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Flag fin générération du cube:  O=complet,  N=non terminé",
    )
    cusensicomplet = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Flag fin générération du vecteur de sensibilité :  O=complet,  N=non terminé",
    )
    cudatesensi = db.Column(db.DateTime)
    cuarchive = db.Column(db.String(1), server_default=db.FetchedValue())
    cunbrecopiecube = db.Column(
        db.Float,
        server_default=db.FetchedValue(),
        info="Nombre de recopies de ce cube",
    )
    cuprofile = db.Column(
        db.Float, server_default=db.FetchedValue(), info="Profile de calcul",
    )
    cuutcstartcube = db.Column(
        db.DateTime,
        server_default=db.FetchedValue(),
        info="Timestamp utc de reception de la demande de cube",
    )
    cuutcstartsensi = db.Column(
        db.DateTime,
        server_default=db.FetchedValue(),
        info="Timestamp utc de reception de la demande de sensis",
    )
    cutype = db.Column(
        db.Float,
        nullable=False,
        server_default=db.FetchedValue(),
        info="Type de cube (0: full, 1:intraday)",
    )
    cuerrorcode = db.Column(
        db.Float, server_default=db.FetchedValue(), info="Code erreur du cube",
    )


class Echeancier(db.Model):
    __tablename__ = "echeancier"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    eccfin = db.Column(
        db.ForeignKey(Produit.prcfin, ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    ecdate = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Date de detachement des intérêts",
    )
    ecmontant = db.Column(db.Float, nullable=False, info="Montant des intérêts")
    ecremb = db.Column(db.Float, nullable=False, info="Montant du capital remboursé")
    ecanticipe = db.Column(db.String(1), info="Remboursement anticipe ou normal")
    ecisrembo = db.Column(
        db.Float,
        nullable=False,
        info="Titres initiaux dans la tranche d'amortissement",
    )
    eccurembo = db.Column(
        db.Float,
        nullable=False,
        info="Titres courants dans la tranche d'amortissement",
    )
    ecdateex = db.Column(db.DateTime, nullable=False, info="Date de détachement.")

    produit = db.relationship(
        Produit,
        primaryjoin="Echeancier.eccfin == Produit.prcfin",
        backref="echeanciers",
    )


class Basecc(db.Model):
    __tablename__ = "basecc"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    bacode = db.Column(
        db.Float,
        primary_key=True,
        info="Code de la convention de calcul du coupon couru",
    )
    banom = db.Column(
        db.String(15),
        nullable=False,
        info="Libellé de la convention de calcul du coupon couru",
    )


class Amort(Produit):
    __tablename__ = "amort"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("AMCFIN<>AMCODETAUX"),
        db.CheckConstraint("AMCFIN<>AMCODETAUX"),
        {"schema": "exane"},
    )

    amcfin = db.Column(
        db.ForeignKey(Produit.prcfin, ondelete="CASCADE"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    ambase = db.Column(
        db.ForeignKey(Basecc.bacode),
        nullable=False,
        index=True,
        info="Code de la convention de calcul du coupon couru",
    )
    amdev = db.Column(
        db.ForeignKey(Devise.dvcfin),
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    amcodetaux = db.Column(db.Float, index=True, info="Code de l'instrument financier")
    amtype = db.Column(
        db.String(1), nullable=False, info="Méthode d'amortissement utilisée"
    )
    amfreq = db.Column(
        db.String(1), nullable=False, info="Périodicité de détachement du coupon"
    )
    amfacial = db.Column(db.Float, info="Taux facial de l'emprunt")
    amclean = db.Column(
        db.String(1),
        nullable=False,
        info="Prix coté en pied de coupon ou coupon couru inclus",
    )
    amtypecc = db.Column(db.String(1), nullable=False, info="Type du premier coupon")
    amdebut = db.Column(db.DateTime, info="Date de paiement du premier coupon")
    amfin = db.Column(db.DateTime, info="Date de paiement du dernier coupon")
    amprepost = db.Column(
        db.String(1), nullable=False, info="Intérêts pré ou post-comptés"
    )
    ammargeadd = db.Column(db.Float, info="Marge additive")
    ammargemult = db.Column(db.Float, info="Marge multiplicative")
    amhorizon = db.Column(db.Float, info="Horizon\t")
    amcouponrule = db.Column(db.Float, info="Nb de jour avant paiement du coupon.")
    amcouponfixe = db.Column(db.Float, info="Montant fixe du coupon")

    basecc = db.relationship(
        "Basecc", primaryjoin="Amort.ambase == Basecc.bacode", backref="amorts"
    )
    devise = db.relationship(
        "Devise", primaryjoin="Amort.amdev == Devise.dvcfin", backref="amorts"
    )


class ContribInstrument(db.Model):
    __tablename__ = "contrib_instrument"
    __bind_key__ = "exane_contrib"
    __table_args__ = {"schema": "contribnext"}

    contribution_method = db.Column(db.String(255))
    discount = db.Column(db.Float)
    end_date = db.Column(db.DateTime)
    end_of_day_processing_active = db.Column(db.Float, nullable=False)
    position_cfin = db.Column(db.Float)
    pricing_method = db.Column(db.String(255))
    rubbish_ask = db.Column(db.Float, nullable=False)
    rubbish_bid = db.Column(db.Float, nullable=False)
    rubbish_spot = db.Column(db.Float, nullable=False)
    sold_out = db.Column(db.Float, nullable=False)
    start_date = db.Column(db.DateTime)
    status = db.Column(db.String(255))
    tempo = db.Column(db.Float, nullable=False)
    threshold = db.Column(db.String(255))
    instrument_cfin = db.Column(primary_key=True)
    pricing_profile_code = db.Column()


class IdxauditUdl(db.Model):
    __bind_key__ = "exane_analyse"
    __tablename__ = "idxaudit_udl"
    __table_args__ = {"schema": "derives"}

    idusessionid = db.Column()
    iducfin = db.Column(primary_key=True)
    iduvaluedate = db.Column(db.DateTime)
    iducfinssj = db.Column(db.Integer)
    iducoupon = db.Column()
    iducross = db.Column()
    iduspot = db.Column(db.Float)
    iduspotdate = db.Column(
        db.DateTime
    )  # Some AMC's components use the previous known close
    iduid = db.Column()
    idumarket = db.Column()


class Dividendes(db.Model):
    __tablename__ = "dividende"
    __table_args__ = {"schema": "exane"}

    dicfin = db.Column(primary_key=True)
    didate = db.Column(db.DateTime)
    dimontant = db.Column(db.Float)


if __name__ == "__main__":
    from app import server
    import pandas as pd
    from utils.basics import prev_bday

    pd.options.display.width = 800
    pd.set_option("max_rows", 35)
    pd.set_option("max_columns", 15)

    from sqlalchemy import func

    # Get types from DB
    with server.app_context():

        x = (
            db.session.query(
                Rkpricing.prprofil,
                Rkpricing.prparent,
                Instrument.ifnom,
                Rkpricingresultat.praxe1,
                Rkpricingresultat.prindicateur,
                Rkpricingresultat.prvaleur,
                Emission.emnominal,
            )
            .select_from(Rkpricingresultat)
            .join(
                (Rkpricing, Rkpricing.prnumero == Rkpricingresultat.prnumero),
                (Instrument, Instrument.ifcfin == Rkpricing.prparent),
                (Emission, Emission.emcfin == Instrument.ifcfin),
            )
            .filter(
                Rkpricingresultat.prflag != 3,
                Rkpricingresultat.prmode == 0,
                Rkpricingresultat.prprofil.in_([93, 63, 142, 99, 246, 247, 249, 347]),
                Rkpricingresultat.prindicateur == 3,
                Rkpricingresultat.prparent == Rkpricingresultat.prcfin,
                Rkpricingresultat.prparent != Rkpricingresultat.praxe1,
                func.substr(Instrument.ifnom, 1, 4) not in ["Swap", "swap"],
                Rkpricingresultat.prdate == prev_bday(1),
                Rkpricingresultat.praxe1 == 42829366,
            )
            .all()
        )

        for y in x:
            print(y.instrument.ifnom)

        test = Produit.query.filter_by(prcfin=45088035).first()
        print(Instrument.query.filter_by(ifcfin=45088035).first().statut)

#     #     df = pd.read_clipboard()
#     #     cfins = list(df["ALSJAC"])
#     #
#     #     result = (
#     #         db.session.query(
#     #             Produits.prcfin.label("cfin"),
#     #             Modecot.monom.label("mode_cot"),
#     #             Marche.manom.label("marche_place"),
#     #             Devise.dvcodeiso.label("devise"),
#     #             Emission.emnominal.label("nominal"),
#     #         )
#     #         .join(
#     #             (Modecot, Modecot.mocode == Produits.prmodecot),
#     #             (Devise, Devise.dvcfin == Produits.prdev),
#     #             (Emission, Emission.emcfin == Produits.prcfin),
#     #             (Marche, Marche.macode == Produits.prmarche),
#     #         )
#     #         .filter(Produits.prcfin.in_(cfins))
#     #     )
#     #
#     #     df_result = pd.DataFrame(result)
#     #     df_result.to_clipboard()
#     #
#     #     print("test")
#
#     # Get types from DB
#     with server.app_context():
#
#         sub_cfins = db.session.query(Afhistoopinionvaleur.hovcfin).distinct().subquery()
#
#         result = (
#             db.session.query(
#                 Instruments.ifcfin.label("cfin"),
#                 Instruments.ifnom.label("name"),
#                 Devise.dvcodeiso.label("currency"),
#                 Codes.cfcode.label("bbg_ticker"),
#                 Collection.cldatein.label("sector_date_in"),
#                 Collection.cldateout.label("sector_date_out"),
#                 Afratioshisto.rhdate.label("date"),
#                 Afratioshisto.rhcapi.label("capi"),
#                 Afratioshisto.rhnbtitresreelfinexe.label("free_float"),
#                 Afhistoopinionvaleur.hovnewopinion.label("reco_value"),
#                 Afhistoobjectifcours.ocobjectif.label("obj_12m_value"),
#                 Afhistoobjectifcours.ocupside.label("obj_12m_perf"),
#                 Afhistoobjectifcours.socoeff.label("obj_12m_perf_coeff"),
#                 Historiques.hoclose.label("close"),
#             )
#             .join(
#                 (Produits, Produits.prcfin == Instruments.ifcfin),
#                 (Devise, Devise.dvcfin == Produits.prdev),
#                 (
#                     Collection,
#                     and_(
#                         Collection.clsjac == Instruments.ifcfin,
#                         Collection.clcollect == 103853,  # Sector MedTech
#                         Collection.cldateout
#                         >= dt(2000, 1, 1),  # Backtest starts Jan 1st, 2020
#                     ),
#                 ),
#                 (Afsecteur, Afsecteur.secfin == Collection.clcollect),
#                 (
#                     Afratioshisto,
#                     and_(
#                         Afratioshisto.rhcfin == Instruments.ifcfin,
#                         # Afratioshisto.rhdate >= Collection.cldatein,
#                         Afratioshisto.rhdate <= Collection.cldateout,
#                         Afratioshisto.rhexefiscal
#                         == extract("year", Afratioshisto.rhdate),
#                     ),
#                 ),
#                 (
#                     Codes,
#                     and_(
#                         Codes.cfcfin == Instruments.ifcfin,
#                         Codes.cfsource == 11,
#                         Codes.cftype == 1,
#                     ),
#                 ),
#             )
#             .outerjoin(
#                 (
#                     Afhistoopinionvaleur,
#                     and_(
#                         Afhistoopinionvaleur.hovcfin == Instruments.ifcfin,
#                         Afhistoopinionvaleur.hovdate == Afratioshisto.rhdate,
#                     ),
#                 ),
#                 (
#                     Afhistoobjectifcours,
#                     and_(
#                         Afhistoobjectifcours.occfin == Instruments.ifcfin,
#                         Afhistoobjectifcours.ocdatemodif == Afratioshisto.rhdate,
#                     ),
#                 ),
#                 (
#                     Historiques,
#                     and_(
#                         Historiques.hocfin == Instruments.ifcfin,
#                         Historiques.hodate == Afratioshisto.rhdate,
#                     ),
#                 ),
#             )
#             .filter(
#                 Instruments.ifcfin == sub_cfins.c.hovcfin,
#                 # Instruments.ifcfin == 452866,
#                 # Instruments.ifcfin.in_([100424, 18206617]),
#             )
#         )
#
#         df = pd.DataFrame(result)
#         df = df.sort_values(by=["cfin", "date", "sector_date_in"])
#
#         # Drop LivaNova PLC UK 17858037
#         df = df[df.cfin != 17858037]
#
#         # Drop Old Fresenius 100424
#         df = df[df.cfin != 100424]
#
#         # Drop sector_date_in if appears twice, example for 18206617 LivaNova PLC (US)
#         df = df.drop_duplicates(subset=["cfin", "date"], keep="first")
#         df.loc[:, "sector_date_in"] = df.groupby("cfin")["sector_date_in"].transform(
#             min
#         )
#
#         df.loc[:, "reco_value"] = df.groupby("cfin")["reco_value"].transform(
#             lambda group: group.ffill()
#         )
#         df.loc[:, "obj_12m_value"] = df.groupby("cfin")["obj_12m_value"].transform(
#             lambda group: group.ffill()
#         )
#         df.loc[:, "obj_12m_perf_coeff"] = df.groupby("cfin")[
#             "obj_12m_perf_coeff"
#         ].transform(lambda group: group.ffill())
#
#         df["obj_12m_value"] = df["obj_12m_value"] * df["obj_12m_perf_coeff"]
#
#         df = df.sort_values(by=["cfin", "date"])
#
#         # Define closing levels
#         # df['close'] = (df.capi * 1000000 / df.free_float).shift(-1)
#
#         df["shift_close"] = df["close"].shift(1)
#         dico_fx = {"GBP": 100}
#         df["shift_close"] = df.apply(
#             lambda x: x.shift_close * dico_fx.get(x.currency, 1), axis=1
#         )
#
#         df["obj_12m_perf"] = df.apply(
#             lambda x: x.obj_12m_perf / 100.0
#             if not pd.isnull(x.obj_12m_perf)
#             else x.obj_12m_value / x.shift_close - 1,
#             axis=1,
#         )
#
#         df = df.drop(columns="shift_close")
#
#         df = df[df.date >= df.sector_date_in]
#
#         dff = pd.pivot_table(
#             df,
#             values=[
#                 "reco_value",
#                 "obj_12m_value",
#                 "obj_12m_perf",
#                 "capi",
#                 "free_float",
#                 "close",
#             ],
#             index="date",
#             columns=[
#                 "cfin",
#                 "name",
#                 "currency",
#                 "bbg_ticker",
#                 "sector_date_in",
#                 "sector_date_out",
#             ],
#         )
#         # print(dff.info())
#         dff.to_clipboard()
#
#         dff.to_pickle("data_medtech.pickle")
#
#     with server.app_context():
#         r = ExternalInstrument.query.all()
#         all_cfins_contributing = [x.instrument_cfin for x in r]
#         issues = {}
#         for cfin in all_cfins_contributing:
#             r_hist = db.session.query(
#                 Histo.hodate.label("date"), Histo.hoclose.label("close_histo")
#             ).filter(Histo.hocfin == cfin)
#             df_hist = pd.DataFrame(r_hist)
#
#             r_reuters = db.session.query(
#                 ExternalInstrumentClose.timestamp.label("date"),
#                 ExternalInstrumentClose.last.label("close_reuters"),
#             ).filter(ExternalInstrumentClose.cfin == cfin)
#             df_reut = pd.DataFrame(r_reuters)
#
#             name = (
#                 db.session.query(Instruments.ifnom)
#                 .filter(Instruments.ifcfin == cfin)
#                 .all()[0][0]
#             )
#
#             try:
#                 max_val_hist = max(df_hist.close_histo.value_counts())
#                 max_val_reuters = max(df_reut.close_reuters.value_counts())
#
#                 maxi = max(max_val_hist, max_val_reuters)
#
#                 statut = (
#                     db.session.query(Instrumentcomplement.icetatdevie)
#                     .filter(Instrumentcomplement.iccfin == cfin)
#                     .all()[0][0]
#                 )
#
#                 if max_val_reuters > 4:
#                     issues[cfin] = [maxi, name, statut]
#
#             except Exception as e:
#
#                 print(cfin)
#                 print(name)
#
#     def display_columns_table(tbl_name):
#         [
#             print(
#                 f'{k.name} = db.Column(db.{"Integer" if "NUMBER" in str(k.type) else k.type})'
#             )
#             for k in eval(f"Base.classes.{tbl_name}.__table__.columns")
#         ]
#
#     cfins = [
#         38831883,
#         38553946,
#         38553609,
#         38554018,
#         38573468,
#         38617625,
#         38635665,
#     ]
#
#     result = db.session.query(
#         Last.lacfin, Last.ladate, Last.labid, Last.ladatepr, Last.labidpr,
#     ).filter(Last.lacfin.in_(cfins))
#     df = pd.DataFrame(result)
#     print(df)

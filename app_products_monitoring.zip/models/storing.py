from utils import sql
import pandas as pd
from app import app, cache
from utils.sql import (
    trades,
    trades_and_products,
    products_histo,
    app_products,
    contribution_issues,
    opinions_stocks,
)
from utils.api_open_positions import OpenPositions
from utils.basics import *


@cache.cached(timeout=0, key_prefix="trades_products")
def cached_trades_and_products():
    app.logger.info("Reloading Trades & Products data")
    start_date = dt(2018, 1, 1)
    end_date = dt_today()
    return trades_and_products(start_date, end_date)


@cache.cached(timeout=0, key_prefix="ytd_trades")
def cached_ytd_trades():
    beginning_of_the_year = dt(2021, 1, 1).date()
    today = dt.today().date()
    return trades(beginning_of_the_year, today)


@cache.cached(timeout=0, key_prefix="products")
def cached_all_products():
    return app_products()


@cache.cached(timeout=3600, key_prefix="contrib")
def cached_data_missing_contrib():
    app.logger.info("Reloading Contribution Issues data")
    return contribution_issues(format="dict")


@cache.memoize(timeout=86400)
def cached_opinions_stocks():
    return opinions_stocks()


@cache.memoize(timeout=86400)
def cached_products_histo():
    return products_histo()


# @cache.cached(timeout=0, key_prefix="all_accounts")
# def cached_all_accounts():
#     op = OpenPositions()
#     app.logger.info("Getting all accounts")
#     return op.all_accounts_and_contacts()


def primary_trades(df, nb_trades=None):
    dff = (
        df[df["is_primary"]][
            [
                "issuer",
                "cfin",
                "isin",
                "initial_date",
                "sales",
                "name",
                "type_order",
                "currency",
                "maturity_date",
                "margin",
                "cash_traded",
                "size_traded",
            ]
        ]
        .groupby(
            [
                "cfin",
                "isin",
                "initial_date",
                "maturity_date",
                "issuer",
                "name",
                "sales",
                "type_order",
                "currency",
            ],
            observed=True,
        )
        .agg(
            nb_trade=("margin", "count"),
            margin=("margin", "sum"),
            cash_traded=("cash_traded", "sum"),
            size_traded=("size_traded", "sum"),
        )
        .reset_index()
        .sort_values("margin", ascending=False)
    )
    dff["L"] = ""
    dff["TS"] = ""
    dff = dff[
        [
            "L",
            "TS",
            "cfin",
            "isin",
            "initial_date",
            "maturity_date",
            "issuer",
            "name",
            "sales",
            "type_order",
            "nb_trade",
            "currency",
            "margin",
            "cash_traded",
            "size_traded",
        ]
    ]
    dff.columns = [
        "L",
        "TS",
        "Cfin",
        "ISIN",
        "Initial Date",
        "Maturity",
        "Issuer",
        "Name",
        "Sales",
        "Type",
        "Nb Trd",
        "Ccy",
        "Margin",
        "Cash Traded",
        "Size Traded",
    ]

    if nb_trades:
        dff = dff.head(nb_trades)

    return dff.to_dict("records")


def secondary_sales(df, nb_trades=None):

    dff = (
        df[~df["is_primary"]][
            [
                "issuer",
                "cfin",
                "isin",
                "initial_date",
                "maturity_date",
                "sales",
                "type_order",
                "name",
                "currency",
                "margin",
                "cash_traded",
                "size_traded",
            ]
        ]
        .groupby(
            [
                "cfin",
                "isin",
                "initial_date",
                "maturity_date",
                "issuer",
                "name",
                "sales",
                "type_order",
                "currency",
            ],
            observed=True,
        )
        .agg(
            nb_trade=("margin", "count"),
            margin=("margin", "sum"),
            size_traded=("size_traded", "sum"),
            cash_traded=("cash_traded", "sum"),
        )
        .reset_index()
        .sort_values("margin", ascending=False)
    )
    dff = dff[dff["margin"] > 0]
    dff["L"] = ""
    dff["TS"] = ""
    dff = dff[
        [
            "L",
            "TS",
            "cfin",
            "isin",
            "initial_date",
            "maturity_date",
            "issuer",
            "name",
            "sales",
            "type_order",
            "nb_trade",
            "currency",
            "margin",
            "cash_traded",
            "size_traded",
        ]
    ]
    dff.columns = [
        "L",
        "TS",
        "Cfin",
        "ISIN",
        "Initial Date",
        "Maturity",
        "Issuer",
        "Name",
        "Sales",
        "Type",
        "Nb Trd",
        "Ccy",
        "Margin",
        "Cash Traded",
        "Size Traded",
    ]

    if nb_trades:
        dff = dff.head(nb_trades)

    return dff.to_dict("records")


def losing_trades(df, nb_trades=None):
    dff = (
        df[
            [
                "issuer",
                "cfin",
                "isin",
                "initial_date",
                "maturity_date",
                "sales",
                "name",
                "type_order",
                "currency",
                # "maturity_date",
                "margin",
                "cash_traded",
                "size_traded",
            ]
        ]
        .groupby(
            [
                "cfin",
                "isin",
                "initial_date",
                "maturity_date",
                "issuer",
                "name",
                "sales",
                "type_order",
                "currency",
            ],
            observed=True,
        )
        .agg(
            nb_trade=("margin", "count"),
            margin=("margin", "sum"),
            cash_traded=("cash_traded", "sum"),
            size_traded=("size_traded", "sum"),
        )
        .reset_index()
        .sort_values("margin", ascending=True)
    )
    dff = dff[dff["margin"] < 0]
    dff["L"] = ""
    dff["TS"] = ""
    dff = dff[
        [
            "L",
            "TS",
            "cfin",
            "isin",
            "initial_date",
            "maturity_date",
            "issuer",
            "name",
            "sales",
            "type_order",
            "nb_trade",
            "currency",
            "margin",
            "cash_traded",
            "size_traded",
        ]
    ]
    dff.columns = [
        "L",
        "TS",
        "Cfin",
        "ISIN",
        "Initial Date",
        "Maturity",
        "Issuer",
        "Name",
        "Sales",
        "Type",
        "Nb Trd",
        "Ccy",
        "Margin",
        "Cash Traded",
        "Size Traded",
    ]

    if nb_trades:
        dff = dff.head(nb_trades)

    return dff.to_dict("records")

# coding: utf-8
from local_db_mgt import db


class BactionOld(db.Model):
    __tablename__ = "baction_old"
    __table_args__ = {"schema": "derives"}

    accfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    acdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    acnom = db.Column(db.String(60))
    acmktcap = db.Column(db.Numeric(18, 2))
    acrdtnetdiv_last = db.Column(db.Numeric(13, 5))
    acrdtafdiv_last = db.Column(db.Numeric(13, 5))
    acrdtnetdiv_next = db.Column(db.Numeric(13, 5))
    acrdtafdiv_next = db.Column(db.Numeric(13, 5))
    accodesect = db.Column(db.ForeignKey("exane.secteur.secode"))
    acnote_rsk = db.Column(db.String(4))
    acdate_lastoff = db.Column(db.DateTime)
    acdate_nextest = db.Column(db.DateTime)
    acdate_modif = db.Column(db.DateTime)
    acnb_est = db.Column(db.Numeric(10, 0, asdecimal=False))
    acflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="BactionOld.accfin == Instrument.ifcfin",
        backref="baction_olds",
    )
    secteur = db.relationship(
        "Secteur",
        primaryjoin="BactionOld.accodesect == Secteur.secode",
        backref="baction_olds",
    )


class Bbtsaudit(db.Model):
    __tablename__ = "bbtsaudit"
    __table_args__ = {"schema": "derives"}

    tsacfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        info="cfin",
    )
    tsadate = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Horodate de l envoie de la termsheet a bloomberg",
    )
    tsastatut = db.Column(db.Numeric(3, 0, asdecimal=False), info="Statut de reception")
    tsautilisateur = db.Column(
        db.String(64), info="Nom de l utilisateur qui a envoye la TS"
    )
    tsafichier = db.Column(db.String(128), info="Nom du fichier envoye a BB")
    tsacommentaire = db.Column(db.String(256), info="Commentaire")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Bbtsaudit.tsacfin == Instrument.ifcfin",
        backref="bbtsaudits",
    )


class Bcaspcommun(db.Model):
    __tablename__ = "bcaspcommun"
    __table_args__ = (
        db.CheckConstraint("CCMODEUT IN ('V','T')"),
        db.CheckConstraint("CCSOURCE IN ('T','S','C')"),
        {"schema": "derives"},
    )

    cccfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    ccmodeut = db.Column(
        db.String(1), primary_key=True, nullable=False, info="Vente,Trading"
    )
    ccprofilgcp = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Profil Gestion Centralisée des Paramètres",
    )
    cctypepricer = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Constante Casper : ServiceValorisation::PR_STANDARD,PR_BLACK,PR_EDP,PR_FAST_MC,PR_SLOW_MC,PR_EXTENDED,...",
    )
    ccsource = db.Column(
        db.String(1), primary_key=True, nullable=False, info="Type,Sous-type,Collection"
    )
    cctype = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="code correspondant par rapport à la colonne CCSOURCE",
    )
    ccdate = db.Column(db.DateTime)
    ccrcprice = db.Column(db.Numeric(13, 5))
    ccrccotation = db.Column(db.Numeric(13, 5))
    ccrccotationri = db.Column(db.Numeric(13, 5))
    ccmodecotation = db.Column(db.Numeric(2, 0, asdecimal=False))
    ccrcvolimp = db.Column(db.Numeric(10, 5))
    ccrcytm = db.Column(db.Numeric(13, 5))
    ccrcaccrinterest = db.Column(db.Numeric(13, 5))
    ccrcbondfloor = db.Column(db.Numeric(13, 5))
    ccrcconvpremium = db.Column(db.Numeric(13, 5))
    ccrcduration = db.Column(db.Numeric(13, 5))
    ccrctheta = db.Column(db.Numeric(13, 5))
    ccrcthetabe = db.Column(db.Numeric(13, 5))
    ccrcmcerror = db.Column(db.Numeric(13, 5))
    ccflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cczerocoupon = db.Column(db.Numeric(13, 5))
    ccrctotaldelta = db.Column(db.Numeric(13, 5))
    ccrctotalgamma = db.Column(db.Numeric(13, 5))
    ccrcfullvega = db.Column(db.Numeric(13, 5))
    ccrctotaldeltaeur = db.Column(db.Numeric(13, 5), info="Total delta en euro")
    ccrctotalgammaeur = db.Column(db.Numeric(13, 5), info="Total Gamma en euro")
    ccrcfullvegaeur = db.Column(db.Numeric(13, 5), info="Full Vega en euro")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Bcaspcommun.cccfin == Instrument.ifcfin",
        backref="bcaspcommuns",
    )


class Bcaspcompo(db.Model):
    __tablename__ = "bcaspcompo"
    __table_args__ = (
        db.CheckConstraint("COMODEUT IN ('V','T')"),
        db.CheckConstraint("COSOURCE IN ('T','S','C')"),
        {"schema": "derives"},
    )

    cocfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    comodeut = db.Column(
        db.String(1), primary_key=True, nullable=False, info="Vente,Trading"
    )
    coprofilgcp = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Profil Gestion Centralisée des Paramètres",
    )
    cotypepricer = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Constante Casper : ServiceValorisation::PR_STANDARD,PR_BLACK,PR_EDP,PR_FAST_MC,PR_SLOW_MC,PR_EXTENDED,...",
    )
    cosource = db.Column(
        db.String(1), primary_key=True, nullable=False, info="Type,Sous-type,Collection"
    )
    cotype = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="code correspondant par rapport à la colonne COSOURCE",
    )
    cocfincompo = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    codate = db.Column(db.DateTime)
    cocompoqty = db.Column(db.Numeric(24, 15))
    cocompovalo = db.Column(db.Numeric(13, 5))
    coflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Bcaspcompo.cocfin == Instrument.ifcfin",
        backref="bcaspcompoes",
    )


class Bcaspemetteur(db.Model):
    __tablename__ = "bcaspemetteur"
    __table_args__ = (
        db.CheckConstraint("CEMODEUT IN ('V','T')"),
        db.CheckConstraint("CESOURCE IN ('T','S','C')"),
        db.CheckConstraint("CETYPERECOVERY IN ('S','P')"),
        {"schema": "derives"},
    )

    cecfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    cemodeut = db.Column(
        db.String(1), primary_key=True, nullable=False, info="Vente,Trading"
    )
    ceprofilgcp = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Profil Gestion Centralisée des Paramètres",
    )
    cetypepricer = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Constante Casper : ServiceValorisation::PR_STANDARD,PR_BLACK,PR_EDP,PR_FAST_MC,PR_SLOW_MC,PR_EXTENDED,...",
    )
    cesource = db.Column(
        db.String(1), primary_key=True, nullable=False, info="Type,Sous-type,Collection"
    )
    cetype = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="code correspondant par rapport à la colonne CESOURCE",
    )
    cecfinact = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="cfin de l'action de l'emetteur",
    )
    cedate = db.Column(db.DateTime)
    cetiers = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="code tiers de l'emetteur du produit"
    )
    cercdefaultsensi = db.Column(db.Numeric(13, 5))
    cetyperecovery = db.Column(db.String(1))
    cespread = db.Column(db.Numeric(13, 5))
    ceprobadefaut = db.Column(db.Numeric(13, 5))
    cerecoverycode = db.Column(db.Numeric(8, 0, asdecimal=False))
    cerecoveryvalue = db.Column(db.Numeric(13, 5))
    ceflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Bcaspemetteur.cecfin == Instrument.ifcfin",
        backref="bcaspemetteurs",
    )


class Bcaspsj(db.Model):
    __tablename__ = "bcaspsj"
    __table_args__ = (
        db.CheckConstraint("CJMODEUT IN ('V','T')"),
        db.CheckConstraint("CJSOURCE IN ('T','S','C')"),
        {"schema": "derives"},
    )

    cjcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    cjmodeut = db.Column(
        db.String(1), primary_key=True, nullable=False, info="Vente,Trading"
    )
    cjprofilgcp = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Profil Gestion Centralisée des Paramètres",
    )
    cjtypepricer = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Constante Casper : ServiceValorisation::PR_STANDARD,PR_BLACK,PR_EDP,PR_FAST_MC,PR_SLOW_MC,PR_EXTENDED,...",
    )
    cjsource = db.Column(
        db.String(1), primary_key=True, nullable=False, info="Type,Sous-type,Collection"
    )
    cjtype = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="code correspondant par rapport à la colonne CJSOURCE",
    )
    cjcfinsj = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cjdate = db.Column(db.DateTime)
    cjdevsj = db.Column(db.Numeric(8, 0, asdecimal=False))
    cjrcvolatility = db.Column(db.Numeric(10, 5))
    cjrcspot = db.Column(db.Numeric(13, 5))
    cjrcdelta = db.Column(db.Numeric(13, 5))
    cjrcdeltanorme = db.Column(db.Numeric(13, 5))
    cjrcgamma = db.Column(db.Numeric(13, 5))
    cjrcvega = db.Column(db.Numeric(13, 5))
    cjrcvegaweighed = db.Column(db.Numeric(13, 5))
    cjrcsega = db.Column(db.Numeric(13, 5))
    cjflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cjdeltapct = db.Column(db.Numeric(13, 5))
    cjrcvegapdpct = db.Column(
        db.Numeric(13, 5),
        info="vega normé en devise du produit = (CJRCVEGA / EMnominal) * 100 ",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Bcaspsj.cjcfin == Instrument.ifcfin",
        backref="bcaspsjs",
    )


class Bcasptaux(db.Model):
    __tablename__ = "bcasptaux"
    __table_args__ = (
        db.CheckConstraint("CTMODEUT IN ('V','T')"),
        db.CheckConstraint("CTSOURCE IN ('T','S','C')"),
        {"schema": "derives"},
    )

    ctcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    ctmodeut = db.Column(
        db.String(1), primary_key=True, nullable=False, info="Vente,Trading"
    )
    ctprofilgcp = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Profil Gestion Centralisée des Paramètres",
    )
    cttypepricer = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Constante Casper : ServiceValorisation::PR_STANDARD,PR_BLACK,PR_EDP,PR_FAST_MC,PR_SLOW_MC,PR_EXTENDED,...",
    )
    ctsource = db.Column(
        db.String(1), primary_key=True, nullable=False, info="Type,Sous-type,Collection"
    )
    cttype = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="code correspondant par rapport à la colonne CTSOURCE",
    )
    ctdev = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ctdate = db.Column(db.DateTime)
    ctrcfxsensi = db.Column(db.Numeric(13, 5))
    ctrcrho = db.Column(db.Numeric(13, 5))
    ctflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ctrcrhopdpct = db.Column(
        db.Numeric(13, 5),
        info="rho norm¿ = (rho en devise du produit / EMnominal) * 100 ",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Bcasptaux.ctcfin == Instrument.ifcfin",
        backref="bcasptauxes",
    )


class Bconvert(db.Model):
    __tablename__ = "bconvert"
    __table_args__ = {"schema": "derives"}

    cvcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    cvdate = db.Column(db.DateTime, nullable=False)
    cvnom = db.Column(db.String(60))
    cvsjac = db.Column(db.ForeignKey("exane.instruments.ifcfin"), index=True)
    cvmktcapini = db.Column(db.Numeric(18, 2))
    cvmktcap = db.Column(db.Numeric(18, 2))
    cvmktcapsj = db.Column(db.Numeric(18, 2))
    cvcall = db.Column(db.Numeric(13, 5))
    cvdatedebcall = db.Column(db.DateTime)
    cvdatefincall = db.Column(db.DateTime)
    cvtriggercall = db.Column(db.Numeric(13, 5))
    cvcroisstrig = db.Column(db.Numeric(13, 5))
    cvnominal = db.Column(db.Numeric(13, 5))
    cvput = db.Column(db.Numeric(13, 5))
    cvdatedebput = db.Column(db.DateTime)
    cvdaterembo = db.Column(db.DateTime)
    cvprimerembo = db.Column(db.Numeric(13, 5))
    cvsj = db.Column(db.Numeric(13, 5))
    cvdr = db.Column(db.Numeric(13, 5))
    cvcoupcouru = db.Column(db.Numeric(13, 5))
    cvprixpiedcoup = db.Column(db.Numeric(13, 5))
    cvduration = db.Column(db.Numeric(13, 5))
    cvdureevie = db.Column(db.Numeric(13, 5))
    cvpayback = db.Column(db.Numeric(13, 5))
    cvsproat = db.Column(db.Numeric(13, 5))
    cvrdtcall = db.Column(db.Numeric(13, 5))
    cvrdtput = db.Column(db.Numeric(13, 5))
    cvrdtmaturite = db.Column(db.Numeric(13, 5))
    cvrdtcourant = db.Column(db.Numeric(13, 5))
    cvprimebrute = db.Column(db.Numeric(13, 5))
    cvprimebrutea = db.Column(db.Numeric(13, 5))
    cvprimenette = db.Column(db.Numeric(13, 5))
    cvprimenettea = db.Column(db.Numeric(13, 5))
    cvvalactuflat = db.Column(db.Numeric(13, 5))
    cvvalactuptb = db.Column(db.Numeric(13, 5))
    cvbaisseflat = db.Column(db.Numeric(13, 5))
    cvbaisseptb = db.Column(db.Numeric(13, 5))
    cvdelta = db.Column(db.Numeric(13, 5))
    cvdeltanorme = db.Column(db.Numeric(13, 5))
    cvndelta = db.Column(db.String(1))
    cvrho = db.Column(db.Numeric(13, 5))
    cvnrho = db.Column(db.String(1))
    cvvaltheo = db.Column(db.Numeric(13, 5))
    cvnvaltheo = db.Column(db.String(1))
    cvdecote = db.Column(db.Numeric(13, 5))
    cvdw20 = db.Column(db.Numeric(13, 5))
    cvdw10 = db.Column(db.Numeric(13, 5))
    cvup10 = db.Column(db.Numeric(13, 5))
    cvup20 = db.Column(db.Numeric(13, 5))
    cvdw20pb = db.Column(db.Numeric(13, 5))
    cvdw10pb = db.Column(db.Numeric(13, 5))
    cvup10pb = db.Column(db.Numeric(13, 5))
    cvup20pb = db.Column(db.Numeric(13, 5))
    cvnote_spr = db.Column(db.String(32))
    cvnote_div = db.Column(db.String(1))
    cvnote_vol = db.Column(db.String(1))
    cvnote_rsk = db.Column(db.String(1))
    cvspr_ex = db.Column(db.Numeric(13, 5))
    cvcrdiv_ex = db.Column(db.Numeric(13, 5))
    cvvol_ex = db.Column(db.Numeric(13, 5))
    cvvolmax_ex = db.Column(db.Numeric(13, 5))
    cvtauxref = db.Column(db.Numeric(13, 5))
    cvmatref = db.Column(db.Numeric(13, 5))
    cvvega = db.Column(db.Numeric(13, 5))
    cvnvega = db.Column(db.String(1))
    cvrkqds = db.Column(db.Numeric(13, 5))
    cvnrkqds = db.Column(db.String(1))
    cvrkdiv = db.Column(db.Numeric(13, 5))
    cvnrkdiv = db.Column(db.String(1))
    cvsynthese = db.Column(db.Numeric(2, 0, asdecimal=False))
    cvflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cvdirtyvalue = db.Column(db.Numeric(13, 5))
    cvtheta = db.Column(db.Numeric(13, 5))
    cvntheta = db.Column(db.String(1))
    cvtemp = db.Column(db.Numeric(13, 5))
    cvvactptbmatu = db.Column(db.Numeric(13, 5))
    cvbaisseptbmatu = db.Column(db.Numeric(13, 5))
    cvdurationput = db.Column(db.Numeric(13, 5))
    cvvactptbput = db.Column(db.Numeric(13, 5))
    cvbaisseptbput = db.Column(db.Numeric(13, 5))
    cvsprput = db.Column(db.Numeric(13, 5))
    cvtauxput = db.Column(db.Numeric(13, 5))
    cvvaltheoput = db.Column(db.Numeric(13, 5))
    cvtempput = db.Column(db.Numeric(13, 5))
    cvdeltaput = db.Column(db.Numeric(13, 5))
    cvdeltanormeput = db.Column(db.Numeric(13, 5))
    cvvegaput = db.Column(db.Numeric(13, 5))
    cvthetaput = db.Column(db.Numeric(13, 5))
    cvrhoput = db.Column(db.Numeric(13, 5))
    cvdw20put = db.Column(db.Numeric(13, 5))
    cvdw10put = db.Column(db.Numeric(13, 5))
    cvup10put = db.Column(db.Numeric(13, 5))
    cvup20put = db.Column(db.Numeric(13, 5))
    cvgamma = db.Column(db.Numeric(13, 5))
    cvgammaput = db.Column(db.Numeric(13, 5))
    cvrkqdsput = db.Column(db.Numeric(13, 5))
    cvspreadimp = db.Column(db.Numeric(13, 5))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Bconvert.cvcfin == Instrument.ifcfin",
        backref="instrument_bconverts",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Bconvert.cvsjac == Instrument.ifcfin",
        backref="instrument_bconverts_0",
    )


class Bconvertible(db.Model):
    __tablename__ = "bconvertible"
    __table_args__ = {"schema": "derives"}

    cvcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cvdate = db.Column(db.DateTime, nullable=False)
    cvnom = db.Column(db.String(60), nullable=False)
    cvsjac = db.Column(db.Numeric(8, 0, asdecimal=False))
    cvmktcapini = db.Column(db.Numeric(18, 2))
    cvmktcap = db.Column(db.Numeric(18, 2))
    cvmktcapsj = db.Column(db.Numeric(18, 2))
    cvcall = db.Column(db.Numeric(13, 5))
    cvdatedebcall = db.Column(db.DateTime)
    cvdatefincall = db.Column(db.DateTime)
    cvtriggercall = db.Column(db.Numeric(13, 5))
    cvcroisstrig = db.Column(db.Numeric(13, 5))
    cvnominal = db.Column(db.Numeric(18, 5))
    cvput = db.Column(db.Numeric(13, 5))
    cvdatedebput = db.Column(db.DateTime)
    cvdaterembo = db.Column(db.DateTime)
    cvprimerembo = db.Column(db.Numeric(13, 5))
    cvsj = db.Column(db.Numeric(13, 5))
    cvdr = db.Column(db.Numeric(13, 5))
    cvcoupcouru = db.Column(db.Numeric(13, 5))
    cvprixpiedcoup = db.Column(db.Numeric(13, 5))
    cvduration = db.Column(db.Numeric(13, 5))
    cvdurationcorr = db.Column(db.Numeric(13, 5))
    cvdureevie = db.Column(db.Numeric(13, 5))
    cvpayback = db.Column(db.Numeric(13, 5))
    cvsproat = db.Column(db.Numeric(13, 5))
    cvrdtcall = db.Column(db.Numeric(13, 5))
    cvrdtput = db.Column(db.Numeric(13, 5))
    cvrdtmaturite = db.Column(db.Numeric(13, 5))
    cvrdtcourant = db.Column(db.Numeric(13, 5))
    cvprimebrute = db.Column(db.Numeric(13, 5))
    cvprimebrutea = db.Column(db.Numeric(13, 5))
    cvprimenette = db.Column(db.Numeric(13, 5))
    cvprimenettea = db.Column(db.Numeric(13, 5))
    cvvalactuflat = db.Column(db.Numeric(13, 5))
    cvvalactuptb = db.Column(db.Numeric(13, 5))
    cvbaisseflat = db.Column(db.Numeric(13, 5))
    cvbaisseptb = db.Column(db.Numeric(13, 5))
    cvdelta = db.Column(db.Numeric(13, 5))
    cvdeltanorme = db.Column(db.Numeric(13, 5))
    cvdeltacall = db.Column(db.Numeric(13, 5))
    cvndelta = db.Column(db.String(1))
    cvrho = db.Column(db.Numeric(13, 5))
    cvnrho = db.Column(db.String(1))
    cvvaltheo = db.Column(db.Numeric(13, 5))
    cvnvaltheo = db.Column(db.String(1))
    cvdecote = db.Column(db.Numeric(13, 5))
    cvdw20 = db.Column(db.Numeric(13, 5))
    cvdw10 = db.Column(db.Numeric(13, 5))
    cvup10 = db.Column(db.Numeric(13, 5))
    cvup20 = db.Column(db.Numeric(13, 5))
    cvdw20pb = db.Column(db.Numeric(13, 5))
    cvdw10pb = db.Column(db.Numeric(13, 5))
    cvup10pb = db.Column(db.Numeric(13, 5))
    cvup20pb = db.Column(db.Numeric(13, 5))
    cvnote_spr = db.Column(db.String(32))
    cvnote_div = db.Column(db.String(1))
    cvnote_vol = db.Column(db.String(1))
    cvnote_rsk = db.Column(db.String(1))
    cvspr_ex = db.Column(db.Numeric(13, 5))
    cvcrdiv_ex = db.Column(db.Numeric(13, 5))
    cvvol_ex = db.Column(db.Numeric(13, 5))
    cvvolmax_ex = db.Column(db.Numeric(13, 5))
    cvtauxref = db.Column(db.Numeric(13, 5))
    cvmatref = db.Column(db.Numeric(13, 5))
    cvvega = db.Column(db.Numeric(13, 5))
    cvnvega = db.Column(db.String(1))
    cvvegapct = db.Column(db.Numeric(13, 5))
    cvrkqds = db.Column(db.Numeric(13, 5))
    cvnrkqds = db.Column(db.String(1))
    cvrkdiv = db.Column(db.Numeric(13, 5))
    cvnrkdiv = db.Column(db.String(1))
    cvsynthese = db.Column(db.Numeric(2, 0, asdecimal=False))
    cvflag_etat = db.Column(db.Numeric(asdecimal=False))
    cvdirtyvalue = db.Column(db.Numeric(13, 5))
    cvtheta = db.Column(db.Numeric(13, 5))
    cvntheta = db.Column(db.String(1))
    cvvolimp = db.Column(db.Numeric(13, 5))
    cvvactptbmatu = db.Column(db.Numeric(13, 5))
    cvbaisseptbmatu = db.Column(db.Numeric(13, 5))
    cvdurationput = db.Column(db.Numeric(13, 5))
    cvdurationcorrput = db.Column(db.Numeric(13, 5))
    cvvactptbput = db.Column(db.Numeric(13, 5))
    cvbaisseptbput = db.Column(db.Numeric(13, 5))
    cvsprput = db.Column(db.Numeric(13, 5))
    cvtauxput = db.Column(db.Numeric(13, 5))
    cvvaltheoput = db.Column(db.Numeric(13, 5))
    cvvolimpput = db.Column(db.Numeric(13, 5))
    cvdeltaput = db.Column(db.Numeric(13, 5))
    cvdeltanormeput = db.Column(db.Numeric(13, 5))
    cvvegaput = db.Column(db.Numeric(13, 5))
    cvthetaput = db.Column(db.Numeric(13, 5))
    cvrhoput = db.Column(db.Numeric(13, 5))
    cvdw20put = db.Column(db.Numeric(13, 5))
    cvdw10put = db.Column(db.Numeric(13, 5))
    cvup10put = db.Column(db.Numeric(13, 5))
    cvup20put = db.Column(db.Numeric(13, 5))
    cvgamma = db.Column(db.Numeric(13, 5))
    cvgammaput = db.Column(db.Numeric(13, 5))
    cvrkqdsput = db.Column(db.Numeric(13, 5))
    cvspreadimp = db.Column(db.Numeric(13, 5))
    cvsensiaction = db.Column(db.Numeric(13, 5))
    cvprixparite = db.Column(db.Numeric(13, 5))
    cvsourcehyp = db.Column(db.String(16))


class BconvertibleOld(db.Model):
    __tablename__ = "bconvertible_old"
    __table_args__ = {"schema": "derives"}

    cvcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    cvdate = db.Column(db.DateTime, nullable=False)
    cvnom = db.Column(db.String(60))
    cvsjac = db.Column(db.ForeignKey("exane.instruments.ifcfin"), index=True)
    cvmktcapini = db.Column(db.Numeric(18, 2))
    cvmktcap = db.Column(db.Numeric(18, 2))
    cvmktcapsj = db.Column(db.Numeric(18, 2))
    cvcall = db.Column(db.Numeric(13, 5))
    cvdatedebcall = db.Column(db.DateTime)
    cvdatefincall = db.Column(db.DateTime)
    cvtriggercall = db.Column(db.Numeric(13, 5))
    cvcroisstrig = db.Column(db.Numeric(13, 5))
    cvnominal = db.Column(db.Numeric(13, 5))
    cvput = db.Column(db.Numeric(13, 5))
    cvdatedebput = db.Column(db.DateTime)
    cvdaterembo = db.Column(db.DateTime)
    cvprimerembo = db.Column(db.Numeric(13, 5))
    cvsj = db.Column(db.Numeric(13, 5))
    cvdr = db.Column(db.Numeric(13, 5))
    cvcoupcouru = db.Column(db.Numeric(13, 5))
    cvprixpiedcoup = db.Column(db.Numeric(13, 5))
    cvduration = db.Column(db.Numeric(13, 5))
    cvdureevie = db.Column(db.Numeric(13, 5))
    cvpayback = db.Column(db.Numeric(13, 5))
    cvsproat = db.Column(db.Numeric(13, 5))
    cvrdtcall = db.Column(db.Numeric(13, 5))
    cvrdtput = db.Column(db.Numeric(13, 5))
    cvrdtmaturite = db.Column(db.Numeric(13, 5))
    cvrdtcourant = db.Column(db.Numeric(13, 5))
    cvprimebrute = db.Column(db.Numeric(13, 5))
    cvprimebrutea = db.Column(db.Numeric(13, 5))
    cvprimenette = db.Column(db.Numeric(13, 5))
    cvprimenettea = db.Column(db.Numeric(13, 5))
    cvvalactuflat = db.Column(db.Numeric(13, 5))
    cvvalactuptb = db.Column(db.Numeric(13, 5))
    cvbaisseflat = db.Column(db.Numeric(13, 5))
    cvbaisseptb = db.Column(db.Numeric(13, 5))
    cvdelta = db.Column(db.Numeric(13, 5))
    cvdeltanorme = db.Column(db.Numeric(13, 5))
    cvndelta = db.Column(db.String(1))
    cvrho = db.Column(db.Numeric(13, 5))
    cvnrho = db.Column(db.String(1))
    cvvaltheo = db.Column(db.Numeric(13, 5))
    cvnvaltheo = db.Column(db.String(1))
    cvdecote = db.Column(db.Numeric(13, 5))
    cvdw20 = db.Column(db.Numeric(13, 5))
    cvdw10 = db.Column(db.Numeric(13, 5))
    cvup10 = db.Column(db.Numeric(13, 5))
    cvup20 = db.Column(db.Numeric(13, 5))
    cvdw20pb = db.Column(db.Numeric(13, 5))
    cvdw10pb = db.Column(db.Numeric(13, 5))
    cvup10pb = db.Column(db.Numeric(13, 5))
    cvup20pb = db.Column(db.Numeric(13, 5))
    cvnote_spr = db.Column(db.String(32))
    cvnote_div = db.Column(db.String(1))
    cvnote_vol = db.Column(db.String(1))
    cvnote_rsk = db.Column(db.String(1))
    cvspr_ex = db.Column(db.Numeric(13, 5))
    cvcrdiv_ex = db.Column(db.Numeric(13, 5))
    cvvol_ex = db.Column(db.Numeric(13, 5))
    cvvolmax_ex = db.Column(db.Numeric(13, 5))
    cvtauxref = db.Column(db.Numeric(13, 5))
    cvmatref = db.Column(db.Numeric(13, 5))
    cvvega = db.Column(db.Numeric(13, 5))
    cvnvega = db.Column(db.String(1))
    cvrkqds = db.Column(db.Numeric(13, 5))
    cvnrkqds = db.Column(db.String(1))
    cvrkdiv = db.Column(db.Numeric(13, 5))
    cvnrkdiv = db.Column(db.String(1))
    cvsynthese = db.Column(db.Numeric(2, 0, asdecimal=False))
    cvflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cvdirtyvalue = db.Column(db.Numeric(13, 5))
    cvtheta = db.Column(db.Numeric(13, 5))
    cvntheta = db.Column(db.String(1))
    cvtemp = db.Column(db.Numeric(13, 5))
    cvvactptbmatu = db.Column(db.Numeric(13, 5))
    cvbaisseptbmatu = db.Column(db.Numeric(13, 5))
    cvdurationput = db.Column(db.Numeric(13, 5))
    cvvactptbput = db.Column(db.Numeric(13, 5))
    cvbaisseptbput = db.Column(db.Numeric(13, 5))
    cvsprput = db.Column(db.Numeric(13, 5))
    cvtauxput = db.Column(db.Numeric(13, 5))
    cvvaltheoput = db.Column(db.Numeric(13, 5))
    cvtempput = db.Column(db.Numeric(13, 5))
    cvdeltaput = db.Column(db.Numeric(13, 5))
    cvdeltanormeput = db.Column(db.Numeric(13, 5))
    cvvegaput = db.Column(db.Numeric(13, 5))
    cvthetaput = db.Column(db.Numeric(13, 5))
    cvrhoput = db.Column(db.Numeric(13, 5))
    cvdw20put = db.Column(db.Numeric(13, 5))
    cvdw10put = db.Column(db.Numeric(13, 5))
    cvup10put = db.Column(db.Numeric(13, 5))
    cvup20put = db.Column(db.Numeric(13, 5))
    cvgamma = db.Column(db.Numeric(13, 5))
    cvgammaput = db.Column(db.Numeric(13, 5))
    cvrkqdsput = db.Column(db.Numeric(13, 5))
    cvspreadimp = db.Column(db.Numeric(13, 5))
    cvsensiaction = db.Column(db.Numeric(13, 5))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="BconvertibleOld.cvcfin == Instrument.ifcfin",
        backref="instrument_bconvertible_olds",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="BconvertibleOld.cvsjac == Instrument.ifcfin",
        backref="instrument_bconvertible_olds_0",
    )


class Bconvertiblehyp(db.Model):
    __tablename__ = "bconvertiblehyp"
    __table_args__ = (
        db.CheckConstraint("CVHYPOTHESEDESC in (1,2)"),
        {"schema": "derives"},
    )

    cvcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    cvdate = db.Column(db.DateTime, nullable=False)
    cvhypothese = db.Column(
        db.ForeignKey("derives.convtypehypothese.hyptype"),
        primary_key=True,
        nullable=False,
        info="Hypohèse du jeu de paramètre lors de pricing",
    )
    cvhypothesedesc = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="1 : VI 9 mois, 2 : moyenne VH"
    )
    cvmktcapini = db.Column(db.Numeric(18, 2))
    cvmktcap = db.Column(db.Numeric(18, 2))
    cvmktcapsj = db.Column(db.Numeric(18, 2))
    cvcall = db.Column(db.Numeric(13, 5))
    cvdatedebcall = db.Column(db.DateTime)
    cvdatefincall = db.Column(db.DateTime)
    cvtriggercall = db.Column(db.Numeric(13, 5))
    cvcroisstrig = db.Column(db.Numeric(13, 5))
    cvnominal = db.Column(db.Numeric(18, 5))
    cvput = db.Column(db.Numeric(13, 5))
    cvdatedebput = db.Column(db.DateTime)
    cvdaterembo = db.Column(db.DateTime)
    cvprimerembo = db.Column(db.Numeric(13, 5))
    cvsj = db.Column(db.Numeric(13, 5))
    cvdr = db.Column(db.Numeric(13, 5))
    cvcoupcouru = db.Column(db.Numeric(13, 5))
    cvprixpiedcoup = db.Column(db.Numeric(13, 5))
    cvduration = db.Column(db.Numeric(13, 5))
    cvdureevie = db.Column(db.Numeric(13, 5))
    cvpayback = db.Column(db.Numeric(13, 5))
    cvsproat = db.Column(db.Numeric(13, 5))
    cvrdtcall = db.Column(db.Numeric(13, 5))
    cvrdtput = db.Column(db.Numeric(13, 5))
    cvrdtmaturite = db.Column(db.Numeric(13, 5))
    cvrdtcourant = db.Column(db.Numeric(13, 5))
    cvprimebrute = db.Column(db.Numeric(13, 5))
    cvprimebrutea = db.Column(db.Numeric(13, 5))
    cvprimenette = db.Column(db.Numeric(13, 5))
    cvprimenettea = db.Column(db.Numeric(13, 5))
    cvvalactuflat = db.Column(db.Numeric(13, 5))
    cvvalactuptb = db.Column(db.Numeric(13, 5))
    cvbaisseflat = db.Column(db.Numeric(13, 5))
    cvbaisseptb = db.Column(db.Numeric(13, 5))
    cvdelta = db.Column(db.Numeric(13, 5))
    cvdeltanorme = db.Column(db.Numeric(13, 5))
    cvndelta = db.Column(db.String(1))
    cvdeltat = db.Column(db.Numeric(13, 5))
    cvrho = db.Column(db.Numeric(13, 5))
    cvnrho = db.Column(db.String(1))
    cvvaltheo = db.Column(db.Numeric(13, 5))
    cvnvaltheo = db.Column(db.String(1))
    cvdecote = db.Column(db.Numeric(13, 5))
    cvdw20 = db.Column(db.Numeric(13, 5))
    cvdw10 = db.Column(db.Numeric(13, 5))
    cvup10 = db.Column(db.Numeric(13, 5))
    cvup20 = db.Column(db.Numeric(13, 5))
    cvdw20pb = db.Column(db.Numeric(13, 5))
    cvdw10pb = db.Column(db.Numeric(13, 5))
    cvup10pb = db.Column(db.Numeric(13, 5))
    cvup20pb = db.Column(db.Numeric(13, 5))
    cvnote_spr = db.Column(db.String(32))
    cvnote_div = db.Column(db.String(1))
    cvnote_vol = db.Column(db.String(1))
    cvnote_rsk = db.Column(db.String(1))
    cvspr_ex = db.Column(db.Numeric(13, 5))
    cvcrdiv_ex = db.Column(db.Numeric(13, 5))
    cvvol_ex = db.Column(db.Numeric(13, 5))
    cvvolmax_ex = db.Column(db.Numeric(13, 5))
    cvtauxref = db.Column(db.Numeric(13, 5))
    cvmatref = db.Column(db.Numeric(13, 5))
    cvvega = db.Column(db.Numeric(13, 5))
    cvnvega = db.Column(db.String(1))
    cvrkqds = db.Column(db.Numeric(13, 5))
    cvnrkqds = db.Column(db.String(1))
    cvrkdiv = db.Column(db.Numeric(13, 5))
    cvnrkdiv = db.Column(db.String(1))
    cvsynthese = db.Column(db.Numeric(2, 0, asdecimal=False))
    cvdirtyvalue = db.Column(db.Numeric(13, 5))
    cvtheta = db.Column(db.Numeric(13, 5))
    cvntheta = db.Column(db.String(1))
    cvvolimp = db.Column(db.Numeric(13, 5))
    cvvactptbmatu = db.Column(db.Numeric(13, 5))
    cvbaisseptbmatu = db.Column(db.Numeric(13, 5))
    cvdurationput = db.Column(db.Numeric(13, 5))
    cvvactptbput = db.Column(db.Numeric(13, 5))
    cvbaisseptbput = db.Column(db.Numeric(13, 5))
    cvsprput = db.Column(db.Numeric(13, 5))
    cvtauxput = db.Column(db.Numeric(13, 5))
    cvvaltheoput = db.Column(db.Numeric(13, 5))
    cvvolimpput = db.Column(db.Numeric(13, 5))
    cvdeltaput = db.Column(db.Numeric(13, 5))
    cvdeltanormeput = db.Column(db.Numeric(13, 5))
    cvvegaput = db.Column(db.Numeric(13, 5))
    cvthetaput = db.Column(db.Numeric(13, 5))
    cvrhoput = db.Column(db.Numeric(13, 5))
    cvdw20put = db.Column(db.Numeric(13, 5))
    cvdw10put = db.Column(db.Numeric(13, 5))
    cvup10put = db.Column(db.Numeric(13, 5))
    cvup20put = db.Column(db.Numeric(13, 5))
    cvgamma = db.Column(db.Numeric(13, 5))
    cvgammaput = db.Column(db.Numeric(13, 5))
    cvrkqdsput = db.Column(db.Numeric(13, 5))
    cvspreadimp = db.Column(db.Numeric(13, 5))
    cvsensiaction = db.Column(db.Numeric(13, 5))
    cvrdtnetdiv_next = db.Column(db.Numeric(13, 5))
    cvrdtafdiv_next = db.Column(db.Numeric(13, 5))
    cvdurationcorr = db.Column(db.Numeric(13, 5), info="Duration corrigée")
    cvdurationcorrput = db.Column(db.Numeric(13, 5), info="Duration corrigée au Put")
    cvprixparite = db.Column(db.Numeric(13, 5), info="Parity")
    cvcorrectvol = db.Column(db.Numeric(24, 7), info="Correcteur de volatilité")
    cvperfvi1d = db.Column(db.Numeric(24, 7), info="Perf VI 1 jour")
    cvperfvi1w = db.Column(db.Numeric(24, 7), info="Perf VI 1 semaine")
    cvperfvi1m = db.Column(db.Numeric(24, 7), info="Perf VI 1 mois")
    cvvegapct = db.Column(db.Numeric(13, 5), info="100*CVVEGA/CVDR")
    cvtriggerpct = db.Column(
        db.Numeric(13, 5), info="trigger call * crossSjtoDer * parity * 100 / callvalue"
    )
    cvparity = db.Column(db.Numeric(13, 5), info="parity")
    cvvalactuptbclean = db.Column(db.Numeric(13, 5))
    cvbaisseptbclean = db.Column(db.Numeric(13, 5))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Bconvertiblehyp.cvcfin == Instrument.ifcfin",
        backref="bconvertiblehyps",
    )
    convtypehypothese = db.relationship(
        "Convtypehypothese",
        primaryjoin="Bconvertiblehyp.cvhypothese == Convtypehypothese.hyptype",
        backref="bconvertiblehyps",
    )


class Bctd(db.Model):
    __tablename__ = "bctd"
    __table_args__ = {"schema": "derives"}

    bcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    bdate = db.Column(db.DateTime)
    bctd = db.Column(db.Numeric(8, 0, asdecimal=False))


class Bidx(db.Model):
    __tablename__ = "bidx"
    __table_args__ = {"schema": "derives"}

    ixcfin = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    ixdate = db.Column(db.DateTime, nullable=False)
    ixopen = db.Column(db.Numeric(asdecimal=False))
    ixclose = db.Column(db.Numeric(asdecimal=False))
    ixbase = db.Column(db.Numeric(asdecimal=False))
    ixdisp = db.Column(db.Numeric(10, 6))
    ixdisphebdo = db.Column(db.Numeric(10, 6))
    ixdisp1m = db.Column(db.Numeric(10, 6))
    ixdisp3m = db.Column(db.Numeric(10, 6))
    ixcorrmoy = db.Column(db.Numeric(10, 6))
    ixmoycorr = db.Column(db.Numeric(10, 6))
    ixvh = db.Column(db.Numeric(13, 5))
    ixmoyvh = db.Column(db.Numeric(13, 5))
    ixprevdate = db.Column(db.DateTime)
    ixprevopen = db.Column(db.Numeric(asdecimal=False))
    ixprevclose = db.Column(db.Numeric(asdecimal=False))
    ixprevbase = db.Column(db.Numeric(asdecimal=False))
    ixprevdisp = db.Column(db.Numeric(10, 6))
    ixprevdisphebdo = db.Column(db.Numeric(10, 6))
    ixprevdisp1m = db.Column(db.Numeric(10, 6))
    ixprevdisp3m = db.Column(db.Numeric(10, 6))
    ixprevcorrmoy = db.Column(db.Numeric(10, 6))
    ixprevmoycorr = db.Column(db.Numeric(10, 6))
    ixprevvh = db.Column(db.Numeric(13, 5))
    ixprevmoyvh = db.Column(db.Numeric(13, 5))


class Bindicerisque(db.Model):
    __tablename__ = "bindicerisque"
    __table_args__ = {"schema": "derives"}

    bicfin = db.Column(db.ForeignKey("derives.indicerisque.ircfin"), nullable=False)
    bidate = db.Column(db.DateTime)
    binb = db.Column(db.Numeric(9, 0, asdecimal=False))
    bimediane = db.Column(db.Numeric(13, 5))
    bimoyenne = db.Column(db.Numeric(13, 5))
    bidispersion = db.Column(db.Numeric(13, 5))
    biflag_etat = db.Column(db.Numeric(1, 0, asdecimal=False))

    indicerisque = db.relationship(
        "Indicerisque",
        primaryjoin="Bindicerisque.bicfin == Indicerisque.ircfin",
        backref="bindicerisques",
    )


class BobligOld(db.Model):
    __tablename__ = "boblig_old"
    __table_args__ = {"schema": "derives"}

    bbcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    bbdate = db.Column(db.DateTime)
    bbnom = db.Column(db.String(60))
    bbmktcap = db.Column(db.Numeric(18, 2))
    bbprix = db.Column(db.Numeric(13, 5))
    bbcouponcouru = db.Column(db.Numeric(13, 5))
    bbrdt = db.Column(db.Numeric(13, 5))
    bbspr_ex = db.Column(db.Numeric(13, 5))
    bbnote_ex = db.Column(db.String(4))
    bbpays = db.Column(db.Numeric(3, 0, asdecimal=False))
    bbsecteur = db.Column(db.Numeric(8, 0, asdecimal=False))
    bbdev = db.Column(db.Numeric(8, 0, asdecimal=False))
    bberreur = db.Column(db.Numeric(13, 5))
    bbspread = db.Column(db.Numeric(13, 5))
    bbduration = db.Column(db.Numeric(13, 5))
    bbecart_prix = db.Column(db.Numeric(13, 5))
    bbecart_rdt = db.Column(db.Numeric(13, 5))
    bbflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="BobligOld.bbcfin == Instrument.ifcfin",
        backref="boblig_olds",
    )


class Brix(db.Model):
    __tablename__ = "brix"
    __table_args__ = {"schema": "derives"}

    ixcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Cfin indice"
    )
    ixdate = db.Column(db.DateTime, nullable=False, info="Date valeur")
    ixopen = db.Column(db.Numeric(asdecimal=False), info="Valeur d'ouverture")
    ixclose = db.Column(db.Numeric(asdecimal=False), info="Valeur de cloture")
    ixbase = db.Column(db.Numeric(asdecimal=False), info="Base indice")
    ixscript = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        info="ID session batch qui a calcule l'indice",
    )
    ixsessionid = db.Column(db.ForeignKey("exane_batch.appsession.asidsession"))

    appsession = db.relationship(
        "Appsession",
        primaryjoin="Brix.ixsessionid == Appsession.asidsession",
        backref="brixes",
    )


class BrixPr(db.Model):
    __tablename__ = "brix_pr"
    __table_args__ = {"schema": "derives"}

    ixcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Cfin indice"
    )
    ixdate = db.Column(db.DateTime, nullable=False, info="Date valeur")
    ixopen = db.Column(db.Numeric(asdecimal=False), info="Valeur d'ouverture")
    ixclose = db.Column(db.Numeric(asdecimal=False), info="Valeur de cloture")
    ixbase = db.Column(db.Numeric(asdecimal=False), info="Base indice")
    ixscript = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        info="ID session batch qui a calcule l'indice",
    )
    ixsessionid = db.Column(db.Numeric(9, 0, asdecimal=False))


class Bstrspecifique(db.Model):
    __tablename__ = "bstrspecifique"
    __table_args__ = (
        db.CheckConstraint("CSMODEUT IN ('V','T')"),
        {"schema": "derives"},
    )

    cscfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    csmodeut = db.Column(
        db.String(1), primary_key=True, nullable=False, info="Vente,Trading"
    )
    csprofilgcp = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cstypepricer = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Constante Casper : ServiceValorisation::PR_STANDARD,PR_BLACK,PR_EDP,PR_FAST_MC,PR_SLOW_MC,PR_EXTENDED,...",
    )
    csindic = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    csdate = db.Column(db.DateTime)
    csvaleurindic = db.Column(db.Numeric(18, 5))
    csflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Bstrspecifique.cscfin == Instrument.ifcfin",
        backref="bstrspecifiques",
    )


class Bstrspecsj(db.Model):
    __tablename__ = "bstrspecsj"
    __table_args__ = {"schema": "derives"}

    cjcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False, info="Cfin"
    )
    cjundl = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Underlying",
    )
    cjindic = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code for indicator",
    )
    cjvalue = db.Column(db.Numeric(18, 5), nullable=False, info="Indicator value")
    cjdate = db.Column(db.DateTime, nullable=False, info="Date")
    cjsource = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Source 1=Castor 2=Pythagore",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Bstrspecsj.cjundl == Instrument.ifcfin",
        backref="bstrspecsjs",
    )


class Bstructure(db.Model):
    __tablename__ = "bstructure"
    __table_args__ = {"schema": "derives"}

    strcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    strdate = db.Column(db.DateTime, nullable=False)
    strnom = db.Column(db.String(60))
    strtype = db.Column(db.Numeric(3, 0, asdecimal=False))
    strpays = db.Column(db.Numeric(3, 0, asdecimal=False))
    strsjac = db.Column(db.Numeric(8, 0, asdecimal=False))
    strclossjac = db.Column(db.Numeric(13, 5))
    strclosdr = db.Column(db.Numeric(13, 5))
    strclosdrhm = db.Column(db.Numeric(13, 5))
    strbasecfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    strtypebase = db.Column(db.Numeric(3, 0, asdecimal=False))
    strnbbase = db.Column(db.Numeric(24, 15))
    stroption1cfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    strstrike1 = db.Column(db.Numeric(13, 5))
    strnboption1 = db.Column(db.Numeric(11, 5))
    strtypeoption1 = db.Column(db.String(1))
    strextype1 = db.Column(db.String(1))
    strmatoption1 = db.Column(db.DateTime)
    stroption2cfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    strstrike2 = db.Column(db.Numeric(13, 5))
    strnboption2 = db.Column(db.Numeric(11, 5))
    strtypeoption2 = db.Column(db.String(1))
    strextype2 = db.Column(db.String(1))
    strmatoption2 = db.Column(db.DateTime)
    strdatefin = db.Column(db.DateTime)
    strmktcap = db.Column(db.Numeric(18, 2))
    strmktcapsj = db.Column(db.Numeric(18, 2))
    strnominal = db.Column(db.Numeric(15, 2))
    strcoupon = db.Column(db.Numeric(13, 5))
    strtxoat = db.Column(db.Numeric(13, 5))
    strptb = db.Column(db.Numeric(13, 5))
    strvol_ex = db.Column(db.Numeric(13, 5))
    strvolmax_ex = db.Column(db.Numeric(13, 5))
    strvaltheo = db.Column(db.Numeric(13, 5))
    strdecote = db.Column(db.Numeric(13, 5))
    strdecotehm = db.Column(db.Numeric(13, 5))
    strprime = db.Column(db.Numeric(13, 5))
    strprimea = db.Column(db.Numeric(13, 5))
    strcap = db.Column(db.Numeric(13, 5))
    strytm_cap = db.Column(db.Numeric(13, 5))
    strbkeven_cap = db.Column(db.Numeric(13, 5))
    strfloor = db.Column(db.Numeric(13, 5))
    strytm_floor = db.Column(db.Numeric(13, 5))
    strbkeven_floor = db.Column(db.Numeric(13, 5))
    strvolimp = db.Column(db.Numeric(13, 5))
    strvolimphm = db.Column(db.Numeric(13, 5))
    strdelta = db.Column(db.Numeric(13, 5))
    strdeltahm = db.Column(db.Numeric(13, 5))
    strdeltanorme = db.Column(db.Numeric(13, 5))
    strdeltanormehm = db.Column(db.Numeric(13, 5))
    strvega = db.Column(db.Numeric(13, 5))
    strvegahm = db.Column(db.Numeric(13, 5))
    strrho = db.Column(db.Numeric(13, 5))
    strtheta = db.Column(db.Numeric(13, 5))
    strduration = db.Column(db.Numeric(13, 5))
    strcouponcouru = db.Column(db.Numeric(13, 5))
    strsomdivact = db.Column(db.Numeric(13, 5))
    strflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    strparite = db.Column(db.Numeric(11, 5))
    strproportion = db.Column(db.Numeric(11, 5))
    strrdtcourant = db.Column(db.Numeric(13, 5))
    strpremium = db.Column(db.Numeric(13, 5))
    strpremiuma = db.Column(db.Numeric(13, 5))
    strconvm20 = db.Column(db.Numeric(13, 5))
    strconvp20 = db.Column(db.Numeric(13, 5))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Bstructure.strcfin == Instrument.ifcfin",
        backref="bstructures",
    )


class Bwarrant(db.Model):
    __tablename__ = "bwarrant"
    __table_args__ = {"schema": "derives"}

    rwcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    rwdate = db.Column(db.DateTime, nullable=False)
    rwnom = db.Column(db.String(60))
    rwpays = db.Column(db.Numeric(3, 0, asdecimal=False))
    rwsjac = db.Column(db.ForeignKey("exane.instruments.ifcfin"), index=True)
    rwclossjac = db.Column(db.Numeric(13, 5))
    rwclosdr = db.Column(db.Numeric(13, 5))
    rwstrike = db.Column(db.Numeric(13, 5))
    rwparite = db.Column(db.Numeric(11, 5))
    rwproportion = db.Column(db.Numeric(11, 5))
    rwdatefin = db.Column(db.DateTime)
    rwput = db.Column(db.Numeric(10, 2))
    rwdatedebput = db.Column(db.DateTime)
    rwdatefinput = db.Column(db.DateTime)
    rwmktcap = db.Column(db.Numeric(18, 2))
    rwmktcapsj = db.Column(db.Numeric(18, 2))
    rwprime = db.Column(db.Numeric(13, 5))
    rwprimea = db.Column(db.Numeric(13, 5))
    rwvalactu = db.Column(db.Numeric(13, 5))
    rwvaltheo = db.Column(db.Numeric(13, 5))
    rwdecote = db.Column(db.Numeric(13, 5))
    rwvolimp = db.Column(db.Numeric(13, 5))
    rwdelta = db.Column(db.Numeric(13, 5))
    rwdeltanorme = db.Column(db.Numeric(13, 5))
    rwvega = db.Column(db.Numeric(13, 5))
    rwrho = db.Column(db.Numeric(13, 5))
    rwinout = db.Column(db.Numeric(13, 5))
    rwvol_ex = db.Column(db.Numeric(13, 5))
    rwvolmax_ex = db.Column(db.Numeric(13, 5))
    rwgearing = db.Column(db.Numeric(13, 5))
    rwelast = db.Column(db.Numeric(13, 5))
    rwcractsup = db.Column(db.Numeric(13, 5))
    rwcractinf = db.Column(db.Numeric(13, 5))
    rwcoeffext = db.Column(db.Numeric(13, 5))
    rwtxoat = db.Column(db.Numeric(13, 5))
    rwsomdivcap = db.Column(db.Numeric(13, 5))
    rwsynthese = db.Column(db.Numeric(2, 0, asdecimal=False))
    rwstrat = db.Column(db.Numeric(3, 0, asdecimal=False))
    rwflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    rwbreak_lev_hedge = db.Column(db.Numeric(13, 5))
    rwtheta = db.Column(db.Numeric(13, 5))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Bwarrant.rwcfin == Instrument.ifcfin",
        backref="instrument_bwarrants",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Bwarrant.rwsjac == Instrument.ifcfin",
        backref="instrument_bwarrants_0",
    )


class Clausederivevente(db.Model):
    __tablename__ = "clausederivevente"
    __table_args__ = (
        db.CheckConstraint("CDCPNCOUR in ('O','N')"),
        db.CheckConstraint("CDDROIT is null or ( CDDROIT in ('P','E') )"),
        {"schema": "derives"},
    )

    cdcfin = db.Column(
        db.ForeignKey("exane.derives.decfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        info="Code de l'instrument financier",
    )
    cdordre = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Numero d'ordre de la clause. Permet d'avoir un critŠre d'unicit‚é",
    )
    cdtype = db.Column(
        db.ForeignKey("exane.typeclause.tdcode"),
        nullable=False,
        info="Code de la clause sur un d‚riv‚",
    )
    cddatedeb = db.Column(db.DateTime, nullable=False, info="date de debut de validite")
    cddatefin = db.Column(db.DateTime, nullable=False, info="date de fin de validite")
    cdlimitbas = db.Column(
        db.ForeignKey("derives.fonctiontempsvente.fntid"), info="Limite basse"
    )
    cdlimithaut = db.Column(
        db.ForeignKey("derives.fonctiontempsvente.fntid"), info="Limite haute"
    )
    cddroit = db.Column(db.String(1), info="P pour HOLDER,  E pour ISSUER")
    cdvaleur = db.Column(
        db.ForeignKey("derives.fonctiontempsvente.fntid"), info="valeur"
    )
    cdformule = db.Column(db.Numeric(13, 0, asdecimal=False), info="ref Formule")
    cdcpncour = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="coupon couru",
    )
    cddatevaleur = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Payment Offset in number of working days",
    )
    cddecision = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Decision period for conversion in calendar day",
    )
    cdtypeconvert = db.Column(
        db.ForeignKey("exane.typeconversion.tcclcode"),
        info="Code Interne du type de conversion",
    )
    cdstatut = db.Column(
        db.ForeignKey("exane.typestatut.tstcode"),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Code du statut d'un instrument financier",
    )
    cddatemaj = db.Column(db.DateTime, info="date de mise … jour")
    cdproprietes = db.Column(
        db.Numeric(38, 0, asdecimal=False),
        unique=True,
        info="Definit l'identifiant de liste de propriétés de clause",
    )

    derive = db.relationship(
        "Derive",
        primaryjoin="Clausederivevente.cdcfin == Derive.decfin",
        backref="clausederiveventes",
    )
    fonctiontempsvente = db.relationship(
        "Fonctiontempsvente",
        primaryjoin="Clausederivevente.cdlimitbas == Fonctiontempsvente.fntid",
        backref="fonctiontempsvente_fonctiontempsvente_clausederiveventes",
    )
    fonctiontempsvente1 = db.relationship(
        "Fonctiontempsvente",
        primaryjoin="Clausederivevente.cdlimithaut == Fonctiontempsvente.fntid",
        backref="fonctiontempsvente_fonctiontempsvente_clausederiveventes_0",
    )
    typestatut = db.relationship(
        "Typestatut",
        primaryjoin="Clausederivevente.cdstatut == Typestatut.tstcode",
        backref="clausederiveventes",
    )
    typeclause = db.relationship(
        "Typeclause",
        primaryjoin="Clausederivevente.cdtype == Typeclause.tdcode",
        backref="clausederiveventes",
    )
    typeconversion = db.relationship(
        "Typeconversion",
        primaryjoin="Clausederivevente.cdtypeconvert == Typeconversion.tcclcode",
        backref="clausederiveventes",
    )
    fonctiontempsvente2 = db.relationship(
        "Fonctiontempsvente",
        primaryjoin="Clausederivevente.cdvaleur == Fonctiontempsvente.fntid",
        backref="fonctiontempsvente_fonctiontempsvente_clausederiveventes",
    )


class Convtypehypothese(db.Model):
    __tablename__ = "convtypehypothese"
    __table_args__ = {"schema": "derives"}

    hyptype = db.Column(db.Numeric(2, 0, asdecimal=False), primary_key=True)
    hypnom = db.Column(db.String(120))


class Corresgammebbproductname(db.Model):
    __tablename__ = "corresgammebbproductname"
    __table_args__ = {"schema": "derives"}

    gpngamme = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Gamme"
    )
    gpnbbidname = db.Column(
        db.Numeric(24, 0, asdecimal=False),
        nullable=False,
        info="Identifiant du nom de produit bloomberg",
    )


class Corresmontagebbsecuritytype(db.Model):
    __tablename__ = "corresmontagebbsecuritytype"
    __table_args__ = (
        db.ForeignKeyConstraint(
            ["gmssecurity", "gmstype"],
            [
                "derives.dicobloombergsecuritytype.bsttypesecurity",
                "derives.dicobloombergsecuritytype.bstcodesecurity",
            ],
        ),
        {"schema": "derives"},
    )

    gmsgamme = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Code gamme montage"
    )
    gmssecurity = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="Type de code bloomberg"
    )
    gmstype = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code gamme bloomberg (security type)",
    )

    dicobloombergsecuritytype = db.relationship(
        "Dicobloombergsecuritytype",
        primaryjoin="and_(Corresmontagebbsecuritytype.gmssecurity == Dicobloombergsecuritytype.bsttypesecurity, Corresmontagebbsecuritytype.gmstype == Dicobloombergsecuritytype.bstcodesecurity)",
        backref="corresmontagebbsecuritytypes",
    )


t_correspayofftypebloomberg = db.Table(
    "correspayofftypebloomberg",
    db.Column(
        "ctbpayoff",
        db.ForeignKey("exane.typepayoff.tflcode"),
        primary_key=True,
        info="Payoff",
    ),
    db.Column(
        "ctbcodetypebloom",
        db.ForeignKey("derives.typebloomberg.tbcode"),
        nullable=False,
        info="Code du type de la ressource Bloomberg",
    ),
    schema="derives",
)


class Couponsvariable(db.Model):
    __tablename__ = "couponsvariables"
    __table_args__ = {"schema": "derives"}

    vccfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="CFIN",
    )
    vcdatepaiement = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date de paiement"
    )
    vcmontant = db.Column(
        db.Numeric(13, 5), info="Montant calculé du coupon exprimé en % du nominal"
    )
    vccouru = db.Column(db.Numeric(13, 5), info="Coupon couru")
    vcdatecalcul = db.Column(db.DateTime, info="Date du calcul")
    vcdateref = db.Column(
        db.DateTime, info="Date prise pour le cours du taux de référence"
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Couponsvariable.vccfin == Instrument.ifcfin",
        backref="couponsvariables",
    )


class Defliste(db.Model):
    __tablename__ = "defliste"
    __table_args__ = (
        db.CheckConstraint("DLTYPE IN ('SE','PA','NO','DE','CL')"),
        {"schema": "derives"},
    )

    dlidl = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    dlnom = db.Column(db.String(60), nullable=False)
    dltype = db.Column(db.String(60), nullable=False)


class Dicobloombergsecuritytype(db.Model):
    __tablename__ = "dicobloombergsecuritytype"
    __table_args__ = {"schema": "derives"}

    bsttypesecurity = db.Column(
        db.ForeignKey("derives.dicotypesecuritytype.sttcode"),
        primary_key=True,
        nullable=False,
        info="Type security type",
    )
    bstcodesecurity = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code security type",
    )
    bstlibelle = db.Column(db.String(60), nullable=False, info="Nom security type")

    dicotypesecuritytype = db.relationship(
        "Dicotypesecuritytype",
        primaryjoin="Dicobloombergsecuritytype.bsttypesecurity == Dicotypesecuritytype.sttcode",
        backref="dicobloombergsecuritytypes",
    )


class Dicotypesecuritytype(db.Model):
    __tablename__ = "dicotypesecuritytype"
    __table_args__ = {"schema": "derives"}

    sttcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code type de sécurité",
    )
    sttlibelle = db.Column(db.String(60), nullable=False, info="Nom type de sécurité")


class Donnees3(db.Model):
    __tablename__ = "donnees3"
    __table_args__ = {"schema": "derives"}

    code_simu = db.Column(
        db.ForeignKey("derives.simulation3.code_simu", ondelete="CASCADE"),
        nullable=False,
        index=True,
        info="Code de simulation ( clef)",
    )
    code = db.Column(db.Numeric(3, 0, asdecimal=False), info="code valeur")
    valeur = db.Column(db.String(15), info="valeur")

    simulation3 = db.relationship(
        "Simulation3",
        primaryjoin="Donnees3.code_simu == Simulation3.code_simu",
        backref="donnees3s",
    )


class EcheancierBackup(db.Model):
    __tablename__ = "echeancier_backup"
    __table_args__ = {"schema": "derives"}

    eccfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    ecdate = db.Column(db.DateTime, nullable=False)
    ecmontant = db.Column(db.Numeric(16, 5), nullable=False)
    ecremb = db.Column(db.Numeric(16, 5), nullable=False)
    ecanticipe = db.Column(db.String(1))
    ecisrembo = db.Column(db.Numeric(16, 2), nullable=False)
    eccurembo = db.Column(db.Numeric(16, 2), nullable=False)
    ecdateex = db.Column(db.DateTime, nullable=False)


class Fonctionspotvente(db.Model):
    __tablename__ = "fonctionspotvente"
    __table_args__ = {"schema": "derives"}

    fnsid = db.Column(
        db.Numeric(13, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Identifiant de la fonction",
    )
    fnstype = db.Column(
        db.ForeignKey("exane.typefonctionspot.tfcscode"),
        nullable=False,
        info="Type de fonction",
    )
    fnsarg = db.Column(
        db.ForeignKey("derives.fonctiontempsvente.fntid", ondelete="CASCADE"),
        nullable=False,
        info="Argument",
    )
    fnsnumarg = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Nombre d'argument",
    )
    fnsstatut = db.Column(
        db.ForeignKey("exane.typestatut.tstcode"),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Code du statut d'un instrument financier",
    )
    fnsdatemaj = db.Column(
        db.DateTime,
        nullable=False,
        server_default=db.FetchedValue(),
        info="Date de mise … jour",
    )

    fonctiontempsvente = db.relationship(
        "Fonctiontempsvente",
        primaryjoin="Fonctionspotvente.fnsarg == Fonctiontempsvente.fntid",
        backref="fonctionspotventes",
    )
    typestatut = db.relationship(
        "Typestatut",
        primaryjoin="Fonctionspotvente.fnsstatut == Typestatut.tstcode",
        backref="fonctionspotventes",
    )
    typefonctionspot = db.relationship(
        "Typefonctionspot",
        primaryjoin="Fonctionspotvente.fnstype == Typefonctionspot.tfcscode",
        backref="fonctionspotventes",
    )


class Fonctiontempsvente(db.Model):
    __tablename__ = "fonctiontempsvente"
    __table_args__ = {"schema": "derives"}

    fntid = db.Column(
        db.Numeric(13, 0, asdecimal=False),
        primary_key=True,
        info="Identifiant de la fonction ",
    )
    fnttype = db.Column(
        db.ForeignKey("exane.typefonctiontemps.tfctcode"),
        nullable=False,
        info="Type de fonction ",
    )
    fntvaldeb = db.Column(
        db.Numeric(asdecimal=False), nullable=False, info="Valeur de d‚but "
    )
    fntvalfin = db.Column(db.Numeric(asdecimal=False), info="Ignor‚ si FNTTYPE=1")
    fntdatedeb = db.Column(db.DateTime, info="Ignor‚ si FNTTYPE=1")
    fntdatefin = db.Column(db.DateTime, info="Ignor‚ si FNTTYPE=1")
    fntstatut = db.Column(
        db.ForeignKey("exane.typestatut.tstcode"),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Code du statut de la fonction temps",
    )
    fntdatemaj = db.Column(
        db.DateTime,
        nullable=False,
        server_default=db.FetchedValue(),
        info="Deta de mise … jour, sysdate si non renseign‚",
    )

    typestatut = db.relationship(
        "Typestatut",
        primaryjoin="Fonctiontempsvente.fntstatut == Typestatut.tstcode",
        backref="fonctiontempsventes",
    )
    typefonctiontemp = db.relationship(
        "Typefonctiontemp",
        primaryjoin="Fonctiontempsvente.fnttype == Typefonctiontemp.tfctcode",
        backref="fonctiontempsventes",
    )


class Ftprecup(db.Model):
    __tablename__ = "ftprecup"
    __table_args__ = {"schema": "derives"}

    ftcfinsj = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    ftdatefin = db.Column(db.DateTime, primary_key=True, nullable=False)
    ftstrike = db.Column(db.Numeric(13, 5), primary_key=True, nullable=False)
    ftcallput = db.Column(db.String(1), primary_key=True, nullable=False)
    ftextype = db.Column(db.String(1))
    ftechtype = db.Column(db.String(1))
    ftdate = db.Column(db.DateTime)
    ftprisj = db.Column(db.Numeric(13, 5))
    ftpriop = db.Column(db.Numeric(13, 5))
    ftvolimp = db.Column(db.Numeric(13, 5))
    ftpo = db.Column(db.Numeric(12, 0, asdecimal=False))
    ftvolqute = db.Column(db.Numeric(16, 0, asdecimal=False))
    ftbid = db.Column(db.Numeric(13, 5))
    ftask = db.Column(db.Numeric(13, 5))
    ftmodecot = db.Column(db.Numeric(4, 0, asdecimal=False))
    ftcode = db.Column(db.Numeric(8, 0, asdecimal=False))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Ftprecup.ftcfinsj == Instrument.ifcfin",
        backref="ftprecups",
    )


class Haction(db.Model):
    __tablename__ = "hactions"
    __table_args__ = {"schema": "derives"}

    hacfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="CFIN",
    )
    hadate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date de calcul"
    )
    hamktcap = db.Column(db.Numeric(18, 2), info="Market cap")
    hardtnetdiv_next = db.Column(
        db.Numeric(13, 5), info="Somme des div de l année fiscale en cours (en %cours)"
    )
    hacodesect = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code secteur")
    hanote_rsk = db.Column(db.String(4), info="Note risque")
    hardtbrutdiv_next = db.Column(
        db.Numeric(13, 5),
        info="Somme des divs (bruts) de l année fiscale en cours (en %cours)",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Haction.hacfin == Instrument.ifcfin",
        backref="hactions",
    )


class Hcaspcommun(db.Model):
    __tablename__ = "hcaspcommun"
    __table_args__ = {"schema": "derives"}

    hcccfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hccmodeut = db.Column(db.String(1), primary_key=True, nullable=False)
    hccprofilgcp = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcctypepricer = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hccsource = db.Column(db.String(1), primary_key=True, nullable=False)
    hcctype = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hccdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hccrcprice = db.Column(db.Numeric(13, 5))
    hccrccotation = db.Column(db.Numeric(13, 5))
    hccrccotationri = db.Column(db.Numeric(13, 5))
    hccmodecotation = db.Column(db.Numeric(2, 0, asdecimal=False))
    hccrcvolimp = db.Column(db.Numeric(10, 5))
    hccrcytm = db.Column(db.Numeric(13, 5))
    hccrcaccrinterest = db.Column(db.Numeric(13, 5))
    hccrcbondfloor = db.Column(db.Numeric(13, 5))
    hccrcconvpremium = db.Column(db.Numeric(13, 5))
    hccrcduration = db.Column(db.Numeric(13, 5))
    hccrctheta = db.Column(db.Numeric(13, 5))
    hccrcthetabe = db.Column(db.Numeric(13, 5))
    hccrcmcerror = db.Column(db.Numeric(13, 5))
    hcczerocoupon = db.Column(db.Numeric(13, 5))
    hccrctotaldelta = db.Column(db.Numeric(13, 5))
    hccrctotalgamma = db.Column(db.Numeric(13, 5))
    hccrcfullvega = db.Column(db.Numeric(13, 5))
    hccrctotaldeltaeur = db.Column(db.Numeric(13, 5), info="Total delta en euro")
    hccrctotalgammaeur = db.Column(db.Numeric(13, 5), info="Total Gamma en euro")
    hccrcfullvegaeur = db.Column(db.Numeric(13, 5), info="Full Vega en euro")


class Hcaspcompo(db.Model):
    __tablename__ = "hcaspcompo"
    __table_args__ = {"schema": "derives"}

    hcocfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcomodeut = db.Column(db.String(1), primary_key=True, nullable=False)
    hcoprofilgcp = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcotypepricer = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcosource = db.Column(db.String(1), primary_key=True, nullable=False)
    hcotype = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcocfincompo = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcodate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hcocompoqty = db.Column(db.Numeric(24, 15))
    hcocompovalo = db.Column(db.Numeric(13, 5))


class Hcaspemetteur(db.Model):
    __tablename__ = "hcaspemetteur"
    __table_args__ = {"schema": "derives"}

    hcecfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcemodeut = db.Column(db.String(1), primary_key=True, nullable=False)
    hceprofilgcp = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcetypepricer = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcesource = db.Column(db.String(1), primary_key=True, nullable=False)
    hcetype = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcecfinact = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcedate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hcetiers = db.Column(db.Numeric(8, 0, asdecimal=False))
    hcercdefaultsensi = db.Column(db.Numeric(13, 5))
    hcetyperecovery = db.Column(db.String(1))
    hcespread = db.Column(db.Numeric(13, 5))
    hceprobadefaut = db.Column(db.Numeric(13, 5))
    hcerecoverycode = db.Column(db.Numeric(8, 0, asdecimal=False))
    hcerecoveryvalue = db.Column(db.Numeric(13, 5))


class Hcaspsj(db.Model):
    __tablename__ = "hcaspsj"
    __table_args__ = {"schema": "derives"}

    hcjcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcjmodeut = db.Column(db.String(1), primary_key=True, nullable=False)
    hcjprofilgcp = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcjtypepricer = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcjsource = db.Column(db.String(1), primary_key=True, nullable=False)
    hcjtype = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcjcfinsj = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcjdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hcjdevsj = db.Column(db.Numeric(8, 0, asdecimal=False))
    hcjrcvolatility = db.Column(db.Numeric(10, 5))
    hcjrcspot = db.Column(db.Numeric(13, 5))
    hcjrcdelta = db.Column(db.Numeric(13, 5))
    hcjrcdeltanorme = db.Column(db.Numeric(13, 5))
    hcjrcgamma = db.Column(db.Numeric(13, 5))
    hcjrcvega = db.Column(db.Numeric(13, 5))
    hcjrcvegaweighed = db.Column(db.Numeric(13, 5))
    hcjrcsega = db.Column(db.Numeric(13, 5))
    hcjdeltapct = db.Column(db.Numeric(13, 5))
    hcjrcvegapdpct = db.Column(
        db.Numeric(13, 5),
        info="vega normé en devise du produit = (HCJRCVEGA / EMnominal) * 100 ",
    )


class Hcasptaux(db.Model):
    __tablename__ = "hcasptaux"
    __table_args__ = {"schema": "derives"}

    hctcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hctmodeut = db.Column(db.String(1), primary_key=True, nullable=False)
    hctprofilgcp = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcttypepricer = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hctsource = db.Column(db.String(1), primary_key=True, nullable=False)
    hcttype = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hctdev = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hctdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hctrcfxsensi = db.Column(db.Numeric(13, 5))
    hctrcrho = db.Column(db.Numeric(13, 5))
    hctrcrhopdpct = db.Column(
        db.Numeric(13, 5),
        info="rho norm¿ = (rho en devise du produit / EMnominal) * 100 ",
    )


class Hconvert(db.Model):
    __tablename__ = "hconvert"
    __table_args__ = {"schema": "derives"}

    hccfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    hcdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hcsproat = db.Column(db.Numeric(13, 5))
    hcrdtmaturite = db.Column(db.Numeric(13, 5))
    hcprimenette = db.Column(db.Numeric(13, 5))
    hcprimenettea = db.Column(db.Numeric(13, 5))
    hcdelta = db.Column(db.Numeric(13, 5))
    hcdeltanorme = db.Column(db.Numeric(13, 5))
    hcndelta = db.Column(db.String(1))
    hcrho = db.Column(db.Numeric(13, 5))
    hcnrho = db.Column(db.String(1))
    hcvaltheo = db.Column(db.Numeric(13, 5))
    hcnvaltheo = db.Column(db.String(1))
    hcdecote = db.Column(db.Numeric(13, 5))
    hcnote_spr = db.Column(db.String(32))
    hcnote_vol = db.Column(db.String(1))
    hcspr_ex = db.Column(db.Numeric(13, 5))
    hccrdiv_ex = db.Column(db.Numeric(13, 5))
    hcvol_ex = db.Column(db.Numeric(13, 5))
    hcrdtnetdiv_next = db.Column(db.Numeric(13, 5))
    hcrdtafdiv_next = db.Column(db.Numeric(13, 5))
    hctauxref = db.Column(db.Numeric(13, 5))
    hcvega = db.Column(db.Numeric(13, 5))
    hcnvega = db.Column(db.String(1))
    hcrkqds = db.Column(db.Numeric(13, 5))
    hcnrkqds = db.Column(db.String(1))
    hcvolimp = db.Column(db.Numeric(13, 5))
    hcbase = db.Column(db.Numeric(13, 5))
    hcvolmax_ex = db.Column(db.Numeric(13, 5))
    hctheta = db.Column(db.Numeric(13, 5))
    hcntheta = db.Column(db.String(1))
    hcgamma = db.Column(db.Numeric(13, 5))
    hcspreadimp = db.Column(db.Numeric(13, 5))
    hcgammaput = db.Column(db.Numeric(13, 5))
    hcthetaput = db.Column(db.Numeric(13, 5))
    hcdatedebput = db.Column(db.DateTime)
    hcrdtput = db.Column(db.Numeric(13, 5))
    hcrhoput = db.Column(db.Numeric(13, 5))
    hcdeltanormeput = db.Column(db.Numeric(13, 5))
    hcdeltaput = db.Column(db.Numeric(13, 5))
    hcrkqdsput = db.Column(db.Numeric(13, 5))
    hcsprput = db.Column(db.Numeric(13, 5))
    hctauxput = db.Column(db.Numeric(13, 5))
    hctempput = db.Column(db.Numeric(13, 5))
    hcdurationput = db.Column(db.Numeric(13, 5))
    hcduration = db.Column(db.Numeric(13, 5))
    hcmktcap = db.Column(db.Numeric(18, 2))
    hcprimebrute = db.Column(db.Numeric(13, 5))
    hcprimebrutea = db.Column(db.Numeric(13, 5))
    hcdirtyvalue = db.Column(db.Numeric(13, 5))
    hcdw10 = db.Column(db.Numeric(13, 5))
    hcdw10pb = db.Column(db.Numeric(13, 5))
    hcdw10put = db.Column(db.Numeric(13, 5))
    hcdw20 = db.Column(db.Numeric(13, 5))
    hcdw20pb = db.Column(db.Numeric(13, 5))
    hcdw20put = db.Column(db.Numeric(13, 5))
    hcup10 = db.Column(db.Numeric(13, 5))
    hcup10pb = db.Column(db.Numeric(13, 5))
    hcup10put = db.Column(db.Numeric(13, 5))
    hcup20 = db.Column(db.Numeric(13, 5))
    hcup20pb = db.Column(db.Numeric(13, 5))
    hcup20put = db.Column(db.Numeric(13, 5))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hconvert.hccfin == Instrument.ifcfin",
        backref="hconverts",
    )


class Hconvertible(db.Model):
    __tablename__ = "hconvertible"
    __table_args__ = {"schema": "derives"}

    hccfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    hcdate = db.Column(db.DateTime)
    hcsproat = db.Column(db.Numeric(13, 5))
    hcrdtmaturite = db.Column(db.Numeric(13, 5))
    hcprimenette = db.Column(db.Numeric(13, 5))
    hcprimenettea = db.Column(db.Numeric(13, 5))
    hcdelta = db.Column(db.Numeric(13, 5))
    hcdeltanorme = db.Column(db.Numeric(13, 5))
    hcndelta = db.Column(db.String(1))
    hcrho = db.Column(db.Numeric(13, 5))
    hcnrho = db.Column(db.String(1))
    hcvaltheo = db.Column(db.Numeric(13, 5))
    hcnvaltheo = db.Column(db.String(1))
    hcdecote = db.Column(db.Numeric(13, 5))
    hcnote_spr = db.Column(db.String(32))
    hcnote_vol = db.Column(db.String(1))
    hcspr_ex = db.Column(db.Numeric(13, 5))
    hccrdiv_ex = db.Column(db.Numeric(13, 5))
    hcvol_ex = db.Column(db.Numeric(13, 5))
    hcrdtnetdiv_next = db.Column(db.Numeric(13, 5))
    hcrdtafdiv_next = db.Column(db.Numeric(13, 5))
    hctauxref = db.Column(db.Numeric(13, 5))
    hcvega = db.Column(db.Numeric(13, 5))
    hcnvega = db.Column(db.String(1))
    hcvegapct = db.Column(db.Numeric(13, 5))
    hcrkqds = db.Column(db.Numeric(13, 5))
    hcnrkqds = db.Column(db.String(1))
    hcvolimp = db.Column(db.Numeric(13, 5))
    hcbase = db.Column(db.Numeric(18, 2))
    hcvolmax_ex = db.Column(db.Numeric(13, 5))
    hctheta = db.Column(db.Numeric(13, 5))
    hcntheta = db.Column(db.String(1))
    hcgamma = db.Column(db.Numeric(13, 5))
    hcspreadimp = db.Column(db.Numeric(13, 5))
    hcgammaput = db.Column(db.Numeric(13, 5))
    hcthetaput = db.Column(db.Numeric(13, 5))
    hcdatedebput = db.Column(db.DateTime)
    hcrdtput = db.Column(db.Numeric(13, 5))
    hcrhoput = db.Column(db.Numeric(13, 5))
    hcdeltanormeput = db.Column(db.Numeric(13, 5))
    hcdeltaput = db.Column(db.Numeric(13, 5))
    hcrkqdsput = db.Column(db.Numeric(13, 5))
    hcsprput = db.Column(db.Numeric(13, 5))
    hctauxput = db.Column(db.Numeric(13, 5))
    hctempput = db.Column(db.Numeric(13, 5))
    hcdurationput = db.Column(db.Numeric(13, 5))
    hcdurationcorrput = db.Column(db.Numeric(13, 5))
    hcduration = db.Column(db.Numeric(13, 5))
    hcdurationcorr = db.Column(db.Numeric(13, 5))
    hcmktcap = db.Column(db.Numeric(18, 2))
    hcprimebrute = db.Column(db.Numeric(13, 5))
    hcprimebrutea = db.Column(db.Numeric(13, 5))
    hcdirtyvalue = db.Column(db.Numeric(13, 5))
    hcdw10 = db.Column(db.Numeric(13, 5))
    hcdw10pb = db.Column(db.Numeric(13, 5))
    hcdw10put = db.Column(db.Numeric(13, 5))
    hcdw20 = db.Column(db.Numeric(13, 5))
    hcdw20pb = db.Column(db.Numeric(13, 5))
    hcdw20put = db.Column(db.Numeric(13, 5))
    hcup10 = db.Column(db.Numeric(13, 5))
    hcup10pb = db.Column(db.Numeric(13, 5))
    hcup10put = db.Column(db.Numeric(13, 5))
    hcup20 = db.Column(db.Numeric(13, 5))
    hcup20pb = db.Column(db.Numeric(13, 5))
    hcup20put = db.Column(db.Numeric(13, 5))
    hcbaisseptb = db.Column(db.Numeric(13, 5))
    hccoupcouru = db.Column(db.Numeric(13, 5))
    hcprixpiedcoup = db.Column(db.Numeric(13, 5))
    hcsensiaction = db.Column(db.Numeric(13, 5))
    hcsourcehyp = db.Column(db.String(36))
    hcdureevie = db.Column(db.Numeric(13, 5))


class Hconvertiblehyp(db.Model):
    __tablename__ = "hconvertiblehyp"
    __table_args__ = (
        db.CheckConstraint("hcHYPOTHESEDESC in (1,2)"),
        {"schema": "derives"},
    )

    hccfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    hcdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hchypothese = db.Column(
        db.ForeignKey("derives.convtypehypothese.hyptype"),
        primary_key=True,
        nullable=False,
        info="Hypohèse du jeu de paramètre lors de pricing",
    )
    hchypothesedesc = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="1 : VI 9 mois, 2 : moyenne VH"
    )
    hcmktcapini = db.Column(db.Numeric(18, 2))
    hcmktcap = db.Column(db.Numeric(18, 2))
    hcmktcapsj = db.Column(db.Numeric(18, 2))
    hccall = db.Column(db.Numeric(13, 5))
    hcdatedebcall = db.Column(db.DateTime)
    hcdatefincall = db.Column(db.DateTime)
    hctriggercall = db.Column(db.Numeric(13, 5))
    hccroisstrig = db.Column(db.Numeric(13, 5))
    hcnominal = db.Column(db.Numeric(18, 5))
    hcput = db.Column(db.Numeric(13, 5))
    hcdatedebput = db.Column(db.DateTime)
    hcdaterembo = db.Column(db.DateTime)
    hcprimerembo = db.Column(db.Numeric(13, 5))
    hcsj = db.Column(db.Numeric(13, 5))
    hcdr = db.Column(db.Numeric(13, 5))
    hccoupcouru = db.Column(db.Numeric(13, 5))
    hcprixpiedcoup = db.Column(db.Numeric(13, 5))
    hcduration = db.Column(db.Numeric(13, 5))
    hcdureevie = db.Column(db.Numeric(13, 5))
    hcpayback = db.Column(db.Numeric(13, 5))
    hcsproat = db.Column(db.Numeric(13, 5))
    hcrdtcall = db.Column(db.Numeric(13, 5))
    hcrdtput = db.Column(db.Numeric(13, 5))
    hcrdtmaturite = db.Column(db.Numeric(13, 5))
    hcrdtcourant = db.Column(db.Numeric(13, 5))
    hcprimebrute = db.Column(db.Numeric(13, 5))
    hcprimebrutea = db.Column(db.Numeric(13, 5))
    hcprimenette = db.Column(db.Numeric(13, 5))
    hcprimenettea = db.Column(db.Numeric(13, 5))
    hcvalactuflat = db.Column(db.Numeric(13, 5))
    hcvalactuptb = db.Column(db.Numeric(13, 5))
    hcbaisseflat = db.Column(db.Numeric(13, 5))
    hcbaisseptb = db.Column(db.Numeric(13, 5))
    hcdelta = db.Column(db.Numeric(13, 5))
    hcdeltanorme = db.Column(db.Numeric(13, 5))
    hcndelta = db.Column(db.String(1))
    hcdeltat = db.Column(db.Numeric(13, 5))
    hcrho = db.Column(db.Numeric(13, 5))
    hcnrho = db.Column(db.String(1))
    hcvaltheo = db.Column(db.Numeric(13, 5))
    hcnvaltheo = db.Column(db.String(1))
    hcdecote = db.Column(db.Numeric(13, 5))
    hcdw20 = db.Column(db.Numeric(13, 5))
    hcdw10 = db.Column(db.Numeric(13, 5))
    hcup10 = db.Column(db.Numeric(13, 5))
    hcup20 = db.Column(db.Numeric(13, 5))
    hcdw20pb = db.Column(db.Numeric(13, 5))
    hcdw10pb = db.Column(db.Numeric(13, 5))
    hcup10pb = db.Column(db.Numeric(13, 5))
    hcup20pb = db.Column(db.Numeric(13, 5))
    hcnote_spr = db.Column(db.String(32))
    hcnote_div = db.Column(db.String(1))
    hcnote_vol = db.Column(db.String(1))
    hcnote_rsk = db.Column(db.String(1))
    hcspr_ex = db.Column(db.Numeric(13, 5))
    hccrdiv_ex = db.Column(db.Numeric(13, 5))
    hcvol_ex = db.Column(db.Numeric(13, 5))
    hcvolmax_ex = db.Column(db.Numeric(13, 5))
    hctauxref = db.Column(db.Numeric(13, 5))
    hcmatref = db.Column(db.Numeric(13, 5))
    hcvega = db.Column(db.Numeric(13, 5))
    hcnvega = db.Column(db.String(1))
    hcrkqds = db.Column(db.Numeric(13, 5))
    hcnrkqds = db.Column(db.String(1))
    hcrkdiv = db.Column(db.Numeric(13, 5))
    hcnrkdiv = db.Column(db.String(1))
    hcsynthese = db.Column(db.Numeric(2, 0, asdecimal=False))
    hcdirtyvalue = db.Column(db.Numeric(13, 5))
    hctheta = db.Column(db.Numeric(13, 5))
    hcntheta = db.Column(db.String(1))
    hcvolimp = db.Column(db.Numeric(13, 5))
    hcvactptbmatu = db.Column(db.Numeric(13, 5))
    hcbaisseptbmatu = db.Column(db.Numeric(13, 5))
    hcdurationput = db.Column(db.Numeric(13, 5))
    hcvactptbput = db.Column(db.Numeric(13, 5))
    hcbaisseptbput = db.Column(db.Numeric(13, 5))
    hcsprput = db.Column(db.Numeric(13, 5))
    hctauxput = db.Column(db.Numeric(13, 5))
    hcvaltheoput = db.Column(db.Numeric(13, 5))
    hcvolimpput = db.Column(db.Numeric(13, 5))
    hcdeltaput = db.Column(db.Numeric(13, 5))
    hcdeltanormeput = db.Column(db.Numeric(13, 5))
    hcvegaput = db.Column(db.Numeric(13, 5))
    hcthetaput = db.Column(db.Numeric(13, 5))
    hcrhoput = db.Column(db.Numeric(13, 5))
    hcdw20put = db.Column(db.Numeric(13, 5))
    hcdw10put = db.Column(db.Numeric(13, 5))
    hcup10put = db.Column(db.Numeric(13, 5))
    hcup20put = db.Column(db.Numeric(13, 5))
    hcgamma = db.Column(db.Numeric(13, 5))
    hcgammaput = db.Column(db.Numeric(13, 5))
    hcrkqdsput = db.Column(db.Numeric(13, 5))
    hcspreadimp = db.Column(db.Numeric(13, 5))
    hcsensiaction = db.Column(db.Numeric(13, 5))
    hcrdtnetdiv_next = db.Column(db.Numeric(13, 5))
    hcrdtafdiv_next = db.Column(db.Numeric(13, 5))
    hcbase = db.Column(db.Numeric(18, 2))
    hcdurationcorr = db.Column(db.Numeric(13, 5), info="Duration corrigée")
    hcdurationcorrput = db.Column(db.Numeric(13, 5), info="Duration corrigée au Put")
    hcprixparite = db.Column(db.Numeric(13, 5), info="Parity")
    hccorrectvol = db.Column(db.Numeric(24, 7), info="Correcteur de volatilité")
    hcperfvi1d = db.Column(db.Numeric(24, 7), info="Perf VI 1 jour")
    hcperfvi1w = db.Column(db.Numeric(24, 7), info="Perf VI 1 semaine")
    hcperfvi1m = db.Column(db.Numeric(24, 7), info="Perf VI 1 mois")
    hcvegapct = db.Column(db.Numeric(13, 5), info="100*HCVEGA/HCDR")
    hctriggerpct = db.Column(
        db.Numeric(13, 5), info="trigger call * crossSjtoDer * parity * 100 / callvalue"
    )
    hcparity = db.Column(db.Numeric(13, 5), info="parity")
    hcvalactuptbclean = db.Column(db.Numeric(13, 5))
    hcbaisseptbclean = db.Column(db.Numeric(13, 5))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hconvertiblehyp.hccfin == Instrument.ifcfin",
        backref="hconvertiblehyps",
    )
    convtypehypothese = db.relationship(
        "Convtypehypothese",
        primaryjoin="Hconvertiblehyp.hchypothese == Convtypehypothese.hyptype",
        backref="hconvertiblehyps",
    )


class Hctd(db.Model):
    __tablename__ = "hctd"
    __table_args__ = {"schema": "derives"}

    hcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    hdate = db.Column(db.DateTime, nullable=False)
    hctd = db.Column(db.Numeric(8, 0, asdecimal=False))


class Hibe(db.Model):
    __tablename__ = "hibes"
    __table_args__ = {"schema": "derives"}

    hbcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hbdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hbdev = db.Column(db.Numeric(8, 0, asdecimal=False))
    hbpriceind = db.Column(db.Numeric(13, 5))
    hboutstanding = db.Column(db.Numeric(15, 0, asdecimal=False))
    hbdtendfiscy0 = db.Column(db.DateTime)
    hbeps0 = db.Column(db.Numeric(13, 5))
    hbdps0 = db.Column(db.Numeric(13, 5))
    hbdtendfiscy1 = db.Column(db.DateTime)
    hbeps1 = db.Column(db.Numeric(13, 5))
    hbdps1 = db.Column(db.Numeric(13, 5))
    hbnbeps1 = db.Column(db.Numeric(4, 0, asdecimal=False))
    hbnbdps1 = db.Column(db.Numeric(4, 0, asdecimal=False))
    hbdtendfiscy2 = db.Column(db.DateTime)
    hbeps2 = db.Column(db.Numeric(13, 5))
    hbdps2 = db.Column(db.Numeric(13, 5))
    hbnbeps2 = db.Column(db.Numeric(4, 0, asdecimal=False))
    hbnbdps2 = db.Column(db.Numeric(4, 0, asdecimal=False))
    hbdtendfiscy3 = db.Column(db.DateTime)
    hbeps3 = db.Column(db.Numeric(13, 5))
    hbdps3 = db.Column(db.Numeric(13, 5))
    hbnbeps3 = db.Column(db.Numeric(4, 0, asdecimal=False))
    hbnbdps3 = db.Column(db.Numeric(4, 0, asdecimal=False))
    hbdtendfiscy4 = db.Column(db.DateTime)
    hbeps4 = db.Column(db.Numeric(13, 5))
    hbdps4 = db.Column(db.Numeric(13, 5))
    hbnbeps4 = db.Column(db.Numeric(4, 0, asdecimal=False))
    hbnbdps4 = db.Column(db.Numeric(4, 0, asdecimal=False))


class Hidx(db.Model):
    __tablename__ = "hidx"
    __table_args__ = {"schema": "derives"}

    hixcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hixdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hixopen = db.Column(db.Numeric(asdecimal=False))
    hixclose = db.Column(db.Numeric(asdecimal=False))
    hixbase = db.Column(db.Numeric(asdecimal=False))
    hixdisp = db.Column(db.Numeric(10, 6))
    hixdisphebdo = db.Column(db.Numeric(10, 6))
    hixdisp1m = db.Column(db.Numeric(10, 6))
    hixdisp3m = db.Column(db.Numeric(10, 6))
    hixcorrmoy = db.Column(db.Numeric(10, 6))
    hixmoycorr = db.Column(db.Numeric(10, 6))
    hixvh = db.Column(db.Numeric(13, 5))
    hixmoyvh = db.Column(db.Numeric(13, 5))


class Hindicerisque(db.Model):
    __tablename__ = "hindicerisque"
    __table_args__ = {"schema": "derives"}

    hicfin = db.Column(db.ForeignKey("derives.indicerisque.ircfin"), nullable=False)
    hidate = db.Column(db.DateTime)
    hinb = db.Column(db.Numeric(9, 0, asdecimal=False))
    himediane = db.Column(db.Numeric(13, 5))
    himoyenne = db.Column(db.Numeric(13, 5))
    hidispersion = db.Column(db.Numeric(13, 5))

    indicerisque = db.relationship(
        "Indicerisque",
        primaryjoin="Hindicerisque.hicfin == Indicerisque.ircfin",
        backref="hindicerisques",
    )


class Hindivol(db.Model):
    __tablename__ = "hindivol"
    __table_args__ = {"schema": "derives"}

    hivcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de l'instrument financier",
    )
    hivmarche = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code marche",
    )
    hivdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="date de calcul"
    )
    hivvol = db.Column(db.Numeric(13, 5), info="volatilité agrégée pour le forward")
    hivnbop = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        info="nombre d options de l agrégation des volatilités pour le forward",
    )
    hivvol_up = db.Column(
        db.Numeric(13, 5), info="volatilité agrégée pour le forward up"
    )
    hivnbop_up = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        info="nombre d options de l agrégation des volatilités pour le forward up",
    )
    hivvol_dw = db.Column(
        db.Numeric(13, 5), info="volatilité agrégée pour le forward down"
    )
    hivnbop_dw = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        info="nombre d options de l agrégation des volatilités pour le forward down",
    )
    hivvolume = db.Column(db.Numeric(16, 5), info="volume agrégé des call et des put")
    hivpocall = db.Column(db.Numeric(18, 2), info="position ouverte agrégée des call")
    hivpoput = db.Column(db.Numeric(18, 2), info="position ouverte agrégée des put")
    hivvaleur = db.Column(db.Numeric(13, 5), info="valorisation théorique")
    hivvol_th = db.Column(db.Numeric(13, 5), info="vol th")


class Hirraggregation(db.Model):
    __tablename__ = "hirraggregation"
    __table_args__ = (
        db.CheckConstraint("HAGTYPEAGGR IN ('A','B')"),
        db.CheckConstraint("HAGTYPEUNIVERSE IN ('S','C')"),
        {"schema": "derives"},
    )

    hagdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    haguniverse = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hagrpu = db.Column(db.Numeric(13, 5))
    hagrfr = db.Column(db.Numeric(13, 5))
    hagmedianirr = db.Column(db.Numeric(13, 5))
    hagaverageirr = db.Column(db.Numeric(13, 5))
    hagwaverageirr = db.Column(db.Numeric(13, 5))
    hagmedianrp = db.Column(db.Numeric(13, 5))
    hagaveragerp = db.Column(db.Numeric(13, 5))
    hagwaveragerp = db.Column(db.Numeric(13, 5))
    hagmedianduration = db.Column(db.Numeric(13, 5))
    hagaverageduration = db.Column(db.Numeric(13, 5))
    hagwaverageduration = db.Column(db.Numeric(13, 5))
    haginputtype = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hagmodeltype = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hagratetype = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hagnbresociete = db.Column(db.Numeric(5, 0, asdecimal=False))
    hagtypeuniverse = db.Column(db.String(1), primary_key=True, nullable=False)
    hagtypeaggr = db.Column(db.String(1), primary_key=True, nullable=False)


class Hirrcompany(db.Model):
    __tablename__ = "hirrcompany"
    __table_args__ = {"schema": "derives"}

    hircdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hirccfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hircpo = db.Column(db.Numeric(13, 5))
    hirceps = db.Column(db.Numeric(13, 5))
    hircgst = db.Column(db.Numeric(13, 5))
    hircirr = db.Column(db.Numeric(13, 5))
    hircrp = db.Column(db.Numeric(13, 5))
    hircduration = db.Column(db.Numeric(13, 5))
    hircinputtype = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hircmodeltype = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hircratetype = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hircerreur = db.Column(db.String(36))
    hircpentecours = db.Column(db.Numeric(13, 5))
    hirccurvecours = db.Column(db.Numeric(13, 5))
    hircpenteeps = db.Column(db.Numeric(13, 5))
    hirccurveeps = db.Column(db.Numeric(13, 5))
    hircirreps = db.Column(db.Numeric(13, 5))
    hircvarimpl = db.Column(db.Numeric(13, 5))
    hircsommediv = db.Column(db.Numeric(13, 5))


class HobligOld(db.Model):
    __tablename__ = "hoblig_old"
    __table_args__ = {"schema": "derives"}

    hbcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    hbdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hbprix = db.Column(db.Numeric(13, 5))
    hbrdt = db.Column(db.Numeric(13, 5))
    hbspr_ex = db.Column(db.Numeric(13, 5))
    hbnote_ex = db.Column(db.String(4))
    hbspread = db.Column(db.Numeric(13, 5))
    hbduration = db.Column(db.Numeric(13, 5))
    hbecart_prix = db.Column(db.Numeric(13, 5))
    hbecart_rdt = db.Column(db.Numeric(13, 5))
    hberreur = db.Column(db.Numeric(13, 5))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="HobligOld.hbcfin == Instrument.ifcfin",
        backref="hoblig_olds",
    )


class Hobligation(db.Model):
    __tablename__ = "hobligation"
    __table_args__ = {"schema": "derives"}

    hbcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="CFIN",
    )
    hbdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date de calcul"
    )
    hbmktcap = db.Column(
        db.Numeric(18, 2),
        info="Cours dirty en devise * nb titres, converti en USD (idem cvmktcap)",
    )
    hbprix = db.Column(db.Numeric(13, 5), info="moyenne bid / ask du prix")
    hbcouponcouru = db.Column(
        db.Numeric(13, 5), info="TI_COUPON_COURU (idem cvcouponcouru)"
    )
    hbrdt = db.Column(
        db.Numeric(13, 5), info="TI_TAUX_RDT_ACTUARIEL (idem cvrdtmaturite)"
    )
    hbspr_ex = db.Column(db.Numeric(13, 5), info="null par défaut (hyp. de spread)")
    hbsecteur = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="secteur de l émetteur (si null, secteur du garant)",
    )
    hberreur = db.Column(db.Numeric(13, 5), info="ecart mid rendement vs bbrdt")
    hbspread = db.Column(db.Numeric(13, 5), info="ecart bbrdt vs bbtauxref")
    hbduration = db.Column(db.Numeric(13, 5), info="TI_DURATION (idem cvduration)")
    hbecart_prix = db.Column(db.Numeric(13, 5), info="ecart bid ask du prix")
    hbecart_rdt = db.Column(db.Numeric(13, 5), info="ecart bid ask du rendement")
    hbdaterembo = db.Column(db.DateTime, info="date de remboursement")
    hbprimerembo = db.Column(db.Numeric(13, 5), info="prime de remboursement")
    hbmontant = db.Column(db.Numeric(13, 5), info="montant du prochain coupon")
    hbremb = db.Column(db.Numeric(13, 5), info="montant de remboursement à échéance")
    hbprixpiedcoup = db.Column(
        db.Numeric(13, 5), info="prix pied de coupon (prix en % hors coupon couru)"
    )
    hbdirtyvalule = db.Column(
        db.Numeric(13, 5),
        info="prix en devise coupon couru inclus, converti en EUR (idem cvdirtyvalue)",
    )
    hbdureevie = db.Column(db.Numeric(13, 5), info="durée de vie restante (nb jours)")
    hbrdtcourant = db.Column(
        db.Numeric(13, 5),
        info="somme coupon(s) à venir sur un an glissant / bbdirtyvalue * 100",
    )
    hbrho = db.Column(db.Numeric(13, 5), info="TI_RHO (sensi. Taux ; idem CVRHO)")
    hbnrho = db.Column(db.String(1), info="note sensi. Taux (idem CVNRHO)")
    hbtauxref = db.Column(
        db.Numeric(13, 5), info='taux "CP" à duration en nb jours (bbduration * 365.25)'
    )
    hbrdtcall = db.Column(
        db.Numeric(13, 5), info="rendement actuariel si la prochain call est exercé"
    )
    hbdurationcall = db.Column(
        db.Numeric(13, 5), info="duration si le prochain call est exercé"
    )
    hbtotalreturn = db.Column(
        db.Numeric(13, 5), info="rendement coupon(s) réinvesti(s)"
    )
    hbrdtrecup = db.Column(db.Numeric(13, 5), info="Taux Mid recupere")
    hbdurationrecup = db.Column(db.Numeric(13, 5), info="Duration recuperee")
    hbcouponcoururecup = db.Column(db.Numeric(13, 5), info="Coupon couru recupere")
    hbspreadrecup = db.Column(
        db.Numeric(16, 5),
        info="Spread entre le rendement de l obligation et le taux swap",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hobligation.hbcfin == Instrument.ifcfin",
        backref="hobligations",
    )


class HobligationBloom(db.Model):
    __tablename__ = "hobligation_bloom"
    __table_args__ = {"schema": "derives"}

    hbbcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        index=True,
        info="CFin de l'obligation",
    )
    hbbdate = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Date d'historisation des informations concernant l'obligation",
    )
    hbbyld_ytm_bid = db.Column(db.Numeric(13, 5), info="Yield To Maturity - BID")
    hbbyld_ytm_mid = db.Column(db.Numeric(13, 5), info="Yield To Maturity - MID")
    hbbyld_ytm_ask = db.Column(db.Numeric(13, 5), info="Yield To Maturity - ASK\t")
    hbbyld_ytc_bid = db.Column(db.Numeric(13, 5), info="Yield To Call - BID\t")
    hbbyld_ytc_mid = db.Column(db.Numeric(13, 5), info="Yield To Call - MID\t")
    hbbyld_ytc_ask = db.Column(db.Numeric(13, 5), info="Yield To Call - ASK\t")
    hbbyas_bond_yld = db.Column(
        db.Numeric(13, 5),
        info='Yield sur YAS\tForcer le recalcul avec le prix de cloture ; [FORCED_FLD]="YAS_BOND_PX" ; [FORCED_VALUE]=Prix de clôture sur BGN (puis CBBT si pas de prix BGN et enfin BVAL)',
    )
    hbbdur_bid = db.Column(db.Numeric(13, 5), info="Macaulay Duration To Worst - BID")
    hbbdur_mid = db.Column(db.Numeric(13, 5), info="Macaulay Duration To Worst - MID")
    hbbdur_ask = db.Column(db.Numeric(13, 5), info="Macaulay Duration To Worst - ASK")
    hbbmty_dur_bid = db.Column(
        db.Numeric(13, 5), info="Macaulay Duration To Maturity - BID"
    )
    hbbmty_dur_mid = db.Column(
        db.Numeric(13, 5), info="Macaulay Duration To Maturity - MID"
    )
    hbbmty_dur_ask = db.Column(
        db.Numeric(13, 5), info="Macaulay Duration To Maturity - ASK\t"
    )
    hbbdur_adj_bid = db.Column(
        db.Numeric(13, 5), info="Adjusted Duration To Worst - BID"
    )
    hbbdur_adj_mid = db.Column(
        db.Numeric(13, 5), info="Adjusted Duration To Worst - MID"
    )
    hbbdur_adj_ask = db.Column(
        db.Numeric(13, 5), info="Adjusted Duration To Worst - ASK"
    )
    hbbdur_adj_mty_bid = db.Column(
        db.Numeric(13, 5), info="Adjusted Duration To Maturity - BID"
    )
    hbbdur_adj_mty_mid = db.Column(
        db.Numeric(13, 5), info="Adjusted Duration To Maturity - MID"
    )
    hbbdur_adj_mty_ask = db.Column(
        db.Numeric(13, 5), info="Adjusted Duration To Maturity - ASK"
    )
    hbbdur_adj_oas_bid = db.Column(
        db.Numeric(13, 5), info="OAS Effective Duration - BID"
    )
    hbbdur_adj_oas_mid = db.Column(
        db.Numeric(13, 5), info="OAS Effective Duration - MID"
    )
    hbbdur_adj_oas_ask = db.Column(
        db.Numeric(13, 5), info="OAS Effective Duration - ASK"
    )
    hbbyas_mod_dur = db.Column(
        db.Numeric(13, 5),
        info='Modified Duration sur YAS\tForcer le recalcul avec le prix de cloture ; [FORCED_FLD]="YAS_BOND_PX" ; [FORCED_VALUE]=Prix de clôture sur BGN (puis CBBT si pas de prix BGN et enfin BVAL)',
    )
    hbbrisk_bid = db.Column(db.Numeric(13, 5), info="Sensibilité Spread au Worst - BID")
    hbbrisk_mid = db.Column(db.Numeric(13, 5), info="Sensibilité Spread au Worst - MID")
    hbbrisk_ask = db.Column(db.Numeric(13, 5), info="Sensibilité Spread au Worst - ASK")
    hbbrisk_mty_bid = db.Column(
        db.Numeric(13, 5), info="Sensibilité Spread à Maturité - BID"
    )
    hbbrisk_mty_mid = db.Column(
        db.Numeric(13, 5), info="Sensibilité Spread à Maturité - MID"
    )
    hbbrisk_mty_ask = db.Column(
        db.Numeric(13, 5), info="Sensibilité Spread à Maturité - ASK"
    )
    hbbrisk_oas_bid = db.Column(db.Numeric(13, 5), info="OAS Spread Risk - BID")
    hbbrisk_oas_mid = db.Column(db.Numeric(13, 5), info="OAS Spread Risk - MID")
    hbbrisk_oas_ask = db.Column(db.Numeric(13, 5), info="OAS Spread Risk - ASK")
    hbbyas_risk = db.Column(
        db.Numeric(13, 5),
        info='Sensibilité Spread sur YAS\tForcer le recalcul avec le prix de cloture ; [FORCED_FLD]="YAS_BOND_PX" ; [FORCED_VALUE]=Prix de clôture sur BGN (puis CBBT si pas de prix BGN et enfin BVAL)',
    )
    hbbyas_asw_spread = db.Column(
        db.Numeric(16, 5),
        info='Asset Swap Spread sur YAS\tForcer le recalcul avec le prix de cloture ; [FORCED_FLD]="YAS_BOND_PX" ; [FORCED_VALUE]=Prix de clôture sur BGN (puis CBBT si pas de prix BGN et enfin BVAL)',
    )
    hbbyas_oas_spread = db.Column(
        db.Numeric(16, 5),
        info='OAS Spread sur YAS\tForcer le recalcul avec le prix de cloture ; [FORCED_FLD]="YAS_BOND_PX" ; [FORCED_VALUE]=Prix de clôture sur BGN (puis CBBT si pas de prix BGN et enfin BVAL)',
    )
    hbbyas_yld_spread = db.Column(
        db.Numeric(16, 5),
        info='Yield sur YAS\tForcer le recalcul avec le prix de cloture ; [FORCED_FLD]="YAS_BOND_PX" ; [FORCED_VALUE]=Prix de clôture sur BGN (puis CBBT si pas de prix BGN et enfin BVAL)',
    )
    hbbyas_zspread = db.Column(
        db.Numeric(16, 5),
        info='Z Spread sur YAS\tForcer le recalcul avec le prix de cloture ; [FORCED_FLD]="YAS_BOND_PX" ; [FORCED_VALUE]=Prix de clôture sur BGN (puis CBBT si pas de prix BGN et enfin BVAL)',
    )
    hbbyas_ispread = db.Column(
        db.Numeric(16, 5),
        info='I Spread sur YAS\tForcer le recalcul avec le prix de cloture ; [FORCED_FLD]="YAS_BOND_PX" ; [FORCED_VALUE]=Prix de clôture sur BGN (puis CBBT si pas de prix BGN et enfin BVAL)',
    )
    hbbyas_ispread_to_govt = db.Column(
        db.Numeric(16, 5),
        info='G Spread sur YAS\tForcer le recalcul avec le prix de cloture ; [FORCED_FLD]="YAS_BOND_PX" ; [FORCED_VALUE]=Prix de clôture sur BGN (puis CBBT si pas de prix BGN et enfin BVAL)',
    )
    hbbpx_last_bgn = db.Column(
        db.Numeric(13, 5),
        info="Prix de clôture sur BGN\tForcer le contributeur sur BGN",
    )
    hbbpx_last_cbbt = db.Column(
        db.Numeric(13, 5),
        info="Prix de clôture sur CBBT\tForcer le contributeur sur CBBT",
    )
    hbbpx_last_bval = db.Column(
        db.Numeric(13, 5),
        info="Prix de clôture sur BVAL\tForcer le contributeur sur BVAL",
    )
    hbbnxt_call_dt = db.Column(db.DateTime, info="Prochaine date de Call")
    hbbpx_bid_bgn = db.Column(db.Numeric(13, 5), info="PX_BID sur le contributeur BGN")
    hbbpx_ask_bgn = db.Column(db.Numeric(13, 5), info="PX_ASK sur le contributeur BGN")
    hbbpx_bid_cbbt = db.Column(
        db.Numeric(13, 5), info="PX_BID sur le contributeur CBBT"
    )
    hbbpx_ask_cbbt = db.Column(
        db.Numeric(13, 5), info="PX_ASK sur le contributeur CBBT"
    )
    hbbpx_bid_bval = db.Column(
        db.Numeric(13, 5), info="PX_BID sur le contributeur BVAL"
    )
    hbbpx_ask_bval = db.Column(
        db.Numeric(13, 5), info="PX_ASK sur le contributeur BVAL"
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="HobligationBloom.hbbcfin == Instrument.ifcfin",
        backref="hobligation_blooms",
    )


class Hoption(Base):
    __tablename__ = "hoption"
    __table_args__ = {"schema": "derives"}

    hpcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    hpdate = db.Column(db.DateTime, nullable=False)
    hpdatematu = db.Column(db.DateTime, nullable=False)
    hpstrike = db.Column(db.Numeric(13, 5), nullable=False)
    hpextype = db.Column(db.String(1), nullable=False)
    hpechtype = db.Column(db.String(1))
    hpbidcall = db.Column(db.Numeric(13, 5))
    hpaskcall = db.Column(db.Numeric(13, 5))
    hpbidput = db.Column(db.Numeric(13, 5))
    hpaskput = db.Column(db.Numeric(13, 5))
    hpprixsj = db.Column(db.Numeric(13, 5))
    hpprixsjmoy = db.Column(db.Numeric(13, 5))
    hpvbs = db.Column(db.Numeric(13, 5))
    hppocall = db.Column(db.Numeric(13, 5))
    hpvolqutecall = db.Column(db.Numeric(13, 5))
    hppoput = db.Column(db.Numeric(13, 5))
    hpvolquteput = db.Column(db.Numeric(13, 5))
    hptaux = db.Column(db.Numeric(asdecimal=False))
    hpflag_etat = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    hpclosing = db.Column(db.Numeric(13, 5))
    hpfiltre = db.Column(db.Numeric(2, 0, asdecimal=False))
    hpvatmf = db.Column(db.Numeric(13, 5))
    hpquotite = db.Column(db.Numeric(13, 5))


class Hoptionb(db.Model):
    __tablename__ = "hoptionb"
    __table_args__ = {"schema": "derives"}

    hpcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    hpdate = db.Column(db.DateTime, nullable=False)
    hpdatematu = db.Column(db.DateTime, nullable=False)
    hpstrike = db.Column(db.Numeric(13, 5), nullable=False)
    hpextype = db.Column(db.String(1), nullable=False)
    hpechtype = db.Column(db.String(1))
    hpquotite = db.Column(db.Numeric(13, 5))
    hpprixsj = db.Column(db.Numeric(13, 5))
    hpprixsjmoy = db.Column(db.Numeric(13, 5))
    hpclosing = db.Column(db.Numeric(13, 5))
    hpcallcomp = db.Column(db.Numeric(13, 5))
    hpputcomp = db.Column(db.Numeric(13, 5))
    hpaskcall = db.Column(db.Numeric(13, 5))
    hpbidcall = db.Column(db.Numeric(13, 5))
    hpaskput = db.Column(db.Numeric(13, 5))
    hpbidput = db.Column(db.Numeric(13, 5))
    hppocall = db.Column(db.Numeric(13, 5))
    hpvolqutecall = db.Column(db.Numeric(13, 5))
    hppoput = db.Column(db.Numeric(13, 5))
    hpvolquteput = db.Column(db.Numeric(13, 5))
    hptaux = db.Column(db.Numeric(asdecimal=False))
    hpflag_etat = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    hpfiltre = db.Column(db.Numeric(2, 0, asdecimal=False))
    hpvatmf = db.Column(db.Numeric(13, 5))
    hpvbs = db.Column(db.Numeric(13, 5))
    hprepo = db.Column(db.Numeric(13, 5))
    hpcallprice = db.Column(db.Numeric(13, 5))
    hpputprice = db.Column(db.Numeric(13, 5))
    hpcount = db.Column(db.Numeric(asdecimal=False))
    hptime = db.Column(db.Numeric(asdecimal=False))
    hperror = db.Column(db.Numeric(asdecimal=False))


class Hoption(db.Model):
    __tablename__ = "hoptions"
    __table_args__ = (
        db.CheckConstraint("HOEXTYPE IN ('A','E')"),
        {"schema": "derives"},
    )

    hocfincall = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="SET NULL"),
        index=True,
        info="CFIN Call",
    )
    hocfinput = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="SET NULL"),
        index=True,
        info="CFIN Put",
    )
    homarche = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="Marché des Options",
    )
    hocfinsj = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="CFIN Sous-Jacent",
    )
    hodatecalcul = db.Column(
        db.DateTime, nullable=False, index=True, info="Date de Calcul"
    )
    homaturite = db.Column(db.DateTime, nullable=False, info="Maturité Options")
    hostrike = db.Column(db.Numeric(13, 5), nullable=False, info="Strike")
    hoextype = db.Column(db.String(1), nullable=False, info="Type d'exerçabilité")
    hoquotite = db.Column(db.Numeric(13, 5), info="Quotité")
    hocourssj = db.Column(db.Numeric(13, 5), info="Cours du sous-jacent")
    hocourscall = db.Column(db.Numeric(13, 5), info="Cours de compens Call")
    hocoursput = db.Column(db.Numeric(13, 5), info="Cours de compens Put")
    hobidcall = db.Column(db.Numeric(13, 5), info="Bid du Call")
    hoaskcall = db.Column(db.Numeric(13, 5), info="Ask du Call")
    hobidput = db.Column(db.Numeric(13, 5), info="Bid du Put")
    hoaskput = db.Column(db.Numeric(13, 5), info="Ask du Put")
    hopocall = db.Column(db.Numeric(13, 5), info="Position ouverte Call")
    hovolumecall = db.Column(db.Numeric(13, 5), info="Volume Call")
    hopoput = db.Column(db.Numeric(13, 5), info="Position ouverte Put")
    hovolumeput = db.Column(db.Numeric(13, 5), info="Volume PUT")
    hoprofil = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="Profil de Calcul (PROFILCALCUL)",
    )
    hofiltre = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        info="Flag (-2 si xxxPRICE échoué; -1 si aucune paire CP sur la maturité)",
    )
    hovolmoney = db.Column(
        db.Numeric(13, 5), info="Vol At The Money Forward (ie:Strike<-Forward)"
    )
    hovolimp = db.Column(db.Numeric(13, 5), info="Volatilité implicite")
    hotauxrepo = db.Column(db.Numeric(13, 5), info="Taux de Repo implicite")
    hocallprice = db.Column(
        db.Numeric(13, 5), info="Prix théorique Call avec VI et Taux de Repo Implicite"
    )
    hoputprice = db.Column(
        db.Numeric(13, 5), info="Prix théorique Put avec VI et Taux de Repo Implicite"
    )
    hoforward = db.Column(db.Numeric(13, 5), info="forward")
    hosource = db.Column(
        db.ForeignKey("exane.source.socode"), info="Source de recuperation"
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hoption.hocfincall == Instrument.ifcfin",
        backref="instrument_instrument_hoptions",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Hoption.hocfinput == Instrument.ifcfin",
        backref="instrument_instrument_hoptions_0",
    )
    instrument2 = db.relationship(
        "Instrument",
        primaryjoin="Hoption.hocfinsj == Instrument.ifcfin",
        backref="instrument_instrument_hoptions",
    )
    source = db.relationship(
        "Source", primaryjoin="Hoption.hosource == Source.socode", backref="hoptions"
    )


class Hoptionsparam(db.Model):
    __tablename__ = "hoptionsparam"
    __table_args__ = {"schema": "derives"}

    hpcfinsj = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="Sjac",
    )
    hpmarche = db.Column(
        db.ForeignKey("exane.marche.macode"),
        primary_key=True,
        nullable=False,
        info="March‚ option",
    )
    hpdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date valeur"
    )
    hpprofil = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Profil de calcul",
    )
    hpmaturite = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Maturit‚ option"
    )
    hpidsession = db.Column(
        db.ForeignKey("exane_batch.appsession.asidsession"),
        nullable=False,
        info="Session de calcul",
    )
    hpsumdiv = db.Column(db.Numeric(13, 5), info="Somme des divs")
    hpsumdivdy = db.Column(db.Numeric(13, 5), info="Somme des divs Delay")
    hpzerocoupon = db.Column(db.Numeric(13, 5), info="ZeroCoupon de la maturite")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hoptionsparam.hpcfinsj == Instrument.ifcfin",
        backref="hoptionsparams",
    )
    appsession = db.relationship(
        "Appsession",
        primaryjoin="Hoptionsparam.hpidsession == Appsession.asidsession",
        backref="hoptionsparams",
    )
    marche = db.relationship(
        "Marche",
        primaryjoin="Hoptionsparam.hpmarche == Marche.macode",
        backref="hoptionsparams",
    )


class Hoptionstrike(db.Model):
    __tablename__ = "hoptionstrike"
    __table_args__ = {"schema": "derives"}

    hscfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="Cfin du sous-jacent",
    )
    hsmarche = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Marche option",
    )
    hsstrike = db.Column(
        db.Numeric(13, 5), primary_key=True, nullable=False, info="Strike"
    )
    hsdatedebut = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date de creation"
    )
    hsdatefin = db.Column(db.DateTime, info="Date de suppression")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hoptionstrike.hscfin == Instrument.ifcfin",
        backref="hoptionstrikes",
    )


class Hrecupop(db.Model):
    __tablename__ = "hrecupop"
    __table_args__ = (
        db.CheckConstraint("HRCALLPUT IN ('C','P')"),
        db.CheckConstraint("HREXTYPE IN ('A','E')"),
        {"schema": "derives"},
    )

    hrcfinsj = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Cfin du sous-jacent de l'option",
    )
    hrmarche = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Marché de l'option",
    )
    hrsource = db.Column(
        db.ForeignKey("exane.source.socode"),
        primary_key=True,
        nullable=False,
        info="Source de récupération",
    )
    hrdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date de valeur"
    )
    hrmaturite = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Maturité"
    )
    hrstrike = db.Column(
        db.Numeric(13, 5), primary_key=True, nullable=False, info="Strike"
    )
    hrextype = db.Column(
        db.String(1), primary_key=True, nullable=False, info="Type d'exercabilité"
    )
    hrquotite = db.Column(
        db.Numeric(13, 5), primary_key=True, nullable=False, info="Quotité"
    )
    hrcallput = db.Column(
        db.String(1), primary_key=True, nullable=False, info="Type d'option C ou P"
    )
    hrpriop = db.Column(db.Numeric(13, 5), info="Prix d'option")
    hrbid = db.Column(db.Numeric(13, 5), info="Bid")
    hrask = db.Column(db.Numeric(13, 5), info="Ask")
    hrprisj = db.Column(db.Numeric(13, 5), info="Prix du sous-jacent")
    hrvolimp = db.Column(db.Numeric(5, 2), info="Volatilité implicite")
    hrvaltheo = db.Column(db.Numeric(13, 5), info="Valeur théorique")
    hrpo = db.Column(db.Numeric(12, 0, asdecimal=False), info="Position ouverte")
    hrvolqute = db.Column(db.Numeric(16, 0, asdecimal=False), info="Volume")
    hrvolcapi = db.Column(db.Numeric(16, 0, asdecimal=False), info="Capi")
    hrlasttradedate = db.Column(db.DateTime, info="date du dernier trade sur l option")

    source = db.relationship(
        "Source", primaryjoin="Hrecupop.hrsource == Source.socode", backref="hrecupops"
    )


class Hrecupoption(db.Model):
    __tablename__ = "hrecupoption"
    __table_args__ = {"schema": "derives"}

    hrcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        info="Cfin de l'option",
    )
    hrsource = db.Column(
        db.ForeignKey("exane.source.socode"),
        primary_key=True,
        nullable=False,
        info="Source de récupération",
    )
    hrdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, index=True, info="Date de valeur"
    )
    hridsession = db.Column(
        db.ForeignKey("exane_batch.appsession.asidsession"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Identifiant de la session de récupération",
    )
    hrmarche = db.Column(
        db.Numeric(8, 0, asdecimal=False), index=True, info="Marché de l'option"
    )
    hrpriop = db.Column(db.Numeric(13, 5), info="Prix d'option")
    hropen = db.Column(db.Numeric(13, 5), info="Cours d'ouverture de l'option")
    hrclose = db.Column(db.Numeric(13, 5), info="Cours de fermeture de l'option")
    hrlast = db.Column(db.Numeric(13, 5), info="Dernier cours de l'option")
    hrsettle = db.Column(db.Numeric(13, 5), info="Cours de compensation de l'option")
    hrbid = db.Column(db.Numeric(13, 5), info="Bid")
    hrask = db.Column(db.Numeric(13, 5), info="Ask")
    hrbidvolume = db.Column(db.Numeric(13, 5), info="Volume du Bid")
    hraskvolume = db.Column(db.Numeric(13, 5), info="Volume du Ask")
    hrprisj = db.Column(db.Numeric(13, 5), info="Prix du sous-jacent")
    hrvolimp = db.Column(db.Numeric(5, 2), info="Volatilité implicite")
    hrvaltheo = db.Column(db.Numeric(13, 5), info="Valeur théorique")
    hrpo = db.Column(db.Numeric(12, 0, asdecimal=False), info="Position ouverte")
    hrvolqute = db.Column(db.Numeric(16, 0, asdecimal=False), info="Volume")
    hrvolcapi = db.Column(db.Numeric(16, 0, asdecimal=False), info="Capi")
    hrlasttradedate = db.Column(db.DateTime, info="date du dernier trade sur l option")
    hrdev = db.Column(db.Numeric(8, 0, asdecimal=False), info="Devise de l'option")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hrecupoption.hrcfin == Instrument.ifcfin",
        backref="hrecupoptions",
    )
    appsession = db.relationship(
        "Appsession",
        primaryjoin="Hrecupoption.hridsession == Appsession.asidsession",
        backref="hrecupoptions",
    )
    source = db.relationship(
        "Source",
        primaryjoin="Hrecupoption.hrsource == Source.socode",
        backref="hrecupoptions",
    )


class Hrejetoption(db.Model):
    __tablename__ = "hrejetoption"
    __table_args__ = {"schema": "derives"}

    rjcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        info="Cfin de l'option",
    )
    rjsource = db.Column(
        db.ForeignKey("exane.source.socode"),
        primary_key=True,
        nullable=False,
        info="Source de récupération",
    )
    rjmarche = db.Column(
        db.Numeric(8, 0, asdecimal=False), index=True, info="Marché de l'option"
    )
    rjdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, index=True, info="Date de valeur"
    )
    rjidsession = db.Column(
        db.ForeignKey("exane_batch.appsession.asidsession"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Identifiant de la session de récupération",
    )
    rjtype = db.Column(db.Numeric(9, 0, asdecimal=False), info="Type d'erreur")
    rjmsgid = db.Column(
        db.ForeignKey("exane.hrejetmessage.rmid"), info="Id du message d'erreur"
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hrejetoption.rjcfin == Instrument.ifcfin",
        backref="hrejetoptions",
    )
    appsession = db.relationship(
        "Appsession",
        primaryjoin="Hrejetoption.rjidsession == Appsession.asidsession",
        backref="hrejetoptions",
    )
    hrejetmessage = db.relationship(
        "Hrejetmessage",
        primaryjoin="Hrejetoption.rjmsgid == Hrejetmessage.rmid",
        backref="hrejetoptions",
    )
    source = db.relationship(
        "Source",
        primaryjoin="Hrejetoption.rjsource == Source.socode",
        backref="hrejetoptions",
    )


class Hrix(db.Model):
    __tablename__ = "hrix"
    __table_args__ = {"schema": "derives"}

    hixcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Date valeur",
    )
    hixdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date valeur"
    )
    hixopen = db.Column(db.Numeric(asdecimal=False), info="Valeur d'ouverture")
    hixclose = db.Column(db.Numeric(asdecimal=False), info="Valeur de cloture")
    hixbase = db.Column(db.Numeric(asdecimal=False), info="Base indice")
    hixscript = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        info="ID script utilise pour le calcul d'indice",
    )
    hixsessionid = db.Column(
        db.ForeignKey("exane_batch.appsession.asidsession"),
        info="ID session batch qui a calcule l'indice",
    )

    appsession = db.relationship(
        "Appsession",
        primaryjoin="Hrix.hixsessionid == Appsession.asidsession",
        backref="hrixes",
    )


class HrixPr(db.Model):
    __tablename__ = "hrix_pr"
    __table_args__ = {"schema": "derives"}

    hixcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Date valeur",
    )
    hixdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date valeur"
    )
    hixopen = db.Column(db.Numeric(asdecimal=False), info="Valeur d'ouverture")
    hixclose = db.Column(db.Numeric(asdecimal=False), info="Valeur de cloture")
    hixbase = db.Column(db.Numeric(asdecimal=False), info="Base indice")
    hixscript = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        info="ID script utilise pour le calcul d'indice",
    )
    hixsessionid = db.Column(
        db.Numeric(9, 0, asdecimal=False),
        info="ID session batch qui a calcule l'indice",
    )


class Hsaut(db.Model):
    __tablename__ = "hsaut"
    __table_args__ = {"schema": "derives"}

    pscfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    psdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    psvhc3m = db.Column(db.Numeric(13, 5))
    psvhc1a = db.Column(db.Numeric(13, 5))
    pstalpha = db.Column(db.Numeric(13, 5))
    psamplitude = db.Column(db.Numeric(13, 5))
    psamplitude_ec = db.Column(db.Numeric(13, 5))
    pschocs = db.Column(db.Numeric(13, 5))
    pschocs_ec = db.Column(db.Numeric(13, 5))
    psnbchocs = db.Column(db.Numeric(13, 5))
    psprobsembas = db.Column(db.Numeric(13, 5))
    psprobsemhaut = db.Column(db.Numeric(13, 5))
    pssig0 = db.Column(db.Numeric(13, 5))
    pssiginf = db.Column(db.Numeric(13, 5))
    psb = db.Column(db.Numeric(13, 5))
    psm = db.Column(db.Numeric(13, 5))
    psgamma = db.Column(db.Numeric(13, 5))
    pserreur = db.Column(db.Numeric(13, 5))
    psnbdata = db.Column(db.Numeric(6, 0, asdecimal=False))
    psminnbjours = db.Column(db.Numeric(6, 0, asdecimal=False))
    psvhcmin = db.Column(db.Numeric(13, 5))
    psmaxnbjours = db.Column(db.Numeric(6, 0, asdecimal=False))
    psvhcmax = db.Column(db.Numeric(13, 5))
    psnboptim = db.Column(db.Numeric(6, 0, asdecimal=False))
    psflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    psexvarsaut3m = db.Column(db.Numeric(13, 5))
    psexvarsaut1a = db.Column(db.Numeric(13, 5))
    psexvarsautmoy3m = db.Column(db.Numeric(13, 5))
    psexvarsautmoy1a = db.Column(db.Numeric(13, 5))

    instrument = db.relationship(
        "Instrument", primaryjoin="Hsaut.pscfin == Instrument.ifcfin", backref="hsauts"
    )


class Hsmile(db.Model):
    __tablename__ = "hsmiles"
    __table_args__ = {"schema": "derives"}

    smcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="cfin du sous-jacent",
    )
    smmarche = db.Column(
        db.ForeignKey("exane.marche.macode"), nullable=False, index=True
    )
    smdate = db.Column(db.DateTime, nullable=False, index=True, info="date de calcul")
    smdatematu = db.Column(db.DateTime, nullable=False, info="date de maturité réelle")
    smnbjours = db.Column(
        db.Numeric(6, 0, asdecimal=False), info="date de maturité en jours"
    )
    smforward = db.Column(db.Numeric(13, 5), info="forward à smdatematu")
    smvatm = db.Column(db.Numeric(13, 5), info="niveau de volatilité à la monnaie spot")
    smsmile = db.Column(
        db.Numeric(13, 5), info="écart des point de volatilité à +/- 5% de smforward"
    )
    smcurve = db.Column(db.Numeric(13, 5), info="curve")
    smerreur = db.Column(db.Numeric(13, 5), info="erreur moyenne quadratique")
    smnbdata = db.Column(
        db.Numeric(6, 0, asdecimal=False), info="nombre de strike utilisés"
    )
    smnboptim = db.Column(
        db.Numeric(6, 0, asdecimal=False), info="nombre itérations pour converger"
    )
    smflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="(1,7,0:données courantes;2,3:paramètres normalisés (1m,2m,3m,4m,6m,9m,1y,2y,3y);4,5,6:moyenne glissante)",
    )
    smncode = db.Column(db.Numeric(5, 0, asdecimal=False), info="code erreur")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hsmile.smcfin == Instrument.ifcfin",
        backref="hsmiles",
    )
    marche = db.relationship(
        "Marche", primaryjoin="Hsmile.smmarche == Marche.macode", backref="hsmiles"
    )


class Hsolvency2(db.Model):
    __tablename__ = "hsolvency2"
    __table_args__ = {"schema": "derives"}

    socfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="Cfin de l instrument",
    )
    sodate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date des calculs"
    )
    sovalref = db.Column(
        db.Numeric(24, 7), info="Valeur théorique de référence (dev produit)"
    )
    sovaltauxup = db.Column(
        db.Numeric(24, 7),
        info="Composante Risque de Taux avec acroissement de la courbe des taux (dev produit)",
    )
    sovaltauxdown = db.Column(
        db.Numeric(24, 7),
        info="Composante Risque de Taux avec diminution de la courbe des taux (dev produit)",
    )
    sovalspot = db.Column(
        db.Numeric(24, 7), info="Composante Risque Action, stress de Spot (dev produit)"
    )
    sovalvol = db.Column(
        db.Numeric(24, 7),
        info="Composante Risque Action, stress de Volatilité (dev produit)",
    )
    sovalspread = db.Column(
        db.Numeric(24, 7), info="Composante Risque de Spread, calcul basé sur RHO"
    )
    sovalchange = db.Column(db.Numeric(24, 7), info="Composante Risque de Change (EUR)")
    soscr = db.Column(
        db.Numeric(24, 7),
        info="Solvency Capital Requirement pour le Cfin (EUR) avec composante spread basee sur RHO",
    )
    soundlcurr = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Devise du sous-jacent"
    )
    soassetcurr = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Devise de la convertible"
    )
    soupundlfx = db.Column(
        db.Numeric(24, 7), info="Variation de +25% de la devise SSJ/EUR"
    )
    sodownundlfx = db.Column(
        db.Numeric(24, 7), info="Variation de -25% de la devise SSJ/EUR"
    )
    soupassetfx = db.Column(
        db.Numeric(24, 7), info="Variation de +25% de la devise Convert/EUR"
    )
    sodownassetfx = db.Column(
        db.Numeric(24, 7), info="Variation de -25% de la devise Convert/EUR"
    )
    sovalspread2 = db.Column(
        db.Numeric(24, 7),
        info="Composante Risque de Spread, calcul basé sur CREDIT SPREAD",
    )
    soscr2 = db.Column(
        db.Numeric(24, 7),
        info="Solvency Capital Requirement pour le Cfin (EUR) avec composante spread basee sur CREDIT SPREAD",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hsolvency2.socfin == Instrument.ifcfin",
        backref="hsolvency2s",
    )


class Hspreadrecup(db.Model):
    __tablename__ = "hspreadrecup"
    __table_args__ = {"schema": "derives"}

    hsrcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="CFIN",
    )
    hsrdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date de calcul"
    )
    hsrspread = db.Column(
        db.Numeric(16, 5),
        info="Spread entre le rendement de l'obligation et le taux swap",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hspreadrecup.hsrcfin == Instrument.ifcfin",
        backref="hspreadrecups",
    )


class Hstatsaut(db.Model):
    __tablename__ = "hstatsaut"
    __table_args__ = {"schema": "derives"}

    hscfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    hsdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hsvhc = db.Column(db.Numeric(13, 5))
    hshv = db.Column(db.Numeric(13, 5))
    hsamplitude = db.Column(db.Numeric(13, 5))
    hsamplitude_ec = db.Column(db.Numeric(13, 5))
    hschocs = db.Column(db.Numeric(13, 5))
    hschocs_ec = db.Column(db.Numeric(13, 5))
    hsprobsembas = db.Column(db.Numeric(13, 5))
    hsprobsemhaut = db.Column(db.Numeric(13, 5))
    hsexvarsaut = db.Column(db.Numeric(13, 5))
    hsmoy = db.Column(db.Numeric(13, 5))
    hsnbchocs = db.Column(db.Numeric(13, 5))
    hsm = db.Column(db.Numeric(13, 5))
    hsgamma = db.Column(db.Numeric(13, 5))
    hsmaxv = db.Column(db.Numeric(13, 5))
    hsprofondeur = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hsnboptim = db.Column(db.Numeric(6, 0, asdecimal=False))
    hsflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hstatsaut.hscfin == Instrument.ifcfin",
        backref="hstatsauts",
    )


class Hstdiver(db.Model):
    __tablename__ = "hstdivers"
    __table_args__ = {"schema": "derives"}

    hsdcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Cfin du produit",
    )
    hsdmarche = db.Column(
        db.ForeignKey("exane.marche.macode"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Marché de cotation",
    )
    hsddate = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        index=True,
        info="Date de la statistique",
    )
    hsdidsession = db.Column(
        db.ForeignKey("exane_batch.appsession.asidsession"),
        nullable=False,
        info="Identifiant de la session de calcul",
    )
    hsdturnover = db.Column(db.Numeric(13, 5), info="Taux de rotation de l'indice")
    hsdnbcompo = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Nombre de composantes du produit"
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hstdiver.hsdcfin == Instrument.ifcfin",
        backref="hstdivers",
    )
    appsession = db.relationship(
        "Appsession",
        primaryjoin="Hstdiver.hsdidsession == Appsession.asidsession",
        backref="hstdivers",
    )
    marche = db.relationship(
        "Marche", primaryjoin="Hstdiver.hsdmarche == Marche.macode", backref="hstdivers"
    )


class Hstrspecifique(db.Model):
    __tablename__ = "hstrspecifique"
    __table_args__ = {"schema": "derives"}

    hcscfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcsmodeut = db.Column(db.String(1), primary_key=True, nullable=False)
    hcsprofilgcp = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcstypepricer = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcsindic = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hcsdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hcsvaleurindic = db.Column(db.Numeric(18, 5))


class Hstrspecsj(db.Model):
    __tablename__ = "hstrspecsj"
    __table_args__ = {"schema": "derives"}

    hcjcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False, info="Cfin"
    )
    hcjundl = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Underlying",
    )
    hcjindic = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code for indicator",
    )
    hcjvalue = db.Column(db.Numeric(18, 5), nullable=False, info="Indicator value")
    hcjdate = db.Column(db.DateTime, primary_key=True, nullable=False, info="Date")
    hcjsource = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Source 1=Castor 2=Pythagore",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hstrspecsj.hcjundl == Instrument.ifcfin",
        backref="hstrspecsjs",
    )


class Hstructure(db.Model):
    __tablename__ = "hstructure"
    __table_args__ = {"schema": "derives"}

    hstrcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), nullable=False, index=True
    )
    hstrdate = db.Column(db.DateTime, nullable=False)
    hstrtxoat = db.Column(db.Numeric(13, 5))
    hstrptb = db.Column(db.Numeric(13, 5))
    hstrvol_ex = db.Column(db.Numeric(13, 5))
    hstrvolmax_ex = db.Column(db.Numeric(13, 5))
    hstrprime = db.Column(db.Numeric(13, 5))
    hstrprimea = db.Column(db.Numeric(13, 5))
    hstrvaltheo = db.Column(db.Numeric(13, 5))
    hstrdecote = db.Column(db.Numeric(13, 5))
    hstrdecotehm = db.Column(db.Numeric(13, 5))
    hstrytm_cap = db.Column(db.Numeric(13, 5))
    hstrbkeven_cap = db.Column(db.Numeric(13, 5))
    hstrytm_floor = db.Column(db.Numeric(13, 5))
    hstrbkeven_floor = db.Column(db.Numeric(13, 5))
    hstrvolimp = db.Column(db.Numeric(13, 5))
    hstrvolimphm = db.Column(db.Numeric(13, 5))
    hstrdelta = db.Column(db.Numeric(13, 5))
    hstrdeltahm = db.Column(db.Numeric(13, 5))
    hstrdeltanorme = db.Column(db.Numeric(13, 5))
    hstrdeltanormehm = db.Column(db.Numeric(13, 5))
    hstrvega = db.Column(db.Numeric(13, 5))
    hstrvegahm = db.Column(db.Numeric(13, 5))
    hstrrho = db.Column(db.Numeric(13, 5))
    hstrtheta = db.Column(db.Numeric(13, 5))
    hstrsomdivact = db.Column(db.Numeric(13, 5))
    hstrpremium = db.Column(db.Numeric(13, 5))
    hstrpremiuma = db.Column(db.Numeric(13, 5))
    hstrconvm20 = db.Column(db.Numeric(13, 5))
    hstrconvp20 = db.Column(db.Numeric(13, 5))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hstructure.hstrcfin == Instrument.ifcfin",
        backref="hstructures",
    )


class Hsurface(db.Model):
    __tablename__ = "hsurfaces"
    __table_args__ = (
        db.CheckConstraint("sustatusdatematu in (1,2)"),
        db.CheckConstraint("sustatusstrike in (1,2)"),
        {"schema": "derives"},
    )

    sucfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="Cfin du sous-jacent",
    )
    sumarche = db.Column(
        db.ForeignKey("exane.marche.macode"),
        nullable=False,
        index=True,
        info="Marché Option",
    )
    sudate = db.Column(db.DateTime, nullable=False, index=True, info="Date de calcul")
    sudatematu = db.Column(db.DateTime, nullable=False, info="Date de maturité")
    sustatusdatematu = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        info="Type de Maturité (1:réelle,2:normée)",
    )
    sustrike = db.Column(db.Numeric(13, 5), nullable=False, info="Strike Option")
    sustatusstrike = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        info="Type de Strike (1:réel,2:fictif)",
    )
    suvi = db.Column(db.Numeric(13, 5), info="Volatilité Implicite")
    suvmodele = db.Column(db.Numeric(13, 5), info="Deprecated: Type de modele")
    suvmodeleobj = db.Column(db.Numeric(13, 5), info="Deprecated: Indice de modele")
    suvsmile = db.Column(db.Numeric(13, 5), info="Smile")
    suflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="Type de surface (1,7)",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hsurface.sucfin == Instrument.ifcfin",
        backref="hsurfaces",
    )
    marche = db.relationship(
        "Marche", primaryjoin="Hsurface.sumarche == Marche.macode", backref="hsurfaces"
    )


class Hwar(db.Model):
    __tablename__ = "hwar"
    __table_args__ = {"schema": "derives"}

    hwcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    hwmarche = db.Column(
        db.ForeignKey("exane.marche.macode"), primary_key=True, nullable=False
    )
    hwdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hwclose = db.Column(db.Numeric(13, 5), info="cours du warrant")
    hwclosesj = db.Column(
        db.Numeric(13, 5), info="cours SJ du warrant utilisé pour le calcul de la VI"
    )
    hwvimarche = db.Column(db.Numeric(13, 5), info="VI de marche")
    hwviex = db.Column(
        db.Numeric(13, 5), info="VI calculee à partir du profil de reference"
    )

    instrument = db.relationship(
        "Instrument", primaryjoin="Hwar.hwcfin == Instrument.ifcfin", backref="hwars"
    )
    marche = db.relationship(
        "Marche", primaryjoin="Hwar.hwmarche == Marche.macode", backref="hwars"
    )


class Hwarrant(db.Model):
    __tablename__ = "hwarrant"
    __table_args__ = {"schema": "derives"}

    hwcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    hwdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hwvaltheo = db.Column(db.Numeric(13, 5))
    hwvalactu = db.Column(db.Numeric(13, 5))
    hwdecote = db.Column(db.Numeric(13, 5))
    hwvolimp = db.Column(db.Numeric(13, 5))
    hwdelta = db.Column(db.Numeric(13, 5))
    hwdeltanorme = db.Column(db.Numeric(13, 5))
    hwvega = db.Column(db.Numeric(13, 5))
    hwvol_ex = db.Column(db.Numeric(13, 5))
    hwvolmax_ex = db.Column(db.Numeric(13, 5))
    hwrho = db.Column(db.Numeric(13, 5))
    hwtxoat = db.Column(db.Numeric(13, 5))
    hwsomdivcap = db.Column(db.Numeric(13, 5))
    hwtheta = db.Column(db.Numeric(13, 5))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hwarrant.hwcfin == Instrument.ifcfin",
        backref="hwarrants",
    )


class Hypvolmodele(db.Model):
    __tablename__ = "hypvolmodele"
    __table_args__ = {"schema": "derives"}

    hvtypecalcul = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    hvfamille = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    hvtypeinstrument = db.Column(db.Numeric(3, 0, asdecimal=False))
    hvcodemodele = db.Column(db.Numeric(3, 0, asdecimal=False))
    hvnomodele = db.Column(db.Numeric(2, 0, asdecimal=False))
    hvpoids = db.Column(db.Numeric(7, 3))
    hvparam1 = db.Column(db.Numeric(13, 5))
    hvparam2 = db.Column(db.Numeric(13, 5))
    hvparam3 = db.Column(db.Numeric(13, 5))
    hvparam4 = db.Column(db.Numeric(13, 5))
    hvparam5 = db.Column(db.Numeric(13, 5))
    hvparam6 = db.Column(db.Numeric(13, 5))
    hvparam7 = db.Column(db.Numeric(13, 5))
    hvparam8 = db.Column(db.Numeric(13, 5))
    hvparam9 = db.Column(db.Numeric(13, 5))


class Hypvolmonitor(db.Model):
    __tablename__ = "hypvolmonitor"
    __table_args__ = {"schema": "derives"}

    hmcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        index=True,
    )
    hmtypecalcul = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hmcodemodele = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hmnomodele = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hmres1 = db.Column(db.Numeric(13, 5))
    hmres2 = db.Column(db.Numeric(13, 5))
    hmres3 = db.Column(db.Numeric(13, 5))
    hmres4 = db.Column(db.Numeric(13, 5))
    hmres5 = db.Column(db.Numeric(13, 5))
    hmres6 = db.Column(db.Numeric(13, 5))
    hmres7 = db.Column(db.Numeric(13, 5))
    hmres8 = db.Column(db.Numeric(13, 5))
    hmres9 = db.Column(db.Numeric(13, 5))
    hmflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hmdate = db.Column(db.DateTime)

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hypvolmonitor.hmcfin == Instrument.ifcfin",
        backref="hypvolmonitors",
    )


class Hypvolproduit(db.Model):
    __tablename__ = "hypvolproduit"
    __table_args__ = {"schema": "derives"}

    vccfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), nullable=False, index=True
    )
    vccodematurite = db.Column(db.Numeric(3, 0, asdecimal=False))
    vcval = db.Column(db.Numeric(13, 5))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hypvolproduit.vccfin == Instrument.ifcfin",
        backref="hypvolproduits",
    )


class IdxIndictr(db.Model):
    __tablename__ = "idx_indictrs"
    __table_args__ = {"schema": "derives"}

    indcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="Date valeur",
    )
    inddate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date valeur"
    )
    indname = db.Column(
        db.String(32), primary_key=True, nullable=False, info="Nom de l'idicateur"
    )
    indvalue = db.Column(
        db.Numeric(asdecimal=False), info="Valeur en integer de l indicateur"
    )
    inddatevalue = db.Column(db.DateTime, info="Valeur en date de l indicateur")
    indstringvalue = db.Column(db.String(200), info="Valeur en string de l indicateur")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="IdxIndictr.indcfin == Instrument.ifcfin",
        backref="idx_indictrs",
    )


class IdxIndictrsExt(db.Model):
    __tablename__ = "idx_indictrs_ext"
    __table_args__ = {"schema": "derives"}

    indcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        info="cfin de l indice",
    )
    inddate = db.Column(db.DateTime, nullable=False, info="Date valeur")
    indname = db.Column(db.String(32), nullable=False, info="Nom de l'idicateur")
    indsjac = db.Column(db.Numeric(8, 0, asdecimal=False), info="cfin composante")
    indvalue = db.Column(db.Numeric(asdecimal=False), info="Valeur de l indicateur")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="IdxIndictrsExt.indcfin == Instrument.ifcfin",
        backref="idx_indictrs_exts",
    )


class Idxattribut(db.Model):
    __tablename__ = "idxattributs"
    __table_args__ = (
        db.CheckConstraint("XAVALEURBOOL IN ('O','N')"),
        db.CheckConstraint(
            "XAVALEURNUM Is Not Null OR XAVALEURDATE  Is Not Null OR XAVALEURBOOL Is Not Null OR  XAVALEURSTRING Is Not Null"
        ),
        db.CheckConstraint(
            "XAVALEURNUM Is Not Null OR XAVALEURDATE  Is Not Null OR XAVALEURBOOL Is Not Null OR  XAVALEURSTRING Is Not Null"
        ),
        db.CheckConstraint(
            "XAVALEURNUM Is Not Null OR XAVALEURDATE  Is Not Null OR XAVALEURBOOL Is Not Null OR  XAVALEURSTRING Is Not Null"
        ),
        db.CheckConstraint(
            "XAVALEURNUM Is Not Null OR XAVALEURDATE  Is Not Null OR XAVALEURBOOL Is Not Null OR  XAVALEURSTRING Is Not Null"
        ),
        {"schema": "derives"},
    )

    xacfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        index=True,
        info="cfin de l indice (ou du panier)",
    )
    xatypeattribut = db.Column(
        db.ForeignKey("derives.idxtypeattribut.xaid"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Identifiant du type de l attribut",
    )
    xadatedeb = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="date de début d effet (date incluse)",
    )
    xadatefin = db.Column(db.DateTime, info="date de fin d effet (date exclue)")
    xavaleurnum = db.Column(
        db.Numeric(asdecimal=False), info="Valeur de l attribut de type numérique"
    )
    xavaleurdate = db.Column(db.DateTime, info="Valeur de l attribut de type date")
    xavaleurbool = db.Column(db.String(1), info="Valeur de l attribut de type booleen")
    xavaleurstring = db.Column(
        db.String(1000), info="Valeur de l attribut de type chaine"
    )
    xadatesaisie = db.Column(
        db.DateTime,
        nullable=False,
        server_default=db.FetchedValue(),
        info="date de saisie",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Idxattribut.xacfin == Instrument.ifcfin",
        backref="idxattributs",
    )
    idxtypeattribut = db.relationship(
        "Idxtypeattribut",
        primaryjoin="Idxattribut.xatypeattribut == Idxtypeattribut.xaid",
        backref="idxattributs",
    )


class IdxauditCustomIdx(db.Model):
    __tablename__ = "idxaudit_custom_idx"
    __table_args__ = {"schema": "derives"}

    idcsessionid = db.Column(
        db.Numeric(9, 0, asdecimal=False), nullable=False, info="id de la session"
    )
    idccfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        info="cfin de l indice",
    )
    idcvaluedate = db.Column(db.DateTime, nullable=False, info="value date")
    idceventype = db.Column(db.String(256), nullable=False, info="type event")
    idcmontant = db.Column(db.Numeric(asdecimal=False), info="montant")
    idccfinsource = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), info="cfin source"
    )
    idccross = db.Column(db.Numeric(asdecimal=False), info="Cross used")
    idccomment = db.Column(db.String(256), nullable=False, info="commentaire")
    idcid = db.Column(
        db.Numeric(38, 0, asdecimal=False),
        info="Identifiant technique de la piste d'audit",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="IdxauditCustomIdx.idccfin == Instrument.ifcfin",
        backref="instrument_idxaudit_custom_idxes",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="IdxauditCustomIdx.idccfinsource == Instrument.ifcfin",
        backref="instrument_idxaudit_custom_idxes_0",
    )


class IdxauditIndexEvent(db.Model):
    __tablename__ = "idxaudit_index_event"
    __table_args__ = {"schema": "derives"}

    idasessionid = db.Column(
        db.ForeignKey("exane_batch.appsession.asidsession"),
        nullable=False,
        index=True,
        info="id de la session",
    )
    idacfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="cfin de l indice",
    )
    idavaluedate = db.Column(db.DateTime, nullable=False, index=True, info="value date")
    idaeventype = db.Column(
        db.Numeric(7, 0, asdecimal=False), nullable=False, info="type event"
    )
    idamontant = db.Column(db.Numeric(asdecimal=False), info="montant")
    idacfinsource = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), index=True, info="cfin source"
    )
    idacross = db.Column(db.Numeric(asdecimal=False), info="Cross used")
    idaid = db.Column(
        db.Numeric(38, 0, asdecimal=False),
        info="Identifiant technique de la piste d'audit",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="IdxauditIndexEvent.idacfin == Instrument.ifcfin",
        backref="instrument_idxaudit_index_events",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="IdxauditIndexEvent.idacfinsource == Instrument.ifcfin",
        backref="instrument_idxaudit_index_events_0",
    )
    appsession = db.relationship(
        "Appsession",
        primaryjoin="IdxauditIndexEvent.idasessionid == Appsession.asidsession",
        backref="idxaudit_index_events",
    )


class IdxauditUdl(db.Model):
    __tablename__ = "idxaudit_udl"
    __table_args__ = {"schema": "derives"}

    idusessionid = db.Column(
        db.ForeignKey("exane_batch.appsession.asidsession"),
        nullable=False,
        index=True,
        info="id de la session",
    )
    iducfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="cfin de l indice",
    )
    iduvaluedate = db.Column(db.DateTime, nullable=False, index=True, info="value date")
    iducfinssj = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="cfin ssjac",
    )
    iducoupon = db.Column(db.Numeric(asdecimal=False), info="montant coupon couru")
    iducross = db.Column(db.Numeric(asdecimal=False), info="cross idx-ssjac")
    iduspot = db.Column(db.Numeric(asdecimal=False), info="spot ssjac")
    iduspotdate = db.Column(db.DateTime, info="spot date")
    iduid = db.Column(
        db.Numeric(38, 0, asdecimal=False),
        info="Identifiant technique de la piste d'audit",
    )
    idumarket = db.Column(
        db.Numeric(9, 0, asdecimal=False), info="Market at value date"
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="IdxauditUdl.iducfin == Instrument.ifcfin",
        backref="instrument_idxaudit_udls",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="IdxauditUdl.iducfinssj == Instrument.ifcfin",
        backref="instrument_idxaudit_udls_0",
    )
    appsession = db.relationship(
        "Appsession",
        primaryjoin="IdxauditUdl.idusessionid == Appsession.asidsession",
        backref="idxaudit_udls",
    )


class Idxcompofixe(db.Model):
    __tablename__ = "idxcompofixe"
    __table_args__ = {"schema": "derives"}

    xccfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    xcdate = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="date a laquelle il faut appliquer ces quantites",
    )
    xcsj = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        index=True,
        info="cfin de l indice",
    )
    xcmontant = db.Column(
        db.Numeric(24, 15),
        nullable=False,
        info="Poids % de chaque SJ dans l indice ou quantite du SJ dans l indice",
    )
    xctype = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Type de compo fixe (0 = Op. Rebalancement, 1 = Algèbre)",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Idxcompofixe.xccfin == Instrument.ifcfin",
        backref="instrument_idxcompofixes",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Idxcompofixe.xcsj == Instrument.ifcfin",
        backref="instrument_idxcompofixes_0",
    )


class Idxcompovar(db.Model):
    __tablename__ = "idxcompovar"
    __table_args__ = {"schema": "derives"}

    cvfin = db.Column(
        db.ForeignKey("derives.idxalgebre.alcfin"),
        primary_key=True,
        nullable=False,
        info="cfin de l indice",
    )
    cvdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="date de la composition"
    )
    cvsjac = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="cfin du SJ",
    )
    cvquantite = db.Column(
        db.Numeric(asdecimal=False), nullable=False, info="quantité du SJ"
    )

    idxalgebre = db.relationship(
        "Idxalgebre",
        primaryjoin="Idxcompovar.cvfin == Idxalgebre.alcfin",
        backref="idxcompovars",
    )


class Idxcomputcomposition(db.Model):
    __tablename__ = "idxcomputcomposition"
    __table_args__ = {"schema": "derives"}

    cccfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="cfin de l indice",
    )
    ccdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="date de la composition"
    )
    ccsjac = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="cfin du SJ",
    )
    ccquantite = db.Column(
        db.Numeric(asdecimal=False), nullable=False, info="quantité du SJ"
    )
    ccsessionid = db.Column(
        db.ForeignKey("exane_batch.appsession.asidsession"),
        info="ID session batch qui a calcule l'indice",
    )
    ccpoids = db.Column(db.Numeric(11, 5))

    appsession = db.relationship(
        "Appsession",
        primaryjoin="Idxcomputcomposition.ccsessionid == Appsession.asidsession",
        backref="idxcomputcompositions",
    )


class IdxcomputcompositionPr(db.Model):
    __tablename__ = "idxcomputcomposition_pr"
    __table_args__ = {"schema": "derives"}

    cccfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="cfin de l indice",
    )
    ccdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="date de la composition"
    )
    ccsjac = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="cfin du SJ",
    )
    ccquantite = db.Column(
        db.Numeric(asdecimal=False), nullable=False, info="quantité du SJ"
    )
    ccsessionid = db.Column(
        db.Numeric(9, 0, asdecimal=False),
        info="ID session batch qui a calcule l'indice",
    )
    ccpoids = db.Column(db.Numeric(11, 5))


class Idxcontrib(db.Model):
    __tablename__ = "idxcontrib"
    __table_args__ = {"schema": "derives"}

    iccfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    iccodeelt = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ictype = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    icdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    iccontrib = db.Column(db.Numeric(18, 5), nullable=False)
    iccontribdev = db.Column(db.Numeric(18, 5))
    iccloseelt = db.Column(db.Numeric(18, 5))


class IdxcontribPr(db.Model):
    __tablename__ = "idxcontrib_pr"
    __table_args__ = {"schema": "derives"}

    iccfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    iccodeelt = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ictype = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    icdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    iccontrib = db.Column(db.Numeric(18, 5), nullable=False)
    iccontribdev = db.Column(db.Numeric(18, 5))
    iccloseelt = db.Column(db.Numeric(18, 5))


class Idxdeploiement(db.Model):
    __tablename__ = "idxdeploiement"
    __table_args__ = {"schema": "derives"}

    depcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="cfin indice",
    )
    depcfindep = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="cfin elementaire a à déployer",
    )
    depdebut = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="date de début"
    )
    depfin = db.Column(db.DateTime, info="date de fin")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Idxdeploiement.depcfin == Instrument.ifcfin",
        backref="instrument_idxdeploiements",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Idxdeploiement.depcfindep == Instrument.ifcfin",
        backref="instrument_idxdeploiements_0",
    )


class Idxoperationrecurrente(db.Model):
    __tablename__ = "idxoperationrecurrente"
    __table_args__ = (
        db.Index("operrecur_unique", "xocfin", "xosj", "xotype", "xodatedeb"),
        {"schema": "derives"},
    )

    xocfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        info="Cfin de l indice (ou du panier)",
    )
    xosj = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        info="Cfin du  sous jacent sur lequel porte l operation",
    )
    xodatedeb = db.Column(
        db.DateTime, nullable=False, info="Date de début d effet (date incluse)"
    )
    xodatefin = db.Column(db.DateTime, info="Date de fin d effet (date exclue)")
    xotype = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="Type de l operation"
    )
    xobase = db.Column(db.Numeric(asdecimal=False), info="Base de reference")
    xomontant = db.Column(db.Numeric(asdecimal=False), info="Montant")
    xocommentaire = db.Column(db.String(450), info="Commentaire")
    xodatesaisie = db.Column(
        db.DateTime,
        nullable=False,
        server_default=db.FetchedValue(),
        info="Date de saisie",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Idxoperationrecurrente.xocfin == Instrument.ifcfin",
        backref="instrument_idxoperationrecurrentes",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Idxoperationrecurrente.xosj == Instrument.ifcfin",
        backref="instrument_idxoperationrecurrentes_0",
    )


class Idxoperation(db.Model):
    __tablename__ = "idxoperations"
    __table_args__ = (
        db.Index(
            "uk_idxcompofixe", "xocfin", "xosj", "xodate", "xotype", "xotypereinvest"
        ),
        {"schema": "derives"},
    )

    xocfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        info="cfin de l indice (ou du panier)",
    )
    xosj = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        index=True,
        info="cfin du sous jacent",
    )
    xodatesaisie = db.Column(db.DateTime, nullable=False, info="date de saisie")
    xodate = db.Column(db.DateTime, nullable=False, info="date d effet de l operation")
    xotype = db.Column(
        db.ForeignKey("derives.idxtypeoperation.xtocode"),
        nullable=False,
        info="type de l operation",
    )
    xotypereinvest = db.Column(
        db.ForeignKey("derives.idxtypereinvest.xtrcode"),
        info="type de reinvestissement",
    )
    xomontant = db.Column(db.Numeric(asdecimal=False))
    xodev = db.Column(db.Numeric(8, 0, asdecimal=False), info="devise")
    xocommentaire = db.Column(db.String(450), info="commentaire")
    xosjcible = db.Column(db.Numeric(8, 0, asdecimal=False))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Idxoperation.xocfin == Instrument.ifcfin",
        backref="instrument_idxoperations",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Idxoperation.xosj == Instrument.ifcfin",
        backref="instrument_idxoperations_0",
    )
    idxtypeoperation = db.relationship(
        "Idxtypeoperation",
        primaryjoin="Idxoperation.xotype == Idxtypeoperation.xtocode",
        backref="idxoperations",
    )
    idxtypereinvest = db.relationship(
        "Idxtypereinvest",
        primaryjoin="Idxoperation.xotypereinvest == Idxtypereinvest.xtrcode",
        backref="idxoperations",
    )


class Idxparamsindex(db.Model):
    __tablename__ = "idxparamsindex"
    __table_args__ = {"schema": "derives"}

    picfin = db.Column(
        db.Numeric(38, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info=" Cfin de l'indice",
    )
    pimodereinvest = db.Column(
        db.ForeignKey("derives.idxtypereinvest.xtrcode"),
        info=" Mode de reinvestissement par defaut de l'indice (DERIVES.IDXTYPEREINVEST)",
    )
    pidatein = db.Column(db.DateTime, primary_key=True, nullable=False)
    pidateout = db.Column(db.DateTime)

    idxtypereinvest = db.relationship(
        "Idxtypereinvest",
        primaryjoin="Idxparamsindex.pimodereinvest == Idxtypereinvest.xtrcode",
        backref="idxparamsindexes",
    )


class Idxreinvest(db.Model):
    __tablename__ = "idxreinvest"
    __table_args__ = {"schema": "derives"}

    riidxcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="cfin de l indice",
    )
    ricfinsj = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        index=True,
        info="cfin du SJ qui détache le flux",
    )
    ricfinreinvest = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="cfin sur lequel le flux sera reinvesti",
    )
    ridatein = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Date de debut de validité de la règle (incluse)",
    )
    ridateout = db.Column(
        db.DateTime, info="Date de fin de validité de la règle (excluse)"
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Idxreinvest.ricfinreinvest == Instrument.ifcfin",
        backref="instrument_instrument_idxreinvests",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Idxreinvest.ricfinsj == Instrument.ifcfin",
        backref="instrument_instrument_idxreinvests_0",
    )
    instrument2 = db.relationship(
        "Instrument",
        primaryjoin="Idxreinvest.riidxcfin == Instrument.ifcfin",
        backref="instrument_instrument_idxreinvests",
    )


class Idxrollperiod(db.Model):
    __tablename__ = "idxrollperiod"
    __table_args__ = {"schema": "derives"}

    rpid = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="PK technique "
    )
    rpcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        info="cfin de l indice",
    )
    rpstartdate = db.Column(
        db.DateTime, nullable=False, info="date de début de la période de rebalancement"
    )
    rpenddate = db.Column(
        db.DateTime,
        nullable=False,
        info="date de fin (incluse) de la période de rebalancement",
    )
    rpname = db.Column(db.String(450), info="Nom de la période de rebalancement")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Idxrollperiod.rpcfin == Instrument.ifcfin",
        backref="idxrollperiods",
    )


class Idxsnapshotcomposition(db.Model):
    __tablename__ = "idxsnapshotcomposition"
    __table_args__ = {"schema": "derives"}

    xscidsession = db.Column(
        db.ForeignKey("exane_batch.appsession.asidsession"),
        primary_key=True,
        nullable=False,
        info="Session de sauvegarde",
    )
    xsclabel = db.Column(
        db.String(256), info="Commentaire utilisateur avant le snapshot"
    )
    xsccfin = db.Column(
        db.Numeric(10, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="CFIN indice",
    )
    xscdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date de la compo"
    )
    xsccfinsj = db.Column(
        db.Numeric(10, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="CFIN sous jacent",
    )
    xscquantite = db.Column(db.Numeric(24, 15), info="Quantite sous jacent")
    xscpoids = db.Column(db.Numeric(24, 15))
    xscniveauindice = db.Column(db.Numeric(24, 15), info="Poids sous jacent")
    xschorodate = db.Column(
        db.DateTime,
        server_default=db.FetchedValue(),
        info="Horodate d'insertion de la donnée",
    )

    appsession = db.relationship(
        "Appsession",
        primaryjoin="Idxsnapshotcomposition.xscidsession == Appsession.asidsession",
        backref="idxsnapshotcompositions",
    )


class Idxtypeattribut(db.Model):
    __tablename__ = "idxtypeattribut"
    __table_args__ = {"schema": "derives"}

    xaid = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="ID de l attribut"
    )
    xascriptlibelle = db.Column(
        db.String(64), nullable=False, info="Libellé dans le script"
    )
    xadescription = db.Column(db.String(450), info="Description de l attribut")


class Idxtypeoperation(db.Model):
    __tablename__ = "idxtypeoperation"
    __table_args__ = {"schema": "derives"}

    xtocode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Identifiant de l operation",
    )
    xtolibelle = db.Column(db.String(200), info="Nom de l operation")


class Idxtypereinvest(db.Model):
    __tablename__ = "idxtypereinvest"
    __table_args__ = {"schema": "derives"}

    xtrcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Identifiant du type de reinvestissement",
    )
    xtrlibelle = db.Column(db.String(200), info="Description du reinvestissement")


class Indiceliste(db.Model):
    __tablename__ = "indiceliste"
    __table_args__ = {"schema": "derives"}

    ilcfin = db.Column(db.ForeignKey("derives.indicerisque.ircfin"), nullable=False)
    ilidl = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)

    indicerisque = db.relationship(
        "Indicerisque",
        primaryjoin="Indiceliste.ilcfin == Indicerisque.ircfin",
        backref="indicelistes",
    )


class Indictauxrecette(db.Model):
    __tablename__ = "indictauxrecette"
    __table_args__ = {"schema": "derives"}

    itcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
    )
    itmaturite = db.Column(db.ForeignKey("exane.maturite.mtcode"), nullable=False)
    itdev = db.Column(db.ForeignKey("exane.devise.dvcfin"), nullable=False)
    itdate = db.Column(db.DateTime, nullable=False)
    itvaleur = db.Column(db.Numeric(9, 5))
    itbase = db.Column(db.ForeignKey("exane.basecc.bacode"), nullable=False)
    itforward = db.Column(db.ForeignKey("exane.maturite.mtcode"))
    itcontrib = db.Column(
        db.ForeignKey("exane.contributeur.cocode"), primary_key=True, nullable=False
    )
    itfixing = db.Column(db.Numeric(3, 0, asdecimal=False))
    itmodeexp = db.Column(db.ForeignKey("exane.modeexptaux.mecode"), nullable=False)
    ittypecourbe = db.Column(db.Numeric(3, 0, asdecimal=False))

    basecc = db.relationship(
        "Basecc",
        primaryjoin="Indictauxrecette.itbase == Basecc.bacode",
        backref="indictauxrecettes",
    )
    instrument = db.relationship(
        "Instrument",
        primaryjoin="Indictauxrecette.itcfin == Instrument.ifcfin",
        backref="indictauxrecettes",
    )
    contributeur = db.relationship(
        "Contributeur",
        primaryjoin="Indictauxrecette.itcontrib == Contributeur.cocode",
        backref="indictauxrecettes",
    )
    devise = db.relationship(
        "Devise",
        primaryjoin="Indictauxrecette.itdev == Devise.dvcfin",
        backref="devise_indictauxrecettes",
    )
    maturite = db.relationship(
        "Maturite",
        primaryjoin="Indictauxrecette.itforward == Maturite.mtcode",
        backref="maturite_indictauxrecettes",
    )
    maturite1 = db.relationship(
        "Maturite",
        primaryjoin="Indictauxrecette.itmaturite == Maturite.mtcode",
        backref="maturite_indictauxrecettes_0",
    )
    modeexptaux = db.relationship(
        "Modeexptaux",
        primaryjoin="Indictauxrecette.itmodeexp == Modeexptaux.mecode",
        backref="indictauxrecettes",
    )


class Intradayop(db.Model):
    __tablename__ = "intradayop"
    __table_args__ = {"schema": "derives"}

    iocfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        info="Cfin de l'option",
    )
    iomarche = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Marché de l'option",
    )
    iosource = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Source de récupération",
    )
    iohrecup = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Horodate de la recup"
    )
    iohsession = db.Column(
        db.DateTime, nullable=False, info="Horodate de Session de Recup"
    )
    iopriop = db.Column(db.Numeric(13, 5))
    ioprisj = db.Column(db.Numeric(13, 5), nullable=False, info="Spot")
    iovolqte = db.Column(db.Numeric(16, 0, asdecimal=False), info="Volume")
    iobid = db.Column(db.Numeric(13, 5), info="Bid de l'option")
    ioask = db.Column(db.Numeric(13, 5), info="Ask de l'option")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Intradayop.iocfin == Instrument.ifcfin",
        backref="intradayops",
    )


class Intradayopsession(db.Model):
    __tablename__ = "intradayopsession"
    __table_args__ = {"schema": "derives"}

    ishsession = db.Column(
        db.DateTime, nullable=False, info="Heure de session de récupération"
    )
    isnbsjrecup = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Nombre de SJ récupérés"
    )
    isnboptrecup = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Nombre d'options récupérées",
    )
    isnboptrejet = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Nombre d'options rejetées",
    )


class Intradayopvi(db.Model):
    __tablename__ = "intradayopvi"
    __table_args__ = (
        db.CheckConstraint("IVEXTYPE IN ('A','E')"),
        db.CheckConstraint("IVPROFIL IN (0,1,3,4,7,8,9)"),
        {"schema": "derives"},
    )

    ivcfincall = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="SET NULL"),
        index=True,
        info="CFIN Call",
    )
    ivcfinput = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="SET NULL"),
        index=True,
        info="CFIN Put",
    )
    ivhrecup = db.Column(
        db.DateTime, nullable=False, info="Horodate du Groupe de Recup"
    )
    ivhsession = db.Column(
        db.DateTime, nullable=False, info="Horodate de Session de Recup"
    )
    ivcfinsj = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="CFIN Sous-Jacent",
    )
    ivmarche = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="Marché des Options"
    )
    ivsource = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="Source de récup des cours",
    )
    ivmaturite = db.Column(db.DateTime, nullable=False, info="Maturité Options")
    ivstrike = db.Column(db.Numeric(13, 5), nullable=False, info="Strike")
    ivextype = db.Column(db.String(1), nullable=False, info="Type d'exerçabilité")
    ivquotite = db.Column(db.Numeric(13, 5), info="Quotité")
    ivcourssj = db.Column(db.Numeric(13, 5), info="Cours du sous-jacent")
    ivcourscall = db.Column(db.Numeric(13, 5), info="Cours de compens Call")
    ivcoursput = db.Column(db.Numeric(13, 5), info="Cours de compens Put")
    ivbidcall = db.Column(db.Numeric(13, 5), info="Bid du Call")
    ivaskcall = db.Column(db.Numeric(13, 5), info="Ask du Call")
    ivbidput = db.Column(db.Numeric(13, 5), info="Bid du Put")
    ivaskput = db.Column(db.Numeric(13, 5), info="Ask du Put")
    ivvolumecall = db.Column(db.Numeric(13, 5), info="Volume Call")
    ivvolumeput = db.Column(db.Numeric(13, 5), info="Volume PUT")
    ivprofil = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        nullable=False,
        info="Profil de Calcul (PROFILCALCUL)",
    )
    ivfiltre = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        info="Flag (-2 si xxxPRICE échoué; -1 si aucune paire CP sur la maturité)",
    )
    ivvolmoney = db.Column(
        db.Numeric(13, 5), info="Vol At The Money Forward (ie:Strike<-Forward)"
    )
    ivvolimp = db.Column(db.Numeric(13, 5), info="Volatilité implicite")
    ivtauxrepo = db.Column(db.Numeric(13, 5), info="Taux de Repo implicite")
    ivcallprice = db.Column(
        db.Numeric(13, 5), info="Prix théorique Call avec VI et Taux de Repo Implicite"
    )
    ivputprice = db.Column(
        db.Numeric(13, 5), info="Prix théorique Put avec VI et Taux de Repo Implicite"
    )
    ivforward = db.Column(db.Numeric(13, 5), info="Forward")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Intradayopvi.ivcfincall == Instrument.ifcfin",
        backref="instrument_instrument_intradayopvis",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Intradayopvi.ivcfinput == Instrument.ifcfin",
        backref="instrument_instrument_intradayopvis_0",
    )
    instrument2 = db.relationship(
        "Instrument",
        primaryjoin="Intradayopvi.ivcfinsj == Instrument.ifcfin",
        backref="instrument_instrument_intradayopvis",
    )


class Intradayopvim(db.Model):
    __tablename__ = "intradayopvim"
    __table_args__ = (
        db.CheckConstraint("IMEXTYPE IN ('A','E')"),
        db.CheckConstraint("IMPROFIL IN (0,1,3,4,7,8,9)"),
        {"schema": "derives"},
    )

    imcfinsj = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        index=True,
        info="CFIN Sous-Jacent",
    )
    immarche = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        index=True,
        info="Marché des Options",
    )
    imsource = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False, index=True
    )
    immaturite = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        index=True,
        info="Maturité Options",
    )
    imstrike = db.Column(
        db.Numeric(13, 5), primary_key=True, nullable=False, index=True, info="Strike"
    )
    imextype = db.Column(db.String(1), nullable=False, info="Type d'exerçabilité")
    imquotite = db.Column(db.Numeric(13, 5), info="Quotité")
    imdatecalcul = db.Column(
        db.DateTime, primary_key=True, nullable=False, index=True, info="Date de Calcul"
    )
    imcfincall = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="SET NULL"),
        index=True,
        info="CFIN Call",
    )
    imcfinput = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="SET NULL"),
        index=True,
        info="CFIN Put",
    )
    imnb = db.Column(
        db.Numeric(6, 0, asdecimal=False),
        nullable=False,
        info="Nombre d'options récupérées et moyennées",
    )
    imcourssjm = db.Column(db.Numeric(13, 5), info="Cours du sous-jacent")
    imcourscallm = db.Column(db.Numeric(13, 5), info="Cours de compens Call")
    imcoursputm = db.Column(db.Numeric(13, 5), info="Cours de compens Put")
    imbidcallm = db.Column(db.Numeric(13, 5), info="Bid du Call")
    imaskcallm = db.Column(db.Numeric(13, 5), info="Ask du Call")
    imbidputm = db.Column(db.Numeric(13, 5), info="Bid du Put")
    imaskputm = db.Column(db.Numeric(13, 5), info="Ask du Put")
    improfil = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        nullable=False,
        info="Profil de Calcul (PROFILCALCUL)",
    )
    imfiltre = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        info="Flag (-2 si xxxPRICE échoué; -1 si aucune paire CP sur la maturité)",
    )
    imcallpricem = db.Column(db.Numeric(13, 5), info="Prix call moyen")
    imputpricem = db.Column(db.Numeric(13, 5), info="Prix put moyen")
    imvolimpm = db.Column(db.Numeric(13, 5), info="Volatilité implicite moyenne")
    imecartvol = db.Column(
        db.Numeric(13, 5), info="Ecart type sur la volatilité implicite"
    )
    immedianvol = db.Column(db.Numeric(13, 5), info="Volatilité implicite médiane")
    imtauxrepom = db.Column(db.Numeric(13, 5), info="Taux de Repo implicite moyen")
    imecartrepo = db.Column(
        db.Numeric(13, 5), info="Ecart tye sur le taux de Repo implicite"
    )
    immedianrepo = db.Column(db.Numeric(13, 5), info="Taux de Repo implicite médian")
    imforwardm = db.Column(db.Numeric(13, 5), info="Forward moyen")
    imvolmoneym = db.Column(db.Numeric(13, 5), info="Vol money moyen")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Intradayopvim.imcfincall == Instrument.ifcfin",
        backref="instrument_instrument_intradayopvims",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Intradayopvim.imcfinput == Instrument.ifcfin",
        backref="instrument_instrument_intradayopvims_0",
    )
    instrument2 = db.relationship(
        "Instrument",
        primaryjoin="Intradayopvim.imcfinsj == Instrument.ifcfin",
        backref="instrument_instrument_intradayopvims",
    )


class Isscript(db.Model):
    __tablename__ = "isscript"
    __table_args__ = {"schema": "derives"}

    iscfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="CFin indice",
    )
    isscriptid = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="id computation script"
    )
    isloadscriptid = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="id loading sccript"
    )
    isdatein = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="start of valididty"
    )
    isdateout = db.Column(db.DateTime, info="end of valididty")
    isagentcalcul = db.Column(db.String(30))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Isscript.iscfin == Instrument.ifcfin",
        backref="isscripts",
    )


class Lastop(db.Model):
    __tablename__ = "lastop"
    __table_args__ = (
        db.Index("ixlastop", "locfin", "lomarche", "losource"),
        {"schema": "derives"},
    )

    locfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    lomarche = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    losource = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    lodate = db.Column(db.DateTime, nullable=False)
    lopriop = db.Column(db.Numeric(13, 5))
    loprisj = db.Column(db.Numeric(13, 5))
    lovolimp = db.Column(db.Numeric(5, 2))
    lovaltheo = db.Column(db.Numeric(13, 5))
    lopo = db.Column(db.Numeric(12, 0, asdecimal=False))
    lovolqute = db.Column(db.Numeric(16, 0, asdecimal=False))
    lovolcapi = db.Column(db.Numeric(16, 0, asdecimal=False))
    lodatepr = db.Column(db.DateTime)
    loprioppr = db.Column(db.Numeric(13, 5))
    loprisjpr = db.Column(db.Numeric(13, 5))
    lovolimppr = db.Column(db.Numeric(5, 2))
    lovaltheopr = db.Column(db.Numeric(13, 5))
    lopopr = db.Column(db.Numeric(12, 0, asdecimal=False))
    lovolqutepr = db.Column(db.Numeric(16, 0, asdecimal=False))
    lovolcapipr = db.Column(db.Numeric(16, 0, asdecimal=False))
    loflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    lobid = db.Column(db.Numeric(13, 5))
    loask = db.Column(db.Numeric(13, 5))
    loquotite = db.Column(db.Numeric(13, 5))
    lolasttradedate = db.Column(db.DateTime, info="date du dernier trade sur l option")


class Lastrejetrecette(db.Model):
    __tablename__ = "lastrejetrecette"
    __table_args__ = {"schema": "derives"}

    rjcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    rjmarche = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    rjdate = db.Column(db.DateTime, nullable=False)
    rjdata = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    rjsource = db.Column(db.Numeric(3, 0, asdecimal=False))
    rjtype = db.Column(db.Numeric(10, 0, asdecimal=False), nullable=False)
    rjflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class Lastwar(db.Model):
    __tablename__ = "lastwar"
    __table_args__ = {"schema": "derives"}

    lwcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    lwmarche = db.Column(
        db.ForeignKey("exane.marche.macode"), primary_key=True, nullable=False
    )
    lwdate = db.Column(db.DateTime, nullable=False)
    lwclose = db.Column(db.Numeric(13, 5), info="cours du warrant")
    lwvimarche = db.Column(db.Numeric(13, 5), info="VI de marche")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Lastwar.lwcfin == Instrument.ifcfin",
        backref="lastwars",
    )
    marche = db.relationship(
        "Marche", primaryjoin="Lastwar.lwmarche == Marche.macode", backref="lastwars"
    )


class Liste(db.Model):
    __tablename__ = "liste"
    __table_args__ = {"schema": "derives"}

    ltidl = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    ltelt = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)


class Loption(Base):
    __tablename__ = "loption"
    __table_args__ = {"schema": "derives"}

    hpcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    hpdate = db.Column(db.DateTime, nullable=False)
    hpdatematu = db.Column(db.DateTime, nullable=False)
    hpstrike = db.Column(db.Numeric(13, 5), nullable=False)
    hpextype = db.Column(db.String(1), nullable=False)
    hpechtype = db.Column(db.String(1))
    hpbidcall = db.Column(db.Numeric(13, 5))
    hpaskcall = db.Column(db.Numeric(13, 5))
    hpbidput = db.Column(db.Numeric(13, 5))
    hpaskput = db.Column(db.Numeric(13, 5))
    hpprixsj = db.Column(db.Numeric(13, 5))
    hpprixsjmoy = db.Column(db.Numeric(13, 5))
    hpvbs = db.Column(db.Numeric(13, 5))
    hppocall = db.Column(db.Numeric(13, 5))
    hpvolqutecall = db.Column(db.Numeric(13, 5))
    hppoput = db.Column(db.Numeric(13, 5))
    hpvolquteput = db.Column(db.Numeric(13, 5))
    hptaux = db.Column(db.Numeric(asdecimal=False))
    hpflag_etat = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    hpclosing = db.Column(db.Numeric(13, 5))
    hpfiltre = db.Column(db.Numeric(2, 0, asdecimal=False))
    hpvatmf = db.Column(db.Numeric(13, 5))
    hpquotite = db.Column(db.Numeric(13, 5))


class Loptionb(db.Model):
    __tablename__ = "loptionb"
    __table_args__ = {"schema": "derives"}

    hpcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    hpdate = db.Column(db.DateTime, nullable=False)
    hpdatematu = db.Column(db.DateTime, nullable=False)
    hpstrike = db.Column(db.Numeric(13, 5), nullable=False)
    hpextype = db.Column(db.String(1), nullable=False)
    hpechtype = db.Column(db.String(1))
    hpquotite = db.Column(db.Numeric(13, 5))
    hpprixsj = db.Column(db.Numeric(13, 5))
    hpprixsjmoy = db.Column(db.Numeric(13, 5))
    hpclosing = db.Column(db.Numeric(13, 5))
    hpcallcomp = db.Column(db.Numeric(13, 5))
    hpputcomp = db.Column(db.Numeric(13, 5))
    hpaskcall = db.Column(db.Numeric(13, 5))
    hpbidcall = db.Column(db.Numeric(13, 5))
    hpaskput = db.Column(db.Numeric(13, 5))
    hpbidput = db.Column(db.Numeric(13, 5))
    hppocall = db.Column(db.Numeric(13, 5))
    hpvolqutecall = db.Column(db.Numeric(13, 5))
    hppoput = db.Column(db.Numeric(13, 5))
    hpvolquteput = db.Column(db.Numeric(13, 5))
    hptaux = db.Column(db.Numeric(asdecimal=False))
    hpflag_etat = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    hpfiltre = db.Column(db.Numeric(2, 0, asdecimal=False))
    hpvatmf = db.Column(db.Numeric(13, 5))
    hpvbs = db.Column(db.Numeric(13, 5))
    hprepo = db.Column(db.Numeric(13, 5))
    hpcallprice = db.Column(db.Numeric(13, 5))
    hpputprice = db.Column(db.Numeric(13, 5))
    hpcount = db.Column(db.Numeric(asdecimal=False))
    hptime = db.Column(db.Numeric(asdecimal=False))
    hperror = db.Column(db.Numeric(asdecimal=False))


class Loption(db.Model):
    __tablename__ = "loptions"
    __table_args__ = (
        db.CheckConstraint("HOEXTYPE IN ('A','E')"),
        {"schema": "derives"},
    )

    hocfincall = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="SET NULL"),
        index=True,
        info="CFIN Call",
    )
    hocfinput = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="SET NULL"),
        index=True,
        info="CFIN Put",
    )
    homarche = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="Marché des Options"
    )
    hocfinsj = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="CFIN Sous-Jacent",
    )
    hodatecalcul = db.Column(db.DateTime, nullable=False, info="Date de Calcul")
    homaturite = db.Column(db.DateTime, nullable=False, info="Maturité Options")
    hostrike = db.Column(db.Numeric(13, 5), nullable=False, info="Strike")
    hoextype = db.Column(db.String(1), nullable=False, info="Type d'exerçabilité")
    hoquotite = db.Column(db.Numeric(13, 5), info="Quotité")
    hocourssj = db.Column(db.Numeric(13, 5), info="Cours du sous-jacent")
    hocourscall = db.Column(db.Numeric(13, 5), info="Cours de compens Call")
    hocoursput = db.Column(db.Numeric(13, 5), info="Cours de compens Put")
    hobidcall = db.Column(db.Numeric(13, 5), info="Bid du Call")
    hoaskcall = db.Column(db.Numeric(13, 5), info="Ask du Call")
    hobidput = db.Column(db.Numeric(13, 5), info="Bid du Put")
    hoaskput = db.Column(db.Numeric(13, 5), info="Ask du Put")
    hopocall = db.Column(db.Numeric(13, 5), info="Position ouverte Call")
    hovolumecall = db.Column(db.Numeric(13, 5), info="Volume Call")
    hopoput = db.Column(db.Numeric(13, 5), info="Position ouverte Put")
    hovolumeput = db.Column(db.Numeric(13, 5), info="Volume PUT")
    hoprofil = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        nullable=False,
        info="Profil de Calcul (PROFILCALCUL)",
    )
    hofiltre = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        info="Flag (-2 si xxxPRICE échoué; -1 si aucune paire CP sur la maturité)",
    )
    hovolmoney = db.Column(
        db.Numeric(13, 5), info="Vol At The Money Forward (ie:Strike<-Forward)"
    )
    hovolimp = db.Column(db.Numeric(13, 5), info="Volatilité implicite")
    hotauxrepo = db.Column(db.Numeric(13, 5), info="Taux de Repo implicite")
    hocallprice = db.Column(
        db.Numeric(13, 5), info="Prix théorique Call avec VI et Taux de Repo Implicite"
    )
    hoputprice = db.Column(
        db.Numeric(13, 5), info="Prix théorique Put avec VI et Taux de Repo Implicite"
    )
    hoforward = db.Column(db.Numeric(13, 5), info="forward")
    hosource = db.Column(
        db.ForeignKey("exane.source.socode"), info="Source de recuperation"
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Loption.hocfincall == Instrument.ifcfin",
        backref="instrument_instrument_loptions",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Loption.hocfinput == Instrument.ifcfin",
        backref="instrument_instrument_loptions_0",
    )
    instrument2 = db.relationship(
        "Instrument",
        primaryjoin="Loption.hocfinsj == Instrument.ifcfin",
        backref="instrument_instrument_loptions",
    )
    source = db.relationship(
        "Source", primaryjoin="Loption.hosource == Source.socode", backref="loptions"
    )


class Lsurface(db.Model):
    __tablename__ = "lsurfaces"
    __table_args__ = (
        db.CheckConstraint("sustatusdatematu in (1,2)"),
        db.CheckConstraint("sustatusstrike in (1,2)"),
        {"schema": "derives"},
    )

    sucfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Cfin du sous-jacent",
    )
    sumarche = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Marché Option",
    )
    sudate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date de calcul"
    )
    sudatematu = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date de maturité"
    )
    sustatusdatematu = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Type de Maturité (1:réelle,2:normée)",
    )
    sustrike = db.Column(
        db.Numeric(13, 5), primary_key=True, nullable=False, info="Strike Option"
    )
    sustatusstrike = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Type de Strike (1:réel,2:fictif)",
    )
    suvi = db.Column(db.Numeric(13, 5), info="Volatilité Implicite")
    suvmodele = db.Column(db.Numeric(13, 5), info="Deprecated: Type de modele")
    suvmodeleobj = db.Column(db.Numeric(13, 5), info="Deprecated: Indice de modele")
    suvsmile = db.Column(db.Numeric(13, 5), info="Smile")
    suflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Type de surface (1,7)",
    )


class Nogroupecot(db.Model):
    __tablename__ = "nogroupecot"
    __table_args__ = {"schema": "derives"}

    grgrpecot = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    grlibelle = db.Column(db.String(15))
    grflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class Nogroupecotcomp(db.Model):
    __tablename__ = "nogroupecotcomp"
    __table_args__ = {"schema": "derives"}

    gcgrpecot = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    gcmarket = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    gcflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    gctype = db.Column(db.Numeric(3, 0, asdecimal=False))


class Nolastop(db.Model):
    __tablename__ = "nolastop"
    __table_args__ = {"schema": "derives"}

    locfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    lodate = db.Column(db.DateTime, nullable=False)
    lopriop = db.Column(db.Numeric(13, 5))
    loprisj = db.Column(db.Numeric(13, 5))
    lovolimp = db.Column(db.Numeric(5, 2))
    lovaltheo = db.Column(db.Numeric(13, 5))
    lopo = db.Column(db.Numeric(12, 0, asdecimal=False))
    lovolqute = db.Column(db.Numeric(16, 0, asdecimal=False))
    lovolcapi = db.Column(db.Numeric(16, 0, asdecimal=False))
    lodatepr = db.Column(db.DateTime)
    loprioppr = db.Column(db.Numeric(13, 5))
    loprisjpr = db.Column(db.Numeric(13, 5))
    lovolimppr = db.Column(db.Numeric(5, 2))
    lovaltheopr = db.Column(db.Numeric(13, 5))
    lopopr = db.Column(db.Numeric(12, 0, asdecimal=False))
    lovolqutepr = db.Column(db.Numeric(16, 0, asdecimal=False))
    lovolcapipr = db.Column(db.Numeric(16, 0, asdecimal=False))
    loflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    lobid = db.Column(db.Numeric(13, 5))
    loask = db.Column(db.Numeric(13, 5))
    loquotite = db.Column(db.Numeric(13, 5))


class Nooptionope(db.Model):
    __tablename__ = "nooptionope"
    __table_args__ = (
        db.Index("ix_nooptionope", "oocfin", "oocfinsj"),
        {"schema": "derives"},
    )

    ooidgenop = db.Column(db.Numeric(8, 0, asdecimal=False))
    oocfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    oocfinsj = db.Column(db.Numeric(8, 0, asdecimal=False))
    ooextype = db.Column(db.String(1))
    ooechtype = db.Column(db.String(1))
    oostrike = db.Column(db.Numeric(13, 5))
    oodatefin = db.Column(db.DateTime)
    ooparite = db.Column(db.Numeric(10, 5))
    ooproportion = db.Column(db.Numeric(10, 5))
    oocallput = db.Column(db.String(1))
    oocode = db.Column(db.String(30))
    oosource = db.Column(db.Numeric(3, 0, asdecimal=False))


class Norejet(db.Model):
    __tablename__ = "norejet"
    __table_args__ = {"schema": "derives"}

    rjcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    rjdate = db.Column(db.DateTime, nullable=False, index=True)
    rjdata = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    rjsource = db.Column(db.Numeric(3, 0, asdecimal=False))
    rjtype = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    rjflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class Nospecope(db.Model):
    __tablename__ = "nospecope"
    __table_args__ = {"schema": "derives"}

    spidgenop = db.Column(db.Numeric(8, 0, asdecimal=False))
    spcfinsj = db.Column(db.Numeric(8, 0, asdecimal=False))
    spmarcheop = db.Column(db.Numeric(4, 0, asdecimal=False))
    spextype = db.Column(db.String(1))
    spechtype = db.Column(db.String(1))
    spmodecot = db.Column(db.Numeric(4, 0, asdecimal=False))
    spcmois = db.Column(db.Numeric(3, 0, asdecimal=False))
    spcjour = db.Column(db.Numeric(3, 0, asdecimal=False))
    spcstrike = db.Column(db.Numeric(3, 0, asdecimal=False))
    spcodea = db.Column(db.Numeric(3, 0, asdecimal=False))
    spcodeb = db.Column(db.Numeric(3, 0, asdecimal=False))
    spfannee = db.Column(db.String(1))
    spsuffixe = db.Column(db.String(10))
    spsource = db.Column(db.Numeric(3, 0, asdecimal=False))
    spflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    spmethode = db.Column(db.Numeric(3, 0, asdecimal=False))
    splienech = db.Column(db.Numeric(8, 0, asdecimal=False))
    spsplitlet = db.Column(db.String(1))


class Notyperejet(db.Model):
    __tablename__ = "notyperejet"
    __table_args__ = {"schema": "derives"}

    trtype = db.Column(db.Numeric(10, 0, asdecimal=False), primary_key=True)
    trlibelle = db.Column(db.String(30))
    trflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class OctImportfichier(db.Model):
    __tablename__ = "oct_importfichier"
    __table_args__ = {"schema": "derives"}

    impnomval = db.Column(db.String(30), primary_key=True, nullable=False)
    impnombre = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    impdebutligne = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    impcol = db.Column(db.Numeric(4, 0, asdecimal=False), nullable=False)
    imponglet = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    imptypedata = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    imptypefichier = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    imptypeapplicable = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    impordrecol = db.Column(db.Numeric(3, 0, asdecimal=False))


class OctTypeapplicable(db.Model):
    __tablename__ = "oct_typeapplicable"
    __table_args__ = {"schema": "derives"}

    taid = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tanom = db.Column(db.String(60), nullable=False, unique=True)


class OctTypefichier(db.Model):
    __tablename__ = "oct_typefichier"
    __table_args__ = {"schema": "derives"}

    tfid = db.Column(db.Numeric(2, 0, asdecimal=False), primary_key=True)
    tfnom = db.Column(db.String(3), nullable=False, unique=True)


class Param3(db.Model):
    __tablename__ = "param3"
    __table_args__ = {"schema": "derives"}

    code_simu = db.Column(
        db.ForeignKey("derives.simulation3.code_simu", ondelete="CASCADE"),
        nullable=False,
        info="Code de simulation ( clef)",
    )
    code = db.Column(db.Numeric(3, 0, asdecimal=False), info="code valeur")
    valeur = db.Column(db.Numeric(15, 8), info="valeur")

    simulation3 = db.relationship(
        "Simulation3",
        primaryjoin="Param3.code_simu == Simulation3.code_simu",
        backref="param3s",
    )


class Paramcalcgenerique(db.Model):
    __tablename__ = "paramcalcgenerique"
    __table_args__ = {"schema": "derives"}

    gencfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), nullable=False, index=True
    )
    gendatein = db.Column(db.DateTime, nullable=False)
    gendateout = db.Column(db.DateTime)
    genprofil = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    gentypepricer = db.Column(db.Numeric(8, 0, asdecimal=False))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Paramcalcgenerique.gencfin == Instrument.ifcfin",
        backref="paramcalcgeneriques",
    )


class Primepay(db.Model):
    __tablename__ = "primepays"
    __table_args__ = {"schema": "derives"}

    ppcodepays = db.Column(db.Numeric(3, 0, asdecimal=False))
    ppcodecfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), nullable=False, index=True
    )
    ppval = db.Column(db.Numeric(13, 5))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Primepay.ppcodecfin == Instrument.ifcfin",
        backref="primepays",
    )


class Primesecteur(db.Model):
    __tablename__ = "primesecteur"
    __table_args__ = {"schema": "derives"}

    pscodetype = db.Column(db.Numeric(8, 0, asdecimal=False))
    pscodesecteur = db.Column(db.Numeric(8, 0, asdecimal=False))
    pscodematu = db.Column(db.Numeric(3, 0, asdecimal=False))
    psval = db.Column(db.Numeric(13, 5))


class Pyjointure(db.Model):
    __tablename__ = "pyjointure"
    __table_args__ = {"schema": "derives"}

    pyid = db.Column(db.Numeric(12, 0, asdecimal=False))
    pycfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)


class Quotiteoption(db.Model):
    __tablename__ = "quotiteoption"
    __table_args__ = {"schema": "derives"}

    qtcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info=" Cfin du Sjac de l'option / Présent dans Derive.Desjac",
    )
    qtquotitea = db.Column(db.Numeric(13, 5), info="  Quotite ")
    qtquotitee = db.Column(db.Numeric(13, 5))


class RatecurveCotation(db.Model):
    __tablename__ = "ratecurve_cotation"
    __table_args__ = {"schema": "derives"}

    rcdate = db.Column(db.DateTime, nullable=False)
    rcdevise = db.Column(db.Numeric(8, 0, asdecimal=False))
    rccfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    rcsettledate = db.Column(db.DateTime)
    rccotation = db.Column(db.Numeric(13, 5))


class Result3(db.Model):
    __tablename__ = "result3"
    __table_args__ = {"schema": "derives"}

    code_simu = db.Column(
        db.ForeignKey("derives.simulation3.code_simu", ondelete="CASCADE"),
        nullable=False,
        info="Code de simulation ( clef)",
    )
    code = db.Column(db.Numeric(3, 0, asdecimal=False), info="code valeur")
    valeur = db.Column(db.Numeric(15, 8), info="valeur")

    simulation3 = db.relationship(
        "Simulation3",
        primaryjoin="Result3.code_simu == Simulation3.code_simu",
        backref="result3s",
    )


class Scriptcoupon(db.Model):
    __tablename__ = "scriptcoupons"
    __table_args__ = {"schema": "derives"}

    sccfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="Cfin de l instrument",
    )
    scindex = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Id du coupon",
    )
    scdate = db.Column(db.DateTime, nullable=False, info="Date de ficing du coupon")
    scamount = db.Column(db.Numeric(13, 5), nullable=False, info="Montant du coupon")
    scconstatpast = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="DateConstat Est Elle Passee"
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Scriptcoupon.sccfin == Instrument.ifcfin",
        backref="scriptcoupons",
    )


class Simulation3(db.Model):
    __tablename__ = "simulation3"
    __table_args__ = {"schema": "derives"}

    code_simu = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de simulation ( clef)",
    )
    code_modele = db.Column(db.String(15), info="Code du modele")
    identif = db.Column(db.String(20), info="Identificateur de donnees")
    datemin = db.Column(db.DateTime, info="Date de debut historique")
    dateref = db.Column(db.DateTime, info="Date de reference de la performance")
    datemax = db.Column(db.DateTime, info="Date de fin historique")
    perf = db.Column(db.Numeric(13, 5), info="Performance")
    date_h_simu = db.Column(db.DateTime, info="Date et heure de calcul")
    type_simu = db.Column(db.Numeric(3, 0, asdecimal=False), info="Type de simulation")
    nb_simu = db.Column(db.Numeric(4, 0, asdecimal=False), info="Nombre de simulation")


class Stabsdiver(db.Model):
    __tablename__ = "stabsdivers"
    __table_args__ = {"schema": "derives"}

    dacfin = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    dadatemaj = db.Column(db.DateTime, nullable=False)
    dacours = db.Column(db.Numeric(13, 5))
    dadate1a_min = db.Column(db.DateTime)
    dacours1a_min = db.Column(db.Numeric(13, 5))
    daperf1a_min = db.Column(db.Numeric(10, 2))
    dadate1a_max = db.Column(db.DateTime)
    dacours1a_max = db.Column(db.Numeric(13, 5))
    daperf1a_max = db.Column(db.Numeric(10, 2))
    davol_2ah_haus = db.Column(db.Numeric(7, 2))
    davol_2ah_bais = db.Column(db.Numeric(7, 2))
    dachocs_2aq_haus_2 = db.Column(db.Numeric(6, 2))
    dachocs_2aq_bais_2 = db.Column(db.Numeric(6, 2))
    davolhc_2aq_2 = db.Column(db.Numeric(7, 2))
    dachocs_2aq_haus_3 = db.Column(db.Numeric(6, 2))
    dachocs_2aq_bais_3 = db.Column(db.Numeric(6, 2))
    davolhc_2aq_3 = db.Column(db.Numeric(7, 2))
    daecart_hb_1m = db.Column(db.Numeric(10, 3))
    daecart_hb_3m = db.Column(db.Numeric(10, 3))
    daecart_hb_6m = db.Column(db.Numeric(10, 3))
    daecart_hb_1a = db.Column(db.Numeric(10, 3))
    damoyrdt_2ah = db.Column(db.Numeric(10, 4))
    daectrdt_2ah = db.Column(db.Numeric(10, 4))
    daasym_2ah = db.Column(db.Numeric(10, 4))
    dakurtosis_2ah = db.Column(db.Numeric(10, 4))
    dakhideux_2ah = db.Column(db.Numeric(10, 4))
    damoyrdt_2aq = db.Column(db.Numeric(10, 4))
    daectrdt_2aq = db.Column(db.Numeric(10, 4))
    daasym_2aq = db.Column(db.Numeric(10, 4))
    dakurtosis_2aq = db.Column(db.Numeric(10, 4))
    dakhideux_2aq = db.Column(db.Numeric(10, 4))
    dardtjour_3mq = db.Column(db.Numeric(10, 2))
    dardtnuit_3mq = db.Column(db.Numeric(10, 2))
    davoljour_3mq = db.Column(db.Numeric(7, 2))
    davolnuit_3mq = db.Column(db.Numeric(7, 2))
    darsi_20j = db.Column(db.Numeric(10, 2))
    damoycours_50j = db.Column(db.Numeric(10, 2))
    damoycours_200j = db.Column(db.Numeric(10, 2))
    dacapit_1m = db.Column(db.Numeric(10, 2))
    datendance = db.Column(db.Numeric(10, 2))
    datauxrot = db.Column(db.Numeric(10, 2))
    dasharpe_rinv_1a = db.Column(db.Numeric(10, 2))
    dasharpe_rinv_2a = db.Column(db.Numeric(10, 2))


class Stabsperf(db.Model):
    __tablename__ = "stabsperf"
    __table_args__ = {"schema": "derives"}

    pacfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    pacodematu = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    padatemaj = db.Column(db.DateTime, nullable=False)
    padate = db.Column(db.DateTime)
    paperf = db.Column(db.Numeric(18, 4))
    paperf_ann = db.Column(db.Numeric(18, 4))
    paperf_rinv = db.Column(db.Numeric(18, 4))
    paperf_rinv_ann = db.Column(db.Numeric(18, 4))
    paperf_nue = db.Column(db.Numeric(18, 4), info="Performance absolue nette")
    paperf_flux_som = db.Column(
        db.Numeric(18, 4), info="Performance absolue avec flux sommés"
    )
    paperf_flux_rinv = db.Column(
        db.Numeric(18, 4), info="Performance absolue avec flux réinvestis"
    )
    paperf_nue_ann = db.Column(
        db.Numeric(18, 4), info="Performance absolue nette annualisée"
    )
    paperf_flux_som_ann = db.Column(
        db.Numeric(18, 4), info="Performance absolue avec flux sommés annualisée"
    )
    paperf_flux_rinv_ann = db.Column(
        db.Numeric(18, 4), info="Performance absolue avec flux réinvestis annualisée"
    )


class Stabsrisk(db.Model):
    __tablename__ = "stabsrisk"
    __table_args__ = {"schema": "derives"}

    srcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), nullable=False, index=True
    )
    srcodematu = db.Column(db.Numeric(3, 0, asdecimal=False))
    srdatemaj = db.Column(db.DateTime)
    srdiff = db.Column(db.Numeric(13, 5))
    srmoy = db.Column(db.Numeric(13, 5))
    srmin = db.Column(db.Numeric(13, 5))
    srdatemin = db.Column(db.DateTime)
    srmax = db.Column(db.Numeric(13, 5))
    srdatemax = db.Column(db.DateTime)
    srect = db.Column(db.Numeric(13, 5))
    srectmin1a = db.Column(db.Numeric(13, 5))
    srectmax1a = db.Column(db.Numeric(13, 5))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Stabsrisk.srcfin == Instrument.ifcfin",
        backref="stabsrisks",
    )


class Stabsvol(db.Model):
    __tablename__ = "stabsvol"
    __table_args__ = (
        db.CheckConstraint("VATYPE_SERIE in ('Q','H','M')"),
        {"schema": "derives"},
    )

    vacfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    vatype_serie = db.Column(db.String(1), primary_key=True, nullable=False)
    vacodematu = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    vadatemaj = db.Column(db.DateTime, nullable=False)
    vavol = db.Column(db.Numeric(7, 2))
    vavolmoy1a = db.Column(db.Numeric(7, 2))
    vavolect1a = db.Column(db.Numeric(7, 2))
    vavolmin1a = db.Column(db.Numeric(7, 2))
    vavolmax1a = db.Column(db.Numeric(7, 2))
    vavhcorrigee = db.Column(db.Numeric(7, 2))


class Stdiver(db.Model):
    __tablename__ = "stdivers"
    __table_args__ = {"schema": "derives"}

    sdcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Cfin du produit",
    )
    sdmarche = db.Column(
        db.ForeignKey("exane.marche.macode"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Marché de cotation",
    )
    sddate = db.Column(
        db.DateTime, nullable=False, index=True, info="Date de la statistique"
    )
    sdidsession = db.Column(
        db.ForeignKey("exane_batch.appsession.asidsession"),
        nullable=False,
        info="Identifiant de la session de calcul",
    )
    sdturnover = db.Column(db.Numeric(13, 5), info="Taux de rotation de l'indice")
    sdnbcompo = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Nombre de composantes du produit"
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Stdiver.sdcfin == Instrument.ifcfin",
        backref="stdivers",
    )
    appsession = db.relationship(
        "Appsession",
        primaryjoin="Stdiver.sdidsession == Appsession.asidsession",
        backref="stdivers",
    )
    marche = db.relationship(
        "Marche", primaryjoin="Stdiver.sdmarche == Marche.macode", backref="stdivers"
    )


class Strelcorr(db.Model):
    __tablename__ = "strelcorr"
    __table_args__ = (
        db.CheckConstraint("CRDIV_COUP in ('O','N')"),
        db.CheckConstraint("CRTYPE_SERIE in ('Q','H','M')"),
        {"schema": "derives"},
    )

    crcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    crref = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    crdiv_coup = db.Column(db.String(1), primary_key=True, nullable=False)
    crdev = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    crtype_serie = db.Column(db.String(1), primary_key=True, nullable=False)
    crcodematu = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    crdatemaj = db.Column(db.DateTime, nullable=False)
    crbeta = db.Column(db.Numeric(10, 4))
    cralpha = db.Column(db.Numeric(10, 4))
    crrisqspe = db.Column(db.Numeric(10, 4))
    crrisqsys = db.Column(db.Numeric(10, 4))
    crr2 = db.Column(db.Numeric(10, 4))
    crtstudent = db.Column(db.Numeric(13, 5))


class Streldiver(db.Model):
    __tablename__ = "streldivers"
    __table_args__ = (
        db.CheckConstraint("DRDIV_COUP in ('O','N')"),
        {"schema": "derives"},
    )

    drcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    drref = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    drdiv_coup = db.Column(db.String(1), primary_key=True, nullable=False)
    drdev = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    drdatemaj = db.Column(db.DateTime, nullable=False)
    drcours = db.Column(db.Numeric(10, 2))
    drcoursref = db.Column(db.Numeric(10, 2))
    drbeta_2ah_haus = db.Column(db.Numeric(10, 4))
    drr2_2ah_haus = db.Column(db.Numeric(10, 4))
    drbeta_2ah_bais = db.Column(db.Numeric(10, 4))
    drr2_2ah_bais = db.Column(db.Numeric(10, 4))
    drrsibeta_20j = db.Column(db.Numeric(10, 2))


class Strelperf(db.Model):
    __tablename__ = "strelperf"
    __table_args__ = (
        db.CheckConstraint("PRDIV_COUP in ('O','N')"),
        {"schema": "derives"},
    )

    prcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    prref = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    prdiv_coup = db.Column(db.String(1), primary_key=True, nullable=False)
    prdev = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    prcodematu = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    prdatemaj = db.Column(db.DateTime, nullable=False)
    prdate = db.Column(db.DateTime)
    prperf = db.Column(db.Numeric(18, 4))
    prperf_ann = db.Column(db.Numeric(18, 4))
    prperf_nue = db.Column(db.Numeric(18, 4), info="Performance relative nette")
    prperf_flux_som = db.Column(
        db.Numeric(18, 4), info="Performance relative avec flux sommés"
    )
    prperf_flux_rinv = db.Column(
        db.Numeric(18, 4), info="Performance relative avec flux réinvestis"
    )
    prperf_nue_ann = db.Column(
        db.Numeric(18, 4), info="Performance relative nette annualisée"
    )
    prperf_flux_som_ann = db.Column(
        db.Numeric(18, 4), info="Performance relative avec flux sommés annualisée"
    )
    prperf_flux_rinv_ann = db.Column(
        db.Numeric(18, 4), info="Performance relative avec flux réinvestis annualisée"
    )


class Typebloomberg(db.Model):
    __tablename__ = "typebloomberg"
    __table_args__ = {"schema": "derives"}

    tbcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True, info="Code")
    tbtype = db.Column(
        db.String(64), nullable=False, info="Type de la ressource Bloomberg"
    )

    typepayoff = db.relationship(
        "Typepayoff",
        secondary="derives.correspayofftypebloomberg",
        backref="typebloombergs",
    )


class VBaction(db.Model):
    __tablename__ = "v_baction"
    __table_args__ = {"schema": "derives"}

    accfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    acdate = db.Column(db.DateTime, nullable=False)
    acnom = db.Column(db.String(60), nullable=False)
    acmktcap = db.Column(db.Numeric(18, 2))
    acrdtnetdiv_last = db.Column(db.Numeric(asdecimal=False))
    acrdtafdiv_last = db.Column(db.Numeric(asdecimal=False))
    acrdtnetdiv_next = db.Column(db.Numeric(13, 5))
    acrdtbrutdiv_next = db.Column(db.Numeric(13, 5))
    acrdtafdiv_next = db.Column(db.Numeric(asdecimal=False))
    accodesect = db.Column(db.Numeric(8, 0, asdecimal=False))
    acnote_rsk = db.Column(db.String(4))
    acdate_lastoff = db.Column(db.DateTime)
    acdate_nextest = db.Column(db.DateTime)
    acdate_modif = db.Column(db.DateTime)
    acnb_est = db.Column(db.Numeric(asdecimal=False))
    acflag_etat = db.Column(db.Numeric(asdecimal=False))


class VBobligation(db.Model):
    __tablename__ = "v_bobligation"
    __table_args__ = {"schema": "derives"}

    bbcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    bbdate = db.Column(db.DateTime, nullable=False)
    bbnom = db.Column(db.String(60), nullable=False)
    bbmktcap = db.Column(db.Numeric(18, 2))
    bbprix = db.Column(db.Numeric(13, 5))
    bbcouponcouru = db.Column(db.Numeric(13, 5))
    bbrdt = db.Column(db.Numeric(13, 5))
    bbspr_ex = db.Column(db.Numeric(13, 5))
    bbnote_ex = db.Column(db.String(0))
    bbpays = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    bbsecteur = db.Column(db.Numeric(8, 0, asdecimal=False))
    bbdev = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    bberreur = db.Column(db.Numeric(13, 5))
    bbspread = db.Column(db.Numeric(13, 5))
    bbduration = db.Column(db.Numeric(13, 5))
    bbecart_prix = db.Column(db.Numeric(13, 5))
    bbecart_rdt = db.Column(db.Numeric(13, 5))
    bbflag_etat = db.Column(db.Numeric(asdecimal=False))


class VHobligation(db.Model):
    __tablename__ = "v_hobligation"
    __table_args__ = {"schema": "derives"}

    hbcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    hbdate = db.Column(db.DateTime, nullable=False)
    hbprix = db.Column(db.Numeric(13, 5))
    hbrdt = db.Column(db.Numeric(13, 5))
    hbspr_ex = db.Column(db.Numeric(13, 5))
    hbnote_ex = db.Column(db.String(0))
    hbspread = db.Column(db.Numeric(13, 5))
    hbduration = db.Column(db.Numeric(13, 5))
    hbecart_prix = db.Column(db.Numeric(13, 5))
    hbecart_rdt = db.Column(db.Numeric(13, 5))
    hberreur = db.Column(db.Numeric(13, 5))


class VHrecupintraday(db.Model):
    __tablename__ = "v_hrecupintraday"
    __table_args__ = {"schema": "derives"}

    hrcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    hrsource = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    hrdate = db.Column(db.DateTime, nullable=False)
    hrhorodatestart = db.Column(db.DateTime, nullable=False)
    hrhorodateend = db.Column(db.DateTime)
    hridsession = db.Column(db.Numeric(9, 0, asdecimal=False), nullable=False)
    hrmarche = db.Column(db.Numeric(8, 0, asdecimal=False))
    hrpriop = db.Column(db.Numeric(13, 5))
    hropen = db.Column(db.Numeric(13, 5))
    hrclose = db.Column(db.Numeric(13, 5))
    hrlast = db.Column(db.Numeric(13, 5))
    hrsettle = db.Column(db.Numeric(13, 5))
    hrbid = db.Column(db.Numeric(13, 5))
    hrask = db.Column(db.Numeric(13, 5))
    hrbidvolume = db.Column(db.Numeric(13, 5))
    hraskvolume = db.Column(db.Numeric(13, 5))
    hrprisj = db.Column(db.Numeric(13, 5))
    hrvolimp = db.Column(db.Numeric(5, 2))
    hrvaltheo = db.Column(db.Numeric(13, 5))
    hrpo = db.Column(db.Numeric(12, 0, asdecimal=False))
    hrvolqute = db.Column(db.Numeric(16, 0, asdecimal=False))
    hrvolcapi = db.Column(db.Numeric(16, 0, asdecimal=False))
    hrlasttradedate = db.Column(db.DateTime)
    hrdev = db.Column(db.Numeric(8, 0, asdecimal=False))


class VHsmile(db.Model):
    __tablename__ = "v_hsmile"
    __table_args__ = {"schema": "derives"}

    smcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    smdate = db.Column(db.DateTime, nullable=False)
    smdatematu = db.Column(db.DateTime, nullable=False)
    smnbjours = db.Column(db.Numeric(6, 0, asdecimal=False))
    smforward = db.Column(db.Numeric(13, 5))
    smvatm = db.Column(db.Numeric(13, 5))
    smsmile = db.Column(db.Numeric(13, 5))
    smcurve = db.Column(db.Numeric(13, 5))
    smerreur = db.Column(db.Numeric(13, 5))
    smnbdata = db.Column(db.Numeric(6, 0, asdecimal=False))
    smnboptim = db.Column(db.Numeric(6, 0, asdecimal=False))
    smflag_etat = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    smncode = db.Column(db.Numeric(5, 0, asdecimal=False))


class VHsurface(db.Model):
    __tablename__ = "v_hsurface"
    __table_args__ = {"schema": "derives"}

    sucfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Cfin du sous-jacent"
    )
    sudate = db.Column(db.DateTime, nullable=False, info="Date de calcul")
    sudatematu = db.Column(db.DateTime, nullable=False, info="Date de maturité")
    sustatusdatematu = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        info="Type de Maturité (1:réelle,2:normée)",
    )
    sustrike = db.Column(db.Numeric(13, 5), nullable=False, info="Strike Option")
    sustatusstrike = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        info="Type de Strike (1:réel,2:fictif)",
    )
    suvi = db.Column(db.Numeric(13, 5), info="Volatilité Implicite")
    suvmodele = db.Column(db.Numeric(13, 5), info="Deprecated: Type de modele")
    suvmodeleobj = db.Column(db.Numeric(13, 5), info="Deprecated: Indice de modele")
    suvsmile = db.Column(db.Numeric(13, 5), info="Smile")
    suflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), nullable=False, info="Type de surface (1,7)"
    )


class VIdxSjacSpot(db.Model):
    __tablename__ = "v_idx_sjac_spot"
    __table_args__ = {"schema": "derives"}

    cfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cfinsjac = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    valuedate = db.Column(db.DateTime, nullable=False)
    coursdirty = db.Column(db.Numeric(asdecimal=False))
    coupon = db.Column(db.Numeric(asdecimal=False))


class VIdxSjacSpotH(db.Model):
    __tablename__ = "v_idx_sjac_spot_h"
    __table_args__ = {"schema": "derives"}

    cfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cfinsjac = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    valuedate = db.Column(db.DateTime, nullable=False)
    coursdirty = db.Column(db.Numeric(asdecimal=False))
    coupon = db.Column(db.Numeric(asdecimal=False))


class VLsurface(db.Model):
    __tablename__ = "v_lsurface"
    __table_args__ = {"schema": "derives"}

    sucfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Cfin du sous-jacent"
    )
    sudate = db.Column(db.DateTime, nullable=False, info="Date de calcul")
    sudatematu = db.Column(db.DateTime, nullable=False, info="Date de maturité")
    sustatusdatematu = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        info="Type de Maturité (1:réelle,2:normée)",
    )
    sustrike = db.Column(db.Numeric(13, 5), nullable=False, info="Strike Option")
    sustatusstrike = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        info="Type de Strike (1:réel,2:fictif)",
    )
    suvi = db.Column(db.Numeric(13, 5), info="Volatilité Implicite")
    suvmodele = db.Column(db.Numeric(13, 5), info="Deprecated: Type de modele")
    suvmodeleobj = db.Column(db.Numeric(13, 5), info="Deprecated: Indice de modele")
    suvsmile = db.Column(db.Numeric(13, 5), info="Smile")
    suflag_etat = db.Column(
        db.Numeric(1, 0, asdecimal=False), nullable=False, info="Type de surface (1,7)"
    )


class VPerimVioptFlag3(db.Model):
    __tablename__ = "v_perim_viopt_flag_3"
    __table_args__ = {"schema": "derives"}

    cfin_option = db.Column(db.Numeric(8, 0, asdecimal=False), info="Cfin de l'option")
    marche_option = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="Code du marché de récupération de l'option",
    )


class VWebBconvertible(db.Model):
    __tablename__ = "v_web_bconvertible"
    __table_args__ = {"schema": "derives"}

    cvcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    cvdate = db.Column(db.DateTime)
    cvnom = db.Column(db.String(60))
    cvsjac = db.Column(db.Numeric(8, 0, asdecimal=False))
    cvmktcapini = db.Column(db.Numeric(18, 2))
    cvmktcap = db.Column(db.Numeric(18, 2))
    cvmktcapsj = db.Column(db.Numeric(18, 2))
    cvcall = db.Column(db.Numeric(13, 5))
    cvdatedebcall = db.Column(db.DateTime)
    cvdatefincall = db.Column(db.DateTime)
    cvtriggercall = db.Column(db.Numeric(13, 5))
    cvcroisstrig = db.Column(db.Numeric(13, 5))
    cvnominal = db.Column(db.Numeric(18, 5))
    cvput = db.Column(db.Numeric(13, 5))
    cvdatedebput = db.Column(db.DateTime)
    cvdaterembo = db.Column(db.DateTime)
    cvprimerembo = db.Column(db.Numeric(13, 5))
    cvsj = db.Column(db.Numeric(13, 5))
    cvdr = db.Column(db.Numeric(13, 5))
    cvcoupcouru = db.Column(db.Numeric(13, 5))
    cvprixpiedcoup = db.Column(db.Numeric(13, 5))
    cvduration = db.Column(db.Numeric(13, 5))
    cvdureevie = db.Column(db.Numeric(13, 5))
    cvpayback = db.Column(db.Numeric(13, 5))
    cvsproat = db.Column(db.Numeric(13, 5))
    cvrdtcall = db.Column(db.Numeric(13, 5))
    cvrdtput = db.Column(db.Numeric(13, 5))
    cvrdtmaturite = db.Column(db.Numeric(13, 5))
    cvrdtcourant = db.Column(db.Numeric(13, 5))
    cvprimebrute = db.Column(db.Numeric(13, 5))
    cvprimebrutea = db.Column(db.Numeric(13, 5))
    cvprimenette = db.Column(db.Numeric(13, 5))
    cvprimenettea = db.Column(db.Numeric(13, 5))
    cvvalactuflat = db.Column(db.Numeric(13, 5))
    cvvalactuptb = db.Column(db.Numeric(13, 5))
    cvbaisseflat = db.Column(db.Numeric(13, 5))
    cvbaisseptb = db.Column(db.Numeric(13, 5))
    cvdelta = db.Column(db.Numeric(13, 5))
    cvdeltanorme = db.Column(db.Numeric(13, 5))
    cvndelta = db.Column(db.String(1))
    cvrho = db.Column(db.Numeric(13, 5))
    cvnrho = db.Column(db.String(1))
    cvvaltheo = db.Column(db.Numeric(13, 5))
    cvnvaltheo = db.Column(db.String(1))
    cvdecote = db.Column(db.Numeric(13, 5))
    cvdw20 = db.Column(db.Numeric(13, 5))
    cvdw10 = db.Column(db.Numeric(13, 5))
    cvup10 = db.Column(db.Numeric(13, 5))
    cvup20 = db.Column(db.Numeric(13, 5))
    cvdw20pb = db.Column(db.Numeric(13, 5))
    cvdw10pb = db.Column(db.Numeric(13, 5))
    cvup10pb = db.Column(db.Numeric(13, 5))
    cvup20pb = db.Column(db.Numeric(13, 5))
    cvnote_spr = db.Column(db.String(32))
    cvnote_div = db.Column(db.String(1))
    cvnote_vol = db.Column(db.String(1))
    cvnote_rsk = db.Column(db.String(1))
    cvspr_ex = db.Column(db.Numeric(13, 5))
    cvcrdiv_ex = db.Column(db.Numeric(13, 5))
    cvvol_ex = db.Column(db.Numeric(13, 5))
    cvvolmax_ex = db.Column(db.Numeric(13, 5))
    cvtauxref = db.Column(db.Numeric(13, 5))
    cvmatref = db.Column(db.Numeric(13, 5))
    cvvega = db.Column(db.Numeric(13, 5))
    cvnvega = db.Column(db.String(1))
    cvvegapct = db.Column(db.Numeric(13, 5))
    cvrkqds = db.Column(db.Numeric(13, 5))
    cvnrkqds = db.Column(db.String(1))
    cvrkdiv = db.Column(db.Numeric(13, 5))
    cvnrkdiv = db.Column(db.String(1))
    cvsynthese = db.Column(db.Numeric(2, 0, asdecimal=False))
    cvflag_etat = db.Column(db.Numeric(asdecimal=False))
    cvdirtyvalue = db.Column(db.Numeric(13, 5))
    cvtheta = db.Column(db.Numeric(13, 5))
    cvntheta = db.Column(db.String(1))
    cvtemp = db.Column(db.Numeric(13, 5))
    cvvactptbmatu = db.Column(db.Numeric(13, 5))
    cvbaisseptbmatu = db.Column(db.Numeric(13, 5))
    cvdurationput = db.Column(db.Numeric(13, 5))
    cvvactptbput = db.Column(db.Numeric(13, 5))
    cvbaisseptbput = db.Column(db.Numeric(13, 5))
    cvsprput = db.Column(db.Numeric(13, 5))
    cvtauxput = db.Column(db.Numeric(13, 5))
    cvvaltheoput = db.Column(db.Numeric(13, 5))
    cvtempput = db.Column(db.Numeric(13, 5))
    cvdeltaput = db.Column(db.Numeric(13, 5))
    cvdeltanormeput = db.Column(db.Numeric(13, 5))
    cvvegaput = db.Column(db.Numeric(13, 5))
    cvthetaput = db.Column(db.Numeric(13, 5))
    cvrhoput = db.Column(db.Numeric(13, 5))
    cvdw20put = db.Column(db.Numeric(13, 5))
    cvdw10put = db.Column(db.Numeric(13, 5))
    cvup10put = db.Column(db.Numeric(13, 5))
    cvup20put = db.Column(db.Numeric(13, 5))
    cvgamma = db.Column(db.Numeric(13, 5))
    cvgammaput = db.Column(db.Numeric(13, 5))
    cvrkqdsput = db.Column(db.Numeric(13, 5))
    cvspreadimp = db.Column(db.Numeric(13, 5))
    cvsensiaction = db.Column(db.Numeric(13, 5))
    cvperfvi1d = db.Column(db.Numeric(asdecimal=False))
    cvperfvi1w = db.Column(db.Numeric(asdecimal=False))
    cvperfvi1m = db.Column(db.Numeric(asdecimal=False))
    cvprixparite = db.Column(db.Numeric(13, 5))


class VarSwapLvBbg(db.Model):
    __tablename__ = "var_swap_lv_bbg"
    __table_args__ = (
        db.CheckConstraint("VSBDATERECUP = TRUNC(VSBDATERECUP)"),
        {"schema": "derives"},
    )

    vsbcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="Cfin du produit",
    )
    vsbdaterecup = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Date de récupération des données",
    )
    vsbmaturite = db.Column(
        db.ForeignKey("exane.maturite.mtcode"),
        primary_key=True,
        nullable=False,
        info="Maturité du VARSWAP (EXANE.MATURITE)",
    )
    vsbvaleur = db.Column(db.Numeric(10, 5), info="Niveau du varswap ")
    vsbstrike = db.Column(db.Numeric(10, 5), info="Strike du varswap")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="VarSwapLvBbg.vsbcfin == Instrument.ifcfin",
        backref="var_swap_lv_bbgs",
    )
    maturite = db.relationship(
        "Maturite",
        primaryjoin="VarSwapLvBbg.vsbmaturite == Maturite.mtcode",
        backref="var_swap_lv_bbgs",
    )


class Volimpl(db.Model):
    __tablename__ = "volimpl"
    __table_args__ = {"schema": "derives"}

    vocfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    lcorr = db.Column(db.Numeric(8, 0, asdecimal=False))
    lvlt = db.Column(db.Numeric(8, 0, asdecimal=False))
    lvct = db.Column(db.Numeric(8, 0, asdecimal=False))
    beta1 = db.Column(db.Numeric(12, 6))
    beta2 = db.Column(db.Numeric(12, 6))
    alpha = db.Column(db.Numeric(12, 6))
    r2 = db.Column(db.Numeric(12, 6))
    moy_vi = db.Column(db.Numeric(12, 6))
    moy_vlt = db.Column(db.Numeric(12, 6))
    moy_vct = db.Column(db.Numeric(12, 6))
    ect_vi = db.Column(db.Numeric(12, 6))
    ect_vlt = db.Column(db.Numeric(12, 6))
    ect_vct = db.Column(db.Numeric(12, 6))
    lastvlt = db.Column(db.Numeric(12, 6))
    lastvct = db.Column(db.Numeric(12, 6))


class Agence(db.Model):
    __tablename__ = "agence"
    __table_args__ = {"schema": "exane"}

    agcode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code agence de notation",
    )
    agnom = db.Column(db.String(20), nullable=False, info="Nom agence de notation")


class Basecc(db.Model):
    __tablename__ = "basecc"
    __table_args__ = {"schema": "exane"}

    bacode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de la convention de calcul du coupon couru",
    )
    banom = db.Column(
        db.String(15),
        nullable=False,
        info="Libellé de la convention de calcul du coupon couru",
    )


class Calendriersdescription(db.Model):
    __tablename__ = "calendriersdescription"
    __table_args__ = (
        db.CheckConstraint("CNDefiniParJourOuvre IN ('O','N')"),
        {"schema": "exane"},
    )

    cncode = db.Column(db.Numeric(10, 0, asdecimal=False), primary_key=True)
    cndefiniparjourouvre = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="O Indique si les jours définissant le calendrier sont des jours ouverts de type 33",
    )
    cnnom = db.Column(db.String(256), info="Libellé du calendrier")


class Contributeur(db.Model):
    __tablename__ = "contributeur"
    __table_args__ = {"schema": "exane"}

    cocode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="Code contributeur"
    )
    conom = db.Column(db.String(15), info="Nom contributeur")


class Cotation(db.Model):
    __tablename__ = "cotation"
    __table_args__ = {"schema": "exane"}

    cotcfin = db.Column(
        db.ForeignKey("exane.produits.prcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        info="Code de l'instrument financier",
    )
    cotmarche = db.Column(
        db.ForeignKey("exane.marche.macode"),
        primary_key=True,
        nullable=False,
        info="Code du marché de cotation",
    )
    cotstatut = db.Column(db.ForeignKey("exane.typestatut.tstcode"))

    produit = db.relationship(
        "Produit", primaryjoin="Cotation.cotcfin == Produit.prcfin", backref="cotations"
    )
    marche = db.relationship(
        "Marche", primaryjoin="Cotation.cotmarche == Marche.macode", backref="cotations"
    )
    typestatut = db.relationship(
        "Typestatut",
        primaryjoin="Cotation.cotstatut == Typestatut.tstcode",
        backref="cotations",
    )


class Lastfondsrecette(Cotation):
    __tablename__ = "lastfondsrecette"
    __table_args__ = (
        db.ForeignKeyConstraint(
            ["lecfin", "lemarche"],
            ["exane.cotation.cotcfin", "exane.cotation.cotmarche"],
            ondelete="CASCADE",
        ),
        {"schema": "derives"},
    )

    lecfin = db.Column(
        db.ForeignKey("exane.fonds.fdcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
    )
    lemarche = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ledate = db.Column(db.DateTime, nullable=False)
    lenav = db.Column(db.Numeric(13, 5), nullable=False)
    lesjac = db.Column(db.Numeric(13, 5))
    ledatepr = db.Column(db.DateTime)
    lenavpr = db.Column(db.Numeric(13, 5))
    lesjacpr = db.Column(db.Numeric(13, 5))
    ledatecotation = db.Column(db.DateTime)
    lecapi = db.Column(db.Numeric(21, 5))

    fond = db.relationship(
        "Fond",
        primaryjoin="Lastfondsrecette.lecfin == Fond.fdcfin",
        backref="lastfondsrecettes",
    )


class Lastobrecette(Cotation):
    __tablename__ = "lastobrecette"
    __table_args__ = (
        db.ForeignKeyConstraint(
            ["lbcfin", "lbmarche"],
            ["exane.cotation.cotcfin", "exane.cotation.cotmarche"],
            ondelete="CASCADE",
        ),
        {"schema": "derives"},
    )

    lbcfin = db.Column(
        db.ForeignKey("exane.produits.prcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
    )
    lbmarche = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    lbdate = db.Column(db.DateTime, nullable=False)
    lbbid_rdt = db.Column(db.Numeric(13, 5))
    lbbid_prix = db.Column(db.Numeric(13, 2))
    lbask_rdt = db.Column(db.Numeric(13, 5))
    lbask_prix = db.Column(db.Numeric(13, 2))
    lbdatecotation = db.Column(db.DateTime)

    produit = db.relationship(
        "Produit",
        primaryjoin="Lastobrecette.lbcfin == Produit.prcfin",
        backref="lastobrecettes",
    )


class Lastrecette(Cotation):
    __tablename__ = "lastrecette"
    __table_args__ = (
        db.ForeignKeyConstraint(
            ["lacfin", "lamarche"],
            ["exane.cotation.cotcfin", "exane.cotation.cotmarche"],
            ondelete="CASCADE",
        ),
        {"schema": "derives"},
    )

    lacfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    lamarche = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ladate = db.Column(db.DateTime, nullable=False)
    lapriclos = db.Column(db.Numeric(13, 5))
    lapriopen = db.Column(db.Numeric(13, 5))
    laprimoypond = db.Column(db.Numeric(13, 5))
    lapo = db.Column(db.Numeric(16, 5))
    lavolqute = db.Column(db.Numeric(18, 2))
    lavolcapi = db.Column(db.Numeric(18, 2))
    ladatepr = db.Column(db.DateTime)
    lapriclospr = db.Column(db.Numeric(13, 5))
    lapriopenpr = db.Column(db.Numeric(13, 5))
    laprimoypondpr = db.Column(db.Numeric(13, 5))
    lapopr = db.Column(db.Numeric(16, 2))
    lavolqutepr = db.Column(db.Numeric(18, 2))
    lavolcapipr = db.Column(db.Numeric(18, 2))
    lahigh = db.Column(db.Numeric(13, 5))
    lahighpr = db.Column(db.Numeric(13, 5))
    lalow = db.Column(db.Numeric(13, 5))
    lalowpr = db.Column(db.Numeric(13, 5))
    labid = db.Column(db.Numeric(13, 5))
    laask = db.Column(db.Numeric(13, 5))
    labidpr = db.Column(db.Numeric(13, 5))
    laaskpr = db.Column(db.Numeric(13, 5))
    ladatecotation = db.Column(db.DateTime)


class Famille(db.Model):
    __tablename__ = "famille"
    __table_args__ = {"schema": "exane"}

    facode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de la famille d'un type dinstruments",
    )
    fanom = db.Column(
        db.String(15), nullable=False, info="Nom de la famille d'un type dinstruments"
    )


class Grpuser(db.Model):
    __tablename__ = "grpuser"
    __table_args__ = {"schema": "exane"}

    gucode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code du groupe d'utilisateurs",
    )
    gunom = db.Column(db.String(15), nullable=False, info="Nomdu groupe d'utilisateurs")


class Hrejetmessage(db.Model):
    __tablename__ = "hrejetmessage"
    __table_args__ = {"schema": "exane"}

    rmid = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Id du message d'erreur",
    )
    rmlibelle = db.Column(db.String(4000), nullable=False, info="Message d'erreur")
    rmhashcode = db.Column(
        db.Numeric(38, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="Clé de hashage de ora_hash(rmlibelle)",
    )


class Instrument(db.Model):
    __tablename__ = "instruments"
    __table_args__ = (
        db.CheckConstraint(
            "IFVALIDATION = 'N' OR IFVALIDATION = 'M' OR IFVALIDATION = 'R' OR IFVALIDATION = 'V'"
        ),
        db.CheckConstraint("ifcfin <> 0"),
        db.Index("idx1_instrument", "ifcfin", "ifpayoff", "iftype"),
        {"schema": "exane"},
    )

    ifcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    ifstatut = db.Column(
        db.ForeignKey("exane.typestatut.tstcode"),
        nullable=False,
        index=True,
        info="Code du statut d'un instrument financier",
    )
    iftype = db.Column(
        db.ForeignKey("exane.typeinstrument.tycode"),
        nullable=False,
        index=True,
        info="Code du type d'instrument",
    )
    ifnom = db.Column(db.String(60), nullable=False, info="Nom de l'instrument")
    ifmaj = db.Column(
        db.DateTime, nullable=False, info="Date de mise à jour de l'instrument"
    )
    ifpayoff = db.Column(
        db.ForeignKey("exane.typepayoff.tflcode"),
        index=True,
        server_default=db.FetchedValue(),
        info="type de payoff de l'instrument",
    )
    ifcontrat = db.Column(
        db.ForeignKey("exane.typecontrat.tctcode"),
        index=True,
        server_default=db.FetchedValue(),
        info="type de contrat de l'instrument",
    )
    ifvalidation = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Gere la validation des instruments, toutes les caracteristiques du produit qui peuvent influencer le prix  agissent sur le champ IFVALIDATION",
    )
    ifproprietaire = db.Column(
        db.ForeignKey("exane.typeproprietaire.tpcode"),
        info="Propriétaire de l'instument",
    )
    iftypofo = db.Column(
        db.ForeignKey("exane.typofoinstrumentsautorisees.tacode"),
        index=True,
        info="Nouvelle typologie Front des produits cf. EXANE.TYPOFOINSTRUMENTSAUTORISEES",
    )

    typecontrat = db.relationship(
        "Typecontrat",
        primaryjoin="Instrument.ifcontrat == Typecontrat.tctcode",
        backref="instruments",
    )
    typepayoff = db.relationship(
        "Typepayoff",
        primaryjoin="Instrument.ifpayoff == Typepayoff.tflcode",
        backref="instruments",
    )
    typeproprietaire = db.relationship(
        "Typeproprietaire",
        primaryjoin="Instrument.ifproprietaire == Typeproprietaire.tpcode",
        backref="instruments",
    )
    typestatut = db.relationship(
        "Typestatut",
        primaryjoin="Instrument.ifstatut == Typestatut.tstcode",
        backref="instruments",
    )
    typeinstrument = db.relationship(
        "Typeinstrument",
        primaryjoin="Instrument.iftype == Typeinstrument.tycode",
        backref="instruments",
    )
    typofoinstrumentsautorisee = db.relationship(
        "Typofoinstrumentsautorisee",
        primaryjoin="Instrument.iftypofo == Typofoinstrumentsautorisee.tacode",
        backref="instruments",
    )


class Baction(Instrument):
    __tablename__ = "bactions"
    __table_args__ = {"schema": "derives"}

    accfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, info="CFIN"
    )
    acdate = db.Column(db.DateTime, nullable=False, info="Date de calcul")
    acmktcap = db.Column(db.Numeric(18, 2), info="Market cap")
    acrdtnetdiv_next = db.Column(
        db.Numeric(13, 5), info="Somme des div de l année fiscale en cours (en %cours)"
    )
    accodesect = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code secteur")
    acnote_rsk = db.Column(db.String(4), info="Note risque")
    acrdtbrutdiv_next = db.Column(
        db.Numeric(13, 5),
        info="Somme des divs (bruts) de l année fiscale en cours (en %cours)",
    )


class Bobligation(Instrument):
    __tablename__ = "bobligation"
    __table_args__ = {"schema": "derives"}

    bbcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, info="CFIN"
    )
    bbdate = db.Column(db.DateTime, nullable=False, info="Date de calcul")
    bbmktcap = db.Column(
        db.Numeric(18, 2),
        info="Cours dirty en devise * nb titres, converti en USD (idem cvmktcap)",
    )
    bbprix = db.Column(db.Numeric(13, 5), info="moyenne bid / ask du prix")
    bbcouponcouru = db.Column(
        db.Numeric(13, 5), info="TI_COUPON_COURU (idem cvcouponcouru)"
    )
    bbrdt = db.Column(
        db.Numeric(13, 5), info="TI_TAUX_RDT_ACTUARIEL (idem cvrdtmaturite)"
    )
    bbspr_ex = db.Column(db.Numeric(13, 5), info="null par défaut (hyp. de spread)")
    bbsecteur = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="secteur de l émetteur (si null, secteur du garant)",
    )
    bberreur = db.Column(db.Numeric(13, 5), info="ecart mid rendement vs bbrdt")
    bbspread = db.Column(db.Numeric(13, 5), info="ecart bbrdt vs bbtauxref")
    bbduration = db.Column(db.Numeric(13, 5), info="TI_DURATION (idem cvduration)")
    bbecart_prix = db.Column(db.Numeric(13, 5), info="ecart bid ask du prix")
    bbecart_rdt = db.Column(db.Numeric(13, 5), info="ecart bid ask du rendement")
    bbdaterembo = db.Column(db.DateTime, info="date de remboursement")
    bbprimerembo = db.Column(db.Numeric(13, 5), info="prime de remboursement")
    bbmontant = db.Column(db.Numeric(13, 5), info="montant du prochain coupon")
    bbremb = db.Column(db.Numeric(13, 5), info="montant de remboursement à échéance")
    bbprixpiedcoup = db.Column(
        db.Numeric(13, 5), info="prix pied de coupon (prix en % hors coupon couru)"
    )
    bbdirtyvalule = db.Column(
        db.Numeric(13, 5),
        info="prix en devise coupon couru inclus, converti en EUR (idem cvdirtyvalue)",
    )
    bbdureevie = db.Column(db.Numeric(13, 5), info="durée de vie restante (nb jours)")
    bbrdtcourant = db.Column(
        db.Numeric(13, 5),
        info="somme coupon(s) à venir sur un an glissant / bbdirtyvalue * 100",
    )
    bbrho = db.Column(db.Numeric(13, 5), info="TI_RHO (sensi. Taux ; idem CVRHO)")
    bbnrho = db.Column(db.String(1), info="note sensi. Taux (idem CVNRHO)")
    bbtauxref = db.Column(
        db.Numeric(13, 5), info='taux "CP" à duration en nb jours (bbduration * 365.25)'
    )
    bbrdtcall = db.Column(
        db.Numeric(13, 5), info="rendement actuariel si la prochain call est exercé"
    )
    bbdurationcall = db.Column(
        db.Numeric(13, 5), info="duration si le prochain call est exercé"
    )
    bbtotalreturn = db.Column(
        db.Numeric(13, 5), info="rendement coupon(s) réinvesti(s)"
    )
    bbrdtrecup = db.Column(db.Numeric(13, 5), info="Taux Mid recupere")
    bbdurationrecup = db.Column(db.Numeric(13, 5), info="Duration recuperee")
    bbcouponcoururecup = db.Column(db.Numeric(13, 5), info="Coupon couru recupere")
    bbspreadrecup = db.Column(
        db.Numeric(16, 5),
        info="Spread entre le rendement de l obligation et le taux swap",
    )


class Idxalgebre(Instrument):
    __tablename__ = "idxalgebre"
    __table_args__ = {"schema": "derives"}

    alcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        info="cfin de l indice",
    )
    alcfinconstant = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="cfin de l instrument representant la constante",
    )
    alfrais = db.Column(db.Numeric(13, 8), info="frais quotidien")


class Idxvhcapparam(Instrument):
    __tablename__ = "idxvhcapparam"
    __table_args__ = {"schema": "derives"}

    vcpcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        info="cfin de l indice",
    )
    vcpcfinref = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="cfin de reference pour calculer la VH",
    )
    vcpdiv = db.Column(db.Numeric(13, 5), info="taux des dividendes x.x\\%")
    vcpvhcap = db.Column(db.Numeric(13, 5), info="VHcap du cfin de reference")
    vcpnbjourvh = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Nb de jour pour le calcul de la VH"
    )
    vcpnbjourannee = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="Nb de jour par annee pour le calcul de la VH",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Idxvhcapparam.vcpcfinref == Instrument.ifcfin",
        backref="idxvhcapparams",
    )


class Indicerisque(Instrument):
    __tablename__ = "indicerisque"
    __table_args__ = {"schema": "derives"}

    ircfin = db.Column(db.ForeignKey("exane.instruments.ifcfin"), primary_key=True)
    irmatub = db.Column(db.Numeric(3, 0, asdecimal=False))
    irmatuh = db.Column(db.Numeric(3, 0, asdecimal=False))
    irsub = db.Column(db.Numeric(1, 0, asdecimal=False))


class Intradayopparam(Instrument):
    __tablename__ = "intradayopparam"
    __table_args__ = {"schema": "derives"}

    ipcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        info="Cfin du sous jacent",
    )
    ipwithsj = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        info="Calculs sur les sous-jacents de l'indice",
    )
    ipstrikefocus = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="En % le périmètre du strike autour du spot",
    )
    ipmaturitecode = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="La période max de maturité"
    )


class Scriptg(Instrument):
    __tablename__ = "scriptg"
    __table_args__ = {"schema": "derives"}

    scgcfin = db.Column(db.ForeignKey("exane.instruments.ifcfin"), primary_key=True)
    scgstrike = db.Column(db.Numeric(13, 5))
    scgparite = db.Column(db.Numeric(11, 5))
    scgproportion = db.Column(db.Numeric(11, 5))
    scgscript = db.Column(db.Text)
    scgdureematurite = db.Column(db.ForeignKey("exane.maturite.mtcode"))
    scgstrikesj = db.Column(
        db.Numeric(13, 5), info="Strike du sous-jacent (mono uniquement)"
    )
    scgproduit = db.Column(
        db.Numeric(6, 0, asdecimal=False), info="Nature du produit générique"
    )
    scgresultat = db.Column(
        db.Numeric(6, 0, asdecimal=False), info="Nature du résultat"
    )

    maturite = db.relationship(
        "Maturite",
        primaryjoin="Scriptg.scgdureematurite == Maturite.mtcode",
        backref="scriptgs",
    )


class Solvency2(Instrument):
    __tablename__ = "solvency2"
    __table_args__ = {"schema": "derives"}

    socfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        info="Cfin de l instrument",
    )
    sodate = db.Column(db.DateTime, nullable=False, info="Date des calculs")
    sovalref = db.Column(
        db.Numeric(24, 7), info="Valeur théorique de référence (dev produit)"
    )
    sovaltauxup = db.Column(
        db.Numeric(24, 7),
        info="Composante Risque de Taux avec acroissement de la courbe des taux (dev produit)",
    )
    sovaltauxdown = db.Column(
        db.Numeric(24, 7),
        info="Composante Risque de Taux avec diminution de la courbe des taux (dev produit)",
    )
    sovalspot = db.Column(
        db.Numeric(24, 7), info="Composante Risque Action, stress de Spot (dev produit)"
    )
    sovalvol = db.Column(
        db.Numeric(24, 7),
        info="Composante Risque Action, stress de Volatilité (dev produit)",
    )
    sovalspread = db.Column(
        db.Numeric(24, 7), info="Composante Risque de Spread, calcul basé sur RHO"
    )
    sovalchange = db.Column(db.Numeric(24, 7), info="Composante Risque de Change (EUR)")
    soscr = db.Column(
        db.Numeric(24, 7),
        info="Solvency Capital Requirement pour le Cfin (EUR) avec composante spread basee sur RHO",
    )
    soundlcurr = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Devise du sous-jacent"
    )
    soassetcurr = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Devise de la convertible"
    )
    soupundlfx = db.Column(
        db.Numeric(24, 7), info="Variation de +25% de la devise SSJ/EUR"
    )
    sodownundlfx = db.Column(
        db.Numeric(24, 7), info="Variation de -25% de la devise SSJ/EUR"
    )
    soupassetfx = db.Column(
        db.Numeric(24, 7), info="Variation de +25% de la devise Convert/EUR"
    )
    sodownassetfx = db.Column(
        db.Numeric(24, 7), info="Variation de -25% de la devise Convert/EUR"
    )
    sovalspread2 = db.Column(
        db.Numeric(24, 7),
        info="Composante Risque de Spread, calcul basé sur CREDIT SPREAD",
    )
    soscr2 = db.Column(
        db.Numeric(24, 7),
        info="Solvency Capital Requirement pour le Cfin (EUR) avec composante spread basee sur CREDIT SPREAD",
    )


class Courbetx(Instrument):
    __tablename__ = "courbetx"
    __table_args__ = {"schema": "exane"}

    cbcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    cbfwd = db.Column(
        db.ForeignKey("exane.maturite.mtcode"),
        index=True,
        info="Code maturite d'un taux, d'une volatilité",
    )
    cbcontrib = db.Column(
        db.ForeignKey("exane.contributeur.cocode"), index=True, info="Code contributeur"
    )
    cbnature = db.Column(
        db.ForeignKey("exane.nature.nacode"),
        nullable=False,
        index=True,
        info="Code nature",
    )
    cbmethode = db.Column(
        db.ForeignKey("exane.methode.mecode"),
        nullable=False,
        index=True,
        info="Code methode construction de courbe",
    )
    cbdev = db.Column(
        db.ForeignKey("exane.devise.dvcfin"),
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )

    contributeur = db.relationship(
        "Contributeur",
        primaryjoin="Courbetx.cbcontrib == Contributeur.cocode",
        backref="courbetxes",
    )
    devise = db.relationship(
        "Devise", primaryjoin="Courbetx.cbdev == Devise.dvcfin", backref="courbetxes"
    )
    maturite = db.relationship(
        "Maturite",
        primaryjoin="Courbetx.cbfwd == Maturite.mtcode",
        backref="courbetxes",
    )
    methode = db.relationship(
        "Methode",
        primaryjoin="Courbetx.cbmethode == Methode.mecode",
        backref="courbetxes",
    )
    nature = db.relationship(
        "Nature", primaryjoin="Courbetx.cbnature == Nature.nacode", backref="courbetxes"
    )


class Devise(Instrument):
    __tablename__ = "devise"
    __table_args__ = {"schema": "exane"}

    dvcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    dvpays = db.Column(
        db.ForeignKey("exane.pays.pacode"), nullable=False, index=True, info="Code pays"
    )
    dvcodeiso = db.Column(db.String(3), unique=True)
    dvlibelle = db.Column(db.String(60), info="Libelle de la devise ")

    pay = db.relationship(
        "Pay", primaryjoin="Devise.dvpays == Pay.pacode", backref="devises"
    )


class Fond(Instrument):
    __tablename__ = "fonds"
    __table_args__ = (
        db.CheckConstraint("FDASSVIE IN ('O', 'N')"),
        db.CheckConstraint("FDCONVENTION in ('O', 'N')"),
        db.CheckConstraint("FDCOORDONNE IN ('O', 'N')"),
        db.CheckConstraint("FDOUVERT IN ('O', 'F')"),
        db.CheckConstraint("FDSTATUTFISCAL IN ('O', 'N')"),
        db.CheckConstraint("FDdistrib IN ('D', 'C')"),
        db.CheckConstraint("fdjourperiodicite between 1 and 7"),
        db.CheckConstraint("fdjourperiodicite between 1 and 7"),
        {"schema": "exane"},
    )

    fdcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        info="Code instrument financier              ",
    )
    fddate = db.Column(db.DateTime, info="Date de création                       ")
    fdsocietegestion = db.Column(
        db.ForeignKey("exane.tiers.ticode"),
        info="Société de gestion                     ",
    )
    fddepositaire = db.Column(
        db.ForeignKey("exane.tiers.ticode"),
        info="Dépositaire                            ",
    )
    fdagent = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Agent de calcul                        ",
    )
    fdpays = db.Column(
        db.ForeignKey("exane.pays.pacode"),
        info="Pays juridique                         ",
    )
    fdstatutjuridique = db.Column(
        db.ForeignKey("exane.typestatjuridique.tsjcode"),
        info="Statut juridique (SICAV, FCP, ETF,...) ",
    )
    fdtype = db.Column(
        db.ForeignKey("exane.typefonds.tfcode"),
        info="Type de Fonds (Action, Obligation,...) ",
    )
    fddistrib = db.Column(db.String(1), info="Distribution / Capitalisation          ")
    fdcoordonne = db.Column(
        db.String(1), info="Coordonné                              "
    )
    fdouvert = db.Column(db.String(1), info="Ouvert / Fermé                         ")
    fdstatutfiscal = db.Column(
        db.String(1), info="Statut fiscal (PEA Oui/Non,...)        "
    )
    fdfrais = db.Column(
        db.Numeric(8, 5), info="Frais de gestion                       "
    )
    fddroitentree = db.Column(
        db.Numeric(8, 5), info="Droit d entrée                         "
    )
    fddroitsortie = db.Column(
        db.Numeric(8, 5), info="Droit de sortie                        "
    )
    fdparticipation = db.Column(
        db.Numeric(8, 5), info="Droit de gestion lié à la performance  "
    )
    fdsjac = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        index=True,
        info="Benchmark                              ",
    )
    fdratio = db.Column(
        db.Numeric(13, 5), info="Ratio Fonds / Benchmark                "
    )
    fdobjectiftrack = db.Column(
        db.Numeric(8, 5), info="Objectif tracking error                "
    )
    fdobjectifbeta = db.Column(
        db.Numeric(8, 5), info="Objectif bêta                          "
    )
    fdhoraire = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        info="Horaire valorisation NAV               ",
    )
    fdperiodicitenav = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="Périodicité publication NAV            ",
    )
    fdretardnav = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        info="Retard publication NAV                 ",
    )
    fdmaturite = db.Column(db.DateTime, info="Date de maturité")
    fdassvie = db.Column(db.String(1), info="Eligibilité assurance vie")
    fddatecob = db.Column(db.DateTime, info="Date d'agrément COB")
    fddebutlancement = db.Column(db.DateTime, info="Début période de lancement")
    fdfinlancement = db.Column(db.DateTime, info="Fin période de lancement")
    fdfraisindirect = db.Column(db.Numeric(8, 5), info="Frais de gestion indirect")
    fddroitentreeacquis = db.Column(db.Numeric(8, 5), info="Droit d'entrée acquis")
    fddroitsortieacquis = db.Column(db.Numeric(8, 5), info="Droit de sortie acquis")
    fdrefparticipation = db.Column(
        db.String(255), info="Référence frais de gestion variables"
    )
    fdnavorigine = db.Column(db.Numeric(13, 5), info="NAV d'origine")
    fdcommentnav = db.Column(db.String(255), info="Commentaire calcul NAV")
    fdpreavissouscr = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Préavis de souscription"
    )
    fdpreavisrachat = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Préavis de rachat"
    )
    fdhorairesouscr = db.Column(
        db.Numeric(4, 0, asdecimal=False), info="Heure limite de souscription"
    )
    fdhorairerachat = db.Column(
        db.Numeric(4, 0, asdecimal=False), info="Heure limite de rachat"
    )
    fddroitentreeind = db.Column(db.Numeric(8, 5), info="Droit d'entrée indirect")
    fddroitentreeindacquis = db.Column(
        db.Numeric(8, 5), info="Droit d'entrée indirect acquis"
    )
    fddroitsortieind = db.Column(db.Numeric(8, 5), info="Droit de sortie indirect")
    fddroitsortieindacquis = db.Column(
        db.Numeric(8, 5), info="Droit de sortie indirect acquis"
    )
    fdtiers = db.Column(
        db.ForeignKey("exane.tiers.ticode"), info="Code du Tiers representant ce fond"
    )
    fdcommissaire = db.Column(
        db.ForeignKey("exane.tiers.ticode"), info="Code du commissaire aux comptes"
    )
    fdclientele = db.Column(
        db.ForeignKey("exane.typeclientele.tccode"), info="Code du type de clientèle"
    )
    fdregime = db.Column(db.ForeignKey("exane.typeregimefonds.trfcode"))
    fdfamille = db.Column(db.ForeignKey("exane.typefamillefonds.tfdcode"))
    fdzonegeo = db.Column(db.ForeignKey("exane.zonegeographique.zgcode"))
    fdconvention = db.Column(db.String(1))
    fdliquidite = db.Column(db.ForeignKey("exane.maturite.mtcode"))
    fddelaiachat = db.Column(db.ForeignKey("exane.maturite.mtcode"))
    fddelaivente = db.Column(db.ForeignKey("exane.maturite.mtcode"))
    fduser = db.Column(db.Numeric(3, 0, asdecimal=False))
    fddatemaj = db.Column(db.DateTime)
    fdstrategie = db.Column(db.ForeignKey("exane.typestrategie.tyscode"))
    fdjourperiodicite = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        info="Jour de semaine lié à certaines périodicités (1=Dimanche --> 7=Samedi)",
    )

    typeclientele = db.relationship(
        "Typeclientele",
        primaryjoin="Fond.fdclientele == Typeclientele.tccode",
        backref="fonds",
    )
    tier = db.relationship(
        "Tier",
        primaryjoin="Fond.fdcommissaire == Tier.ticode",
        backref="tier_tier_tier_fonds",
    )
    maturite = db.relationship(
        "Maturite",
        primaryjoin="Fond.fddelaiachat == Maturite.mtcode",
        backref="maturite_maturite_fonds",
    )
    maturite1 = db.relationship(
        "Maturite",
        primaryjoin="Fond.fddelaivente == Maturite.mtcode",
        backref="maturite_maturite_fonds_0",
    )
    tier1 = db.relationship(
        "Tier",
        primaryjoin="Fond.fddepositaire == Tier.ticode",
        backref="tier_tier_tier_fonds_0",
    )
    typefamillefond = db.relationship(
        "Typefamillefond",
        primaryjoin="Fond.fdfamille == Typefamillefond.tfdcode",
        backref="fonds",
    )
    maturite2 = db.relationship(
        "Maturite",
        primaryjoin="Fond.fdliquidite == Maturite.mtcode",
        backref="maturite_maturite_fonds",
    )
    pay = db.relationship(
        "Pay", primaryjoin="Fond.fdpays == Pay.pacode", backref="fonds"
    )
    typeregimefond = db.relationship(
        "Typeregimefond",
        primaryjoin="Fond.fdregime == Typeregimefond.trfcode",
        backref="fonds",
    )
    instrument = db.relationship(
        "Instrument", primaryjoin="Fond.fdsjac == Instrument.ifcfin", backref="fonds"
    )
    tier2 = db.relationship(
        "Tier",
        primaryjoin="Fond.fdsocietegestion == Tier.ticode",
        backref="tier_tier_tier_fonds",
    )
    typestatjuridique = db.relationship(
        "Typestatjuridique",
        primaryjoin="Fond.fdstatutjuridique == Typestatjuridique.tsjcode",
        backref="fonds",
    )
    typestrategie = db.relationship(
        "Typestrategie",
        primaryjoin="Fond.fdstrategie == Typestrategie.tyscode",
        backref="fonds",
    )
    tier3 = db.relationship(
        "Tier",
        primaryjoin="Fond.fdtiers == Tier.ticode",
        backref="tier_tier_tier_fonds_0",
    )
    typefond = db.relationship(
        "Typefond", primaryjoin="Fond.fdtype == Typefond.tfcode", backref="fonds"
    )
    zonegeographique = db.relationship(
        "Zonegeographique",
        primaryjoin="Fond.fdzonegeo == Zonegeographique.zgcode",
        backref="fonds",
    )


class Produit(Instrument):
    __tablename__ = "produits"
    __table_args__ = {"schema": "exane"}

    prcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    prcourbe = db.Column(
        db.ForeignKey("exane.courbetx.cbcfin"),
        index=True,
        info="Code de l'instrument financier",
    )
    prmodecot = db.Column(
        db.ForeignKey("exane.modecot.mocode"),
        nullable=False,
        index=True,
        info="Code mode cotation",
    )
    prpays = db.Column(
        db.ForeignKey("exane.pays.pacode"), nullable=False, index=True, info="Code pays"
    )
    prmarche = db.Column(
        db.ForeignKey("exane.marche.macode"),
        nullable=False,
        index=True,
        info="Code du marché de cotation",
    )
    prdev = db.Column(
        db.ForeignKey("exane.devise.dvcfin"),
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    prdevnominal = db.Column(
        db.ForeignKey("exane.devise.dvcfin", ondelete="CASCADE"),
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    prquotite = db.Column(
        db.Numeric(12, 4), nullable=False, info="Quotité minimale de transaction"
    )
    prcalendrier = db.Column(db.ForeignKey("exane.calendriersdescription.cncode"))

    calendriersdescription = db.relationship(
        "Calendriersdescription",
        primaryjoin="Produit.prcalendrier == Calendriersdescription.cncode",
        backref="produits",
    )
    courbetx = db.relationship(
        "Courbetx",
        primaryjoin="Produit.prcourbe == Courbetx.cbcfin",
        backref="produits",
    )
    devise = db.relationship(
        "Devise",
        primaryjoin="Produit.prdev == Devise.dvcfin",
        backref="devise_produits",
    )
    devise1 = db.relationship(
        "Devise",
        primaryjoin="Produit.prdevnominal == Devise.dvcfin",
        backref="devise_produits_0",
    )
    marche = db.relationship(
        "Marche", primaryjoin="Produit.prmarche == Marche.macode", backref="produits"
    )
    modecot = db.relationship(
        "Modecot", primaryjoin="Produit.prmodecot == Modecot.mocode", backref="produits"
    )
    pay = db.relationship(
        "Pay", primaryjoin="Produit.prpays == Pay.pacode", backref="produits"
    )


class Derive(Produit):
    __tablename__ = "derives"
    __table_args__ = (
        db.CheckConstraint("DECFIN<>DESJAC"),
        db.CheckConstraint("DECFIN<>DESJAC"),
        {"schema": "exane"},
    )

    decfin = db.Column(
        db.ForeignKey("exane.produits.prcfin", ondelete="CASCADE"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    desjac = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        index=True,
        info="Code de l'instrument financier",
    )
    dereg = db.Column(
        db.ForeignKey("exane.mode_reglement.mrcode"),
        info="Libelle du mode de reglement",
    )
    decouv = db.Column(db.String(1), info="Type de couverture")
    deassim = db.Column(db.String(1), info="Type d'assimilation")
    desoulteuro = db.Column(db.Numeric(8, 2), info="Soulte Euro")
    deappelmarge = db.Column(
        db.Enum("O", "N"),
        server_default=db.FetchedValue(),
        info="Précise si le derive fonctionne avec appel de marge et non pas avec une prime (O/N)",
    )

    mode_reglement = db.relationship(
        "ModeReglement",
        primaryjoin="Derive.dereg == ModeReglement.mrcode",
        backref="derives",
    )
    instrument = db.relationship(
        "Instrument",
        primaryjoin="Derive.desjac == Instrument.ifcfin",
        backref="derives",
    )


class Langue(db.Model):
    __tablename__ = "langue"
    __table_args__ = {"schema": "exane"}

    lacode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="code de la langue"
    )
    lanom = db.Column(
        db.String(50), nullable=False, info="libellé francais de la langue"
    )


class Marche(db.Model):
    __tablename__ = "marche"
    __table_args__ = {"schema": "exane"}

    macode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du marché de cotation",
    )
    maplace = db.Column(
        db.ForeignKey("exane.place.plcode"),
        nullable=False,
        index=True,
        info="Code de la place de cotation",
    )
    manom = db.Column(db.String(60), nullable=False, info="Nom du marché de cotation")
    mamic = db.Column(db.String(4), info="Code MIC du marché")
    mafininfo = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Code FinInfo du marché"
    )
    mareuter = db.Column(db.String(3), info="Code Reuter du marché")
    macamelot = db.Column(
        db.String(3), info="Préfixe du code Camelot de la place associée."
    )

    place = db.relationship(
        "Place", primaryjoin="Marche.maplace == Place.plcode", backref="marches"
    )


class Maturite(db.Model):
    __tablename__ = "maturite"
    __table_args__ = {"schema": "exane"}

    mtcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code maturite d'un taux, d'une volatilité",
    )
    mtday = db.Column(db.Numeric(5, 1), info="Maturite en jours")
    mtmonth = db.Column(db.Numeric(5, 1), info="Maturite en mois")
    mtyear = db.Column(db.Numeric(5, 1), info="Maturite en annees")


class Methode(db.Model):
    __tablename__ = "methode"
    __table_args__ = {"schema": "exane"}

    mecode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code methode construction de courbe",
    )
    menom = db.Column(
        db.String(15),
        nullable=False,
        info="Nom methode construction courbe, indicateur taux, volatilité",
    )


class ModeReglement(db.Model):
    __tablename__ = "mode_reglement"
    __table_args__ = {"schema": "exane"}

    mrcode = db.Column(
        db.String(1), primary_key=True, info="Code du mode de réglement."
    )
    mrlibelle = db.Column(
        db.String(60), nullable=False, info="Libéllé du mode de réglement."
    )


class Modecot(db.Model):
    __tablename__ = "modecot"
    __table_args__ = {"schema": "exane"}

    mocode = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, info="Code mode cotation"
    )
    monom = db.Column(db.String(20), nullable=False, info="Libelle mode cotation")


class Modeexptaux(db.Model):
    __tablename__ = "modeexptaux"
    __table_args__ = {"schema": "exane"}

    mecode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    menom = db.Column(db.String(60))


class Nature(db.Model):
    __tablename__ = "nature"
    __table_args__ = {"schema": "exane"}

    nacode = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, info="Code nature"
    )
    nanom = db.Column(db.String(40), nullable=False, info="Nom nature")


class Pay(db.Model):
    __tablename__ = "pays"
    __table_args__ = {"schema": "exane"}

    pacode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="Code pays"
    )
    panom = db.Column(db.String(25), nullable=False, info="Nom pays")
    panomfr = db.Column(db.String(25), info="Nom francais pays\t")
    paabrege = db.Column(db.String(3), info="Abrege du pays\t")
    pacodeiso = db.Column(db.String(6))
    palangue = db.Column(
        db.ForeignKey("exane.langue.lacode"),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Langue parlée dans le pays",
    )

    langue = db.relationship(
        "Langue", primaryjoin="Pay.palangue == Langue.lacode", backref="pays"
    )


class Place(db.Model):
    __tablename__ = "place"
    __table_args__ = {"schema": "exane"}

    plcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de la place de cotation",
    )
    plnom = db.Column(db.String(20), nullable=False, info="Nom de la place de cotation")


class Ratconformitetier(db.Model):
    __tablename__ = "ratconformitetiers"
    __table_args__ = {"schema": "exane"}

    rgcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    rgstatut = db.Column(db.ForeignKey("exane.typestatut.tstcode"))
    rgnote = db.Column(db.String(60))

    typestatut = db.relationship(
        "Typestatut",
        primaryjoin="Ratconformitetier.rgstatut == Typestatut.tstcode",
        backref="ratconformitetiers",
    )


class Secteur(db.Model):
    __tablename__ = "secteur"
    __table_args__ = {"schema": "exane"}

    secode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Code secteur"
    )
    setype = db.Column(
        db.ForeignKey("exane.typesecteurs.tsecode"),
        nullable=False,
        index=True,
        info="Code de la nomenclature des secteurs",
    )
    senom = db.Column(db.String(250), nullable=False, info="Nom du secteur")
    sename = db.Column(db.String(250), nullable=False, info="Nom du secteur en anglais")
    seordre = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="Ordre de presentation d'un secteur au sein d'une nomenclature",
    )
    selevel = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Niveau de composition du secteur"
    )
    senote = db.Column(
        db.ForeignKey("exane.typenote.tnnote"),
        index=True,
        info="Code de la note attribuée par une agence de rating",
    )
    seabrege = db.Column(db.String(20))

    typenote = db.relationship(
        "Typenote", primaryjoin="Secteur.senote == Typenote.tnnote", backref="secteurs"
    )
    typesecteur = db.relationship(
        "Typesecteur",
        primaryjoin="Secteur.setype == Typesecteur.tsecode",
        backref="secteurs",
    )


class Source(db.Model):
    __tablename__ = "source"
    __table_args__ = {"schema": "exane"}

    socode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de la source du flux",
    )
    sonom = db.Column(db.String(15), nullable=False, info="Nomde la source du flux")
    sotype = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        info="Récupération automatique ou pas",
    )
    sounicite = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        info="Cette source emet des codes uniques. donnée Informelle : Valeur  0 (no check) ou 1(check+alien) ou 2(check)",
    )
    soctrlunique = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Les codes de cette source doivent être unique : Controle via trigger sur CODIF / par défaut pas unicite ",
    )


class Tier(db.Model):
    __tablename__ = "tiers"
    __table_args__ = (
        db.CheckConstraint("TITYPE IN ('T','G','P')"),
        db.CheckConstraint("TITYPE IN ('T','G','P')"),
        {"schema": "exane"},
    )

    ticode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code d'une personne physique ou morale",
    )
    tipays = db.Column(
        db.ForeignKey("exane.pays.pacode"), nullable=False, index=True, info="Code pays"
    )
    tinom = db.Column(
        db.String(60), nullable=False, info="Nom d'une personne physique ou morale"
    )
    timemo = db.Column(db.String(4), nullable=False, info="Abréviation du nom du tiers")
    tisuivi = db.Column(
        db.String(1),
        info="Type de suivi sur une société assuré par un analyste financier",
    )
    titype = db.Column(db.String(1), nullable=False)
    tiappartenance = db.Column(db.ForeignKey("exane.grpuser.gucode"))
    tistatut = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Statut",
    )
    tivaliderdc = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Ce champ ne doit plus être utilisé (remplacé par REFDOC.KYCINFORMATION.KIVALIDERDC)",
    )
    tiratingconf = db.Column(db.ForeignKey("exane.ratconformitetiers.rgcode"))
    tipaysrisk = db.Column(db.ForeignKey("exane.pays.pacode"), info="Code pays risque")
    tiformejuridique = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Forme juridique du tiers"
    )

    grpuser = db.relationship(
        "Grpuser", primaryjoin="Tier.tiappartenance == Grpuser.gucode", backref="tiers"
    )
    pay = db.relationship(
        "Pay", primaryjoin="Tier.tipays == Pay.pacode", backref="pay_tiers"
    )
    pay1 = db.relationship(
        "Pay", primaryjoin="Tier.tipaysrisk == Pay.pacode", backref="pay_tiers_0"
    )
    ratconformitetier = db.relationship(
        "Ratconformitetier",
        primaryjoin="Tier.tiratingconf == Ratconformitetier.rgcode",
        backref="tiers",
    )


class Correstiersbloombergid(Tier):
    __tablename__ = "correstiersbloombergid"
    __table_args__ = {"schema": "derives"}

    ctbcodetiers = db.Column(db.ForeignKey("exane.tiers.ticode"), primary_key=True)
    ctbidbloom = db.Column(db.Numeric(asdecimal=False), nullable=False)


class Typeattributfamille(db.Model):
    __tablename__ = "typeattributfamille"
    __table_args__ = {"schema": "exane"}

    tafcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    taflibelle = db.Column(db.String(60), nullable=False)


class Typeclause(db.Model):
    __tablename__ = "typeclause"
    __table_args__ = {"schema": "exane"}

    tdcode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de la clause sur un dérivé",
    )
    tdnom = db.Column(
        db.String(20), nullable=False, info="Libellé de la clause sur un dérivé"
    )
    tdtype = db.Column(db.String(255), info="Type de calcul sur la clause dérivé")


class Typeclientele(db.Model):
    __tablename__ = "typeclientele"
    __table_args__ = {"schema": "exane"}

    tccode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Code du type"
    )
    tcnom = db.Column(db.String(80), nullable=False, info="Libelle Type")


class Typecontrat(db.Model):
    __tablename__ = "typecontrat"
    __table_args__ = {"schema": "exane"}

    tctcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tctnom = db.Column(db.String(60), nullable=False)


class Typeconversion(db.Model):
    __tablename__ = "typeconversion"
    __table_args__ = {"schema": "exane"}

    tcclcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code Interne du type de conversion",
    )
    tcclnom = db.Column(
        db.String(60), info="Mode de conversion:  Old Shares, New Shares, Choice..."
    )


class Typefamillefond(db.Model):
    __tablename__ = "typefamillefonds"
    __table_args__ = {"schema": "exane"}

    tfdcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tfdattribut = db.Column(db.ForeignKey("exane.typeattributfamille.tafcode"))
    tfdlibelle = db.Column(db.String(60))

    typeattributfamille = db.relationship(
        "Typeattributfamille",
        primaryjoin="Typefamillefond.tfdattribut == Typeattributfamille.tafcode",
        backref="typefamillefonds",
    )


class Typefonctionspot(db.Model):
    __tablename__ = "typefonctionspot"
    __table_args__ = {"schema": "exane"}

    tfcscode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tfcsnom = db.Column(db.String(60))


class Typefonctiontemp(db.Model):
    __tablename__ = "typefonctiontemps"
    __table_args__ = {"schema": "exane"}

    tfctcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tfctnom = db.Column(db.String(30), info="1=Constant 2=Lineaire 3=Expo")


class Typefond(db.Model):
    __tablename__ = "typefonds"
    __table_args__ = {"schema": "exane"}

    tfcode = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, info="code type fonds"
    )
    tfnom = db.Column(db.String(30), nullable=False, info="nom francais type fonds")
    tfname = db.Column(db.String(30), nullable=False, info="nom anglais type fonds")


class Typeinstrument(db.Model):
    __tablename__ = "typeinstrument"
    __table_args__ = {"schema": "exane"}

    tycode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du type d'instrument",
    )
    tyfamille = db.Column(
        db.ForeignKey("exane.famille.facode"),
        nullable=False,
        index=True,
        info="Code de la famille d'un type dinstruments",
    )
    tynom = db.Column(db.String(60), info="Libelle du type d'instrument")
    tyname = db.Column(db.String(60))

    famille = db.relationship(
        "Famille",
        primaryjoin="Typeinstrument.tyfamille == Famille.facode",
        backref="typeinstruments",
    )


class Typenote(db.Model):
    __tablename__ = "typenote"
    __table_args__ = {"schema": "exane"}

    tnnote = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de la note attribuée par une agence de rating",
    )
    tnagence = db.Column(
        db.ForeignKey("exane.agence.agcode"),
        nullable=False,
        index=True,
        info="Code agence de notation",
    )
    tnrating = db.Column(db.String(20), nullable=False, info="Code du rating")
    tnhorizon = db.Column(
        db.String(4), info="Spécifie si le rating attribué est CT ou LT"
    )
    tnsignif = db.Column(
        db.String(20),
        info="Signification de la note attribuée par une agence de rating",
    )
    tntype = db.Column(db.ForeignKey("exane.typescale.tstype"))
    tnratingordre = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        info="Ordonnancement du code du rating au sein d'une agence",
    )

    agence = db.relationship(
        "Agence", primaryjoin="Typenote.tnagence == Agence.agcode", backref="typenotes"
    )
    typescale = db.relationship(
        "Typescale",
        primaryjoin="Typenote.tntype == Typescale.tstype",
        backref="typenotes",
    )


class Typepayoff(db.Model):
    __tablename__ = "typepayoff"
    __table_args__ = {"schema": "exane"}

    tflcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tflnom = db.Column(db.String(60), nullable=False)


class Typeproprietaire(db.Model):
    __tablename__ = "typeproprietaire"
    __table_args__ = {"schema": "exane"}

    tpcode = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, info="Code du propriétaire"
    )
    tplibelle = db.Column(db.String(60), info="Libellé du propriétaire")


class Typeregimefond(db.Model):
    __tablename__ = "typeregimefonds"
    __table_args__ = {"schema": "exane"}

    trfcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    trflibelle = db.Column(db.String(60), nullable=False)


class Typescale(db.Model):
    __tablename__ = "typescale"
    __table_args__ = {"schema": "exane"}

    tstype = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="Type scale"
    )
    tsnom = db.Column(db.String(20), info="Scale")


class Typesecteur(db.Model):
    __tablename__ = "typesecteurs"
    __table_args__ = {"schema": "exane"}

    tsecode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de la nomenclature des secteurs",
    )
    tsenom = db.Column(
        db.String(15), nullable=False, info="Libellé de la nomenclature des secteurs"
    )


class Typestatjuridique(db.Model):
    __tablename__ = "typestatjuridique"
    __table_args__ = {"schema": "exane"}

    tsjcode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="code statut juridique",
    )
    tsjnom = db.Column(
        db.String(30), nullable=False, info="nom francais statut juridique"
    )
    tsjname = db.Column(
        db.String(30), nullable=False, info="nom anglais statut juridique"
    )


class Typestatut(db.Model):
    __tablename__ = "typestatut"
    __table_args__ = {"schema": "exane"}

    tstcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du statut d'un instrument financier",
    )
    tstnom = db.Column(
        db.String(15),
        nullable=False,
        info="Libellé du statut d'un instrument financier",
    )


class Typestrategie(db.Model):
    __tablename__ = "typestrategie"
    __table_args__ = {"schema": "exane"}

    tyscode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tyslibelle = db.Column(db.String(60))


class Typofoinstrument(db.Model):
    __tablename__ = "typofoinstrument"
    __table_args__ = (db.CheckConstraint("TICODE>=1000"), {"schema": "exane"})

    ticode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de la nouvelle typologie FO",
    )
    tilibelle = db.Column(
        db.String(200), nullable=False, info="Libellé de la nouvelle typologie FO"
    )


class Typofoinstrumentsautorisee(db.Model):
    __tablename__ = "typofoinstrumentsautorisees"
    __table_args__ = (
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACONTRATINDEFINI Is Not Null AND TACONTRATINDEFINI IN ('O','N')"
        ),
        db.CheckConstraint(
            "TACONTRATLISTE Is Not Null AND TACONTRATLISTE IN ('O','N')"
        ),
        db.CheckConstraint("TACONTRATOTC Is Not Null AND TACONTRATOTC IN ('O','N')"),
        db.CheckConstraint(
            "TACONTRATTITRE Is Not Null AND TACONTRATTITRE IN ('O','N')"
        ),
        db.Index(
            "uk_typofoinstrumentsautorisees",
            "tacodetypoinstrument",
            "tacodetypoinstsjac",
        ),
        {"schema": "exane"},
    )

    tacode = db.Column(
        db.Numeric(9, 0, asdecimal=False),
        primary_key=True,
        info="Code d'association de la typologie instrument et de la typologie sous jacent",
    )
    tacodetypoinstrument = db.Column(
        db.ForeignKey("exane.typofoinstrument.ticode"),
        nullable=False,
        info="Code de la typologie instrument cf. EXANE.TYPOFOINSTRUMENT",
    )
    tacodetypoinstsjac = db.Column(
        db.ForeignKey("exane.typofoinstrumentsjac.tscode"),
        info="Code de la typologie sous jacent cf. EXANE.TYPOFOINSTRUMENTSJAC",
    )
    tacontrattitre = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Titre",
    )
    tacontratliste = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Liste",
    )
    tacontratotc = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat OTC",
    )
    tacontratindefini = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Indéfini",
    )

    typofoinstrument = db.relationship(
        "Typofoinstrument",
        primaryjoin="Typofoinstrumentsautorisee.tacodetypoinstrument == Typofoinstrument.ticode",
        backref="typofoinstrumentsautorisees",
    )
    typofoinstrumentsjac = db.relationship(
        "Typofoinstrumentsjac",
        primaryjoin="Typofoinstrumentsautorisee.tacodetypoinstsjac == Typofoinstrumentsjac.tscode",
        backref="typofoinstrumentsautorisees",
    )


class Typofoinstrumentsjac(db.Model):
    __tablename__ = "typofoinstrumentsjac"
    __table_args__ = {"schema": "exane"}

    tscode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de la nouvelle typologie sous jacent",
    )
    tslibellesjac = db.Column(
        db.String(200), nullable=False, info="Libellé du type de sous jacent du produit"
    )


class Zonegeographique(db.Model):
    __tablename__ = "zonegeographique"
    __table_args__ = {"schema": "exane"}

    zgcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code numérique zone géographique",
    )
    zglibelle = db.Column(
        db.String(60), nullable=False, info="Libelle de la zone géographique"
    )


class Appfunction(db.Model):
    __tablename__ = "appfunction"
    __table_args__ = {"schema": "exane_batch"}

    afcode = db.Column(
        db.Numeric(7, 0, asdecimal=False),
        primary_key=True,
        info="Identifiant de la fonctionalité",
    )
    aflibelle = db.Column(
        db.String(30), nullable=False, info="Libellé de la fonctionalité"
    )


class Appmode(db.Model):
    __tablename__ = "appmode"
    __table_args__ = {"schema": "exane_batch"}

    amidapp = db.Column(
        db.Numeric(7, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Identifiant de l'application",
    )
    ammode = db.Column(
        db.Numeric(7, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="mode applicatif",
    )
    amlibelle = db.Column(
        db.String(30), nullable=False, info="Libellé du mode applicatif"
    )


class Appsession(db.Model):
    __tablename__ = "appsession"
    __table_args__ = (
        db.ForeignKeyConstraint(
            ["asidapp", "asmode"],
            ["exane_batch.appmode.amidapp", "exane_batch.appmode.ammode"],
        ),
        db.Index("fk_appsession_appmode", "asidapp", "asmode"),
        {"schema": "exane_batch"},
    )

    asidsession = db.Column(
        db.Numeric(9, 0, asdecimal=False),
        primary_key=True,
        info="Identifiant unique de session",
    )
    asidapp = db.Column(
        db.Numeric(7, 0, asdecimal=False),
        nullable=False,
        info="Identifiant de l'application",
    )
    asversion = db.Column(
        db.String(64), nullable=False, info="Version de l'application"
    )
    asmode = db.Column(
        db.Numeric(7, 0, asdecimal=False), info="Mode optionel de l'application"
    )
    ashostname = db.Column(db.String(256), nullable=False, info="Machine d'exécution")
    ashorodatedebut = db.Column(db.DateTime, nullable=False, info="Heure de début")
    ashorodatefin = db.Column(db.DateTime, info="Heure de fin")
    aserreur = db.Column(
        db.Numeric(7, 0, asdecimal=False), info="Code erreur de l'application"
    )
    ascastorver = db.Column(db.String(64), info="Version Castor")
    ascastorparam = db.Column(db.String(256), info="Paramètres Castor")
    asappparam = db.Column(db.String(4000), info="Paramètres de l'application")
    asfunction = db.Column(
        db.ForeignKey("exane_batch.appfunction.afcode"),
        index=True,
        info="Fonction optionnelle de l'application",
    )
    asidclient = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Id session du client demandeur"
    )
    asidsvcpt = db.Column(
        db.ForeignKey("exane_batch.servicepoint.spid"),
        info="Id du point d'entrée demandeur",
    )
    asforcedcalculationcomment = db.Column(
        db.String(512), info="Commentaire en cas de calcul forcé"
    )

    appfunction = db.relationship(
        "Appfunction",
        primaryjoin="Appsession.asfunction == Appfunction.afcode",
        backref="appsessions",
    )
    appmode = db.relationship(
        "Appmode",
        primaryjoin="and_(Appsession.asidapp == Appmode.amidapp, Appsession.asmode == Appmode.ammode)",
        backref="appsessions",
    )
    servicepoint = db.relationship(
        "Servicepoint",
        primaryjoin="Appsession.asidsvcpt == Servicepoint.spid",
        backref="appsessions",
    )


class Service(db.Model):
    __tablename__ = "service"
    __table_args__ = {"schema": "exane_batch"}

    seid = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        unique=True,
        info="Id du service",
    )
    sehostname = db.Column(db.String(256), nullable=False, info="Hostname du service")
    seport = db.Column(
        db.Numeric(7, 0, asdecimal=False), nullable=False, info="Port du service"
    )
    setype = db.Column(
        db.ForeignKey("exane_batch.typeservice.tsid"),
        nullable=False,
        info="Type du service",
    )

    typeservice = db.relationship(
        "Typeservice",
        primaryjoin="Service.setype == Typeservice.tsid",
        backref="services",
    )


class Servicepoint(db.Model):
    __tablename__ = "servicepoint"
    __table_args__ = {"schema": "exane_batch"}

    spid = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        unique=True,
        info="Id du point d'entrée",
    )
    spname = db.Column(db.String(256), nullable=False, info="Nom du point d'entrée")
    spidservice = db.Column(
        db.ForeignKey("exane_batch.service.seid"), nullable=False, info="Id du service"
    )

    service = db.relationship(
        "Service",
        primaryjoin="Servicepoint.spidservice == Service.seid",
        backref="servicepoints",
    )


class Typeservice(db.Model):
    __tablename__ = "typeservice"
    __table_args__ = {"schema": "exane_batch"}

    tsid = db.Column(
        db.Numeric(7, 0, asdecimal=False),
        primary_key=True,
        unique=True,
        info="Id du type de service",
    )
    tslibelle = db.Column(
        db.String(64), nullable=False, info="Libelle du type de service"
    )

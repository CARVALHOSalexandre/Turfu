# coding: utf-8
from local_db_mgt import db


class Bbpageitem(db.Model):
    __tablename__ = "bbpageitem"
    __table_args__ = {"schema": "crs"}

    bimenuid = db.Column(db.Numeric(asdecimal=False), primary_key=True, nullable=False)
    bipagecode = db.Column(db.Numeric(asdecimal=False))
    bipagenumber = db.Column(
        db.Numeric(asdecimal=False), primary_key=True, nullable=False
    )
    bimonitornumber = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="MPF Monitor Number"
    )


class Bbpagemenu(db.Model):
    __tablename__ = "bbpagemenu"
    __table_args__ = {"schema": "crs"}

    bmmenuid = db.Column(db.Numeric(asdecimal=False))
    bmlibelle = db.Column(db.String(64))
    bmfirstpage = db.Column(db.Numeric(asdecimal=False))
    bmlastpage = db.Column(db.Numeric(asdecimal=False))
    bmuser = db.Column(db.Numeric(asdecimal=False))
    bmpagetoric = db.Column(db.Numeric(asdecimal=False))
    bmricmenuid = db.Column(db.Numeric(5, 0, asdecimal=False))
    bmlinkmenu = db.Column(db.String(4))
    bmlinkmenunumber = db.Column(db.Numeric(asdecimal=False))


class Bbricmenu(db.Model):
    __tablename__ = "bbricmenu"
    __table_args__ = {"schema": "crs"}

    brmenuid = db.Column(db.Numeric(asdecimal=False))
    brfunctionname = db.Column(db.String(4))
    brmonitorid = db.Column(db.String(4))
    brorder = db.Column(db.Numeric(asdecimal=False))
    brcolor = db.Column(db.Numeric(asdecimal=False))
    brcomment = db.Column(db.String(512))
    brtempo = db.Column(db.Numeric(asdecimal=False))
    brpagetoric = db.Column(db.Numeric(asdecimal=False))
    brmonitornumber = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="MPF Monitor Number"
    )
    brlinkmenu = db.Column(db.String(4), info="Menu Commercial Ric")
    brlinkmenunumber = db.Column(
        db.Numeric(asdecimal=False), info="Id Menu commercial externe"
    )


class CfinNoRecup(db.Model):
    __tablename__ = "cfin_no_recup"
    __table_args__ = {"schema": "crs"}

    cfin = db.Column(
        db.Numeric(asdecimal=False), nullable=False, info="Code instrument financier"
    )


class CollectionNoRecup(db.Model):
    __tablename__ = "collection_no_recup"
    __table_args__ = {"schema": "crs"}

    cfin = db.Column(
        db.Numeric(asdecimal=False), nullable=False, info="Code instrument financier"
    )


class Crbloomindex(db.Model):
    __tablename__ = "crbloomindexes"
    __table_args__ = {"schema": "crs"}

    blcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        nullable=False,
        index=True,
        info="Cfin de l'indice",
    )
    bllastctrdate = db.Column(db.DateTime, info="Date de derniÃ¨ contribution")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Crbloomindex.blcfin == Instrument.ifcfin",
        backref="crbloomindexes",
    )


class Crcfinadmin(db.Model):
    __tablename__ = "crcfinadmin"
    __table_args__ = {"schema": "crs"}

    adcfin = db.Column(
        db.Numeric(asdecimal=False), primary_key=True, info="Code instrument"
    )
    adtempo = db.Column(db.Numeric(asdecimal=False), info="Temporisation ")
    adgomme = db.Column(db.Numeric(asdecimal=False), info="Gomme sur BID ASK SPOT")
    adindic = db.Column(db.Numeric(2, 0, asdecimal=False), info="Calcul Indicateurs")
    adendbidgomme = db.Column(
        db.Numeric(asdecimal=False), info="Date de validitÃ©e la gomme BID"
    )
    adendaskgomme = db.Column(
        db.Numeric(asdecimal=False), info="Date de validitÃ©e la gomme ASK"
    )
    adendspotgomme = db.Column(
        db.Numeric(asdecimal=False), info="Date de validitÃ©e la gomme SPOT"
    )


class Crcfinpxparam(db.Model):
    __tablename__ = "crcfinpxparam"
    __table_args__ = {"schema": "crs"}

    cfpxpcfin = db.Column(db.Numeric(asdecimal=False))
    cfpxpsjac = db.Column(db.Numeric(asdecimal=False))
    cfpxpcfinfut = db.Column(db.Numeric(asdecimal=False))
    cfpxpaparam = db.Column(db.Numeric(asdecimal=False))
    cfpxpbparam = db.Column(db.Numeric(asdecimal=False))
    cfpxpcparam = db.Column(db.Numeric(asdecimal=False))
    cfpxpcode = db.Column(db.String(64))


class Crcfintempo(db.Model):
    __tablename__ = "crcfintempo"
    __table_args__ = {"schema": "crs"}

    ctcfin = db.Column(db.Numeric(asdecimal=False))
    cttempo = db.Column(db.Numeric(asdecimal=False))


class Crdico(db.Model):
    __tablename__ = "crdico"
    __table_args__ = {"schema": "crs"}

    dccode = db.Column(db.Numeric(6, 0, asdecimal=False), nullable=False)
    dclongueur = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    dcjustif = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    dcprecision = db.Column(db.Numeric(2, 0, asdecimal=False))
    dcref = db.Column(db.String(50), nullable=False)
    dctype = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    dccomment = db.Column(db.String(255))
    dcvaleur = db.Column(db.String(255))
    dccodefct = db.Column(db.Numeric(6, 0, asdecimal=False))
    dccodefct2 = db.Column(db.Numeric(6, 0, asdecimal=False))
    dctyper = db.Column(db.Numeric(1, 0, asdecimal=False))
    dcoptzero = db.Column(db.Numeric(1, 0, asdecimal=False))
    dcoptfixe = db.Column(db.Numeric(1, 0, asdecimal=False))
    dcopttrunc = db.Column(db.Numeric(1, 0, asdecimal=False))
    dcoptneg = db.Column(db.Numeric(1, 0, asdecimal=False))


class CrgrpIndic(db.Model):
    __tablename__ = "crgrp_indic"
    __table_args__ = {"schema": "crs"}

    gicode = db.Column(
        db.Numeric(asdecimal=False), primary_key=True, info="Code groupe"
    )
    giname = db.Column(
        db.String(64), nullable=False, info="Nom du groupe d'indicateurs"
    )


class Crgrptache(db.Model):
    __tablename__ = "crgrptache"
    __table_args__ = {"schema": "crs"}

    gtcode = db.Column(db.Numeric(6, 0, asdecimal=False), primary_key=True)
    gtnom = db.Column(db.String(50), nullable=False)
    gttype = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    gtstatus = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    gtdebut = db.Column(db.String(5), nullable=False)
    gtfin = db.Column(db.String(5))
    gtmodehs = db.Column(db.Numeric(2, 0, asdecimal=False))
    gttempo = db.Column(db.Numeric(2, 0, asdecimal=False))
    gtgucode = db.Column(db.Numeric(6, 0, asdecimal=False))


class Crgrpuser(db.Model):
    __tablename__ = "crgrpuser"
    __table_args__ = {"schema": "crs"}

    gucode = db.Column(db.Numeric(6, 0, asdecimal=False), primary_key=True)
    gunom = db.Column(db.String(50), nullable=False)

    cruser = db.relationship(
        "Cruser", secondary="crs.crusergrpuser", backref="crgrpusers"
    )


class CrindicReference(db.Model):
    __tablename__ = "crindic_reference"
    __table_args__ = {"schema": "crs"}

    irivcode = db.Column(
        db.Numeric(asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code indicateur",
    )
    irivtype = db.Column(
        db.Numeric(asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Type indicateur : ALpha / Num",
    )
    irname = db.Column(db.String(64), nullable=False, info="Nom indicateur")
    irvalue = db.Column(db.String(128), nullable=False, info="Code serveur calcul")
    irmnemo = db.Column(db.String(5))


class CrindicValue(db.Model):
    __tablename__ = "crindic_values"
    __table_args__ = {"schema": "crs"}

    ivgicode = db.Column(
        db.Numeric(asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code groupe",
    )
    ivtype = db.Column(
        db.Numeric(asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Type indicateur : Casper / Pythagor",
    )
    ivcode = db.Column(
        db.Numeric(asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code indicateur",
    )


class Crmarge(db.Model):
    __tablename__ = "crmarge"
    __table_args__ = (
        db.CheckConstraint(" mgcfin > 0"),
        db.Index("pk_marge_cfin_modemg", "mgcfin", "mgmodemg"),
        {"schema": "crs"},
    )

    mgcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    mgmodemg = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    mgemet = db.Column(db.Numeric(12, 5))
    mgbid = db.Column(db.Numeric(12, 5))
    mgask = db.Column(db.Numeric(12, 5))
    mgmodepas = db.Column(db.Numeric(1, 0, asdecimal=False))
    mgpas = db.Column(db.Numeric(12, 5))
    mgperiod = db.Column(db.Numeric(3, 0, asdecimal=False))
    mgdatedeb = db.Column(db.DateTime)
    mgbidcontrib = db.Column(db.Numeric(12, 5))
    mgaskcontrib = db.Column(db.Numeric(12, 5))
    mgspotcontrib = db.Column(db.Numeric(12, 5))
    mgtaux = db.Column(db.Numeric(12, 5))
    mgnbjour = db.Column(db.Numeric(6, 0, asdecimal=False))
    mgflag = db.Column(db.Numeric(1, 0, asdecimal=False))


class CrmargeDerive(db.Model):
    __tablename__ = "crmarge_derive"
    __table_args__ = {"schema": "crs"}

    mgdcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    mgduser = db.Column(db.Numeric(6, 0, asdecimal=False), nullable=False)
    mgdsort = db.Column(db.Numeric(6, 0, asdecimal=False))
    mgdsoldout = db.Column(db.Numeric(6, 0, asdecimal=False))
    mgdpxmode = db.Column(db.Numeric(asdecimal=False))
    mgdspotmode = db.Column(db.Numeric(asdecimal=False))
    mggrpindic = db.Column(db.Numeric(asdecimal=False))


class CrmargeH(db.Model):
    __tablename__ = "crmarge_h"
    __table_args__ = {"schema": "crs"}

    mgcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    mgmodemg = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    mgemet = db.Column(db.Numeric(12, 5))
    mgbid = db.Column(db.Numeric(12, 5))
    mgask = db.Column(db.Numeric(12, 5))
    mgmodepas = db.Column(db.Numeric(1, 0, asdecimal=False))
    mgpas = db.Column(db.Numeric(12, 5))
    mgperiod = db.Column(db.Numeric(3, 0, asdecimal=False))
    mgdatedeb = db.Column(db.DateTime)
    mgbidcontrib = db.Column(db.Numeric(12, 5))
    mgaskcontrib = db.Column(db.Numeric(12, 5))
    mgspotcontrib = db.Column(db.Numeric(12, 5))
    mgtaux = db.Column(db.Numeric(12, 5))
    mgnbjour = db.Column(db.Numeric(6, 0, asdecimal=False))
    mgdttime = db.Column(db.DateTime)
    mgtypema = db.Column(db.Numeric(1, 0, asdecimal=False))
    mgflag = db.Column(db.Numeric(1, 0, asdecimal=False))


class Crmodeleligne(db.Model):
    __tablename__ = "crmodeleligne"
    __table_args__ = {"schema": "crs"}

    mlcode = db.Column(db.Numeric(6, 0, asdecimal=False), primary_key=True)
    mlnom = db.Column(db.String(50), nullable=False)


class Crmodelelignedico(db.Model):
    __tablename__ = "crmodelelignedico"
    __table_args__ = {"schema": "crs"}

    ldmlcode = db.Column(
        db.ForeignKey("crs.crmodeleligne.mlcode"),
        primary_key=True,
        nullable=False,
        index=True,
    )
    lddccode = db.Column(
        db.Numeric(6, 0, asdecimal=False), primary_key=True, nullable=False, index=True
    )
    ldoffset = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)

    crmodeleligne = db.relationship(
        "Crmodeleligne",
        primaryjoin="Crmodelelignedico.ldmlcode == Crmodeleligne.mlcode",
        backref="crmodelelignedicoes",
    )


class Crmodelepage(db.Model):
    __tablename__ = "crmodelepage"
    __table_args__ = {"schema": "crs"}

    mpcode = db.Column(db.Numeric(6, 0, asdecimal=False), primary_key=True)
    mpnom = db.Column(db.String(50), nullable=False)


class Crmodelepageligne(db.Model):
    __tablename__ = "crmodelepageligne"
    __table_args__ = {"schema": "crs"}

    plmpcode = db.Column(
        db.ForeignKey("crs.crmodelepage.mpcode"),
        primary_key=True,
        nullable=False,
        index=True,
    )
    plmlcode = db.Column(
        db.ForeignKey("crs.crmodeleligne.mlcode"), nullable=False, index=True
    )
    plnoligne = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )

    crmodeleligne = db.relationship(
        "Crmodeleligne",
        primaryjoin="Crmodelepageligne.plmlcode == Crmodeleligne.mlcode",
        backref="crmodelepagelignes",
    )
    crmodelepage = db.relationship(
        "Crmodelepage",
        primaryjoin="Crmodelepageligne.plmpcode == Crmodelepage.mpcode",
        backref="crmodelepagelignes",
    )


class Crnomcontrib(db.Model):
    __tablename__ = "crnomcontrib"
    __table_args__ = {"schema": "crs"}

    crlibelle = db.Column(db.String(64), nullable=False)
    crcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, nullable=False
    )
    crgroup = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Crnomcontrib.crcfin == Instrument.ifcfin",
        backref="crnomcontribs",
    )


class Crpage(db.Model):
    __tablename__ = "crpage"
    __table_args__ = {"schema": "crs"}

    pgcode = db.Column(db.Numeric(6, 0, asdecimal=False), primary_key=True)
    pgmpcode = db.Column(
        db.ForeignKey("crs.crmodelepage.mpcode"), nullable=False, index=True
    )
    pgnom = db.Column(db.String(50), nullable=False)
    pgtype = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    pgstatus = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    pguscode = db.Column(db.Numeric(6, 0, asdecimal=False))

    crmodelepage = db.relationship(
        "Crmodelepage",
        primaryjoin="Crpage.pgmpcode == Crmodelepage.mpcode",
        backref="crpages",
    )


class Crprdpginactif(db.Model):
    __tablename__ = "crprdpginactif"
    __table_args__ = {"schema": "crs"}

    ppptcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    pppgcode = db.Column(db.Numeric(6, 0, asdecimal=False), nullable=False)
    ppoffligne = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    ppdccode = db.Column(db.Numeric(6, 0, asdecimal=False), nullable=False)
    ppmlcode = db.Column(db.Numeric(6, 0, asdecimal=False), nullable=False)


class Crproduitpage(db.Model):
    __tablename__ = "crproduitpage"
    __table_args__ = (
        db.Index("icrproduitpage", "pppgcode", "ppmlcode", "ppdccode", "ppoffligne"),
        {"schema": "crs"},
    )

    ppptcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    pppgcode = db.Column(
        db.ForeignKey("crs.crpage.pgcode"), primary_key=True, nullable=False, index=True
    )
    ppoffligne = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ppdccode = db.Column(
        db.Numeric(6, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ppmlcode = db.Column(
        db.Numeric(6, 0, asdecimal=False), primary_key=True, nullable=False
    )
    pppgcodein = db.Column(db.Numeric(6, 0, asdecimal=False))
    ppofflignein = db.Column(db.Numeric(2, 0, asdecimal=False))
    ppdccodein = db.Column(db.Numeric(6, 0, asdecimal=False))
    ppmlcodein = db.Column(db.Numeric(6, 0, asdecimal=False))

    crpage = db.relationship(
        "Crpage",
        primaryjoin="Crproduitpage.pppgcode == Crpage.pgcode",
        backref="crproduitpages",
    )


class Crreference(db.Model):
    __tablename__ = "crreferences"
    __table_args__ = {"schema": "crs"}

    fwcode = db.Column(db.Numeric(6, 0, asdecimal=False), primary_key=True)
    fwtype = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    fwref = db.Column(db.String(50))
    fwvaleur = db.Column(db.Numeric(5, 0, asdecimal=False))
    fwbeauty = db.Column(db.Numeric(2, 0, asdecimal=False))


class Crtache(db.Model):
    __tablename__ = "crtache"
    __table_args__ = {"schema": "crs"}

    tacode = db.Column(db.Numeric(6, 0, asdecimal=False), nullable=False)
    taref = db.Column(db.String(50))
    tagtcode = db.Column(db.Numeric(6, 0, asdecimal=False), nullable=False)
    tastatus = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    taclosingsj = db.Column(db.Numeric(1, 0, asdecimal=False))
    taclosingprd = db.Column(db.Numeric(1, 0, asdecimal=False))
    tatype = db.Column(db.Numeric(2, 0, asdecimal=False))
    tafreq = db.Column(db.Numeric(2, 0, asdecimal=False))
    tatolspotemet = db.Column(db.Numeric(12, 5))
    taexpspotemet = db.Column(db.Numeric(1, 0, asdecimal=False))
    tatolspotexa = db.Column(db.Numeric(12, 5))
    taexpspotexa = db.Column(db.Numeric(1, 0, asdecimal=False))
    tatolmidexa = db.Column(db.Numeric(12, 5))
    taexpmidexa = db.Column(db.Numeric(1, 0, asdecimal=False))
    tatolspreadexa = db.Column(db.Numeric(12, 5))
    taexpspreadexa = db.Column(db.Numeric(1, 0, asdecimal=False))
    tatolvolimpexa = db.Column(db.Numeric(12, 5))
    taexpvolimpexa = db.Column(db.Numeric(1, 0, asdecimal=False))
    taptcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    tapgcode = db.Column(db.Numeric(8, 0, asdecimal=False))
    tamoderskrpd = db.Column(db.Numeric(1, 0, asdecimal=False))
    taderniernom = db.Column(db.String(50))
    tacheckpv = db.Column(db.Numeric(1, 0, asdecimal=False))
    tadernierevi = db.Column(db.Numeric(12, 5))
    tamgbid = db.Column(db.Numeric(12, 5))
    taexpmgbid = db.Column(db.Numeric(1, 0, asdecimal=False))
    tamgask = db.Column(db.Numeric(12, 5))
    taexpmgask = db.Column(db.Numeric(1, 0, asdecimal=False))
    tatimekeepprice = db.Column(db.Numeric(6, 0, asdecimal=False))
    tachkin = db.Column(db.Numeric(1, 0, asdecimal=False))
    tachkout = db.Column(db.Numeric(1, 0, asdecimal=False))
    tachklib = db.Column(db.Numeric(1, 0, asdecimal=False))
    tachktimekeepprice = db.Column(db.Numeric(1, 0, asdecimal=False))
    tachkmgask = db.Column(db.Numeric(1, 0, asdecimal=False))
    tachkmgbid = db.Column(db.Numeric(1, 0, asdecimal=False))
    tachkspotemet = db.Column(db.Numeric(1, 0, asdecimal=False))
    tachkspreadexa = db.Column(db.Numeric(1, 0, asdecimal=False))
    tachkspotexa = db.Column(db.Numeric(1, 0, asdecimal=False))
    tachkmidexa = db.Column(db.Numeric(1, 0, asdecimal=False))
    tastart = db.Column(db.String(5))
    tastop = db.Column(db.String(5))


class Cruser(db.Model):
    __tablename__ = "cruser"
    __table_args__ = {"schema": "crs"}

    uscode = db.Column(db.Numeric(6, 0, asdecimal=False), primary_key=True)
    usnom = db.Column(db.String(50))
    usprenom = db.Column(db.String(50))
    uspassword = db.Column(db.String(50))
    usmail = db.Column(db.String(50))
    usgrp = db.Column(db.Numeric(1, 0, asdecimal=False))


t_crusergrpuser = db.Table(
    "crusergrpuser",
    db.Column(
        "uggucode",
        db.ForeignKey("crs.crgrpuser.gucode"),
        primary_key=True,
        nullable=False,
        index=True,
    ),
    db.Column(
        "uguscode",
        db.ForeignKey("crs.cruser.uscode"),
        primary_key=True,
        nullable=False,
        index=True,
    ),
    schema="crs",
)


class HwarCrEx(db.Model):
    __tablename__ = "hwar_cr_ex"
    __table_args__ = {"schema": "crs"}

    hccfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Cfin du produit dérivé",
    )
    hcdevin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Cfin de la devise d'entrée",
    )
    hcdevout = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Cfin de la devise de sortie",
    )
    hcdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date d'enregistrement"
    )
    hccross = db.Column(db.Numeric(13, 5), info="Valeur du taux de change")
    hchorodate = db.Column(db.DateTime)


class HwarDrEx(db.Model):
    __tablename__ = "hwar_dr_ex"
    __table_args__ = (
        db.Index("idx_hwar_dr_ex_hxcfin_hxdate", "hxcfin", "hxdate"),
        {"schema": "crs"},
    )

    hxdate = db.Column(db.DateTime, info="Date insertion")
    hxcfin = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code instrument")
    hxprofil = db.Column(db.Numeric(asdecimal=False), info="Profil de pricing")
    hxevent = db.Column(db.String(1), info="Evenement : Update / Closing")
    hxuser = db.Column(db.String(64), info="Utilisateur")
    hxhost = db.Column(db.String(64), info="Host")
    hxtheo = db.Column(db.Numeric(asdecimal=False), info="Prix theorique")
    hxbid = db.Column(db.Numeric(asdecimal=False), info="Bid")
    hxask = db.Column(db.Numeric(asdecimal=False), info="Ask")
    hxmargebid_v = db.Column(db.Numeric(asdecimal=False), info="Marge vente BID")
    hxmargeask_v = db.Column(db.Numeric(asdecimal=False), info="Marge vente ASK")
    hxmargebid_cp = db.Column(db.Numeric(asdecimal=False), info="Marge trading BID")
    hxmargeask_cp = db.Column(db.Numeric(asdecimal=False), info="Marge trading ASK")
    hxmode = db.Column(
        db.String(1), info="Sales / Trading ( non renseigné pour les cours de cloture )"
    )
    hxhorodate = db.Column(db.DateTime)


class HwarMargeInit(db.Model):
    __tablename__ = "hwar_marge_init"
    __table_args__ = (db.CheckConstraint("HMTYPE IN ('A','B')"), {"schema": "crs"})

    hmdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date insertion"
    )
    hmcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code instrument",
    )
    hmtype = db.Column(
        db.String(1),
        primary_key=True,
        nullable=False,
        info="Type de la marge Bid / Ask",
    )
    hmmarge = db.Column(db.Numeric(asdecimal=False), info="Valeur de la marge initiale")
    hmloginad = db.Column(
        db.String(64), info="Login ad de la personne qui a fait la modification"
    )


class HwarSjEx(db.Model):
    __tablename__ = "hwar_sj_ex"
    __table_args__ = {"schema": "crs"}

    hscfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Clef Cfin du produit dérivé.",
    )
    hssjac = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Clef Cfin du S/J",
    )
    hsdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hsspot = db.Column(db.Numeric(13, 5))
    hshorodate = db.Column(db.DateTime)


class IntradayDer(db.Model):
    __tablename__ = "intraday_der"
    __table_args__ = (
        db.Index("idx_intraday_der_cfin_stamp", "iddcfin", "iddstamp"),
        {"schema": "crs"},
    )

    iddstamp = db.Column(db.DateTime, info="Time stamp du flux sur cfin")
    iddcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code instrument financier"
    )
    iddbid = db.Column(db.Numeric(13, 5), info="Bid du cfin en l'instant du timestamp")
    iddask = db.Column(db.Numeric(13, 5), info="Ask du cfin en l'instant du timestamp")
    iddpxtheo = db.Column(
        db.Numeric(13, 5), info="Prix theorique du cfin en l'instant du timestamp"
    )
    iddminbid = db.Column(
        db.Numeric(13, 5), info="Min du bid lors de la derniere periode"
    )
    iddmaxbid = db.Column(
        db.Numeric(13, 5), info="Max du bid lors de la derniere periode"
    )
    iddminask = db.Column(
        db.Numeric(13, 5), info="Min du ask lors de la derniere periode"
    )
    iddmaxask = db.Column(
        db.Numeric(13, 5), info="Max du ask lors de la derniere periode"
    )
    iddminpxtheo = db.Column(
        db.Numeric(13, 5), info="Min du prix theorique lors de la derniere periode"
    )
    iddmaxpxtheo = db.Column(
        db.Numeric(13, 5), info="Max du prix theorique lors de la derniere periode"
    )


class LastTemp(db.Model):
    __tablename__ = "last_temp"
    __table_args__ = {"schema": "crs"}

    lacfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    ladate = db.Column(db.DateTime, nullable=False)
    lapriclos = db.Column(db.Numeric(13, 5))
    lapriopen = db.Column(db.Numeric(13, 5))
    laprimoypond = db.Column(db.Numeric(13, 5))
    lapo = db.Column(db.Numeric(16, 5))
    lavolqute = db.Column(db.Numeric(18, 2))
    lavolcapi = db.Column(db.Numeric(18, 2))
    ladatepr = db.Column(db.DateTime)
    lapriclospr = db.Column(db.Numeric(13, 5))
    lapriopenpr = db.Column(db.Numeric(13, 5))
    laprimoypondpr = db.Column(db.Numeric(13, 5))
    lapopr = db.Column(db.Numeric(16, 2))
    lavolqutepr = db.Column(db.Numeric(18, 2))
    lavolcapipr = db.Column(db.Numeric(18, 2))
    lahigh = db.Column(db.Numeric(13, 5))
    lahighpr = db.Column(db.Numeric(13, 5))
    lalow = db.Column(db.Numeric(13, 5))
    lalowpr = db.Column(db.Numeric(13, 5))


class LastTempBak(db.Model):
    __tablename__ = "last_temp_bak"
    __table_args__ = {"schema": "crs"}

    lacfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    ladate = db.Column(db.DateTime, nullable=False)
    lapriclos = db.Column(db.Numeric(13, 5))
    lapriopen = db.Column(db.Numeric(13, 5))
    laprimoypond = db.Column(db.Numeric(13, 5))
    lapo = db.Column(db.Numeric(16, 5))
    lavolqute = db.Column(db.Numeric(18, 2))
    lavolcapi = db.Column(db.Numeric(18, 2))
    ladatepr = db.Column(db.DateTime)
    lapriclospr = db.Column(db.Numeric(13, 5))
    lapriopenpr = db.Column(db.Numeric(13, 5))
    laprimoypondpr = db.Column(db.Numeric(13, 5))
    lapopr = db.Column(db.Numeric(16, 2))
    lavolqutepr = db.Column(db.Numeric(18, 2))
    lavolcapipr = db.Column(db.Numeric(18, 2))
    lahigh = db.Column(db.Numeric(13, 5))
    lahighpr = db.Column(db.Numeric(13, 5))
    lalow = db.Column(db.Numeric(13, 5))
    lalowpr = db.Column(db.Numeric(13, 5))


class Recuptemp(db.Model):
    __tablename__ = "recuptemp"
    __table_args__ = {"schema": "crs"}

    cfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    mid = db.Column(db.Numeric(13, 5))


class Rtbloomdiff(db.Model):
    __tablename__ = "rtbloomdiff"
    __table_args__ = {"schema": "crs"}

    pgnom = db.Column(db.String(50))
    cfin = db.Column(db.Numeric(asdecimal=False))
    line = db.Column(db.Numeric(asdecimal=False))


class RtcfinExtDef(db.Model):
    __tablename__ = "rtcfin_ext_def"
    __table_args__ = {"schema": "crs"}

    cdcfin = db.Column(
        db.Numeric(asdecimal=False), primary_key=True, info="Code instrument financier"
    )
    cdpublish = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        info="Flag de publication interne",
    )
    cdindicgrp = db.Column(
        db.Numeric(asdecimal=False), nullable=False, info="Groupe indicateurs"
    )


class RtcfinExtParam(db.Model):
    __tablename__ = "rtcfin_ext_param"
    __table_args__ = {"schema": "crs"}

    cpcfin = db.Column(
        db.Numeric(asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code instrument financier",
    )
    cpresource = db.Column(
        db.Numeric(asdecimal=False),
        nullable=False,
        info="Ressource Reuters (Ric ou Page)",
    )
    cpfieldtype = db.Column(
        db.Numeric(asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Type de champ ( Bid/Ask/Spot)",
    )
    cpname = db.Column(db.String(64), nullable=False, info="Nom de la ressource")
    cpfield = db.Column(db.String(64), info="Nom du champ ( si Ric )")
    cplinepos = db.Column(
        db.Numeric(asdecimal=False), info="Position de ligne (si Page)"
    )
    cpcolpos = db.Column(
        db.Numeric(asdecimal=False), info="Position de colonne (si Page)"
    )
    cplen = db.Column(db.Numeric(asdecimal=False), info="Longueur (si Page)")


class Rtchain(db.Model):
    __tablename__ = "rtchain"
    __table_args__ = {"schema": "crs"}

    seq = db.Column(db.Numeric(asdecimal=False), nullable=False)
    reuterscode = db.Column(db.String(16), nullable=False)
    title = db.Column(db.String(16))
    reuterspage = db.Column(db.String(21))
    cornerlib = db.Column(db.String(21))
    sjac = db.Column(db.Numeric(1, 0, asdecimal=False))
    order_chain = db.Column(db.Numeric(1, 0, asdecimal=False))
    type_chain = db.Column(db.Numeric(1, 0, asdecimal=False))
    autoload = db.Column(db.Numeric(1, 0, asdecimal=False))
    attach_cfin = db.Column(db.Numeric(asdecimal=False))
    usercode = db.Column(db.Numeric(6, 0, asdecimal=False))
    link3 = db.Column(db.String(21), info="RECORD SUR LINK3")
    link4 = db.Column(db.String(21), info="RECORD SUR LINK4")
    link5 = db.Column(db.String(21), info="RECORD SUR LINK5")
    link6 = db.Column(db.String(21), info="RECORD SUR LINK6")


class Rtlastcontrib(db.Model):
    __tablename__ = "rtlastcontrib"
    __table_args__ = {"schema": "crs"}

    pgcode = db.Column(db.Numeric(asdecimal=False))
    cfin = db.Column(db.Numeric(asdecimal=False))
    bid = db.Column(db.Numeric(12, 5))
    ask = db.Column(db.Numeric(12, 5))
    spot = db.Column(db.Numeric(12, 5))
    flag = db.Column(db.Numeric(1, 0, asdecimal=False))


class Rtric(db.Model):
    __tablename__ = "rtric"
    __table_args__ = {"schema": "crs"}

    seqchain = db.Column(db.Numeric(asdecimal=False), nullable=False)
    code = db.Column(db.Numeric(asdecimal=False), nullable=False)
    typecode = db.Column(db.Numeric(asdecimal=False), nullable=False)


class Rtwaitack(db.Model):
    __tablename__ = "rtwaitack"
    __table_args__ = {"schema": "crs"}

    reuterscode = db.Column(db.String(30), nullable=False)
    mailtext = db.Column(db.String(255), nullable=False)
    destination = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    create_mail = db.Column(db.DateTime, nullable=False)


class VCfinMarge(db.Model):
    __tablename__ = "v_cfin_marges"
    __table_args__ = {"schema": "crs"}

    cfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    date_cours = db.Column(db.DateTime)
    prix_theorique = db.Column(db.Numeric(asdecimal=False))
    bid = db.Column(db.Numeric(asdecimal=False))
    ask = db.Column(db.Numeric(asdecimal=False))
    marge_bid_vente = db.Column(db.Numeric(asdecimal=False))
    marge_ask_vente = db.Column(db.Numeric(asdecimal=False))
    marge_bid_cp = db.Column(db.Numeric(asdecimal=False))
    marge_ask_cp = db.Column(db.Numeric(asdecimal=False))
    event = db.Column(db.String(1))


class VCfinNoRecup(db.Model):
    __tablename__ = "v_cfin_no_recup"
    __table_args__ = {"schema": "crs"}

    cfin = db.Column(db.Numeric(asdecimal=False))


class VHwarDrExBi(db.Model):
    __tablename__ = "v_hwar_dr_ex_bi"
    __table_args__ = {"schema": "crs"}

    hxdate = db.Column(db.DateTime)
    hxcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    hxprofil = db.Column(db.Numeric(asdecimal=False))
    hxbid = db.Column(db.Numeric(asdecimal=False))
    hxask = db.Column(db.Numeric(asdecimal=False))
    hxmargebid_v = db.Column(db.Numeric(asdecimal=False))
    hxmargeask_v = db.Column(db.Numeric(asdecimal=False))


class VHwarEx(db.Model):
    __tablename__ = "v_hwar_ex"
    __table_args__ = {"schema": "crs"}

    hxdate = db.Column(db.DateTime)
    hxcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    hxsjac = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    hxbid = db.Column(db.Numeric(asdecimal=False))
    hxmargebid = db.Column(db.Numeric(asdecimal=False))
    hxask = db.Column(db.Numeric(asdecimal=False))
    hxmargeask = db.Column(db.Numeric(asdecimal=False))
    hxmidsj = db.Column(db.Numeric(13, 5))


class VHwarWebDr(db.Model):
    __tablename__ = "v_hwar_web_dr"
    __table_args__ = {"schema": "crs"}

    hxdate = db.Column(db.DateTime)
    hxcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    hxbid = db.Column(db.Numeric(asdecimal=False))
    hxask = db.Column(db.Numeric(asdecimal=False))


class VMargesInitiale(db.Model):
    __tablename__ = "v_marges_initiales"
    __table_args__ = {"schema": "crs"}

    cfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Cfin eclus"
    )
    marge_initiale_bid = db.Column(
        db.Numeric(asdecimal=False), info="Marge initiale Bid."
    )
    marge_initiale_ask = db.Column(
        db.Numeric(asdecimal=False), info="Marge initiale Ask."
    )
    date_maj_marge_bid = db.Column(
        db.DateTime, info="Date de dernière modification de la marge initiale Bid"
    )
    loginad_marge_bid = db.Column(
        db.String(64),
        info="Login AD de la personne qui a modifié la marge initiale Bid",
    )
    date_maj_marge_ask = db.Column(
        db.DateTime, info="Date de dernière modification de la marge initiale Ask"
    )
    loginad_marge_ask = db.Column(
        db.String(64),
        info="Login AD de la personne qui a modifié la marge initiale Ask",
    )


class VPiCfin(db.Model):
    __tablename__ = "v_pi_cfin"
    __table_args__ = {"schema": "crs"}

    picfin = db.Column(db.Numeric(asdecimal=False), info="Code Financier")


class VueContribCfin(db.Model):
    __tablename__ = "vue_contrib_cfin"
    __table_args__ = {"schema": "crs"}

    vcicfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Code Financier"
    )


class VuePagesCfin(db.Model):
    __tablename__ = "vue_pages_cfin"
    __table_args__ = {"schema": "crs"}

    pgnom = db.Column(db.String(50), nullable=False)
    ppptcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)


class Famille(db.Model):
    __tablename__ = "famille"
    __table_args__ = {"schema": "exane"}

    facode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de la famille d'un type dinstruments",
    )
    fanom = db.Column(
        db.String(15), nullable=False, info="Nom de la famille d'un type dinstruments"
    )


class Instrument(db.Model):
    __tablename__ = "instruments"
    __table_args__ = (
        db.CheckConstraint(
            "IFVALIDATION = 'N' OR IFVALIDATION = 'M' OR IFVALIDATION = 'R' OR IFVALIDATION = 'V'"
        ),
        db.CheckConstraint("ifcfin <> 0"),
        db.Index("idx1_instrument", "ifcfin", "ifpayoff", "iftype"),
        {"schema": "exane"},
    )

    ifcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    ifstatut = db.Column(
        db.ForeignKey("exane.typestatut.tstcode"),
        nullable=False,
        index=True,
        info="Code du statut d'un instrument financier",
    )
    iftype = db.Column(
        db.ForeignKey("exane.typeinstrument.tycode"),
        nullable=False,
        index=True,
        info="Code du type d'instrument",
    )
    ifnom = db.Column(db.String(60), nullable=False, info="Nom de l'instrument")
    ifmaj = db.Column(
        db.DateTime, nullable=False, info="Date de mise à jour de l'instrument"
    )
    ifpayoff = db.Column(
        db.ForeignKey("exane.typepayoff.tflcode"),
        index=True,
        server_default=db.FetchedValue(),
        info="type de payoff de l'instrument",
    )
    ifcontrat = db.Column(
        db.ForeignKey("exane.typecontrat.tctcode"),
        index=True,
        server_default=db.FetchedValue(),
        info="type de contrat de l'instrument",
    )
    ifvalidation = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Gere la validation des instruments, toutes les caracteristiques du produit qui peuvent influencer le prix  agissent sur le champ IFVALIDATION",
    )
    ifproprietaire = db.Column(
        db.ForeignKey("exane.typeproprietaire.tpcode"),
        info="Propriétaire de l'instument",
    )
    iftypofo = db.Column(
        db.ForeignKey("exane.typofoinstrumentsautorisees.tacode"),
        index=True,
        info="Nouvelle typologie Front des produits cf. EXANE.TYPOFOINSTRUMENTSAUTORISEES",
    )

    typecontrat = db.relationship(
        "Typecontrat",
        primaryjoin="Instrument.ifcontrat == Typecontrat.tctcode",
        backref="instruments",
    )
    typepayoff = db.relationship(
        "Typepayoff",
        primaryjoin="Instrument.ifpayoff == Typepayoff.tflcode",
        backref="instruments",
    )
    typeproprietaire = db.relationship(
        "Typeproprietaire",
        primaryjoin="Instrument.ifproprietaire == Typeproprietaire.tpcode",
        backref="instruments",
    )
    typestatut = db.relationship(
        "Typestatut",
        primaryjoin="Instrument.ifstatut == Typestatut.tstcode",
        backref="instruments",
    )
    typeinstrument = db.relationship(
        "Typeinstrument",
        primaryjoin="Instrument.iftype == Typeinstrument.tycode",
        backref="instruments",
    )
    typofoinstrumentsautorisee = db.relationship(
        "Typofoinstrumentsautorisee",
        primaryjoin="Instrument.iftypofo == Typofoinstrumentsautorisee.tacode",
        backref="instruments",
    )


class Typecontrat(db.Model):
    __tablename__ = "typecontrat"
    __table_args__ = {"schema": "exane"}

    tctcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tctnom = db.Column(db.String(60), nullable=False)


class Typeinstrument(db.Model):
    __tablename__ = "typeinstrument"
    __table_args__ = {"schema": "exane"}

    tycode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du type d'instrument",
    )
    tyfamille = db.Column(
        db.ForeignKey("exane.famille.facode"),
        nullable=False,
        index=True,
        info="Code de la famille d'un type dinstruments",
    )
    tynom = db.Column(db.String(60), info="Libelle du type d'instrument")
    tyname = db.Column(db.String(60))

    famille = db.relationship(
        "Famille",
        primaryjoin="Typeinstrument.tyfamille == Famille.facode",
        backref="typeinstruments",
    )


class Typepayoff(db.Model):
    __tablename__ = "typepayoff"
    __table_args__ = {"schema": "exane"}

    tflcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tflnom = db.Column(db.String(60), nullable=False)


class Typeproprietaire(db.Model):
    __tablename__ = "typeproprietaire"
    __table_args__ = {"schema": "exane"}

    tpcode = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, info="Code du propriétaire"
    )
    tplibelle = db.Column(db.String(60), info="Libellé du propriétaire")


class Typestatut(db.Model):
    __tablename__ = "typestatut"
    __table_args__ = {"schema": "exane"}

    tstcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du statut d'un instrument financier",
    )
    tstnom = db.Column(
        db.String(15),
        nullable=False,
        info="Libellé du statut d'un instrument financier",
    )


class Typofoinstrument(db.Model):
    __tablename__ = "typofoinstrument"
    __table_args__ = (db.CheckConstraint("TICODE>=1000"), {"schema": "exane"})

    ticode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de la nouvelle typologie FO",
    )
    tilibelle = db.Column(
        db.String(200), nullable=False, info="Libellé de la nouvelle typologie FO"
    )


class Typofoinstrumentsautorisee(db.Model):
    __tablename__ = "typofoinstrumentsautorisees"
    __table_args__ = (
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACONTRATINDEFINI Is Not Null AND TACONTRATINDEFINI IN ('O','N')"
        ),
        db.CheckConstraint(
            "TACONTRATLISTE Is Not Null AND TACONTRATLISTE IN ('O','N')"
        ),
        db.CheckConstraint("TACONTRATOTC Is Not Null AND TACONTRATOTC IN ('O','N')"),
        db.CheckConstraint(
            "TACONTRATTITRE Is Not Null AND TACONTRATTITRE IN ('O','N')"
        ),
        db.Index(
            "uk_typofoinstrumentsautorisees",
            "tacodetypoinstrument",
            "tacodetypoinstsjac",
        ),
        {"schema": "exane"},
    )

    tacode = db.Column(
        db.Numeric(9, 0, asdecimal=False),
        primary_key=True,
        info="Code d'association de la typologie instrument et de la typologie sous jacent",
    )
    tacodetypoinstrument = db.Column(
        db.ForeignKey("exane.typofoinstrument.ticode"),
        nullable=False,
        info="Code de la typologie instrument cf. EXANE.TYPOFOINSTRUMENT",
    )
    tacodetypoinstsjac = db.Column(
        db.ForeignKey("exane.typofoinstrumentsjac.tscode"),
        info="Code de la typologie sous jacent cf. EXANE.TYPOFOINSTRUMENTSJAC",
    )
    tacontrattitre = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Titre",
    )
    tacontratliste = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Liste",
    )
    tacontratotc = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat OTC",
    )
    tacontratindefini = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Indéfini",
    )

    typofoinstrument = db.relationship(
        "Typofoinstrument",
        primaryjoin="Typofoinstrumentsautorisee.tacodetypoinstrument == Typofoinstrument.ticode",
        backref="typofoinstrumentsautorisees",
    )
    typofoinstrumentsjac = db.relationship(
        "Typofoinstrumentsjac",
        primaryjoin="Typofoinstrumentsautorisee.tacodetypoinstsjac == Typofoinstrumentsjac.tscode",
        backref="typofoinstrumentsautorisees",
    )


class Typofoinstrumentsjac(db.Model):
    __tablename__ = "typofoinstrumentsjac"
    __table_args__ = {"schema": "exane"}

    tscode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de la nouvelle typologie sous jacent",
    )
    tslibellesjac = db.Column(
        db.String(200), nullable=False, info="Libellé du type de sous jacent du produit"
    )

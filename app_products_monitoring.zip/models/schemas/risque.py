# coding: utf-8
from local_db_mgt import db


class Basecc(db.Model):
    __tablename__ = "basecc"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    bacode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de la convention de calcul du coupon couru",
    )
    banom = db.Column(
        db.String(15),
        nullable=False,
        info="Libellé de la convention de calcul du coupon couru",
    )


class Contributeur(db.Model):
    __tablename__ = "contributeur"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    cocode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="Code contributeur"
    )
    conom = db.Column(db.String(15), info="Nom contributeur")


class Famille(db.Model):
    __tablename__ = "famille"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    facode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de la famille d'un type dinstruments",
    )
    fanom = db.Column(
        db.String(15), nullable=False, info="Nom de la famille d'un type dinstruments"
    )


class Grpuser(db.Model):
    __tablename__ = "grpuser"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    gucode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code du groupe d'utilisateurs",
    )
    gunom = db.Column(db.String(15), nullable=False, info="Nomdu groupe d'utilisateurs")


class Instrument(db.Model):
    __tablename__ = "instruments"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint(
            "IFVALIDATION = 'N' OR IFVALIDATION = 'M' OR IFVALIDATION = 'R' OR IFVALIDATION = 'V'"
        ),
        db.CheckConstraint("ifcfin <> 0"),
        db.Index("idx1_instrument", "ifcfin", "ifpayoff", "iftype"),
        {"schema": "exane"},
    )

    ifcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    ifstatut = db.Column(
        db.ForeignKey("exane.typestatut.tstcode"),
        nullable=False,
        index=True,
        info="Code du statut d'un instrument financier",
    )
    iftype = db.Column(
        db.ForeignKey("exane.typeinstrument.tycode"),
        nullable=False,
        index=True,
        info="Code du type d'instrument",
    )
    ifnom = db.Column(db.String(60), nullable=False, info="Nom de l'instrument")
    ifmaj = db.Column(
        db.DateTime, nullable=False, info="Date de mise à jour de l'instrument"
    )
    ifpayoff = db.Column(
        db.ForeignKey("exane.typepayoff.tflcode"),
        index=True,
        server_default=db.FetchedValue(),
        info="type de payoff de l'instrument",
    )
    ifcontrat = db.Column(
        db.ForeignKey("exane.typecontrat.tctcode"),
        index=True,
        server_default=db.FetchedValue(),
        info="type de contrat de l'instrument",
    )
    ifvalidation = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Gere la validation des instruments, toutes les caracteristiques du produit qui peuvent influencer le prix  agissent sur le champ IFVALIDATION",
    )
    ifproprietaire = db.Column(
        db.ForeignKey("exane.typeproprietaire.tpcode"),
        info="Propriétaire de l'instument",
    )
    iftypofo = db.Column(
        db.ForeignKey("exane.typofoinstrumentsautorisees.tacode"),
        index=True,
        info="Nouvelle typologie Front des produits cf. EXANE.TYPOFOINSTRUMENTSAUTORISEES",
    )

    typecontrat = db.relationship(
        "Typecontrat",
        primaryjoin="Instrument.ifcontrat == Typecontrat.tctcode",
        backref="instruments",
    )
    typepayoff = db.relationship(
        "Typepayoff",
        primaryjoin="Instrument.ifpayoff == Typepayoff.tflcode",
        backref="instruments",
    )
    typeproprietaire = db.relationship(
        "Typeproprietaire",
        primaryjoin="Instrument.ifproprietaire == Typeproprietaire.tpcode",
        backref="instruments",
    )
    typestatut = db.relationship(
        "Typestatut",
        primaryjoin="Instrument.ifstatut == Typestatut.tstcode",
        backref="instruments",
    )
    typeinstrument = db.relationship(
        "Typeinstrument",
        primaryjoin="Instrument.iftype == Typeinstrument.tycode",
        backref="instruments",
    )
    typofoinstrumentsautorisee = db.relationship(
        "Typofoinstrumentsautorisee",
        primaryjoin="Instrument.iftypofo == Typofoinstrumentsautorisee.tacode",
        backref="instruments",
    )


class Devise(Instrument):
    __tablename__ = "devise"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    dvcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    dvpays = db.Column(
        db.ForeignKey("exane.pays.pacode"), nullable=False, index=True, info="Code pays"
    )
    dvcodeiso = db.Column(db.String(3), unique=True)
    dvlibelle = db.Column(db.String(60), info="Libelle de la devise ")

    pay = db.relationship(
        "Pay", primaryjoin="Devise.dvpays == Pay.pacode", backref="devises"
    )


class Rkdevisecomplement(Devise):
    __tablename__ = "rkdevisecomplement"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    dccfin = db.Column(
        db.ForeignKey("exane.devise.dvcfin"),
        primary_key=True,
        info="Cfin de la devise concernee",
    )
    dcpriorite = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        unique=True,
        info="Priorite de la devise par rapport aux autres (determination du sens du cross)",
    )


class Langue(db.Model):
    __tablename__ = "langue"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    lacode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="code de la langue"
    )
    lanom = db.Column(
        db.String(50), nullable=False, info="libellé francais de la langue"
    )


class Marche(db.Model):
    __tablename__ = "marche"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    macode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du marché de cotation",
    )
    maplace = db.Column(
        db.ForeignKey("exane.place.plcode"),
        nullable=False,
        index=True,
        info="Code de la place de cotation",
    )
    manom = db.Column(db.String(60), nullable=False, info="Nom du marché de cotation")
    mamic = db.Column(db.String(4), info="Code MIC du marché")
    mafininfo = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Code FinInfo du marché"
    )
    mareuter = db.Column(db.String(3), info="Code Reuter du marché")
    macamelot = db.Column(
        db.String(3), info="Préfixe du code Camelot de la place associée."
    )

    place = db.relationship(
        "Place", primaryjoin="Marche.maplace == Place.plcode", backref="marches"
    )


class Maturite(db.Model):
    __tablename__ = "maturite"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    mtcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code maturite d'un taux, d'une volatilité",
    )
    mtday = db.Column(db.Numeric(5, 1), info="Maturite en jours")
    mtmonth = db.Column(db.Numeric(5, 1), info="Maturite en mois")
    mtyear = db.Column(db.Numeric(5, 1), info="Maturite en annees")


class Modeexptaux(db.Model):
    __tablename__ = "modeexptaux"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    mecode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    menom = db.Column(db.String(60))


class Pay(db.Model):
    __tablename__ = "pays"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    pacode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="Code pays"
    )
    panom = db.Column(db.String(25), nullable=False, info="Nom pays")
    panomfr = db.Column(db.String(25), info="Nom francais pays\t")
    paabrege = db.Column(db.String(3), info="Abrege du pays\t")
    pacodeiso = db.Column(db.String(6))
    palangue = db.Column(
        db.ForeignKey("exane.langue.lacode"),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Langue parlée dans le pays",
    )

    langue = db.relationship(
        "Langue", primaryjoin="Pay.palangue == Langue.lacode", backref="pays"
    )


class Place(db.Model):
    __tablename__ = "place"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    plcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de la place de cotation",
    )
    plnom = db.Column(db.String(20), nullable=False, info="Nom de la place de cotation")


class Ratconformitetier(db.Model):
    __tablename__ = "ratconformitetiers"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    rgcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    rgstatut = db.Column(db.ForeignKey("exane.typestatut.tstcode"))
    rgnote = db.Column(db.String(60))

    typestatut = db.relationship(
        "Typestatut",
        primaryjoin="Ratconformitetier.rgstatut == Typestatut.tstcode",
        backref="ratconformitetiers",
    )


class Tauxcourbe(db.Model):
    __tablename__ = "tauxcourbe"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("TCBASECC is null or ( TCBASECC in (1,2,3,4,5,6) )"),
        db.CheckConstraint("TCFLAG is null or ( TCFLAG in (1,2,3) )"),
        db.CheckConstraint("TCMODELE in ('D','H')"),
        db.Index(
            "unq_tauxcourbe",
            "tcid",
            "tcdatevaleur",
            "tcdevise",
            "tcmodeexptaux",
            "tcbasecc",
            "tccontributeur",
            "tcmodele",
        ),
        {"schema": "exane"},
    )

    tcid = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    tcdatevaleur = db.Column(db.DateTime, nullable=False, index=True)
    tcdevise = db.Column(
        db.ForeignKey("exane.devise.dvcfin"), info="Code de l'instrument financier"
    )
    tcmodeexptaux = db.Column(db.ForeignKey("exane.modeexptaux.mecode"))
    tcbasecc = db.Column(
        db.ForeignKey("exane.basecc.bacode"),
        info="Code de la convention de calcul du coupon couru",
    )
    tccontributeur = db.Column(
        db.ForeignKey("exane.contributeur.cocode"), info="Code contributeur"
    )
    tcmodele = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="D=Date pilier, H=Horizons pour compatibilité avec INDICTAUX",
    )
    tcuser = db.Column(db.Numeric(8, 0, asdecimal=False))
    tcusermaj = db.Column(db.String(60))
    tcdatecre = db.Column(db.DateTime, server_default=db.FetchedValue())
    tcflag = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )

    basecc = db.relationship(
        "Basecc",
        primaryjoin="Tauxcourbe.tcbasecc == Basecc.bacode",
        backref="tauxcourbes",
    )
    contributeur = db.relationship(
        "Contributeur",
        primaryjoin="Tauxcourbe.tccontributeur == Contributeur.cocode",
        backref="tauxcourbes",
    )
    devise = db.relationship(
        "Devise",
        primaryjoin="Tauxcourbe.tcdevise == Devise.dvcfin",
        backref="tauxcourbes",
    )
    modeexptaux = db.relationship(
        "Modeexptaux",
        primaryjoin="Tauxcourbe.tcmodeexptaux == Modeexptaux.mecode",
        backref="tauxcourbes",
    )


class Tier(db.Model):
    __tablename__ = "tiers"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("TITYPE IN ('T','G','P')"),
        db.CheckConstraint("TITYPE IN ('T','G','P')"),
        {"schema": "exane"},
    )

    ticode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code d'une personne physique ou morale",
    )
    tipays = db.Column(
        db.ForeignKey("exane.pays.pacode"), nullable=False, index=True, info="Code pays"
    )
    tinom = db.Column(
        db.String(60), nullable=False, info="Nom d'une personne physique ou morale"
    )
    timemo = db.Column(db.String(4), nullable=False, info="Abréviation du nom du tiers")
    tisuivi = db.Column(
        db.String(1),
        info="Type de suivi sur une société assuré par un analyste financier",
    )
    titype = db.Column(db.String(1), nullable=False)
    tiappartenance = db.Column(db.ForeignKey("exane.grpuser.gucode"))
    tistatut = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Statut",
    )
    tivaliderdc = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Ce champ ne doit plus être utilisé (remplacé par REFDOC.KYCINFORMATION.KIVALIDERDC)",
    )
    tiratingconf = db.Column(db.ForeignKey("exane.ratconformitetiers.rgcode"))
    tipaysrisk = db.Column(db.Numeric(3, 0, asdecimal=False), info="Code pays risque")
    tiformejuridique = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Forme juridique du tiers"
    )

    grpuser = db.relationship(
        "Grpuser", primaryjoin="Tier.tiappartenance == Grpuser.gucode", backref="tiers"
    )
    pay = db.relationship(
        "Pay", primaryjoin="Tier.tipays == Pay.pacode", backref="pay_tiers"
    )
    pay1 = db.relationship(
        "Pay", primaryjoin="Tier.tipaysrisk == Pay.pacode", backref="pay_tiers_0"
    )
    ratconformitetier = db.relationship(
        "Ratconformitetier",
        primaryjoin="Tier.tiratingconf == Ratconformitetier.rgcode",
        backref="tiers",
    )


class Tpconfirmation(db.Model):
    __tablename__ = "tpconfirmation"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    tccode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de la Confirmation, alimenté manuellement",
    )
    tcnom = db.Column(db.String(100), nullable=False, info="Libellé de la Confirmation")


class Typecontrat(db.Model):
    __tablename__ = "typecontrat"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    tctcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tctnom = db.Column(db.String(60), nullable=False)


class Typeinstrument(db.Model):
    __tablename__ = "typeinstrument"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    tycode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du type d'instrument",
    )
    tyfamille = db.Column(
        db.ForeignKey("exane.famille.facode"),
        nullable=False,
        index=True,
        info="Code de la famille d'un type dinstruments",
    )
    tynom = db.Column(db.String(60), info="Libelle du type d'instrument")
    tyname = db.Column(db.String(60))

    famille = db.relationship(
        "Famille",
        primaryjoin="Typeinstrument.tyfamille == Famille.facode",
        backref="typeinstruments",
    )


class Typepayoff(db.Model):
    __tablename__ = "typepayoff"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    tflcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tflnom = db.Column(db.String(60), nullable=False)


class Typeproprietaire(db.Model):
    __tablename__ = "typeproprietaire"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    tpcode = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, info="Code du propriétaire"
    )
    tplibelle = db.Column(db.String(60), info="Libellé du propriétaire")


class Typeseniorite(db.Model):
    __tablename__ = "typeseniorite"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    tscode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    tsnom = db.Column(db.String(60))


class Typestatut(db.Model):
    __tablename__ = "typestatut"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    tstcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du statut d'un instrument financier",
    )
    tstnom = db.Column(
        db.String(15),
        nullable=False,
        info="Libellé du statut d'un instrument financier",
    )


class Typevolat(db.Model):
    __tablename__ = "typevolat"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    tvcode = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, info="Type volatilite"
    )
    tvnom = db.Column(db.String(20), info="Libel type volat")


class Typofoinstrument(db.Model):
    __tablename__ = "typofoinstrument"
    __bind_key__ = "exane_risque"
    __table_args__ = (db.CheckConstraint("TICODE>=1000"), {"schema": "exane"})

    ticode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de la nouvelle typologie FO",
    )
    tilibelle = db.Column(
        db.String(200), nullable=False, info="Libellé de la nouvelle typologie FO"
    )


class Typofoinstrumentsautorisee(db.Model):
    __tablename__ = "typofoinstrumentsautorisees"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACONTRATINDEFINI Is Not Null AND TACONTRATINDEFINI IN ('O','N')"
        ),
        db.CheckConstraint(
            "TACONTRATLISTE Is Not Null AND TACONTRATLISTE IN ('O','N')"
        ),
        db.CheckConstraint("TACONTRATOTC Is Not Null AND TACONTRATOTC IN ('O','N')"),
        db.CheckConstraint(
            "TACONTRATTITRE Is Not Null AND TACONTRATTITRE IN ('O','N')"
        ),
        db.Index(
            "uk_typofoinstrumentsautorisees",
            "tacodetypoinstrument",
            "tacodetypoinstsjac",
        ),
        {"schema": "exane"},
    )

    tacode = db.Column(
        db.Numeric(9, 0, asdecimal=False),
        primary_key=True,
        info="Code d'association de la typologie instrument et de la typologie sous jacent",
    )
    tacodetypoinstrument = db.Column(
        db.ForeignKey("exane.typofoinstrument.ticode"),
        nullable=False,
        info="Code de la typologie instrument cf. EXANE.TYPOFOINSTRUMENT",
    )
    tacodetypoinstsjac = db.Column(
        db.ForeignKey("exane.typofoinstrumentsjac.tscode"),
        info="Code de la typologie sous jacent cf. EXANE.TYPOFOINSTRUMENTSJAC",
    )
    tacontrattitre = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Titre",
    )
    tacontratliste = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Liste",
    )
    tacontratotc = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat OTC",
    )
    tacontratindefini = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Indéfini",
    )

    typofoinstrument = db.relationship(
        "Typofoinstrument",
        primaryjoin="Typofoinstrumentsautorisee.tacodetypoinstrument == Typofoinstrument.ticode",
        backref="typofoinstrumentsautorisees",
    )
    typofoinstrumentsjac = db.relationship(
        "Typofoinstrumentsjac",
        primaryjoin="Typofoinstrumentsautorisee.tacodetypoinstsjac == Typofoinstrumentsjac.tscode",
        backref="typofoinstrumentsautorisees",
    )


class Typofoinstrumentsjac(db.Model):
    __tablename__ = "typofoinstrumentsjac"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "exane"}

    tscode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de la nouvelle typologie sous jacent",
    )
    tslibellesjac = db.Column(
        db.String(200), nullable=False, info="Libellé du type de sous jacent du produit"
    )


class Caaction(db.Model):
    __tablename__ = "caaction"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    caaccfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    caacprincipal = db.Column(db.String(1))
    caacdebut = db.Column(db.DateTime)
    caacfin = db.Column(db.DateTime)
    caaccroissdiv = db.Column(db.Numeric(5, 2))


class Caamort(db.Model):
    __tablename__ = "caamort"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    caamcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    caambase = db.Column(db.Numeric(2, 0, asdecimal=False))
    caamdev = db.Column(db.Numeric(8, 0, asdecimal=False))
    caamcodetaux = db.Column(db.Numeric(8, 0, asdecimal=False))
    caamtype = db.Column(db.String(1))
    caamfreq = db.Column(db.String(1))
    caamfacial = db.Column(db.Numeric(8, 5))
    caamclean = db.Column(db.String(1))
    caamtypecc = db.Column(db.String(1))
    caamdebut = db.Column(db.DateTime)
    caamfin = db.Column(db.DateTime)
    caamprepost = db.Column(db.String(1))
    caammargeadd = db.Column(db.Numeric(8, 3))
    caammargemult = db.Column(db.Numeric(8, 3))


class Caclause(db.Model):
    __tablename__ = "caclause"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    caclcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    caclnum = db.Column(db.Numeric(8, 0, asdecimal=False))
    cacltype = db.Column(db.Numeric(2, 0, asdecimal=False))
    cacldebut = db.Column(db.DateTime)
    caclfin = db.Column(db.DateTime)
    cacldelai = db.Column(db.Numeric(3, 0, asdecimal=False))
    caclprix = db.Column(db.Numeric(10, 2))
    caclseuil = db.Column(db.Numeric(10, 2))
    caclsoulte = db.Column(db.Numeric(13, 5))
    caclcap = db.Column(db.Numeric(13, 5))
    caclfloor = db.Column(db.Numeric(13, 5))
    caclcoupon = db.Column(db.String(1))
    cacltaux = db.Column(db.Numeric(8, 2))
    caclproba = db.Column(db.Numeric(8, 3))
    caclmulttrigger = db.Column(db.Numeric(8, 3))


class Caclause6(db.Model):
    __tablename__ = "caclause6"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    caclcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Identifiant de l'instrument",
    )
    cacltclause = db.Column(db.Numeric(2, 0, asdecimal=False))
    caclnum = db.Column(
        db.Numeric(20, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="La clé d'ordre de présentation",
    )
    cacldebut = db.Column(db.DateTime, info="Date de début de clause")
    caclfin = db.Column(db.DateTime, info="Date de fin de clause")
    caclrembo = db.Column(
        db.Numeric(10, 2),
        info="Montant du remboursement ( en devise ou pourcentage suivant le type de la clause)",
    )
    cacltrigger = db.Column(
        db.Numeric(10, 2),
        info="Seuil ( trigger) de remboursement ( en devise ou pourcentage suivant le type de la clause)",
    )
    caclmulttrigger = db.Column(
        db.Numeric(8, 3), info="Multiplicateur de seuil ( trigger)"
    )
    cacltypetrigger = db.Column(
        db.Numeric(asdecimal=False), info="Identificateur du type de seuil ( trigger)"
    )
    caclactu = db.Column(
        db.Numeric(8, 2), info="Taus d'actualisation de la clause ( en pourcentage)"
    )
    caclindiccc = db.Column(
        db.String(1), info="Indicateur de prise en compte du coupon couru"
    )
    caclproba = db.Column(
        db.Numeric(8, 3), info="Probabilité d'exercice de la clause ( en pourcentage)"
    )
    caclmin = db.Column(
        db.Numeric(10, 2), info="Montant minimal ( borne inférieure de la clause)"
    )
    caclmax = db.Column(
        db.Numeric(10, 2), info="Montant maximal ( borne supérieure de la clause)"
    )
    caclupdate = db.Column(
        db.DateTime, info="Date de dernière mise à jour de la clause"
    )
    caclflag = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        info="Etat de l'enregistrement: Nouveau ( 1), Modifié ( 2) ou Effacé ( 3)",
    )


class Cacodif(db.Model):
    __tablename__ = "cacodif"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cacfcacfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    cacfsource = db.Column(db.Numeric(3, 0, asdecimal=False))
    cacftype = db.Column(db.Numeric(3, 0, asdecimal=False))
    cacfcode = db.Column(db.String(30))
    cacfmodecot = db.Column(db.Numeric(2, 0, asdecimal=False))
    cacfdesc = db.Column(db.String(30))
    cacfstatut = db.Column(db.Numeric(1, 0, asdecimal=False))
    cacfmarge = db.Column(db.Numeric(6, 2))
    cacfcoeff = db.Column(db.Numeric(6, 0, asdecimal=False))
    cacfrecup = db.Column(db.Numeric(1, 0, asdecimal=False))


class Cacomposition(db.Model):
    __tablename__ = "cacomposition"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cpcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    cpsjac = db.Column(db.Numeric(8, 0, asdecimal=False))
    cpquantite = db.Column(db.Numeric(24, 15))


class Cacvt(db.Model):
    __tablename__ = "cacvt"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cacvcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    cacvtypeconv = db.Column(db.String(1))
    cacvtype = db.Column(db.String(1))
    cacvdebut = db.Column(db.DateTime)
    cacvfin = db.Column(db.DateTime)
    cacvptbase = db.Column(db.Numeric(8, 2))
    cacvparite = db.Column(db.Numeric(11, 5))
    cacvproportion = db.Column(db.Numeric(11, 5))
    cacvsoulte = db.Column(db.Numeric(8, 2))
    cacvptbasersk = db.Column(db.Numeric(8, 2))
    cacvecarttaux = db.Column(db.Numeric(8, 2))
    cacvtypecoupon = db.Column(db.String(1))
    cacvactucoupon = db.Column(db.Numeric(8, 2))
    cacvsjvol = db.Column(db.Numeric(8, 3))
    cacvsjtauxemp = db.Column(db.Numeric(8, 3))
    cacvcoefopda = db.Column(db.Numeric(8, 3))
    cacvcoefaf = db.Column(db.Numeric(8, 3))
    cacvlissage = db.Column(db.String(1))
    cacvmaillage = db.Column(db.Numeric(8, 0, asdecimal=False))
    cacvreglcc = db.Column(db.Numeric(3, 0, asdecimal=False))


class Cadefgroupeprod(db.Model):
    __tablename__ = "cadefgroupeprod"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cadggroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    cadgcfin = db.Column(db.Numeric(8, 0, asdecimal=False))


class Cadefuser(db.Model):
    __tablename__ = "cadefuser"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    caususer = db.Column(db.Numeric(3, 0, asdecimal=False))
    causdefgroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    causdefcolor = db.Column(db.Numeric(3, 0, asdecimal=False))


class Caderive(db.Model):
    __tablename__ = "caderive"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cadecfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    cadesjac = db.Column(db.Numeric(8, 0, asdecimal=False))
    cadereg = db.Column(db.String(1))
    cadecouv = db.Column(db.String(1))
    cadeassim = db.Column(db.String(1))
    cadesoulteuro = db.Column(db.Numeric(8, 2))
    cadedivflag = db.Column(db.Numeric(2, 0, asdecimal=False))
    cadejo = db.Column(db.String(1))
    cademodele = db.Column(db.Numeric(3, 0, asdecimal=False))


class Cadividende(db.Model):
    __tablename__ = "cadividendes"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cadicfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    cadidate = db.Column(db.DateTime)
    cadimontant = db.Column(db.Numeric(13, 5))
    cadidev = db.Column(db.Numeric(8, 0, asdecimal=False))
    cadiavf = db.Column(db.Numeric(8, 3))
    cadiexercice = db.Column(db.DateTime)
    cadistatut = db.Column(db.String(1))
    cadiexdroit = db.Column(db.DateTime)
    cadimaj = db.Column(db.DateTime)
    cadrecart = db.Column(db.Numeric(10, 2))


class Caecheancier(db.Model):
    __tablename__ = "caecheancier"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    caeccfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    caecdate = db.Column(db.DateTime)
    caecmontant = db.Column(db.Numeric(16, 5))
    caecremb = db.Column(db.Numeric(16, 2))
    caecisrembo = db.Column(db.Numeric(16, 2))
    caeccurrembo = db.Column(db.Numeric(16, 2))
    caecanticipe = db.Column(db.Numeric(5, 0, asdecimal=False))


class Caemission(db.Model):
    __tablename__ = "caemission"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    caemcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    caemissuer = db.Column(db.Numeric(12, 0, asdecimal=False))
    caemtype = db.Column(db.String(1))
    caemdate = db.Column(db.DateTime)
    caempaiement = db.Column(db.DateTime)
    caemnominal = db.Column(db.Numeric(15, 2))
    caemnomieuro = db.Column(db.Numeric(10, 2))
    caemprix = db.Column(db.Numeric(10, 2))
    caemspread = db.Column(db.Numeric(13, 5))
    caemnomport = db.Column(db.String(1))
    caemprixpoint = db.Column(db.Numeric(10, 2))
    caemcapiinit = db.Column(db.Numeric(18, 2))
    caemprime = db.Column(db.Numeric(13, 5))
    caemrdt = db.Column(db.Numeric(13, 5))
    caemmaturite = db.Column(db.DateTime)


class Cagroupeprod(db.Model):
    __tablename__ = "cagroupeprod"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cagrcagroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    cagruser = db.Column(db.Numeric(8, 0, asdecimal=False))
    cagrnom = db.Column(db.String(30))
    cagrdefcolonne = db.Column(db.String(300))
    cagrmaturite = db.Column(db.Numeric(3, 0, asdecimal=False))
    cagrdev = db.Column(db.Numeric(3, 0, asdecimal=False))
    cagrmajtaux = db.Column(db.DateTime)
    cagrtaux = db.Column(db.Numeric(8, 5))


class Cagroupetaux(db.Model):
    __tablename__ = "cagroupetaux"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cagtgroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    cagtdev = db.Column(db.Numeric(8, 0, asdecimal=False))
    cagtmaturite = db.Column(db.Numeric(3, 0, asdecimal=False))
    cagttaux = db.Column(db.Numeric(8, 5))


class Cainstrument(db.Model):
    __tablename__ = "cainstrument"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    caifcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    caifstatut = db.Column(db.Numeric(3, 0, asdecimal=False))
    caiftype = db.Column(db.Numeric(3, 0, asdecimal=False))
    caifnom = db.Column(db.String(60))
    caifmaj = db.Column(db.DateTime)
    caifuser = db.Column(db.Numeric(3, 0, asdecimal=False))


class Calast(db.Model):
    __tablename__ = "calast"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    calacfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    caladate = db.Column(db.DateTime)
    calacours = db.Column(db.Numeric(18, 7))


class Capdtcompo(db.Model):
    __tablename__ = "capdtcompo"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pccfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    pctyperevenu = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    pctypecalcul = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)


class Caproduit(db.Model):
    __tablename__ = "caproduit"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    caprcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    caprcourbe = db.Column(db.Numeric(8, 0, asdecimal=False))
    caprmodecot = db.Column(db.Numeric(2, 0, asdecimal=False))
    caprpays = db.Column(db.Numeric(3, 0, asdecimal=False))
    caprmarche = db.Column(db.Numeric(3, 0, asdecimal=False))
    caprdev = db.Column(db.Numeric(8, 0, asdecimal=False))
    caprdevnominal = db.Column(db.Numeric(8, 0, asdecimal=False))
    cacaprquotite = db.Column(db.Numeric(12, 4))


class Castoractivemqserver(db.Model):
    __tablename__ = "castoractivemqservers"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    amservername = db.Column(
        db.String(4000), nullable=False, info="nom du serveur active mq"
    )
    amserverpriority = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="priorite du serveur active mq (pour l ordre de connection)",
    )
    amtcpport = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Port tcp",
    )
    amstompport = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Port stomp",
    )
    amforproduction = db.Column(
        db.String(1), nullable=False, info="Est-ce un serveur de production (Y/N)"
    )


class Castorpottserver(db.Model):
    __tablename__ = "castorpottservers"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    poservername = db.Column(
        db.String(4000), nullable=False, info="nom du serveur Pott"
    )
    pohttpport = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Port http",
    )
    poserverpriority = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="priorite du serveur Pott (pour l ordre de connection)",
    )
    poforproduction = db.Column(
        db.String(1),
        nullable=False,
        info="Y : peut etre utilise pour la production, N: peut etre utilise pour l integration",
    )


class Castortedserver(db.Model):
    __tablename__ = "castortedservers"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    teservername = db.Column(db.String(4000), nullable=False, info="nom du serveur Ted")
    tehttpport = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Port http",
    )
    teserverpriority = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="priorite du serveur Ted (pour l ordre de connection)",
    )
    teforproduction = db.Column(
        db.String(1),
        nullable=False,
        info="Y : peut etre utilise pour la production, N: peut etre utilise pour l integration",
    )


class Cawar(db.Model):
    __tablename__ = "cawar"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cawacfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    cawadevstrike = db.Column(db.Numeric(8, 0, asdecimal=False))
    cawadevput = db.Column(db.Numeric(8, 0, asdecimal=False))
    cawatype = db.Column(db.String(1))
    cawastrike = db.Column(db.Numeric(10, 2))
    cawacallput = db.Column(db.String(1))
    cawaextype = db.Column(db.String(1))
    cawadatedeb = db.Column(db.DateTime)
    cawaremb = db.Column(db.Numeric(6, 2))
    cawaparite = db.Column(db.Numeric(11, 5))
    cawaproportion = db.Column(db.Numeric(11, 5))
    cawaecarttaux = db.Column(db.Numeric(8, 2))
    cawasjvol = db.Column(db.Numeric(8, 3))
    cawasjtauxemp = db.Column(db.Numeric(8, 3))
    cawaactucoupon = db.Column(db.Numeric(8, 2))
    cawatypecoupon = db.Column(db.String(1))
    cawacoefaf = db.Column(db.Numeric(8, 3))
    cawacoefopda = db.Column(db.Numeric(8, 3))
    cawamaillage = db.Column(db.Numeric(8, 0, asdecimal=False))


class CfinScript(db.Model):
    __tablename__ = "cfin_script"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cscfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    csbook = db.Column(db.Numeric(5, 0, asdecimal=False))
    cspos = db.Column(db.Numeric(13, 0, asdecimal=False))
    cscapi = db.Column(db.Numeric(18, 2))


class Defcolcolor(db.Model):
    __tablename__ = "defcolcolor"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ccgroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    cccolonne = db.Column(db.Numeric(3, 0, asdecimal=False))
    cccolor = db.Column(db.Numeric(15, 0, asdecimal=False))


class Extractionmiddle(db.Model):
    __tablename__ = "extractionmiddle"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    emdatetravail = db.Column(db.DateTime)
    emdatevaleur = db.Column(db.DateTime)
    emdateexecution = db.Column(db.DateTime)
    emcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    emqte = db.Column(db.Numeric(10, 0, asdecimal=False))
    emcours = db.Column(db.Numeric(18, 5))
    emsens = db.Column(db.String(1))
    emuser = db.Column(db.Numeric(5, 0, asdecimal=False))
    emcleordre = db.Column(db.String(150))
    emcleexecution = db.Column(db.String(30))
    emcodecptie = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    emlibellecptie = db.Column(db.String(30), nullable=False)
    emivalcptie = db.Column(db.Numeric(5, 0, asdecimal=False))
    embudget = db.Column(db.Numeric(4, 0, asdecimal=False))
    embudgetlibre = db.Column(db.String(20))
    emcompte = db.Column(db.Numeric(5, 0, asdecimal=False))
    emcomptelibre = db.Column(db.String(20))
    emdevise = db.Column(db.Numeric(asdecimal=False))
    emstatut = db.Column(db.Numeric(1, 0, asdecimal=False))
    emmodule = db.Column(db.String(4))
    emmarcherti = db.Column(db.String(30))


class GepettoConfig(db.Model):
    __tablename__ = "gepetto_config"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    cfg_book = db.Column(
        db.Numeric(asdecimal=False), primary_key=True, info=" n\\260 sous-portefeuille"
    )
    cfg_pas = db.Column(
        db.Numeric(asdecimal=False),
        nullable=False,
        info=' pas de spot en "portion" de ticks',
    )
    cfg_limite = db.Column(
        db.Numeric(asdecimal=False),
        info=" Limite de variation autour du spot central (en %)",
    )


class GepettoPortefeuille(db.Model):
    __tablename__ = "gepetto_portefeuilles"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    pf_bigbook = db.Column(
        db.Numeric(asdecimal=False), primary_key=True, info=" n\\260 portefeuille"
    )
    pf_pas = db.Column(
        db.Numeric(asdecimal=False),
        nullable=False,
        info=' pas de spot par d\\351faut (en "portion" de ticks)',
    )
    pf_limite = db.Column(
        db.Numeric(asdecimal=False),
        info=" Limite par d\\351faut de variation autour du spot central (en %)",
    )


class Hcpindex(db.Model):
    __tablename__ = "hcpindex"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    citype = db.Column(
        db.ForeignKey("risque.typecpindex.ticode"),
        nullable=False,
        info="Type d'entree RISQUE.TYPECPINDEX",
    )
    cisource = db.Column(
        db.ForeignKey("risque.typesourceindex.tscode"),
        nullable=False,
        index=True,
        info="Source de donn‚es RISQUE.TYPESOURCEINDEX",
    )
    cicfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="Cfin du produit",
    )
    cidatevaleur = db.Column(
        db.DateTime, nullable=False, info="Date valeur de la donn‚es (date calcul)"
    )
    cicodematurite = db.Column(
        db.ForeignKey("exane.maturite.mtcode"),
        info="Code de la maturite EXANE.MATURITE",
    )
    cidatematurite = db.Column(db.DateTime, info="Date de maturite")
    cistrikepct = db.Column(db.Numeric(13, 5), index=True, info="Strike en %")
    cispot = db.Column(
        db.Numeric(13, 5), info="Spot - plus g‚n‚ralement c'est le Forward"
    )
    civaleur = db.Column(db.Numeric(13, 5), info="Valeur de vol")
    ciprofil = db.Column(
        db.ForeignKey("risque.prprofil.pprofil"), info="Profil de vol RISQUE.PRPROFIL"
    )
    ciinfoflag = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        info="Flag indiquant si la nappe de vol associee a ete mise … jour depuis la derniŠre ‚valuation",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hcpindex.cicfin == Instrument.ifcfin",
        backref="hcpindexes",
    )
    maturite = db.relationship(
        "Maturite",
        primaryjoin="Hcpindex.cicodematurite == Maturite.mtcode",
        backref="hcpindexes",
    )
    prprofil = db.relationship(
        "Prprofil",
        primaryjoin="Hcpindex.ciprofil == Prprofil.pprofil",
        backref="hcpindexes",
    )
    typesourceindex = db.relationship(
        "Typesourceindex",
        primaryjoin="Hcpindex.cisource == Typesourceindex.tscode",
        backref="hcpindexes",
    )
    typecpindex = db.relationship(
        "Typecpindex",
        primaryjoin="Hcpindex.citype == Typecpindex.ticode",
        backref="hcpindexes",
    )


class Hforward(db.Model):
    __tablename__ = "hforward"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint(
            "hfdatematu=TRUNC(hfdatematu) AND (hfdatematu Is Not Null OR hfcodematu Is Not Null)"
        ),
        db.CheckConstraint(
            "hfdatematu=TRUNC(hfdatematu) AND (hfdatematu Is Not Null OR hfcodematu Is Not Null)"
        ),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    hfcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    hfdate = db.Column(
        db.DateTime, nullable=False, index=True, info="Date de calcul du forward"
    )
    hfcodematu = db.Column(
        db.ForeignKey("exane.maturite.mtcode"), info="Code maturite (cf EXANE.MATURITE)"
    )
    hfdatematu = db.Column(db.DateTime, info="Date de maturite (")
    hfforward = db.Column(db.Numeric(13, 5), info="Valeur du forward")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Hforward.hfcfin == Instrument.ifcfin",
        backref="hforwards",
    )
    maturite = db.relationship(
        "Maturite",
        primaryjoin="Hforward.hfcodematu == Maturite.mtcode",
        backref="hforwards",
    )


class HtauxTirage(db.Model):
    __tablename__ = "htaux_tirage"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    httdateval = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date de valeur du taux"
    )
    httcfin = db.Column(
        db.Numeric(asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Devise associée",
    )
    htttxjjdebiteur = db.Column(db.Numeric(asdecimal=False), info="Taux JJ Debiteur")
    htttxterme = db.Column(db.Numeric(asdecimal=False), info="Taux Terme")
    htttxbnpcrediteur = db.Column(
        db.Numeric(asdecimal=False), info="Taux BNP Crediteur"
    )
    htttxbnpdebiteur = db.Column(db.Numeric(asdecimal=False), info="Taux BNP Debiteur")


class Mdpnlinstrument(db.Model):
    __tablename__ = "mdpnlinstrument"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pidate = db.Column(db.DateTime, index=True)
    pihorodate = db.Column(db.DateTime)
    pibudget = db.Column(db.String(5), index=True)
    pibigbook = db.Column(db.Numeric(4, 0, asdecimal=False), index=True)
    pibook = db.Column(db.Numeric(5, 0, asdecimal=False))
    pitypeproduit = db.Column(db.String(30))
    pidevise = db.Column(db.String(3))
    picfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    piisin = db.Column(db.String(30))
    pilibelle = db.Column(db.String(60))
    pistatut = db.Column(db.String(1), info="'E': Echu - 'N': Non echu")
    piplcumul = db.Column(db.Numeric(asdecimal=False))
    piplcumulbrut = db.Column(db.Numeric(asdecimal=False))
    pipljour = db.Column(db.Numeric(asdecimal=False))
    pipos = db.Column(db.Numeric(asdecimal=False))
    piprixref = db.Column(db.Numeric(asdecimal=False))
    pivaloref = db.Column(db.Numeric(asdecimal=False))
    piprixcotation = db.Column(db.Numeric(asdecimal=False))
    piprixvalo = db.Column(db.Numeric(asdecimal=False))
    pivalo = db.Column(db.Numeric(asdecimal=False))
    piflux = db.Column(db.Numeric(asdecimal=False))
    pidividende = db.Column(db.Numeric(asdecimal=False))
    picoupon = db.Column(db.Numeric(asdecimal=False))
    pitaxerecup = db.Column(db.Numeric(asdecimal=False))
    piretro = db.Column(db.Numeric(asdecimal=False))
    pifraisemission = db.Column(db.Numeric(asdecimal=False))
    pitransfertcash = db.Column(db.Numeric(asdecimal=False))
    pifraiscumul = db.Column(db.Numeric(asdecimal=False))
    pifraisjour = db.Column(db.Numeric(asdecimal=False))
    piecartvalojour = db.Column(db.Numeric(asdecimal=False))
    piflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class Mdrare(db.Model):
    __tablename__ = "mdrare"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("mrflag in (1,2,3)"),
        db.CheckConstraint("mrflag in (1,2,3)"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    mrdate = db.Column(
        db.DateTime, nullable=False, index=True, info="date de generation du pnl"
    )
    mrbigbook = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="Code du portefeuille (cf RKBIGBOOK.BBBIGBOOK)",
    )
    mrdevise = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de la devise (cf INSTRUMENT.IFCFIN)",
    )
    mrpnl = db.Column(
        db.Numeric(asdecimal=False),
        nullable=False,
        info="Montant cumule depuis le debut de l annee dans la devise MRDEVISE",
    )
    mrtauxvseuro = db.Column(
        db.Numeric(16, 8),
        nullable=False,
        info="Taux de change contre l Euro utilise lors de l edition du pnl",
    )
    mrflag = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Statut de l enregistrement 1(cree), 2(mis a jour), 3(efface)",
    )
    mrfrais = db.Column(
        db.Numeric(asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Montant cumule des frais depuis le debut de l annee dans la devise MRDEVISE",
    )


class Mgalgoreference(db.Model):
    __tablename__ = "mgalgoreference"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("ARSHORTCODE BETWEEN 900000001 AND 999999999"),
        db.CheckConstraint("ARTYPE IN ('A','O')"),
        db.CheckConstraint("Regexp_Like(ARLONGNAME,'^([A-Z0-9])+$')"),
        {"schema": "risque"},
    )

    arshortcode = db.Column(
        db.Numeric(9, 0, asdecimal=False),
        primary_key=True,
        info="Short code between 900 000 000 and 999 999 999",
    )
    arlongname = db.Column(db.String(50), nullable=False)
    arowner = db.Column(db.String(50))
    ardescription = db.Column(db.String(100))
    artype = db.Column(db.String(1), server_default=db.FetchedValue())
    arcreationdate = db.Column(db.DateTime, server_default=db.FetchedValue())


class Mgdefworkspaceroute(db.Model):
    __tablename__ = "mgdefworkspaceroute"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("WRINFRA IN ('TRADING','SALES')"),
        db.CheckConstraint("WRROUTETYPE IN ('BROKER','MEMBERSHIP')"),
        {"schema": "risque"},
    )

    wrinfra = db.Column(
        db.String(30), nullable=False, info="Type d'infra (SALES / TRADING)"
    )
    wrapplicationid = db.Column(
        db.Integer, nullable=False, info="Identification de l'application Morgan"
    )
    wrworkspaceid = db.Column(
        db.Integer, primary_key=True, info="Identification du workspace Camelot"
    )
    wrroute = db.Column(db.String(30), nullable=False, info="Route utilisée")
    wrroutetype = db.Column(
        db.String(50), nullable=False, info="Type de route utilisé, Broker / Membership"
    )
    wrbrokerid = db.Column(
        db.ForeignKey("exane.tiers.ticode"),
        info="Identifiant du broker (EXANE.TIERS.TICODE)",
    )

    tier = db.relationship(
        "Tier",
        primaryjoin="Mgdefworkspaceroute.wrbrokerid == Tier.ticode",
        backref="mgdefworkspaceroutes",
    )


class Mgticket(db.Model):
    __tablename__ = "mgticket"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("TKEQUITIESSTATUS IN ('E','C','O','D','R','Z','M')"),
        db.CheckConstraint("TKTRADINGCAPACITY IN ('UNKNOWN', 'MTCH', 'DEAL', 'AOTC')"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tktransactiondate = db.Column(
        db.DateTime,
        nullable=False,
        index=True,
        info="Date de la transaction électronique",
    )
    tktransactiontime = db.Column(
        db.DateTime, info="Heure de la transaction électronique"
    )
    tktransactiontimelag = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Décalage horaire éventuel / GMT"
    )
    tkinstrumentalias = db.Column(
        db.String(127), index=True, info="GenericName Camelot"
    )
    tkinstrumentnegokey = db.Column(
        db.String(255),
        nullable=False,
        index=True,
        info="Identifiant marché de l'instrument",
    )
    tkcfin = db.Column(db.Numeric(8, 0, asdecimal=False), index=True, info="Cfin Exane")
    tkisincode = db.Column(db.String(12), index=True, info="Code ISIN")
    tksegment = db.Column(db.String(10), info="Code compartiment")
    tkmarketcode = db.Column(
        db.Numeric(4, 0, asdecimal=False), index=True, info="Code marché Exane"
    )
    tkdirection = db.Column(db.String(1), nullable=False, info="Sens")
    tkquantity = db.Column(db.Numeric(17, 4), nullable=False, info="Quantité exécutée")
    tkprice = db.Column(db.Numeric(15, 5), nullable=False, info="Prix d'exécution")
    tkcurrencycodeiso = db.Column(db.String(3), info="Code ISO de la devise")
    tkcurrencycode = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code Exane de la devise"
    )
    tkprofitcentre = db.Column(db.String(4), index=True, info="Centre budgétaire")
    tkportfolio = db.Column(
        db.Numeric(4, 0, asdecimal=False), index=True, info="Portefeuille (Big Book)"
    )
    tksubportfolio = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="Sous-portefeuille (Book)"
    )
    tktradingaccounttype = db.Column(db.String(1), info="Type de compte")
    tktradingaccountname = db.Column(db.String(39), info="Nom du compte")
    tkcounterpart = db.Column(db.String(49), index=True, info="Contrepartie")
    tktransactionid = db.Column(
        db.String(49), info="Identifiant marché de la transaction"
    )
    tkexecutionvenue = db.Column(db.String(10), info="Place d'execution")
    tkmarketstatus = db.Column(db.String(1), info="Flag d'annulation marché")
    tkstrlegreference = db.Column(db.String(11), info="Référence de l'ordre")
    tkworkspaceid = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="Identifiant Arthur",
    )
    tkappgroup = db.Column(db.String(3), index=True, info="Groupe de l'utilisateur")
    tkownerid = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        index=True,
        info="Identifiant Camelot de l'utilisateur",
    )
    tkorigin = db.Column(db.String(3), index=True, info="Origine de l'ordre")
    tktickettype = db.Column(db.String(1), info="Type de transaction")
    tkbookingstatus = db.Column(db.String(1), info="Statut de booking")
    tkbookingmessage = db.Column(db.String(255), info="Message de booking")
    tkbookingreference = db.Column(
        db.String(30),
        info=" Référence de booking : opnumero (PoTT) ou ptntransaction (PoP)",
    )
    tkloginad = db.Column(db.String(40), info="Login AD de donneur d'ordre.")
    tkequitiescashid = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="CASHID - Id de l'instrument dans EQUITIES (source web service ACT interroge par CAMELOT)",
    )
    tkequitiesstatus = db.Column(
        db.String(1),
        info="Statut de l'integration du ticket dans EQUITIES. E => Error, C => Cashid non trouve aupres du Web Service cote CASH, O => Ok, D => Duplicate Id (CASHINTRADAY_CLIENTEXEC), R => Ready (pret a integrer dans Equities), M => code MIC non trouve pour le marche principale du produit, Z => En dehors du perimetre identifie",
    )
    tkequitiesstatushoro = db.Column(
        db.DateTime, info="Horodatage du dernier changement de statut"
    )
    tkintegrationhorodate = db.Column(
        db.DateTime,
        server_default=db.FetchedValue(),
        info="Horodatage d'intégration du ticket au sein de la table MGTICKET.",
    )
    tkagregationkey = db.Column(
        db.String(30), info="clé Morgan d'agrégation d'exécutions électroniques"
    )
    tkconsumer = db.Column(
        db.String(10),
        info=" identifiant du consommateur d'un agrégat de tickets Camelot",
    )
    tkyoshiid = db.Column(
        db.String(50),
        info="Identifiant Yoshi ayant amené à l'exécution Morgan / utilisée dans le TR MIFID 2.",
    )
    tkclientid = db.Column(
        db.Integer, info="Identifiant CRM du client / utilisée dans le TR MIFID 2."
    )
    tkexecutiondecision = db.Column(
        db.String(50), info="Identifiant de l'algorithme / utilisée dans le TR MIFID 2."
    )
    tkinvestmentdecision = db.Column(
        db.String(50), info="Identifiant de l'automate / utilisée dans le TR MIFID 2."
    )
    tktradingcapacity = db.Column(
        db.String(7), info="Trading Capacity / utilisée dans le TR MIFID 2"
    )
    tktvtic = db.Column(
        db.String(60),
        info="Trading Venue Identification Code / utilisée dans le TR MIFID 2",
    )
    tkticketid = db.Column(
        db.String(64), unique=True, info="identifiant camelot du ticket"
    )
    tkbrokerid = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Identifiant du broker utilisé."
    )
    tkroute = db.Column(
        db.String(30), info="Nom de la route utilisée cf MGDEFWORKSPACEROUTE"
    )
    tkroutetype = db.Column(
        db.String(50), info="Type de la route utilisée cf MGDEFWORKSPACEROUTE."
    )


class Mvoldata(db.Model):
    __tablename__ = "mvoldatas"
    __bind_key__ = "exane_risque"
    __table_args__ = (db.CheckConstraint("VDTYPE IN ('A','E')"), {"schema": "risque"})

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vdhorodate = db.Column(
        db.DateTime,
        nullable=False,
        server_default=db.FetchedValue(),
        info="Horodatage du calcul",
    )
    vdsjac = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="Cfin du sous-jacent",
    )
    vdmaturite = db.Column(db.DateTime, nullable=False, info="Maturité options")
    vdtype = db.Column(
        db.String(1), nullable=False, info="type option (Américaine/Européenne)"
    )
    vdbidcall = db.Column(db.Numeric(18, 6), info="\tBid call")
    vdprixtheocall = db.Column(db.Numeric(18, 6), info="\tPrix theorique")
    vdaskcall = db.Column(db.Numeric(18, 6), info="\tAsk call")
    vdstrike = db.Column(db.Numeric(18, 6), info=" \tstrike option")
    vdbidput = db.Column(db.Numeric(18, 6), info=" \tbid put")
    vdprixtheoput = db.Column(db.Numeric(18, 6), info=" \tprix theorique ")
    vdaskput = db.Column(db.Numeric(18, 6), info=" \tas put")
    vdvi = db.Column(db.Numeric(18, 6), info=" \tvol implicite exane")
    vdvolmidmarket = db.Column(db.Numeric(18, 6), info=" \tvol implicite mid du marché")
    vdforward = db.Column(db.Numeric(18, 6), info="forward à la maturité de l'option")
    vdvolatmmarket = db.Column(
        db.Numeric(18, 6), info="vol à la monnaie implicte du marché"
    )
    vdvolbidmarket = db.Column(db.Numeric(18, 6), info="vol implicite bid du marché")
    vdvolaskmarket = db.Column(db.Numeric(18, 6), info="vol implicite ask du marché")
    vdrepoimp = db.Column(db.Numeric(18, 6), info="repo implicite du marché")
    vdspot = db.Column(db.Numeric(18, 6), info="spot de référence")
    vdvolcallbid = db.Column(db.Numeric(18, 6), info="vol implicite bid du call")
    vdvolcallmid = db.Column(db.Numeric(18, 6), info="vol implicite mid du call")
    vdvolcallask = db.Column(db.Numeric(18, 6), info="vol implicite ask du call")
    vdvolputbid = db.Column(db.Numeric(18, 6), info="vol implicite bid du put")
    vdvolputmid = db.Column(db.Numeric(18, 6), info="vol implicite mid du put")
    vdvolputask = db.Column(db.Numeric(18, 6), info="vol implicite ask du put")
    vdvegacall = db.Column(db.Numeric(18, 6), info="vega du call")
    vdvegaput = db.Column(db.Numeric(18, 6), info="vega du put")
    vdcfincall = db.Column(db.Numeric(8, 0, asdecimal=False), info="cfin du call")
    vdcfinput = db.Column(db.Numeric(8, 0, asdecimal=False), info="cfin du put")
    vddeltacall = db.Column(db.Numeric(18, 6), info="delta du call")
    vddeltaput = db.Column(db.Numeric(18, 6), info="delta du put")
    vdqtybidcall = db.Column(db.Numeric(18, 6), info="Quantité bid du call")
    vdqtyaskcall = db.Column(db.Numeric(18, 6), info="Quantité ask du call")
    vdqtybidput = db.Column(db.Numeric(18, 6), info="Quantité bid du put")
    vdqtyaskput = db.Column(db.Numeric(18, 6), info="Quantité ask du put")
    vdquotitecall = db.Column(db.Numeric(18, 6), info="Quotite du call.")
    vdquotiteput = db.Column(db.Numeric(18, 6), info="Quotite du put")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Mvoldata.vdsjac == Instrument.ifcfin",
        backref="mvoldatas",
    )


class Mvolforward(db.Model):
    __tablename__ = "mvolforward"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    vfhorodate = db.Column(
        db.DateTime,
        nullable=False,
        server_default=db.FetchedValue(),
        info="Horodatage de la saisie",
    )
    vfsjac = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="Cfin du sous-jacent",
    )
    vfmaturite = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Maturite"
    )
    vfforward = db.Column(db.Numeric(18, 6), info="Forward")
    vfvolatmmid = db.Column(db.Numeric(18, 6), info="Vol ATM Mid implicite du marché")
    vfvolatmbid = db.Column(db.Numeric(18, 6), info="Vol ATM Bid implicite du marché")
    vfvolatmask = db.Column(db.Numeric(18, 6), info="Vol ATM Ask implicite du marché")
    vfvolatmindref = db.Column(
        db.Numeric(18, 6), info="Vol ATM de l'indice de ref du sous-jacent"
    )
    vfvoldownindref = db.Column(
        db.Numeric(18, 6), info="Vol 99.5  de l'indice de ref du sous-jacent"
    )
    vfvolupindref = db.Column(
        db.Numeric(18, 6), info="Vol 100.5  de l'indice de ref du sous-jacent"
    )
    vfspotindref = db.Column(
        db.Numeric(18, 6), info="spot de l'indice de ref du sous-jacent"
    )
    vfrepoimp = db.Column(db.Numeric(18, 6), info="Repo implicite du marché")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Mvolforward.vfsjac == Instrument.ifcfin",
        backref="mvolforwards",
    )


class Mvolgen(db.Model):
    __tablename__ = "mvolgen"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("uk_mvolgen", "vgcfin", "vgmodele", "vgsource"),
        {"schema": "risque"},
    )

    vgidmvol = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="ID des nouveaux paramètres(un ID unique pour un couple cfin / modèle)",
    )
    vgcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        index=True,
        info="cfin du sous-jacent",
    )
    vgmnemo = db.Column(db.String(30), info="mnemo du sous-jacent")
    vgmodele = db.Column(
        db.ForeignKey("risque.mvoltypemodel.tmcode"), info="modèle utilisé"
    )
    vghorodate = db.Column(db.DateTime, info="date de mise à jour des paramètres")
    vguser = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="user qui a mis à jour les paramètres"
    )
    vgindiceref = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        index=True,
        info="cfin de l'indice de référence",
    )
    vgsource = db.Column(
        db.ForeignKey("risque.typesourceindex.tscode"),
        index=True,
        info="Source de donnees RISQUE.TYPESOURCEINDEX",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Mvolgen.vgcfin == Instrument.ifcfin",
        backref="instrument_mvolgens",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Mvolgen.vgindiceref == Instrument.ifcfin",
        backref="instrument_mvolgens_0",
    )
    mvoltypemodel = db.relationship(
        "Mvoltypemodel",
        primaryjoin="Mvolgen.vgmodele == Mvoltypemodel.tmcode",
        backref="mvolgens",
    )
    typesourceindex = db.relationship(
        "Typesourceindex",
        primaryjoin="Mvolgen.vgsource == Typesourceindex.tscode",
        backref="mvolgens",
    )


class MvolgenH(db.Model):
    __tablename__ = "mvolgen_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("VGHDATEVALEUR = TRUNC(VGHDATEVALEUR)"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vghidmvol = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="ID des nouveaux paramètres(un ID unique pour un couple cfin / modèle)",
    )
    vghcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), index=True, info="cfin du sous-jacent"
    )
    vghmnemo = db.Column(db.String(30), info="mnemo du sous-jacent")
    vghmodele = db.Column(
        db.Numeric(3, 0, asdecimal=False), index=True, info="modèle utilisé"
    )
    vghhorodate = db.Column(db.DateTime, info="date de mise à jour des paramètres")
    vghuser = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="user qui a mis à jour les paramètres"
    )
    vghindiceref = db.Column(db.Numeric(8, 0, asdecimal=False))
    vghdatevaleur = db.Column(db.DateTime, index=True, server_default=db.FetchedValue())
    vghsource = db.Column(
        db.ForeignKey("risque.typesourceindex.tscode"),
        index=True,
        info="Source de donnees RISQUE.TYPESOURCEINDEX",
    )

    typesourceindex = db.relationship(
        "Typesourceindex",
        primaryjoin="MvolgenH.vghsource == Typesourceindex.tscode",
        backref="mvolgen_hs",
    )


class MvolgenTemp(db.Model):
    __tablename__ = "mvolgen_temp"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    vgidmvol = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    vgcfin = db.Column(db.ForeignKey("exane.instruments.ifcfin"), index=True)
    vgmnemo = db.Column(db.String(30))
    vgmodele = db.Column(db.ForeignKey("risque.mvoltypemodel.tmcode"))
    vghorodate = db.Column(db.DateTime, server_default=db.FetchedValue())
    vguser = db.Column(db.Numeric(8, 0, asdecimal=False))
    vgindiceref = db.Column(db.Numeric(8, 0, asdecimal=False))
    vgsource = db.Column(
        db.ForeignKey("risque.typesourceindex.tscode"),
        index=True,
        info="Source de donnees RISQUE.TYPESOURCEINDEX",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="MvolgenTemp.vgcfin == Instrument.ifcfin",
        backref="mvolgen_temps",
    )
    mvoltypemodel = db.relationship(
        "Mvoltypemodel",
        primaryjoin="MvolgenTemp.vgmodele == Mvoltypemodel.tmcode",
        backref="mvolgen_temps",
    )
    typesourceindex = db.relationship(
        "Typesourceindex",
        primaryjoin="MvolgenTemp.vgsource == Typesourceindex.tscode",
        backref="mvolgen_temps",
    )


class Mvolparamgen(db.Model):
    __tablename__ = "mvolparamgen"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    pgidmvol = db.Column(
        db.ForeignKey("risque.mvolgen.vgidmvol", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        info="ID des paramètres",
    )
    pgindicateur = db.Column(
        db.ForeignKey("risque.mvoltypeindic.ticode"),
        primary_key=True,
        nullable=False,
        info="code de l'Indicateur",
    )
    pgvaleur = db.Column(
        db.Numeric(18, 6), nullable=False, info="valeur de l'indicateur"
    )

    mvolgen = db.relationship(
        "Mvolgen",
        primaryjoin="Mvolparamgen.pgidmvol == Mvolgen.vgidmvol",
        backref="mvolparamgens",
    )
    mvoltypeindic = db.relationship(
        "Mvoltypeindic",
        primaryjoin="Mvolparamgen.pgindicateur == Mvoltypeindic.ticode",
        backref="mvolparamgens",
    )


class MvolparamgenH(db.Model):
    __tablename__ = "mvolparamgen_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pghidmvol = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="ID des paramètres",
    )
    pghindicateur = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="code de l'Indicateur"
    )
    pghvaleur = db.Column(
        db.Numeric(18, 6), nullable=False, info="valeur de l'indicateur"
    )


class MvolparamgenTemp(db.Model):
    __tablename__ = "mvolparamgen_temp"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    pgidmvol = db.Column(
        db.ForeignKey("risque.mvolgen_temp.vgidmvol", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
    )
    pgindicateur = db.Column(
        db.ForeignKey("risque.mvoltypeindic.ticode"), primary_key=True, nullable=False
    )
    pgvaleur = db.Column(db.Numeric(18, 6), nullable=False)

    mvolgen_temp = db.relationship(
        "MvolgenTemp",
        primaryjoin="MvolparamgenTemp.pgidmvol == MvolgenTemp.vgidmvol",
        backref="mvolparamgen_temps",
    )
    mvoltypeindic = db.relationship(
        "Mvoltypeindic",
        primaryjoin="MvolparamgenTemp.pgindicateur == Mvoltypeindic.ticode",
        backref="mvolparamgen_temps",
    )


class Mvolparammat(db.Model):
    __tablename__ = "mvolparammat"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    pmidmvol = db.Column(
        db.ForeignKey("risque.mvolgen.vgidmvol", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        info="ID des paramètres",
    )
    pmmaturite = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Maturité sur laquelle porte l'indicateur",
    )
    pmindicateur = db.Column(
        db.ForeignKey("risque.mvoltypeindic.ticode"),
        primary_key=True,
        nullable=False,
        info="code de l'indicateur",
    )
    pmvaleur = db.Column(
        db.Numeric(18, 6), nullable=False, info="valeur de l'indicateur"
    )

    mvolgen = db.relationship(
        "Mvolgen",
        primaryjoin="Mvolparammat.pmidmvol == Mvolgen.vgidmvol",
        backref="mvolparammats",
    )
    mvoltypeindic = db.relationship(
        "Mvoltypeindic",
        primaryjoin="Mvolparammat.pmindicateur == Mvoltypeindic.ticode",
        backref="mvolparammats",
    )


class MvolparammatH(db.Model):
    __tablename__ = "mvolparammat_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pmhidmvol = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="ID des paramètres",
    )
    pmhmaturite = db.Column(
        db.DateTime, nullable=False, info="Maturité sur laquelle porte l'indicateur"
    )
    pmhindicateur = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="code de l'indicateur"
    )
    pmhvaleur = db.Column(
        db.Numeric(18, 6), nullable=False, info="valeur de l'indicateur"
    )


class MvolparammatTemp(db.Model):
    __tablename__ = "mvolparammat_temp"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    pmidmvol = db.Column(
        db.ForeignKey("risque.mvolgen_temp.vgidmvol", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
    )
    pmmaturite = db.Column(db.DateTime, primary_key=True, nullable=False)
    pmindicateur = db.Column(
        db.ForeignKey("risque.mvoltypeindic.ticode"), primary_key=True, nullable=False
    )
    pmvaleur = db.Column(db.Numeric(18, 6), nullable=False)

    mvolgen_temp = db.relationship(
        "MvolgenTemp",
        primaryjoin="MvolparammatTemp.pmidmvol == MvolgenTemp.vgidmvol",
        backref="mvolparammat_temps",
    )
    mvoltypeindic = db.relationship(
        "Mvoltypeindic",
        primaryjoin="MvolparammatTemp.pmindicateur == Mvoltypeindic.ticode",
        backref="mvolparammat_temps",
    )


class Mvoltypeindic(db.Model):
    __tablename__ = "mvoltypeindic"
    __bind_key__ = "exane_risque"
    __table_args__ = (db.CheckConstraint("TIType IN ('G','M')"), {"schema": "risque"})

    ticode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="code du paramètre"
    )
    tilibelle = db.Column(db.String(30), nullable=False, info="libellé du paramètre")
    titype = db.Column(
        db.String(1), nullable=False, info="type du paramètre (General ou par Maturité)"
    )


class Mvoltypemodel(db.Model):
    __tablename__ = "mvoltypemodel"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    tmcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du modèle de calibration de vol",
    )
    tmlibelle = db.Column(
        db.String(30), nullable=False, info="libellé du modèle de calibration de vol"
    )


class Ngactivite(db.Model):
    __tablename__ = "ngactivite"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    accode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    acservice = db.Column(db.ForeignKey("risque.ngservice.svcode"))
    acmachine = db.Column(db.String(60))
    acetat = db.Column(db.String(3))
    acflag = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    acutilisateur = db.Column(db.String(60))

    ngservice = db.relationship(
        "Ngservice",
        primaryjoin="Ngactivite.acservice == Ngservice.svcode",
        backref="ngactivites",
    )


class Ngadminexanego(db.Model):
    __tablename__ = "ngadminexanego"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    adcode = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Numero enregistrement"
    )
    adnom = db.Column(db.String(30), nullable=False, info="Nom")
    adpw = db.Column(db.String(10), info="Password")
    adflag = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Flag",
    )


class Ngcommunordre(db.Model):
    __tablename__ = "ngcommunordre"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_ngcommunordre", "couser", "cohost"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    couser = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    coticket = db.Column(db.String(30), nullable=False)
    coindex = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cocfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    coplacenego = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    comarchenego = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cosaisie = db.Column(db.DateTime, nullable=False)
    covalide = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    cobudget = db.Column(db.Numeric(4, 0, asdecimal=False))
    cobudgetlibre = db.Column(db.String(20))
    cocompte = db.Column(db.Numeric(5, 0, asdecimal=False))
    cocomptelibre = db.Column(db.String(20))
    coreglement = db.Column(db.DateTime)
    codatemaj = db.Column(db.DateTime, nullable=False)
    coimprime = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    codateimpression = db.Column(db.DateTime)
    corecup = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    coflag = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    cobook = db.Column(db.Numeric(5, 0, asdecimal=False))
    cohost = db.Column(
        db.Numeric(5, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    cocourtage = db.Column(db.Numeric(8, 4))
    cotypecourtage = db.Column(db.Numeric(2, 0, asdecimal=False))


class Ngcorrespondance(db.Model):
    __tablename__ = "ngcorrespondance"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cosource = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="Type de source"
    )
    couser = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Utilisateur associé"
    )
    cocorresp = db.Column(db.String(10), nullable=False, info="Id correspondant")
    coflag = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False, info="Flag")


class Ngfamille(db.Model):
    __tablename__ = "ngfamille"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    facode = db.Column(db.Numeric(5, 0, asdecimal=False), primary_key=True)
    falibelle = db.Column(db.String(30), nullable=False)
    faflag = db.Column(db.Numeric(1, 0, asdecimal=False))

    typeinstrument = db.relationship(
        "Typeinstrument", secondary="risque.ngfamillecontenu", backref="ngfamilles"
    )
    ngsupervision = db.relationship(
        "Ngsupervision", secondary="risque.ngfamillesup", backref="ngfamilles"
    )


t_ngfamillecontenu = db.Table(
    "ngfamillecontenu",
    db.Column(
        "fccodefamille",
        db.ForeignKey("risque.ngfamille.facode"),
        primary_key=True,
        nullable=False,
    ),
    db.Column(
        "fctypeinstrument",
        db.ForeignKey("exane.typeinstrument.tycode"),
        primary_key=True,
        nullable=False,
    ),
    schema="risque",
)


t_ngfamillesup = db.Table(
    "ngfamillesup",
    db.Column(
        "fscodesupervision",
        db.ForeignKey("risque.ngsupervision.sucode"),
        primary_key=True,
        nullable=False,
    ),
    db.Column(
        "fscodefamille",
        db.ForeignKey("risque.ngfamille.facode"),
        primary_key=True,
        nullable=False,
    ),
    schema="risque",
)


class Ngfonction(db.Model):
    __tablename__ = "ngfonction"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    focode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="Code interne unique"
    )
    fopriorite = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    foid = db.Column(db.String(1), info="Id raccourci")
    fofonction = db.Column(db.String(30), info="Description")
    foflag = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False, info="Flag")


class Nghost(db.Model):
    __tablename__ = "nghost"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    hocode = db.Column(db.Numeric(5, 0, asdecimal=False), primary_key=True)
    holibelle = db.Column(db.String(30), nullable=False)
    hoflag = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    hocodeival = db.Column(db.Numeric(5, 0, asdecimal=False))
    hoplace = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    holibellerti = db.Column(db.String(12))
    honego = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )


class Nglimitesfixing(db.Model):
    __tablename__ = "nglimitesfixing"
    __bind_key__ = "exane_risque"
    __table_args__ = (db.CheckConstraint(" lfsens in ('A','V') "), {"schema": "risque"})

    lfmarche = db.Column(
        db.ForeignKey("exane.marche.macode"), primary_key=True, nullable=False
    )
    lftype = db.Column(
        db.ForeignKey("exane.typeinstrument.tycode"), primary_key=True, nullable=False
    )
    lfsens = db.Column(db.String(1), primary_key=True, nullable=False)
    lflimite = db.Column(
        db.ForeignKey("risque.ngtypelimite.ltcode"),
        nullable=False,
        info="Associie ` la table NGTypeLimite. Permet ditablir le prix de l'ordre (numirique ou code tel ATP/ouv)",
    )
    lfperiode = db.Column(
        db.ForeignKey("risque.ngtypeperiode.prdcode"),
        nullable=False,
        info="Associie ` la table NGTypePeriode. Spicifie l'iventuel valeur ` placer dans le champ period de l'ordre.",
    )
    lfticks = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Nombre de ticks ` ajouter ` la limite (si numirique).",
    )

    ngtypelimite = db.relationship(
        "Ngtypelimite",
        primaryjoin="Nglimitesfixing.lflimite == Ngtypelimite.ltcode",
        backref="nglimitesfixings",
    )
    marche = db.relationship(
        "Marche",
        primaryjoin="Nglimitesfixing.lfmarche == Marche.macode",
        backref="nglimitesfixings",
    )
    ngtypeperiode = db.relationship(
        "Ngtypeperiode",
        primaryjoin="Nglimitesfixing.lfperiode == Ngtypeperiode.prdcode",
        backref="nglimitesfixings",
    )
    typeinstrument = db.relationship(
        "Typeinstrument",
        primaryjoin="Nglimitesfixing.lftype == Typeinstrument.tycode",
        backref="nglimitesfixings",
    )


class Ngmachine(db.Model):
    __tablename__ = "ngmachine"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    macode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Code interne unique"
    )
    mamachine = db.Column(db.String(30), nullable=False, info="Libellé de la machine")
    maflag = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False, info="Flag")


class Ngmarche(db.Model):
    __tablename__ = "ngmarche"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    macode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    malibelle = db.Column(db.String(30))
    malibellerti = db.Column(db.String(30))


class Ngmodule(db.Model):
    __tablename__ = "ngmodule"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    mocode = db.Column(
        db.Numeric(5, 0, asdecimal=False), primary_key=True, info="Code interne unique"
    )
    moidrti = db.Column(db.String(5), nullable=False, info="Libelle RTI")
    monom = db.Column(db.String(60))
    moflag = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Flag",
    )


class Ngoperation(db.Model):
    __tablename__ = "ngoperation"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_ngoperation", "opuser", "ophost"),
        db.Index("idx2_ngoperation", "opdate", "opuser", "ophost"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    opdate = db.Column(db.DateTime, info="date et heure d'éxécution de l'ordre")
    opquantite = db.Column(db.Numeric(10, 0, asdecimal=False), info="quantité éxécutée")
    opcours = db.Column(db.Numeric(18, 5), info="prix brut d'éxécution")
    opcourssj = db.Column(
        db.Numeric(18, 5),
        info="cours du sous-jacent au moment de l'éxécution ( pour les options)",
    )
    opstrategie = db.Column(
        db.String(20), info="stratégie de l'opération: identifiant panier ou option"
    )
    opticket = db.Column(db.String(30), info="identifiant de l'ordre initial passé")
    opdeltat = db.Column(
        db.Numeric(asdecimal=False),
        info="delta titres de l'opération ( pour les options)",
    )
    opbroker = db.Column(db.Numeric(5, 0, asdecimal=False), info="identifiant broker")
    opsens = db.Column(db.String(1), info="Sens de l'opération: 'A'chat ou 'V'ente")
    opstatut = db.Column(
        db.String(1),
        info="statut de l'opération: Exécution, Modification ou Annulation",
    )
    opflag = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        info="statut de l'enregistrement : Nouveau(1), Modifié(2) ou Effacé(3)",
    )
    opuser = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="identifiant user / n° de poste"
    )
    opnumero = db.Column(
        db.String(30),
        info="identifiant de l'éxécution ( numéro unique pour chaque deal sur un sous-jacent donné)",
    )
    opindex = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    ophost = db.Column(
        db.Numeric(5, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    opuserrecup = db.Column(db.Numeric(5, 0, asdecimal=False))
    opbudgetrecup = db.Column(db.Numeric(4, 0, asdecimal=False))


class NgoperationH(db.Model):
    __tablename__ = "ngoperation_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    opdate = db.Column(db.DateTime)
    opquantite = db.Column(db.Numeric(10, 0, asdecimal=False))
    opcours = db.Column(db.Numeric(18, 5))
    opcourssj = db.Column(db.Numeric(18, 5))
    opstrategie = db.Column(db.String(20))
    opticket = db.Column(db.String(30))
    opdeltat = db.Column(db.Numeric(asdecimal=False))
    opbroker = db.Column(db.Numeric(5, 0, asdecimal=False))
    opsens = db.Column(db.String(1))
    opstatut = db.Column(db.String(1))
    opflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    opuser = db.Column(db.Numeric(5, 0, asdecimal=False))
    opnumero = db.Column(db.String(30))
    opindex = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    ophost = db.Column(
        db.Numeric(5, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    opuserrecup = db.Column(db.Numeric(5, 0, asdecimal=False))
    opbudgetrecup = db.Column(db.Numeric(4, 0, asdecimal=False))


class Ngordre(db.Model):
    __tablename__ = "ngordre"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx2_ngordre", "orsaisie", "oruser", "orhost"),
        db.Index("idx3_ngordre", "oruser", "orhost", "ordatetravail"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    orsaisie = db.Column(db.DateTime, info="date et heure de saisie de l'ordre")
    orcodif = db.Column(
        db.String(30), info="code valeur ( mnémonique GL, code Sicovam, code ISIN,...)"
    )
    ortypecodif = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="type de code valeur ( GL, sicovam, Isin,...) cf  EXANE.SOURCE",
    )
    ormarche = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Marché de cotation ( cf EXANE.MARCHE)"
    )
    orquantite = db.Column(db.Numeric(10, 0, asdecimal=False), info="quantité éxécutée")
    orquotite = db.Column(db.Numeric(12, 4), info="Quotité de négociation")
    orcours = db.Column(db.Numeric(18, 5), info="Prix brut d'éxécution moyen")
    orcourtage = db.Column(db.Numeric(8, 4), info="Courtage")
    ortypecourtage = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="Nature du courtage ( taux, montant unitaire, montant global) 'T', 'U' ou 'G'",
    )
    ordev = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="devise de l'opération ( cf EXANE.INSTRUMENT)",
    )
    orvalidite = db.Column(
        db.String(20), info="validité de l'ordre ( Jour, Revoc ou date explicite)"
    )
    orreference = db.Column(db.String(64), info="référence de l'opération")
    orstrategie = db.Column(
        db.String(20), info="stratégie de l'opération: identifiant panier ou option"
    )
    orticket = db.Column(
        db.String(30), index=True, info="identifiant de l'ordre initial passé"
    )
    orbudget = db.Column(
        db.Numeric(4, 0, asdecimal=False), info="identifiant du centre budgétaire"
    )
    orcompte = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="identifiant compte middle"
    )
    orcompteclient = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="identifiant client / compte client"
    )
    orobservations = db.Column(db.String(128))
    orsens = db.Column(db.String(1), info="Sens de l'opération: 'A'chat ou 'V'ente")
    orstatut = db.Column(
        db.String(1),
        info="statut de l'opération: Exécution, Modification ou Annulation",
    )
    ortrader = db.Column(db.Numeric(3, 0, asdecimal=False), info="identifiant trader")
    orflag = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        info="statut de l'enregistrement : Nouveau(1), Modifié(2) ou Effacé(3)",
    )
    oruser = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="identifiant user / n° de poste"
    )
    orreglement = db.Column(db.DateTime)
    orbudgetlibre = db.Column(db.String(20))
    orcomptelibre = db.Column(db.String(20))
    orimprime = db.Column(db.Numeric(1, 0, asdecimal=False))
    orvalide = db.Column(db.Numeric(1, 0, asdecimal=False))
    ordepouille = db.Column(db.Numeric(1, 0, asdecimal=False))
    orindex = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    ordateimpression = db.Column(db.DateTime)
    orplace = db.Column(db.Numeric(3, 0, asdecimal=False))
    ordatemaj = db.Column(db.DateTime)
    orrecup = db.Column(db.Numeric(5, 0, asdecimal=False))
    orbook = db.Column(db.Numeric(5, 0, asdecimal=False))
    orhost = db.Column(
        db.Numeric(5, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    orcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    ormodule = db.Column(db.String(4))
    ordatetravail = db.Column(db.DateTime)
    ordatevaleur = db.Column(db.DateTime)
    orsupervision = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    ortypequantite = db.Column(db.String(1))


class NgordreH(db.Model):
    __tablename__ = "ngordre_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    orsaisie = db.Column(db.DateTime)
    orcodif = db.Column(db.String(30))
    ortypecodif = db.Column(db.Numeric(3, 0, asdecimal=False))
    ormarche = db.Column(db.Numeric(3, 0, asdecimal=False))
    orquantite = db.Column(db.Numeric(10, 0, asdecimal=False))
    orquotite = db.Column(db.Numeric(12, 4))
    orcours = db.Column(db.Numeric(18, 5))
    orcourtage = db.Column(db.Numeric(8, 4))
    ortypecourtage = db.Column(db.Numeric(3, 0, asdecimal=False))
    ordev = db.Column(db.Numeric(8, 0, asdecimal=False))
    orvalidite = db.Column(db.String(20))
    orreference = db.Column(db.String(64))
    orstrategie = db.Column(db.String(20))
    orticket = db.Column(db.String(30))
    orbudget = db.Column(db.Numeric(4, 0, asdecimal=False))
    orcompte = db.Column(db.Numeric(5, 0, asdecimal=False))
    orcompteclient = db.Column(db.Numeric(5, 0, asdecimal=False))
    orobservations = db.Column(db.String(128))
    orsens = db.Column(db.String(1))
    orstatut = db.Column(db.String(1))
    ortrader = db.Column(db.Numeric(3, 0, asdecimal=False))
    orflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    oruser = db.Column(db.Numeric(5, 0, asdecimal=False))
    orreglement = db.Column(db.DateTime)
    orbudgetlibre = db.Column(db.String(20))
    orcomptelibre = db.Column(db.String(20))
    orimprime = db.Column(db.Numeric(1, 0, asdecimal=False))
    orvalide = db.Column(db.Numeric(1, 0, asdecimal=False))
    ordepouille = db.Column(db.Numeric(1, 0, asdecimal=False))
    orindex = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    ordateimpression = db.Column(db.DateTime)
    orplace = db.Column(db.Numeric(3, 0, asdecimal=False))
    ordatemaj = db.Column(db.DateTime)
    orrecup = db.Column(db.Numeric(5, 0, asdecimal=False))
    orbook = db.Column(db.Numeric(5, 0, asdecimal=False))
    orhost = db.Column(
        db.Numeric(5, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    orcfin = db.Column(db.Numeric(8, 0, asdecimal=False), index=True)
    ormodule = db.Column(db.String(4))
    ordatetravail = db.Column(db.DateTime)
    ordatevaleur = db.Column(db.DateTime)
    orsupervision = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    ortypequantite = db.Column(db.String(1))


class Ngordresec(db.Model):
    __tablename__ = "ngordresec"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_ngordresec", "osuser", "oshost"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    osuser = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    osticket = db.Column(db.String(30), nullable=False)
    osindex = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    ossens = db.Column(db.String(1), nullable=False)
    osquantite = db.Column(db.Numeric(10, 0, asdecimal=False), nullable=False)
    ostypecours = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    oscours = db.Column(db.Numeric(18, 5))
    ostypevalidite = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    osvalidite = db.Column(db.DateTime)
    ostypecourtage = db.Column(db.Numeric(3, 0, asdecimal=False))
    oscourtage = db.Column(db.Numeric(8, 4))
    osreference = db.Column(db.String(64), nullable=False)
    osstrategie = db.Column(db.String(20))
    osdate = db.Column(db.DateTime)
    osflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    oshost = db.Column(
        db.Numeric(5, 0, asdecimal=False), server_default=db.FetchedValue()
    )


class Ngrddp(db.Model):
    __tablename__ = "ngrddp"
    __bind_key__ = "exane_risque"
    __table_args__ = (db.Index("idx1_ngrddp", "rduser", "rdhost"), {"schema": "risque"})

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rduser = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    rdticket = db.Column(db.String(30), nullable=False)
    rdindex = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    rdquantitea = db.Column(db.Numeric(10, 0, asdecimal=False), nullable=False)
    rdquantitev = db.Column(db.Numeric(10, 0, asdecimal=False), nullable=False)
    rdcoursa = db.Column(db.Numeric(18, 5), nullable=False)
    rdcoursv = db.Column(db.Numeric(18, 5), nullable=False)
    rdtypecourtagea = db.Column(db.Numeric(3, 0, asdecimal=False))
    rdtypecourtagev = db.Column(db.Numeric(3, 0, asdecimal=False))
    rdcourtagea = db.Column(db.Numeric(8, 4))
    rdcourtagev = db.Column(db.Numeric(8, 4))
    rdtyperddp = db.Column(db.String(1))
    rdflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    rddate = db.Column(db.DateTime)
    rdhost = db.Column(
        db.Numeric(5, 0, asdecimal=False), server_default=db.FetchedValue()
    )


class Ngreglecodif(db.Model):
    __tablename__ = "ngreglecodif"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rgcode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    rgmarche = db.Column(db.ForeignKey("risque.ngmarche.macode"))
    rgplace = db.Column(db.Numeric(8, 0, asdecimal=False))
    rgsource = db.Column(db.Numeric(3, 0, asdecimal=False))
    rgordre = db.Column(db.Numeric(4, 0, asdecimal=False))
    rgflag = db.Column(db.Numeric(1, 0, asdecimal=False))

    ngmarche = db.relationship(
        "Ngmarche",
        primaryjoin="Ngreglecodif.rgmarche == Ngmarche.macode",
        backref="ngreglecodifs",
    )


class Ngsdb(db.Model):
    __tablename__ = "ngsdb"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    sdcode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Le code numerique correspondant a la societe de bourse ( ie 059 pour Exane)",
    )
    sdnom = db.Column(
        db.String(64),
        server_default=db.FetchedValue(),
        info="Le libelle associe au code societe de bourse",
    )


class Ngservice(db.Model):
    __tablename__ = "ngservice"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    svcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    svid = db.Column(db.String(12))
    svnom = db.Column(db.String(60))
    svflag = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )


class Ngsource(db.Model):
    __tablename__ = "ngsource"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    socode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="Code interne unique"
    )
    solibelle = db.Column(db.String(30), nullable=False, info="Libelle de la source")
    sonego = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        info="Negociable (1) ou non (0)",
    )
    soflag = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False, info="Flag")


class Ngsupervision(db.Model):
    __tablename__ = "ngsupervision"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("SUDEFHOST IN (0,1)"),
        db.Index("ix2_ngsupervision", "sufonction", "suuser", "suhost"),
        {"schema": "risque"},
    )

    sucode = db.Column(db.Numeric(5, 0, asdecimal=False), primary_key=True)
    sumachine = db.Column(db.String(30), nullable=False)
    suuser = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    suhost = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    suidsrti = db.Column(db.String(60), nullable=False)
    susauvegarde = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    suignore = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    suconfirm = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    suflag = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    sumajbdauto = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    suinsertionauto = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    sumodification = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    susource = db.Column(
        db.ForeignKey("risque.ngsource.socode"),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    sucodemachine = db.Column(
        db.ForeignKey("risque.ngmachine.macode"),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    suutilisateur = db.Column(
        db.ForeignKey("risque.ngutilisateur.utcode"),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    sufonction = db.Column(
        db.ForeignKey("risque.ngfonction.focode"),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    sudefhost = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )

    ngmachine = db.relationship(
        "Ngmachine",
        primaryjoin="Ngsupervision.sucodemachine == Ngmachine.macode",
        backref="ngsupervisions",
    )
    ngfonction = db.relationship(
        "Ngfonction",
        primaryjoin="Ngsupervision.sufonction == Ngfonction.focode",
        backref="ngsupervisions",
    )
    ngsource = db.relationship(
        "Ngsource",
        primaryjoin="Ngsupervision.susource == Ngsource.socode",
        backref="ngsupervisions",
    )
    ngutilisateur = db.relationship(
        "Ngutilisateur",
        primaryjoin="Ngsupervision.suutilisateur == Ngutilisateur.utcode",
        backref="ngsupervisions",
    )


class Ngtypecourtage(db.Model):
    __tablename__ = "ngtypecourtage"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tccode = db.Column(db.Numeric(3, 0, asdecimal=False))
    tclibelle = db.Column(db.String(40))
    tcflag = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        info="statut de l'enregistrement : Nouveau(1), Modifié(2) ou Effacé(3)",
    )


class Ngtypelimite(db.Model):
    __tablename__ = "ngtypelimite"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    ltcode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code d'origine arbitraire; servira de base aux futurs diveloppements (un enum sera associi)",
    )
    ltnom = db.Column(db.String(20), nullable=False)


class Ngtypeperiode(db.Model):
    __tablename__ = "ngtypeperiode"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    prdcode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code correspondant ` l'enum RTIperiod de RTIAPI (API de nigo temps riel)",
    )
    prdrtinom = db.Column(db.String(20), info="Nom des enum correspondants")


class Ngutilisateur(db.Model):
    __tablename__ = "ngutilisateur"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    utcode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Code interne unique"
    )
    utnom = db.Column(db.String(30), nullable=False, info="Nom")
    utprenom = db.Column(db.String(30), nullable=False, info="Prenom")
    utservice = db.Column(
        db.ForeignKey("risque.ngservice.svcode"), info="Reference NGSERVICE"
    )
    utfonction = db.Column(
        db.ForeignKey("risque.ngfonction.focode"), info="Reference NGFONCTION"
    )
    utflag = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False, info="Flag")

    ngfonction = db.relationship(
        "Ngfonction",
        primaryjoin="Ngutilisateur.utfonction == Ngfonction.focode",
        backref="ngutilisateurs",
    )
    ngservice = db.relationship(
        "Ngservice",
        primaryjoin="Ngutilisateur.utservice == Ngservice.svcode",
        backref="ngutilisateurs",
    )


class Prnappevoldiscrete(db.Model):
    __tablename__ = "prnappevoldiscrete"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    vdnappe = db.Column(
        db.ForeignKey("risque.prprofvolat.pvnappe", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
    )
    vdmaturite = db.Column(db.DateTime, primary_key=True, nullable=False)
    vdstrike = db.Column(db.Numeric(18, 5), primary_key=True, nullable=False)
    vdvol = db.Column(db.Numeric(10, 5))
    vdmodifie = db.Column(db.Numeric(3, 0, asdecimal=False))
    vdmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    vdflag = db.Column(db.Numeric(3, 0, asdecimal=False))

    prprofvolat = db.relationship(
        "Prprofvolat",
        primaryjoin="Prnappevoldiscrete.vdnappe == Prprofvolat.pvnappe",
        backref="prnappevoldiscretes",
    )


class PrnappevoldiscreteH(db.Model):
    __tablename__ = "prnappevoldiscrete_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx_prnappevoldisc_h_horo_nap", "vhdnappe", "vhdhorodate"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vhdnappe = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vhdmaturite = db.Column(db.DateTime, nullable=False)
    vhdstrike = db.Column(db.Numeric(18, 5), nullable=False)
    vhdvol = db.Column(db.Numeric(10, 5))
    vhdmodifie = db.Column(db.Numeric(3, 0, asdecimal=False))
    vhdmaj = db.Column(db.DateTime)
    vhdflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    vhdhorodate = db.Column(db.DateTime, nullable=False)
    vhduser = db.Column(db.String(60))
    vhdtrait = db.Column(db.String(1))


class Prnappevolgeneration(db.Model):
    __tablename__ = "prnappevolgeneration"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    vgnappe = db.Column(
        db.ForeignKey("risque.prprofvolat.pvnappe", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
    )
    vgmaturite = db.Column(db.DateTime, primary_key=True, nullable=False)
    vgpivot = db.Column(db.Numeric(18, 5))
    vgvolpivot = db.Column(db.Numeric(18, 5))
    vgpente = db.Column(db.Numeric(18, 5))
    vgcourbure = db.Column(db.Numeric(18, 5))
    vgvolmini = db.Column(db.Numeric(18, 5))
    vgvolmaxi = db.Column(db.Numeric(18, 5))
    vgmodifie = db.Column(db.Numeric(3, 0, asdecimal=False))
    vgmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    vgflag = db.Column(db.Numeric(3, 0, asdecimal=False))

    prprofvolat = db.relationship(
        "Prprofvolat",
        primaryjoin="Prnappevolgeneration.vgnappe == Prprofvolat.pvnappe",
        backref="prnappevolgenerations",
    )


class PrnappevolgenerationH(db.Model):
    __tablename__ = "prnappevolgeneration_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx_prnappegen_h_castor", "vhgnappe", "vhgmaturite", "vhghorodate"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vhgnappe = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vhgmaturite = db.Column(db.DateTime, nullable=False)
    vhgpivot = db.Column(db.Numeric(18, 5))
    vhgvolpivot = db.Column(db.Numeric(10, 5))
    vhgpente = db.Column(db.Numeric(18, 5))
    vhgcourbure = db.Column(db.Numeric(18, 5))
    vhgvolmini = db.Column(db.Numeric(10, 5))
    vhgvolmaxi = db.Column(db.Numeric(10, 5))
    vhgmodifie = db.Column(db.Numeric(3, 0, asdecimal=False))
    vhgmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    vhgflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    vhghorodate = db.Column(
        db.DateTime, nullable=False, index=True, server_default=db.FetchedValue()
    )
    vhguser = db.Column(db.String(60))
    vhgtrait = db.Column(db.String(1))


class PrnappevolparametreH(db.Model):
    __tablename__ = "prnappevolparametre_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx_prnappevolparam_h", "vhpnappe", "vhphorodate"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vhpnappe = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vhpvolinf = db.Column(db.Numeric(10, 5))
    vhpvolct = db.Column(db.Numeric(10, 5))
    vhppenteinf = db.Column(db.Numeric(18, 5))
    vhppentect = db.Column(db.Numeric(18, 5))
    vhpmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    vhpflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    vhphorodate = db.Column(db.DateTime)
    vhpuser = db.Column(db.String(60))
    vhptrait = db.Column(db.String(1))
    vhpcourbeinf = db.Column(db.Numeric(8, 3))
    vhpcourbecrtterme = db.Column(db.Numeric(8, 3))
    vhpfreezedays = db.Column(db.Numeric(8, 0, asdecimal=False))


class Prprofaccdiv(db.Model):
    __tablename__ = "prprofaccdiv"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    paprofil = db.Column(
        db.ForeignKey("risque.prprofil.pprofil", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
    )
    pacfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    paaccdiv = db.Column(db.Numeric(18, 5))
    pamaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    paflag = db.Column(db.Numeric(3, 0, asdecimal=False))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Prprofaccdiv.pacfin == Instrument.ifcfin",
        backref="prprofaccdivs",
    )
    prprofil = db.relationship(
        "Prprofil",
        primaryjoin="Prprofaccdiv.paprofil == Prprofil.pprofil",
        backref="prprofaccdivs",
    )


class PrprofaccdivH(db.Model):
    __tablename__ = "prprofaccdiv_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx_prprofaccdiv_h_castor", "phaprofil", "phacfin", "phahorodate"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phaprofil = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    phacfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    phaaccdiv = db.Column(db.Numeric(18, 5))
    phamaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    phaflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    phahorodate = db.Column(db.DateTime, index=True)
    phauser = db.Column(db.String(60))
    phatrait = db.Column(db.String(1))


class Prprofbigbook(db.Model):
    __tablename__ = "prprofbigbook"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    pbbbigbook = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    pbbprofil = db.Column(db.ForeignKey("risque.prprofil.pprofil", ondelete="CASCADE"))

    prprofil = db.relationship(
        "Prprofil",
        primaryjoin="Prprofbigbook.pbbprofil == Prprofil.pprofil",
        backref="prprofbigbooks",
    )


class PrprofbigbookH(db.Model):
    __tablename__ = "prprofbigbook_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx_prprofbigbook_h", "phbbbigbook", "phbbprofil", "phbbhorodate"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phbbbigbook = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    phbbprofil = db.Column(db.Numeric(8, 0, asdecimal=False))
    phbbhorodate = db.Column(db.DateTime)
    phbbuser = db.Column(db.String(60))
    phbbtrait = db.Column(db.String(1))


class Prprofbump(db.Model):
    __tablename__ = "prprofbump"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    bvprofil = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Profil"
    )
    bvcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Identifiant du sous jacent",
    )
    bvmaturity = db.Column(db.DateTime, nullable=False, info="Date de maturite")
    bvvalue = db.Column(db.Numeric(18, 5), info="Valeur de Bump")
    bvmaj = db.Column(db.DateTime, nullable=False, info="Date d insertion")
    bvflag = db.Column(db.Numeric(3, 0, asdecimal=False), info="Flag")


class PrprofbumpH(db.Model):
    __tablename__ = "prprofbump_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    bvhprofil = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Profil"
    )
    bvhcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Identifiant du sous-jacent",
    )
    bvhmaturity = db.Column(db.DateTime, nullable=False, info="Date de maturite")
    bvhvalue = db.Column(db.Numeric(18, 5), info="Valeur de Bump")
    bvhmaj = db.Column(db.DateTime, nullable=False, info="Date de mise a jour")
    bvhflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    bvhhorodate = db.Column(db.DateTime)
    bvhuser = db.Column(db.String(60), info="utilisateur")
    bvhtrait = db.Column(db.String(1))


class Prprofcorrelation(db.Model):
    __tablename__ = "prprofcorrelation"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    pcprofil = db.Column(
        db.ForeignKey("risque.prprofil.pprofil", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
    )
    pccfin1 = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    pccfin2 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    pcvaleur = db.Column(db.Numeric(18, 5))
    pcmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    pcflag = db.Column(db.Numeric(3, 0, asdecimal=False))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Prprofcorrelation.pccfin1 == Instrument.ifcfin",
        backref="instrument_prprofcorrelations",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Prprofcorrelation.pccfin2 == Instrument.ifcfin",
        backref="instrument_prprofcorrelations_0",
    )
    prprofil = db.relationship(
        "Prprofil",
        primaryjoin="Prprofcorrelation.pcprofil == Prprofil.pprofil",
        backref="prprofcorrelations",
    )


class PrprofcorrelationH(db.Model):
    __tablename__ = "prprofcorrelation_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "idx_prprofcorrel_h", "phcprofil", "phcflag", "phchorodate", "phctrait"
        ),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phcprofil = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    phccfin1 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    phccfin2 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    phcvaleur = db.Column(db.Numeric(18, 5))
    phcmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    phcflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    phchorodate = db.Column(db.DateTime)
    phcuser = db.Column(db.String(60))
    phctrait = db.Column(db.String(1))


class Prprofdivyieldratio(db.Model):
    __tablename__ = "prprofdivyieldratio"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint(
            "(PRDATE Is Null OR PRDATEOFFSET IS Null) AND NOT (PRDATE Is  Null AND PRDATEOFFSET IS  Null)"
        ),
        db.CheckConstraint(
            "(PRDATE Is Null OR PRDATEOFFSET IS Null) AND NOT (PRDATE Is  Null AND PRDATEOFFSET IS  Null)"
        ),
        db.Index(
            "uk_prprofdivyieldratio", "prprofil", "prcfin", "prdate", "prdateoffset"
        ),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    prprofil = db.Column(db.ForeignKey("risque.prprofil.pprofil"), info="Profil")
    prcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        index=True,
        info="Instrument financier",
    )
    prdate = db.Column(db.DateTime, info="Date à laquelle appliquer le ratio")
    prratio = db.Column(
        db.Numeric(5, 4), nullable=False, info="Ratio à appliquer au spot de référence."
    )
    prflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    prdateoffset = db.Column(
        db.ForeignKey("exane.maturite.mtcode"),
        info="Date en format offset Ã\xa0 laquelle appliquer le ratio",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Prprofdivyieldratio.prcfin == Instrument.ifcfin",
        backref="prprofdivyieldratios",
    )
    maturite = db.relationship(
        "Maturite",
        primaryjoin="Prprofdivyieldratio.prdateoffset == Maturite.mtcode",
        backref="prprofdivyieldratios",
    )
    prprofil1 = db.relationship(
        "Prprofil",
        primaryjoin="Prprofdivyieldratio.prprofil == Prprofil.pprofil",
        backref="prprofdivyieldratios",
    )


class PrprofdivyieldratioH(db.Model):
    __tablename__ = "prprofdivyieldratio_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phrdatehisto = db.Column(
        db.DateTime, nullable=False, index=True, info="Date de valeur de l'historique"
    )
    phrprofil = db.Column(db.Numeric(8, 0, asdecimal=False), index=True, info="Profil")
    phrcfin = db.Column(db.Numeric(8, 0, asdecimal=False), info="Instrument financier")
    phrdate = db.Column(db.DateTime, info="Date à laquelle appliquer le ratio")
    phrratio = db.Column(
        db.Numeric(5, 4), nullable=False, info="Ratio à appliquer au spot de référence."
    )
    phrdateoffset = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="Date en format offset Ã\xa0 laquelle appliquer le ratio",
    )


class Prprofdivyieldspotref(db.Model):
    __tablename__ = "prprofdivyieldspotref"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("PSYIELDRATIOTYPE IN ('D', 'O')"),
        {"schema": "risque"},
    )

    psprofil = db.Column(
        db.ForeignKey("risque.prprofil.pprofil"),
        primary_key=True,
        nullable=False,
        info="Profil",
    )
    pscfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Instrument financier",
    )
    psspotref = db.Column(
        db.Numeric(13, 5),
        nullable=False,
        info="Spot de référence pour le CFIN et le profil",
    )
    psflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    psyieldratiotype = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Type de divyield: yield div format offset ou yield div format date",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Prprofdivyieldspotref.pscfin == Instrument.ifcfin",
        backref="prprofdivyieldspotrefs",
    )
    prprofil = db.relationship(
        "Prprofil",
        primaryjoin="Prprofdivyieldspotref.psprofil == Prprofil.pprofil",
        backref="prprofdivyieldspotrefs",
    )


class PrprofdivyieldspotrefH(db.Model):
    __tablename__ = "prprofdivyieldspotref_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phsdatehisto = db.Column(
        db.DateTime, nullable=False, index=True, info="Date de valeur de l'historique"
    )
    phsprofil = db.Column(db.Numeric(8, 0, asdecimal=False), index=True, info="Profil")
    phscfin = db.Column(db.Numeric(8, 0, asdecimal=False), info="Instrument financier")
    phsspotref = db.Column(
        db.Numeric(13, 5),
        nullable=False,
        info="Spot de référence pour le CFIN et le profil",
    )
    phsyieldratiotype = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Type de divyield: yield div format offset ou yield div format date",
    )


class Prprofil(db.Model):
    __tablename__ = "prprofil"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("PREFERENCE = 0 or PREFERENCE = 1"),
        db.CheckConstraint("PREFERENCE = 0 or PREFERENCE = 1"),
        {"schema": "risque"},
    )

    pprofil = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    pgroupe = db.Column(db.Numeric(8, 0, asdecimal=False))
    pnom = db.Column(db.String(60))
    preference = db.Column(
        db.Numeric(asdecimal=False), nullable=False, server_default=db.FetchedValue()
    )
    psnapshot = db.Column(
        db.Enum("N", "O"),
        server_default=db.FetchedValue(),
        info="Le profil effectue un cliché des nappes chaque jours (ex : 1004,1001,1002).",
    )


class PrprofilH(db.Model):
    __tablename__ = "prprofil_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx_prprofil_h", "phprofil", "phgroupe", "phhorodate"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phprofil = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    phgroupe = db.Column(db.Numeric(8, 0, asdecimal=False))
    phnom = db.Column(db.String(60))
    phhorodate = db.Column(db.DateTime)
    phuser = db.Column(db.String(60))
    phtrait = db.Column(db.String(1))


class Prprofintensdefaut(db.Model):
    __tablename__ = "prprofintensdefaut"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    pidprofil = db.Column(
        db.ForeignKey("risque.prprofil.pprofil", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
    )
    pidcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    pidmaturite = db.Column(db.DateTime, primary_key=True, nullable=False)
    pidintdefinf = db.Column(db.Numeric(18, 5))
    pidintdefcurve = db.Column(db.Numeric(18, 5))
    pidintdefpump = db.Column(db.Numeric(18, 5))
    pidmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    pidflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    pidseniorite = db.Column(
        db.ForeignKey("exane.typeseniorite.tscode"),
        primary_key=True,
        nullable=False,
        server_default=db.FetchedValue(),
        info="Seniorite a prendre en compte (EXANE.TYPESENIORITE)",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Prprofintensdefaut.pidcfin == Instrument.ifcfin",
        backref="prprofintensdefauts",
    )
    prprofil = db.relationship(
        "Prprofil",
        primaryjoin="Prprofintensdefaut.pidprofil == Prprofil.pprofil",
        backref="prprofintensdefauts",
    )
    typeseniorite = db.relationship(
        "Typeseniorite",
        primaryjoin="Prprofintensdefaut.pidseniorite == Typeseniorite.tscode",
        backref="prprofintensdefauts",
    )


class PrprofintensdefautH(db.Model):
    __tablename__ = "prprofintensdefaut_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "idx_prprofintdefaut_h",
            "phidprofil",
            "phidcfin",
            "phidflag",
            "phihorodate",
            "phitrait",
        ),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phidprofil = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    phidcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    phidmaturite = db.Column(db.DateTime, nullable=False)
    phidintdefinf = db.Column(db.Numeric(18, 5))
    phidintdefcurve = db.Column(db.Numeric(18, 5))
    phidintdefpump = db.Column(db.Numeric(18, 5))
    phidmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    phidflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    phihorodate = db.Column(db.DateTime)
    phiuser = db.Column(db.String(60))
    phitrait = db.Column(db.String(1))
    phidseniorite = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Seniorite a prendre en compte (EXANE.TYPESENIORITE) initie a 1 par defaut",
    )


class Prprofmargerepo(db.Model):
    __tablename__ = "prprofmargerepo"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    pmprofil = db.Column(
        db.ForeignKey("risque.prprofil.pprofil", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
    )
    pmcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    pmecheance = db.Column(db.DateTime, primary_key=True, nullable=False)
    pmmarge = db.Column(db.Numeric(18, 5))
    pmmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    pmflag = db.Column(db.Numeric(3, 0, asdecimal=False))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Prprofmargerepo.pmcfin == Instrument.ifcfin",
        backref="prprofmargerepoes",
    )
    prprofil = db.relationship(
        "Prprofil",
        primaryjoin="Prprofmargerepo.pmprofil == Prprofil.pprofil",
        backref="prprofmargerepoes",
    )


class PrprofmargerepoH(db.Model):
    __tablename__ = "prprofmargerepo_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "idx_prprofmargerepo_h",
            "phmprofil",
            "phmcfin",
            "phmecheance",
            "phmhorodate",
        ),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phmprofil = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    phmcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    phmecheance = db.Column(db.DateTime, nullable=False)
    phmmarge = db.Column(db.Numeric(18, 5))
    phmmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    phmflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    phmhorodate = db.Column(db.DateTime)
    phmuser = db.Column(db.String(60))
    phmtrait = db.Column(db.String(1))


class Prprofrefmultisjac(db.Model):
    __tablename__ = "prprofrefmultisjac"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    prmprofil = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    prmcfin1 = db.Column(db.Numeric(8, 0, asdecimal=False))
    prmcfin2 = db.Column(db.Numeric(8, 0, asdecimal=False))
    prmpcorrelvol = db.Column(db.Numeric(8, 0, asdecimal=False))
    prmtypeprofref = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="Type de données"
    )
    prmmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    prmflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class PrprofrefmultisjacH(db.Model):
    __tablename__ = "prprofrefmultisjac_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "idx_prprofrefmultisjac_h",
            "phrmprofil",
            "phrmcfin1",
            "phrmcfin2",
            "phrmhorodate",
        ),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phrmprofil = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    phrmcfin1 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    phrmcfin2 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    phrmpcorrel = db.Column(db.Numeric(8, 0, asdecimal=False))
    phrmmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    phrmflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    phrmhorodate = db.Column(db.DateTime)
    phrmuser = db.Column(db.String(60))
    phrmtrait = db.Column(db.String(1))


class Prprofrefsjac(db.Model):
    __tablename__ = "prprofrefsjac"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    prprofil = db.Column(
        db.ForeignKey("risque.prprofil.pprofil"), primary_key=True, nullable=False
    )
    prcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    prrepo = db.Column(db.Numeric(8, 0, asdecimal=False))
    prvol = db.Column(db.Numeric(8, 0, asdecimal=False))
    praccdiv = db.Column(db.Numeric(8, 0, asdecimal=False))
    prtauxreco = db.Column(db.Numeric(8, 0, asdecimal=False))
    prspread = db.Column(db.Numeric(8, 0, asdecimal=False))
    printensdefaut = db.Column(db.Numeric(8, 0, asdecimal=False))
    prmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    prflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    prdivtaux = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Profil à utiliser pour les dividendes en taux.",
    )
    prbump = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Profil à utiliser pour les bump VarSwap.",
    )

    prprofil1 = db.relationship(
        "Prprofil",
        primaryjoin="Prprofrefsjac.praccdiv == Prprofil.pprofil",
        backref="prprofil_prprofil_prprofil_prprofil_prprofil_prprofil_prprofrefsjacs",
    )
    instrument = db.relationship(
        "Instrument",
        primaryjoin="Prprofrefsjac.prcfin == Instrument.ifcfin",
        backref="prprofrefsjacs",
    )
    prprofil2 = db.relationship(
        "Prprofil",
        primaryjoin="Prprofrefsjac.printensdefaut == Prprofil.pprofil",
        backref="prprofil_prprofil_prprofil_prprofil_prprofil_prprofil_prprofrefsjacs_0",
    )
    prprofil3 = db.relationship(
        "Prprofil",
        primaryjoin="Prprofrefsjac.prprofil == Prprofil.pprofil",
        backref="prprofil_prprofil_prprofil_prprofil_prprofil_prprofil_prprofrefsjacs",
    )
    prprofil4 = db.relationship(
        "Prprofil",
        primaryjoin="Prprofrefsjac.prrepo == Prprofil.pprofil",
        backref="prprofil_prprofil_prprofil_prprofil_prprofil_prprofil_prprofrefsjacs_0",
    )
    prprofil5 = db.relationship(
        "Prprofil",
        primaryjoin="Prprofrefsjac.prspread == Prprofil.pprofil",
        backref="prprofil_prprofil_prprofil_prprofil_prprofil_prprofil_prprofrefsjacs",
    )
    prprofil6 = db.relationship(
        "Prprofil",
        primaryjoin="Prprofrefsjac.prtauxreco == Prprofil.pprofil",
        backref="prprofil_prprofil_prprofil_prprofil_prprofil_prprofil_prprofrefsjacs_0",
    )
    prprofil7 = db.relationship(
        "Prprofil",
        primaryjoin="Prprofrefsjac.prvol == Prprofil.pprofil",
        backref="prprofil_prprofil_prprofil_prprofil_prprofil_prprofil_prprofrefsjacs",
    )


class PrprofrefsjacH(db.Model):
    __tablename__ = "prprofrefsjac_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx_prprofrefsjac_h", "phrprofil", "phrcfin", "phrhorodate"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phrprofil = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    phrcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    phrrepo = db.Column(db.Numeric(8, 0, asdecimal=False))
    phrvol = db.Column(db.Numeric(8, 0, asdecimal=False))
    phraccdiv = db.Column(db.Numeric(8, 0, asdecimal=False))
    phrtauxreco = db.Column(db.Numeric(8, 0, asdecimal=False))
    phrspread = db.Column(db.Numeric(8, 0, asdecimal=False))
    phrintensdefaut = db.Column(db.Numeric(8, 0, asdecimal=False))
    phrmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    phrflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    phrhorodate = db.Column(
        db.DateTime, nullable=False, server_default=db.FetchedValue()
    )
    phruser = db.Column(db.String(60))
    phrspot = db.Column(db.Numeric(13, 5))
    phrvolchange = db.Column(db.Numeric(8, 0, asdecimal=False))
    phrtrait = db.Column(db.String(1))
    phrbump = db.Column(db.Numeric(8, 0, asdecimal=False))


class Prprofspread(db.Model):
    __tablename__ = "prprofspread"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    psprofil = db.Column(
        db.ForeignKey("risque.prprofil.pprofil", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
    )
    pscfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    psmaturite = db.Column(db.DateTime, primary_key=True, nullable=False)
    psspread = db.Column(db.Numeric(18, 5))
    psmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    psflag = db.Column(db.Numeric(3, 0, asdecimal=False))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Prprofspread.pscfin == Instrument.ifcfin",
        backref="prprofspreads",
    )
    prprofil = db.relationship(
        "Prprofil",
        primaryjoin="Prprofspread.psprofil == Prprofil.pprofil",
        backref="prprofspreads",
    )


class PrprofspreadH(db.Model):
    __tablename__ = "prprofspread_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "idx_prprofspread_h_castor",
            "phscfin",
            "phsprofil",
            "phsmaturite",
            "phshorodate",
        ),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phsprofil = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    phscfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    phsmaturite = db.Column(db.DateTime, nullable=False)
    phsspread = db.Column(db.Numeric(18, 5))
    phsmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    phsflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    phshorodate = db.Column(db.DateTime, index=True)
    phsuser = db.Column(db.String(60))
    phstrait = db.Column(db.String(1))


class Prproftauxreco(db.Model):
    __tablename__ = "prproftauxreco"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    ptprofil = db.Column(
        db.ForeignKey("risque.prprofil.pprofil", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
    )
    ptcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    ptseniorite = db.Column(
        db.ForeignKey("exane.typeseniorite.tscode", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
    )
    ptvaleur = db.Column(db.Numeric(18, 5))
    ptmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    ptflag = db.Column(db.Numeric(3, 0, asdecimal=False))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Prproftauxreco.ptcfin == Instrument.ifcfin",
        backref="prproftauxrecoes",
    )
    prprofil = db.relationship(
        "Prprofil",
        primaryjoin="Prproftauxreco.ptprofil == Prprofil.pprofil",
        backref="prproftauxrecoes",
    )
    typeseniorite = db.relationship(
        "Typeseniorite",
        primaryjoin="Prproftauxreco.ptseniorite == Typeseniorite.tscode",
        backref="prproftauxrecoes",
    )


class PrproftauxrecoH(db.Model):
    __tablename__ = "prproftauxreco_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "idx_prproftauxreco_h_castor",
            "phtprofil",
            "phtcfin",
            "phtseniorite",
            "phthorodate",
        ),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phtprofil = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    phtcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    phtseniorite = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    phtvaleur = db.Column(db.Numeric(18, 5))
    phtmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    phtflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    phthorodate = db.Column(db.DateTime, index=True)
    phtuser = db.Column(db.String(60))
    phttrait = db.Column(db.String(1))


class Prproftypeparametresjac(db.Model):
    __tablename__ = "prproftypeparametresjac"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    ptidentifiant = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Identifiant du type parametre mono sous jacent",
    )
    ptnom = db.Column(
        db.String(100),
        nullable=False,
        unique=True,
        info="Libellé qui désigne le type paramètre mono sous jacent",
    )
    ptcolnom = db.Column(
        db.String(100),
        nullable=False,
        unique=True,
        info="Nom de la colonne qui représente le type paramètre mono dans la table PRPROFREFMONOSJAC",
    )
    ptnomtable = db.Column(
        db.String(100),
        nullable=False,
        info="Nom de la table qui contient les données pour un type paramètre mono sous jacent",
    )
    ptcolprofil = db.Column(
        db.String(100),
        nullable=False,
        info="Nom de la colonne Profil dans la table des données pour un type paramètre mono sous jacent",
    )
    ptcolcfin = db.Column(
        db.String(100),
        nullable=False,
        info="Nom de la colonne CFIN dans la table des données pour un type paramètre mono sous jacent",
    )
    ptcolflag = db.Column(
        db.String(100),
        nullable=False,
        info="Nom de la colonne FLAG dans la table des données pour un type paramètre mono sous jacent",
    )


class Prprofvolat(db.Model):
    __tablename__ = "prprofvolat"
    __bind_key__ = "exane_risque"
    __table_args__ = (db.Index("unq_nappe", "pvprofil", "pvcfin"), {"schema": "risque"})

    pvnappe = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    pvcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    pvprofil = db.Column(
        db.ForeignKey("risque.prprofil.pprofil", ondelete="CASCADE"), nullable=False
    )
    pvtype = db.Column(
        db.ForeignKey("exane.typevolat.tvcode"), nullable=False, info="Type volatilite"
    )
    pvstatut = db.Column(
        db.ForeignKey("exane.typestatut.tstcode"),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Code du statut d'un instrument financier",
    )
    pvmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    pvflag = db.Column(db.Numeric(3, 0, asdecimal=False))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Prprofvolat.pvcfin == Instrument.ifcfin",
        backref="prprofvolats",
    )
    prprofil = db.relationship(
        "Prprofil",
        primaryjoin="Prprofvolat.pvprofil == Prprofil.pprofil",
        backref="prprofvolats",
    )
    typestatut = db.relationship(
        "Typestatut",
        primaryjoin="Prprofvolat.pvstatut == Typestatut.tstcode",
        backref="prprofvolats",
    )
    typevolat = db.relationship(
        "Typevolat",
        primaryjoin="Prprofvolat.pvtype == Typevolat.tvcode",
        backref="prprofvolats",
    )


class Prnappevolparametre(Prprofvolat):
    __tablename__ = "prnappevolparametre"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    vpnappe = db.Column(
        db.ForeignKey("risque.prprofvolat.pvnappe", ondelete="CASCADE"),
        primary_key=True,
    )
    vpvolinf = db.Column(db.Numeric(18, 5))
    vpvolct = db.Column(db.Numeric(18, 5))
    vppenteinf = db.Column(db.Numeric(18, 5))
    vppentect = db.Column(db.Numeric(18, 5))
    vpmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    vpflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    vpcourbeinf = db.Column(db.Numeric(8, 3), info="Courbe Inférieure")
    vpcourbecrtterme = db.Column(db.Numeric(8, 3), info="Courbe court terme")
    vpfreezedays = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Les coefficients des échéances dont le nb de jours ouvrés est <= à FreezeDays ne sont pas modifiés.",
    )


class PrprofvolatH(db.Model):
    __tablename__ = "prprofvolat_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "idx_prprofvolat_h",
            "phvnappe",
            "phvcfin",
            "phvprofil",
            "phvflag",
            "phvhorodate",
            "phvtrait",
        ),
        db.Index("unq_nappe_h", "phvprofil", "phvcfin"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phvnappe = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    phvcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    phvprofil = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    phvtype = db.Column(
        db.Numeric(2, 0, asdecimal=False), nullable=False, info="Type volatilite"
    )
    phvstatut = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="Code du statut d'un instrument financier",
    )
    phvmaj = db.Column(db.DateTime)
    phvflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    phvhorodate = db.Column(db.DateTime)
    phvuser = db.Column(db.String(60))
    phvtrait = db.Column(db.String(1))


class Prprofvolchange(db.Model):
    __tablename__ = "prprofvolchange"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    pvcprofil = db.Column(
        db.ForeignKey("risque.prprofil.pprofil", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
    )
    pvccfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    pvcvaleur = db.Column(db.Numeric(18, 5))
    pvcmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    pvcflag = db.Column(db.Numeric(3, 0, asdecimal=False))

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Prprofvolchange.pvccfin == Instrument.ifcfin",
        backref="prprofvolchanges",
    )
    prprofil = db.relationship(
        "Prprofil",
        primaryjoin="Prprofvolchange.pvcprofil == Prprofil.pprofil",
        backref="prprofvolchanges",
    )


class PrprofvolchangeH(db.Model):
    __tablename__ = "prprofvolchange_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "idx_prprofvolchange_h",
            "phvcprofil",
            "phvccfin",
            "phvcflag",
            "phvchorodate",
            "phvctrait",
        ),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phvcprofil = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    phvccfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    phvcvaleur = db.Column(db.Numeric(18, 5))
    phvcmaj = db.Column(db.DateTime, server_default=db.FetchedValue())
    phvcflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    phvchorodate = db.Column(db.DateTime)
    phvcuser = db.Column(db.String(60))
    phvctrait = db.Column(db.String(1))


class Prtypeprofref(db.Model):
    __tablename__ = "prtypeprofref"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    tprcode = db.Column(db.Numeric(5, 0, asdecimal=False), primary_key=True)
    tprlibelle = db.Column(db.String(30))


class RapproCompen(db.Model):
    __tablename__ = "rappro_compens"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rcdate = db.Column(db.DateTime)
    rcclasse = db.Column(db.String(8))
    rcecheance = db.Column(db.DateTime)
    rcstrike = db.Column(db.Numeric(15, 4))
    rccontrat = db.Column(db.String(1))
    rctype = db.Column(db.String(1))
    rcquotite = db.Column(db.Numeric(15, 4))
    rccours = db.Column(db.Numeric(15, 2))
    rcmarche = db.Column(db.String(8))
    rcvol = db.Column(db.Numeric(15, 2))


class RapproOpe(db.Model):
    __tablename__ = "rappro_ope"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rodate = db.Column(db.DateTime)
    rocompte = db.Column(db.String(12))
    roclasse = db.Column(db.String(8))
    roecheance = db.Column(db.DateTime)
    rostrike = db.Column(db.Numeric(15, 4))
    rocontrat = db.Column(db.String(1))
    rotype = db.Column(db.String(1))
    ronb_lot = db.Column(db.Numeric(15, 0, asdecimal=False))
    roquotite = db.Column(db.Numeric(15, 4))
    ropremium = db.Column(db.Numeric(15, 2))
    romarche = db.Column(db.String(8))


class RapproPo(db.Model):
    __tablename__ = "rappro_pos"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rpdate = db.Column(db.DateTime)
    rpcompte = db.Column(db.String(12))
    rpclasse = db.Column(db.String(8))
    rplibelle = db.Column(db.String(64))
    rpecheance = db.Column(db.DateTime)
    rpstrike = db.Column(db.Numeric(15, 4))
    rpcontrat = db.Column(db.String(1))
    rptype = db.Column(db.String(1))
    rpachat = db.Column(db.Numeric(15, 0, asdecimal=False))
    rpvente = db.Column(db.Numeric(15, 0, asdecimal=False))
    rpquotite = db.Column(db.Numeric(15, 4))
    rpcours = db.Column(db.Numeric(15, 2))
    rpmarche = db.Column(db.String(8))


class Rdctier(db.Model):
    __tablename__ = "rdctiers"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ctiers = db.Column(db.Numeric(5, 0, asdecimal=False))
    abrtiers = db.Column(db.String(8))
    ltiers = db.Column(db.String(30))
    catrat = db.Column(db.String(2))
    fpn = db.Column(db.Numeric(10, 0, asdecimal=False))
    dmaj = db.Column(db.String(8))
    ctyptie = db.Column(db.String(2))
    cpcrb = db.Column(db.String(4))
    cgroupe = db.Column(db.Numeric(5, 0, asdecimal=False))


class Rkaction(db.Model):
    __tablename__ = "rkaction"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    accfin = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code du produit")
    acdebutex = db.Column(db.DateTime, info="Date de debut d exercice fiscal")
    acfinex = db.Column(db.DateTime, info="Date de fin d exercice fiscal")
    accoefopda = db.Column(
        db.Numeric(8, 3), info="Coefficient risque du montant d OPDA"
    )
    accoefaf = db.Column(
        db.Numeric(8, 3), info="Coefficient risque du montant d avoir fiscal"
    )
    acflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de mise a jour")


class Rkappli(db.Model):
    __tablename__ = "rkappli"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    apcode = db.Column(db.Numeric(3, 0, asdecimal=False))
    aplibelle = db.Column(db.String(32))
    apflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Rkapplisam(db.Model):
    __tablename__ = "rkapplisam"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    ascode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    asnom = db.Column(db.String(30))


class Rkbigbook(db.Model):
    __tablename__ = "rkbigbook"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("BBFINDEJOURNEEAUTO IN ('O','N')"),
        {"schema": "risque"},
    )

    bbbigbook = db.Column(
        db.Numeric(4, 0, asdecimal=False), primary_key=True, info="Code du portefeuille"
    )
    bbnom = db.Column(db.String(30), info="Nom du portefeuille")
    bbdevise = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Devise du portefeuille"
    )
    bbbudget = db.Column(
        db.Numeric(4, 0, asdecimal=False), info="Centre budg. du portef."
    )
    bbdebut = db.Column(db.DateTime, info="Creation du portef.")
    bbfin = db.Column(db.DateTime, info="Fin du portef.")
    bbtravail = db.Column(db.DateTime, info="Journee de travail")
    bbouvert = db.Column(db.DateTime, info="Journee d ouverture")
    bbferme = db.Column(db.DateTime, info="Fin de journee")
    bbstatus = db.Column(db.Numeric(5, 0, asdecimal=False), info="Status du portef.")
    bbflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    bbtype = db.Column(db.Numeric(5, 0, asdecimal=False))
    bbfindejourneeauto = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indicateur de déclenchement de la fin de journée automatique (Geode)",
    )


class RkbigbookH(db.Model):
    __tablename__ = "rkbigbook_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    bbhbigbook = db.Column(db.Numeric(4, 0, asdecimal=False))
    bbhnom = db.Column(db.String(30))
    bbhdevise = db.Column(db.Numeric(8, 0, asdecimal=False))
    bbhbudget = db.Column(db.Numeric(4, 0, asdecimal=False))
    bbhdebut = db.Column(db.DateTime)
    bbhfin = db.Column(db.DateTime)
    bbhtravail = db.Column(db.DateTime)
    bbhouvert = db.Column(db.DateTime)
    bbhferme = db.Column(db.DateTime)
    bbhstatus = db.Column(db.Numeric(5, 0, asdecimal=False))
    bbhflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    bbhtype = db.Column(db.Numeric(5, 0, asdecimal=False))
    bbhorodate = db.Column(
        db.DateTime,
        server_default=db.FetchedValue(),
        info="Date /heure d'historisation",
    )
    bbhuser = db.Column(
        db.String(60),
        info="Identification de l'utilisateur OS qui a engendré la modification",
    )
    bbhtrait = db.Column(db.String(1), info="Type du traitement d'historisation")
    bbhfindejourneeauto = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indicateur de déclenchement de la fin de journée automatique (Geode)",
    )


class RkbigbookRef(db.Model):
    __tablename__ = "rkbigbook_ref"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint(" BBRACTIF IS NOT NULL AND BBRACTIF IN ('O','N') "),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    bbrbigbook = db.Column(
        db.Numeric(4, 0, asdecimal=False), nullable=False, info="Code du portefeuille"
    )
    bbrferme = db.Column(db.DateTime, nullable=False, info="Date du dernier PnL de ref")
    bbractif = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Le big book est pris en compte dans l'evaluation du PNL (O/N).",
    )


class Rkbigbooksam(db.Model):
    __tablename__ = "rkbigbooksam"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    bbsbigbook = db.Column(db.Numeric(4, 0, asdecimal=False), primary_key=True)
    bbsnomcourt = db.Column(db.String(20))
    bbsnomlong = db.Column(db.String(60))
    bbsnomgerant = db.Column(db.String(60))
    bbsprenomgerant = db.Column(db.String(60))
    bbscompfuture = db.Column(db.String(30))
    bbscomptefuture = db.Column(db.String(30))
    bbsdepositaire = db.Column(db.String(30))
    bbscptdepositaire = db.Column(db.String(30))
    bbsoperateurmiddle = db.Column(db.String(40))
    bbstelephonemiddle = db.Column(db.String(30))


class Rkbooktaux(db.Model):
    __tablename__ = "rkbooktaux"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    btbigbook = db.Column(
        db.Numeric(4, 0, asdecimal=False), index=True, info="Code du portefeuille"
    )
    bttcode = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code du taux de reference"
    )
    bttval = db.Column(db.Numeric(8, 4), info="Valeur du taux de reference")
    btdevise = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code de la devise de reference"
    )
    btdval = db.Column(db.Numeric(16, 8), info="Valeur de la devise de reference")
    btflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    btidcourbetaux = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Id de la courbe de taux utilisee lors de la fin de journee",
    )


class RkbooktauxH(db.Model):
    __tablename__ = "rkbooktaux_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    bhbigbook = db.Column(db.Numeric(4, 0, asdecimal=False))
    bhdevise = db.Column(db.Numeric(8, 0, asdecimal=False))
    bhval = db.Column(db.Numeric(16, 8))
    bhdate = db.Column(db.DateTime, index=True)
    bhflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    bhidcourbetaux = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Id de la courbe de taux utilisee lors de la fin de journee",
    )
    bhtypepnl = db.Column(db.String(1))


class RkbooktauxRef(db.Model):
    __tablename__ = "rkbooktaux_ref"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    btrbigbook = db.Column(
        db.Numeric(4, 0, asdecimal=False), nullable=False, info="Code du portefeuille"
    )
    btrdevise = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de la devise de reference",
    )
    btrdval = db.Column(
        db.Numeric(16, 8), nullable=False, info="Valeur de la devise de reference"
    )
    btrflag = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Flag de suppression"
    )


class RkbooktauxRefH(db.Model):
    __tablename__ = "rkbooktaux_ref_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    bhrdate = db.Column(db.DateTime, nullable=False, info="Date")
    bhrbigbook = db.Column(
        db.Numeric(4, 0, asdecimal=False), nullable=False, info="Code du portefeuille"
    )
    bhrdevise = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de la devise de reference",
    )
    bhrdval = db.Column(
        db.Numeric(16, 8), nullable=False, info="Valeur de la devise de reference"
    )
    bhrflag = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Flag de suppression"
    )


class Rkbroker(db.Model):
    __tablename__ = "rkbroker"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    brcode = db.Column(
        db.Numeric(5, 0, asdecimal=False), primary_key=True, nullable=False
    )
    brnumagent = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    brnom = db.Column(db.String(64))
    brflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Rkbrokersam(db.Model):
    __tablename__ = "rkbrokersam"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    bscode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    bsnom = db.Column(db.String(30))
    bsflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class Rkbudget(db.Model):
    __tablename__ = "rkbudget"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    bgbudget = db.Column(db.Numeric(4, 0, asdecimal=False), info="Code Budget")
    bgcodebud = db.Column(db.String(10), info="Mnemonique du centre budgetaire")
    bgnom = db.Column(db.String(15), info="Libelle complet du centre budgetaire")
    bgtype = db.Column(
        db.String(1), info="R (risque) ou V (vente) ou T (tresorerie) ou A (autre)"
    )
    bgfe = db.Column(db.String(1), info="F (france) ou E (etranger)")
    bgflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    bgentite = db.Column(db.Numeric(3, 0, asdecimal=False))
    bgttfiexonere = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Exoneration pour la TTF italienne 1 (oui) / 0 (non)",
    )


class Rkcdlinkrole(db.Model):
    __tablename__ = "rkcdlinkrole"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    lrid = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Identifier of a role of a complex deal in an association",
    )
    lrname = db.Column(
        db.String(20),
        nullable=False,
        info="Label of the role of a complex deal in an association",
    )


class Rkcdlinktype(db.Model):
    __tablename__ = "rkcdlinktype"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    ltid = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Identifier of a complex deal association type",
    )
    ltname = db.Column(
        db.String(20), nullable=False, info="Label of the complex deal association type"
    )


class Rkcertifrisque(db.Model):
    __tablename__ = "rkcertifrisque"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cecfin = db.Column(db.Numeric(8, 0, asdecimal=False), index=True)
    cestrike = db.Column(db.Numeric(10, 2))
    cesjvol = db.Column(db.Numeric(8, 3))
    ceflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    ceupdate = db.Column(db.DateTime)
    cetypestrike = db.Column(db.String(1))
    cehorizon = db.Column(db.Numeric(3, 0, asdecimal=False))


class Rkcfinotc(db.Model):
    __tablename__ = "rkcfinotc"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    otcfin = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)


class Rkcfinsexclu(db.Model):
    __tablename__ = "rkcfinsexclus"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    cecfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Cfin de l'instrument"
    )


class Rkclau(db.Model):
    __tablename__ = "rkclaus"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    clcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Code du produit pour lequel est definie la clause",
    )
    clcallput = db.Column(db.String(1), info="PLUS UTILISE")
    cldebut = db.Column(db.DateTime, info="Date de debut de validite de la clause")
    clfin = db.Column(db.DateTime, info="Date de fin de validite de la clause")
    clrembo = db.Column(db.Numeric(10, 2), info="Montant du remboursement")
    cltrigger = db.Column(db.Numeric(10, 2), info="Seuil d une clause call")
    clcoupon = db.Column(db.String(1), info="boursement avec ou sans coupon couru")
    clmodele = db.Column(db.String(1), info="Modele de clause ( inutilise)")
    clactu = db.Column(db.Numeric(8, 2), info="Actualisation du boursement, call")
    clproba = db.Column(db.Numeric(8, 3), info="Probabilite de rappel, call")
    clcode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Code sequentiel dans la table des clauses",
    )
    cltclause = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Type de clause ( place CLCALLPUT)"
    )
    clflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de mise a jour")
    clmultstrike = db.Column(db.Numeric(8, 3))
    clmulttrigger = db.Column(db.Numeric(8, 3))
    cldevtrigger = db.Column(db.Numeric(8, 0, asdecimal=False))


class Rkclause6(db.Model):
    __tablename__ = "rkclause6"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    clcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Identifiant de l'instrument"
    )
    clnum = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="La clé de présentation"
    )
    cldebut = db.Column(db.DateTime, info="Date de début de clause")
    clfin = db.Column(db.DateTime, info="Date de fin de clause")
    clrembo = db.Column(
        db.Numeric(10, 2),
        info="Montant du remboursement ( en devise ou pourcentage suivant le type de la clause)",
    )
    cltrigger = db.Column(
        db.Numeric(10, 2),
        info="Seuil ( trigger) de remboursement ( en devise ou pourcentage suivant le type de la clause)",
    )
    clmulttrigger = db.Column(
        db.Numeric(8, 3), info="Multiplicateur de seuil ( trigger)"
    )
    cltypetrigger = db.Column(
        db.Numeric(asdecimal=False), info="Identificateur du type de seuil ( trigger)"
    )
    clactu = db.Column(
        db.Numeric(8, 2), info="Taus d'actualisation de la clause ( en pourcentage)"
    )
    clindiccc = db.Column(
        db.String(1), info="Indicateur de prise en compte du coupon couru"
    )
    clproba = db.Column(
        db.Numeric(8, 3), info="Probabilité d'exercice de la clause ( en pourcentage)"
    )
    clmin = db.Column(
        db.Numeric(10, 2), info="Montant minimal ( borne inférieure de la clause)"
    )
    clmax = db.Column(
        db.Numeric(10, 2), info="Montant maximal ( borne supérieure de la clause)"
    )
    clupdate = db.Column(db.DateTime, info="Date de dernière mise à jour de la clause")
    clflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    cltclause = db.Column(db.Numeric(2, 0, asdecimal=False))


class Rkclausetprod(db.Model):
    __tablename__ = "rkclausetprod"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tctclause = db.Column(db.Numeric(2, 0, asdecimal=False), info="Type de clause")
    tctype = db.Column(db.Numeric(3, 0, asdecimal=False), info="Type de produit")
    tcflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Rkcoeffrisk(db.Model):
    __tablename__ = "rkcoeffrisk"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cocfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code produit ( cf RKPRODUIT)"
    )
    cocoeff = db.Column(db.Numeric(8, 3), info="Coefficient de risque associe")
    coflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Rkcomplexdeal(db.Model):
    __tablename__ = "rkcomplexdeal"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    cdid = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Technical ID for a complex deal. Based on the RISQUE.SEQ_RKCOMPLEXDEAL sequence",
    )
    cdparentid = db.Column(
        db.ForeignKey("risque.rkcomplexdeal.cdid"),
        index=True,
        info="Parent complex deal ID if this complex deal is aggregated with another complex deal",
    )
    cdtradedate = db.Column(
        db.DateTime,
        nullable=False,
        index=True,
        info="Trade date (aka negociation date) of this complex deal",
    )
    cdinitdate = db.Column(
        db.DateTime,
        nullable=False,
        info="System date when this complex deal has been created",
    )
    cdexchangerate = db.Column(
        db.Numeric(13, 8), info="Exchange rate for a FOREX complex deal"
    )
    cdnetprice = db.Column(
        db.Numeric(15, 5),
        info="The complex deal net price in the deal currency, which can differ from the instrument currency",
    )
    cdbrokerfees = db.Column(
        db.Numeric(21, 5),
        info="The complex deal broker fees in the deal currency, which can differ from the instrument currency",
    )
    cdflag = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        nullable=False,
        info="Indicate whether this complex deal has been created (1), modified (2) or removed (3)",
    )
    cdversion = db.Column(
        db.Numeric(38, 0, asdecimal=False),
        info="Numero de version (de modification) du complex deal (initialiser par le numero de version de l'ope.",
    )
    cdinstrumentid = db.Column(
        db.Numeric(8, 0, asdecimal=False), index=True, info="CFIN of the complex deal"
    )
    cdsystem = db.Column(
        db.ForeignKey("risque.rksystem.syid"), info="System which has created the deal"
    )
    cdexternalref = db.Column(
        db.String(37),
        info="External reference of the deal: id of the deal in the system CDSYSTEM",
    )
    cdmodifdate = db.Column(
        db.DateTime, index=True, info="Last modification date of the complex deal"
    )
    cdtype = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="code type of the complex deal"
    )
    cdexporttomo = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="Export to MO Flag for complex deal"
    )
    cdtcsstate = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="TCS state for complex deal"
    )
    cdmostate = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="MO state for simple deal"
    )
    cdsalesid = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Complex deal sales id"
    )
    cdquotationmode = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="quotation mode as input by user"
    )
    cdaccruedinterest = db.Column(
        db.Numeric(21, 5), info="accrued interest as input by user"
    )
    cddiscount = db.Column(db.Numeric(21, 5), info="discount as input by user")
    cdcreationdate = db.Column(
        db.DateTime, info="Creation date down to the millisecond of the transaction"
    )
    cdmodificationdate = db.Column(
        db.DateTime, info="Modification date down to the millisecond of the transaction"
    )

    parent = db.relationship(
        "Rkcomplexdeal",
        remote_side=[cdid],
        primaryjoin="Rkcomplexdeal.cdparentid == Rkcomplexdeal.cdid",
        backref="rkcomplexdeals",
    )
    rksystem = db.relationship(
        "Rksystem",
        primaryjoin="Rkcomplexdeal.cdsystem == Rksystem.syid",
        backref="rkcomplexdeals",
    )


class Rkcomplexdeallink(db.Model):
    __tablename__ = "rkcomplexdeallink"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("uq_rkcomplexdeallink", "clid1", "clid2", "clrole1", "clrole2"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    clid1 = db.Column(
        db.ForeignKey("risque.rkoperation.opnumero"),
        nullable=False,
        index=True,
        info="Identifier of the first complex deal in the association; note that the main deal id is the same as its complex deal",
    )
    clid2 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="Identifier of the second complex deal in the association; note that the main deal id is the same as its complex deal",
    )
    cltype = db.Column(
        db.ForeignKey("risque.rkcdlinktype.ltid"),
        nullable=False,
        info="Identifier of the type of the complex deal association",
    )
    clrole1 = db.Column(
        db.ForeignKey("risque.rkcdlinkrole.lrid"),
        nullable=False,
        info="Identifier of the role of the first complex deal in the association",
    )
    clrole2 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Identifier of the role of the second complex deal in the association",
    )

    rkoperation = db.relationship(
        "Rkoperation",
        primaryjoin="Rkcomplexdeallink.clid1 == Rkoperation.opnumero",
        backref="rkoperation_rkcomplexdeallinks",
    )
    rkoperation1 = db.relationship(
        "Rkoperation",
        primaryjoin="Rkcomplexdeallink.clid2 == Rkoperation.opnumero",
        backref="rkoperation_rkcomplexdeallinks_0",
    )
    rkcdlinkrole = db.relationship(
        "Rkcdlinkrole",
        primaryjoin="Rkcomplexdeallink.clrole1 == Rkcdlinkrole.lrid",
        backref="rkcdlinkrole_rkcomplexdeallinks",
    )
    rkcdlinkrole1 = db.relationship(
        "Rkcdlinkrole",
        primaryjoin="Rkcomplexdeallink.clrole2 == Rkcdlinkrole.lrid",
        backref="rkcdlinkrole_rkcomplexdeallinks_0",
    )
    rkcdlinktype = db.relationship(
        "Rkcdlinktype",
        primaryjoin="Rkcomplexdeallink.cltype == Rkcdlinktype.ltid",
        backref="rkcomplexdeallinks",
    )


class Rkcompte(db.Model):
    __tablename__ = "rkcompte"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cpcompte = db.Column(db.Numeric(5, 0, asdecimal=False), info="Code Compte ouvert")
    cpnumcompte = db.Column(db.String(30), info="Numero du compte")
    cpnumscompte = db.Column(db.String(30), info="Reference du sous compte")
    cpdepot = db.Column(
        db.Numeric(4, 0, asdecimal=False), info="Code Depot (cd table RKDEPOT)"
    )
    cpnom = db.Column(db.String(30), info="Libelle du compte ouvert")
    cpflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    cptypecompte = db.Column(db.Numeric(2, 0, asdecimal=False))


class Rkcomptebud(db.Model):
    __tablename__ = "rkcomptebud"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cbcompte = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="Code compte (cf table RKCOMPTE)"
    )
    cbbudget = db.Column(
        db.Numeric(4, 0, asdecimal=False), info="Code Budget (cd table RKBUDGET)"
    )
    cbflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Rkcomptedef(db.Model):
    __tablename__ = "rkcomptedef"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cdcompte = db.Column(db.Numeric(5, 0, asdecimal=False), info="Code du compte")
    cdbigbook = db.Column(
        db.Numeric(4, 0, asdecimal=False), info="Code du portefeuille"
    )
    cdtprod = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Code du type de produit"
    )
    cdmarket = db.Column(db.Numeric(3, 0, asdecimal=False), info="Code du marche")
    cdmoderl = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Code du mode de reglement livraison"
    )
    cdflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    cdcfin = db.Column(db.Numeric(8, 0, asdecimal=False))


class Rkcontrepart(db.Model):
    __tablename__ = "rkcontrepart"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cpcptie = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code contrepartie")
    cpnom = db.Column(db.String(15), info="Nom de la contrepartie")
    cpclef = db.Column(db.String(1), info="I ( interne) E ( externe)")
    cpflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Rkcorporateaction(db.Model):
    __tablename__ = "rkcorporateaction"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    caid = db.Column(
        db.Numeric(10, 0, asdecimal=False),
        primary_key=True,
        info="Corporation action instance id",
    )
    cawfid = db.Column(
        db.Numeric(10, 0, asdecimal=False),
        nullable=False,
        info="Corporation action workflow model id",
    )
    cacfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="cfin used in the CA",
    )
    casubbook = db.Column(
        db.ForeignKey("risque.rkdefbigbook.dbbook"),
        nullable=False,
        info="subbook of the CA",
    )
    caeventdate = db.Column(db.DateTime, nullable=False, index=True, info="Event date")
    capaymentdate = db.Column(
        db.DateTime, nullable=False, index=True, info="payment date"
    )
    caissuedqte = db.Column(db.Numeric(17, 4), nullable=False, info="issue quantity")
    cainvestedqte = db.Column(
        db.Numeric(17, 4), nullable=False, info="inversted quantity"
    )
    cacoupontype = db.Column(
        db.Numeric(1, 0, asdecimal=False), info="coupon type :none, cash or stock"
    )
    caredemptiontype = db.Column(
        db.Numeric(1, 0, asdecimal=False), info="redemption type :none, cash or stock"
    )
    cabudgetcenter = db.Column(
        db.Numeric(4, 0, asdecimal=False), nullable=False, info="budget center id"
    )
    cainstrumenttype = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        info="instrument type :certificate or warrant",
    )
    castatus = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        nullable=False,
        info="Corporate action status",
    )
    caflag = db.Column(db.Numeric(1, 0, asdecimal=False), info="1 if alive")
    causer = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="last update user"
    )
    cahorodate = db.Column(db.DateTime, nullable=False, info="last update date")
    caversion = db.Column(db.Numeric(4, 0, asdecimal=False), nullable=False)
    cacreationdate = db.Column(db.DateTime, info="Date de creation de l event")
    calastmodifier = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        info="ID du dernier utilisation modifiant l event",
    )
    catogenerateflag = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Flag indiquant que les deals de l event devraient etre genere par un job(ex date dans le future)",
    )
    capaidqte = db.Column(
        db.Numeric(17, 4), info="Indicates the quantity real paid to EOC"
    )
    caispayingagent = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="are we the paying agent for the originated issue",
    )
    caisexceptional = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="Indique si l event est de type exceptionnel",
    )
    cacomment = db.Column(db.String(255), server_default=db.FetchedValue())
    cacreationmode = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info=" M if the event is created manually, B if the event is created by batch",
    )
    cashouldnotifyeurotlx = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info=" Flag used to send email notification to eurotlx by batch",
    )
    cashouldnotifysedex = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info=" Flag used to send email notification to sedex by batch",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Rkcorporateaction.cacfin == Instrument.ifcfin",
        backref="rkcorporateactions",
    )
    rkdefbigbook = db.relationship(
        "Rkdefbigbook",
        primaryjoin="Rkcorporateaction.casubbook == Rkdefbigbook.dbbook",
        backref="rkcorporateactions",
    )


class Rkcorrelation(db.Model):
    __tablename__ = "rkcorrelation"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    cocfin1 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="1er CFin de la correlation",
    )
    cocfin2 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="2nd CFin de la correlation",
    )
    covaleur = db.Column(db.Numeric(18, 5), info="Valeur de la correlation")
    comaj = db.Column(
        db.DateTime,
        server_default=db.FetchedValue(),
        info="Date de mise à jour de la corrélation",
    )


class RkcorrelationBkp(db.Model):
    __tablename__ = "rkcorrelation_bkp"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cocfin1 = db.Column(db.Numeric(8, 0, asdecimal=False))
    cocfin2 = db.Column(db.Numeric(8, 0, asdecimal=False))
    covaleur = db.Column(db.Numeric(18, 5))
    comaj = db.Column(db.DateTime)


class RkcorrelationEc(db.Model):
    __tablename__ = "rkcorrelation_ec"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cocfin1 = db.Column(db.Numeric(8, 0, asdecimal=False))
    cocfin2 = db.Column(db.Numeric(8, 0, asdecimal=False))
    covaleur = db.Column(db.Numeric(18, 5))
    comaj = db.Column(db.DateTime)


class RkcorrelationH(db.Model):
    __tablename__ = "rkcorrelation_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cohcfin1 = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="1er CFin de la correlation"
    )
    cohcfin2 = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="2nd CFin de la correlation"
    )
    cohvaleur = db.Column(db.Numeric(18, 5), info="Valeur de la correlation")
    cohmaj = db.Column(db.DateTime, info="Date de mise à jour de la corrélation")
    cohhorodate = db.Column(
        db.DateTime,
        server_default=db.FetchedValue(),
        info="Date d'entrée dans l'historique",
    )
    cohuser = db.Column(
        db.String(60), info="Utilisateur ayant effectuée la mise à jour"
    )
    cohtrait = db.Column(db.String(1), info="Type de mise à jour effectuée")


class RkcorrelationRef(db.Model):
    __tablename__ = "rkcorrelation_ref"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx_rkcorrelation_ref_cfin1_2", "cocfin1", "cocfin2"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cocfin1 = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="1er CFin de la correlation"
    )
    cocfin2 = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="2nd CFin de la correlation"
    )
    covaleur = db.Column(db.Numeric(18, 5), info="Valeur de la correlation")
    codateref = db.Column(db.DateTime, info="Date du cliché du PNL de Ref")


class RkcorrelationRefH(db.Model):
    __tablename__ = "rkcorrelation_ref_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cohcfin1 = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="1er CFin de la correlation"
    )
    cohcfin2 = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="2nd CFin de la correlation"
    )
    cohvaleur = db.Column(db.Numeric(18, 5), info="Valeur de la correlation")
    cohdateref = db.Column(db.DateTime, index=True, info="Date du cliché")
    cohdatehisto = db.Column(db.DateTime, info="Date de prise du cliché")


class RkcorrelationTmp(db.Model):
    __tablename__ = "rkcorrelation_tmp"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    cocfin1 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="1er CFin de la correlation",
    )
    cocfin2 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="2nd CFin de la correlation",
    )
    covaleur = db.Column(db.Numeric(18, 5), info="Valeur de la correlation")
    comaj = db.Column(
        db.DateTime,
        server_default=db.FetchedValue(),
        info="Date de mise Ã\xa0our de la corrÃ©tion",
    )


class Rkcouponspaye(db.Model):
    __tablename__ = "rkcouponspayes"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    cpcode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Code du coupon payé"
    )
    cpcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="Cfin de l'instrument",
    )
    cpexdate = db.Column(db.DateTime, nullable=False, info="Date ex-dividende")
    cpdaterl = db.Column(
        db.DateTime,
        nullable=False,
        index=True,
        info="Date de paiement (reglement/livraison)",
    )
    cpmontant = db.Column(db.Numeric(25, 9), nullable=False, info="Montant unitaire")
    cpdev = db.Column(
        db.ForeignKey("exane.devise.dvcfin"),
        nullable=False,
        info="Devise dans laquelle est exprimé le montant",
    )
    cpdate = db.Column(db.DateTime, nullable=False, info="Date de modification")
    cputilisateur = db.Column(
        db.ForeignKey("risque.rkuser.ususer"),
        nullable=False,
        info="Le code de l'utilisateur qui a modifié le coupon.",
    )
    cpflag = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Etat de la ligne (1-active, 2-modifié, 3-supprimée).",
    )
    cpsjac = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Sous-jacent ayant entraéné la tombé de coupon.",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Rkcouponspaye.cpcfin == Instrument.ifcfin",
        backref="rkcouponspayes",
    )
    devise = db.relationship(
        "Devise",
        primaryjoin="Rkcouponspaye.cpdev == Devise.dvcfin",
        backref="devise_rkcouponspayes",
    )
    rkuser = db.relationship(
        "Rkuser",
        primaryjoin="Rkcouponspaye.cputilisateur == Rkuser.ususer",
        backref="rkcouponspayes",
    )


class Rkcouponspayesmiddle(Rkcouponspaye):
    __tablename__ = "rkcouponspayesmiddle"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    cmcode = db.Column(
        db.ForeignKey("risque.rkcouponspayes.cpcode"),
        primary_key=True,
        info="Code du coupon",
    )
    cmvalidation = db.Column(
        db.ForeignKey("risque.rkstatutvalidation.svcode"),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Statut de validation du coupon",
    )
    cmmotifrefus = db.Column(
        db.ForeignKey("risque.rkmotifrefuscoupons.mrcode"),
        info="Code du motif de refus de validation du coupon",
    )
    cmcommentaire = db.Column(db.String(1024), info="Commentaire")
    cmutilisateur = db.Column(
        db.String(30),
        info="Nom/machine de l'utilisateur qui valide (géré via un trigger)",
    )
    cmhorodate = db.Column(
        db.DateTime,
        nullable=False,
        info="Date/heure de dernière mise à jour du statut (géré via un trigger)",
    )

    rkmotifrefuscoupon = db.relationship(
        "Rkmotifrefuscoupon",
        primaryjoin="Rkcouponspayesmiddle.cmmotifrefus == Rkmotifrefuscoupon.mrcode",
        backref="rkcouponspayesmiddles",
    )
    rkstatutvalidation = db.relationship(
        "Rkstatutvalidation",
        primaryjoin="Rkcouponspayesmiddle.cmvalidation == Rkstatutvalidation.svcode",
        backref="rkcouponspayesmiddles",
    )


class RkcouponspayesH(db.Model):
    __tablename__ = "rkcouponspayes_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx_rkcouponspayes_h_cfin", "cphcfin", "cphdate"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cphcode = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Code du coupon payé"
    )
    cphcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Cfin de l'instrument"
    )
    cphexdate = db.Column(db.DateTime, nullable=False, info="Date ex-dividende")
    cphdaterl = db.Column(
        db.DateTime, nullable=False, info="Date de paiement (reglement/livraison)"
    )
    cphmontant = db.Column(db.Numeric(25, 9), nullable=False, info="Montant unitaire")
    cphdev = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Devise dans laquelle est exprimé le montant",
    )
    cphdate = db.Column(db.DateTime, nullable=False, info="Date de modification")
    cphutilisateur = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="Le code de l'utilisateur qui a modifié le coupon.",
    )
    cphflag = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="Etat de la ligne (1-active, 2-modifié, 3-supprimée).",
    )
    cphhorodate = db.Column(
        db.DateTime,
        nullable=False,
        server_default=db.FetchedValue(),
        info="Date/heure de la mise à jour",
    )
    cphsjac = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Sous-jacent ayant entraîné la tombé de coupon.",
    )


class Rkcritereautomate(db.Model):
    __tablename__ = "rkcritereautomate"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    caordre = db.Column(db.Numeric(4, 0, asdecimal=False))
    cabook = db.Column(db.Numeric(4, 0, asdecimal=False))
    cacfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    catypeex = db.Column(db.String(1))
    camontant = db.Column(db.Numeric(asdecimal=False))
    capourcent = db.Column(db.Numeric(asdecimal=False))


class Rkcritereechelle(db.Model):
    __tablename__ = "rkcritereechelle"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ceordre = db.Column(db.Numeric(4, 0, asdecimal=False))
    cemin = db.Column(db.Numeric(asdecimal=False))
    cemax = db.Column(db.Numeric(asdecimal=False))


class Rkcriteremarche(db.Model):
    __tablename__ = "rkcriteremarche"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ceordre = db.Column(db.Numeric(4, 0, asdecimal=False))
    cemarche = db.Column(db.Numeric(3, 0, asdecimal=False))
    cemin = db.Column(db.Numeric(asdecimal=False))
    cemax = db.Column(db.Numeric(asdecimal=False))


class Rkcube(db.Model):
    __tablename__ = "rkcube"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint(" cucubecomplet in ('O','N')"),
        db.CheckConstraint(" cucubecomplet in ('O','N')"),
        db.CheckConstraint(" cucubecomplet in ('O','N')"),
        db.CheckConstraint(" cusensicomplet in ('O','N')"),
        db.CheckConstraint(" cusensicomplet in ('O','N')"),
        db.CheckConstraint(" cusensicomplet in ('O','N')"),
        db.CheckConstraint("cuARCHIVE in ('O','N') "),
        db.CheckConstraint("cuARCHIVE in ('O','N') "),
        db.CheckConstraint("cuARCHIVE in ('O','N') "),
        db.Index("uk_cube", "cucfinproduit", "cutype", "cudategeneration"),
        {"schema": "risque"},
    )

    cudategeneration = db.Column(db.DateTime, nullable=False, index=True)
    cucode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    cudatecalcul = db.Column(db.DateTime)
    cucfinproduit = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, index=True
    )
    cusommediv = db.Column(db.Numeric(asdecimal=False), nullable=False)
    cucubecomplet = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Flag fin générération du cube:  O=complet,  N=non terminé",
    )
    cusensicomplet = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Flag fin générération du vecteur de sensibilité :  O=complet,  N=non terminé",
    )
    cudatesensi = db.Column(db.DateTime)
    cuarchive = db.Column(db.String(1), server_default=db.FetchedValue())
    cunbrecopiecube = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Nombre de recopies de ce cube",
    )
    cuprofile = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Profile de calcul",
    )
    cuutcstartcube = db.Column(
        db.DateTime,
        server_default=db.FetchedValue(),
        info="Timestamp utc de reception de la demande de cube",
    )
    cuutcstartsensi = db.Column(
        db.DateTime,
        server_default=db.FetchedValue(),
        info="Timestamp utc de reception de la demande de sensis",
    )
    cutype = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Type de cube (0: full, 1:intraday)",
    )
    cuerrorcode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Code erreur du cube",
    )


class Rkcubeautoactiveworker(db.Model):
    __tablename__ = "rkcubeautoactiveworker"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cuaaid = db.Column(
        nullable=False, info="GUID du worker actif de recalcul automatique des cubes"
    )
    cuaahealthcheckdate = db.Column(
        db.DateTime,
        nullable=False,
        info="Derniere date a laquelle le worker actif de recalcul automatique a notifie son etat",
    )


class Rkcubeautoconfig(db.Model):
    __tablename__ = "rkcubeautoconfig"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cuaccfinproduit = db.Column(
        db.Numeric(16, 0, asdecimal=False),
        nullable=False,
        unique=True,
        info="Cfin du produit",
    )
    cuacforceprofile = db.Column(
        db.Numeric(16, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Si non-null, determine quel profile sera utilise pour le calcul. Si null, on utilise le profile avec le plus de position.",
    )
    cuacactive = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Flag indiquant si le cube doit etre calcule automatiquement:  Y=Yes,  N=No",
    )
    cuacadditivescoreadjustment = db.Column(
        db.Float,
        server_default=db.FetchedValue(),
        info="On ajoute cette valeur au score du cube (apres une eventuelle multiplication)",
    )
    cuacmultiplicativescoreadjustment = db.Column(
        db.Float,
        server_default=db.FetchedValue(),
        info="On multiplie le score du cube par cette valeur (avant une eventuelle addition)",
    )


class Rkcubeautocrosserror(db.Model):
    __tablename__ = "rkcubeautocrosserrors"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cuascur1 = db.Column(
        db.Numeric(16, 0, asdecimal=False), nullable=False, info="Monnaie source"
    )
    cuascur2 = db.Column(
        db.Numeric(16, 0, asdecimal=False), nullable=False, info="Monnaie destination"
    )
    cuastaskid = db.Column(
        db.Numeric(15, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="ID de la tache",
    )
    cuastaskphase = db.Column(
        db.Numeric(2, 0, asdecimal=False), nullable=False, info="Phase de la tache"
    )
    cuastedid = db.Column(
        server_default=db.FetchedValue(),
        info="ID de la requete TED (null si il n y a pas eu de demande de cross)",
    )
    cuasdatetime = db.Column(db.DateTime, nullable=False, info="Heure de l erreur")
    cuaserrortype = db.Column(
        db.String(4000), server_default=db.FetchedValue(), info="Type d erreur"
    )
    cuaserrormsg = db.Column(
        db.String(4000), server_default=db.FetchedValue(), info="Message d erreur"
    )
    cuaserrordetail = db.Column(
        db.String(4000), server_default=db.FetchedValue(), info="Details sur l erreur"
    )


class Rkcubeautodeviation(db.Model):
    __tablename__ = "rkcubeautodeviations"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("uk1_cubeautodeviations", "cuadtaskid", "cuadcfinproduit"),
        db.Index("uk2_cubeautodeviations", "cuadcfinproduit", "cuadtaskid"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cuadtaskid = db.Column(
        db.Numeric(15, 0, asdecimal=False), nullable=False, info="ID de la tache"
    )
    cuadenvid = db.Column(
        server_default=db.FetchedValue(),
        info="Environnement castor utilise pour les calculs standards",
    )
    cuadcfinproduit = db.Column(
        db.Numeric(16, 0, asdecimal=False), nullable=False, info="Cfin du produit"
    )
    cuadcomputeprofile = db.Column(
        db.Numeric(16, 0, asdecimal=False),
        nullable=False,
        info="Le profile utilise pour les calculs",
    )
    cuadcentralprice = db.Column(
        db.Float,
        server_default=db.FetchedValue(),
        info="Prix en mode central, dans la monnaie du produit",
    )
    cuadcentralerror = db.Column(
        db.String(4000),
        server_default=db.FetchedValue(),
        info="Erreur survenue pendant le calcul de prix en mode central",
    )
    cuaddeformationprice = db.Column(
        db.Float,
        server_default=db.FetchedValue(),
        info="Prix en mode deformation, dans la monnaie du produit",
    )
    cuaddeformationerror = db.Column(
        db.String(4000),
        server_default=db.FetchedValue(),
        info="Erreur survenue pendant le calcul de prix en mode standard deformation",
    )
    cuadcrosstoeuro = db.Column(
        db.Float,
        server_default=db.FetchedValue(),
        info="Cross de la monnaie du produit vers euro",
    )
    cuadmultponder = db.Column(
        db.Float,
        server_default=db.FetchedValue(),
        info="Ponderation multiplicative du score (multiplicativeAdjustment)",
    )
    cuadaddponder = db.Column(
        db.Float,
        server_default=db.FetchedValue(),
        info="Ponderation additive du score (additiveAdjustment)",
    )
    cuaddeviationeuro = db.Column(
        db.Float,
        server_default=db.FetchedValue(),
        info="Score du cube= additiveAdjustment + multiplicativeAdjustment * abs(totalposition * (centralprice-deformationprice) * crosstoeuro)",
    )


class Rkcubeautoenv(db.Model):
    __tablename__ = "rkcubeautoenvs"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cuaeenvid = db.Column(
        nullable=False,
        unique=True,
        info="GUID d un environnement utilise en ce moment par le recalcul automatique des cubes",
    )
    cuaeenvhost = db.Column(
        db.String(4000),
        nullable=False,
        info="Hostname du frontal castor sur lequel l environnement a ete cree",
    )


class Rkcubeautohistopendingslice(db.Model):
    __tablename__ = "rkcubeautohistopendingslices"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cuahworkerid = db.Column(nullable=False, info="ID du worker")
    cuahcountpendingslices = db.Column(
        db.Numeric(16, 0, asdecimal=False),
        nullable=False,
        info="Nombre de slices qui sont en cours de calcul ou a venir",
    )
    cuahdatetime = db.Column(
        db.DateTime, nullable=False, index=True, info="Heure de la mesure"
    )
    cuahinterpprev = db.Column(
        db.String(1),
        nullable=False,
        info="Interpolation avec la valeur precedente. Y = Oui, N = Non",
    )
    cuahtype = db.Column(
        db.String(1),
        nullable=False,
        info="Type de slice : S = Standard, N = Native(calcul de cube)",
    )


class Rkcubeautoignoredspoterror(db.Model):
    __tablename__ = "rkcubeautoignoredspoterrors"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cuaicfin = db.Column(
        db.Numeric(16, 0, asdecimal=False),
        nullable=False,
        unique=True,
        info="Cfin de sous-jacent pour lequel on autorise les erreurs de recuperation du spot temps reel",
    )


class Rkcubeautonativecompute(db.Model):
    __tablename__ = "rkcubeautonativecomputes"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "uk1_cubeautonativecomputes", "cuantaskid", "cuancfinproduit", "cuantype"
        ),
        db.Index(
            "uk2_cubeautonativecomputes", "cuancfinproduit", "cuantaskid", "cuantype"
        ),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cuantaskid = db.Column(
        db.Numeric(15, 0, asdecimal=False), nullable=False, info="ID de la tache"
    )
    cuanreason = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Raison pour laquelle ce cube a ete calcule (F:Forced, D:Deviated E:Error in previous task)",
    )
    cuancfinproduit = db.Column(
        db.Numeric(16, 0, asdecimal=False), nullable=False, info="Cfin du produit"
    )
    cuantype = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Type du cube"
    )
    cuancomputeprofile = db.Column(
        db.Numeric(16, 0, asdecimal=False),
        nullable=False,
        info="Le profile utilise pour les calculs",
    )
    cuanenvid = db.Column(
        server_default=db.FetchedValue(),
        info="Environnement castor utilise pour le calcul natif",
    )
    cuanstate = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Etat du calcul natif: Q=Queued, P=in_Progress, S=Success, E=Error",
    )
    cuanstart = db.Column(db.DateTime, server_default=db.FetchedValue())
    cuanparts = db.Column(
        db.Numeric(16, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Le nombre de slices pour ce calcul",
    )
    cuanerror = db.Column(
        db.String(4000),
        server_default=db.FetchedValue(),
        info="Erreur survenue pendant le calcul natif",
    )
    cuancubecode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Resultat du calcul de cube",
    )


class Rkcubeautoposition(db.Model):
    __tablename__ = "rkcubeautopositions"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("uk2_cubeautopositions", "cuaocfinproduit", "cuaotaskid"),
        db.Index("uk1_cubeautopositions", "cuaotaskid", "cuaocfinproduit"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cuaotaskid = db.Column(
        db.Numeric(15, 0, asdecimal=False), nullable=False, info="ID de la tache"
    )
    cuaocfinproduit = db.Column(
        db.Numeric(16, 0, asdecimal=False), nullable=False, info="Cfin du produit"
    )
    cuaopositionprofile = db.Column(
        db.Numeric(16, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Le profile dans lequel il y a le plus de position en valeur absolue",
    )
    cuaototalposition = db.Column(
        db.Numeric(16, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="La position aggregee sur tous les profils",
    )
    cuaopositionerror = db.Column(
        db.String(4000),
        server_default=db.FetchedValue(),
        info="Erreur de calcul de position",
    )


class Rkcubeautorequest(db.Model):
    __tablename__ = "rkcubeautorequests"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cuarcfinproduit = db.Column(
        db.Numeric(16, 0, asdecimal=False),
        nullable=False,
        info="cfin du produit dont le cube doit etre recalcule",
    )
    cuarprofile = db.Column(
        db.Numeric(16, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="profile dans lequel on veut recalculer le cube \n    (si null on utilise RISQUE.RKCUBEAUTOCONFIG.CUACFORCEPROFILE si il existe ou on prend le profile avec le plus de position)",
    )
    cuartype = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Type de cube (0: full, 1:intraday)",
    )
    cuardaterequest = db.Column(
        db.DateTime,
        server_default=db.FetchedValue(),
        info="Date a laquelle la requete a ete creee",
    )


class Rkcubeautospoterror(db.Model):
    __tablename__ = "rkcubeautospoterrors"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cuapcfin = db.Column(
        db.Numeric(16, 0, asdecimal=False),
        nullable=False,
        info="Cfin pour lequel on a eu une erreur de spot temps reel",
    )
    cuaptaskid = db.Column(
        db.Numeric(15, 0, asdecimal=False), nullable=False, info="ID de la tache"
    )
    cuaptaskphase = db.Column(
        db.Numeric(2, 0, asdecimal=False), nullable=False, info="Phase de la tache"
    )
    cuaptedid = db.Column(
        server_default=db.FetchedValue(),
        info="ID de la requete TED (null si il n y a pas eu de demande de spot)",
    )
    cuaprequestlabel = db.Column(db.String(4000), nullable=False)
    cuapdatetime = db.Column(db.DateTime, nullable=False, info="Heure de l erreur")
    cuapisin = db.Column(
        db.String(100),
        server_default=db.FetchedValue(),
        info="Isin passe ted dans la demande de spot",
    )
    cuapmic = db.Column(
        db.String(100),
        server_default=db.FetchedValue(),
        info="Mic passe ted dans la demande de spot",
    )
    cuapassettype = db.Column(
        db.String(4000),
        server_default=db.FetchedValue(),
        info="Type d asset (renvoye par ted)",
    )
    cuaperrortype = db.Column(
        db.String(4000), server_default=db.FetchedValue(), info="Type d erreur"
    )
    cuaperrormsg = db.Column(
        db.String(4000), server_default=db.FetchedValue(), info="Message d erreur"
    )
    cuaperrordetail = db.Column(
        db.String(4000), server_default=db.FetchedValue(), info="Details sur l erreur"
    )


class Rkcubeautotask(db.Model):
    __tablename__ = "rkcubeautotasks"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cuattaskid = db.Column(
        db.Numeric(15, 0, asdecimal=False),
        nullable=False,
        unique=True,
        server_default=db.FetchedValue(),
        info="ID de la tache",
    )
    cuatworkerid = db.Column(nullable=False, info="ID du worker qui contient la tache")
    cuatdatetime = db.Column(
        db.DateTime, nullable=False, index=True, info="Heure de creation de la tache"
    )
    cuattype = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        nullable=False,
        info="Type de tache (0: autocompute, 1: forcedCompute)",
    )
    cuatstatus = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Status de la tache (P=in_Progress,T=Terminated)",
    )
    cuattotalvalueused = db.Column(
        db.Numeric(16, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="La valeur totalvalue utilisee pour une tache d evaluation",
    )


class Rkcubeautotasksspoterror(db.Model):
    __tablename__ = "rkcubeautotasksspoterrors"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cuaotaskid = db.Column(
        db.Numeric(15, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="ID de la tache",
    )
    cuaotaskphase = db.Column(
        db.Numeric(2, 0, asdecimal=False), nullable=False, info="Phase de la tache"
    )
    cuaocfinprd = db.Column(
        db.Numeric(16, 0, asdecimal=False), nullable=False, info="Cfin du produit"
    )
    cuaocfinsjac = db.Column(
        db.Numeric(16, 0, asdecimal=False),
        nullable=False,
        info="Cfin du sous-jacent pour lequel on a eu une erreur de spot temps reel",
    )


class Rkcubeautototalvalue(db.Model):
    __tablename__ = "rkcubeautototalvalue"
    __bind_key__ = "exane_risque"
    __table_args__ = (db.CheckConstraint("CUATLOCK='X'"), {"schema": "risque"})

    cuatlock = db.Column(
        db.String(1), primary_key=True, server_default=db.FetchedValue()
    )
    cuattotalvalue = db.Column(
        db.Numeric(16, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Si la somme des valeurs absolues des deviations des cubes est inferieure a cette valeur, on ne les recalcule pas automatiquement",
    )


class Rkcubeautoworkererror(db.Model):
    __tablename__ = "rkcubeautoworkererror"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cuawworkerid = db.Column(nullable=False, info="worker qui est a l originie du log")
    cuawtimestamp = db.Column(
        db.DateTime, nullable=False, index=True, info="Heure du log (sur le worker)"
    )
    cuawlog = db.Column(db.String(4000), nullable=False)


class Rkcubeduree(db.Model):
    __tablename__ = "rkcubeduree"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "uk_cubeduree",
            "cdcfin",
            "cdsjac",
            "cddefspot",
            "cddefvol",
            "cddeftaux",
            "cddevise",
            "cdprofile",
            "cdtype",
        ),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cdcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        info="CFIN du produit scripté",
    )
    cdsjac = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="CFIN du sous jacent, non null que  dans le cas de scénario avec spot null (cfin du sous jacent dont le spot est mis à null) pour les scripts multis",
    )
    cddefspot = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Déformation du spot, 0 pour scénario point central(mono ou multi), NULL pour scénario multi spot null et autre point mono, valeur*100 pour les autres points multis",
    )
    cddefvol = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Déformation de la volatilité, 0 pour scénario point central MONO, NULL pour tous les scénarios multis, valeur *100 pour les autres points monos",
    )
    cddeftaux = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Déformation du taux, 0 pour scénario point central MONO, NULL pour tous les scénarios multis, valeur *100 pour les autres points monos",
    )
    cdduree = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Durée totale en secondes pour le calcul du point",
    )
    cddevise = db.Column(
        db.ForeignKey("exane.devise.dvcfin"),
        info="Devise de la déformation en taux (CDDEFTAUX)",
    )
    cdprofile = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Profile de calcul",
    )
    cdtype = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Type de cube (0: full, 1:intraday)",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Rkcubeduree.cdcfin == Instrument.ifcfin",
        backref="rkcubedurees",
    )
    devise = db.relationship(
        "Devise",
        primaryjoin="Rkcubeduree.cddevise == Devise.dvcfin",
        backref="devise_rkcubedurees",
    )


class Rkcuberesultat(db.Model):
    __tablename__ = "rkcuberesultat"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    crcodecube = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, index=True
    )
    crcoderesultat = db.Column(
        db.Numeric(13, 0, asdecimal=False), nullable=False, index=True
    )
    crtypeindicateur = db.Column(
        db.ForeignKey("risque.rktypeindicateur.ticode"), nullable=False, index=True
    )
    crcodefin1 = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, index=True
    )
    crcodefin2 = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, index=True
    )
    crvaleur = db.Column(db.Numeric(asdecimal=False))
    crtypescenario = db.Column(
        db.ForeignKey("risque.rktypescenario.tscode"), nullable=False
    )

    rktypeindicateur = db.relationship(
        "Rktypeindicateur",
        primaryjoin="Rkcuberesultat.crtypeindicateur == Rktypeindicateur.ticode",
        backref="rkcuberesultats",
    )
    rktypescenario = db.relationship(
        "Rktypescenario",
        primaryjoin="Rkcuberesultat.crtypescenario == Rktypescenario.tscode",
        backref="rkcuberesultats",
    )


class Rkcvt(db.Model):
    __tablename__ = "rkcvt"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cvcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    cvdatedeb = db.Column(db.DateTime)
    cvdatefin = db.Column(db.DateTime)
    cvclean = db.Column(db.String(1))
    cvptbase = db.Column(db.Numeric(8, 2))
    cvzerocoupon = db.Column(db.String(1))
    cvremb = db.Column(db.Numeric(6, 2))
    cvsoulte = db.Column(db.Numeric(8, 2))
    cvassim = db.Column(db.String(1))
    cvfacial = db.Column(db.Numeric(8, 5))
    cvtamort = db.Column(db.String(1))
    cvflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class Rkcvtrisque(db.Model):
    __tablename__ = "rkcvtrisque"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cvcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), index=True, info="Code du produit"
    )
    cvdatedeb = db.Column(db.DateTime, info="Debut de conversion")
    cvdatefin = db.Column(db.DateTime, info="Maturite")
    cvclean = db.Column(db.String(1), info="C pied de coupon D coupon couru")
    cvptbase = db.Column(db.Numeric(8, 2), info="Risque de signature")
    cvecarttaux = db.Column(db.Numeric(8, 2), info="Inutilise")
    cvtypecoupon = db.Column(db.String(1), info="Dividende en % P en devise C")
    cvactucoupon = db.Column(db.Numeric(8, 2), info="Actualisation div.")
    cvzerocoupon = db.Column(db.String(1), info="Periodicite des coupons Z M B T S A")
    cvremb = db.Column(db.Numeric(6, 2), info="Remboursement a maturite")
    cvsjvol = db.Column(db.Numeric(8, 3), info="Vol sous-jacent")
    cvsjtauxemp = db.Column(db.Numeric(8, 3), info="Taux d emprunt du sj")
    cvcoefopda = db.Column(db.Numeric(8, 3), info="Coef. d OPDA")
    cvcoefaf = db.Column(db.Numeric(8, 3), info="Coef af")
    cvsoulte = db.Column(
        db.Numeric(8, 2), info="Montant devise nominale percue a conversion"
    )
    cvlissage = db.Column(db.String(1), info="Option modele")
    cvregl = db.Column(db.String(1), info="Mode de reglement C T F R M")
    cvcouv = db.Column(db.String(1), info="Type de couverture C R")
    cvassim = db.Column(db.String(1), info="Mode d assimilation I D")
    cvfacial = db.Column(db.Numeric(8, 5), info="Taux facial")
    cvtamort = db.Column(db.String(1), info="Type d amort R I S A")
    cvflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    cvmaillage = db.Column(db.Numeric(8, 0, asdecimal=False))
    cvdevcoupon = db.Column(db.Numeric(8, 0, asdecimal=False))
    cvhorizon = db.Column(db.Numeric(3, 0, asdecimal=False))


class Rkdatepnlref(db.Model):
    __tablename__ = "rkdatepnlref"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    drdate = db.Column(db.DateTime, nullable=False)
    drflag = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)


class Rkdefbigbook(db.Model):
    __tablename__ = "rkdefbigbook"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx2_rkdefbigbook", "dbbigbook", "dbbook"),
        {"schema": "risque"},
    )

    dbbigbook = db.Column(
        db.ForeignKey("risque.rkbigbook.bbbigbook"), info="Code du portefeuille"
    )
    dbbook = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        primary_key=True,
        index=True,
        info="Code du sous portefeuille",
    )
    dbordre = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Ordre du sp dans le portefeuille"
    )
    dbnom = db.Column(db.String(60), info="Nom du sp")
    dbbooktype = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Type du sp -> RKTYPEBOOK"
    )
    dbstatus = db.Column(db.Numeric(5, 0, asdecimal=False), info="Status du sp")
    dbflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")

    rkbigbook = db.relationship(
        "Rkbigbook",
        primaryjoin="Rkdefbigbook.dbbigbook == Rkbigbook.bbbigbook",
        backref="rkdefbigbooks",
    )


class RkdefbigbookH(db.Model):
    __tablename__ = "rkdefbigbook_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dhbbigbook = db.Column(
        db.Numeric(4, 0, asdecimal=False), nullable=False, info="Code du portefeuille"
    )
    dhbbook = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        nullable=False,
        info="Code du sous portefeuille",
    )
    dhbnom = db.Column(db.String(60), info="Nom du sp")
    dhbbooktype = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Type du sp -> RKTYPEBOOK"
    )
    dhbhorodate = db.Column(db.DateTime, info="Date /heure d'historisation")
    dhbuser = db.Column(
        db.String(60),
        info="Identification de l'utilisateur OS qui a engendré la modification",
    )
    dhbtrait = db.Column(db.String(1), info="Type du traitement d'historisation")


class Rkdefbook(db.Model):
    __tablename__ = "rkdefbook"
    __bind_key__ = "exane_risque"
    __table_args__ = (db.Index("id_dfbook", "dfbook", "dfcfin"), {"schema": "risque"})

    dfbook = db.Column(
        db.ForeignKey("risque.rkdefbigbook.dbbook"),
        primary_key=True,
        nullable=False,
        info="Code du sous-portefeuille",
    )
    dfcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code du produit",
    )
    dfordre = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        info="Ordre de presentation dans le sous-portefeuille",
    )
    dfecarttaux = db.Column(
        db.Numeric(8, 4),
        info="Ecart de taux du produit par rapport au taux du portefeuille",
    )
    dfflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")

    rkdefbigbook = db.relationship(
        "Rkdefbigbook",
        primaryjoin="Rkdefbook.dfbook == Rkdefbigbook.dbbook",
        backref="rkdefbooks",
    )
    instrument = db.relationship(
        "Instrument",
        primaryjoin="Rkdefbook.dfcfin == Instrument.ifcfin",
        backref="rkdefbooks",
    )


class RkdefbookH(db.Model):
    __tablename__ = "rkdefbook_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dhfbook = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        nullable=False,
        info="Code du sous-portefeuille",
    )
    dhfcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Code du produit"
    )
    dhfhorodate = db.Column(db.DateTime, info="Date /heure d'historisation")
    dhfuser = db.Column(
        db.String(60),
        info="Identification de l'utilisateur OS qui a engendré la modification",
    )
    dhftrait = db.Column(db.String(1), info="Type du traitement d'historisation")
    dhfordre = db.Column(db.Numeric(5, 0, asdecimal=False))
    dhfecarttaux = db.Column(db.Numeric(8, 4))
    dhfflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class Rkdeffamille(db.Model):
    __tablename__ = "rkdeffamille"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dfcode = db.Column(db.Numeric(3, 0, asdecimal=False))
    dftype = db.Column(db.Numeric(3, 0, asdecimal=False))
    dfflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Rkdefreglemarche(db.Model):
    __tablename__ = "rkdefreglemarche"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("DREXERCABILITE in ('E','A')"),
        db.CheckConstraint("DREXERCABILITE in ('E','A')"),
        db.CheckConstraint("DRHORIZON in ('D','F')"),
        db.CheckConstraint("DRHORIZON in ('D','F')"),
        {"schema": "risque"},
    )

    drnumero = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="N° de la règle (Identifiant)",
    )
    drmarche = db.Column(db.Numeric(3, 0, asdecimal=False), info="Code marché\t")
    drexercabilite = db.Column(
        db.String(1), info="Exerçabilité (E: Européen, A: Américain)"
    )
    drhorizon = db.Column(
        db.String(1), info="Horizon (D: Début de mois, F: Fin de mois)"
    )
    drspotmin = db.Column(db.Numeric(13, 4), info="Borne min de la fourchette Spot")
    drspotmax = db.Column(db.Numeric(13, 4), info="Borne max de la fourchette Spot")
    drlibelle = db.Column(db.String(100), info="Description de la règle")


class RkdefreglemarcheH(db.Model):
    __tablename__ = "rkdefreglemarche_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dhrnumero = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="N° de la règle (Identifiant)",
    )
    dhrmarche = db.Column(db.Numeric(3, 0, asdecimal=False), info="Code marché\t")
    dhrexercabilite = db.Column(
        db.String(1), info="Exerçabilité (E: Européen, A: Américain)"
    )
    dhrhorizon = db.Column(
        db.String(1), info="Horizon (D: Début de mois, F: Fin de mois)"
    )
    dhrspotmin = db.Column(db.Numeric(13, 4), info="Borne min de la fourchette Spot")
    dhrspotmax = db.Column(db.Numeric(13, 4), info="Borne max de la fourchette Spot")
    dhrlibelle = db.Column(db.String(100), info="Description de la règle")
    dhrhorodate = db.Column(
        db.DateTime, nullable=False, info="Horodate de la mise à jour"
    )
    dhruser = db.Column(db.String(60), info="Utilisateur ayant effectué la mise à jour")
    dhrtrait = db.Column(
        db.String(1), nullable=False, info="Type de traitement de mise à jour"
    )


class Rkdepot(db.Model):
    __tablename__ = "rkdepot"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    decode = db.Column(db.Numeric(4, 0, asdecimal=False), info="Code Depositaires")
    denom = db.Column(db.String(30), info="Libelle des depositaires")
    depays = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Code Pays (cf table RKPAYS)"
    )
    deflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Rkdividende(db.Model):
    __tablename__ = "rkdividende"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint(
            "    DIDATE     >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIEXERCICE >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIPAIEMENT >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIRECORD   >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIUPDATE   >= To_Date('01/01/1900','DD/MM/YYYY') "
        ),
        db.CheckConstraint(
            "    DIDATE     >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIEXERCICE >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIPAIEMENT >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIRECORD   >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIUPDATE   >= To_Date('01/01/1900','DD/MM/YYYY') "
        ),
        db.CheckConstraint(
            "    DIDATE     >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIEXERCICE >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIPAIEMENT >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIRECORD   >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIUPDATE   >= To_Date('01/01/1900','DD/MM/YYYY') "
        ),
        db.CheckConstraint(
            "    DIDATE     >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIEXERCICE >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIPAIEMENT >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIRECORD   >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIUPDATE   >= To_Date('01/01/1900','DD/MM/YYYY') "
        ),
        db.CheckConstraint(
            "    DIDATE     >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIEXERCICE >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIPAIEMENT >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIRECORD   >= To_Date('01/01/1900','DD/MM/YYYY')\nAND DIUPDATE   >= To_Date('01/01/1900','DD/MM/YYYY') "
        ),
        db.CheckConstraint("DIRATIONETBRUT > 0"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dicfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), index=True, info="Code du produit"
    )
    didate = db.Column(db.DateTime, info="Date de detachement du dividende")
    dimontant = db.Column(db.Numeric(13, 5), info="Montant du dividende")
    didev = db.Column(
        db.ForeignKey("exane.devise.dvcfin"), info="Devise du montant du dividende"
    )
    diavf = db.Column(
        db.Numeric(8, 3), info="Montant d avoir fiscal legal en pourcentage"
    )
    diexercice = db.Column(
        db.DateTime, info="Exercice fiscal auquel se rapporte le dividende"
    )
    diacompte = db.Column(db.String(1), info="Solde ou Accompte")
    dioption = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code CFIN du droit d option"
    )
    dipaiement = db.Column(db.DateTime, info="Date de paiement du dividende")
    dicode = db.Column(
        db.Numeric(8, 0, asdecimal=False), index=True, info="Code sequentiel"
    )
    diupdate = db.Column(db.DateTime, info="Date de mise a jour des informations")
    diopda = db.Column(db.String(1), info="Payable en action Oui ou Non")
    diconf = db.Column(db.String(1), info="Dividende confirme Oui ou Non")
    diflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    dirationetbrut = db.Column(
        db.Numeric(6, 3),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Ratio net / brut du dividende en pourcentage",
    )
    dicodeost = db.Column(
        db.Numeric(10, 0, asdecimal=False),
        info="Identifiant interne (Exane) de l'OST => EXANE.OSTSRCDATA(SOSTID) ou TOST.OSTMAIN(OMID).",
    )
    direcord = db.Column(
        db.DateTime, info="Date de constatation de paiement chez le dépositaire"
    )

    devise = db.relationship(
        "Devise",
        primaryjoin="Rkdividende.didev == Devise.dvcfin",
        backref="rkdividendes",
    )


class RkdividendeH(db.Model):
    __tablename__ = "rkdividende_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx_rkdividende_h_castor", "hdicfin", "hdicode", "hdihorodate"),
        db.Index("idx_rkdividende_h", "hdicode", "hdihorodate"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    hdicfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    hdidate = db.Column(db.DateTime)
    hdimontant = db.Column(db.Numeric(13, 5))
    hdidev = db.Column(db.Numeric(8, 0, asdecimal=False))
    hdiavf = db.Column(db.Numeric(8, 3))
    hdiexercice = db.Column(db.DateTime)
    hdiacompte = db.Column(db.String(1))
    hdioption = db.Column(db.Numeric(8, 0, asdecimal=False))
    hdipaiement = db.Column(db.DateTime)
    hdicode = db.Column(db.Numeric(8, 0, asdecimal=False))
    hdiupdate = db.Column(db.DateTime)
    hdiopda = db.Column(db.String(1))
    hdiconf = db.Column(db.String(1))
    hdiflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    hdihorodate = db.Column(db.DateTime)
    hditraitement = db.Column(db.String(1))
    hdirationetbrut = db.Column(
        db.Numeric(6, 3),
        server_default=db.FetchedValue(),
        info="Ratio net / brut du dividende en pourcentage",
    )
    hdirecord = db.Column(
        db.DateTime, info="Date de constatation de paiement chez le dépositaire"
    )
    hdicodeost = db.Column(
        db.Numeric(10, 0, asdecimal=False), info="Identifiant de l'OST"
    )


class RkdividendeRef(db.Model):
    __tablename__ = "rkdividende_ref"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dricfin = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code du produit")
    dridate = db.Column(db.DateTime, info="Date de detachement du dividende")
    drimontant = db.Column(db.Numeric(13, 5), info="Montant du dividende")
    dridev = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Devise du montant du dividende"
    )
    driavf = db.Column(
        db.Numeric(8, 3), info="Montant d avoir fiscal legal en pourcentage"
    )
    driexercice = db.Column(
        db.DateTime, info="Exercice fiscal auquel se rapporte le dividende"
    )
    driacompte = db.Column(db.String(1), info="Solde ou Accompte")
    drioption = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code CFIN du droit d option"
    )
    dripaiement = db.Column(db.DateTime, info="Date de paiement du dividende")
    dricode = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code sequentiel")
    driupdate = db.Column(db.DateTime, info="Date de mise a jour des informations")
    driopda = db.Column(db.String(1), info="Payable en action Oui ou Non")
    driconf = db.Column(db.String(1), info="Dividende confirme Oui ou Non")
    driflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    drdateref = db.Column(
        db.DateTime, info="Date de référence de la sauvegarde des dividendes"
    )
    drirationetbrut = db.Column(
        db.Numeric(6, 3),
        server_default=db.FetchedValue(),
        info="Ratio net / brut du dividende en pourcentage",
    )


class RkdividendeRefH(db.Model):
    __tablename__ = "rkdividende_ref_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    drhicfin = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code du produit")
    drhidate = db.Column(db.DateTime, info="Date de detachement du dividende")
    drhimontant = db.Column(db.Numeric(13, 5), info="Montant du dividende")
    drhidev = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Devise du montant du dividende"
    )
    drhiavf = db.Column(
        db.Numeric(8, 3), info="Montant d avoir fiscal legal en pourcentage"
    )
    drhiexercice = db.Column(
        db.DateTime, info="Exercice fiscal auquel se rapporte le dividende"
    )
    drhiacompte = db.Column(db.String(1), info="Solde ou Accompte")
    drhioption = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code CFIN du droit d option"
    )
    drhipaiement = db.Column(db.DateTime, info="Date de paiement du dividende")
    drhicode = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code sequentiel")
    drhiupdate = db.Column(
        db.DateTime, index=True, info="Date de mise a jour des informations"
    )
    drhiopda = db.Column(db.String(1), info="Payable en action Oui ou Non")
    drhiconf = db.Column(db.String(1), info="Dividende confirme Oui ou Non")
    drhiflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    drhdateref = db.Column(
        db.DateTime,
        index=True,
        info="Date de référence de la sauvegarde des dividendes",
    )
    drhdatehisto = db.Column(
        db.DateTime, server_default=db.FetchedValue(), info="Date de l'historisation"
    )
    drhirationetbrut = db.Column(
        db.Numeric(6, 3),
        server_default=db.FetchedValue(),
        info="Ratio net / brut du dividende en pourcentage",
    )


class Rkdivrisk(db.Model):
    __tablename__ = "rkdivrisk"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    drcfindrv = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code du derive")
    drcode = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code du dividende")
    drdateex = db.Column(db.DateTime, info="Date ex droit au dividende")
    drecart = db.Column(db.Numeric(13, 5), info="Ecart de dividende")
    drflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class RkdivriskH(db.Model):
    __tablename__ = "rkdivrisk_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    drhcfindrv = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code du derive")
    drhcode = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code du dividende")
    drhdateex = db.Column(db.DateTime, info="Date ex droit au dividende")
    drhecart = db.Column(db.Numeric(13, 5), info="Ecart de dividende")
    drhflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    drhhorodate = db.Column(db.DateTime)
    drhtraitement = db.Column(db.String(1))
    drhutilisateur = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Code utilisateur (exane.utilit) qui a effectue la mis à jour",
    )


class Rkdroitbook(db.Model):
    __tablename__ = "rkdroitbook"
    __bind_key__ = "exane_risque"
    __table_args__ = (db.CheckConstraint("dbtypedroit in (0, 1)"), {"schema": "risque"})

    dbuser = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Code User (cf table RKUSER)"
    )
    dbbigbook = db.Column(
        db.Numeric(4, 0, asdecimal=False), info="Code BigBook (cf table RKBIGBOOK)"
    )
    dbflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    dbconvertible = db.Column(db.Numeric(2, 0, asdecimal=False))
    dbwarrant = db.Column(db.Numeric(2, 0, asdecimal=False))
    dbcode = db.Column(db.Integer, primary_key=True, server_default=db.FetchedValue())
    dbtypedroit = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        nullable=False,
        info="Type de droit (lecture ou lecture/ecriture)",
    )


class Rkdsj(db.Model):
    __tablename__ = "rkdsj"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dscfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Code CFIN du produit (cf table RKPRODUIT)",
    )
    dssjac = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Code du sous jacent associe au produit (cf table RKPRODUIT)",
    )
    dsparite = db.Column(db.Numeric(11, 5), info="Exemple : 1 pour 2 --> parite = 1")
    dsproportion = db.Column(
        db.Numeric(11, 5), info="Exemple : 1 pour 2 --> proportion = 2"
    )
    dsupdate = db.Column(db.DateTime, info="Date de mise a jour")
    dsflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Rkecheancebook(db.Model):
    __tablename__ = "rkecheancebook"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_rkecheancebook", "ebbook", "ebecheance"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ebbook = db.Column(db.Numeric(4, 0, asdecimal=False))
    ebecheance = db.Column(db.DateTime)
    ebextype = db.Column(db.String(1))
    ebvol = db.Column(db.Numeric(8, 3))
    ebtauxliq = db.Column(db.Numeric(8, 3))
    ebflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    ebquotite = db.Column(db.Numeric(12, 4))
    ebpivot = db.Column(db.Numeric(8, 3))
    ebpente = db.Column(db.Numeric(8, 3))
    ebcourbure = db.Column(db.Numeric(8, 3))
    ebvolmin = db.Column(db.Numeric(8, 3))
    ebvolmax = db.Column(db.Numeric(8, 3))
    ebmarge = db.Column(db.Numeric(8, 3))


class RkecheancebookH(db.Model):
    __tablename__ = "rkecheancebook_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ebbook = db.Column(db.Numeric(4, 0, asdecimal=False))
    ebecheance = db.Column(db.DateTime)
    ebextype = db.Column(db.String(1))
    ebvol = db.Column(db.Numeric(8, 3))
    ebtauxliq = db.Column(db.Numeric(8, 3))
    ebflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    ebquotite = db.Column(db.Numeric(12, 4))
    ebpivot = db.Column(db.Numeric(8, 3))
    ebpente = db.Column(db.Numeric(8, 3))
    ebcourbure = db.Column(db.Numeric(8, 3))
    ebvolmin = db.Column(db.Numeric(8, 3))
    ebvolmax = db.Column(db.Numeric(8, 3))
    ebdate = db.Column(db.DateTime, nullable=False)
    ebmarge = db.Column(db.Numeric(8, 3))


class Rkemission(db.Model):
    __tablename__ = "rkemission"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    emcfin = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code du produit")
    emissuer = db.Column(db.Numeric(4, 0, asdecimal=False), info="Code emetteur")
    emgarant = db.Column(db.Numeric(4, 0, asdecimal=False), info="Code garant")
    emisdate = db.Column(db.DateTime, info="Date emission")
    emispaiement = db.Column(db.DateTime, info="Date de mise en paiement")
    emisprix = db.Column(db.Numeric(10, 2), info="Prix d emission")
    emnominal = db.Column(
        db.Numeric(15, 2), info="Montant du nominal en devise de nominal"
    )
    emdevnominal = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Devise du nominal ou de reference"
    )
    emisdesc = db.Column(db.String(30), info="Description de l emission")
    emisdetail = db.Column(db.String(30), info="Detail de l emission")
    emnomport = db.Column(db.String(1), info="N nominatif P porteur")
    emprixpoint = db.Column(db.Numeric(10, 2), info="Prix de point")
    emcapiinit = db.Column(db.Numeric(18, 2), info="Capitalisation initiale")
    emflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Rkexercicefixingseuil(db.Model):
    __tablename__ = "rkexercicefixingseuil"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    esbigbook = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code du portefeuille",
    )
    escfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code du produit",
    )
    esseuil = db.Column(db.Numeric(8, 3), info="Valeur du seuil en pourcentage")


class Rkfamille(db.Model):
    __tablename__ = "rkfamille"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    facode = db.Column(db.Numeric(3, 0, asdecimal=False))
    faappli = db.Column(db.Numeric(3, 0, asdecimal=False))
    falibelle = db.Column(db.String(32))
    faflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Rkfamilleop(db.Model):
    __tablename__ = "rkfamilleop"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    focode = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False, unique=True)
    fonom = db.Column(db.String(30), nullable=False)
    foflag = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)


class Rkfiltre(db.Model):
    __tablename__ = "rkfiltre"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    flcode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    flsource = db.Column(db.Numeric(8, 0, asdecimal=False))
    fldatemodification = db.Column(db.DateTime)
    fldatedebut = db.Column(db.DateTime)
    fldatefin = db.Column(db.DateTime)
    flheuredebut = db.Column(db.DateTime)
    flheurefin = db.Column(db.DateTime)
    flmaturitemin = db.Column(db.DateTime)
    flmaturitemax = db.Column(db.DateTime)
    flspotmin = db.Column(db.Numeric(12, 3))
    flspotmax = db.Column(db.Numeric(12, 3))
    flstrikemin = db.Column(db.Numeric(12, 3))
    flstrikemax = db.Column(db.Numeric(12, 3))
    flvolumemin = db.Column(db.Numeric(8, 3))
    flvolumemax = db.Column(db.Numeric(8, 3))
    fltype = db.Column(db.Numeric(2, 0, asdecimal=False))
    fltypeoption = db.Column(db.String(1))
    flexercabilite = db.Column(db.String(1))


class Rkfin(db.Model):
    __tablename__ = "rkfin"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    fidate = db.Column(db.DateTime, index=True, info="Date")
    fibook = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        index=True,
        info="Sous portefeuille (RKDEFBIGBOOK)",
    )
    ficfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        index=True,
        info="Code du produit (RKPRODUIT)",
    )
    ficompte = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="Code compte (RKCOMPTE)"
    )
    fidev = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code devise (RKPRODUIT)")
    fipljour = db.Column(db.Numeric(asdecimal=False), info="P\\ jour")
    fiplcumul = db.Column(db.Numeric(asdecimal=False), info="P\\ cumule")
    fiafjour = db.Column(db.Numeric(asdecimal=False), info="Avoirs fiscaux jour")
    fiafcumul = db.Column(db.Numeric(asdecimal=False), info="Avoirs fiscaux cumules")
    fifraisjour = db.Column(db.Numeric(asdecimal=False), info="Frais divers jour")
    fifraiscumul = db.Column(db.Numeric(asdecimal=False), info="Frais divers cumules")
    fisolde = db.Column(db.Numeric(asdecimal=False), info="Solde espece")
    ficours = db.Column(db.Numeric(asdecimal=False), info="Cour de valorisation")
    fichange = db.Column(
        db.Numeric(13, 5), info="Cours de change Devise du nominal / Devise de cotation"
    )
    fiflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    fiprixtheo = db.Column(db.Numeric(asdecimal=False))
    fiecartvalojour = db.Column(db.Numeric(asdecimal=False))
    fiecartvalocumul = db.Column(db.Numeric(asdecimal=False))
    fiecartvalodev = db.Column(db.Numeric(asdecimal=False))
    fitypepnl = db.Column(db.String(1))


class RkfinH(db.Model):
    __tablename__ = "rkfin_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    fidate = db.Column(db.DateTime)
    fibook = db.Column(db.Numeric(5, 0, asdecimal=False))
    ficfin = db.Column(db.Numeric(8, 0, asdecimal=False), index=True)
    ficompte = db.Column(db.Numeric(5, 0, asdecimal=False))
    fidev = db.Column(db.Numeric(8, 0, asdecimal=False))
    fipljour = db.Column(db.Numeric(18, 2))
    fiplcumul = db.Column(db.Numeric(18, 2))
    fiafjour = db.Column(db.Numeric(10, 2))
    fiafcumul = db.Column(db.Numeric(12, 2))
    fifraisjour = db.Column(db.Numeric(10, 2))
    fifraiscumul = db.Column(db.Numeric(12, 2))
    fisolde = db.Column(db.Numeric(18, 2))
    ficours = db.Column(db.Numeric(19, 10))
    fichange = db.Column(db.Numeric(13, 5))
    fiflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    fiprixtheo = db.Column(db.Numeric(19, 10))
    fiecartvalojour = db.Column(db.Numeric(18, 2))
    fiecartvalocumul = db.Column(db.Numeric(18, 2))
    fiecartvalodev = db.Column(db.Numeric(8, 0, asdecimal=False))


class RkfinRef(db.Model):
    __tablename__ = "rkfin_ref"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    firdate = db.Column(db.DateTime, nullable=False, index=True, info="Date")
    firbook = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Code sous-portefeuille"
    )
    fircfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="Cfin Instrument",
    )
    fircompte = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Compte"
    )
    firdev = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False, info="Devise")
    firpljour = db.Column(db.Numeric(asdecimal=False), nullable=False, info="PnL Jour")
    firplcumul = db.Column(
        db.Numeric(asdecimal=False), nullable=False, info="PnL Cumule"
    )
    firfraisjour = db.Column(db.Numeric(asdecimal=False), info="Frais Jour")
    firfraiscumul = db.Column(db.Numeric(asdecimal=False), info="Frais Cumule")
    firsolde = db.Column(db.Numeric(asdecimal=False), nullable=False, info="Solde")
    fircours = db.Column(db.Numeric(asdecimal=False), nullable=False, info="Cours")
    firprixtheo = db.Column(db.Numeric(asdecimal=False), info="Prix theo")
    firecartvalojour = db.Column(db.Numeric(asdecimal=False), info="Ecart Valo Jour")
    firecartvalocumul = db.Column(db.Numeric(asdecimal=False), info="Ecart Valo Cumule")
    firecartvalodev = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Devise Ecart Valo"
    )
    firflag = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Flag de suppression"
    )


class Rkfinancement(db.Model):
    __tablename__ = "rkfinancement"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx_rkfinancement", "fidate", "fibook", "fidevise"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    fibook = db.Column(db.Numeric(5, 0, asdecimal=False))
    fidate = db.Column(db.DateTime)
    fifinancementjour = db.Column(db.Numeric(asdecimal=False))
    fifinancementcumule = db.Column(db.Numeric(asdecimal=False))
    fidevise = db.Column(db.Numeric(8, 0, asdecimal=False))
    fiflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    fitypepnl = db.Column(db.String(1))


class RkfinancementRef(db.Model):
    __tablename__ = "rkfinancement_ref"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    firdate = db.Column(db.DateTime, nullable=False, info="Date")
    firbook = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Code sous-portefeuille"
    )
    firdevise = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Devise"
    )
    firfinancementjour = db.Column(
        db.Numeric(asdecimal=False), nullable=False, info="Financement Jour"
    )
    firfinancementcumule = db.Column(
        db.Numeric(asdecimal=False), nullable=False, info="Financement Cumule"
    )
    firflag = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Flag de suppression"
    )


class Rkfinbook(db.Model):
    __tablename__ = "rkfinbook"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx_rkfinbook", "fbbook", "fbdate"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    fbdate = db.Column(db.DateTime)
    fbbook = db.Column(db.Numeric(5, 0, asdecimal=False))
    fbpnl = db.Column(db.Numeric(asdecimal=False))
    fbfrais = db.Column(db.Numeric(asdecimal=False))
    fbflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    fbtypepnl = db.Column(db.String(1))


class RkfinbookRef(db.Model):
    __tablename__ = "rkfinbook_ref"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    fbrdate = db.Column(db.DateTime, nullable=False, info="Date")
    fbrbook = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Code sous-portefeuille"
    )
    fbrpnl = db.Column(db.Numeric(18, 2), nullable=False, info="PnL")
    fbrfrais = db.Column(db.Numeric(18, 2), nullable=False, info="Frais")
    fbrflag = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Flag de suppression"
    )


class Rkfut(db.Model):
    __tablename__ = "rkfut"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    fucfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    futick = db.Column(db.Numeric(10, 2))
    fudeposit = db.Column(db.Numeric(12, 2))
    fumaturite = db.Column(db.DateTime)
    fuflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class Rkfutrisque(db.Model):
    __tablename__ = "rkfutrisque"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    fucfin = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code du produit")
    futick = db.Column(db.Numeric(10, 2), info="Pas de cotation du futur")
    fudeposit = db.Column(db.Numeric(12, 2), info="Deposit pour un contrat")
    fumaturite = db.Column(db.DateTime, info="Maturite")
    futauxcourt = db.Column(db.Numeric(8, 4), info="Taux court terme")
    fudatecomptant = db.Column(
        db.DateTime, info="Date de negociation au comptant (Notionnel)"
    )
    fucoefopda = db.Column(db.Numeric(8, 3), info="Coef OPDA")
    fucoefaf = db.Column(db.Numeric(8, 3), info="Coef avoir fiscal")
    fusoulte = db.Column(db.Numeric(8, 2), info="Soulte de conversion")
    furegl = db.Column(db.String(1), info="Mode de reglement C T F R M")
    fucouv = db.Column(db.String(1), info="Type de couverture C R")
    fuassim = db.Column(db.String(1), info="Taux notionnel")
    fufacial = db.Column(db.Numeric(11, 5))
    fuflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    fubase = db.Column(db.Numeric(8, 3))


class Rkfuturtrading(db.Model):
    __tablename__ = "rkfuturtrading"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ftbook = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Code sous-portefeuille"
    )
    ftcfinfutur = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Cfin du dernier Futur de trading paramétré",
    )
    ftbasemanuelle = db.Column(db.Numeric(13, 5), info="Valeur de la base manuelle")
    ftflag = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        nullable=False,
        info="Flag Créé, Modifié, Supprimé",
    )


class RkfuturtradingH(db.Model):
    __tablename__ = "rkfuturtrading_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    fhtbook = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Code sous-portefeuille"
    )
    fhtcfinfutur = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Cfin du dernier Futur de trading paramétré",
    )
    fhtbasemanuelle = db.Column(db.Numeric(13, 5), info="Valeur de la base manuelle")
    fhtflag = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        nullable=False,
        info="Flag Créé, Modifié, Supprimé",
    )
    fhthorodate = db.Column(
        db.DateTime, nullable=False, info="Horodate de la mise à jour"
    )
    fhtuser = db.Column(db.String(60), info="Utilisateur ayant effectué la mise à jour")
    fhttrait = db.Column(
        db.String(1), nullable=False, info="Type de traitement de mise à jour"
    )


class Rkgrec(db.Model):
    __tablename__ = "rkgrecs"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx_rkgrecs", "grdatejournee", "grbigbook", "grbook", "grcfin"),
        db.Index("idx1_rkgrecs", "grbook", "grcfin"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    gruser = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    grbigbook = db.Column(db.Numeric(4, 0, asdecimal=False), nullable=False)
    grbook = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    grcfin = db.Column(db.Numeric(8, 0, asdecimal=False), index=True)
    grdate = db.Column(db.DateTime, nullable=False)
    grfinjournee = db.Column(db.String(1), nullable=False)
    grdatejournee = db.Column(db.DateTime)
    grcourssj = db.Column(db.Numeric(asdecimal=False))
    grsjvol = db.Column(db.Numeric(asdecimal=False))
    grtaux = db.Column(db.Numeric(asdecimal=False))
    grecarttaux = db.Column(db.Numeric(asdecimal=False))
    grptbase = db.Column(db.Numeric(asdecimal=False))
    grrepo = db.Column(db.Numeric(asdecimal=False))
    grmodele = db.Column(db.Numeric(asdecimal=False))
    grerrcode = db.Column(db.Numeric(5, 0, asdecimal=False))
    grprixtheo = db.Column(db.Numeric(asdecimal=False))
    grdelta = db.Column(db.Numeric(asdecimal=False))
    grdeltadecay = db.Column(db.Numeric(asdecimal=False))
    grgamma = db.Column(db.Numeric(asdecimal=False))
    grvega = db.Column(db.Numeric(asdecimal=False))
    grtheta = db.Column(db.Numeric(asdecimal=False))
    grrho = db.Column(db.Numeric(asdecimal=False))
    grconvexitetaux = db.Column(db.Numeric(asdecimal=False))
    grduration = db.Column(db.Numeric(asdecimal=False))
    grflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    grthetabe = db.Column(db.Numeric(asdecimal=False))
    grfinancement = db.Column(db.Numeric(asdecimal=False))
    grvegapond = db.Column(db.Numeric(asdecimal=False))
    grsega = db.Column(db.Numeric(asdecimal=False))
    grsensidiv = db.Column(db.Numeric(asdecimal=False))
    grmontantcc = db.Column(db.Numeric(13, 5))
    grdevins = db.Column(db.Numeric(8, 0, asdecimal=False))
    grsensichange = db.Column(db.Numeric(asdecimal=False))
    grmodevalo = db.Column(db.String(1))
    grsensicorrel = db.Column(db.Numeric(asdecimal=False))
    grsensispread = db.Column(db.Numeric(asdecimal=False))
    grsommediv = db.Column(db.Numeric(asdecimal=False))
    grmargerepo = db.Column(db.Numeric(asdecimal=False))
    grprixpayoff = db.Column(db.Numeric(asdecimal=False))
    grtypepnl = db.Column(db.String(1))
    grcoupon = db.Column(db.Numeric(asdecimal=False))


class Rkgrecsref(db.Model):
    __tablename__ = "rkgrecsref"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx_grecbbookdate", "grrbigbook", "grrdatejournee"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    grrbigbook = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    grrbook = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    grrcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    grrindicateur = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    grrvaleur = db.Column(db.Numeric(asdecimal=False), nullable=False)
    grrrefcfin1 = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    grrrefcfin2 = db.Column(db.Numeric(8, 0, asdecimal=False))
    grrdate = db.Column(db.DateTime, nullable=False)
    grrdatejournee = db.Column(db.DateTime, nullable=False)
    grrfinjournee = db.Column(db.String(1), nullable=False)
    grrflag = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    grrtypepnl = db.Column(db.String(1))


class Rkgroupe(db.Model):
    __tablename__ = "rkgroupe"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    grgroupe = db.Column(db.Numeric(2, 0, asdecimal=False), info="Code groupe")
    grlibelle = db.Column(db.String(15), info="Libelle du groupe")
    grflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Rkiasmarge(db.Model):
    __tablename__ = "rkiasmarge"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    iascfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    iasdate = db.Column(db.DateTime, nullable=False)
    iasmarge = db.Column(db.Numeric(12, 5), nullable=False)
    iasstock = db.Column(db.Numeric(13, 0, asdecimal=False), nullable=False)
    iasflag = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    iasbrut = db.Column(db.Numeric(12, 5))


class Rkiasob(db.Model):
    __tablename__ = "rkiasobs"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    iascfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        unique=True,
        info="CFIN DU PRODUIT",
    )
    iasdateobs = db.Column(db.DateTime, info="DATE D'OBSERVABILITÉ")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Rkiasob.iascfin == Instrument.ifcfin",
        backref="rkiasobs",
    )


class RkiasobsH(db.Model):
    __tablename__ = "rkiasobs_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    iashcfin = db.Column(
        db.Numeric(asdecimal=False), nullable=False, info="CFIN DU PRODUIT"
    )
    iashdateobs = db.Column(db.DateTime, info="DATE D'OBSERVABILITÉ")
    iashhorodate = db.Column(db.DateTime, nullable=False)


class Rkinstrumentsgroup(db.Model):
    __tablename__ = "rkinstrumentsgroups"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("ak_rkinstrumentsgroups", "username", "instrumentid"),
        {"schema": "risque"},
    )

    username = db.Column(
        db.String(60),
        primary_key=True,
        nullable=False,
        info="The active directory (AD) name of the group's owner",
    )
    grouppath = db.Column(
        db.String(2000),
        primary_key=True,
        nullable=False,
        info="The group's path: parent/child/grandChild/...",
    )
    instrumentid = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="The identifier of an instrument belonging to the group",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Rkinstrumentsgroup.instrumentid == Instrument.ifcfin",
        backref="rkinstrumentsgroups",
    )


class Rkinsttemplate(db.Model):
    __tablename__ = "rkinsttemplate"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("itAutomaticFT in ('Y', 'N')"),
        db.CheckConstraint("itAutomaticNotice in ('Y', 'N')"),
        db.CheckConstraint("itAutomaticTS IN ('Y', 'N')"),
        db.CheckConstraint("itDeleted IN ('Y', 'N')"),
        db.CheckConstraint("itFTRequired in ('Y', 'N')"),
        db.CheckConstraint("itInstGenFromTemplate IN ( 'Y', 'N' )"),
        db.CheckConstraint("itInstGenFromTemplate IN ( 'Y', 'N' )"),
        db.CheckConstraint("itNoticeRequired in ('Y', 'N')"),
        db.CheckConstraint("itOtc IN ('Y', 'N')"),
        db.CheckConstraint("itWithTermsheet IN ('Y', 'N')"),
        {"schema": "risque"},
    )

    itid = db.Column(
        db.Numeric(12, 0, asdecimal=False),
        primary_key=True,
        info="The ID of the template",
    )
    itcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        unique=True,
        info="The ID of the generated instrument",
    )
    itname = db.Column(db.String(60), info="The name of the generated instrument")
    itinstrumenttype = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="The generated instrument type",
    )
    itcurrency = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="The currency ID of the generated instrument",
    )
    itcountry = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="The country ID of the generated instrument",
    )
    itbook = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        info="The book ID of the generated instrument",
    )
    itissuer = db.Column(
        db.Numeric(12, 0, asdecimal=False),
        info="The issuer ID of of the generated instrument",
    )
    itissuedate = db.Column(
        db.DateTime, info="The issue date of the generated instrument"
    )
    itissueprice = db.Column(
        db.Numeric(18, 5), info="The issue price of the generated instrument"
    )
    itissuequantity = db.Column(
        db.Numeric(23, 5), info="The issue quantity of the generated instrument"
    )
    itnominal = db.Column(
        db.Numeric(18, 5), info="The nominal of the generated instrument"
    )
    itmaturitydate = db.Column(
        db.DateTime, info="The maturity date of the generated instrument"
    )
    itpremiumrule = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="The premium rule of the generated instrument",
    )
    itquotationmode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        nullable=False,
        info="The quotation mode (in price, in percent, etc.) of the generated instrument",
    )
    itmarket = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="The market ID of the generated instrument",
    )
    itclean = db.Column(
        db.String(1),
        nullable=False,
        info="The quotation type (clean or dirty) of the generated instrument",
    )
    itobsmargindate = db.Column(
        db.DateTime, info="The obs. margin date of the generated instrument"
    )
    itinstgenfromtemplate = db.Column(
        db.String(1), info="Indicates whether an OTC is created with the instrument"
    )
    itlastmodificationdate = db.Column(
        db.DateTime, nullable=False, info="The last modification date of the template"
    )
    itlastmodificationuser = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="The ID of the user that performed the last modification of the template",
    )
    itversion = db.Column(
        db.Numeric(6, 0, asdecimal=False),
        nullable=False,
        info="The version of the instrument template",
    )
    itinsttemplatetype = db.Column(
        db.String(30),
        nullable=False,
        info="A descriminator to distinguich the different types of instrument templates",
    )
    itlastmodificationcomment = db.Column(
        db.String(256), info="The user comments regarding the last changes"
    )
    itpledgecost = db.Column(db.Numeric(18, 5), info="The pledge cost")
    itvalidationstate = db.Column(
        db.String(20), info="The instrument template validation status"
    )
    itinstgendate = db.Column(db.DateTime, info="The instrument last generation date")
    itwithtermsheet = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indicates whether the template is for an issue with termsheet",
    )
    itaccountid = db.Column(db.String(60), info="Account ID")
    itcategory = db.Column(db.Numeric(8, 0, asdecimal=False), info="Category")
    itclearerid = db.Column(db.Numeric(8, 0, asdecimal=False), info="Clearer ID")
    itcommercialname = db.Column(db.String(120), info="Commercial name")
    itcommissionpaid = db.Column(
        db.String(1), server_default=db.FetchedValue(), info="Commission paid"
    )
    itcomplexity = db.Column(db.Numeric(8, 0, asdecimal=False), info="Complexity")
    itdocumenttype = db.Column(db.String(30), info="Document type")
    itisintype = db.Column(db.String(2), info="ISIN type")
    itlatamclause = db.Column(
        db.String(1), server_default=db.FetchedValue(), info="LATAM clause"
    )
    itmoodysrating = db.Column(db.Numeric(3, 0, asdecimal=False), info="Moody's rating")
    itpayingagentid = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Paying agent ID"
    )
    itpayoffrisk = db.Column(db.Numeric(8, 0, asdecimal=False), info="Payoff risk")
    itplacementcountryid = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Placement country ID"
    )
    itplacementtype = db.Column(db.String(30), info="Placement type")
    itpledgetype = db.Column(db.Numeric(8, 0, asdecimal=False), info="Pledge type")
    itpledged = db.Column(
        db.String(1), server_default=db.FetchedValue(), info="Pledged"
    )
    itredemptiontype = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Redemption type"
    )
    itsecondarymarketspread = db.Column(
        db.Numeric(13, 5), info="Secondary market spread"
    )
    itsecondarymarkettype = db.Column(db.String(30), info="Secondary market type")
    itstandardandpoorsrating = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Standard and Poor's rating"
    )
    itsvspcode = db.Column(db.Numeric(10, 0, asdecimal=False), info="SVSP code")
    itswisstaxclause = db.Column(
        db.String(1), server_default=db.FetchedValue(), info="Swiss tax clause"
    )
    ittradedate = db.Column(db.DateTime, info="Trade date")
    itsalesid = db.Column(db.Numeric(8, 0, asdecimal=False), info="Sales ID")
    ittraderid = db.Column(db.Numeric(8, 0, asdecimal=False), info="Trader ID")
    itisincode = db.Column(db.String(12), info="ISIN code")
    itcommoncode = db.Column(db.String(12), info="Common code")
    ittelekurscode = db.Column(db.String(12), info="Telekurs code")
    itserialnumber = db.Column(db.String(12), info="Serial number")
    itmaxcommissionrate = db.Column(db.Numeric(18, 7), info="Max. commission rate")
    ittermsheetid = db.Column(db.String(36), info="Term sheet ID")
    itautomaticts = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indicates whether the termsheet of an issue is automatically generated",
    )
    itdeleted = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indicates whether the template is deleted",
    )
    itmintradingsize = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Min trading size"
    )
    itcamelotcode = db.Column(db.String(128), info="The Camelot code")
    itnoticeid = db.Column(db.String(36), info="Notice ID")
    itautomaticnotice = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indicates whether the issue is in automatic notice",
    )
    itautomaticft = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indicates whether the issue is in automatic FT",
    )
    itftrequired = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indicates whether the generation of final terms is required",
    )
    itnoticerequired = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indicates whether the notice is required",
    )
    itfinaltermsid = db.Column(db.String(36), info="The final terms document id")
    itsalesdeskid = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="The sales' desk id when the issue was created",
    )
    itsalesdeskname = db.Column(
        db.String(50), info="The sales' desk name when the issue was created"
    )
    itotc = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indicates if the template is OTC (or security)",
    )
    itsellerid = db.Column(
        db.ForeignKey("exane.tiers.ticode"), info="Id of the seller of the OTC template"
    )
    itbuyerid = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Id of the buyer of the OTC template"
    )
    itstartdate = db.Column(
        db.DateTime, info="Start date of the OTC contract of the template"
    )
    it871mclause = db.Column(db.String(30), info="The section 871m clause")
    ittermsheetlasteditiondate = db.Column(
        db.DateTime, info="The last edition date of the term-sheet"
    )
    itmonetarypart = db.Column(
        db.Numeric(18, 7), info="The monetary part of the swiss tax clause"
    )
    itoptionalpart = db.Column(
        db.Numeric(18, 7), info="The optional part of the swiss tax clause"
    )
    itfloatingrateindex = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="The floating rate index for a template swap",
    )
    itfloatingratespread = db.Column(
        db.Numeric(18, 7), info="The floating rate spread for a template swap"
    )
    itfloatinglegcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="The CFIN of the floating leg for a template swap",
    )
    itinstrumentlegcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="The CFIN of the instrument leg for a template swap",
    )
    itkidisrequired = db.Column(db.String(1), info="is kid required")
    itmaturitytype = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="maturity type or open date"
    )
    itissuerrefdate = db.Column(db.DateTime, info="reference date for issuer")
    itholderrefdate = db.Column(db.DateTime, info="reference date for holder")
    itclienttype = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="target marget client type"
    )
    itisincomepaying = db.Column(db.String(1), info="client objective income paying")
    itcapitalpreservation = db.Column(
        db.String(1), info="client objective capital preservation"
    )
    itgrowth = db.Column(db.String(1), info="client objective growth")
    ithedge = db.Column(db.String(1), info="client objective hedge")
    itleverage = db.Column(db.String(1), info="client objective leverage")
    itexpirationdate = db.Column(
        db.DateTime, info="The date at which the issue matures or is early redeemed"
    )
    itemtisrequired = db.Column(db.String(1), info="Indicates if the EMT is required")
    itfronttypo = db.Column(db.Numeric(5, 0, asdecimal=False), info="Front typology")
    itriccode = db.Column(db.String(12), info="The RIC code of the instrument")
    ittspublicationcount = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Termsheet publication count"
    )
    itcrescendoswapcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Cfin of the linked crescendo swap"
    )
    ittermsheetmintradingsize = db.Column(
        db.Numeric(asdecimal=False), info="Termsheet minimun trading size"
    )

    tier = db.relationship(
        "Tier",
        primaryjoin="Rkinsttemplate.itbuyerid == Tier.ticode",
        backref="tier_rkinsttemplates",
    )
    tier1 = db.relationship(
        "Tier",
        primaryjoin="Rkinsttemplate.itsellerid == Tier.ticode",
        backref="tier_rkinsttemplates_0",
    )


class Rkissuer(db.Model):
    __tablename__ = "rkissuer"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    isissuer = db.Column(db.Numeric(4, 0, asdecimal=False), info="Code Emetteur")
    isnom = db.Column(db.String(30), info="Nom de emetteur")
    isflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Rklimiteautomate(db.Model):
    __tablename__ = "rklimiteautomate"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    labook = db.Column(db.Numeric(5, 0, asdecimal=False))
    lacfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    laqtemax = db.Column(db.Numeric(asdecimal=False))
    ladeltamax = db.Column(db.Numeric(asdecimal=False))
    laactif = db.Column(db.String(1))
    lavarveille = db.Column(db.Numeric(asdecimal=False))
    lavarinst = db.Column(db.Numeric(asdecimal=False))


class RklimiteautomateH(db.Model):
    __tablename__ = "rklimiteautomate_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    lhabook = db.Column(db.Numeric(5, 0, asdecimal=False))
    lhacfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    lhaqtemax = db.Column(db.Numeric(asdecimal=False))
    lhadeltamax = db.Column(db.Numeric(asdecimal=False))
    lhaactif = db.Column(db.String(1))
    lhavarveille = db.Column(db.Numeric(asdecimal=False))
    lhavarinst = db.Column(db.Numeric(asdecimal=False))
    lhahorodate = db.Column(
        db.DateTime, nullable=False, info="Horodate de la mise à jour"
    )
    lhauser = db.Column(db.String(60), info="Utilisateur ayant effectué la mise à jour")
    lhatrait = db.Column(
        db.String(1), nullable=False, info="Type de traitement de mise à jour"
    )


class Rkmaskcot(db.Model):
    __tablename__ = "rkmaskcot"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    mcbook = db.Column(db.Numeric(8, 0, asdecimal=False))
    mcpas = db.Column(db.Numeric(12, 3))


class Rkmffuture(db.Model):
    __tablename__ = "rkmffuture"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    mfid = db.Column(
        db.Numeric(15, 0, asdecimal=False), primary_key=True, info="ID of the future"
    )
    mftempid = db.Column(
        db.ForeignKey("risque.rkminifuturetemplate.mfid"),
        nullable=False,
        info="ID of the mini future template",
    )
    mfname = db.Column(db.String(60))
    mfnodriftcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Associated no drift cfin"
    )
    mfcurrencyid = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="ID of the currency of the future"
    )
    mfcurrency = db.Column(db.String(3), info="Currency of the future")
    mfmaturitydate = db.Column(db.DateTime, info="Maturity date of the future")
    mfadjustedstrike = db.Column(
        db.Numeric(asdecimal=False), info="Adjusted strike after future rolling"
    )
    mfadjustedbarrier = db.Column(
        db.Numeric(asdecimal=False), info="Adjusted barrier after future rolling"
    )
    mfroll = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="True if the future is a roll",
    )

    rkminifuturetemplate = db.relationship(
        "Rkminifuturetemplate",
        primaryjoin="Rkmffuture.mftempid == Rkminifuturetemplate.mfid",
        backref="rkmffutures",
    )


class Rkmfunderlying(db.Model):
    __tablename__ = "rkmfunderlying"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    mfid = db.Column(
        db.Numeric(15, 0, asdecimal=False),
        primary_key=True,
        info="The ID of the underlying",
    )
    mftempid = db.Column(
        db.ForeignKey("risque.rkminifuturetemplate.mfid"),
        nullable=False,
        index=True,
        info="The ID of the template. Cannot be updated.",
    )
    mftechnicalcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Technical underlying CFIN"
    )
    mffunctionalcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Functional underlying CFIN"
    )
    mfinitrefvalue = db.Column(db.Numeric(18, 5), info="Initial reference value")
    mfcurrencyid = db.Column(
        db.Numeric(18, 7), info="The ID of the currency of the underlying"
    )
    mfcurrency = db.Column(
        db.String(3), info="The iso name of the currency of the underlying"
    )
    mffronttypo = db.Column(db.String(30), info="The front typo of the underlying")

    rkminifuturetemplate = db.relationship(
        "Rkminifuturetemplate",
        primaryjoin="Rkmfunderlying.mftempid == Rkminifuturetemplate.mfid",
        backref="rkmfunderlyings",
    )


class Rkmigstrike(db.Model):
    __tablename__ = "rkmigstrike"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint(" mstype in ('O','L','T')"),
        db.CheckConstraint(" mstype in ('O','L','T')"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    mscode = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="ancien CFIN, present dans rkstrike"
    )
    mscfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Nouveau CFIN, present dans Instrument, Produit , Derives....",
    )
    mstype = db.Column(db.String(1), info="TYpe d'options O=OTC, L=Listé, T=Titres")


class Rkminifuturetemplate(db.Model):
    __tablename__ = "rkminifuturetemplate"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("mfdiv in ('Y', 'N')"),
        db.CheckConstraint("mftax in ('Y', 'N')"),
        {"schema": "risque"},
    )

    mfid = db.Column(
        db.Numeric(15, 0, asdecimal=False), primary_key=True, info="Technical Id"
    )
    mfquotity = db.Column(
        db.Numeric(9, 0, asdecimal=False), info="Min quantity to have"
    )
    mfcontracttype = db.Column(db.String(20), info="Bull or bear")
    mfproportionproduct = db.Column(
        db.Numeric(asdecimal=False),
        info="Multplier to apply to redemption value for product",
    )
    mfproportionul = db.Column(
        db.Numeric(asdecimal=False),
        info="Multplier to apply to redemption value for underlying",
    )
    mfstrike = db.Column(
        db.Numeric(asdecimal=False), nullable=False, info="Strike of the mini future"
    )
    mfprotectionbarriertype = db.Column(
        db.String(20), info="TYpe of protection barrier"
    )
    mfprotectionbarrier = db.Column(
        db.Numeric(asdecimal=False), info="Protection barrier value"
    )
    mfwordingstoploss = db.Column(
        db.Numeric(asdecimal=False), info="Way of barrier check"
    )
    mfcompoquanto = db.Column(
        db.String(20),
        info="If underlying currency is different from product currency, which currency to use in delivery.",
    )
    mfinitialfx = db.Column(
        db.Numeric(asdecimal=False), info="Initial forex rate to use"
    )
    mfdiv = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="True if the underlying is a stock and a dividend is paid to client",
    )
    mftax = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="if true, tax is deduced from amount of div paid to client",
    )
    mftaxrate = db.Column(
        db.Numeric(asdecimal=False), info="rate of tax applied to dividend amount"
    )
    mffirstlegweight = db.Column(
        db.Numeric(asdecimal=False), info="Weight of first leg"
    )
    mfsecondlegweight = db.Column(
        db.Numeric(asdecimal=False), info="Weight of second leg"
    )
    mffirstlegcurrencyid = db.Column(
        db.Numeric(asdecimal=False), info="Currency Id of first leg"
    )
    mfsecondlegcurrencyid = db.Column(
        db.Numeric(asdecimal=False), info="Currency Id of second leg"
    )
    mffirstlegusemodellocal = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Use model local of first leg",
    )
    mfsecondlegusemodellocal = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Use model local of second leg",
    )
    mfslow = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="The number of steps of the slow mode"
    )
    mffast = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="The number of steps of the fast mode"
    )
    mfnbdays = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="The number of days between issue and maturity",
    )
    mfinitialvaluationdate = db.Column(db.DateTime)
    mffinalfixingdate = db.Column(db.DateTime, info="The final fixing date")
    mfpaymentdate = db.Column(db.DateTime, info="The payment date")
    mfinitrefvaluestype = db.Column(
        db.String(36), info="Underlyings initial reference values type"
    )
    mfrollfuture = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info=" true if the underlying is a future and is rolled or will be rolled",
    )
    mffirstnotifdate = db.Column(
        db.DateTime, info="First notif date for commo underlyings"
    )
    mfnominalleverage = db.Column(db.Numeric(asdecimal=False), info=" Nominal Leverage")
    mfinitclosesupdatedate = db.Column(
        db.DateTime,
        info="The date at which the initial closes must be updated for a mini future with a fixing date in the future",
    )


class Rkmoderl(db.Model):
    __tablename__ = "rkmoderl"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rlmoderl = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Code Mode reglement livraison"
    )
    rllibelle = db.Column(db.String(15), info="Libelle du mode de reglement livraison")
    rlflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Rkmotifrefu(db.Model):
    __tablename__ = "rkmotifrefus"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    mrcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du motif du refus",
    )
    mrlibelle = db.Column(
        db.String(80), nullable=False, info="Libéllé du motif du refus"
    )


class Rkmotifrefuscoupon(db.Model):
    __tablename__ = "rkmotifrefuscoupons"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    mrcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du motif du refus",
    )
    mrlibelle = db.Column(
        db.String(80), nullable=False, info="Libéllé du motif du refus"
    )


class Rknappedynamique(db.Model):
    __tablename__ = "rknappedynamique"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ndcode = db.Column(db.ForeignKey("risque.rknappestatique.nscode"))
    ndparam1 = db.Column(db.Numeric(18, 5))
    ndparam2 = db.Column(db.Numeric(18, 5))
    ndparam3 = db.Column(db.Numeric(18, 5))
    ndparam4 = db.Column(db.Numeric(18, 5))
    ndparam5 = db.Column(db.Numeric(18, 5))
    ndparam6 = db.Column(db.Numeric(18, 5))
    ndparam7 = db.Column(db.Numeric(18, 5))
    ndparam8 = db.Column(db.Numeric(18, 5))
    ndparam9 = db.Column(db.Numeric(18, 5))
    ndparam10 = db.Column(db.Numeric(18, 5))

    rknappestatique = db.relationship(
        "Rknappestatique",
        primaryjoin="Rknappedynamique.ndcode == Rknappestatique.nscode",
        backref="rknappedynamiques",
    )


class RknappedynamiqueH(db.Model):
    __tablename__ = "rknappedynamique_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nhcode = db.Column(db.ForeignKey("risque.rknappestatique.nscode"), nullable=False)
    nhdate = db.Column(db.DateTime, nullable=False)
    nhparam1 = db.Column(db.Numeric(18, 5))
    nhparam2 = db.Column(db.Numeric(18, 5))
    nhparam3 = db.Column(db.Numeric(18, 5))
    nhparam4 = db.Column(db.Numeric(18, 5))
    nhparam5 = db.Column(db.Numeric(18, 5))
    nhparam6 = db.Column(db.Numeric(18, 5))
    nhparam7 = db.Column(db.Numeric(18, 5))
    nhparam8 = db.Column(db.Numeric(18, 5))
    nhparam9 = db.Column(db.Numeric(18, 5))
    nhparam10 = db.Column(db.Numeric(18, 5))

    rknappestatique = db.relationship(
        "Rknappestatique",
        primaryjoin="RknappedynamiqueH.nhcode == Rknappestatique.nscode",
        backref="rknappedynamique_hs",
    )


class Rknappestatique(db.Model):
    __tablename__ = "rknappestatique"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    nscode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    nslibelle = db.Column(db.String(60))
    nscfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    nsbook = db.Column(db.Numeric(4, 0, asdecimal=False))
    nstypenappe = db.Column(db.Numeric(2, 0, asdecimal=False))
    nstypevol = db.Column(db.String(1))
    nstypeopt = db.Column(db.String(1))
    nsintvol = db.Column(db.String(1))
    nstypepivot = db.Column(db.String(1))
    nscodefiltre = db.Column(db.ForeignKey("risque.rkfiltre.flcode"))

    rkfiltre = db.relationship(
        "Rkfiltre",
        primaryjoin="Rknappestatique.nscodefiltre == Rkfiltre.flcode",
        backref="rknappestatiques",
    )


class Rknav(db.Model):
    __tablename__ = "rknav"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("naflag in (1,2,3)"),
        db.CheckConstraint("naflag in (1,2,3)"),
        {"schema": "risque"},
    )

    nadate = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="date de stockage de l actif net",
    )
    nabigbook = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code du portefeuille (cf RKBIGBOOK.BBBIGBOOK)",
    )
    naactifnet = db.Column(
        db.Numeric(18, 2),
        nullable=False,
        info="Montant de l actif net exprime dans la devise de reference du portefeuille",
    )
    naflag = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        server_default=db.FetchedValue(),
        info="Statut de l enregistrement 1(cree), 2(mis a jour), 3(efface)",
    )


class Rkongletoperation(db.Model):
    __tablename__ = "rkongletoperation"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ooid = db.Column(db.Numeric(8, 0, asdecimal=False), unique=True)
    oobigbook = db.Column(db.Numeric(4, 0, asdecimal=False))
    oolibelle = db.Column(db.String(50))
    ooflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class RkopeconfirmationH(db.Model):
    __tablename__ = "rkopeconfirmation_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("uk_rkopeconfirmation_h", "chopnumero", "chhorodate"),
        {"schema": "risque"},
    )

    chcode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code du Statut de la Confirmation, saisie par sequence risque.seq_rkopeconfirmation_h",
    )
    chhorodate = db.Column(
        db.DateTime,
        nullable=False,
        info="Date à laquelle a eu lieu la modification de statut de confirmation",
    )
    chopnumero = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Numero de l'opération à se réfere la confirmation",
    )
    chstatut = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="Nouveau statut de confirmation",
    )
    chcomment = db.Column(
        db.String(300),
        info="Commentaire optionnel pour expliquer le changement de statut de confirmation.",
    )
    chdocument = db.Column(
        db.String(300),
        info="Chemin optionel vers un document pouvant justifier le nouveau statut",
    )
    chflag = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Statut de la ligne 1 : Active / 3 Supprimée.",
    )


class Rkoperation(db.Model):
    __tablename__ = "rkoperation"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint(" optypevolcker IN ('C', 'M', 'J', 'K', 'T') "),
        db.CheckConstraint("OPDATE = TRUNC(OPDATE) AND OPDATERL = TRUNC(OPDATERL)"),
        db.CheckConstraint("OPDATE = TRUNC(OPDATE) AND OPDATERL = TRUNC(OPDATERL)"),
        db.Index("idx_rkoperation_externalref", "opsysteme", "opexternalref"),
        db.Index("idx_rkoperation_date_book", "opdate", "opbook"),
        db.Index("idx_rkoperation_datenegobook", "opdatenego", "opbook"),
        {"schema": "risque"},
    )
    rowid = db.Column(db.Integer, primary_key=True)

    opbook = db.Column(db.Numeric(5, 0, asdecimal=False), info="Code sous-portefeuille")
    opcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), index=True, info="Code du produit"
    )
    opticket = db.Column(db.String(12), info="Numero de ticket")
    opcompte = db.Column(db.Numeric(5, 0, asdecimal=False), info="Code compte")
    opuser = db.Column(db.Numeric(3, 0, asdecimal=False), info="Code user")
    opquantite = db.Column(db.Numeric(17, 4), info="Quantite")
    opmontant = db.Column(db.Numeric(23, 5), info="Montant")
    opdev = db.Column(db.Numeric(8, 0, asdecimal=False), info="Devise du montant")
    opotype = db.Column(db.Numeric(3, 0, asdecimal=False), info="Code type d operation")
    opdaterl = db.Column(db.DateTime, info="Date de reglement livraison")
    opmoderl = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Code mode de reglement livraison"
    )
    opfrais = db.Column(db.Numeric(22, 15), info="Montant de frais")
    opcptie = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code contrepartie")
    opdate = db.Column(db.DateTime, info="Date de la negociation")
    ophorodate = db.Column(db.DateTime, info="Date/heure de création de l'opération.")
    opstatut = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Status de la negociation"
    )
    opcours = db.Column(db.Numeric(15, 5), info="Cours de la negociation")
    opchange = db.Column(
        db.Numeric(13, 5), info="Taux de change lors de la negociation"
    )
    opmontantcc = db.Column(db.Numeric(16, 8), info="Montant du coupon couru")
    opflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    opquantitebroker = db.Column(db.Numeric(17, 4))
    opprixbroker = db.Column(db.Numeric(21, 5))
    opquantitehedge = db.Column(db.Numeric(13, 0, asdecimal=False))
    opprixhedge = db.Column(db.Numeric(21, 5))
    optiers = db.Column(db.Numeric(asdecimal=False))
    opprovenance = db.Column(db.String(1))
    opportef = db.Column(db.Numeric(8, 0, asdecimal=False))
    opgenerateur = db.Column(db.Numeric(8, 0, asdecimal=False))
    opstyle = db.Column(db.String(1))
    opquotite = db.Column(db.Numeric(12, 4))
    optypesaisie = db.Column(db.Numeric(3, 0, asdecimal=False))
    opcommentaire = db.Column(db.String(256))
    opvendeur = db.Column(db.Numeric(8, 0, asdecimal=False))
    opmargevendeur = db.Column(db.Numeric(12, 5))
    opmargetrader = db.Column(db.Numeric(12, 5))
    opinformation = db.Column(db.Numeric(5, 0, asdecimal=False))
    opnumero = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        # primary_key=True,
        info="Id de la table à renseigner. automatiquement pour Next",
    )
    opannule = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Id de l'opé contrepassée, peut être NULL",
    )
    oporigine = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        index=True,
        info="Id de l'opé qui est remplacée, peut être NULL",
    )
    opdatenego = db.Column(
        db.DateTime, info="Date de négociation de l'opé, peut être NULL"
    )
    opnumechange = db.Column(db.Numeric(8, 0, asdecimal=False))
    opcfinreference = db.Column(db.Numeric(8, 0, asdecimal=False))
    opvalidation = db.Column(db.String(1))
    opmaj = db.Column(
        db.DateTime, index=True, info="Date/heure de mise à jour de l'opération."
    )
    optypecotation = db.Column(
        db.String(1),
        info="Type de cotation (indique si on doit inclure ou non le montant du coupon couru)",
    )
    opmodecotation = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Devise ou % du nominal"
    )
    opcouponpaye = db.Column(
        db.ForeignKey("risque.rkcouponspayes.cpcode"),
        index=True,
        info="N° du coupon payé",
    )
    opversion = db.Column(
        db.Numeric(38, 0, asdecimal=False),
        info="Numéro de version de l'opération (Nb de changements / UPDATE)",
    )
    opparentid = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        index=True,
        info="Parent complex deal ID if this deal is aggregated with at least another deal or complex deal",
    )
    opnominal = db.Column(
        db.Numeric(18, 5), info="Nominal de l instrument de l operation"
    )
    opsysteme = db.Column(
        db.ForeignKey("risque.rksystem.syid"), info="Systeme ayant cree l operation"
    )
    opexternalref = db.Column(
        db.String(36),
        server_default=db.FetchedValue(),
        info="External reference of the deal",
    )
    opexporttomoflag = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="Export to MO Flag for simple deal"
    )
    opbrokertiersprincipal = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Third-party as principal Broker"
    )
    opbrokertierssecondaire = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Third-party as secondary broker"
    )
    opcptietiersprincipal = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Third-party as principal Counterparty"
    )
    opcptietierssecondaire = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Third-party as principal Counterparty"
    )
    opmarche = db.Column(db.String(15), info="Market place of the transaction")
    opentite = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        info="Colonne denormalisee de la table risque.rkbudget pour permettre le partitionnement",
    )
    optcsstate = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="TCS state for simple deal"
    )
    opmostate = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="MO state for simple deal"
    )
    opmontantbrut = db.Column(db.Numeric(23, 5), info="Gross amount")
    opmontantttfi = db.Column(db.Numeric(23, 5), info="Montant de la TTF Italienne")
    oputi = db.Column(
        db.String(52),
        info="Code UTI de la transaction (identificant externe du contrat - Projet EMIR)",
    )
    opmoreconciliation = db.Column(
        db.Numeric(asdecimal=False),
        info="The reconciliation state received from external application (ex. Examatch)",
    )
    opdiscount = db.Column(
        db.Numeric(13, 5),
        info="Montant de la decote concedee sur le produit de la transaction",
    )
    opestflux = db.Column(
        db.String(1), info="Definit si le produit de la transaction est un flux"
    )
    opmargeflux = db.Column(
        db.Numeric(13, 5),
        info="Montant total (marge, commission, decote) genere avant emission du produit de la transaction",
    )
    opcommissionechelonnee = db.Column(db.Numeric(23, 5))
    opetatpolmarge = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Etat de la politique de marge"
    )
    opmargecontrib = db.Column(
        db.Numeric(10, 5),
        info="Marge de contribution de l'instrument d'un deal avec vendeur",
    )
    opinitiateur = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Initiateur de l execution electronique"
    )
    opexecannulraison = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Justification trading pour l'annulation d'une execution",
    )
    opinitialfrontoperator = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Createur de l'operation"
    )
    opyoshiid = db.Column(
        db.String(50),
        index=True,
        info="Identifiant complet de l'execution de la requete Yoshi",
    )
    opdatecreation = db.Column(
        db.DateTime, info="Date de creation a la milliseconde de l'operation"
    )
    opdatemodif = db.Column(
        db.DateTime,
        info="Date de dernier modification a la milliseconde de l'operation",
    )
    opexecutionvenuemic = db.Column(
        db.String(4), info="Execution venue broker MIC code"
    )
    opyoshictpyid = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Yoshi counterparty id"
    )
    opsoulte = db.Column(db.Numeric(23, 5))
    optypevolcker = db.Column(db.String(1), info="Typologie Volcker de l'operation")
    opcommissionia = db.Column(
        db.Numeric(23, 5), info="Prix theorique de l Index advisor"
    )
    opordercategory = db.Column(db.String(50), info="Categorie d'ordre (Yoshi,...)")
    opindexcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    opidadvisoroperation = db.Column(db.String(100))
    optransfertype = db.Column(db.Numeric(1, 0, asdecimal=False))

    rkcouponspaye = db.relationship(
        "Rkcouponspaye",
        primaryjoin="Rkoperation.opcouponpaye == Rkcouponspaye.cpcode",
        backref="rkoperations",
    )
    rksystem = db.relationship(
        "Rksystem",
        primaryjoin="Rkoperation.opsysteme == Rksystem.syid",
        backref="rkoperations",
    )


class Rkoperationmiddle(Rkoperation):
    __tablename__ = "rkoperationmiddle"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    omnumero = db.Column(
        db.ForeignKey("risque.rkoperation.opnumero"),
        primary_key=True,
        info="Numéro de l'opération",
    )
    omvalidation = db.Column(
        db.ForeignKey("risque.rkstatutvalidation.svcode"),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Statut de validation de l'opération",
    )
    ommotifrefus = db.Column(
        db.ForeignKey("risque.rkmotifrefus.mrcode"),
        info="Motif du refus de l'opération",
    )
    omcommentaire = db.Column(db.String(1024), info="Commentaire en cas de rejet")
    omutilisateur = db.Column(
        db.String(30), info="Nom/machine de l'utilisateur qui valide"
    )
    omhorodate = db.Column(
        db.DateTime, nullable=False, info="Date/heure de dernière mise à jour du statut"
    )
    omconfirmation = db.Column(
        db.ForeignKey("risque.rkstatutconfirmation.tscode"),
        info="Statut de confirmation de l'opération",
    )
    omconfplatform = db.Column(
        db.ForeignKey("exane.tpconfirmation.tccode"),
        info="Platforme de confirmation choisie par l'utilisateur",
    )
    ommotifvalidation = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Motif de validation de l'opération"
    )

    rkstatutconfirmation = db.relationship(
        "Rkstatutconfirmation",
        primaryjoin="Rkoperationmiddle.omconfirmation == Rkstatutconfirmation.tscode",
        backref="rkoperationmiddles",
    )
    tpconfirmation = db.relationship(
        "Tpconfirmation",
        primaryjoin="Rkoperationmiddle.omconfplatform == Tpconfirmation.tccode",
        backref="rkoperationmiddles",
    )
    rkmotifrefu = db.relationship(
        "Rkmotifrefu",
        primaryjoin="Rkoperationmiddle.ommotifrefus == Rkmotifrefu.mrcode",
        backref="rkoperationmiddles",
    )
    rkstatutvalidation = db.relationship(
        "Rkstatutvalidation",
        primaryjoin="Rkoperationmiddle.omvalidation == Rkstatutvalidation.svcode",
        backref="rkoperationmiddles",
    )


class RkoperationH(db.Model):
    __tablename__ = "rkoperation_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    opbook = db.Column(db.Numeric(5, 0, asdecimal=False))
    opcfin = db.Column(db.Numeric(8, 0, asdecimal=False), index=True)
    opticket = db.Column(db.String(12))
    opcompte = db.Column(db.Numeric(5, 0, asdecimal=False))
    opuser = db.Column(db.Numeric(3, 0, asdecimal=False))
    opquantite = db.Column(db.Numeric(13, 0, asdecimal=False))
    opmontant = db.Column(db.Numeric(21, 5))
    opdev = db.Column(db.Numeric(8, 0, asdecimal=False))
    opotype = db.Column(db.Numeric(3, 0, asdecimal=False))
    opdaterl = db.Column(db.DateTime)
    opmoderl = db.Column(db.Numeric(3, 0, asdecimal=False))
    opfrais = db.Column(db.Numeric(12, 5))
    opcptie = db.Column(db.Numeric(8, 0, asdecimal=False))
    opdate = db.Column(db.DateTime)
    ophorodate = db.Column(db.DateTime, info="Date/heure de création de l'opération.")
    opstatut = db.Column(db.Numeric(3, 0, asdecimal=False))
    opcours = db.Column(db.Numeric(13, 5))
    opchange = db.Column(db.Numeric(13, 5))
    opmontantcc = db.Column(db.Numeric(13, 5))
    opflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    opquantitebroker = db.Column(db.Numeric(13, 0, asdecimal=False))
    opprixbroker = db.Column(db.Numeric(21, 5))
    opquantitehedge = db.Column(db.Numeric(13, 0, asdecimal=False))
    opprixhedge = db.Column(db.Numeric(21, 5))
    optiers = db.Column(db.Numeric(asdecimal=False))
    opprovenance = db.Column(db.String(1))
    opportef = db.Column(db.Numeric(8, 0, asdecimal=False))
    opgenerateur = db.Column(db.Numeric(8, 0, asdecimal=False))
    opstyle = db.Column(db.String(1))
    opquotite = db.Column(db.Numeric(12, 4))
    optypesaisie = db.Column(db.Numeric(3, 0, asdecimal=False))
    opcommentaire = db.Column(db.String(50))
    opvendeur = db.Column(db.Numeric(8, 0, asdecimal=False))
    opmargevendeur = db.Column(db.Numeric(12, 5))
    opmargetrader = db.Column(db.Numeric(12, 5))
    opinformation = db.Column(db.Numeric(5, 0, asdecimal=False))
    opnumero = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Id de la table à renseigner pour EDEN, null pour NEXT et VAC",
    )
    opannule = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Id de l'opé contrepassée, peut être NULL",
    )
    oporigine = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Id de l'opé qui est remplacée, peut être NULL",
    )
    opdatenego = db.Column(
        db.DateTime, info="Date de négociation de l'opé, peut être NULL"
    )
    opnumechange = db.Column(db.Numeric(8, 0, asdecimal=False))
    opcfinreference = db.Column(db.Numeric(8, 0, asdecimal=False))
    opvalidation = db.Column(db.String(1))
    opmaj = db.Column(db.DateTime, info="Date/heure de mise à jour de l'opération.")
    optypecotation = db.Column(
        db.String(1),
        info="Type de cotation (indique si on doit inclure ou non le montant du coupon couru)",
    )
    opmodecotation = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Devise ou % du nominal"
    )


class Rkoperationinit(db.Model):
    __tablename__ = "rkoperationinit"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    opbook = db.Column(db.Numeric(5, 0, asdecimal=False), info="Code sous-portefeuille")
    opcfin = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code du produit")
    opdate = db.Column(db.DateTime, index=True, info="Date de la negociation")
    opquantite = db.Column(db.Numeric(17, 4), info="Quantite")
    opmontant = db.Column(db.Numeric(23, 5), info="Montant")
    opdev = db.Column(db.Numeric(8, 0, asdecimal=False), info="Devise du montant")
    opdaterl = db.Column(db.DateTime, info="Date de reglement livraison")
    opfrais = db.Column(db.Numeric(22, 15), info="Montant de frais")
    ophorodate = db.Column(db.DateTime, info="Date/heure de création de l'opération.")
    opcours = db.Column(db.Numeric(15, 5), info="Cours")
    opflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    opquotite = db.Column(db.Numeric(12, 4), info="Quotité")
    opcommentaire = db.Column(db.String(100), info="Descriptif de l'opération d'init")
    opdatenego = db.Column(
        db.DateTime, info="Date de négociation de l'opé, peut être NULL"
    )
    opmaj = db.Column(db.DateTime, info="Date/heure de mise à jour de l'opération.")
    opnumero = db.Column(
        db.Numeric(10, 0, asdecimal=False),
        primary_key=True,
        info="Identifiant de l'operation",
    )


class Rkopesam(db.Model):
    __tablename__ = "rkopesam"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    opsbigbook = db.Column(db.Numeric(4, 0, asdecimal=False))
    opsbook = db.Column(
        db.Numeric(5, 0, asdecimal=False), primary_key=True, nullable=False
    )
    opscfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    opsticket = db.Column(db.String(12), primary_key=True, nullable=False)
    opsticketsam = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    opsuser = db.Column(db.Numeric(3, 0, asdecimal=False))
    opsquantite = db.Column(db.Numeric(13, 0, asdecimal=False))
    opsmontant = db.Column(db.Numeric(21, 5))
    opsdev = db.Column(db.Numeric(8, 0, asdecimal=False))
    opsotype = db.Column(db.Numeric(3, 0, asdecimal=False))
    opsdaterl = db.Column(db.DateTime)
    opsmoderl = db.Column(db.Numeric(3, 0, asdecimal=False))
    opscours = db.Column(db.Numeric(13, 5))
    opschange = db.Column(db.Numeric(13, 5))
    opsmontantcc = db.Column(db.Numeric(13, 5))
    opsflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    opsquotite = db.Column(db.Numeric(12, 4))
    opstypesaisie = db.Column(db.Numeric(3, 0, asdecimal=False))
    opsorigine = db.Column(db.Numeric(8, 0, asdecimal=False))
    opsdatenego = db.Column(db.DateTime, primary_key=True, nullable=False)
    opsbroker = db.Column(db.Numeric(8, 0, asdecimal=False))
    opscategorie = db.Column(db.String(60))
    opshorodate = db.Column(db.DateTime)
    opsextractmiddle = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="booléen, indique si l opération a été extraite par le middle",
    )
    opshdextractmiddle = db.Column(db.DateTime, info="orodate de l extraction middle")
    opsannul = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Indique si l opération est annulée ou non",
    )
    opshdannul = db.Column(db.DateTime, info="Horodate de l annulation")
    opsextractannul = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Indique si l annulation a été extraite par le middle",
    )
    opshdextractannul = db.Column(
        db.DateTime, info="Horodate de l extraction de l annulation par le middle"
    )
    opscommentaires = db.Column(db.String(80))
    opsdatetravail = db.Column(db.DateTime)


class Rkopfp(db.Model):
    __tablename__ = "rkopfp"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ofbook = db.Column(db.Numeric(8, 0, asdecimal=False))
    ofdate = db.Column(db.DateTime)
    ofassima = db.Column(db.String(1))
    ofassime = db.Column(db.String(1))
    ofcouva = db.Column(db.String(1))
    ofcouve = db.Column(db.String(1))
    ofregla = db.Column(db.String(1))
    ofregle = db.Column(db.String(1))
    ofspot = db.Column(db.Numeric(18, 3))
    ofpasspot = db.Column(db.Numeric(8, 3))
    ofvolat = db.Column(db.Numeric(8, 3))
    ofpasvolat = db.Column(db.Numeric(8, 3))
    oftaux = db.Column(db.Numeric(8, 3))
    ofpastaux = db.Column(db.Numeric(8, 3))
    ofactudiv = db.Column(db.Numeric(8, 3))
    ofimpmin = db.Column(db.Numeric(8, 3))
    ofimpmax = db.Column(db.Numeric(8, 3))
    ofimppasspot = db.Column(db.Numeric(8, 3))
    ofimppasvol = db.Column(db.Numeric(8, 3))
    offlag = db.Column(db.Numeric(3, 0, asdecimal=False))
    ofphedgepv = db.Column(db.Numeric(asdecimal=False))
    ofphedgehm = db.Column(db.Numeric(8, 0, asdecimal=False))


class Rkoriginefiltre(db.Model):
    __tablename__ = "rkoriginefiltre"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    fpcode = db.Column(db.ForeignKey("risque.rkfiltre.flcode"), nullable=False)
    fporigine = db.Column(db.Numeric(8, 0, asdecimal=False))

    rkfiltre = db.relationship(
        "Rkfiltre",
        primaryjoin="Rkoriginefiltre.fpcode == Rkfiltre.flcode",
        backref="rkoriginefiltres",
    )


class Rkparametresariane(db.Model):
    __tablename__ = "rkparametresariane"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "idx_paramariane", "pabook", "pacfin", "paportee", "pamarche", "paflag"
        ),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pabook = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    pacfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    paecheance = db.Column(db.DateTime)
    pacallput = db.Column(db.String(1))
    paportee = db.Column(db.String(1))
    pamarche = db.Column(db.Numeric(3, 0, asdecimal=False))
    paautoriser = db.Column(db.String(1))
    paquantitedefaut = db.Column(db.Numeric(12, 3))
    pamidasspot = db.Column(db.String(1))
    pavarmax = db.Column(db.Numeric(12, 3))
    pactrlbidmin = db.Column(db.String(1))
    pavarveille = db.Column(db.Numeric(12, 3))
    pamargesecurite = db.Column(db.Numeric(12, 3))
    pastatut = db.Column(db.String(1))
    pasizebid = db.Column(db.Numeric(asdecimal=False))
    pasizeask = db.Column(db.Numeric(asdecimal=False))
    pasizequotbid = db.Column(db.Numeric(6, 0, asdecimal=False))
    pasizequotask = db.Column(db.Numeric(6, 0, asdecimal=False))
    paactif = db.Column(db.String(1))
    pafv = db.Column(db.Numeric(asdecimal=False))
    pastrikemin = db.Column(db.Numeric(4, 0, asdecimal=False))
    pastrikemax = db.Column(db.Numeric(4, 0, asdecimal=False))
    padebraye = db.Column(db.String(1))
    paflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class RkparametresarianeH(db.Model):
    __tablename__ = "rkparametresariane_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phabook = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    phacfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    phaecheance = db.Column(db.DateTime)
    phacallput = db.Column(db.String(1))
    phaportee = db.Column(db.String(1))
    phamarche = db.Column(db.Numeric(3, 0, asdecimal=False))
    phaautoriser = db.Column(db.String(1))
    phaquantitedefaut = db.Column(db.Numeric(12, 3))
    phamidasspot = db.Column(db.String(1))
    phavarmax = db.Column(db.Numeric(12, 3))
    phactrlbidmin = db.Column(db.String(1))
    phavarveille = db.Column(db.Numeric(12, 3))
    phamargesecurite = db.Column(db.Numeric(12, 3))
    phastatut = db.Column(db.String(1))
    phasizebid = db.Column(db.Numeric(asdecimal=False))
    phasizeask = db.Column(db.Numeric(asdecimal=False))
    phasizequotbid = db.Column(db.Numeric(6, 0, asdecimal=False))
    phasizequotask = db.Column(db.Numeric(6, 0, asdecimal=False))
    phaactif = db.Column(db.String(1))
    phafv = db.Column(db.Numeric(asdecimal=False))
    phastrikemin = db.Column(db.Numeric(4, 0, asdecimal=False))
    phastrikemax = db.Column(db.Numeric(4, 0, asdecimal=False))
    phadebraye = db.Column(db.String(1))
    phaflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    phahorodate = db.Column(
        db.DateTime, nullable=False, info="Horodate de la mise à jour"
    )
    phauser = db.Column(db.String(60), info="Utilisateur ayant effectué la mise à jour")
    phatrait = db.Column(
        db.String(1), nullable=False, info="Type de traitement de mise à jour"
    )


class Rkparametresniveauxsonic(db.Model):
    __tablename__ = "rkparametresniveauxsonic"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "idx_paramsonic", "pnsbook", "pnscfin", "pnsportee", "pnsniveau", "pnsflag"
        ),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pnsbook = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    pnscfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    pnsecheance = db.Column(db.DateTime)
    pnscallput = db.Column(db.String(1))
    pnsportee = db.Column(db.String(1))
    pnsmargeaskdevise = db.Column(db.Numeric(asdecimal=False))
    pnsmargeaskptsvol = db.Column(db.Numeric(asdecimal=False))
    pnsmargebiddevise = db.Column(db.Numeric(asdecimal=False))
    pnsmargebidptsvol = db.Column(db.Numeric(asdecimal=False))
    pnsdeltamin = db.Column(db.Numeric(asdecimal=False))
    pnsdeltamax = db.Column(db.Numeric(asdecimal=False))
    pnsactifbid = db.Column(db.String(1))
    pnsactifask = db.Column(db.String(1))
    pnsdebraye = db.Column(db.String(1))
    pnsniveau = db.Column(db.Numeric(1, 0, asdecimal=False))
    pnsflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class RkparametresniveauxsonicH(db.Model):
    __tablename__ = "rkparametresniveauxsonic_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phnsbook = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    phnscfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    phnsecheance = db.Column(db.DateTime)
    phnscallput = db.Column(db.String(1))
    phnsportee = db.Column(db.String(1))
    phnsmargeaskdevise = db.Column(db.Numeric(asdecimal=False))
    phnsmargeaskptsvol = db.Column(db.Numeric(asdecimal=False))
    phnsmargebiddevise = db.Column(db.Numeric(asdecimal=False))
    phnsmargebidptsvol = db.Column(db.Numeric(asdecimal=False))
    phnsdeltamin = db.Column(db.Numeric(asdecimal=False))
    phnsdeltamax = db.Column(db.Numeric(asdecimal=False))
    phnsactifbid = db.Column(db.String(1))
    phnsactifask = db.Column(db.String(1))
    phnsdebraye = db.Column(db.String(1))
    phnsniveau = db.Column(db.Numeric(1, 0, asdecimal=False))
    phnsflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    phnhorodate = db.Column(
        db.DateTime, nullable=False, info="Horodate de la mise à jour"
    )
    phnuser = db.Column(db.String(60), info="Utilisateur ayant effectué la mise à jour")
    phntrait = db.Column(
        db.String(1), nullable=False, info="Type de traitement de mise à jour"
    )


class Rkparametressonic(db.Model):
    __tablename__ = "rkparametressonic"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    psbook = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    psautoriser = db.Column(db.String(1))
    psvarmax = db.Column(db.Numeric(12, 3))
    psspotrefbidcall = db.Column(db.String(1))
    psspotrefbidput = db.Column(db.String(1))
    psspotrefaskcall = db.Column(db.String(1))
    psspotrefaskput = db.Column(db.String(1))
    psqtetapeemin = db.Column(db.Numeric(asdecimal=False))
    psqtetapeemax = db.Column(db.Numeric(asdecimal=False))
    psflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class RkparametressonicH(db.Model):
    __tablename__ = "rkparametressonic_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phsbook = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    phsautoriser = db.Column(db.String(1))
    phsvarmax = db.Column(db.Numeric(12, 3))
    phsspotrefbidcall = db.Column(db.String(1))
    phsspotrefbidput = db.Column(db.String(1))
    phsspotrefaskcall = db.Column(db.String(1))
    phsspotrefaskput = db.Column(db.String(1))
    phsqtetapeemin = db.Column(db.Numeric(asdecimal=False))
    phsqtetapeemax = db.Column(db.Numeric(asdecimal=False))
    phsflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    phshorodate = db.Column(
        db.DateTime, nullable=False, info="Horodate de la mise à jour"
    )
    phsuser = db.Column(db.String(60), info="Utilisateur ayant effectué la mise à jour")
    phstrait = db.Column(
        db.String(1), nullable=False, info="Type de traitement de mise à jour"
    )


class Rkparamsam(db.Model):
    __tablename__ = "rkparamsam"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    pscode = db.Column(
        db.ForeignKey("risque.rkapplisam.ascode"),
        primary_key=True,
        nullable=False,
        info="Identifiant du groupe de paramètres (identifiant de l appli par exemple)",
    )
    psnom = db.Column(
        db.String(30), primary_key=True, nullable=False, info="Nom du paramètre"
    )
    pstext = db.Column(db.String(80), info="Paramètre de type texte")
    psint = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Paramètre de type entier"
    )
    psdouble = db.Column(db.Numeric(21, 5), info="Paramètre de type réel")
    psdate = db.Column(db.DateTime, info="Paramètre de type date")

    rkapplisam = db.relationship(
        "Rkapplisam",
        primaryjoin="Rkparamsam.pscode == Rkapplisam.ascode",
        backref="rkparamsams",
    )


class Rkpnl(db.Model):
    __tablename__ = "rkpnl"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx_rkpnl_dateprofil", "pldate", "plprofil"),
        {"schema": "risque"},
    )

    pldate = db.Column(db.DateTime, primary_key=True, nullable=False, info="Date")
    plbook = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Sous portefeuille (RKDEFBIGBOOK)",
    )
    plcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code du produit (RKPRODUIT)",
    )
    plprofil = db.Column(
        db.ForeignKey("risque.prprofil.pprofil"),
        primary_key=True,
        nullable=False,
        info="Profil utilisé pour le calcul du PNL",
    )
    pldev = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code devise (RKPRODUIT)",
    )
    plpljour = db.Column(db.Numeric(asdecimal=False), info="PNL jour")
    plplcumul = db.Column(db.Numeric(asdecimal=False), info="PNL cumule")
    plfraisjour = db.Column(db.Numeric(asdecimal=False), info="Frais jour")
    plfraiscumul = db.Column(db.Numeric(asdecimal=False), info="Frais divers cumules")
    plsolde = db.Column(
        db.Numeric(asdecimal=False),
        info="Solde espèce aggrégé sur somme(POSOLDE) pour une PODATE (RKPOSITION)",
    )
    plcours = db.Column(db.Numeric(asdecimal=False), info="Cour de valorisation")
    plprixtheo = db.Column(db.Numeric(asdecimal=False), info="Prix théorique")
    plecartvalojour = db.Column(
        db.Numeric(asdecimal=False), info="Ecart de valorisation"
    )
    plecartvalocumul = db.Column(
        db.Numeric(asdecimal=False), info="Ecart de valorisation cumulée "
    )
    plecartvalodev = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Devise d'expression des écart de valorisation",
    )
    plmontantcc = db.Column(
        db.Numeric(asdecimal=False),
        info="Montant unitaire du coupon courru sur toute la position",
    )
    plcapi = db.Column(
        db.Numeric(asdecimal=False),
        info="Position totale en date et date valeur valorisée avec le prix théorique (MTM)",
    )
    plchangehisto = db.Column(
        db.Numeric(asdecimal=False),
        info="Position de change historique (antérieur année n).",
    )

    prprofil = db.relationship(
        "Prprofil", primaryjoin="Rkpnl.plprofil == Prprofil.pprofil", backref="rkpnls"
    )


class RkpnlH(db.Model):
    __tablename__ = "rkpnl_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    phldate = db.Column(db.DateTime, primary_key=True, nullable=False, info="Date")
    phlbook = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Sous portefeuille (RKDEFBIGBOOK)",
    )
    phlcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code du produit (RKPRODUIT)",
    )
    phlprofil = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Profil utilisé pour le calcul du PNL",
    )
    phldev = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code devise (RKPRODUIT)",
    )
    phlpljour = db.Column(db.Numeric(18, 2), info="P\\ jour")
    phlplcumul = db.Column(db.Numeric(18, 2), info="P\\ cumule")
    phlfraisjour = db.Column(db.Numeric(10, 2), info="Frais jour")
    phlfraiscumul = db.Column(db.Numeric(12, 2), info="Frais divers cumules")
    phlsolde = db.Column(
        db.Numeric(18, 2),
        info="Solde espèce aggrégé sur somme(POSOLDE) pour une PODATE (RKPOSITION)",
    )
    phlcours = db.Column(db.Numeric(13, 5), info="Cour de valorisation")
    phlprixtheo = db.Column(db.Numeric(19, 10), info="Prix théorique")
    phlecartvalojour = db.Column(db.Numeric(18, 2), info="Ecart de valorisation")
    phlecartvalocumul = db.Column(
        db.Numeric(18, 2), info="Ecart de valorisation cumulée "
    )
    phlecartvalodev = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Devise d'expression des écart de valorisation",
    )
    phlmontantcc = db.Column(
        db.Numeric(asdecimal=False),
        info="Montant unitaire du coupon courru sur toute la position",
    )
    phlcapi = db.Column(
        db.Numeric(18, 2),
        info="Position totale en date et date valeur valorisée avec le prix théorique (MTM)",
    )
    phlchangehisto = db.Column(
        db.Numeric(18, 2), info="Position de change historique (antérieur année n)."
    )


class Rkpoidsjour(db.Model):
    __tablename__ = "rkpoidsjour"
    __bind_key__ = "exane_risque"
    __table_args__ = (db.CheckConstraint("PJDATE=TRUNC(PJDATE)"), {"schema": "risque"})

    pjcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de l'instrument financier",
    )
    pjdate = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Date a laquelle le poids doit etre applique",
    )
    pjpoids = db.Column(
        db.Numeric(7, 4),
        nullable=False,
        info="Poids a appliquer pour le produit a la date donnee",
    )


class RkpoidsjourH(db.Model):
    __tablename__ = "rkpoidsjour_h"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx_rkpoidsjour_h_cfin_dt", "hpjcfin", "hpjdate", "hpjhorodate"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    hpjcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    hpjdate = db.Column(db.DateTime)
    hpjpoids = db.Column(db.Numeric(7, 4))
    hpjhorodate = db.Column(db.DateTime, server_default=db.FetchedValue())
    hpjtraitement = db.Column(
        db.String(1), info="Type de modificiation effectuee (I)nsert (U)pdate (D)elete"
    )
    hpjutilisateur = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Code utilisateur (EXANE.UTILIT) ayant effectue la modif",
    )


class Rkpo(db.Model):
    __tablename__ = "rkpos"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("id_pos_bookdate", "pobook", "podate"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pobook = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        index=True,
        info="Code sous portefeuille(RKDEFBIGBOOK)",
    )
    pocfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        index=True,
        info="Code du produit (RKPRODUIT)",
    )
    podev = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code devise (RKPRODUIT)")
    pocompte = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="Code compte (RKCOMPTE)"
    )
    popos = db.Column(db.Numeric(asdecimal=False), info="Position")
    podateval = db.Column(db.DateTime, info="Date de valeur de la position")
    potype = db.Column(db.String(1), info="Type de position (Cash/Titre/Emprunt)")
    podate = db.Column(
        db.DateTime, index=True, info="Date de generation de cette position"
    )
    postatus = db.Column(db.Numeric(3, 0, asdecimal=False), info="Status position")
    poflag = db.Column(
        db.Numeric(5, 0, asdecimal=False), index=True, info="Flag de suppression"
    )
    poactif = db.Column(db.String(1))
    potiers = db.Column(db.Numeric(asdecimal=False))
    postyle = db.Column(db.String(1))
    poquotite = db.Column(db.Numeric(12, 4))
    pomontantcc = db.Column(db.Numeric(asdecimal=False))
    pocapi = db.Column(db.Numeric(asdecimal=False))
    potypepnl = db.Column(db.String(1))


class RkposH(db.Model):
    __tablename__ = "rkpos_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pobook = db.Column(db.Numeric(5, 0, asdecimal=False))
    pocfin = db.Column(db.Numeric(8, 0, asdecimal=False), index=True)
    podev = db.Column(db.Numeric(8, 0, asdecimal=False))
    pocompte = db.Column(db.Numeric(5, 0, asdecimal=False))
    popos = db.Column(db.Numeric(13, 0, asdecimal=False))
    podateval = db.Column(db.DateTime)
    potype = db.Column(db.String(1))
    podate = db.Column(db.DateTime)
    postatus = db.Column(db.Numeric(3, 0, asdecimal=False))
    poflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    poactif = db.Column(db.String(1))
    potiers = db.Column(db.Numeric(asdecimal=False))
    postyle = db.Column(db.String(1))
    poquotite = db.Column(db.Numeric(14, 4))
    pomontantcc = db.Column(db.Numeric(13, 5))
    pocapi = db.Column(db.Numeric(18, 2))


class RkposRef(db.Model):
    __tablename__ = "rkpos_ref"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pordate = db.Column(db.DateTime, nullable=False, index=True, info="Date")
    porbook = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="Code sous-portefeuille",
    )
    porcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="Cfin instrument",
    )
    pordev = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False, info="Devise")
    porcompte = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Compte"
    )
    porpos = db.Column(
        db.Numeric(13, 0, asdecimal=False), nullable=False, info="Position"
    )
    pordateval = db.Column(db.DateTime, nullable=False, info="Date de valeur")
    porquotite = db.Column(db.Numeric(12, 4), info="Quotite")
    pormontantcc = db.Column(db.Numeric(asdecimal=False), info="Montant Coupon couru")
    porcapi = db.Column(db.Numeric(18, 2), info="Capi")
    porflag = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Flag de suppression"
    )


class Rkposition(db.Model):
    __tablename__ = "rkposition"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    podate = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        index=True,
        info="Date de generation de cette position",
    )
    pobook = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code sous portefeuille(RKDEFBIGBOOK)",
    )
    pocfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code du produit (RKPRODUIT)",
    )
    podev = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code devise (RKPRODUIT)",
    )
    podateval = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Date de valeur de la position",
    )
    popos = db.Column(db.Numeric(asdecimal=False), info="Position")
    posolde = db.Column(
        db.Numeric(asdecimal=False), info="Caisse de l'instrument en date valeur."
    )
    pofrais = db.Column(
        db.Numeric(asdecimal=False), info="Frais de l'instrument en date valeur."
    )
    poquotite = db.Column(db.Numeric(12, 4), info="Quotité")
    pochangehisto = db.Column(
        db.Numeric(asdecimal=False),
        info="Position de change historique (antérieur année n).",
    )
    posystem = db.Column(db.String(25), info="Update system id")


class RkpositionH(db.Model):
    __tablename__ = "rkposition_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    phodate = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Date de generation de cette position",
    )
    phobook = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code sous portefeuille(RKDEFBIGBOOK)",
    )
    phocfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code du produit (RKPRODUIT)",
    )
    phodev = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code devise (RKPRODUIT)",
    )
    phodateval = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Date de valeur de la position",
    )
    phopos = db.Column(db.Numeric(13, 0, asdecimal=False), info="Position")
    phosolde = db.Column(
        db.Numeric(18, 2), info="Caisse de l'instrument en date valeur."
    )
    phofrais = db.Column(
        db.Numeric(10, 2), info="Frais de l'instrument en date valeur."
    )
    phoquotite = db.Column(db.Numeric(12, 4), info="Quotité")
    phochangehisto = db.Column(
        db.Numeric(18, 2), info="Position de change historique (antérieur année n)."
    )


class Rkpositiondevise(db.Model):
    __tablename__ = "rkpositiondevise"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pddate = db.Column(db.DateTime, index=True)
    pdbook = db.Column(db.Numeric(5, 0, asdecimal=False), index=True)
    pddevise = db.Column(db.Numeric(8, 0, asdecimal=False), index=True)
    pdposition = db.Column(db.Numeric(18, 2))
    pdflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    pdtypepnl = db.Column(db.String(1))


class RkpositiondeviseRef(db.Model):
    __tablename__ = "rkpositiondevise_ref"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pdrdate = db.Column(db.DateTime, nullable=False, info="Date")
    pdrbook = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Code sous-portefeuille"
    )
    pdrdevise = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Devise"
    )
    pdrposition = db.Column(db.Numeric(18, 2), nullable=False, info="Position")
    pdrflag = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Flag de suppression"
    )


class Rkprecisiontango(db.Model):
    __tablename__ = "rkprecisiontango"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ptbigbook = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    ptbook = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptprofil = db.Column(db.String(1))
    ptstrike = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptvol = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptspot = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptdelta = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptgamma = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptvega = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptpnl = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptduration = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptconvexite = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptcouponcouru = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptautres = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptcapitaux = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptconstatation = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptcompocoeff = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptparite = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptproportion = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptnominal = db.Column(db.Numeric(5, 0, asdecimal=False))
    ptmarges = db.Column(db.Numeric(5, 0, asdecimal=False))


class Rkpricing(db.Model):
    __tablename__ = "rkpricing"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "uk_pricing_rkpricin",
            "prdate",
            "prprofil",
            "prcfin",
            "prparent",
            "prmode",
            "prflag",
        ),
        {"schema": "risque"},
    )

    prnumero = db.Column(
        db.Numeric(12, 0, asdecimal=False),
        primary_key=True,
        info="Numéro de la requête de pricing",
    )
    prdate = db.Column(db.DateTime, nullable=False, info="Date de pricing")
    prprofil = db.Column(
        db.ForeignKey("risque.prprofil.pprofil"),
        nullable=False,
        info="Profil de pricing",
    )
    prparent = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="Cfin du père",
    )
    prcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, index=True, info="Cfin pricé"
    )
    prmode = db.Column(
        db.ForeignKey("risque.rktypemodepricing.mpcode"),
        nullable=False,
        index=True,
        info="Mode de pricing",
    )
    prflag = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="Etat de la ligne"
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Rkpricing.prcfin == Instrument.ifcfin",
        backref="instrument_rkpricings",
    )
    rktypemodepricing = db.relationship(
        "Rktypemodepricing",
        primaryjoin="Rkpricing.prmode == Rktypemodepricing.mpcode",
        backref="rkpricings",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Rkpricing.prparent == Instrument.ifcfin",
        backref="instrument_rkpricings_0",
    )
    prprofil1 = db.relationship(
        "Prprofil",
        primaryjoin="Rkpricing.prprofil == Prprofil.pprofil",
        backref="rkpricings",
    )


class Rkpricingerreur(db.Model):
    __tablename__ = "rkpricingerreurs"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pedate = db.Column(db.DateTime, index=True, info="Date de pricing")
    peprofil = db.Column(db.Numeric(8, 0, asdecimal=False), info="Profil de pricing")
    pecfin = db.Column(db.Numeric(8, 0, asdecimal=False), info="Cfin pricé")
    pemode = db.Column(db.Numeric(2, 0, asdecimal=False), info="Mode de pricing")
    pecode = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code de l'erreur")
    pemessage = db.Column(db.String(1024), info="Message d'erreur")
    pehorodate = db.Column(db.DateTime, info="Horodate de l'erreur de pricing")
    pedateannul = db.Column(
        db.DateTime,
        index=True,
        info="Date à laquelle l'erreur a été annulée (le CFIN est pricée de nouveau).",
    )
    peauditsessionid = db.Column(
        db.Numeric(38, 0, asdecimal=False),
        info="Stores audit session id in EXANE_BATCH.APPSESSION",
    )


class Rkpricingresultat(db.Model):
    __tablename__ = "rkpricingresultats"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    prnumero = db.Column(
        db.ForeignKey("risque.rkpricing.prnumero", ondelete="CASCADE"),
        nullable=False,
        index=True,
        info="Numéro de la requête de pricing",
    )
    prindicateur = db.Column(
        db.ForeignKey("risque.rktypeindicateur.ticode"),
        nullable=False,
        index=True,
        info="Code de l'indicateur",
    )
    praxe1 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        index=True,
        info="Axe de projection pour les indicateurs vectoriels et matriciels",
    )
    praxe2 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        index=True,
        info="Axe de projection pour les indicateurs matriciels",
    )
    prvaleur = db.Column(db.Numeric(asdecimal=False), info="Valeur de l'indicateur")

    rktypeindicateur = db.relationship(
        "Rktypeindicateur",
        primaryjoin="Rkpricingresultat.prindicateur == Rktypeindicateur.ticode",
        backref="rkpricingresultats",
    )
    rkpricing = db.relationship(
        "Rkpricing",
        primaryjoin="Rkpricingresultat.prnumero == Rkpricing.prnumero",
        backref="rkpricingresultats",
    )


class Rkproduit(db.Model):
    __tablename__ = "rkproduit"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    prcfin = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code du produit")
    prtype = db.Column(db.Numeric(3, 0, asdecimal=False), info="Type de produit")
    prdev = db.Column(db.Numeric(8, 0, asdecimal=False), info="Devise de cotation")
    prnom = db.Column(db.String(30), info="Nom du produit")
    prmarket = db.Column(db.Numeric(3, 0, asdecimal=False), info="Marche de cotation")
    prpays = db.Column(db.Numeric(3, 0, asdecimal=False), info="Pays de cotation")
    prupdate = db.Column(db.DateTime, info="Date de mise a jour")
    prstatus = db.Column(db.Numeric(3, 0, asdecimal=False), info="Status de creation")
    prmodecot = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Mode de cotation du produit"
    )
    prflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Rkproduitfiltre(db.Model):
    __tablename__ = "rkproduitfiltre"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    frcode = db.Column(db.ForeignKey("risque.rkfiltre.flcode"), nullable=False)
    frproduit = db.Column(db.Numeric(8, 0, asdecimal=False))

    rkfiltre = db.relationship(
        "Rkfiltre",
        primaryjoin="Rkproduitfiltre.frcode == Rkfiltre.flcode",
        backref="rkproduitfiltres",
    )


class Rkreftstudent(db.Model):
    __tablename__ = "rkreftstudent"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("TSUTILISE in ('O','N')"),
        db.CheckConstraint("TSUTILISE in ('O','N')"),
        {"schema": "risque"},
    )

    tsseuil = db.Column(
        db.Numeric(5, 2),
        primary_key=True,
        nullable=False,
        info="Seuil de significativité en pourcentage",
    )
    tsvaleur = db.Column(
        db.Numeric(18, 4),
        primary_key=True,
        nullable=False,
        info="Valeur minimum du t-Student pour une significativité positive",
    )
    tsutilise = db.Column(
        db.String(1),
        primary_key=True,
        nullable=False,
        server_default=db.FetchedValue(),
        info="O si utilisé par Next pour le test de significativité, N sinon",
    )


class Rkreglecotation(db.Model):
    __tablename__ = "rkreglecotation"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rcmarche = db.Column(db.Numeric(asdecimal=False))
    rcordre = db.Column(db.Numeric(3, 0, asdecimal=False))
    rcmin = db.Column(db.Numeric(asdecimal=False))
    rcmax = db.Column(db.Numeric(asdecimal=False))
    rcarrondi = db.Column(db.Numeric(asdecimal=False))
    rctype = db.Column(db.Numeric(asdecimal=False))


class Rkregledebrayee(db.Model):
    __tablename__ = "rkregledebrayee"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("RDEXERCABILITE in ('E','A')"),
        db.CheckConstraint("RDEXERCABILITE in ('E','A')"),
        {"schema": "risque"},
    )

    rdbook = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code Book",
    )
    rdcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code CFIN",
    )
    rdregle = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    rdexercabilite = db.Column(
        db.String(1),
        primary_key=True,
        nullable=False,
        info="Exerçabilité (E: Européen, A: Américain)",
    )
    rdmarche = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code marché",
    )
    rdechemin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Borne min de la fourchette Échéance (en nombre de mois)",
    )
    rdechemax = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Borne max de la fourchette Échéance (en nombre de mois)",
    )
    rdordre = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Ordre",
    )
    rdmontant = db.Column(db.Numeric(12, 4), info="Montant max de la largeur de quote")
    rdpourcent = db.Column(
        db.Numeric(4, 0, asdecimal=False), info="% max de la largeur de quote"
    )
    rdfastmarket = db.Column(db.String(1))
    rdfmmontant = db.Column(db.Numeric(12, 4))
    rdfmpourcent = db.Column(db.Numeric(4, 0, asdecimal=False))


class RkregledebrayeeH(db.Model):
    __tablename__ = "rkregledebrayee_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rhdbook = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Code Book"
    )
    rhdcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Code CFIN"
    )
    rhdregle = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    rhdexercabilite = db.Column(
        db.String(1), nullable=False, info="Exerçabilité (E: Européen, A: Américain)"
    )
    rhdmarche = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="Code marché"
    )
    rhdechemin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Borne min de la fourchette Échéance (en nombre de mois)",
    )
    rhdechemax = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Borne max de la fourchette Échéance (en nombre de mois)",
    )
    rhdordre = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="Ordre"
    )
    rhdmontant = db.Column(db.Numeric(12, 4), info="Montant max de la largeur de quote")
    rhdpourcent = db.Column(
        db.Numeric(4, 0, asdecimal=False), info="% max de la largeur de quote"
    )
    rhdfastmarket = db.Column(db.String(1))
    rhdfmmontant = db.Column(db.Numeric(12, 4))
    rhdfmpourcent = db.Column(db.Numeric(4, 0, asdecimal=False))
    rhdhorodate = db.Column(
        db.DateTime, nullable=False, info="Horodate de la mise à jour"
    )
    rhduser = db.Column(db.String(60), info="Utilisateur ayant effectué la mise à jour")
    rhdtrait = db.Column(
        db.String(1), nullable=False, info="Type de traitement de mise à jour"
    )


class Rkreglemarche(db.Model):
    __tablename__ = "rkreglemarche"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rmnumero = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="N° de la règle",
    )
    rmechemin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Borne min de la fourchette Échéance (en nombre de mois)",
    )
    rmechemax = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Borne max de la fourchette Échéance (en nombre de mois)",
    )
    rmordre = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Ordre",
    )
    rmsizeanim = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Taille légale d'animation"
    )
    rmsizerddp = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Taille légale de DPP"
    )
    rmbidmin = db.Column(
        db.Numeric(13, 4), info="Borne min de la fourchette [Bid, Ask]"
    )
    rmbidmax = db.Column(
        db.Numeric(13, 4), info="Borne max de la fourchette [Bid, Ask]"
    )
    rmmontant = db.Column(db.Numeric(12, 4), info="Montant max de la largeur de quote")
    rmpourcent = db.Column(
        db.Numeric(4, 0, asdecimal=False), info="% max de la largeur de quote"
    )


class RkreglemarcheH(db.Model):
    __tablename__ = "rkreglemarche_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rhmnumero = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="N° de la règle"
    )
    rhmechemin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Borne min de la fourchette Échéance (en nombre de mois)",
    )
    rhmechemax = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Borne max de la fourchette Échéance (en nombre de mois)",
    )
    rhmordre = db.Column(
        db.Numeric(4, 0, asdecimal=False), nullable=False, info="Ordre"
    )
    rhmsizeanim = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Taille légale d'animation"
    )
    rhmsizerddp = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Taille légale de DPP"
    )
    rhmbidmin = db.Column(
        db.Numeric(13, 4), info="Borne min de la fourchette [Bid, Ask]"
    )
    rhmbidmax = db.Column(
        db.Numeric(13, 4), info="Borne max de la fourchette [Bid, Ask]"
    )
    rhmmontant = db.Column(db.Numeric(12, 4), info="Montant max de la largeur de quote")
    rhmpourcent = db.Column(
        db.Numeric(4, 0, asdecimal=False), info="% max de la largeur de quote"
    )
    rhmhorodate = db.Column(
        db.DateTime, nullable=False, info="Horodate de la mise à jour"
    )
    rhmuser = db.Column(db.String(60), info="Utilisateur ayant effectué la mise à jour")
    rhmtrait = db.Column(
        db.String(1), nullable=False, info="Type de traitement de mise à jour"
    )


class Rkreglesj(db.Model):
    __tablename__ = "rkreglesj"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("RSEXERCABILITE in ('E','A')"),
        db.CheckConstraint("RSEXERCABILITE in ('E','A')"),
        {"schema": "risque"},
    )

    rsbook = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code Book",
    )
    rscfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code CFIN",
    )
    rsexercabilite = db.Column(
        db.String(1),
        primary_key=True,
        nullable=False,
        info="Exerçabilité (E: Européen, A: Américain)",
    )
    rsmarche = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code marché",
    )
    rsregle = db.Column(db.Numeric(8, 0, asdecimal=False), info="N° de la règle")


class RkreglesjH(db.Model):
    __tablename__ = "rkreglesj_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rhsbook = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Code Book"
    )
    rhscfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Code CFIN"
    )
    rhsexercabilite = db.Column(
        db.String(1), nullable=False, info="Exerçabilité (E: Européen, A: Américain)"
    )
    rhsmarche = db.Column(db.Numeric(3, 0, asdecimal=False), info="Code marché")
    rhsregle = db.Column(db.Numeric(8, 0, asdecimal=False), info="N° de la règle")
    rhshorodate = db.Column(
        db.DateTime, nullable=False, info="Horodate de la mise à jour"
    )
    rhsuser = db.Column(db.String(60), info="Utilisateur ayant effectué la mise à jour")
    rhstrait = db.Column(
        db.String(1), nullable=False, info="Type de traitement de mise à jour"
    )


class Rkreglesquantdev(db.Model):
    __tablename__ = "rkreglesquantdev"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rqdmarche = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    rqdtype = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    rqdminenv = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    rqdtypeminenv = db.Column(
        db.ForeignKey("risque.rktypeminenv.tmetype", ondelete="CASCADE")
    )
    rqdmindev = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    rqdtypemindev = db.Column(
        db.ForeignKey("risque.rktypemindev.tmdtype", ondelete="CASCADE")
    )

    rktypemindev = db.relationship(
        "Rktypemindev",
        primaryjoin="Rkreglesquantdev.rqdtypemindev == Rktypemindev.tmdtype",
        backref="rkreglesquantdevs",
    )
    rktypeminenv = db.relationship(
        "Rktypeminenv",
        primaryjoin="Rkreglesquantdev.rqdtypeminenv == Rktypeminenv.tmetype",
        backref="rkreglesquantdevs",
    )


class Rkremarque(db.Model):
    __tablename__ = "rkremarque"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    renum = db.Column(db.Numeric(asdecimal=False))
    rebook = db.Column(db.Numeric(asdecimal=False))
    recfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    reuser = db.Column(db.Numeric(5, 0, asdecimal=False))
    retitre = db.Column(db.String(256))
    rerem = db.Column(db.String(1024))
    redate = db.Column(db.DateTime)
    remaj = db.Column(db.DateTime)
    restatut = db.Column(db.String(1))


class Rkrepo(db.Model):
    __tablename__ = "rkrepo"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rpcode = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    rpcodefinsj = db.Column(db.Numeric(8, 0, asdecimal=False))
    rpdate = db.Column(db.DateTime)
    rpcodebook = db.Column(db.Numeric(8, 0, asdecimal=False))
    rpdatepilier = db.Column(db.DateTime)
    rpvaleurpilier = db.Column(db.Numeric(12, 3))
    rpcontributeur = db.Column(db.Numeric(3, 0, asdecimal=False))
    rpcodefiltre = db.Column(db.ForeignKey("risque.rkfiltre.flcode"))
    rpcodesource = db.Column(db.Numeric(3, 0, asdecimal=False))
    rporigine = db.Column(db.Numeric(3, 0, asdecimal=False))

    rkfiltre = db.relationship(
        "Rkfiltre",
        primaryjoin="Rkrepo.rpcodefiltre == Rkfiltre.flcode",
        backref="rkrepoes",
    )


class Rkscriptindicateur(db.Model):
    __tablename__ = "rkscriptindicateurs"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}
    rowid = db.Column(db.Integer, primary_key=True)

    sidate = db.Column(db.DateTime, nullable=False, info="Date de pricing.")
    sicfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        info="Cfin du produit.",
    )
    sicle = db.Column(db.String(2048), nullable=False, info="Clé de l'indicateur.")
    sitype = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="Type de l'indicateur."
    )
    sivaleur = db.Column(
        db.Numeric(asdecimal=False), nullable=False, info="Valeur de l'indicateur."
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Rkscriptindicateur.sicfin == Instrument.ifcfin",
        backref="rkscriptindicateurs",
    )


class Rkstat(db.Model):
    __tablename__ = "rkstat"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    stcfin = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code du produit")
    stindice = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Indice de reference des calculs"
    )
    stbeta = db.Column(
        db.Numeric(6, 2),
        info="Coefficient de correlation entre l indice de reference et le produit",
    )
    stflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de mise \x05 jour")
    stnoterisk = db.Column(db.Numeric(2, 0, asdecimal=False))
    stliquidite = db.Column(db.Numeric(8, 4))


class Rkstatutconfirmation(db.Model):
    __tablename__ = "rkstatutconfirmation"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    tscode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du Statut de la Confirmation, saisie manuelle",
    )
    tsnom = db.Column(db.String(100), nullable=False)


class Rkstatutvalidation(db.Model):
    __tablename__ = "rkstatutvalidation"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    svcode = db.Column(
        db.String(1), primary_key=True, info="Code du statut de validation"
    )
    svlibelle = db.Column(
        db.String(80), nullable=False, info="Libéllé du statut de validation"
    )


class Rkstrike(db.Model):
    __tablename__ = "rkstrike"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("id_strike", "stbook", "stcfin"),
        db.Index("idx1_rkstrike", "stbook", "stecheance"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    stbook = db.Column(db.Numeric(4, 0, asdecimal=False))
    stecheance = db.Column(db.DateTime)
    stextype = db.Column(db.String(1))
    stcfin = db.Column(db.Numeric(8, 0, asdecimal=False), index=True)
    ststrike = db.Column(db.Numeric(13, 4))
    stsmile = db.Column(db.Numeric(8, 3))
    stcallput = db.Column(db.String(1))
    stflag = db.Column(db.Numeric(5, 0, asdecimal=False), index=True)
    stquotite = db.Column(db.Numeric(12, 4))
    stfv = db.Column(db.Numeric(asdecimal=False))
    stactif = db.Column(db.String(1))
    stvol = db.Column(db.Numeric(8, 3))
    stanimszbid = db.Column(db.Numeric(asdecimal=False))
    stanimszask = db.Column(db.Numeric(asdecimal=False))
    stcodif = db.Column(db.String(25))
    stordercode = db.Column(db.String(25))


class Rksystem(db.Model):
    __tablename__ = "rksystem"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    syid = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Identifier of a system that can book a deal",
    )
    syname = db.Column(db.String(20), nullable=False, info="Name of the system")


class Rktacolonne(db.Model):
    __tablename__ = "rktacolonnes"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tccolonne = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    tcnom = db.Column(db.String(50))


class Rktacomment(db.Model):
    __tablename__ = "rktacomment"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cocentre = db.Column(db.Numeric(4, 0, asdecimal=False), nullable=False)
    cocfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    cocomment = db.Column(db.String(100))


class Rktahisto(db.Model):
    __tablename__ = "rktahisto"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    thdate = db.Column(db.DateTime, nullable=False)
    thcentre = db.Column(db.Numeric(4, 0, asdecimal=False))
    thcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    thregul = db.Column(db.String(1))
    thpeinterne = db.Column(db.String(1))
    thdatesvg = db.Column(db.DateTime)
    thstockpeint = db.Column(db.Numeric(25, 5))
    thcapinonrefin = db.Column(db.Numeric(25, 5))
    thhaircut = db.Column(db.Numeric(25, 5))
    thprimeopt = db.Column(db.Numeric(25, 5))
    thdeposit = db.Column(db.Numeric(25, 5))
    thconsocompth = db.Column(db.Numeric(25, 5))
    thconsomixte = db.Column(db.Numeric(25, 5))
    thconsofront = db.Column(db.Numeric(25, 5))
    thpretree = db.Column(db.Numeric(25, 5))
    thempree = db.Column(db.Numeric(25, 5))
    thpretret = db.Column(db.Numeric(25, 5))
    thempret = db.Column(db.Numeric(25, 5))
    thcollat = db.Column(db.Numeric(25, 5))
    thpensliv = db.Column(db.Numeric(25, 5))
    thsoldeinit = db.Column(db.Numeric(25, 5))
    thuser = db.Column(db.Numeric(3, 0, asdecimal=False))
    thflag = db.Column(db.Numeric(1, 0, asdecimal=False))


class Rktauser(db.Model):
    __tablename__ = "rktauser"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tauser = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    tacolonnep = db.Column(db.String(1024))
    tacolonnecb = db.Column(db.String(500))
    tajourhisto = db.Column(db.Numeric(3, 0, asdecimal=False))
    tatrip = db.Column(db.Numeric(3, 0, asdecimal=False))
    tatricb = db.Column(db.Numeric(3, 0, asdecimal=False))


class Rktauserprod(db.Model):
    __tablename__ = "rktauserprod"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pruser = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    prtype = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    prmarche = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)


class Rktauxrepo(db.Model):
    __tablename__ = "rktauxrepo"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    trcfin = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    trbook = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    trflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Rktavalreg(db.Model):
    __tablename__ = "rktavalreg"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rucentre = db.Column(db.Numeric(4, 0, asdecimal=False), nullable=False)
    rucfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    rutype = db.Column(db.Numeric(1, 0, asdecimal=False))
    ruidcol = db.Column(db.Numeric(4, 0, asdecimal=False))
    rumontant = db.Column(db.Numeric(25, 5))


class Rktcsdeclaration(db.Model):
    __tablename__ = "rktcsdeclaration"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tdsource = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="The source of the declaration, could be PoTT or Codex",
    )
    tdtransactionid = db.Column(db.String(20), nullable=False, info="Transaction id")
    tdtcsrefid = db.Column(
        db.String(20), info="Reference cod generated by TCS for a transaction"
    )
    tdtransactionversion = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="The version of tcs state for a transaction",
    )
    tdfirstdeclarationdate = db.Column(db.DateTime, info="The first declaration date")
    tdlastdeclarationdate = db.Column(db.DateTime, info="The last declaration date")
    tdtcsstate = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="The tcs state"
    )
    tdmessagesent = db.Column(db.String(1024), info="The last message sent")
    tderror = db.Column(db.String(1024), info="The last error message")


class Rktickmarche(db.Model):
    __tablename__ = "rktickmarche"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tmmarche = db.Column(db.ForeignKey("exane.marche.macode"))
    tmordre = db.Column(db.Numeric(3, 0, asdecimal=False))
    tmmin = db.Column(db.Numeric(asdecimal=False))
    tmmax = db.Column(db.Numeric(asdecimal=False))
    tmarrondi = db.Column(db.Numeric(asdecimal=False))
    tmtypeinst = db.Column(db.ForeignKey("exane.typeinstrument.tycode"))
    tmtypesjac = db.Column(db.Numeric(3, 0, asdecimal=False))

    marche = db.relationship(
        "Marche",
        primaryjoin="Rktickmarche.tmmarche == Marche.macode",
        backref="rktickmarches",
    )
    typeinstrument = db.relationship(
        "Typeinstrument",
        primaryjoin="Rktickmarche.tmtypeinst == Typeinstrument.tycode",
        backref="typeinstrument_rktickmarches",
    )
    typeinstrument1 = db.relationship(
        "Typeinstrument",
        primaryjoin="Rktickmarche.tmtypesjac == Typeinstrument.tycode",
        backref="typeinstrument_rktickmarches_0",
    )


class RktickmarcheH(db.Model):
    __tablename__ = "rktickmarche_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    thmmarche = db.Column(db.Numeric(3, 0, asdecimal=False))
    thmordre = db.Column(db.Numeric(3, 0, asdecimal=False))
    thmmin = db.Column(db.Numeric(asdecimal=False))
    thmmax = db.Column(db.Numeric(asdecimal=False))
    thmarrondi = db.Column(db.Numeric(asdecimal=False))
    thmtypeinst = db.Column(db.Numeric(3, 0, asdecimal=False))
    thmtypesjac = db.Column(db.Numeric(3, 0, asdecimal=False))
    thmhorodate = db.Column(
        db.DateTime, nullable=False, info="Horodate de la mise à jour"
    )
    thmuser = db.Column(db.String(60), info="Utilisateur ayant effectué la mise à jour")
    thmtrait = db.Column(
        db.String(1), nullable=False, info="Type de traitement de mise à jour"
    )


class Rktypebigbook(db.Model):
    __tablename__ = "rktypebigbook"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tbcode = db.Column(db.Numeric(5, 0, asdecimal=False))
    tblibelle = db.Column(db.String(64))
    tbflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class Rktypebook(db.Model):
    __tablename__ = "rktypebook"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tbbooktype = db.Column(db.Numeric(2, 0, asdecimal=False), info="Code du type")
    tblibelle = db.Column(db.String(20), info="Libelle")
    tbflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Rktypeclause(db.Model):
    __tablename__ = "rktypeclause"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tctclause = db.Column(db.Numeric(2, 0, asdecimal=False), info="Type de clause")
    tclibelle = db.Column(db.String(20), info="Libelle")
    tcflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Rktypeclause6(db.Model):
    __tablename__ = "rktypeclause6"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tctclause = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        nullable=False,
        info="Identifiant du type de clause",
    )
    tclibelle = db.Column(db.String(32), info="Libellé correspondant")
    tcflag = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        info="Statut de l'enregistrement Nouveau ( 1), Modifié ( 2) ou Effacé ( 3)",
    )


class Rktypecompte(db.Model):
    __tablename__ = "rktypecompte"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tycode = db.Column(db.Numeric(2, 0, asdecimal=False))
    tylibelle = db.Column(db.String(16))
    tyflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Rktypedroiteden(db.Model):
    __tablename__ = "rktypedroiteden"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    tdtype = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="code du type d autorisation ",
    )
    tdlibelle = db.Column(db.String(32), info="libelle du type")


class Rktypeindicateur(db.Model):
    __tablename__ = "rktypeindicateur"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}
    rowid = db.Column(db.Integer, primary_key=True)

    ticode = db.Column(db.Numeric(8, 0, asdecimal=False))
    tilibelle = db.Column(db.String(30))
    tiflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class Rktypeinformationope(db.Model):
    __tablename__ = "rktypeinformationope"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    ticode = db.Column(db.Numeric(5, 0, asdecimal=False), primary_key=True)
    tilibelle = db.Column(db.String(30))
    tiactif = db.Column(db.String(1))


class Rktypemindev(db.Model):
    __tablename__ = "rktypemindev"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    tmdtype = db.Column(db.Numeric(2, 0, asdecimal=False), primary_key=True)
    tmdnom = db.Column(db.String(20), nullable=False)


class Rktypeminenv(db.Model):
    __tablename__ = "rktypeminenv"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    tmetype = db.Column(db.Numeric(2, 0, asdecimal=False), primary_key=True)
    tmenom = db.Column(db.String(20), nullable=False)


class Rktypemodepricing(db.Model):
    __tablename__ = "rktypemodepricing"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    mpcode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code du mode de pricing.",
    )
    mplibelle = db.Column(db.String(30), info="Libéllé du mode de pricing.")


class Rktypenappe(db.Model):
    __tablename__ = "rktypenappe"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    tncode = db.Column(db.Numeric(2, 0, asdecimal=False), primary_key=True)
    tnlibelle = db.Column(db.String(60))


class Rktypenoterisk(db.Model):
    __tablename__ = "rktypenoterisk"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tnnoterisk = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        nullable=False,
        info="Code interne de la note de risque superviseur",
    )
    tncode = db.Column(
        db.String(10),
        nullable=False,
        info="Code en clair de la note de risque superviseur",
    )
    tnflag = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="Flag de mise a jour"
    )


class Rktypeop(db.Model):
    __tablename__ = "rktypeop"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tootype = db.Column(db.Numeric(3, 0, asdecimal=False), info="Code Type operation")
    tolibelle = db.Column(db.String(20), info="Libelle type operation")
    toflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    tofamille = db.Column(db.Numeric(3, 0, asdecimal=False))
    toactif = db.Column(db.String(1))


class Rktypeprod(db.Model):
    __tablename__ = "rktypeprod"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tytype = db.Column(db.Numeric(3, 0, asdecimal=False), info="Code Type de produit")
    tynom = db.Column(db.String(15), info="Libelle du type de produit")
    tyflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Rktypesaisie(db.Model):
    __tablename__ = "rktypesaisie"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tscode = db.Column(db.Numeric(3, 0, asdecimal=False))
    tsnom = db.Column(db.String(60))
    tsflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Rktypescenario(db.Model):
    __tablename__ = "rktypescenario"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    tscode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tslibelle = db.Column(db.String(60))
    tsflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class Rkuser(db.Model):
    __tablename__ = "rkuser"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    ususer = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="Code User"
    )
    usgroupe = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Code Groupe (cf table RKGROUPE)"
    )
    usnom = db.Column(db.String(30), info="Nom du user")
    uspw = db.Column(db.String(8), info="Mot de passe du user")
    usflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    usadnom = db.Column(
        db.String(30), info="Login de l'utilisateur dans l'Active Directory"
    )


class Rkvendeurcircu(db.Model):
    __tablename__ = "rkvendeurcircus"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    vccode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    vcnom = db.Column(db.String(60))
    vcprenom = db.Column(db.String(60))
    vccodefront = db.Column(db.String(6))
    vcidcrm = db.Column(db.Numeric(8, 0, asdecimal=False), info="Identifiant CRM")
    vcloginad = db.Column(db.String(25), info="Login AD")
    vcflag = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Etat du vendeur",
    )
    vciddeskcrm = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Identifiant du desk dans la CRM"
    )
    vcnomdeskcrm = db.Column(db.String(50), info="Nom du desk dans la CRM")


class Rkvi(db.Model):
    __tablename__ = "rkvi"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("viexercice in ('A','E')"),
        db.CheckConstraint("viexercice in ('A','E')"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vicfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vidate = db.Column(db.DateTime, nullable=False)
    vistrike = db.Column(db.Numeric(12, 3), nullable=False)
    vimaturite = db.Column(db.DateTime, nullable=False)
    vivolatilite = db.Column(db.Numeric(18, 5))
    vispot = db.Column(db.Numeric(18, 5))
    viflag = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    vitype = db.Column(db.Numeric(3, 0, asdecimal=False))
    viexercice = db.Column(db.String(1))
    visource = db.Column(db.Numeric(3, 0, asdecimal=False))
    vicallput = db.Column(db.String(1))
    vivolume = db.Column(db.Numeric(11, 0, asdecimal=False))


class RkviH(db.Model):
    __tablename__ = "rkvi_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vicfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vidate = db.Column(db.DateTime, nullable=False)
    vistrike = db.Column(db.Numeric(12, 3), nullable=False)
    vimaturite = db.Column(db.DateTime, nullable=False)
    vivolatilite = db.Column(db.Numeric(18, 5))
    vispot = db.Column(db.Numeric(18, 5))
    viflag = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    vitype = db.Column(db.Numeric(3, 0, asdecimal=False))
    viexercice = db.Column(db.String(1))
    visource = db.Column(db.Numeric(3, 0, asdecimal=False))
    vicallput = db.Column(db.String(1))
    vivolume = db.Column(db.Numeric(11, 0, asdecimal=False))


class Rkvitrade(db.Model):
    __tablename__ = "rkvitrade"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vicfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vidate = db.Column(db.DateTime, nullable=False)
    vistrike = db.Column(db.Numeric(12, 3), nullable=False)
    vimaturite = db.Column(db.DateTime, nullable=False)
    vivolatilite = db.Column(db.Numeric(18, 5))
    vispot = db.Column(db.Numeric(18, 5))
    viflag = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    vitype = db.Column(db.Numeric(3, 0, asdecimal=False))
    viexercice = db.Column(db.String(1))
    visource = db.Column(db.Numeric(3, 0, asdecimal=False))
    vicallput = db.Column(db.String(1))
    vivolume = db.Column(db.Numeric(11, 0, asdecimal=False))
    vipremium = db.Column(db.Numeric(12, 3))


class RkvitradeH(db.Model):
    __tablename__ = "rkvitrade_h"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vicfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vidate = db.Column(db.DateTime, nullable=False)
    vistrike = db.Column(db.Numeric(12, 3), nullable=False)
    vimaturite = db.Column(db.DateTime, nullable=False)
    vivolatilite = db.Column(db.Numeric(18, 5))
    vispot = db.Column(db.Numeric(18, 5))
    viflag = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    vitype = db.Column(db.Numeric(3, 0, asdecimal=False))
    viexercice = db.Column(db.String(1))
    visource = db.Column(db.Numeric(3, 0, asdecimal=False))
    vicallput = db.Column(db.String(1))
    vivolume = db.Column(db.Numeric(11, 0, asdecimal=False))
    vipremium = db.Column(db.Numeric(12, 3))


class Rkvolat(db.Model):
    __tablename__ = "rkvolat"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vodate = db.Column(db.DateTime, info="Date")
    vocfin = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code CFIN")
    vovol = db.Column(db.Numeric(6, 3), info="Volatilite du produit")
    voflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Rkvolcentre(db.Model):
    __tablename__ = "rkvolcentre"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vccfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Code CFIN du produit (cf table RKPRODUIT)",
    )
    vcvolc = db.Column(db.Numeric(8, 2), info="Volatilite courte")
    vcvoll = db.Column(db.Numeric(8, 2), info="Volatilite longue")
    vcupdate = db.Column(db.DateTime, info="Date de mise a jour")
    vcflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Rkwar(db.Model):
    __tablename__ = "rkwar"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    wacfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    wastrike = db.Column(db.Numeric(10, 2))
    wadatedeb = db.Column(db.DateTime)
    wadatefin = db.Column(db.DateTime)
    wacp = db.Column(db.String(1))
    waremb = db.Column(db.Numeric(6, 2))
    waextype = db.Column(db.String(1))
    waassim = db.Column(db.String(1))
    waflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class Rkwarotc(db.Model):
    __tablename__ = "rkwarotc"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    wocfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    wobook = db.Column(db.Numeric(8, 0, asdecimal=False))
    wocfinoption = db.Column(db.Numeric(8, 0, asdecimal=False))


class Rkwarrisque(db.Model):
    __tablename__ = "rkwarrisque"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_rkwarrisque", "wacfin", "waflag"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    wacfin = db.Column(db.Numeric(8, 0, asdecimal=False), info="Code du produit")
    wastrike = db.Column(db.Numeric(10, 2), info="Prix d exercice")
    wadatedeb = db.Column(db.DateTime, info="Date de debut d exercice")
    wadatefin = db.Column(db.DateTime, info="Date de fin de vie ( maturite)")
    wacp = db.Column(db.String(1), info="Type d option Call ou Put")
    waecarttaux = db.Column(db.Numeric(8, 2), info="Inutilise")
    waremb = db.Column(db.Numeric(6, 2), info="Proportion remboursable en action")
    wasjvol = db.Column(db.Numeric(8, 3), info="Volatilite du sous-jacent")
    wasjtauxemp = db.Column(db.Numeric(8, 3), info="Taux d emprunt du sous-jacent")
    waextype = db.Column(db.String(1), info="Type d exercabilite")
    waregl = db.Column(db.String(1), info="Mode de reglement")
    wacouv = db.Column(db.String(1), info="Type de couverture")
    waassim = db.Column(db.String(1), info="Mode d assimilation")
    waactucoupon = db.Column(
        db.Numeric(8, 2), info="Taux d actualisation des dividendes"
    )
    watypecoupon = db.Column(db.String(1), info="Type de dividende % ou montant")
    wacoefaf = db.Column(
        db.Numeric(8, 3),
        info="Coef d avoir fiscal applicable au divididende du sous-jacent",
    )
    wacoefopda = db.Column(
        db.Numeric(8, 3), info="Coef d OPDA applicable au dividendes du sous-jacent"
    )
    waflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    wamaillage = db.Column(db.Numeric(8, 0, asdecimal=False))
    waupdate = db.Column(db.DateTime)
    watypestrike = db.Column(db.String(1))
    wahorizon = db.Column(db.Numeric(3, 0, asdecimal=False))


class Sensitaux(db.Model):
    __tablename__ = "sensitaux"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("STCube IN ('O','N')"),
        db.CheckConstraint("STPilierFictif IN ('O','N')"),
        db.CheckConstraint("STTypeCalcul IN ('B','E')"),
        db.CheckConstraint("STTypePilier IN ('M','S')"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    sttypecalcul = db.Column(
        db.String(1),
        nullable=False,
        info='Type de calcul : "B"ase (vendredi) ou "E"xtrapolé)',
    )
    stprofil = db.Column(
        db.ForeignKey("risque.prprofil.pprofil"),
        nullable=False,
        index=True,
        info="Profil utilisé.",
    )
    stcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        nullable=False,
        index=True,
        info="Instruments financier",
    )
    stcfincompo = db.Column(
        db.Numeric(8, 0, asdecimal=False), index=True, info="Code de la composition"
    )
    stbook = db.Column(
        db.Numeric(5, 0, asdecimal=False), index=True, info="Code du sous portefeuille"
    )
    stdtcalcul = db.Column(
        db.DateTime,
        nullable=False,
        index=True,
        server_default=db.FetchedValue(),
        info="Date de calcul du sensi",
    )
    stdtmax = db.Column(
        db.DateTime, info="Indicateur de pricing 47 de casper (TI_UNUSED)"
    )
    stdevise = db.Column(
        db.ForeignKey("exane.devise.dvcfin"), index=True, info="Devise utilisée"
    )
    sttypepilier = db.Column(
        db.String(1), info='Type du pilier : "M"aturité ou "S"ensi.'
    )
    stdtpilier = db.Column(db.DateTime, index=True, info="Date du pilier")
    stpilierfictif = db.Column(
        db.String(1),
        info="Définie si le pilier est fictif : dans le cas où il n'y a pas de sensi le vendredi rho/10 est placé sur la maturité du produit",
    )
    stidcourbe = db.Column(
        db.ForeignKey("exane.tauxcourbe.tcid"),
        index=True,
        info="Identifiant de la courbe de taux",
    )
    sttaux = db.Column(db.Numeric(8, 5), info="Valeur du taux")
    sttauxbbavtveille = db.Column(
        db.Numeric(8, 5), info="Taux avant veille de la fin de journée du bigbook"
    )
    stsensiextra = db.Column(
        db.Numeric(asdecimal=False), info="Calcul extrapolé des cubes des sensi ."
    )
    stsensireelle = db.Column(
        db.Numeric(asdecimal=False),
        info="Calcul réel des Sensi. Sensi calculée pour les produits vanilles ou SensiExtra pour les produits Monte Carlo",
    )
    stqtezc = db.Column(
        db.Numeric(asdecimal=False), info="Quantité Zéro Coupon pour un calcul basé"
    )
    strho = db.Column(
        db.Numeric(asdecimal=False), info='Rho pour les types de pilier "M"aturité'
    )
    stpose = db.Column(db.Numeric(20, 5), info="Position")
    stcrosseur = db.Column(
        db.Numeric(13, 5), info="Valeur du Cross par rapport à l'Euro."
    )
    stcube = db.Column(db.String(1), info='Si script Monte Carlo => "O" sinon "N"')
    sterreur = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="Code erreur du calcul"
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Sensitaux.stcfin == Instrument.ifcfin",
        backref="instrument_sensitauxes",
    )
    instrument1 = db.relationship(
        "Instrument",
        primaryjoin="Sensitaux.stcfincompo == Instrument.ifcfin",
        backref="instrument_sensitauxes_0",
    )
    devise = db.relationship(
        "Devise",
        primaryjoin="Sensitaux.stdevise == Devise.dvcfin",
        backref="devise_sensitauxes",
    )
    tauxcourbe = db.relationship(
        "Tauxcourbe",
        primaryjoin="Sensitaux.stidcourbe == Tauxcourbe.tcid",
        backref="sensitauxes",
    )
    prprofil = db.relationship(
        "Prprofil",
        primaryjoin="Sensitaux.stprofil == Prprofil.pprofil",
        backref="sensitauxes",
    )


class Tgactivparam(db.Model):
    __tablename__ = "tgactivparam"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    apusergroupe = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="Code du groupe d utilisateur ( cf RKGROUPE)",
    )
    apriskacf = db.Column(
        db.Numeric(5, 2), info="Coefficient du risque sur l arbitrage Cash/Futur"
    )
    apriskacfflag = db.Column(
        db.String(1),
        info="Flag d activation du calcul du risque d arbitrage Cash/futur",
    )
    apriskevtflag = db.Column(
        db.String(1), info="Flag d activation du calcul du risque evenementiel"
    )
    appointbaseflag = db.Column(
        db.String(1), info="Flag de prise en compte des modifieurs de points de base"
    )
    aptauxempflag = db.Column(
        db.String(1), info="Flag de prise en compte des modifieurs du taux d emprunt"
    )
    apvolatflag = db.Column(
        db.String(1), info="Flag de prise en compte des modifieurs de volatilite"
    )
    apavfflag = db.Column(
        db.String(1), info="Flag de prise en compte des modifieurs d avoir fiscal"
    )
    approbacallflag = db.Column(
        db.String(1), info="Flag de prise en compte des modifieurs de proba de call"
    )
    apflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    apnvolatflag = db.Column(db.String(1))


class Tgcalcdetail(db.Model):
    __tablename__ = "tgcalcdetail"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgcalcdetail", "cdcodecalcul", "cdcfin"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cdcodecalcul = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cdcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cdcompletion = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)


class Tgcalcparam(db.Model):
    __tablename__ = "tgcalcparam"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgcalcparam", "cpcodecalcul", "cpcodejeuparam"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cpcodecalcul = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cpcodejeuparam = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cpcentile = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    cpprof = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Profondeur de l'historique",
    )
    cphorizon = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cptypjour = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    cptypvar = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    cptypcomp = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    cpdevise = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)


class Tgcalcresult(db.Model):
    __tablename__ = "tgcalcresult"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "idx1_tgcalcresult",
            "crcodecalcul",
            "crcodejeuparam",
            "crchamp",
            "crbigbook",
            "crbook",
        ),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    crcodecalcul = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    crcodejeuparam = db.Column(db.Numeric(10, 0, asdecimal=False), nullable=False)
    crchamp = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    crbigbook = db.Column(db.Numeric(4, 0, asdecimal=False), nullable=False)
    crbook = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    crvalue = db.Column(db.Numeric(18, 2))
    crmarge = db.Column(db.Numeric(18, 2))
    crdatevalue = db.Column(db.DateTime)
    crdatemarge = db.Column(db.DateTime)


class Tgcalculvar(db.Model):
    __tablename__ = "tgcalculvar"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cacode = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False, index=True)
    cadate = db.Column(db.DateTime, nullable=False)
    cacodejeudata = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    causer = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)


class Tgcd(db.Model):
    __tablename__ = "tgcds"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cdcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cdcfincvt = db.Column(db.Numeric(8, 0, asdecimal=False))
    cdflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    cddatemaj = db.Column(db.DateTime, info="Date de mise a jour")
    cduser = db.Column(db.Numeric(3, 0, asdecimal=False), info="Responsable adossement")
    cdparfait = db.Column(db.String(1), info="Flag d'adossement parfait")


class Tgchamp(db.Model):
    __tablename__ = "tgchamp"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    chcode = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code du champ d analyse"
    )
    chnom = db.Column(db.String(32), info="Libelle complet du champ d analyse")
    chflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    chtype = db.Column(db.Numeric(3, 0, asdecimal=False))


class Tgdefchamp(db.Model):
    __tablename__ = "tgdefchamp"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dccode = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code du champ d analyse ( cf TGCHAMP)"
    )
    dcbigbook = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Code du portefeuille ( cf RKBIGBOOK)"
    )
    dcflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Tgecartaction(db.Model):
    __tablename__ = "tgecartaction"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    eausergroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    eacode = db.Column(db.String(1))
    eaecart = db.Column(db.Numeric(2, 0, asdecimal=False))
    eaflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Tgecartpay(db.Model):
    __tablename__ = "tgecartpays"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    epusergroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    epcode = db.Column(db.String(1))
    epecart = db.Column(db.Numeric(2, 0, asdecimal=False))
    epflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Tgemetexpo(db.Model):
    __tablename__ = "tgemetexpo"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    eeemet = db.Column(
        db.Numeric(4, 0, asdecimal=False), info="Code de l emetteur ( cf RKISSUER)"
    )
    eeexpoaction = db.Column(
        db.Numeric(12, 0, asdecimal=False), info="Limite d exposition ACTION"
    )
    eeexpoemetteur = db.Column(db.Numeric(12, 0, asdecimal=False))
    eeflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    eeusergroupe = db.Column(db.Numeric(3, 0, asdecimal=False))


class Tgetc(db.Model):
    __tablename__ = "tgetc"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    etusergroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    etcpex = db.Column(db.Numeric(12, 1))
    etfp = db.Column(db.Numeric(12, 1))


class Tggrec(db.Model):
    __tablename__ = "tggrecs"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx2_tggrecs_cfin", "grusergroupe", "grbook", "grcfin", "grdate"),
        db.Index("idx1__tggrecs_bigbook", "grusergroupe", "grbigbook", "grdate"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    grusergroupe = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    grbigbook = db.Column(db.Numeric(4, 0, asdecimal=False))
    grbook = db.Column(db.Numeric(5, 0, asdecimal=False))
    grcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    grdate = db.Column(db.DateTime, nullable=False)
    grvalo = db.Column(db.Numeric(asdecimal=False), nullable=False)
    grdelta = db.Column(db.Numeric(asdecimal=False), nullable=False)
    grrho = db.Column(db.Numeric(asdecimal=False), nullable=False)
    grgamma = db.Column(db.Numeric(asdecimal=False), nullable=False)
    grvega = db.Column(db.Numeric(asdecimal=False), nullable=False)
    grtheta = db.Column(db.Numeric(asdecimal=False), nullable=False)
    grvegapondere = db.Column(db.Numeric(asdecimal=False))
    grsega = db.Column(db.Numeric(asdecimal=False))


class Tgjeudatum(db.Model):
    __tablename__ = "tgjeudata"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgjeudata", "jddate", "jdcode"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    jddate = db.Column(db.DateTime, nullable=False)
    jdcode = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    jdnom = db.Column(db.String(10), nullable=False)
    jdflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Tgjeudataparam(db.Model):
    __tablename__ = "tgjeudataparam"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgjeudataparam", "dtdate", "dtcodejeudata", "dtcodejeuparam"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dtdate = db.Column(db.DateTime, nullable=False)
    dtcodejeudata = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    dtcodejeuparam = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    dtflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Tgjeudataperim(db.Model):
    __tablename__ = "tgjeudataperim"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "idx1_tgjeudataperim",
            "dpdate",
            "dpcodejeudata",
            "dpchamp",
            "dpbigbook",
            "dpbook",
        ),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dpdate = db.Column(db.DateTime, nullable=False)
    dpcodejeudata = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    dpchamp = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    dpbigbook = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    dpbook = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    dpflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Tgjeuparam(db.Model):
    __tablename__ = "tgjeuparam"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgjeuparam", "jpdate", "jpcode"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    jpdate = db.Column(db.DateTime, nullable=False)
    jpcode = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    jpnom = db.Column(db.String(10), nullable=False)
    jpcentile = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    jpprof = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    jphorizon = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    jptypjour = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    jptypvar = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    jptypcomp = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    jphisto = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    jpflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Tglimiteexposition(db.Model):
    __tablename__ = "tglimiteexposition"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    lechamp = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code du champ d analyse ( cf TGCHAMP)"
    )
    leusergroupe = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="Code du groupe d utilisateur ( cf RKGROUPE)",
    )
    leexpoaction = db.Column(
        db.Numeric(12, 0, asdecimal=False), info="Limite d exposition ACTION"
    )
    leexpoemetteur = db.Column(
        db.Numeric(12, 0, asdecimal=False), info="Limite d exposition EMETTEUR"
    )
    leflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Tglimiteposition(db.Model):
    __tablename__ = "tglimiteposition"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    lpchamp = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code du champ d analyse ( cf TGCHAMP)"
    )
    lpusergroupe = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="Code du groupe d utilisateur ( cf RKGROUPE)",
    )
    lptypeprod = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="Code du type de produit ( cf RKTYPEPROD)",
    )
    lpvlshort = db.Column(db.Numeric(14, 2), info="Limite de valorisation SHORT")
    lpvllong = db.Column(db.Numeric(14, 2), info="Limite de valorisation LONG")
    lpflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")


class Tglimiteriskext(db.Model):
    __tablename__ = "tglimiteriskext"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    lrusergroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    lrchampanalyse = db.Column(db.Numeric(8, 0, asdecimal=False))
    lrchange = db.Column(db.Numeric(13, 2))
    lrtaux = db.Column(db.Numeric(13, 2))
    lrindices = db.Column(db.Numeric(13, 2))
    lrvolatilites = db.Column(db.Numeric(13, 2))
    lrsignatures = db.Column(db.Numeric(13, 2))
    lrcourbe = db.Column(db.Numeric(13, 2))
    lrpays = db.Column(db.Numeric(13, 2))
    lrstatistiques = db.Column(db.Numeric(13, 2))
    lrevenementiel = db.Column(db.Numeric(13, 2))
    lrevaluation = db.Column(db.Numeric(13, 2))
    lrsystematique = db.Column(db.Numeric(13, 2))
    lrspecifique = db.Column(db.Numeric(13, 2))
    lrautres = db.Column(db.Numeric(13, 2))
    lrcrash = db.Column(db.Numeric(13, 2))
    lraic = db.Column(db.Numeric(13, 2))
    lraction = db.Column(db.Numeric(13, 2))
    lremetteur = db.Column(db.Numeric(13, 2))
    lrusd = db.Column(db.Numeric(13, 2))
    lrdem = db.Column(db.Numeric(13, 2))
    lrgbp = db.Column(db.Numeric(13, 2))
    lrchf = db.Column(db.Numeric(13, 2))
    lritl = db.Column(db.Numeric(13, 2))
    lrnlg = db.Column(db.Numeric(13, 2))
    lresp = db.Column(db.Numeric(13, 2))
    lrxeu = db.Column(db.Numeric(13, 2))
    lrjpy = db.Column(db.Numeric(13, 2))
    lrhkd = db.Column(db.Numeric(13, 2))
    lrflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    lrsek = db.Column(db.Numeric(13, 2))
    lrdkk = db.Column(db.Numeric(13, 2))
    lrfrf = db.Column(db.Numeric(13, 2))
    lrspecsign = db.Column(db.Numeric(13, 2))


class Tgliqucoeffparam(db.Model):
    __tablename__ = "tgliqucoeffparam"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    lcusergroupe = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    lctypeproduit = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    lcplage = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    lccoefflong = db.Column(db.Numeric(7, 5), nullable=False)
    lccoeffshort = db.Column(db.Numeric(7, 5), nullable=False)
    lcflag = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)


class Tgliqugenparam(db.Model):
    __tablename__ = "tgliqugenparam"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    lgusergroupe = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    lgnbjours = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    lgflag = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)


class Tgliquplageparam(db.Model):
    __tablename__ = "tgliquplageparam"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    lpcode = db.Column(db.Numeric(asdecimal=False), nullable=False)
    lpnom = db.Column(db.String(50), nullable=False)
    lpflag = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    lpnbjours = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)


class Tgphiparam(db.Model):
    __tablename__ = "tgphiparam"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.CheckConstraint("PHTYPE in(0,1)"),
        db.Index("idx2_tgphiparam", "phtype", "phspot", "phdate"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phdate = db.Column(db.DateTime, nullable=False, index=True)
    phtype = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    phspot = db.Column(db.Numeric(asdecimal=False), nullable=False)
    phphi = db.Column(db.Numeric(asdecimal=False), nullable=False)
    phflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class Tgprdparam(db.Model):
    __tablename__ = "tgprdparam"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ppusergroupe = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="Code du groupe d utilisateur ( cf RKGROUPE)",
    )
    pptype = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Code du type ( cf RKTYPEPROD)"
    )
    pppointbaselow = db.Column(
        db.Numeric(5, 2), info="Coeff de minoration des points de base"
    )
    pppointbasehigh = db.Column(
        db.Numeric(5, 2), info="Coeff de majoration des points de base"
    )
    pptauxemplow = db.Column(
        db.Numeric(5, 2), info="Coeff de minoration du taux d emprunt"
    )
    pptauxemphigh = db.Column(
        db.Numeric(5, 2), info="Coeff de majoration du taux d emprunt"
    )
    ppvolatlow = db.Column(
        db.Numeric(5, 2), info="Coeff de minoration de la volatilite"
    )
    ppvolathigh = db.Column(
        db.Numeric(5, 2), info="Coeff de majoration de la volatilite"
    )
    ppavflow = db.Column(db.Numeric(5, 2), info="Coeff de minoration de l avoir fiscal")
    ppavfhigh = db.Column(
        db.Numeric(5, 2), info="Coeff de majoration de l avoir fiscal"
    )
    ppprobacalllow = db.Column(
        db.Numeric(5, 2), info="Probabilite minimum d une clause de Call"
    )
    ppprobacallhigh = db.Column(
        db.Numeric(5, 2), info="Probabilite maximum d une clause de Call"
    )
    ppcoeffspec = db.Column(
        db.Numeric(5, 3), info="Coefficient du risque specifique obligataire"
    )
    ppponderation = db.Column(
        db.String(1), info="Flag d activation de la ponderation par la duration"
    )
    ppactivation = db.Column(
        db.String(1),
        info="Flag d activation du calcul du risque specifique obligataire",
    )
    ppflag = db.Column(db.Numeric(5, 0, asdecimal=False), info="Flag de suppression")
    ppnvolat = db.Column(db.String(1))


class Tgprodderive(db.Model):
    __tablename__ = "tgprodderive"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgprodderive", "prdate", "prtprod", "prcfin", "prsjac"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    prdate = db.Column(db.DateTime, nullable=False)
    prtprod = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    prcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    prsjac = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    prcoef = db.Column(db.Numeric(24, 15), nullable=False)
    prflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Tgrescontrepartie(db.Model):
    __tablename__ = "tgrescontrepartie"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgrescontrepartie", "rcdate", "rcchamp"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rctiers = db.Column(db.Numeric(8, 0, asdecimal=False))
    rcchamp = db.Column(db.Numeric(asdecimal=False))
    rcdate = db.Column(db.DateTime)
    rcfp = db.Column(db.Numeric(asdecimal=False))
    rcmtm = db.Column(db.Numeric(asdecimal=False))
    rcnominaltotal = db.Column(db.Numeric(asdecimal=False))
    rcnominalachat = db.Column(db.Numeric(asdecimal=False))
    rcnominalachatput = db.Column(db.Numeric(asdecimal=False))
    rcrpf = db.Column(db.Numeric(asdecimal=False))


class Tgresexpoaction(db.Model):
    __tablename__ = "tgresexpoaction"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgresexpoaction", "radate", "rausergroupe", "rachampanalyse"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    radate = db.Column(db.DateTime)
    rausergroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    rachampanalyse = db.Column(db.Numeric(8, 0, asdecimal=False))
    racfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    raexpo = db.Column(db.Numeric(12, 1))
    ramarket = db.Column(db.Numeric(12, 1))
    raexces = db.Column(db.Numeric(12, 1))
    raflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Tgresexpoemetteur(db.Model):
    __tablename__ = "tgresexpoemetteur"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgresexpoemetteur", "redate", "reusergroupe", "rechampanalyse"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    redate = db.Column(db.DateTime)
    reusergroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    rechampanalyse = db.Column(db.Numeric(8, 0, asdecimal=False))
    reissuer = db.Column(db.Numeric(8, 0, asdecimal=False))
    reexpo = db.Column(db.Numeric(12, 1))
    reexces = db.Column(db.Numeric(12, 1))
    reflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    reexcescpex = db.Column(db.Numeric(12, 1))


class Tgresgen(db.Model):
    __tablename__ = "tgresgen"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgresgen", "rgdate", "rgusergroupe", "rgchampanalyse"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rgdate = db.Column(db.DateTime)
    rgusergroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    rgchampanalyse = db.Column(db.Numeric(8, 0, asdecimal=False))
    rgchange = db.Column(db.Numeric(12, 1))
    rgtaux = db.Column(db.Numeric(12, 1))
    rgindices = db.Column(db.Numeric(12, 1))
    rgvolatilites = db.Column(db.Numeric(12, 1))
    rgsignatures = db.Column(db.Numeric(12, 1))
    rgcourbe = db.Column(db.Numeric(12, 1))
    rgpays = db.Column(db.Numeric(12, 1))
    rgstatistiques = db.Column(db.Numeric(12, 1))
    rgevenementiel = db.Column(db.Numeric(12, 1))
    rgevaluation = db.Column(db.Numeric(12, 1))
    rgsystematique = db.Column(db.Numeric(12, 1))
    rgspecifique = db.Column(db.Numeric(12, 1))
    rgautres = db.Column(db.Numeric(12, 1))
    rgcrash = db.Column(db.Numeric(12, 1))
    rgaic = db.Column(db.Numeric(12, 1))
    rgusd = db.Column(db.Numeric(12, 1))
    rgdem = db.Column(db.Numeric(12, 1))
    rggbp = db.Column(db.Numeric(12, 1))
    rgchf = db.Column(db.Numeric(12, 1))
    rgitl = db.Column(db.Numeric(12, 1))
    rgfrf = db.Column(db.Numeric(12, 1))
    rgnlg = db.Column(db.Numeric(12, 1))
    rgesp = db.Column(db.Numeric(12, 1))
    rgxeu = db.Column(db.Numeric(12, 1))
    rgjpy = db.Column(db.Numeric(12, 1))
    rghkd = db.Column(db.Numeric(12, 1))
    rgflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    rgbef = db.Column(db.Numeric(12, 1))
    rgsek = db.Column(db.Numeric(12, 1))
    rgdkk = db.Column(db.Numeric(12, 1))
    rgdateexe = db.Column(db.DateTime)
    rgdatepnl = db.Column(db.DateTime)
    rduserexe = db.Column(db.Numeric(5, 0, asdecimal=False))
    rgliquidite = db.Column(db.Numeric(12, 1))
    rgdecote = db.Column(db.Numeric(12, 1))
    rgsurcote = db.Column(db.Numeric(12, 1))
    rgecarttheo = db.Column(db.Numeric(12, 1))
    rgaiccorrigee = db.Column(db.Numeric(12, 1))
    rgspecsign = db.Column(db.Numeric(12, 1))
    rgcorrelation = db.Column(db.Numeric(12, 1))
    rgdividendes = db.Column(db.Numeric(12, 1), info="Risque de dividende")


class Tgresmatrice(db.Model):
    __tablename__ = "tgresmatrice"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgresmatrice", "rmusergroupe", "rmchampanalyse"),
        db.Index("idx2_tgresmatrice", "rmdate", "rmusergroupe", "rmchampanalyse"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rmdate = db.Column(db.DateTime)
    rmusergroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    rmchampanalyse = db.Column(db.Numeric(8, 0, asdecimal=False))
    rmligne = db.Column(db.Numeric(5, 0, asdecimal=False))
    rmcrash = db.Column(db.Numeric(12, 1))
    rmcentral = db.Column(db.Numeric(12, 1))
    rmtauxh = db.Column(db.Numeric(12, 1))
    rmtauxb = db.Column(db.Numeric(12, 1))
    rmvolh = db.Column(db.Numeric(12, 1))
    rmvolb = db.Column(db.Numeric(12, 1))
    rmsignatureh = db.Column(db.Numeric(12, 1))
    rmsignatureb = db.Column(db.Numeric(12, 1))
    rmflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    rmnvolh = db.Column(db.Numeric(12, 1))
    rmnvolb = db.Column(db.Numeric(12, 1))
    rmnsign = db.Column(db.Numeric(12, 1))


class Tgresotc(db.Model):
    __tablename__ = "tgresotc"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgresotc", "rodate", "rochamp"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rotiers = db.Column(db.Numeric(8, 0, asdecimal=False))
    rochamp = db.Column(db.Numeric(asdecimal=False))
    rodate = db.Column(db.DateTime)
    ropos = db.Column(db.Numeric(asdecimal=False))
    rotype = db.Column(db.String(1))
    rosj = db.Column(db.Numeric(8, 0, asdecimal=False))
    rostrike = db.Column(db.Numeric(asdecimal=False))
    romaturite = db.Column(db.DateTime)
    ronominal = db.Column(db.Numeric(asdecimal=False))
    rospot = db.Column(db.Numeric(asdecimal=False))
    romtm = db.Column(db.Numeric(asdecimal=False))


class Tgresposition(db.Model):
    __tablename__ = "tgresposition"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgresposition", "rpchampanalyse", "rpusergroupe", "rpdate"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rpdate = db.Column(db.DateTime)
    rpusergroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    rpchampanalyse = db.Column(db.Numeric(8, 0, asdecimal=False))
    rptypeproduit = db.Column(db.Numeric(3, 0, asdecimal=False))
    rpcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    rpvalolatente = db.Column(db.Numeric(12, 1))
    rpmarket = db.Column(db.Numeric(3, 0, asdecimal=False))
    rpexces = db.Column(db.Numeric(12, 1))
    rpflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Tgrespospondere(db.Model):
    __tablename__ = "tgrespospondere"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgrespospondere", "rpdate", "rpusergroupe", "rpchampanalyse"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rpusergroupe = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    rpchampanalyse = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    rpdate = db.Column(db.DateTime, nullable=False)
    rpdev = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    rpppncl1 = db.Column(db.Numeric(asdecimal=False), nullable=False)
    rpppncc1 = db.Column(db.Numeric(asdecimal=False))
    rpppc1 = db.Column(db.Numeric(asdecimal=False))
    rpppnc1 = db.Column(db.Numeric(asdecimal=False))
    rpppncl2 = db.Column(db.Numeric(asdecimal=False))
    rpppncc2 = db.Column(db.Numeric(asdecimal=False))
    rpppc2 = db.Column(db.Numeric(asdecimal=False))
    rpppnc2 = db.Column(db.Numeric(asdecimal=False))
    rpppncl3 = db.Column(db.Numeric(asdecimal=False))
    rpppncc3 = db.Column(db.Numeric(asdecimal=False))
    rpppc3 = db.Column(db.Numeric(asdecimal=False))
    rpppnc3 = db.Column(db.Numeric(asdecimal=False))
    rpx12 = db.Column(db.Numeric(asdecimal=False))
    rpz1 = db.Column(db.Numeric(asdecimal=False))
    rpz2 = db.Column(db.Numeric(asdecimal=False))
    rpx23 = db.Column(db.Numeric(asdecimal=False))
    rpz3 = db.Column(db.Numeric(asdecimal=False))
    rpz2ult = db.Column(db.Numeric(asdecimal=False))
    rpx13 = db.Column(db.Numeric(asdecimal=False))
    rpz1ult = db.Column(db.Numeric(asdecimal=False))
    rpz3ult = db.Column(db.Numeric(asdecimal=False))
    rpfp = db.Column(db.Numeric(asdecimal=False))
    rpflag = db.Column(db.Numeric(asdecimal=False), nullable=False)


class Tgresposspectaux(db.Model):
    __tablename__ = "tgresposspectaux"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgresposspectaux", "rpdate", "rpusergroupe", "rpchampanalyse"),
        {"schema": "risque"},
    )

    rpusergroupe = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    rpchampanalyse = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    rpcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    rpdate = db.Column(db.DateTime)
    rpposition = db.Column(db.Numeric(asdecimal=False), nullable=False)
    rpduration = db.Column(db.Numeric(asdecimal=False), nullable=False)
    rpplancher = db.Column(db.Numeric(asdecimal=False), nullable=False)
    rpvalo = db.Column(db.Numeric(asdecimal=False), nullable=False)
    rpvalopondere = db.Column(db.Numeric(asdecimal=False), nullable=False)
    rpeligible = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    rprho = db.Column(db.Numeric(asdecimal=False))
    rpprime = db.Column(db.Numeric(asdecimal=False))
    rpdeltanorme = db.Column(db.Numeric(asdecimal=False))
    rpspread = db.Column(db.Numeric(asdecimal=False))


class Tgresratiosensibilite(db.Model):
    __tablename__ = "tgresratiosensibilite"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index(
            "idx1_tgresratiosensibilite", "rrdate", "rrusergroupe", "rrchampanalyse"
        ),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rrdate = db.Column(db.DateTime)
    rrusergroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    rrchampanalyse = db.Column(db.Numeric(8, 0, asdecimal=False))
    rrtype = db.Column(db.Numeric(3, 0, asdecimal=False))
    rrsensibilite = db.Column(db.Numeric(12, 1))
    rrvega = db.Column(db.Numeric(12, 1))
    rrtheta = db.Column(db.Numeric(12, 1))
    rrflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    rrgamma = db.Column(db.Numeric(12, 1))
    rrdelta = db.Column(db.Numeric(12, 1))
    rrvalo = db.Column(db.Numeric(asdecimal=False))
    rrvegapondere = db.Column(db.Numeric(12, 1))
    rrsega = db.Column(db.Numeric(12, 1))


class Tgresvalo(db.Model):
    __tablename__ = "tgresvalo"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgresvalo", "radate", "rausergroupe"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    radate = db.Column(db.DateTime)
    rausergroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    racfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    ravalo = db.Column(db.Numeric(12, 1))
    raflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Tgresvaloexpo(db.Model):
    __tablename__ = "tgresvaloexpo"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgresvaloexpo", "rvdate", "rvusergroupe", "rvchampanalyse"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rvdate = db.Column(db.DateTime)
    rvusergroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    rvchampanalyse = db.Column(db.Numeric(8, 0, asdecimal=False))
    rvtype = db.Column(db.Numeric(3, 0, asdecimal=False))
    rvcac = db.Column(db.Numeric(12, 1))
    rvdax = db.Column(db.Numeric(12, 1))
    rvftse = db.Column(db.Numeric(12, 1))
    rvsmi = db.Column(db.Numeric(12, 1))
    rvsnp = db.Column(db.Numeric(12, 1))
    rvglobal = db.Column(db.Numeric(12, 1))
    rvflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    rvmib = db.Column(db.Numeric(12, 1))
    rvaex = db.Column(db.Numeric(12, 1))
    rvstoxx = db.Column(db.Numeric(12, 1))
    rveurostoxx = db.Column(db.Numeric(12, 1))
    rvnikei = db.Column(db.Numeric(12, 1))
    rvbel = db.Column(db.Numeric(12, 1))
    rvnasdaq = db.Column(db.Numeric(12, 1))
    rvibex = db.Column(db.Numeric(12, 1))
    rvtse = db.Column(db.Numeric(12, 1))
    rvautre = db.Column(db.Numeric(12, 1))


class Tgseuil(db.Model):
    __tablename__ = "tgseuil"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    setiers = db.Column(db.Numeric(8, 0, asdecimal=False))
    seseuil = db.Column(db.Numeric(asdecimal=False))
    senetting = db.Column(db.String(1))


class Tgsjparam(db.Model):
    __tablename__ = "tgsjparam"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    sjdate = db.Column(db.DateTime, primary_key=True, nullable=False, index=True)
    sjcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    sjvic = db.Column(db.Numeric(asdecimal=False), nullable=False)
    sjvil = db.Column(db.Numeric(asdecimal=False), nullable=False)
    sjvh = db.Column(db.Numeric(asdecimal=False), nullable=False)


class Tgvalorisation(db.Model):
    __tablename__ = "tgvalorisation"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx2_tgvalorisation", "vldate", "vlbook"),
        db.Index("idx1_tgvalorisation", "vlcfin", "vlbook", "vldate"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vldate = db.Column(db.DateTime, nullable=False)
    vlbook = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    vlcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vlcontextid = db.Column(db.Numeric(6, 0, asdecimal=False))
    vlcourssj = db.Column(db.Numeric(13, 5))
    vlpos = db.Column(db.Numeric(13, 0, asdecimal=False))
    vlsjvol = db.Column(db.Numeric(8, 3))
    vlprixtheo = db.Column(db.Numeric(asdecimal=False))
    vlvalo = db.Column(db.Numeric(asdecimal=False))
    vldelta = db.Column(db.Numeric(asdecimal=False))
    vlgamma = db.Column(db.Numeric(asdecimal=False))
    vlrho = db.Column(db.Numeric(asdecimal=False))
    vltheta = db.Column(db.Numeric(asdecimal=False))
    vlvega = db.Column(db.Numeric(asdecimal=False))
    vldatestockage = db.Column(db.DateTime, nullable=False)
    vlflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    vlquotite = db.Column(db.Numeric(12, 4))
    vlstatut = db.Column(db.Numeric(5, 0, asdecimal=False))
    vltype = db.Column(db.Numeric(5, 0, asdecimal=False))
    vlspread = db.Column(db.Numeric(asdecimal=False))
    vlsega = db.Column(db.Numeric(asdecimal=False))
    vlvegapondere = db.Column(db.Numeric(asdecimal=False))
    vlsensidiv = db.Column(db.Numeric(asdecimal=False))


class TgvalorisationRho(db.Model):
    __tablename__ = "tgvalorisation_rho"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgvalorisation_rho", "vrcfin", "vrbook", "vrdate"),
        db.Index("idx2_tgvalorisation_rho", "vrdate", "vrbook"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vrdate = db.Column(db.DateTime, nullable=False)
    vrbook = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    vrcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vrcontextid = db.Column(db.Numeric(6, 0, asdecimal=False), nullable=False)
    vrdev = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vrrho = db.Column(db.Numeric(asdecimal=False), nullable=False)
    vrflag = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)


class TgvalorisationSensich(db.Model):
    __tablename__ = "tgvalorisation_sensich"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("idx1_tgvalorisation_sensich", "vscfin", "vsbook", "vsdate"),
        db.Index("idx2_tgvalorisation_sensich", "vsdate", "vsbook"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vsdate = db.Column(db.DateTime, nullable=False)
    vsbook = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    vscfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vscontextid = db.Column(db.Numeric(6, 0, asdecimal=False), nullable=False)
    vsdev = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vssensichange = db.Column(db.Numeric(asdecimal=False), nullable=False)
    vsflag = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)


class Tgvarcompo(db.Model):
    __tablename__ = "tgvarcompo"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("ix_tgvarcompo", "vcpdate", "vcpcfin", "vcpsjac"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vcpdate = db.Column(db.DateTime, nullable=False)
    vcpcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    vcpsjac = db.Column(db.Numeric(8, 0, asdecimal=False))
    vcpproportion = db.Column(db.Numeric(24, 15))
    vcpparite = db.Column(db.Numeric(11, 5))
    vcpflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Tgvarderive(db.Model):
    __tablename__ = "tgvarderive"
    __bind_key__ = "exane_risque"
    __table_args__ = (
        db.Index("ix_tgvarderive", "vdedate", "vdecfin", "vdesjac"),
        {"schema": "risque"},
    )

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vdedate = db.Column(db.DateTime, nullable=False)
    vdecfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vdesjac = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vdeflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class Tgvarexclu(db.Model):
    __tablename__ = "tgvarexclus"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    veuser = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    vechamp = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vebigbook = db.Column(db.Numeric(4, 0, asdecimal=False), nullable=False)
    vebook = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    vecode = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)


class Tgvarrisque(db.Model):
    __tablename__ = "tgvarrisque"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vrusergroupe = db.Column(db.Numeric(3, 0, asdecimal=False))
    vrmarchetaux = db.Column(db.Numeric(2, 0, asdecimal=False))
    vrmarcheaction = db.Column(db.Numeric(2, 0, asdecimal=False))
    vrchange = db.Column(db.Numeric(2, 0, asdecimal=False))
    vrcourbetaux = db.Column(db.Numeric(3, 0, asdecimal=False))
    vrspecactionevt = db.Column(db.String(1))
    vrflag = db.Column(db.Numeric(3, 0, asdecimal=False))
    vrvalolong = db.Column(db.Numeric(12, 0, asdecimal=False))
    vrvaloshort = db.Column(db.Numeric(12, 0, asdecimal=False))


class Tgvolparam(db.Model):
    __tablename__ = "tgvolparam"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vodate = db.Column(db.DateTime, nullable=False, index=True)
    votc = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    votl = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vorac = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    voc1 = db.Column(db.Numeric(asdecimal=False), nullable=False)
    voc2 = db.Column(db.Numeric(asdecimal=False), nullable=False)
    voc3 = db.Column(db.Numeric(asdecimal=False), nullable=False)
    voc4 = db.Column(db.Numeric(asdecimal=False), nullable=False)
    voc5 = db.Column(db.Numeric(asdecimal=False), nullable=False)
    voc6 = db.Column(db.Numeric(asdecimal=False), nullable=False)
    voc7 = db.Column(db.Numeric(asdecimal=False), nullable=False)
    voc8 = db.Column(db.Numeric(asdecimal=False), nullable=False)
    voflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class Typecpindex(db.Model):
    __tablename__ = "typecpindex"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    ticode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="Identifiant du type"
    )
    tilibelle = db.Column(db.String(60), info="Libell‚ du type d'entree dans HCPINDEX")


class Typesourceindex(db.Model):
    __tablename__ = "typesourceindex"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    tscode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Identifiant de la source",
    )
    tslibelle = db.Column(
        db.String(60), info="Libell‚ de la source d'entree dans HCPINDEX"
    )


class VBookInstrumentsPo(db.Model):
    __tablename__ = "v_book_instruments_pos"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    enid = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    enlibelle = db.Column(db.String(32))
    bgtype = db.Column(db.String(1))
    bgcodebud = db.Column(db.String(10))
    bgfe = db.Column(db.String(1))
    tblibelle = db.Column(db.String(64))
    bgnom = db.Column(db.String(15))
    bbbigbook = db.Column(db.Numeric(4, 0, asdecimal=False), nullable=False)
    bbnom = db.Column(db.String(30))
    dbbook = db.Column(db.Numeric(5, 0, asdecimal=False), nullable=False)
    dbnom = db.Column(db.String(60))
    ifcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    ifstatut = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    iftype = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    ifnom = db.Column(db.String(60), nullable=False)
    ifpayoff = db.Column(db.Numeric(3, 0, asdecimal=False))
    ifcontrat = db.Column(db.Numeric(3, 0, asdecimal=False))
    podate = db.Column(db.DateTime)
    en_posistion = db.Column(db.String(3))


class VCfinBigbookEnPosition(db.Model):
    __tablename__ = "v_cfin_bigbook_en_position"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    date_pos = db.Column(db.DateTime)
    cfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code de l'instrument financier"
    )
    book = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="Code du sous portefeuille"
    )
    nom_book = db.Column(db.String(60), info="Nom du sous portefeuille")
    bigbook = db.Column(db.Numeric(4, 0, asdecimal=False), info="Code du portefeuille")
    nom_bigbook = db.Column(db.String(30), info="Nom du portefeuille")


class VCfinEnposition(db.Model):
    __tablename__ = "v_cfin_enposition"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pocfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )


class VCfinEnpositionTransparence(db.Model):
    __tablename__ = "v_cfin_enposition_transparence"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cfin = db.Column(db.Numeric(asdecimal=False), info="Code de l'instrument financier")
    positiondirecte = db.Column(
        db.String(1), info=' "O" si le produit est en position directement'
    )
    positionindirecte = db.Column(
        db.String(1), info=' "O" si le produit est en position directement'
    )
    soldenoneuro = db.Column(
        db.String(1),
        info=" \"O\" si le produit possède du solde sur une devise qui n'est pas de l'euro",
    )


class VCfinPortefeuille(db.Model):
    __tablename__ = "v_cfin_portefeuilles"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    instrument = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Cfin de l'instrument recherché"
    )
    portefeuille = db.Column(
        db.Numeric(4, 0, asdecimal=False), info="Portefeuille contenant l'instrument"
    )
    sousportefeuille = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        nullable=False,
        info="Sous-portefeuille contenant l'instrument",
    )
    type_portefeuille = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        info="Type de portefeuille contenant l'instrument",
    )
    nom_portefeuille = db.Column(
        db.String(60), info="Nom du portefeuille contenant l'instrument"
    )
    cfin_portefeuille = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Cfin en portefeuille"
    )
    profondeur = db.Column(
        db.Numeric(asdecimal=False),
        info="Profondeur de composition 0 pas dans une compo, 1 dans une compo, 2 dans une compo de compo...",
    )
    chemin = db.Column(db.String(172), info="Chemin deplus au niveau vers le produit")
    compo_de_compo_de_compo = db.Column(
        db.Numeric(asdecimal=False),
        info="Cfin éventuel du composite de composite de composite contenant l'instrument",
    )
    compo_de_compo = db.Column(
        db.Numeric(asdecimal=False),
        info="Cfin éventuel du composite de composite contenant l'instrument",
    )
    compo = db.Column(
        db.Numeric(asdecimal=False),
        info="Cfin éventuel du composite contenant l'instrument",
    )
    compo_de_compo_de_compo_qte = db.Column(
        db.Numeric(asdecimal=False),
        info="Quantité à appliquer pour la composition de 3ème niveau (si applicable)",
    )
    compo_de_compo_qte = db.Column(
        db.Numeric(asdecimal=False),
        info="Quantité à appliquer pour la composition de 2ème niveau  (si applicable)",
    )
    compo_qte = db.Column(
        db.Numeric(asdecimal=False),
        info="Quantité à appliquer pour la composition de 1er niveau  (si applicable)",
    )
    compo_de_compo_de_compo_poids = db.Column(
        db.Numeric(asdecimal=False),
        info="Poids à appliquer pour la composition de 3ème niveau  (si applicable)",
    )
    compo_de_compo_poids = db.Column(
        db.Numeric(asdecimal=False),
        info="Poids à appliquer pour la composition de 2ème niveau  (si applicable)",
    )
    compo_poids = db.Column(
        db.Numeric(asdecimal=False),
        info="Poids à appliquer pour la composition de 1er niveau  (si applicable)",
    )


class VContratListeEnVie(db.Model):
    __tablename__ = "v_contrat_liste_en_vie"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cdmnemo = db.Column(db.String(50), info="Code Mnemo.")
    cdcode = db.Column(db.String(50), info="Code l'instrument.")
    cdreuters = db.Column(db.String(50), info="Code Reuters du dérivé")
    cdcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="CFIN du produit"
    )
    cdnom = db.Column(db.String(60), nullable=False, info="Nom du dérivé.")
    cdstrike = db.Column(db.Numeric(asdecimal=False), info="Strike")
    cdquotite = db.Column(db.Numeric(12, 4), nullable=False, info="Quotité")
    cdcallput = db.Column(db.String(1), info="Défition Call / Put.")
    cdextype = db.Column(db.String(1), info="Type d'exercice de l'option.")
    cddateecheance = db.Column(db.DateTime, info="Date d'échéance (Emission).")
    cdmarche = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="Marché."
    )
    cdversion = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="Version du contrat listé",
    )
    cdcfinsjac = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cdnomsjac = db.Column(db.String(60), nullable=False, info="Nom du sous-jacent")
    cdpayoffsjac = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Payoff du sous-jacent."
    )
    cdlibpayoffsjac = db.Column(
        db.String(60), nullable=False, info="Libéllé du payoff du sous jacent."
    )
    cdisinsjac = db.Column(db.String(50), info="Code ISIN du sous jacent.")
    cdcodesjac = db.Column(db.String(50), info="Code du sous jacent.")


class VCotationContrib(db.Model):
    __tablename__ = "v_cotation_contrib"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ccbcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Cfin de l'instrument"
    )
    ccbdate = db.Column(db.DateTime, nullable=False, info="Date de cotation")
    ccbcodectrb = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="Code du contributeur"
    )
    ccbnomctrb = db.Column(db.String(50), info="Libellé du contributeur")
    ccbmodecot = db.Column(db.Numeric(2, 0, asdecimal=False), info="Mode de cotation")
    ccblibmodecot = db.Column(
        db.String(20), nullable=False, info="Libellé du mode de cotation"
    )
    ccbcode = db.Column(db.String(50), info="Code de l'instrument")
    ccbcours = db.Column(db.Numeric(13, 5), info="Cours")
    ccbbid = db.Column(db.Numeric(13, 5), info="Bid")
    ccbask = db.Column(db.Numeric(13, 5), info="Ask")


class VDelCfinsAExclure(db.Model):
    __tablename__ = "v_del_cfins_a_exclure"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cfin = db.Column(db.Numeric(asdecimal=False))


class VDelRechCodesOptEchue(db.Model):
    __tablename__ = "v_del_rech_codes_opt_echues"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Code de l'instrument"
    )
    marche = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="code marché de l'instrument",
    )
    source = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="Source associé au code de l'instrument",
    )
    code = db.Column(db.String(50), nullable=False, info="code marché de l'instrument")
    type = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="type du code"
    )
    nom = db.Column(db.String(60), nullable=False, info="Nom de l'instrument")
    echeance = db.Column(db.DateTime, info="Date d'echeance de l'option")


class VDelRechCodesWarEchue(db.Model):
    __tablename__ = "v_del_rech_codes_war_echues"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Code de l'instrument"
    )
    marche = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="code marché de l'instrument",
    )
    source = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="Source associé au code de l'instrument",
    )
    code = db.Column(db.String(50), nullable=False, info="code marché de l'instrument")
    cftype = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="type du code"
    )
    nom = db.Column(db.String(60), nullable=False, info="Nom de l'instrument")
    opdateecheance = db.Column(db.DateTime, info="Date d'echeance de l'option")


class VDelRechOptEchuesNonMort(db.Model):
    __tablename__ = "v_del_rech_opt_echues_non_mort"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    opcfin = db.Column(db.Numeric(8, 0, asdecimal=False))


class VDelRechOptionsASupp(db.Model):
    __tablename__ = "v_del_rech_options_a_supp"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    opcfin = db.Column(db.Numeric(asdecimal=False))


class VEdenUtilisateur(db.Model):
    __tablename__ = "v_eden_utilisateurs"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ususer = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    usadnom = db.Column(db.String(30))
    usnom = db.Column(db.String(30))
    usflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    usgroupe = db.Column(db.Numeric(2, 0, asdecimal=False))
    uslibellegroupe = db.Column(db.String(15))


class VEmiPricingCp(db.Model):
    __tablename__ = "v_emi_pricing_cp"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    epdate = db.Column(
        db.DateTime, nullable=False, info="Date d'evaluation des indicateurs"
    )
    epcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    epprix = db.Column(
        db.Numeric(asdecimal=False), info="Prix de l'instrument financier"
    )
    epdelta = db.Column(
        db.Numeric(asdecimal=False), info="Delta de l'instrument financier"
    )


class VEmiPricingOtcCp(db.Model):
    __tablename__ = "v_emi_pricing_otc_cp"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    epdate = db.Column(
        db.DateTime, nullable=False, info="Date d'évaluation des indicateurs"
    )
    epcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    epprix = db.Column(
        db.Numeric(asdecimal=False), info="Prix de l'instrument financier"
    )


class VFlow(db.Model):
    __tablename__ = "v_flow"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    opparentid = db.Column(db.Numeric(8, 0, asdecimal=False))
    opnumero = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    opdate = db.Column(db.DateTime)
    opdatenego = db.Column(db.DateTime)
    opdaterl = db.Column(db.DateTime)
    quantity = db.Column(db.Numeric(17, 4))
    netprice = db.Column(db.Numeric(asdecimal=False))
    opotype = db.Column(db.Numeric(3, 0, asdecimal=False))
    opflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    opinformation = db.Column(db.Numeric(5, 0, asdecimal=False))
    opmontantcc = db.Column(db.Numeric(16, 8))
    opmontant = db.Column(db.Numeric(asdecimal=False))
    opmontantbrut = db.Column(db.Numeric(23, 5))
    opmontantttfi = db.Column(db.Numeric(23, 5))
    optypecotation = db.Column(db.String(1))
    opmodecotation = db.Column(db.Numeric(2, 0, asdecimal=False))
    opdev = db.Column(db.Numeric(8, 0, asdecimal=False))
    opchange = db.Column(db.Numeric(13, 5))
    opmargetrader = db.Column(db.Numeric(12, 5))
    opmargevendeur = db.Column(db.Numeric(12, 5))
    opcommentaire = db.Column(db.String(256))
    opuser = db.Column(db.Numeric(3, 0, asdecimal=False))
    opinitialfrontoperator = db.Column(db.Numeric(3, 0, asdecimal=False))
    opcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    opbook = db.Column(db.Numeric(5, 0, asdecimal=False))
    opcptie = db.Column(db.Numeric(8, 0, asdecimal=False))
    ophorodate = db.Column(db.DateTime)
    opticket = db.Column(db.String(12))
    opversion = db.Column(db.Numeric(38, 0, asdecimal=False))
    opvendeur = db.Column(db.Numeric(8, 0, asdecimal=False))
    opfrais = db.Column(db.Numeric(22, 15))
    oporigine = db.Column(db.Numeric(8, 0, asdecimal=False))
    opcompte = db.Column(db.Numeric(5, 0, asdecimal=False))
    opprovenance = db.Column(db.String(1))
    opportef = db.Column(db.Numeric(8, 0, asdecimal=False))
    opgenerateur = db.Column(db.Numeric(8, 0, asdecimal=False))
    opquotite = db.Column(db.Numeric(12, 4))
    optypesaisie = db.Column(db.Numeric(3, 0, asdecimal=False))
    opnumechange = db.Column(db.Numeric(8, 0, asdecimal=False))
    opannule = db.Column(db.Numeric(8, 0, asdecimal=False))
    opbrokertiersprincipal = db.Column(db.Numeric(8, 0, asdecimal=False))
    opbrokertierssecondaire = db.Column(db.Numeric(8, 0, asdecimal=False))
    opcptietiersprincipal = db.Column(db.Numeric(8, 0, asdecimal=False))
    opcptietierssecondaire = db.Column(db.Numeric(8, 0, asdecimal=False))
    opmarche = db.Column(db.String(15))
    opexporttomoflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    opsysteme = db.Column(db.Numeric(8, 0, asdecimal=False))
    opexternalref = db.Column(db.String(36))
    opmaj = db.Column(db.DateTime)
    opnominal = db.Column(db.Numeric(18, 5))
    opentite = db.Column(db.Numeric(5, 0, asdecimal=False))
    optcsstate = db.Column(db.Numeric(5, 0, asdecimal=False))
    opmostate = db.Column(db.Numeric(5, 0, asdecimal=False))
    oputi = db.Column(db.String(52))
    opestflux = db.Column(db.String(1))
    opmargeflux = db.Column(db.Numeric(13, 5))
    opdiscount = db.Column(db.Numeric(13, 5))
    opmoreconciliation = db.Column(db.Numeric(asdecimal=False))
    opcommissionechelonnee = db.Column(db.Numeric(23, 5))
    opetatpolmarge = db.Column(db.Numeric(8, 0, asdecimal=False))
    opmargecontrib = db.Column(db.Numeric(10, 5))
    opinitiateur = db.Column(db.Numeric(3, 0, asdecimal=False))
    opexecannulraison = db.Column(db.Numeric(8, 0, asdecimal=False))
    opyoshiid = db.Column(db.String(50))
    opexecutionvenuemic = db.Column(db.String(4))
    opyoshictpyid = db.Column(db.Numeric(8, 0, asdecimal=False))
    opdatecreation = db.Column(db.DateTime)
    opdatemodif = db.Column(db.DateTime)
    opsoulte = db.Column(db.Numeric(23, 5))
    opcommissionia = db.Column(db.Numeric(23, 5))
    opordercategory = db.Column(db.String(50))
    optypevolcker = db.Column(db.String(1))
    opindexcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    opidadvisoroperation = db.Column(db.String(100))
    optransfertype = db.Column(db.Numeric(1, 0, asdecimal=False))


class VFormatOpeAnnulModifCpd(db.Model):
    __tablename__ = "v_format_ope_annul_modif_cpd"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vfo_centrebud = db.Column(db.String(12))
    vfo_bigbook = db.Column(db.Numeric(4, 0, asdecimal=False))
    vfo_user = db.Column(db.String(30))
    vfo_book = db.Column(db.Numeric(5, 0, asdecimal=False))
    vfo_cfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    vfo_quantite = db.Column(db.Numeric(17, 4))
    vfo_montant = db.Column(db.Numeric(23, 5))
    vfo_devise = db.Column(db.String(3))
    vfo_typeop = db.Column(db.String(20))
    vfo_datevaleur = db.Column(db.DateTime)
    vfo_moderl = db.Column(db.String(15))
    vfo_frais = db.Column(db.Numeric(22, 15))
    vfo_cptie = db.Column(db.String(60), nullable=False)
    vfo_dateop = db.Column(db.DateTime)
    vfo_cours = db.Column(db.Numeric(15, 5))
    vfo_montantcc = db.Column(db.Numeric(16, 8))
    vfo_flag = db.Column(db.Numeric(5, 0, asdecimal=False))
    vfo_quantitebroker = db.Column(db.Numeric(17, 4))
    vfo_prixbroker = db.Column(db.Numeric(21, 5))
    vfo_quotite = db.Column(db.Numeric(12, 4))
    vfo_commentaire = db.Column(db.String(256))
    vfo_typeaction = db.Column(db.String(30))
    vfo_opnumero = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    vfo_opannule = db.Column(db.Numeric(8, 0, asdecimal=False))
    vfo_oporigine = db.Column(db.Numeric(8, 0, asdecimal=False))
    vfo_datenego = db.Column(db.DateTime)


class VFrontCtlpnl(db.Model):
    __tablename__ = "v_front_ctlpnl"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    id = db.Column(db.String(72))
    datepnl = db.Column(db.DateTime)
    cb = db.Column(db.String(12))
    devise = db.Column(db.String(60))
    mtrares = db.Column(db.Numeric(asdecimal=False))
    mtpnlfront = db.Column(db.Numeric(asdecimal=False))
    ecart = db.Column(db.Numeric(asdecimal=False))


class VFrontPnlChangehist(db.Model):
    __tablename__ = "v_front_pnl_changehist"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    id = db.Column(db.String(8))
    datepnl = db.Column(db.DateTime)
    cb = db.Column(db.String(5))
    devise = db.Column(db.String(3))
    mtpnlfront = db.Column(db.Numeric(asdecimal=False))


class VFrontValmob(db.Model):
    __tablename__ = "v_front_valmob"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    r_id = db.Column()
    pidate = db.Column(db.DateTime)
    picfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    pilibelle = db.Column(db.String(60))
    pihorodate = db.Column(db.DateTime)
    pibudget = db.Column(db.String(5))
    pibigbook = db.Column(db.Numeric(4, 0, asdecimal=False))
    pibook = db.Column(db.Numeric(5, 0, asdecimal=False))
    pitypeproduit = db.Column(db.String(30))
    pidevise = db.Column(db.String(3))
    piisin = db.Column(db.String(30))
    pistatut = db.Column(db.String(1))
    piplcumul = db.Column(db.Numeric(asdecimal=False))
    piplcumulbrut = db.Column(db.Numeric(asdecimal=False))
    pipljour = db.Column(db.Numeric(asdecimal=False))
    pipos = db.Column(db.Numeric(asdecimal=False))
    piprixref = db.Column(db.Numeric(asdecimal=False))
    pivaloref = db.Column(db.Numeric(asdecimal=False))
    piprixcotation = db.Column(db.Numeric(asdecimal=False))
    piprixvalo = db.Column(db.Numeric(asdecimal=False))
    pivalo = db.Column(db.Numeric(asdecimal=False))
    piflux = db.Column(db.Numeric(asdecimal=False))
    pidividende = db.Column(db.Numeric(asdecimal=False))
    picoupon = db.Column(db.Numeric(asdecimal=False))
    pitaxerecup = db.Column(db.Numeric(asdecimal=False))
    piretro = db.Column(db.Numeric(asdecimal=False))
    pifraisemission = db.Column(db.Numeric(asdecimal=False))
    pitransfertcash = db.Column(db.Numeric(asdecimal=False))
    pifraiscumul = db.Column(db.Numeric(asdecimal=False))
    pifraisjour = db.Column(db.Numeric(asdecimal=False))
    piecartvalojour = db.Column(db.Numeric(asdecimal=False))
    piflag = db.Column(db.Numeric(5, 0, asdecimal=False))
    picontrat = db.Column(db.Numeric(3, 0, asdecimal=False))


class VGeodePbEcartPrixRef(db.Model):
    __tablename__ = "v_geode_pb_ecart_prix_ref"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    date_fdj = db.Column(
        db.DateTime, nullable=False, info="Date du traitement de fin de journée."
    )
    entite = db.Column(db.String(32), info="Entité du bigbook")
    bigbook = db.Column(db.Numeric(4, 0, asdecimal=False), info="Bigbook concerné.")
    nom_bigbook = db.Column(db.String(30), info="Nom du bigbook")
    etat_bigbook = db.Column(db.String(7), info="Etat du  bigbook (Atcif / Inactif)")
    cfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Produit concerné."
    )
    prixtheo = db.Column(db.Numeric(asdecimal=False), info="Prix théorique.")
    nb_prix = db.Column(db.Numeric(asdecimal=False), info="Nb de prix distinct trouvé.")


class VGeodePricingErreur(db.Model):
    __tablename__ = "v_geode_pricing_erreurs"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    peg_date = db.Column(db.DateTime)
    peg_profil = db.Column(db.Numeric(8, 0, asdecimal=False))
    peg_book = db.Column(db.Numeric(5, 0, asdecimal=False))
    peg_cfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    peg_libelle = db.Column(db.String(60), nullable=False)
    peg_modepricing = db.Column(db.Numeric(2, 0, asdecimal=False))
    peg_ermsg = db.Column(db.String(1024))
    peg_sumpos = db.Column(db.Numeric(asdecimal=False))
    peg_horodate = db.Column(db.DateTime)


class VGeodeSuiviLancement(db.Model):
    __tablename__ = "v_geode_suivi_lancement"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    horodate = db.Column(
        db.DateTime, nullable=False, info="Horodatage de l'appel de l'api."
    )
    api = db.Column(db.String(61), nullable=False, info="Api invoquée")
    date_calcul = db.Column(db.DateTime, info="Api date de calcul demandée")
    mode_pricing = db.Column(db.String(8), info="Mode de pricing utilisé")
    perimetre_reference = db.Column(
        db.String(1),
        info="Specifie si la demande conerne la référence (la gestion si Non)",
    )
    perimetre = db.Column(db.String(4000), info="Perimetre concerne par le lancement")
    utilisateur = db.Column(
        db.String(200), info="Login de l'utilisateur qui a effectué l'appel"
    )
    machine = db.Column(
        db.String(200), info="Specifie la machine utilisée pour faire l'appel"
    )


class VIdentifierPbBooking(db.Model):
    __tablename__ = "v_identifier_pb_booking"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code de l'instrument financier"
    )
    position = db.Column(db.Numeric(asdecimal=False), info="Position constatée")
    date_position = db.Column(db.DateTime, info="Date de la position constatée")
    bigbook = db.Column(db.Numeric(4, 0, asdecimal=False), info="Code du portefeuille")
    nom_bigbook = db.Column(db.String(30), info="Nom du sous portefeuille")
    book = db.Column(
        db.Numeric(5, 0, asdecimal=False), info="Code du sous portefeuille "
    )
    nom_book = db.Column(db.String(60), info="Nom du protefeuille")
    date_fermeture = db.Column(db.DateTime, info="Date de fermeture")
    flag_cfin = db.Column(
        db.String(9), info="Flag statut du produit dans le sous protefeuille"
    )
    flag_book = db.Column(db.String(9), info="Flag statut du sous protefeuille")
    flag_bigbook = db.Column(db.String(9), info="Flag statut du portefeuille")


class VInstrumentsEnPo(db.Model):
    __tablename__ = "v_instruments_en_pos"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ifcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    ifstatut = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    iftype = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    ifnom = db.Column(db.String(60), nullable=False)
    ifmaj = db.Column(db.DateTime, nullable=False)
    ifpayoff = db.Column(db.Numeric(3, 0, asdecimal=False))
    ifcontrat = db.Column(db.Numeric(3, 0, asdecimal=False))
    ifvalidation = db.Column(db.String(1), nullable=False)
    en_pos = db.Column(db.String(3))


class VMgDerMarketshortcode(db.Model):
    __tablename__ = "v_mg_der_marketshortcodes"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    shortcode = db.Column(db.Numeric(9, 0, asdecimal=False))
    idsource = db.Column(db.Numeric(9, 0, asdecimal=False))
    name = db.Column(db.String(101))
    source = db.Column(db.String(1))
    active = db.Column(db.String(1))
    publishable = db.Column(db.String(1))
    creationdate = db.Column(db.DateTime)


class VMiddleComptesGestionsCpd(db.Model):
    __tablename__ = "v_middle_comptes_gestions_cpd"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    compte_n_donnee = db.Column(db.String(50))
    code_compte = db.Column(db.String(11), nullable=False)
    code_parametre = db.Column(db.String(12), nullable=False)
    code_rubrique = db.Column(db.String(12), nullable=False)


class VMiddleOpeChangeSpot(db.Model):
    __tablename__ = "v_middle_ope_change_spot"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    code_ope_flux_1 = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Code type op¿ration du flux 1"
    )
    code_ope_flux_2 = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Code type op¿ration du flux 2"
    )
    libelle_type_flux_1 = db.Column(
        db.String(20), info="Libell¿ du type op¿ration du flux 1"
    )
    libelle_type_flux_2 = db.Column(
        db.String(20), info="Libell¿ du type op¿ration du flux 2"
    )
    nature_operation = db.Column(
        db.String(4), info="Nature de l'op¿ration => toujours SPOT"
    )
    code_typo_ope_middle = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Code Interne de la typologie d'op¿ration middle",
    )
    lib_typo_ope_middle = db.Column(db.String(60), info="Typologie op¿ration")
    ope_sens = db.Column(db.String(5), info="Sens de l'op¿ration (Achat/Vente)")
    uniges = db.Column(db.String(12), info="Centre budgetaire")
    ope_date = db.Column(
        db.DateTime, info="Date de l'op¿ration (¿quivalente flux 1 et 2)"
    )
    date_nego_flux_1 = db.Column(db.DateTime, info="Date n¿go du flux 1")
    date_nego_flux_2 = db.Column(db.DateTime, info="Date n¿go du flux 2")
    date_valeur_flux_1 = db.Column(db.DateTime, info="Date de valeur du flux 1")
    date_valeur_flux_2 = db.Column(db.DateTime, info="Date de valeur du flux 2")
    cfin_dev_flux_1 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Cfin de la devise du flux 1",
    )
    dev_flux_1 = db.Column(db.String(3), info="Code ISO de la devise du flux 1")
    cfin_dev_flux_2 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Cfin de la devise du flux 2",
    )
    dev_flux_2 = db.Column(db.String(3), info="Code ISO de la devise du flux 1")
    montant_flux_dev_1 = db.Column(
        db.Numeric(23, 5), info="Montant de la devise du flux 1"
    )
    montant_flux_dev_2 = db.Column(
        db.Numeric(23, 5), info="Montant de la devise du flux 1"
    )
    code_contrepartie_flux_1 = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code de la contrepartie du flux 1"
    )
    code_contrepartie_flux_2 = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code de la contrepartie du flux 2"
    )
    ope_ticket = db.Column(db.String(12), info="Ticket commun des op¿rations")
    numero_ope_flux_1 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Num¿ro d'op¿ration du flux 1",
    )
    numero_ope_flux_2 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Num¿ro d'op¿ration du flux 2",
    )
    statut_validation_flux_1 = db.Column(
        db.String(1), info="Statut de validation du flux 1"
    )
    horodate_validation_flux_1 = db.Column(
        db.DateTime,
        info="Date de derniere modification du statut de validation du flux 1",
    )
    horodate_flux_1 = db.Column(
        db.DateTime, info="Date de derniere modification du flux 1"
    )
    entite = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Entite budgetaire (CPD, SA, SAM...)"
    )
    code_budgetaire = db.Column(
        db.Numeric(4, 0, asdecimal=False), info="Code du centre budg¿taire"
    )
    bigbook = db.Column(
        db.Numeric(4, 0, asdecimal=False), nullable=False, info="Bigbook de l'op¿ration"
    )
    commentaire_ope_flux_1 = db.Column(db.String(1024), info="Commentaire middle")


class VMotifsRefusOperation(db.Model):
    __tablename__ = "v_motifs_refus_operations"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    mrcode = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False, info="Code du motif de refus"
    )
    mrlibelle = db.Column(
        db.String(80), nullable=False, info="Libéllé du motif de refus"
    )


class VOpeEchangeCentreBudget(db.Model):
    __tablename__ = "v_ope_echange_centre_budget"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    obdate = db.Column(db.DateTime, info="Date de l¿exécution")
    obhorodate = db.Column(db.DateTime, info="Heure de l¿exécution")
    obcentrebud = db.Column(db.String(12), info="Centre budgétaire")
    obisin = db.Column(db.String(50), nullable=False, info="Code\xa0Isin")
    obquantite = db.Column(db.Numeric(asdecimal=False), info="Quantité exécutée")
    obcours = db.Column(db.Numeric(15, 5), info="Cours d'exécution")
    obtauxcoupon = db.Column(db.Numeric(8, 5), info="Taux de coupon")
    obmodeexpres = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Mode d¿expression du cours"
    )
    obdevisecota = db.Column(db.String(3), info="Devise de cotation")
    obdeviseregl = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Devise de règlement "
    )
    obtauxchange = db.Column(db.Numeric(13, 5), info="Taux de change")
    obsens = db.Column(db.String(5), info="Sens de l'exécution")
    obcapitauxbrut = db.Column(
        db.Numeric(23, 5), info="Capitaux bruts en devise de cotation"
    )
    obmontantcourru = db.Column(
        db.Numeric(16, 8), info="Montant coupon couru en devise de cotation"
    )
    obmontantnet = db.Column(
        db.Numeric(23, 5), info="Montant net en devise de règlement"
    )
    obvendeur = db.Column(db.Numeric(3, 0, asdecimal=False), info="Code vendeur")
    obidoperation = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Référence de l'ordre"
    )
    obdatedenou = db.Column(db.DateTime, info="Date de dénouement théorique")
    obtrader = db.Column(db.Numeric(3, 0, asdecimal=False), info="Code trader")
    obnomplace = db.Column(
        db.String(20), nullable=False, info="Libéllé de la place financière"
    )


class VOpeFuture(db.Model):
    __tablename__ = "v_ope_future"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ofu_marche = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    ofu_nommarche = db.Column(db.String(60), nullable=False)
    ofu_openumero = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    ofu_centrebudg = db.Column(db.String(12))
    ofu_devise = db.Column(db.String(60), nullable=False)
    ofu_opdate = db.Column(db.DateTime)
    ofu_opdateval = db.Column(db.DateTime)
    ofu_opdatenego = db.Column(db.DateTime)
    ofu_cfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    ofu_nom = db.Column(db.String(60), nullable=False)
    ofu_codeisinsjac = db.Column(db.String(50))
    ofu_codertrsjac = db.Column(db.String(50))
    ofu_codertsctr = db.Column(db.String(50))
    ofu_libpayoff = db.Column(db.String(60), nullable=False)
    ofu_mnemo = db.Column(db.String(50))
    ofu_mnemo_312 = db.Column(db.String(50))
    ofu_mnemo_319 = db.Column(db.String(50))
    ofu_libellecontrat = db.Column(db.String(17))
    ofu_dbnom = db.Column(db.String(60), nullable=False)
    ofu_sens = db.Column(db.String(1))
    ofu_cours_nego = db.Column(db.Numeric(asdecimal=False))
    ofu_quotite = db.Column(db.Numeric(12, 4), nullable=False)
    ofu_qte_nego = db.Column(db.Numeric(asdecimal=False))
    ofu_montant = db.Column(db.Numeric(23, 5))
    ofu_frais = db.Column(db.Numeric(22, 15))
    ofu_echeance = db.Column(db.String(8))
    ofu_optype = db.Column(db.Numeric(3, 0, asdecimal=False))
    ofu_isinternaldeal = db.Column(db.String(1))
    ofu_isdealwithbroker = db.Column(db.String(1))
    ofu_horodate = db.Column(db.DateTime)
    ofu_margin = db.Column(db.String(1))
    ofu_delivery = db.Column(db.String(1))
    ofu_vendeur = db.Column(db.Numeric(asdecimal=False))
    ofu_nomvendeur = db.Column(db.String(60))
    ofu_codevendeur = db.Column(db.String(6))


class VOpeOption(db.Model):
    __tablename__ = "v_ope_option"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    oop_marche = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    oop_nommarche = db.Column(db.String(60), nullable=False)
    oop_openumero = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    oop_centrebudg = db.Column(db.String(12))
    oop_devise = db.Column(db.String(60), nullable=False)
    oop_opdate = db.Column(db.DateTime)
    oop_opdateval = db.Column(db.DateTime)
    oop_opdatenego = db.Column(db.DateTime)
    oop_cfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    oop_nom = db.Column(db.String(60), nullable=False)
    oop_codeisinsjac = db.Column(db.String(50))
    oop_codertrsjac = db.Column(db.String(50))
    oop_codertsctr = db.Column(db.String(50))
    oop_libpayoff = db.Column(db.String(60), nullable=False)
    oop_mnemo = db.Column(db.String(50))
    oop_mnemo_312 = db.Column(db.String(50))
    oop_mnemo_319 = db.Column(db.String(50))
    oop_libellecontrat = db.Column(db.String(164))
    oop_dbnom = db.Column(db.String(60), nullable=False)
    oop_extype = db.Column(db.String(1), nullable=False)
    oop_callput = db.Column(db.String(1), nullable=False)
    oop_sens = db.Column(db.String(1))
    oop_cours_nego = db.Column(db.Numeric(asdecimal=False))
    oop_strike = db.Column(db.Numeric(13, 5), nullable=False)
    oop_quotite_opt = db.Column(db.Numeric(12, 4), nullable=False)
    oop_version = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    oop_qte_nego = db.Column(db.Numeric(asdecimal=False))
    oop_montant = db.Column(db.Numeric(23, 5))
    oop_frais = db.Column(db.Numeric(22, 15))
    oop_echeance = db.Column(db.String(8))
    oop_optype = db.Column(db.Numeric(3, 0, asdecimal=False))
    oop_isinternaldeal = db.Column(db.String(1))
    oop_isdealwithbroker = db.Column(db.String(1))
    oop_horodate = db.Column(db.DateTime)
    oop_margin = db.Column(db.String(1))
    oop_delivery = db.Column(db.String(1))
    oop_vendeur = db.Column(db.Numeric(asdecimal=False))
    oop_nomvendeur = db.Column(db.String(60))
    oop_codevendeur = db.Column(db.String(6))


class VOpeOtcMiddle(db.Model):
    __tablename__ = "v_ope_otc_middle"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    omcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code interne de l'instrument financier"
    )
    omnom = db.Column(
        db.String(60), nullable=False, info="Nom de l'instrument financier"
    )
    omtypprdbck = db.Column(
        db.String(6), info='Type "back" du produit (déduit de tpvaleur)'
    )
    omcentrebud = db.Column(db.String(12), info="Centre budgétaire du produit")
    omopedevise = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Code interne de la devise de l'opération",
    )
    omopenomdevise = db.Column(db.String(3), info="Nom ISO de la devise de l'opération")
    omopenumero = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Identifiant de l'opération",
    )
    omopedatenego = db.Column(db.DateTime, info="Date de négociation de l'opération")
    omopedate = db.Column(db.DateTime, info="Date de l'opération")
    omopehorodate = db.Column(db.DateTime, info="Date / heure de saisie de l'opération")
    omopemontant = db.Column(db.Numeric(23, 5), info="Montant de l'opération")
    omopecours = db.Column(db.Numeric(15, 5), info="Cours de l'opération")
    omopequantite = db.Column(db.Numeric(17, 4), info="Quantité de l'opération")
    omopevalidation = db.Column(
        db.String(1), info='Statut de validation "Middle" de l\'opération'
    )
    omopecoderefus = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info='Code du modif de refus de la validation "Middle" de l\'opération',
    )
    omopemotifrefus = db.Column(
        db.String(80), info='Modif de refus de la validation "Middle" de l\'opération'
    )
    omopecommentaire = db.Column(
        db.String(1024), info='Commentaire associé à la validation "Middle"'
    )
    omvalidationhorodate = db.Column(
        db.DateTime,
        info='Date de mise à jour du statut de validation "Middle" de l\'opération',
    )
    omcodepayeur = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Code du tiers payeur"
    )
    ompayeur = db.Column(db.String(60), nullable=False, info="Libéllé du tiers payeur")
    omcodereceveur = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Code du tiers receveur"
    )
    omreceveur = db.Column(
        db.String(60), nullable=False, info="Libéllé du tiers receveur"
    )
    omvalidationpdt = db.Column(db.String(1), info="Statut de validation du produit")
    omcodetypo = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Code de la typologie MIDDLE associé au produit",
    )


class VOpeValmob(db.Model):
    __tablename__ = "v_ope_valmob"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ovm_bgtype = db.Column(db.String(1))
    ovm_bgcodebud = db.Column(db.String(10))
    ovm_bgfe = db.Column(db.String(1))
    ovm_bbferme = db.Column(db.DateTime)
    ovm_opdate = db.Column(db.DateTime)
    ovm_opdatenego = db.Column(db.DateTime)
    ovm_optype = db.Column(db.Numeric(3, 0, asdecimal=False))
    ovm_liboptype = db.Column(db.String(20))
    ovm_rga = db.Column(db.String(0))
    ovm_isin = db.Column(db.String(50))
    ovm_libelle = db.Column(db.String(60), nullable=False)
    ovm_cfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    ovm_dbnom = db.Column(db.String(60))
    ovm_typeinstrument = db.Column(db.String(60))
    ovm_devise = db.Column(db.String(60), nullable=False)
    ovm_ticket = db.Column(db.String(12))
    ovm_horodate = db.Column(db.DateTime)
    ovm_quantite = db.Column(db.Numeric(17, 4))
    ovm_quantitebroker = db.Column(db.Numeric(17, 4))
    ovm_cours = db.Column(db.Numeric(15, 5))
    ovm_prixbroker = db.Column(db.Numeric(21, 5))
    ovm_montant = db.Column(db.Numeric(23, 5))
    ovm_modecotation = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    ovm_libmodcot = db.Column(db.String(20), nullable=False)
    ovm_nominal = db.Column(db.Numeric(18, 5))
    ovm_place = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    ovm_nomplace = db.Column(db.String(20), nullable=False)
    ovm_marche = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    ovm_nommarche = db.Column(db.String(60))
    ovm_nombroker = db.Column(db.String(64))
    ovm_frais = db.Column(db.Numeric(22, 15))
    ovm_opnumero = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    ovm_opdatevaleur = db.Column(db.DateTime)
    ovm_vendeur = db.Column(db.Numeric(asdecimal=False))
    ovm_nomvendeur = db.Column(db.String(60))
    ovm_codevendeur = db.Column(db.String(6))
    ovm_cfin_option = db.Column(db.Numeric(8, 0, asdecimal=False))
    ovm_marche_option = db.Column(db.Numeric(3, 0, asdecimal=False))
    ovm_nommarche_option = db.Column(db.String(60))


class VOpeValmobAutre(db.Model):
    __tablename__ = "v_ope_valmob_autre"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ovo_bgtype = db.Column(db.String(1))
    ovo_bgcodebud = db.Column(db.String(10))
    ovo_bgfe = db.Column(db.String(1))
    ovo_bbferme = db.Column(db.DateTime)
    ovo_opdate = db.Column(db.DateTime)
    ovo_opdatenego = db.Column(db.DateTime)
    ovo_optype = db.Column(db.Numeric(3, 0, asdecimal=False))
    ovo_liboptype = db.Column(db.String(20))
    ovo_rga = db.Column(db.String(0))
    ovo_isin = db.Column(db.String(50))
    ovo_libelle = db.Column(db.String(60), nullable=False)
    ovo_cfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    ovo_dbnom = db.Column(db.String(60))
    ovo_codetypeinstrument = db.Column(
        db.Numeric(3, 0, asdecimal=False), nullable=False
    )
    ovo_typeinstrument = db.Column(db.String(60))
    ovo_devise = db.Column(db.String(60), nullable=False)
    ovo_ticket = db.Column(db.String(12))
    ovo_horodate = db.Column(db.DateTime)
    ovo_quantite = db.Column(db.Numeric(17, 4))
    ovo_quantitebroker = db.Column(db.Numeric(17, 4))
    ovo_cours = db.Column(db.Numeric(15, 5))
    ovo_prixbroker = db.Column(db.Numeric(21, 5))
    ovo_montant = db.Column(db.Numeric(23, 5))
    ovo_modecotation = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    ovo_libmodcot = db.Column(db.String(20), nullable=False)
    ovo_nominal = db.Column(db.Numeric(18, 5))
    ovo_place = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    ovo_nomplace = db.Column(db.String(20), nullable=False)
    ovo_marche = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    ovo_nommarche = db.Column(db.String(60))
    ovo_nombroker = db.Column(db.String(64))
    ovo_frais = db.Column(db.Numeric(22, 15))
    ovo_opnumero = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    ovo_opdatevaleur = db.Column(db.DateTime)
    ovo_vendeur = db.Column(db.Numeric(asdecimal=False))
    ovo_nomvendeur = db.Column(db.String(60))
    ovo_codevendeur = db.Column(db.String(6))


class VPbPositionEtatdevie(db.Model):
    __tablename__ = "v_pb_position_etatdevie"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    nom = db.Column(db.String(60), nullable=False, info="Nom de l'instrument")
    code_etatdevie = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Code du statut de l'état de vie"
    )
    etatdevie = db.Column(db.String(60), info="Libéllé du statut de l'état de vie")
    code_aeteenposition = db.Column(
        db.Numeric(1, 0, asdecimal=False), info='Code du statut " A été en position"'
    )
    aeteenposition = db.Column(
        db.String(17), info='Libellé du statut " A été en position"'
    )
    code_contrat = db.Column(db.Numeric(3, 0, asdecimal=False), info="Code du contrat")
    code_payoff = db.Column(db.Numeric(3, 0, asdecimal=False), info="Code du payoff")
    maturite_contrat = db.Column(db.DateTime, info="Date de maturite du contrat")
    position_globale = db.Column(
        db.Numeric(asdecimal=False), info="Position cumulee (inter-portefeuille)"
    )
    portefeuilles = db.Column(db.String(4000), info="Liste des portefeuilles concernes")
    chemin_max = db.Column(
        db.String(172),
        info="Chemin le plus long jusitifant le cfin dans les portefeuilles concernes",
    )
    profondeur_max = db.Column(
        db.Numeric(asdecimal=False),
        info="Profondeur max du cfin dans les portefeuilles concernes",
    )


class VPnlrefCutoffLastN1(db.Model):
    __tablename__ = "v_pnlref_cutoff_last_n1"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    plcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    plpayoff = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Payoff de l'instrument financier"
    )
    pltype = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="Type de l'instrument financier.",
    )
    plmarche = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="Code marché de l'instrument financier",
    )


class VPnlrefCutoffLastN2(db.Model):
    __tablename__ = "v_pnlref_cutoff_last_n2"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    plcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    plpayoff = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Payoff de l'instrument financier"
    )
    pltype = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="Type de l'instrument financier.",
    )
    plmarche = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="Code marché de l'instrument financier",
    )


class VPnlrefCutoffLastN3(db.Model):
    __tablename__ = "v_pnlref_cutoff_last_n3"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    plcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code de l'instrument financier",
    )
    plpayoff = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Payoff de l'instrument financier"
    )
    pltype = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="Type de l'instrument financier.",
    )
    plmarche = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="Code marché de l'instrument financier",
    )


class VPosFuture(db.Model):
    __tablename__ = "v_pos_future"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pfu_marche = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    pfu_nommarche = db.Column(db.String(60), nullable=False)
    pfu_centrebudg = db.Column(db.String(12))
    pfu_devise = db.Column(db.String(60), nullable=False)
    pfu_podate = db.Column(db.DateTime, nullable=False)
    pfu_cfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    pfu_nom = db.Column(db.String(60), nullable=False)
    pfu_codeisinsjac = db.Column(db.String(50))
    pfu_codertrsjac = db.Column(db.String(50))
    pfu_codertsctr = db.Column(db.String(50))
    pfu_libpayoff = db.Column(db.String(60), nullable=False)
    pfu_mnemo = db.Column(db.String(50))
    pfu_mnemo_312 = db.Column(db.String(50))
    pfu_mnemo_319 = db.Column(db.String(50))
    pfu_libellecontrat = db.Column(db.String(17))
    pfu_dbnom = db.Column(db.String(60), nullable=False)
    pfu_cours = db.Column(db.Numeric(asdecimal=False))
    pfu_quotite = db.Column(db.Numeric(12, 4), nullable=False)
    pfu_quantite = db.Column(db.Numeric(asdecimal=False))
    pfu_montant = db.Column(db.Numeric(asdecimal=False))
    pfu_coursref = db.Column(db.Numeric(asdecimal=False))
    pfu_echeance = db.Column(db.String(8))
    pfu_margin = db.Column(db.String(1))
    pfu_delivery = db.Column(db.String(1))


class VPosOption(db.Model):
    __tablename__ = "v_pos_option"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pop_marche = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    pop_nommarche = db.Column(db.String(60), nullable=False)
    pop_centrebudg = db.Column(db.String(12))
    pop_devise = db.Column(db.String(60), nullable=False)
    pop_podate = db.Column(db.DateTime, nullable=False)
    pop_cfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    pop_nom = db.Column(db.String(60), nullable=False)
    pop_codeisinsjac = db.Column(db.String(50))
    pop_codertrsjac = db.Column(db.String(50))
    pop_coeffsjac = db.Column(db.Numeric(asdecimal=False))
    pop_codertsctr = db.Column(db.String(50))
    pop_libpayoff = db.Column(db.String(60), nullable=False)
    pop_mnemo = db.Column(db.String(50))
    pop_mnemo_312 = db.Column(db.String(50))
    pop_mnemo_319 = db.Column(db.String(50))
    pop_libellecontrat = db.Column(db.String(164))
    pop_dbnom = db.Column(db.String(60), nullable=False)
    pop_extype = db.Column(db.String(1), nullable=False)
    pop_callput = db.Column(db.String(1), nullable=False)
    pop_cours = db.Column(db.Numeric(asdecimal=False))
    pop_strike = db.Column(db.Numeric(13, 5), nullable=False)
    pop_quotite_opt = db.Column(db.Numeric(12, 4), nullable=False)
    pop_version = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    pop_quantite = db.Column(db.Numeric(asdecimal=False))
    pop_montant = db.Column(db.Numeric(asdecimal=False))
    pop_style = db.Column(db.String(1))
    pop_coursref = db.Column(db.Numeric(asdecimal=False))
    pop_echeance = db.Column(db.String(8))
    pop_margin = db.Column(db.String(1))
    pop_delivery = db.Column(db.String(1))


class VPosValmob(db.Model):
    __tablename__ = "v_pos_valmob"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    por_bgtype = db.Column(db.String(1), info="Type de code budgétaire")
    por_bgcodebud = db.Column(db.String(10), info="Code budgétaire")
    por_bgfe = db.Column(db.String(1), info="Indicateur F(rance) ou E(tranger)")
    por_bbferme = db.Column(
        db.DateTime, info="Date de fin de journée ou de cloture du portefeuille"
    )
    por_isin = db.Column(db.String(50), info="Code ISIN")
    por_libelle = db.Column(db.String(60), nullable=False, info="Libellé du code ISIN")
    por_dbnom = db.Column(db.String(60), info="Libellé du sous portefeuille")
    por_typeinstrument = db.Column(db.String(60), info="Type instrument")
    por_cfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False, info="Cfin")
    por_devise = db.Column(
        db.String(60), nullable=False, info="Code devise de la position"
    )
    por_podate = db.Column(
        db.DateTime, nullable=False, info="Date de mise à jour de la position"
    )
    por_dateval = db.Column(
        db.DateTime, nullable=False, info="Date de valeur de la position"
    )
    por_position = db.Column(db.Numeric(asdecimal=False), info="Montant de la position")
    por_cours = db.Column(db.Numeric(asdecimal=False), info="Cours")
    por_prixtheo = db.Column(db.Numeric(asdecimal=False), info="Prix théorique")
    por_pnljour = db.Column(db.Numeric(asdecimal=False), info="Montant PnL Jour")
    por_pnlcumul = db.Column(db.Numeric(asdecimal=False), info="Montant PnL cumulé")
    por_modecotation = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Mode de cotation"
    )
    por_amcclean = db.Column(db.String(0))
    por_libmodcot = db.Column(db.String(20), info="Libellé du mode de cotation")
    por_couponcouru = db.Column(db.Numeric(asdecimal=False), info="Coupon couru")
    por_nominal = db.Column(db.Numeric(18, 5), info="Nominal")
    por_marche = db.Column(db.Numeric(3, 0, asdecimal=False), info="Code marché")
    por_nommarche = db.Column(db.String(60), info="Libellé marché")
    por_place = db.Column(db.Numeric(3, 0, asdecimal=False), info="Place de cotation")
    por_nomplace = db.Column(db.String(20), info="Libellé place de cotation")


class VRare(db.Model):
    __tablename__ = "v_rare"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vrdate = db.Column(db.DateTime, nullable=False)
    vrbudget = db.Column(db.String(12))
    vrdevise = db.Column(db.String(60), nullable=False)
    vrpnl = db.Column(db.Numeric(asdecimal=False), nullable=False)
    vrfrais = db.Column(db.Numeric(asdecimal=False), nullable=False)
    vrtauxvseuro = db.Column(db.Numeric(asdecimal=False))
    vrflag = db.Column(db.Numeric(3, 0, asdecimal=False))


class VRkcubeauto(db.Model):
    __tablename__ = "v_rkcubeauto"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    hasspoterrors = db.Column(db.String(1))
    cuatworkerid = db.Column()
    cuatdatetime = db.Column(db.DateTime)
    cuattaskid = db.Column(db.Numeric(15, 0, asdecimal=False))
    cuattype = db.Column(db.Numeric(2, 0, asdecimal=False))
    cuatstatus = db.Column(db.String(1))
    cuattotalvalueused = db.Column(db.Numeric(16, 0, asdecimal=False))
    cuaocfinproduit = db.Column(db.Numeric(16, 0, asdecimal=False))
    cuaopositionerror = db.Column(db.String(4000))
    cuaopositionprofile = db.Column(db.Numeric(16, 0, asdecimal=False))
    cuaototalposition = db.Column(db.Numeric(16, 0, asdecimal=False))
    cuadcomputeprofile = db.Column(db.Numeric(16, 0, asdecimal=False))
    cuadcentralprice = db.Column(db.Float)
    cuadcentralerror = db.Column(db.String(4000))
    cuaddeformationprice = db.Column(db.Float)
    cuaddeformationerror = db.Column(db.String(4000))
    cuadcrosstoeuro = db.Column(db.Float)
    cuadmultponder = db.Column(db.Float)
    cuadaddponder = db.Column(db.Float)
    cuaddeviationeuro = db.Column(db.Float)
    cuantype = db.Column(db.Numeric(8, 0, asdecimal=False))
    cuancomputeprofile = db.Column(db.Numeric(16, 0, asdecimal=False))
    cuanreason = db.Column(db.String(1))
    cuanstate = db.Column(db.String(1))
    cuanstart = db.Column(db.DateTime)
    cuanparts = db.Column(db.Numeric(16, 0, asdecimal=False))
    cuanerror = db.Column(db.String(4000))
    cuancubecode = db.Column(db.Numeric(8, 0, asdecimal=False))


class VRkcubefullonly(db.Model):
    __tablename__ = "v_rkcubefullonly"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cudategeneration = db.Column(db.DateTime, nullable=False)
    cucode = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cudatecalcul = db.Column(db.DateTime)
    cucfinproduit = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cusommediv = db.Column(db.Numeric(asdecimal=False), nullable=False)
    cucubecomplet = db.Column(
        db.String(1), info="Flag fin générération du cube:  O=complet,  N=non terminé"
    )
    cusensicomplet = db.Column(
        db.String(1),
        info="Flag fin générération du vecteur de sensibilité :  O=complet,  N=non terminé",
    )
    cudatesensi = db.Column(db.DateTime)
    cuarchive = db.Column(db.String(1))
    cunbrecopiecube = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Nombre de recopies de ce cube"
    )
    cuprofile = db.Column(db.Numeric(8, 0, asdecimal=False), info="Profil de calcul")
    cuutcstartcube = db.Column(
        db.DateTime, info="Timestamp utc de reception de la demande de cube"
    )
    cuutcstartsensi = db.Column(
        db.DateTime, info="Timestamp utc de reception de la demande de sensis"
    )
    cutype = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Type de cube (0: full, 1:intraday)",
    )


class VRkfinbook(db.Model):
    __tablename__ = "v_rkfinbook"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    fbdate = db.Column(db.DateTime, nullable=False, info="Date du PnL")
    fbbook = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Sous-portefeuille"
    )
    fbpnl = db.Column(db.Numeric(asdecimal=False), info="PnL contrevalorisé")
    fbfrais = db.Column(db.Numeric(asdecimal=False), info="Frais contrevalorisés")
    fbflag = db.Column(db.Numeric(asdecimal=False), info="Flag de suppression")
    fbtypepnl = db.Column(db.String(1), info="Type de PnL Gestion ou Reference")


class VRkfinbookRef(db.Model):
    __tablename__ = "v_rkfinbook_ref"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    fbdate = db.Column(db.DateTime, nullable=False, info="Date du PnL")
    fbbook = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Sous-portefeuille"
    )
    fbpnl = db.Column(db.Numeric(asdecimal=False), info="PnL contrevalorisé")
    fbfrais = db.Column(db.Numeric(asdecimal=False), info="Frais contrevalorisés")
    fbflag = db.Column(db.Numeric(asdecimal=False), info="Flag de suppression")
    fbtypepnl = db.Column(db.String(1), info="Type de PnL Gestion ou Reference")


class VRkpositiondevise(db.Model):
    __tablename__ = "v_rkpositiondevise"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pddate = db.Column(db.DateTime, nullable=False, info="Date de position devise")
    pdbook = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Sous-portefeuille"
    )
    pddev = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False, info="Devise")
    pdposition = db.Column(db.Numeric(asdecimal=False), info="Position de vise")
    pdflag = db.Column(db.Numeric(asdecimal=False), info="Flag de suppression")
    pdtypepnl = db.Column(db.String(1), info="Type de PnL Gestion ou Reference")


class VRkpositiondeviseRef(db.Model):
    __tablename__ = "v_rkpositiondevise_ref"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pddate = db.Column(db.DateTime, nullable=False, info="Date de position devise")
    pdbook = db.Column(
        db.Numeric(5, 0, asdecimal=False), nullable=False, info="Sous-portefeuille"
    )
    pddev = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False, info="Devise")
    pdposition = db.Column(db.Numeric(asdecimal=False), info="Position de vise")
    pdflag = db.Column(db.Numeric(asdecimal=False), info="Flag de suppression")
    pdtypepnl = db.Column(db.String(1), info="Type de PnL Gestion ou Reference")


class VSmartsOfftr(db.Model):
    __tablename__ = "v_smarts_offtr"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    mic = db.Column(db.String(4))
    message_type = db.Column(db.String(5))
    tradedate = db.Column(db.DateTime)
    time = db.Column(db.String(8))
    trade_id = db.Column(db.String(100))
    security = db.Column(db.String(59))
    price = db.Column(db.Numeric(asdecimal=False))
    volume = db.Column(db.Numeric(asdecimal=False))
    trade_flag = db.Column(db.String(2))
    value = db.Column(db.Numeric(asdecimal=False))
    bid_order_id = db.Column(db.String(11))
    ask_order_id = db.Column(db.String(11))
    bid_broker = db.Column(db.String(5))
    bid_trader = db.Column(db.String(40))
    ask_broker = db.Column(db.String(5))
    ask_trader = db.Column(db.String(40))
    execute_time = db.Column(db.String(8))
    bid_account = db.Column(db.String(40))
    bid_account_type = db.Column(db.String(1))
    ask_account = db.Column(db.String(40))
    ask_account_type = db.Column(db.String(1))
    trade_type = db.Column(db.String(1))
    parent_trade_id = db.Column(db.String(0))
    entity = db.Column(db.String(8))
    source = db.Column(db.String(6))
    route = db.Column(db.String(30))
    route_type = db.Column(db.String(50))
    opnum = db.Column(db.String(40))
    isin_cfin = db.Column(db.String(50))
    currency = db.Column(db.String(3))
    type = db.Column(db.String(10))
    portfolio = db.Column(db.Numeric(asdecimal=False))
    origin = db.Column(db.String(40))
    cfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    venue = db.Column(db.String(10))
    trading_capacity = db.Column(db.String(1))
    profit_center = db.Column(db.String(12))
    counterparty_rc_code = db.Column(db.Numeric(asdecimal=False))


class VTauxForexEur(db.Model):
    __tablename__ = "v_taux_forex_eur"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tfcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Instrument financier"
    )
    tfnom = db.Column(
        db.String(60), nullable=False, info="Nom de l'instrument financier"
    )
    tfcours = db.Column(db.Numeric(13, 5), info="Cours")
    tfdate = db.Column(db.DateTime, nullable=False, info="Date de cotation")
    tfdev = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="code de la devise contre valeur Euro",
    )


class VVarVolProfilref(db.Model):
    __tablename__ = "v_var_vol_profilref"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    phvcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    phvmaj = db.Column(db.DateTime)
    vhdstrike = db.Column(db.Numeric(18, 5), nullable=False)
    vhdmaturite = db.Column(db.DateTime, nullable=False)
    vhdvol = db.Column(db.Numeric(10, 5))
    vhdhorodate = db.Column(db.DateTime, nullable=False)
    vhdmaj = db.Column(db.DateTime)


class VVarswapIndex(db.Model):
    __tablename__ = "v_varswap_index"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    citype = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    cisource = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    cicfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cidatevaleur = db.Column(db.DateTime, nullable=False)
    cicodematurite = db.Column(db.Numeric(3, 0, asdecimal=False))
    cidatematurite = db.Column(db.DateTime)
    cistrikepct = db.Column(db.Numeric(13, 5))
    cispot = db.Column(db.Numeric(13, 5))
    civaleur = db.Column(db.Numeric(13, 5))
    ciprofil = db.Column(db.Numeric(5, 0, asdecimal=False))
    ciinfoflag = db.Column(db.Numeric(2, 0, asdecimal=False))


class VWarrantexane(db.Model):
    __tablename__ = "v_warrantexane"
    __bind_key__ = "exane_risque"
    __table_args__ = {"schema": "risque"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    wedate = db.Column(db.DateTime)
    welibelle = db.Column(db.String(60), nullable=False)
    weisin = db.Column(db.String(50))
    wecours = db.Column(db.Numeric(asdecimal=False))
    wedevise = db.Column(db.String(60), nullable=False)

# coding: utf-8
from local_db_mgt import db


class Afacces(db.Model):
    __tablename__ = "afaccess"
    __table_args__ = {"schema": "analyse"}

    acid = db.Column(
        db.String(20), primary_key=True, nullable=False, info="Ip du poste"
    )
    acdatedebut = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Debut de l'init de sake"
    )
    acdatefin = db.Column(db.DateTime, nullable=False, info="Fin de l'init de sake")
    acloadflag = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="Kind of load 1 is Paris mode, 2 is London distant mode, 3 London mode fails swtiching to Paris mode",
    )
    acuser = db.Column(db.String(100), info="Logged user which has launched Sake")


class Afactionnaire(db.Model):
    __tablename__ = "afactionnaires"
    __table_args__ = {"schema": "analyse"}

    aacfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    aaposition = db.Column(
        db.Numeric(6, 0, asdecimal=False), primary_key=True, nullable=False
    )
    aanomfr = db.Column(db.String(80))
    aanomgb = db.Column(db.String(80))
    aapctcapital = db.Column(db.Numeric(7, 3))
    aaddv = db.Column(db.Numeric(7, 3))


class Afanalystesecondaire(db.Model):
    __tablename__ = "afanalystesecondaire"
    __table_args__ = {"schema": "analyse"}

    asanalyste = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Analyste secondaire",
    )
    ascfin = db.Column(
        db.ForeignKey("analyse.afsociete.socfin"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Société suivie",
    )

    afsociete = db.relationship(
        "Afsociete",
        primaryjoin="Afanalystesecondaire.ascfin == Afsociete.socfin",
        backref="afanalystesecondaires",
    )


class Afbasedocpath(db.Model):
    __tablename__ = "afbasedocpath"
    __table_args__ = {"schema": "analyse"}

    bp_code = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    bp_path = db.Column(db.String(255))


class Afbnmodify(db.Model):
    __tablename__ = "afbnmodifies"
    __table_args__ = {"schema": "analyse"}

    mocfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code société",
    )
    moexercice = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date d'exercice fiscal"
    )
    modate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date de modification"
    )
    mobeneficenetcorrige = db.Column(db.Numeric(16, 4), info="Bénéfice net corrigé")
    mobpasvl = db.Column(db.Numeric(13, 5), info="BPA + survaleur calculé")
    mosurvaleur = db.Column(db.Numeric(16, 4), info="Survaleur")
    motauxan = db.Column(db.Numeric(8, 4), info="Taux annuel")
    moeconomiefraisfi = db.Column(
        db.Numeric(13, 5), info="Economie de frais financiers"
    )
    moratiodilution = db.Column(db.Numeric(13, 5), info="Ratio de dilution")


class Afbnmodifiessake(db.Model):
    __tablename__ = "afbnmodifiessake"
    __table_args__ = {"schema": "analyse"}

    mocfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    moexercice = db.Column(db.DateTime, primary_key=True, nullable=False)
    modate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date de modification"
    )
    mobeneficenetcorrige = db.Column(db.Numeric(16, 4), info="Bénéfice net corrigé")
    modevisecompte = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Code devise"
    )
    mobpasvl = db.Column(db.Numeric(13, 5), info="BPA + survaleur calculé")
    mosurvaleur = db.Column(db.Numeric(16, 4), info="Survaleur")
    motauxan = db.Column(db.Numeric(8, 4), info="Taux annuel")
    moeconomiefraisfi = db.Column(
        db.Numeric(13, 5), info="Economie de frais financiers"
    )
    moratiodilution = db.Column(db.Numeric(13, 5), info="Ratio de dilution")


class Afbrevecomment(db.Model):
    __tablename__ = "afbrevecomments"
    __table_args__ = {"schema": "analyse"}

    bcuser = db.Column(db.String(200))
    bcdate = db.Column(db.DateTime)
    bccomment = db.Column(db.String(4000))
    bcflag = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    bctype = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        info="Type 0->Commentaire du workflow 1->Lock PickOfTheDay",
    )


class Afbrevesuser(db.Model):
    __tablename__ = "afbrevesusers"
    __table_args__ = {"schema": "analyse"}

    bufile = db.Column(db.String(200), primary_key=True, nullable=False)
    bufolder = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    buuser = db.Column(db.String(200))
    butime = db.Column(db.DateTime)
    busujet = db.Column(db.String(80))
    butitre = db.Column(db.String(200))
    buauteur = db.Column(db.String(100))
    bulength = db.Column(db.String(3))
    bulancement = db.Column(db.DateTime)
    butypestrat = db.Column(db.String(3))
    bupaofr = db.Column(db.String(200))
    burelgb = db.Column(db.String(200))
    burelfr = db.Column(db.String(200))
    butradgb = db.Column(db.String(3))
    buetatdif = db.Column(db.String(3))
    buas = db.Column(db.String(3))
    buprioritaire = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )


class Afbusinesslabel(db.Model):
    __tablename__ = "afbusinesslabel"
    __table_args__ = {"schema": "analyse"}

    blcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    bltypesplit = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    bllibellefr = db.Column(db.String(80))
    bllibellegb = db.Column(db.String(80))


class Afcfincomparable(db.Model):
    __tablename__ = "afcfincomparables"
    __table_args__ = {"schema": "analyse"}

    ccinstrument = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cccomparable = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )


class Afchamplibre(db.Model):
    __tablename__ = "afchamplibre"
    __table_args__ = {"schema": "analyse"}

    clsocfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    clnumero = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    clindicateur = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)


class Afchamplibreaffiche(db.Model):
    __tablename__ = "afchamplibreaffiche"
    __table_args__ = {"schema": "analyse"}

    clafsocfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    clafnumero = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    clafindicateur = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)


class Afchamplibreexe(db.Model):
    __tablename__ = "afchamplibreexe"
    __table_args__ = {"schema": "analyse"}

    clexsocfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    clexfinexercice = db.Column(db.DateTime, primary_key=True, nullable=False)
    clexnumero = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    clexvalue = db.Column(db.Numeric(16, 5))


class Afchangementanalyste(db.Model):
    __tablename__ = "afchangementanalyste"
    __table_args__ = {"schema": "analyse"}

    chcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code du produit",
    )
    chdate = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Date de changement d'analyste",
    )
    chancien = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Ancien analyste suivant la valeur"
    )
    chnouveau = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Nouvel analyste suivant la valeur"
    )


class Afchatofor(db.Model):
    __tablename__ = "afchatofor"
    __table_args__ = {"schema": "analyse"}

    cht_idmsg = db.Column(db.String(50), info="Id du message d'easychat")
    cht_fichier = db.Column(
        db.String(255),
        info="Nom du fichier (pour faire le lien avec le document diffusé)",
    )
    cht_date = db.Column(db.DateTime, info="Date du message")
    cht_iddoc = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Code du document dans la base documentaire",
    )


class Afclasse(db.Model):
    __tablename__ = "afclasse"
    __table_args__ = {"schema": "analyse"}

    clcode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="Code de la classe"
    )
    cllibfr = db.Column(db.String(50), info="Libelle FR de la classe")
    clliben = db.Column(db.String(50), info="Libelle FR de la classe")
    clsymbole = db.Column(db.String(1), info="Symbole de la classe")


class Afcoderating(db.Model):
    __tablename__ = "afcoderating"
    __table_args__ = {"schema": "analyse"}

    crcoderating = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de type de rating",
    )
    crlibelle = db.Column(db.String(20), info="Libellé du spread")


class Afcodif(db.Model):
    __tablename__ = "afcodif"
    __table_args__ = {"schema": "analyse"}

    cfsource = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cfcode = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cfvalue = db.Column(db.String(6), nullable=False)
    cfdesc = db.Column(db.String(30))
    cfisdpa = db.Column(db.Numeric(1, 0, asdecimal=False))
    cfcodeexane = db.Column(db.Numeric(8, 0, asdecimal=False))
    cfunit = db.Column(db.Numeric(1, 0, asdecimal=False))


class Afcompilcompo(db.Model):
    __tablename__ = "afcompilcompo"
    __table_args__ = {"schema": "analyse"}

    cccode = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ccrownb = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ccrowcondition = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ccoperator = db.Column(db.Numeric(2, 0, asdecimal=False), nullable=False)
    cccustomprop = db.Column(db.String(30))
    cccustomvalue = db.Column(db.String(50))
    ccsignet = db.Column(db.String(15))
    cccomment = db.Column(db.String(50))


class Afcompliance(db.Model):
    __tablename__ = "afcompliance"
    __table_args__ = {"schema": "analyse"}

    cpcfin = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    cpdatedebut = db.Column(db.DateTime, nullable=False)
    cpdatefin = db.Column(db.DateTime, nullable=False)
    cpresumefr = db.Column(db.String(1000), info="resumé interne sur la compliance")
    cpresumegb = db.Column(db.String(1000), info="resumé interne sur la compliance")
    cpresumecountryfr = db.Column(db.String(1000), info="resumé pays sur la compliance")
    cpresumecountrygb = db.Column(db.String(1000), info="resumé pays sur la compliance")
    cpresumeclientfr = db.Column(
        db.String(1000), info="resumé client sur la compliance"
    )
    cpresumeclientgb = db.Column(
        db.String(1000), info="resumé client sur la compliance"
    )
    cpidusercreation = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cpidusermodification = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cpdatecreation = db.Column(db.DateTime, nullable=False)
    cpdatemodification = db.Column(db.DateTime, nullable=False)


class Afcompliancedatadetail(db.Model):
    __tablename__ = "afcompliancedatadetails"
    __table_args__ = {"schema": "analyse"}

    cpdacfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cpdatypedetails = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cpdatypeuser = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cpdatypeusercountry = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cpdadatemodification = db.Column(db.DateTime, nullable=False)


class Afcompliancedatahisto(db.Model):
    __tablename__ = "afcompliancedatahisto"
    __table_args__ = {"schema": "analyse"}

    cpdacfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cpdatypedetails = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cpdatypeuser = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cpdatypeusercountry = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cpdadatemodification = db.Column(db.DateTime, primary_key=True, nullable=False)


class Afcompliancedocumentdetail(db.Model):
    __tablename__ = "afcompliancedocumentdetails"
    __table_args__ = {"schema": "analyse"}

    cpdocfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cpdotypedetails = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cpdotypeuser = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cpdotypeusercountry = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cpdodatemodification = db.Column(db.DateTime, nullable=False)


class Afcompliancedocumenthisto(db.Model):
    __tablename__ = "afcompliancedocumenthisto"
    __table_args__ = {"schema": "analyse"}

    cpdocfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cpdotypedetails = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cpdotypeuser = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cpdotypeusercountry = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cpdodatemodification = db.Column(db.DateTime, primary_key=True, nullable=False)


class Afcompliancehisto(db.Model):
    __tablename__ = "afcompliancehisto"
    __table_args__ = {"schema": "analyse"}

    cpcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cpdatedebut = db.Column(db.DateTime, nullable=False)
    cpdatefin = db.Column(db.DateTime, nullable=False)
    cpresumefr = db.Column(db.String(80))
    cpresumegb = db.Column(db.String(80))
    cpresumecountryfr = db.Column(db.String(80))
    cpresumecountrygb = db.Column(db.String(80))
    cpresumeclientfr = db.Column(db.String(80))
    cpresumeclientgb = db.Column(db.String(80))
    cpidusercreation = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cpidusermodification = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cpdatecreation = db.Column(db.DateTime, nullable=False)
    cpdatemodification = db.Column(db.DateTime, primary_key=True, nullable=False)


class Afcompliancetypedatadetail(db.Model):
    __tablename__ = "afcompliancetypedatadetails"
    __table_args__ = {"schema": "analyse"}

    cptdtype = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    cptdlabel = db.Column(db.String(20), nullable=False)


class Afcompliancetypedocdetail(db.Model):
    __tablename__ = "afcompliancetypedocdetails"
    __table_args__ = {"schema": "analyse"}

    cptotype = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    cptolabel = db.Column(db.String(20), nullable=False)


class Afcompliancetypeuser(db.Model):
    __tablename__ = "afcompliancetypeuser"
    __table_args__ = {"schema": "analyse"}

    cptutype = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    cptulabel = db.Column(db.String(20), nullable=False)


class Afcompodicocodif(db.Model):
    __tablename__ = "afcompodicocodif"
    __table_args__ = {"schema": "analyse"}

    cdtypecodif = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cdcodeexterne = db.Column(db.String(30), primary_key=True, nullable=False)
    cdlibelle = db.Column(db.String(30))
    cdordre = db.Column(db.Numeric(3, 0, asdecimal=False))


class Afcompoechantillon(db.Model):
    __tablename__ = "afcompoechantillon"
    __table_args__ = {"schema": "analyse"}

    cecode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de l'échantillon",
    )
    cesociete = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Société de l'échantillon",
    )
    ceentree = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        server_default=db.FetchedValue(),
        info="Date d'entrée",
    )
    cesortie = db.Column(
        db.DateTime, server_default=db.FetchedValue(), info="Date de sortie"
    )
    ceperf = db.Column(db.Numeric(10, 3))


class Afcompolisteenum(db.Model):
    __tablename__ = "afcompolisteenum"
    __table_args__ = {"schema": "analyse"}

    letypecodif = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    lecode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    lelibelle = db.Column(db.String(60))
    leordre = db.Column(db.Numeric(3, 0, asdecimal=False))


class Afcompoliste(db.Model):
    __tablename__ = "afcompolistes"
    __table_args__ = {"schema": "analyse"}

    clliste = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de la liste",
    )
    clordre = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Ordre d apparence dans la liste",
    )
    clindicateur = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code de l indicateur"
    )
    cltypedevise = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Redéfinition du type devise",
    )
    cltyperatio = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Redéfinition du type de ratio",
    )
    clannualisation = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Redéfinition du type d annualisation",
    )
    cltypecours = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Redéfinition du type de cours",
    )
    cllibellefr = db.Column(db.String(400), info="Redéfinition du libellé FR")
    cllibellegb = db.Column(db.String(400), info="Redéfinition du Libellé GB")
    clfctderive = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Fonction dérivée, TMVA, variation",
    )
    clformat = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Format de réprésentation"
    )
    cltypesociete = db.Column(db.Numeric(8, 0, asdecimal=False), info="Type de secteur")
    clannee = db.Column(db.Numeric(4, 0, asdecimal=False))
    clparamsplit = db.Column(db.Numeric(3, 0, asdecimal=False))
    clprecision = db.Column(db.Numeric(2, 0, asdecimal=False))
    clatomes = db.Column(db.Numeric(3, 0, asdecimal=False))
    clfonctionexcel = db.Column(db.String(400))
    clismasque = db.Column(db.Numeric(1, 0, asdecimal=False))
    clsaisie = db.Column(db.Numeric(1, 0, asdecimal=False))
    cltrvparent = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Ordre du noeud parent quand la compoliste decrit une treeview",
    )
    clparamerequeteur = db.Column(
        db.String(100), info="Parametres pour la fonction eRequeteur"
    )
    cltypedevisefordiff = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        info="type de devise pour les societes a double devise",
    )


class Afcomposecteurstrategie(db.Model):
    __tablename__ = "afcomposecteurstrategie"
    __table_args__ = {"schema": "analyse"}

    cscfinsecteurstrategie = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False
    )
    cscfinsecteur = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)


class Afdatafin(db.Model):
    __tablename__ = "afdatafin"
    __table_args__ = (
        db.CheckConstraint("DTFINEXERCICE >= to_date('01011950',\n     'DDMMYYYY')"),
        db.CheckConstraint("DTFINEXERCICE >= to_date('01011950',\n'DDMMYYYY')"),
        {"schema": "analyse"},
    )

    dtcfin = db.Column(
        db.ForeignKey("analyse.afsociete.socfin"),
        primary_key=True,
        nullable=False,
        info="Code société",
    )
    dtfinexercice = db.Column(db.DateTime, primary_key=True, nullable=False)
    dtfin_exer = db.Column(db.DateTime)
    dtetat = db.Column(db.String(1))
    dtca = db.Column(db.Numeric(18, 5))
    dtexploit = db.Column(db.Numeric(16, 5))
    dtfrais_fn = db.Column(db.Numeric(16, 5))
    dtres_except = db.Column(db.Numeric(16, 5))
    dtimpot = db.Column(db.Numeric(16, 5))
    dtsurval = db.Column(db.Numeric(16, 5))
    dtbn = db.Column(db.Numeric(18, 5))
    dtbn_corrige = db.Column(db.Numeric(18, 5))
    dtcf = db.Column(db.Numeric(16, 5))
    dtcf_pdg = db.Column(db.Numeric(16, 5))
    dtd_bfr = db.Column(db.Numeric(16, 5))
    dtinv_fn_net = db.Column(db.Numeric(16, 5))
    dtdivers = db.Column(db.Numeric(16, 5))
    dtaug_capit = db.Column(db.Numeric(16, 5))
    dtaug_dette = db.Column(db.Numeric(16, 5))
    dtdiv_mf = db.Column(db.Numeric(16, 5))
    dtimmo = db.Column(db.Numeric(16, 5))
    dtelt_incorpo = db.Column(db.Numeric(16, 5))
    dtbfr = db.Column(db.Numeric(16, 5))
    dtfp_ang = db.Column(db.Numeric(20, 5))
    dtfp_pg = db.Column(db.Numeric(20, 5))
    dtprov = db.Column(db.Numeric(16, 5))
    dtdette_fn = db.Column(db.Numeric(16, 5))
    dteffectif = db.Column(db.Numeric(9, 2))
    dtdividend = db.Column(db.Numeric(16, 5))
    dtautocont = db.Column(db.Numeric(16, 5))
    dtajust = db.Column(db.Numeric(17, 6), server_default=db.FetchedValue())
    dtflottant = db.Column(db.Numeric(16, 5))
    dtactif_nr = db.Column(db.Numeric(20, 5))
    dtactif_nt = db.Column(db.Numeric(20, 5))
    dtpnb = db.Column(db.Numeric(16, 5))
    dtrbe = db.Column(db.Numeric(16, 5))
    dtnbre_action = db.Column(db.Numeric(17, 5))
    dtprix_exer = db.Column(db.Numeric(9, 2))
    dtavoir_fiscal = db.Column(db.Numeric(16, 5))
    dtproduction = db.Column(db.Numeric(17, 5))
    dtinvind = db.Column(db.Numeric(16, 5))
    dttitre = db.Column(db.Numeric(16, 5))
    dtcapi_emprunt = db.Column(db.Numeric(16, 5))
    dtprovision = db.Column(db.Numeric(16, 5))
    dtencours = db.Column(db.Numeric(16, 5))
    dtcours_moyen = db.Column(db.Numeric(18, 5))
    dtexe = db.Column(db.Numeric(2, 0, asdecimal=False))
    dtfrais_gnr = db.Column(db.Numeric(16, 5))
    dtmee = db.Column(db.Numeric(16, 5))
    dtminoritaire = db.Column(db.Numeric(16, 5))
    dttreso_actif = db.Column(db.Numeric(16, 5))
    dttreso_passif = db.Column(db.Numeric(16, 5))
    dtdepot = db.Column(db.Numeric(16, 5))
    dtemprunt_obl = db.Column(db.Numeric(16, 5))
    dtdette_sub = db.Column(db.Numeric(16, 5))
    dtcooke = db.Column(db.Numeric(16, 5))
    dtretraite = db.Column(db.Numeric(16, 5))
    dtprime_vie = db.Column(db.Numeric(16, 5))
    dtprime_nonvie = db.Column(db.Numeric(16, 5))
    dtres_tx = db.Column(db.Numeric(16, 5))
    dtpdt_place = db.Column(db.Numeric(16, 5))
    dtplt_imm = db.Column(db.Numeric(16, 5))
    dtplt_fin = db.Column(db.Numeric(16, 5))
    dtsolde_ap = db.Column(db.Numeric(16, 5))
    dtpvl_act = db.Column(db.Numeric(16, 5))
    dtpvl_ass = db.Column(db.Numeric(16, 5))
    dtv_placement = db.Column(db.Numeric(16, 5))
    dtv_interres = db.Column(db.Numeric(16, 5))
    dtv_expense_r = db.Column(db.Numeric(16, 5))
    dtv_bn_vie = db.Column(db.Numeric(16, 5))
    dtnv_loss_r = db.Column(db.Numeric(16, 5))
    dtnv_expense_r = db.Column(db.Numeric(16, 5))
    dtnv_r_combine = db.Column(db.Numeric(16, 5))
    dtnv_bn_vie = db.Column(db.Numeric(16, 5))
    dtprov_vie = db.Column(db.Numeric(16, 5))
    dtprov_non_vie = db.Column(db.Numeric(16, 5))
    dtcharge = db.Column(db.Numeric(16, 5))
    dtdette_cvt = db.Column(db.Numeric(16, 5))
    dtautre_dette = db.Column(db.Numeric(16, 5))
    dtembed_value = db.Column(db.Numeric(16, 5))
    dtv_bn_prov = db.Column(db.Numeric(16, 5))
    dtv_fp_prov = db.Column(db.Numeric(16, 5))
    dtnv_bn_prime = db.Column(db.Numeric(16, 5))
    dtloyer_cbi = db.Column(db.Numeric(16, 5))
    dtloyer_locat = db.Column(db.Numeric(16, 5))
    dtcredit_bail = db.Column(db.Numeric(16, 5))
    dtdivers_actif = db.Column(db.Numeric(16, 5))
    dtpatrimoine = db.Column(db.Numeric(16, 5))
    dtdivers_passif = db.Column(db.Numeric(16, 5))
    dtloyer = db.Column(db.Numeric(16, 5))
    dtdotation = db.Column(db.Numeric(16, 5))
    dtpatrimoine_r = db.Column(db.Numeric(16, 5))
    dtanpa_ve = db.Column(db.Numeric(16, 5))
    dtcycle = db.Column(
        db.Numeric(1, 0, asdecimal=False), info="Haut de cycle 1, bas 2, sinon 0"
    )
    dtetatexercice = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    dtexercice = db.Column(db.Numeric(7, 2))
    dtactifcorponet = db.Column(db.Numeric(16, 5))
    dtsurvalbrut = db.Column(db.Numeric(16, 5))
    dtunite = db.Column(
        db.ForeignKey("analyse.afunite.uncode"),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    dtdevise = db.Column(
        db.Numeric(8, 0, asdecimal=False), server_default=db.FetchedValue()
    )

    afsociete = db.relationship(
        "Afsociete",
        primaryjoin="Afdatafin.dtcfin == Afsociete.socfin",
        backref="afdatafins",
    )
    afunite = db.relationship(
        "Afunite",
        primaryjoin="Afdatafin.dtunite == Afunite.uncode",
        backref="afdatafins",
    )


class Afdatahistochange(db.Model):
    __tablename__ = "afdatahistochange"
    __table_args__ = {"schema": "analyse"}

    dhcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Cfin societe",
    )
    dhdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date de calcul"
    )
    dhexefiscal = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Annee exercice fiscal",
    )
    dhtypedata = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Type de donnee :  Null = 0, VE = 1, Capi = 2, PEAvtSvl = 3, PCFPA = 4, PANPA = 5, VESurCa = 6, VESurEBITDa = 7, VESurEBIT = 8, VESurOPFCF = 9, \tVESurCE = 10, GEaring = 11, Couvff = 12, RoceSurWacc = 13, PESurCAgrNoPat = 14, DNSurVE = 15, ROCE = 16, ROE = 17, WACC = 18, FV = 19, RendementNet = 20, BPA = 21, BPAplusSVL =22, CFPA = 23, ANPA = 24, DividendeNet = 25, CA = 26, \tEBITDA = 27, EBIT = 28, OPFCF = 29, CE = 30, DN = 31, PAYOUT = 32, PEAVTSVL_NEG = 33, PEAPRSVL_NEG = 34, Cours = 35, PoidsGauche = 36, PoidsDroite = 37, \tExeFiscal = 38, PEAPRSVL = 39, BNPdgAvantSVL = 40, BNPdgApresSVL = 41",
    )
    dhdevise = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Devise de la donnee"
    )
    dhvalue = db.Column(db.Numeric(16, 5), info="Valeure de la donnee")
    dhtauxchange = db.Column(
        db.Numeric(16, 5),
        info="Taux de change entre la devise de publication et l EURO",
    )
    dhupdatedate = db.Column(db.DateTime, info="Date de mise a jour de la révision")
    dhtauxchangepubli = db.Column(
        db.Numeric(16, 5),
        info="Taux de change entre la devise de publication et la devise de cotation",
    )


class Afdevise(db.Model):
    __tablename__ = "afdevises"
    __table_args__ = {"schema": "analyse"}

    decfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Code devise"
    )
    denom = db.Column(db.String(40), info="Nom de la devise")
    denomcourtfr = db.Column(
        db.String(5), info="Libelle court de la devise en Francais"
    )
    denomcourtgb = db.Column(db.String(5), info="Libelle court de la devise en Anglais")
    deineuro = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Est une devise de l'Euro",
    )
    dedateineuro = db.Column(db.DateTime, info="Date d'entrée dans l'Euro")
    deparitefixe = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Devise à parité fixe 1 ou variable 0",
    )
    dedeviseparfixe = db.Column(
        db.ForeignKey("analyse.afdevises.decfin"),
        index=True,
        info="Devise de parité fixe",
    )
    demultiplefixe = db.Column(
        db.Numeric(18, 6),
        server_default=db.FetchedValue(),
        info="Multiplicateur de parité fixe",
    )
    deprefixfr = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Prefixé en Francais",
    )
    deprefixgb = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Préfixé en Anglais",
    )
    deunite = db.Column(
        db.ForeignKey("analyse.afunite.uncode"), server_default=db.FetchedValue()
    )
    denomcourtibes = db.Column(db.String(3))
    denomlongfr = db.Column(db.String(5))
    denomlonggb = db.Column(db.String(5))
    demoyennemobile = db.Column(db.Numeric(10, 5))
    despot = db.Column(db.Numeric(10, 5))
    detauxreference = db.Column(db.Numeric(10, 5))
    dedatetauxreference = db.Column(db.DateTime)
    dedateveriftaux = db.Column(db.DateTime)
    dedatemaj = db.Column(db.DateTime)
    denomuk = db.Column(db.String(40))
    denomdatastream = db.Column(db.String(10), info="Nom datastream de la devise")

    parent = db.relationship(
        "Afdevise",
        remote_side=[decfin],
        primaryjoin="Afdevise.dedeviseparfixe == Afdevise.decfin",
        backref="afdevises",
    )
    afunite = db.relationship(
        "Afunite", primaryjoin="Afdevise.deunite == Afunite.uncode", backref="afdevises"
    )


class Afdicodonnee(db.Model):
    __tablename__ = "afdicodonnees"
    __table_args__ = {"schema": "analyse"}

    ddcode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Code de la fonction"
    )
    ddnom = db.Column(
        db.String(40), nullable=False, info="Nom de la fonction appelable"
    )
    ddlibellefr = db.Column(db.String(80), info="Libellé français")
    ddlibellegb = db.Column(db.String(80), info="Libellé anglais")
    ddtype = db.Column(db.Numeric(2, 0, asdecimal=False), info="Typologie d'appel")
    ddsaisie = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Donnée saisissable",
    )
    ddprecision = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Précision du format",
    )
    ddunittype = db.Column(db.Numeric(2, 0, asdecimal=False), info="Type de forma")


class Afdicosake(db.Model):
    __tablename__ = "afdicosake"
    __table_args__ = {"schema": "analyse"}

    ddcode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Code de l indicateur"
    )
    ddnom = db.Column(
        db.String(80), nullable=False, info="Nom de la fonction appelable"
    )
    ddlibellefr = db.Column(db.String(80), info="Libellé français")
    ddlibellegb = db.Column(db.String(80), info="Libellé anglais")
    ddtype = db.Column(db.Numeric(2, 0, asdecimal=False), info="Typologie d'appel")
    ddsaisie = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Type de la fonction (Calcule = 0, Saisie = 1, SaisiePasse =2, SaisieFutur = 3, SaisieFuturEtPremierExercice = 4, SaisieBTExcel = 5)",
    )
    ddprecision = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Précision du format",
    )
    ddunittype = db.Column(db.Numeric(2, 0, asdecimal=False), info="%AttDef")
    ddtypesoc = db.Column(db.Numeric(4, 0, asdecimal=False), info="Type de société")
    ddtypedata = db.Column(db.Numeric(4, 0, asdecimal=False), info="Type de données")
    ddtypedevise = db.Column(
        db.ForeignKey("analyse.afdicotypedevise.tdcode"), info="Code type devise"
    )
    ddtyperatio = db.Column(db.Numeric(1, 0, asdecimal=False))
    ddannualisation = db.Column(
        db.Numeric(1, 0, asdecimal=False), info="Type d annualisation"
    )
    ddtypecours = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Code type de cours"
    )
    ddcomment = db.Column(db.String(40), info="Commentaire")
    ddfonctionexcel = db.Column(db.String(400))
    ddischamplibre = db.Column(db.Numeric(1, 0, asdecimal=False))
    ddmatrix = db.Column(
        db.String(400), info="Description de la fonction pour le requeteur matriciel"
    )
    ddcategory = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        info="Categorie de l'indicateur Null:Aucune ; 1:Comptes ; 2:Target Price ; 3:Rating; 4:NoteRisque/Spread ; 5:BaseTitres",
    )
    ddsensvalue = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="0 => tri croissant, 1 => tri decroissant",
    )
    ddsource = db.Column(db.Numeric(8, 0, asdecimal=False))
    ddtypeval = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Type de l indicateur 0 double, 1 long, 2 string, 3 date etc ...",
    )
    ddcalendarized = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="1 si indicateur est calendarisable",
    )
    ddtypedeviseesake = db.Column(
        db.Numeric(1, 0, asdecimal=False), info="type de devise pour esake"
    )
    ddregleid = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        info="Regle a appliquer pour aggreger un secteur : 1= Somme, 2=Moyenne, 3=Mediane,\n    0= (Pas de regle ou Specifique ou Calcule en fonction d autres indic) ",
    )
    ddparameterstype = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Type de parametres pour eRequeteur"
    )

    afdicotypedevise = db.relationship(
        "Afdicotypedevise",
        primaryjoin="Afdicosake.ddtypedevise == Afdicotypedevise.tdcode",
        backref="afdicosakes",
    )


class Afdicosplit(db.Model):
    __tablename__ = "afdicosplit"
    __table_args__ = {"schema": "analyse"}

    dscode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    ddnom = db.Column(db.String(40))
    dslibellefr = db.Column(db.String(80))
    dslibellegb = db.Column(db.String(80))


class Afdicotypecour(db.Model):
    __tablename__ = "afdicotypecours"
    __table_args__ = {"schema": "analyse"}

    tccode = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        primary_key=True,
        server_default=db.FetchedValue(),
        info="Code type de cours",
    )
    tclibelle = db.Column(db.String(40), info="Libellé")


class Afdicotypedevise(db.Model):
    __tablename__ = "afdicotypedevise"
    __table_args__ = {"schema": "analyse"}

    tdcode = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        primary_key=True,
        server_default=db.FetchedValue(),
        info="Code type devise",
    )
    tdlibelle = db.Column(db.String(40))


class Afdicotypefct(db.Model):
    __tablename__ = "afdicotypefct"
    __table_args__ = {"schema": "analyse"}

    tfcode = db.Column(db.Numeric(2, 0, asdecimal=False), primary_key=True)
    tfenum = db.Column(db.String(40))
    tflibellefr = db.Column(db.String(40))
    tflibellegb = db.Column(db.String(40))


class Afdicotyperatio(db.Model):
    __tablename__ = "afdicotyperatio"
    __table_args__ = {"schema": "analyse"}

    trcode = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        primary_key=True,
        server_default=db.FetchedValue(),
    )
    trlibelle = db.Column(db.String(40))


class Afdirigeant(db.Model):
    __tablename__ = "afdirigeants"
    __table_args__ = {"schema": "analyse"}

    dgcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    dgposition = db.Column(
        db.Numeric(6, 0, asdecimal=False), primary_key=True, nullable=False
    )
    dgtype = db.Column(db.Numeric(4, 0, asdecimal=False))
    dgprenom = db.Column(db.String(40))
    dgnom = db.Column(db.String(40))


class Afdispibe(db.Model):
    __tablename__ = "afdispibes"
    __table_args__ = {"schema": "analyse"}

    dpcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code ( clef) cfin voir RKPRODUIT",
    )
    dpdate = db.Column(db.DateTime, nullable=False, info="Date de la mise a jour")
    dpdispersion = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        info="Dispersion du consensus des estimations EPS",
    )
    dpbureaux = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Nombre de bureaux ayant contribues"
    )
    f1end = db.Column(db.DateTime)
    f1mn = db.Column(db.Numeric(16, 5))
    f1hi = db.Column(db.Numeric(16, 5))
    f1lo = db.Column(db.Numeric(16, 5))
    f1mn1m = db.Column(db.Numeric(16, 5))
    f1mn3m = db.Column(db.Numeric(16, 5))
    f2end = db.Column(db.DateTime)
    f2mn = db.Column(db.Numeric(16, 5))
    f2hi = db.Column(db.Numeric(16, 5))
    f2lo = db.Column(db.Numeric(16, 5))
    f2mn1m = db.Column(db.Numeric(16, 5))
    f2mn3m = db.Column(db.Numeric(16, 5))
    dpdevise = db.Column(db.Numeric(8, 0, asdecimal=False))
    foend = db.Column(db.DateTime)
    foeps = db.Column(db.Numeric(16, 5))
    fm1end = db.Column(db.DateTime)
    fm1eps = db.Column(db.Numeric(16, 5))
    fm2end = db.Column(db.DateTime)
    fm2eps = db.Column(db.Numeric(16, 5))
    rf1mn = db.Column(db.Numeric(16, 5))
    ltgmn = db.Column(db.Numeric(16, 5))
    f0end = db.Column(db.DateTime)
    f0eps = db.Column(db.Numeric(16, 5))
    f3end = db.Column(db.DateTime)
    f3mn = db.Column(db.Numeric(16, 5))
    f3lo = db.Column(db.Numeric(16, 5))
    f3mn1m = db.Column(db.Numeric(16, 5))
    f3mn3m = db.Column(db.Numeric(16, 5))
    f3est = db.Column(db.Numeric(3, 0, asdecimal=False))
    f2est = db.Column(db.Numeric(3, 0, asdecimal=False))
    f3hi = db.Column(db.Numeric(16, 5))
    f2cv = db.Column(db.Numeric(4, 0, asdecimal=False))
    f3cv = db.Column(db.Numeric(4, 0, asdecimal=False))


class Afechantillon(db.Model):
    __tablename__ = "afechantillon"
    __table_args__ = (db.CheckConstraint("ECACCES IN (0, 1, 2)"), {"schema": "analyse"})

    eccode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de l'échantillon",
    )
    ecnomfr = db.Column(db.String(40), info="Nom français de l'échantillon")
    eccreateur = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Code de l'utilisateur"
    )
    ecnomgb = db.Column(db.String(40), info="Nom anglais de l'échantillon")
    ecdevise = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Devise de consolidation de l'échantillon",
    )
    ecindice = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Indice de référence de l'échantillon"
    )
    ectypecapidefaut = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Type de capitalisation par défaut de l'échantillon",
    )
    ectypesuividefaut = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        info="Type de suivi par défaut de l'échantillon",
    )
    eccreation = db.Column(db.DateTime, info="Date de création de l'échantillon")
    ecacces = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Type d'accés autorisé à l'échantillon",
    )
    eclastpub = db.Column(db.DateTime)
    eccalcule = db.Column(db.Numeric(1, 0, asdecimal=False))
    eccompositionbasecentrale = db.Column(db.Numeric(8, 0, asdecimal=False))
    eccfincours = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Cfin Cours echantillon"
    )
    eccodeparent = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code echantillon parent"
    )
    to_monitor = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="flag pour indiquer monitoring on echantillon",
    )


class Afenumcompo(db.Model):
    __tablename__ = "afenumcompo"
    __table_args__ = {"schema": "analyse"}

    edcode = db.Column(db.Numeric(2, 0, asdecimal=False))
    edenum = db.Column(db.Numeric(6, 0, asdecimal=False))
    ednom = db.Column(db.String(40))


class Afenumdico(db.Model):
    __tablename__ = "afenumdico"
    __table_args__ = {"schema": "analyse"}

    edcode = db.Column(db.Numeric(2, 0, asdecimal=False))
    edlibelle = db.Column(db.String(40))


class Afeventcomment(db.Model):
    __tablename__ = "afeventcomment"
    __table_args__ = {"schema": "analyse"}

    eccfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ecfinexercice = db.Column(db.DateTime, primary_key=True, nullable=False)
    ecfonction = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ectypesplit = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    eccommentfr = db.Column(db.String(100))
    eccommentgb = db.Column(db.String(100))


class Afexercice(db.Model):
    __tablename__ = "afexercices"
    __table_args__ = {"schema": "analyse"}

    excfin = db.Column(
        db.ForeignKey("analyse.afsociete.socfin"), primary_key=True, nullable=False
    )
    exfinexercice = db.Column(db.DateTime, primary_key=True, nullable=False)
    cr_ca = db.Column(db.Numeric(16, 5))
    cr_autresproduits = db.Column(db.Numeric(16, 5))
    cr_fraispersetparticipation = db.Column(db.Numeric(16, 5))
    cr_dotationsauxamortissements = db.Column(db.Numeric(16, 5))
    cr_resultatexploitavtsurvaleur = db.Column(db.Numeric(16, 5))
    cr_resultatexploitaprsurvaleur = db.Column(db.Numeric(16, 5))
    cr_ebitajusteavantsurvaleur = db.Column(db.Numeric(16, 5))
    cr_chargesfinnets = db.Column(db.Numeric(16, 5))
    cr_autreelementfin = db.Column(db.Numeric(16, 5))
    cr_resultatsmeavantimpot = db.Column(db.Numeric(16, 5))
    cr_resultatexceptavantimpot = db.Column(db.Numeric(16, 5))
    cr_resultatsmeapresimpot = db.Column(db.Numeric(16, 5))
    cr_resultatexceptapresimpot = db.Column(db.Numeric(16, 5))
    cr_impot = db.Column(db.Numeric(16, 5))
    cr_tauxisnormatif = db.Column(db.Numeric(16, 5))
    cr_participationetdivers = db.Column(db.Numeric(16, 5))
    cr_minoritaires = db.Column(db.Numeric(16, 5))
    cr_amortissementsurvaleur = db.Column(db.Numeric(16, 5))
    cr_survaleurdeductible = db.Column(db.Numeric(16, 5))
    cr_partminoritairesdssurvaleur = db.Column(db.Numeric(16, 5))
    cr_bnpdgpublie = db.Column(db.Numeric(16, 5))
    cr_bnpdgajuste = db.Column(db.Numeric(16, 5))
    cr_correctiondvfa = db.Column(db.Numeric(16, 5))
    tf_autresmouvnondecaisses = db.Column(db.Numeric(16, 5))
    tf_varbfr = db.Column(db.Numeric(16, 5))
    tf_dividendesrecusdessme = db.Column(db.Numeric(16, 5))
    tf_impotpaye = db.Column(db.Numeric(16, 5))
    tf_investissementsindustriels = db.Column(db.Numeric(16, 5))
    tf_investissmentsfinanciers = db.Column(db.Numeric(16, 5))
    tf_invfinnonintegres = db.Column(db.Numeric(16, 5))
    tf_cessions = db.Column(db.Numeric(16, 5))
    tf_divers = db.Column(db.Numeric(16, 5))
    tf_augmentationcapital = db.Column(db.Numeric(16, 5))
    tf_sharebuyback = db.Column(db.Numeric(16, 5))
    tf_augcapfilialesconsolidees = db.Column(db.Numeric(16, 5))
    tf_dividendesdecaisses = db.Column(db.Numeric(16, 5))
    tf_dividdecaissesparfiales = db.Column(db.Numeric(16, 5))
    tf_cashflow = db.Column(db.Numeric(16, 5))
    tf_cashflowpdg = db.Column(db.Numeric(16, 5))
    bl_actifscorporelsbruts = db.Column(db.Numeric(16, 5))
    bl_actifscorporelsnets = db.Column(db.Numeric(16, 5))
    bl_actifsincorporelsbruts = db.Column(db.Numeric(16, 5))
    bl_survaleurbrute = db.Column(db.Numeric(16, 5))
    bl_actifsincorporelsnets = db.Column(db.Numeric(16, 5))
    bl_survaleurnette = db.Column(db.Numeric(16, 5))
    bl_actifsoperationnelsnets = db.Column(db.Numeric(16, 5))
    bl_actifsfinanciers = db.Column(db.Numeric(16, 5))
    bl_sme = db.Column(db.Numeric(16, 5))
    bl_stocks = db.Column(db.Numeric(16, 5))
    bl_clients = db.Column(db.Numeric(16, 5))
    bl_autreactifcirculant = db.Column(db.Numeric(16, 5))
    bl_disponibiliteetvmp = db.Column(db.Numeric(16, 5))
    bl_fondsproprestotaux = db.Column(db.Numeric(16, 5))
    bl_fondsproprespdg = db.Column(db.Numeric(16, 5))
    bl_provisions = db.Column(db.Numeric(16, 5))
    bl_provisionsretraites = db.Column(db.Numeric(16, 5))
    bl_dettesfournisseur = db.Column(db.Numeric(16, 5))
    bl_autrepassifcirculant = db.Column(db.Numeric(16, 5))
    bl_dettesfinancieresbrutes = db.Column(db.Numeric(16, 5))
    bl_dettesobligationsconvert = db.Column(db.Numeric(16, 5))
    bl_dettesfinnettesretraitees = db.Column(db.Numeric(16, 5))
    bl_capitauxemployesretraites = db.Column(db.Numeric(16, 5))
    dv_autocontrole = db.Column(db.Numeric(16, 5))
    dv_dividendebrutparaction = db.Column(db.Numeric(16, 5))
    dv_coeffavoirfiscal = db.Column(db.Numeric(16, 5))
    dv_survaleurimputeesurfp = db.Column(db.Numeric(16, 5))
    dv_fondspropresminoreevalues = db.Column(db.Numeric(16, 5))
    dv_smeetactifsfinreevalues = db.Column(db.Numeric(16, 5))
    dv_fraisrecherchedeveloppement = db.Column(db.Numeric(16, 5))
    dv_effectifsmoyens = db.Column(db.Numeric(16, 5))
    dv_effectifsfinannee = db.Column(db.Numeric(16, 5))
    dv_reservecommissairesauxcptes = db.Column(db.Numeric(16, 5))
    excours_moyen = db.Column(db.Numeric(18, 5))
    excycle = db.Column(db.Numeric(1, 0, asdecimal=False))
    exetatexercice = db.Column(db.Numeric(1, 0, asdecimal=False))
    exexercice = db.Column(db.Numeric(7, 2))
    exdevise = db.Column(db.Numeric(8, 0, asdecimal=False))
    exunite = db.Column(
        db.Numeric(8, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    bl_anr = db.Column(db.Numeric(16, 5))
    cr_resultatcourantavantimpot = db.Column(db.Numeric(16, 5))
    bl_bfr = db.Column(db.Numeric(16, 5))
    bl_actifimmobilise = db.Column(db.Numeric(16, 5))
    cr_primesbrutestotales = db.Column(db.Numeric(16, 5))
    cr_primesnonvienette = db.Column(db.Numeric(16, 5))
    cr_primevienette = db.Column(db.Numeric(16, 5))
    cr_pdtplacementassurance = db.Column(db.Numeric(16, 5))
    cr_resavimpotnonvieetfpr = db.Column(db.Numeric(16, 5))
    cr_resavimpotvie = db.Column(db.Numeric(16, 5))
    cr_resavimpotbancaire = db.Column(db.Numeric(16, 5))
    r_expenseratiopctprovtech = db.Column(db.Numeric(16, 5))
    r_fpallouespctproctech = db.Column(db.Numeric(16, 5))
    r_lossratiopctprimesnet = db.Column(db.Numeric(16, 5))
    r_varprovpctprimntdslssratio = db.Column(db.Numeric(16, 5))
    r_expenseratiopctprimenet = db.Column(db.Numeric(16, 5))
    b_coutacquisitiondifferes = db.Column(db.Numeric(16, 5))
    b_placementsassurance = db.Column(db.Numeric(16, 5))
    b_provisiontechniquevie = db.Column(db.Numeric(16, 5))
    b_unitedecomptedsprovtechvie = db.Column(db.Numeric(16, 5))
    b_provisiontechniquenonvie = db.Column(db.Numeric(16, 5))
    b_plusvaluelatenteactionnaire = db.Column(db.Numeric(16, 5))
    b_embvallatenteactionnaire = db.Column(db.Numeric(16, 5))
    b_gestionpourcomptedetiers = db.Column(db.Numeric(16, 5))
    cr_prodchgeholdingnonaffectes = db.Column(db.Numeric(16, 5))
    cr_revenusbancaires = db.Column(db.Numeric(16, 5))
    cr_interetsdsrevenusbancaires = db.Column(db.Numeric(16, 5))
    cr_commissionsdansrevenusbq = db.Column(db.Numeric(16, 5))
    cr_autresrevenusdansrevenusbq = db.Column(db.Numeric(16, 5))
    dv_rentabappaplacementassu = db.Column(db.Numeric(16, 5))
    dv_roeassurance_avantimpot = db.Column(db.Numeric(16, 5))
    dv_roebanque_avantimpot = db.Column(db.Numeric(16, 5))
    dv_coutsrevenusbancaires = db.Column(db.Numeric(16, 5))
    dv_ratiocooketierone = db.Column(db.Numeric(16, 5))
    bl_pretsbaireetactivitemarche = db.Column(db.Numeric(16, 5))
    bl_fondspropresassurance = db.Column(db.Numeric(16, 5))
    bl_depotsempruntsrefinancement = db.Column(db.Numeric(16, 5))
    cr_pnb = db.Column(db.Numeric(16, 5))
    bl_tresorerieactif = db.Column(db.Numeric(16, 5))
    bl_encourspretsclientele = db.Column(db.Numeric(16, 5))
    bl_titre = db.Column(db.Numeric(16, 5))
    bl_tresoreriepassif = db.Column(db.Numeric(16, 5))
    bl_depotsclientele = db.Column(db.Numeric(16, 5))
    bl_dettessubordonnees = db.Column(db.Numeric(16, 5))
    dv_retraites = db.Column(db.Numeric(16, 5))
    dv_stockoption = db.Column(db.Numeric(16, 5))
    dv_prixexercice = db.Column(db.Numeric(16, 5))
    cr_production = db.Column(db.Numeric(16, 5))
    cr_loyers = db.Column(db.Numeric(16, 5))
    cr_loyerssimples = db.Column(db.Numeric(16, 5))
    bl_patrimoine = db.Column(db.Numeric(16, 5))
    bl_creditbail = db.Column(db.Numeric(16, 5))
    bl_valpatrimoine = db.Column(db.Numeric(16, 5))
    bl_valcreditbail = db.Column(db.Numeric(16, 5))
    cr_chargesexploitation = db.Column(db.Numeric(16, 5))
    cr_resultatfinancier = db.Column(db.Numeric(16, 5))
    tf_cashflowoperationnel = db.Column(db.Numeric(16, 5))
    tf_travauxcourants = db.Column(db.Numeric(16, 5))
    bl_reservereevaluation = db.Column(db.Numeric(16, 5))
    bl_dividendesdecaissesbilan = db.Column(db.Numeric(16, 5))
    cr_impotsurexceptionnel = db.Column(db.Numeric(16, 5))
    excours_min = db.Column(db.Numeric(18, 5))
    excours_max = db.Column(db.Numeric(18, 5))
    exdateca1 = db.Column(db.DateTime)
    exdateca2 = db.Column(db.DateTime)
    exdateca3 = db.Column(db.DateTime)
    exdateca4 = db.Column(db.DateTime)
    exdatebn1 = db.Column(db.DateTime)
    exdatebn2 = db.Column(db.DateTime)
    exdatebn3 = db.Column(db.DateTime)
    exdatebn4 = db.Column(db.DateTime)
    exdateag = db.Column(db.DateTime)
    exdatesfaf = db.Column(db.DateTime)
    bl_interetsminoritaires = db.Column(db.Numeric(16, 5))
    tf_vnccessions = db.Column(db.Numeric(16, 5))
    exdateca1_2 = db.Column(db.DateTime)
    exdateca2_2 = db.Column(db.DateTime)
    exdateca3_2 = db.Column(db.DateTime)
    exdateca4_2 = db.Column(db.DateTime)
    exdateag_2 = db.Column(db.DateTime)
    exdatesfaf_2 = db.Column(db.DateTime)
    exdatebn1_2 = db.Column(db.DateTime)
    exdatebn2_2 = db.Column(db.DateTime)
    exdatebn3_2 = db.Column(db.DateTime)
    exdatebn4_2 = db.Column(db.DateTime)
    dv_champlibre1 = db.Column(db.Numeric(18, 5))
    dv_champlibre2 = db.Column(db.Numeric(18, 5))
    dv_champlibre3 = db.Column(db.Numeric(18, 5))
    bl_creancesdouteusesfinannee = db.Column(db.Numeric(16, 5))
    bl_tauxdecouverturecreandout = db.Column(db.Numeric(16, 5))
    bl_plusvalueslapresimpots = db.Column(db.Numeric(16, 5))
    bl_actionsdepreference = db.Column(db.Numeric(16, 5))
    bl_fondspropresallouesbgi = db.Column(db.Numeric(16, 5))
    bl_fondspropresallouesbgros = db.Column(db.Numeric(16, 5))
    bl_fondspropresallouesbinvest = db.Column(db.Numeric(16, 5))
    bl_autresallocfondspropres = db.Column(db.Numeric(16, 5))
    bl_fondspropresallouesbdetail = db.Column(db.Numeric(16, 5))
    dv_valobanquededetail = db.Column(db.Numeric(16, 5))
    dv_valoprivbanketgestactifs = db.Column(db.Numeric(16, 5))
    dv_valobanquedegros = db.Column(db.Numeric(16, 5))
    dv_valobanqueinvestissement = db.Column(db.Numeric(16, 5))
    dv_plusvaluelsurparticipation = db.Column(db.Numeric(16, 5))
    dv_autresetajustements = db.Column(db.Numeric(16, 5))
    dv_valobanquedegrosetinvest = db.Column(db.Numeric(16, 5))
    dv_totalvaloparparties = db.Column(db.Numeric(16, 5))
    cr_margeinteret = db.Column(db.Numeric(16, 5))
    cr_commissions = db.Column(db.Numeric(16, 5))
    cr_trading = db.Column(db.Numeric(16, 5))
    dv_champlibre4 = db.Column(db.Numeric(18, 5))
    dv_champlibre5 = db.Column(db.Numeric(18, 5))
    dv_champlibre6 = db.Column(db.Numeric(18, 5))
    dv_champlibre7 = db.Column(db.Numeric(18, 5))
    dv_champlibre8 = db.Column(db.Numeric(18, 5))
    dv_champlibre9 = db.Column(db.Numeric(18, 5))
    dv_champlibre10 = db.Column(db.Numeric(18, 5))
    tf_investissementmaintenance = db.Column(db.Numeric(16, 5))
    tf_vncacqetdettesnettesacq = db.Column(db.Numeric(16, 5))
    cr_croissanceorganique = db.Column(db.Numeric(16, 5))
    bl_bfrsocietesacquises = db.Column(db.Numeric(16, 5))
    dv_bpapublie = db.Column(db.Numeric(16, 5))

    afsociete = db.relationship(
        "Afsociete",
        primaryjoin="Afexercice.excfin == Afsociete.socfin",
        backref="afexercices",
    )


class Afexercicessave(db.Model):
    __tablename__ = "afexercicessave"
    __table_args__ = {"schema": "analyse"}

    excfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    exfinexercice = db.Column(db.DateTime, primary_key=True, nullable=False)
    cr_ca = db.Column(db.Numeric(16, 5))
    cr_autresproduits = db.Column(db.Numeric(16, 5))
    cr_fraispersetparticipation = db.Column(db.Numeric(16, 5))
    cr_dotationsauxamortissements = db.Column(db.Numeric(16, 5))
    cr_resultatexploitavtsurvaleur = db.Column(db.Numeric(16, 5))
    cr_resultatexploitaprsurvaleur = db.Column(db.Numeric(16, 5))
    cr_ebitajusteavantsurvaleur = db.Column(db.Numeric(16, 5))
    cr_chargesfinnets = db.Column(db.Numeric(16, 5))
    cr_autreelementfin = db.Column(db.Numeric(16, 5))
    cr_resultatsmeavantimpot = db.Column(db.Numeric(16, 5))
    cr_resultatexceptavantimpot = db.Column(db.Numeric(16, 5))
    cr_resultatsmeapresimpot = db.Column(db.Numeric(16, 5))
    cr_resultatexceptapresimpot = db.Column(db.Numeric(16, 5))
    cr_impot = db.Column(db.Numeric(16, 5))
    cr_tauxisnormatif = db.Column(db.Numeric(16, 5))
    cr_participationetdivers = db.Column(db.Numeric(16, 5))
    cr_minoritaires = db.Column(db.Numeric(16, 5))
    cr_amortissementsurvaleur = db.Column(db.Numeric(16, 5))
    cr_survaleurdeductible = db.Column(db.Numeric(16, 5))
    cr_partminoritairesdssurvaleur = db.Column(db.Numeric(16, 5))
    cr_bnpdgpublie = db.Column(db.Numeric(16, 5))
    cr_bnpdgajuste = db.Column(db.Numeric(16, 5))
    cr_correctiondvfa = db.Column(db.Numeric(16, 5))
    tf_autresmouvnondecaisses = db.Column(db.Numeric(16, 5))
    tf_varbfr = db.Column(db.Numeric(16, 5))
    tf_dividendesrecusdessme = db.Column(db.Numeric(16, 5))
    tf_impotpaye = db.Column(db.Numeric(16, 5))
    tf_investissementsindustriels = db.Column(db.Numeric(16, 5))
    tf_investissmentsfinanciers = db.Column(db.Numeric(16, 5))
    tf_invfinnonintegres = db.Column(db.Numeric(16, 5))
    tf_cessions = db.Column(db.Numeric(16, 5))
    tf_divers = db.Column(db.Numeric(16, 5))
    tf_augmentationcapital = db.Column(db.Numeric(16, 5))
    tf_sharebuyback = db.Column(db.Numeric(16, 5))
    tf_augcapfilialesconsolidees = db.Column(db.Numeric(16, 5))
    tf_dividendesdecaisses = db.Column(db.Numeric(16, 5))
    tf_dividdecaissesparfiales = db.Column(db.Numeric(16, 5))
    tf_cashflow = db.Column(db.Numeric(16, 5))
    tf_cashflowpdg = db.Column(db.Numeric(16, 5))
    bl_actifscorporelsbruts = db.Column(db.Numeric(16, 5))
    bl_actifscorporelsnets = db.Column(db.Numeric(16, 5))
    bl_actifsincorporelsbruts = db.Column(db.Numeric(16, 5))
    bl_survaleurbrute = db.Column(db.Numeric(16, 5))
    bl_actifsincorporelsnets = db.Column(db.Numeric(16, 5))
    bl_survaleurnette = db.Column(db.Numeric(16, 5))
    bl_actifsoperationnelsnets = db.Column(db.Numeric(16, 5))
    bl_actifsfinanciers = db.Column(db.Numeric(16, 5))
    bl_sme = db.Column(db.Numeric(16, 5))
    bl_stocks = db.Column(db.Numeric(16, 5))
    bl_clients = db.Column(db.Numeric(16, 5))
    bl_autreactifcirculant = db.Column(db.Numeric(16, 5))
    bl_disponibiliteetvmp = db.Column(db.Numeric(16, 5))
    bl_fondsproprestotaux = db.Column(db.Numeric(16, 5))
    bl_fondsproprespdg = db.Column(db.Numeric(16, 5))
    bl_provisions = db.Column(db.Numeric(16, 5))
    bl_provisionsretraites = db.Column(db.Numeric(16, 5))
    bl_dettesfournisseur = db.Column(db.Numeric(16, 5))
    bl_autrepassifcirculant = db.Column(db.Numeric(16, 5))
    bl_dettesfinancieresbrutes = db.Column(db.Numeric(16, 5))
    bl_dettesobligationsconvert = db.Column(db.Numeric(16, 5))
    bl_dettesfinnettesretraitees = db.Column(db.Numeric(16, 5))
    bl_capitauxemployesretraites = db.Column(db.Numeric(16, 5))
    dv_autocontrole = db.Column(db.Numeric(16, 5))
    dv_dividendebrutparaction = db.Column(db.Numeric(16, 5))
    dv_coeffavoirfiscal = db.Column(db.Numeric(16, 5))
    dv_survaleurimputeesurfp = db.Column(db.Numeric(16, 5))
    dv_fondspropresminoreevalues = db.Column(db.Numeric(16, 5))
    dv_smeetactifsfinreevalues = db.Column(db.Numeric(16, 5))
    dv_fraisrecherchedeveloppement = db.Column(db.Numeric(16, 5))
    dv_effectifsmoyens = db.Column(db.Numeric(16, 5))
    dv_effectifsfinannee = db.Column(db.Numeric(16, 5))
    dv_reservecommissairesauxcptes = db.Column(db.Numeric(16, 5))
    excours_moyen = db.Column(db.Numeric(18, 5))
    excycle = db.Column(db.Numeric(1, 0, asdecimal=False))
    exetatexercice = db.Column(db.Numeric(1, 0, asdecimal=False))
    exexercice = db.Column(db.Numeric(7, 2))
    exdevise = db.Column(db.Numeric(8, 0, asdecimal=False))
    exunite = db.Column(
        db.Numeric(8, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    bl_anr = db.Column(db.Numeric(16, 5))
    cr_resultatcourantavantimpot = db.Column(db.Numeric(16, 5))
    bl_bfr = db.Column(db.Numeric(16, 5))
    bl_actifimmobilise = db.Column(db.Numeric(16, 5))
    cr_primesbrutestotales = db.Column(db.Numeric(16, 5))
    cr_primesnonvienette = db.Column(db.Numeric(16, 5))
    cr_primevienette = db.Column(db.Numeric(16, 5))
    cr_pdtplacementassurance = db.Column(db.Numeric(16, 5))
    cr_resavimpotnonvieetfpr = db.Column(db.Numeric(16, 5))
    cr_resavimpotvie = db.Column(db.Numeric(16, 5))
    cr_resavimpotbancaire = db.Column(db.Numeric(16, 5))
    r_expenseratiopctprovtech = db.Column(db.Numeric(16, 5))
    r_fpallouespctproctech = db.Column(db.Numeric(16, 5))
    r_lossratiopctprimesnet = db.Column(db.Numeric(16, 5))
    r_varprovpctprimntdslssratio = db.Column(db.Numeric(16, 5))
    r_expenseratiopctprimenet = db.Column(db.Numeric(16, 5))
    b_coutacquisitiondifferes = db.Column(db.Numeric(16, 5))
    b_placementsassurance = db.Column(db.Numeric(16, 5))
    b_provisiontechniquevie = db.Column(db.Numeric(16, 5))
    b_unitedecomptedsprovtechvie = db.Column(db.Numeric(16, 5))
    b_provisiontechniquenonvie = db.Column(db.Numeric(16, 5))
    b_plusvaluelatenteactionnaire = db.Column(db.Numeric(16, 5))
    b_embvallatenteactionnaire = db.Column(db.Numeric(16, 5))
    b_gestionpourcomptedetiers = db.Column(db.Numeric(16, 5))
    cr_prodchgeholdingnonaffectes = db.Column(db.Numeric(16, 5))
    cr_revenusbancaires = db.Column(db.Numeric(16, 5))
    cr_interetsdsrevenusbancaires = db.Column(db.Numeric(16, 5))
    cr_commissionsdansrevenusbq = db.Column(db.Numeric(16, 5))
    cr_autresrevenusdansrevenusbq = db.Column(db.Numeric(16, 5))
    dv_rentabappaplacementassu = db.Column(db.Numeric(16, 5))
    dv_roeassurance_avantimpot = db.Column(db.Numeric(16, 5))
    dv_roebanque_avantimpot = db.Column(db.Numeric(16, 5))
    dv_coutsrevenusbancaires = db.Column(db.Numeric(16, 5))
    dv_ratiocooketierone = db.Column(db.Numeric(16, 5))
    bl_pretsbaireetactivitemarche = db.Column(db.Numeric(16, 5))
    bl_fondspropresassurance = db.Column(db.Numeric(16, 5))
    bl_depotsempruntsrefinancement = db.Column(db.Numeric(16, 5))
    cr_pnb = db.Column(db.Numeric(16, 5))
    bl_tresorerieactif = db.Column(db.Numeric(16, 5))
    bl_encourspretsclientele = db.Column(db.Numeric(16, 5))
    bl_titre = db.Column(db.Numeric(16, 5))
    bl_tresoreriepassif = db.Column(db.Numeric(16, 5))
    bl_depotsclientele = db.Column(db.Numeric(16, 5))
    bl_dettessubordonnees = db.Column(db.Numeric(16, 5))
    dv_retraites = db.Column(db.Numeric(16, 5))
    dv_stockoption = db.Column(db.Numeric(16, 5))
    dv_prixexercice = db.Column(db.Numeric(16, 5))
    cr_production = db.Column(db.Numeric(16, 5))
    cr_loyers = db.Column(db.Numeric(16, 5))
    cr_loyerssimples = db.Column(db.Numeric(16, 5))
    bl_patrimoine = db.Column(db.Numeric(16, 5))
    bl_creditbail = db.Column(db.Numeric(16, 5))
    bl_valpatrimoine = db.Column(db.Numeric(16, 5))
    bl_valcreditbail = db.Column(db.Numeric(16, 5))
    cr_chargesexploitation = db.Column(db.Numeric(16, 5))
    cr_resultatfinancier = db.Column(db.Numeric(16, 5))
    tf_cashflowoperationnel = db.Column(db.Numeric(16, 5))
    tf_travauxcourants = db.Column(db.Numeric(16, 5))
    bl_reservereevaluation = db.Column(db.Numeric(16, 5))
    bl_dividendesdecaissesbilan = db.Column(db.Numeric(16, 5))
    cr_impotsurexceptionnel = db.Column(db.Numeric(16, 5))
    excours_min = db.Column(db.Numeric(18, 5))
    excours_max = db.Column(db.Numeric(18, 5))
    exdateca1 = db.Column(db.DateTime)
    exdateca2 = db.Column(db.DateTime)
    exdateca3 = db.Column(db.DateTime)
    exdateca4 = db.Column(db.DateTime)
    exdatebn1 = db.Column(db.DateTime)
    exdatebn2 = db.Column(db.DateTime)
    exdatebn3 = db.Column(db.DateTime)
    exdatebn4 = db.Column(db.DateTime)
    exdateag = db.Column(db.DateTime)
    exdatesfaf = db.Column(db.DateTime)
    bl_interetsminoritaires = db.Column(db.Numeric(16, 5))
    tf_vnccessions = db.Column(db.Numeric(16, 5))
    exdateca1_2 = db.Column(db.DateTime)
    exdateca2_2 = db.Column(db.DateTime)
    exdateca3_2 = db.Column(db.DateTime)
    exdateca4_2 = db.Column(db.DateTime)
    exdateag_2 = db.Column(db.DateTime)
    exdatesfaf_2 = db.Column(db.DateTime)
    exdatebn1_2 = db.Column(db.DateTime)
    exdatebn2_2 = db.Column(db.DateTime)
    exdatebn3_2 = db.Column(db.DateTime)
    exdatebn4_2 = db.Column(db.DateTime)
    dv_champlibre1 = db.Column(db.Numeric(18, 5))
    dv_champlibre2 = db.Column(db.Numeric(18, 5))
    dv_champlibre3 = db.Column(db.Numeric(18, 5))
    bl_creancesdouteusesfinannee = db.Column(db.Numeric(16, 5))
    bl_tauxdecouverturecreandout = db.Column(db.Numeric(16, 5))
    bl_plusvalueslapresimpots = db.Column(db.Numeric(16, 5))
    bl_actionsdepreference = db.Column(db.Numeric(16, 5))
    bl_fondspropresallouesbgi = db.Column(db.Numeric(16, 5))
    bl_fondspropresallouesbgros = db.Column(db.Numeric(16, 5))
    bl_fondspropresallouesbinvest = db.Column(db.Numeric(16, 5))
    bl_autresallocfondspropres = db.Column(db.Numeric(16, 5))
    bl_fondspropresallouesbdetail = db.Column(db.Numeric(16, 5))
    dv_valobanquededetail = db.Column(db.Numeric(16, 5))
    dv_valoprivbanketgestactifs = db.Column(db.Numeric(16, 5))
    dv_valobanquedegros = db.Column(db.Numeric(16, 5))
    dv_valobanqueinvestissement = db.Column(db.Numeric(16, 5))
    dv_plusvaluelsurparticipation = db.Column(db.Numeric(16, 5))
    dv_autresetajustements = db.Column(db.Numeric(16, 5))
    dv_valobanquedegrosetinvest = db.Column(db.Numeric(16, 5))
    dv_totalvaloparparties = db.Column(db.Numeric(16, 5))
    cr_margeinteret = db.Column(db.Numeric(16, 5))
    cr_commissions = db.Column(db.Numeric(16, 5))
    cr_trading = db.Column(db.Numeric(16, 5))
    dv_champlibre4 = db.Column(db.Numeric(18, 5))
    dv_champlibre5 = db.Column(db.Numeric(18, 5))
    dv_champlibre6 = db.Column(db.Numeric(18, 5))
    dv_champlibre7 = db.Column(db.Numeric(18, 5))
    dv_champlibre8 = db.Column(db.Numeric(18, 5))
    dv_champlibre9 = db.Column(db.Numeric(18, 5))
    dv_champlibre10 = db.Column(db.Numeric(18, 5))
    tf_investissementmaintenance = db.Column(db.Numeric(16, 5))
    tf_vncacqetdettesnettesacq = db.Column(db.Numeric(16, 5))
    cr_croissanceorganique = db.Column(db.Numeric(16, 5))
    bl_bfrsocietesacquises = db.Column(db.Numeric(16, 5))
    dv_bpapublie = db.Column(db.Numeric(16, 5))


class Afexercicessplit(db.Model):
    __tablename__ = "afexercicessplit"
    __table_args__ = {"schema": "analyse"}

    escfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    esfinexercice = db.Column(db.DateTime, primary_key=True, nullable=False)
    esfonction = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    estypesplit = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    esvaleur = db.Column(db.Numeric(16, 5))


class Afgraphessake(db.Model):
    __tablename__ = "afgraphessake"
    __table_args__ = {"schema": "analyse"}

    gscfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="cfin dela societe",
    )
    gsgraphe = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="numero du graphe",
    )
    gsattribut = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="type de l attribut 0->titre 1-1000->chiffre",
    )
    gsvalue = db.Column(db.Numeric(9, 3), info="valeur de l attribut")
    gslibfr = db.Column(db.String(50), info="libelle fr")
    gslibuk = db.Column(db.String(50), info="libelle uk")


class Afgrillessecteur(db.Model):
    __tablename__ = "afgrillessecteurs"
    __table_args__ = {"schema": "analyse"}

    gscode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    gsnomfr = db.Column(db.String(40))
    gsnomgb = db.Column(db.String(40))
    gsdevise = db.Column(db.Numeric(8, 0, asdecimal=False))
    gssecteur = db.Column(db.Numeric(8, 0, asdecimal=False))
    gscodeds = db.Column(db.String(40))
    gsindice = db.Column(db.Numeric(8, 0, asdecimal=False))
    gstypegrille = db.Column(db.Numeric(8, 0, asdecimal=False))
    gslibellerelfr = db.Column(db.String(40))
    gslibellerelgb = db.Column(db.String(40))
    gsparamnotederisque = db.Column(db.Numeric(1, 0, asdecimal=False))


class Afhistocourssecteur(db.Model):
    __tablename__ = "afhistocourssecteur"
    __table_args__ = {"schema": "analyse"}

    hscfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hsdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hsclose = db.Column(db.Numeric(13, 5))
    hsdatemodif = db.Column(db.DateTime)
    hscloseri = db.Column(db.Numeric(13, 5), info="Cours avec dividende reinvesti")


class Afhistoindicateurv(db.Model):
    __tablename__ = "afhistoindicateurv"
    __table_args__ = {"schema": "analyse"}

    ivcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ivspread = db.Column(db.Numeric(8, 4))
    ivmaturiteoption = db.Column(db.DateTime)
    ivvol = db.Column(db.Numeric(5, 2))
    ivtauxrecovery = db.Column(db.Numeric(5, 2))
    ivprobafaillite = db.Column(db.Numeric(6, 2))
    ivprobavol = db.Column(db.Numeric(6, 2))
    ivproba = db.Column(db.Numeric(6, 2))
    ivindicateur = db.Column(db.String(2))
    ivdatemaj = db.Column(db.DateTime, nullable=False)
    ivdate = db.Column(db.DateTime, primary_key=True, nullable=False)


class Afhistonouvellenotederisque(db.Model):
    __tablename__ = "afhistonouvellenotederisque"
    __table_args__ = {"schema": "analyse"}

    nrcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    nrdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    nrvolatiliteabsolue = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrvolatilitenormee = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrvolatilitedebrayee = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrdispersionconsensus12m = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrdispersionnormee = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrdispersiondebrayee = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrcyclicite = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrcyclicitenormee = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrcyclicitedebrayee = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrecarttypemargeebitda = db.Column(db.Numeric(4, 2))
    nrmargeebitda12mois = db.Column(db.Numeric(4, 2))
    nrincertitudeabsolue = db.Column(db.Numeric(2, 0, asdecimal=False))
    nrincertitudenormee = db.Column(db.Numeric(2, 0, asdecimal=False))
    nrincertitudedebrayee = db.Column(db.Numeric(2, 0, asdecimal=False))
    nrecarttypeebitdaparbroker = db.Column(db.Numeric(4, 2))
    nrcroiebitdaparbrokermedian = db.Column(db.Numeric(4, 2))
    nrratiocashconversionperiode = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrratiocashconversionnormee = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrratiocashcoversiondebrayee = db.Column(db.Numeric(4, 0, asdecimal=False))
    nretcashconvebitdaencfdopborne = db.Column(db.Numeric(4, 2))
    nrmdcashconvebitdaencfdopborne = db.Column(db.Numeric(4, 2))
    nrnoteoperationnelle = db.Column(db.Numeric(6, 2))
    nrnoteoperationnelledebrayee = db.Column(db.Numeric(6, 2))
    nrlevierfinancier = db.Column(db.Numeric(6, 2))
    nrlevierfinancierdebraye = db.Column(db.Numeric(4, 2))
    nrfacteurajustementsf = db.Column(db.Numeric(4, 2))
    nrfacteurajustementsfdebraye = db.Column(db.Numeric(4, 2))
    nrtauxisnormatif12mois = db.Column(db.Numeric(4, 2))
    nrtauxisdebraye = db.Column(db.Numeric(4, 2))
    nrnoteoprajusteenormee = db.Column(db.Numeric(4, 2))
    nrnoteoprajusteedebrayeenormee = db.Column(db.Numeric(4, 2))
    nrnotefinale = db.Column(db.Numeric(4, 2))
    datemaj = db.Column(db.DateTime, nullable=False)


class Afhistoobjectifcour(db.Model):
    __tablename__ = "afhistoobjectifcours"
    __table_args__ = {"schema": "analyse"}

    occfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ocdatemodif = db.Column(db.DateTime, primary_key=True, nullable=False)
    ocobjectif = db.Column(db.Numeric(13, 5))
    socoeff = db.Column(db.Numeric(10, 6), server_default=db.FetchedValue())
    ocupside = db.Column(
        db.Numeric(13, 5),
        info="Upside du cours par rapport à la valeur en base centrale",
    )
    octypehisto = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        server_default=db.FetchedValue(),
        info="Type d'historique: 0 = Objectif cours 1 ans, 1 = Objectif de cours 2 ans",
    )
    ocdateraz = db.Column(
        db.DateTime, info="Date de mise à zero de l'objectif de cours"
    )
    ocdatediffusion = db.Column(
        db.DateTime,
        info="Date de diffusion du changement (= toujours J + heure de diffusion)  ",
    )
    ocobjectifmin = db.Column(db.Numeric(18, 6), info="Dernier TP Min contribue")
    ocupsidemin = db.Column(db.Numeric(18, 6), info="Dernier Upside Min contribue")
    ocdaterazmin = db.Column(db.DateTime, info="Date de mise à vide du TP Min")
    ocobjectifmax = db.Column(db.Numeric(18, 6), info="Dernier TP Max contribue")
    ocupsidemax = db.Column(db.Numeric(18, 6), info="Dernier Upside Max contribue")
    ocdaterazmax = db.Column(db.DateTime, info="Date de mise à vide du TP Max")


class Afhistoopinionsecteur(db.Model):
    __tablename__ = "afhistoopinionsecteur"
    __table_args__ = (
        db.CheckConstraint("HOSNEWOPINION IN (0, 1, 2, 4, 8)"),
        db.CheckConstraint("HOSOLDOPINION IN (0, 1, 2, 4, 8)"),
        {"schema": "analyse"},
    )

    hoscfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hosdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hosoldopinion = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    hosnewopinion = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )


class Afhistoopinionvaleur(db.Model):
    __tablename__ = "afhistoopinionvaleur"
    __table_args__ = (
        db.CheckConstraint("HOVNEWOPINION IN (0, 1, 2, 4, 8)"),
        db.CheckConstraint("HOVOLDOPINION IN (0, 1, 2, 4, 8)"),
        {"schema": "analyse"},
    )

    hovcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hovdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hovoldopinion = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    hovnewopinion = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    hoperfabs = db.Column(db.Numeric(10, 3))
    hovdatediffusion = db.Column(
        db.DateTime,
        info="Date de diffusion du changement (= toujours J + heure de diffusion)  ",
    )


class Afhistoperfechant(db.Model):
    __tablename__ = "afhistoperfechant"
    __table_args__ = {"schema": "analyse"}

    hpcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    hpdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    hpperfeqpd = db.Column(db.Numeric(12, 4))
    hpperfeqpddivreinv = db.Column(db.Numeric(12, 4))
    hpperfpf = db.Column(db.Numeric(12, 4))
    hpperfpfdivreinv = db.Column(db.Numeric(12, 4))
    hpdatemaj = db.Column(db.DateTime, nullable=False)


class Afhistosecteurcalc(db.Model):
    __tablename__ = "afhistosecteurcalc"
    __table_args__ = {"schema": "analyse"}

    sccfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    scdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    sctypepond = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    scvalsect = db.Column(db.Numeric(14, 5))
    scvalsectbig = db.Column(db.Numeric(14, 5))
    scvalsectmid = db.Column(db.Numeric(14, 5))
    scvalreco = db.Column(db.Numeric(14, 5))
    scvalrecobig = db.Column(db.Numeric(14, 5))
    scvalrecomid = db.Column(db.Numeric(14, 5))
    scdatemaj = db.Column(db.DateTime)


class Afhistostratsecteur(db.Model):
    __tablename__ = "afhistostratsecteur"
    __table_args__ = (
        db.Index("idx_afhistostratsecteur", "sscfin", "ssdate"),
        {"schema": "analyse"},
    )

    sscfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    ssdate = db.Column(db.DateTime)
    sstypedata = db.Column(db.Numeric(1, 0, asdecimal=False))
    ssvaleur = db.Column(db.Numeric(14, 5))


class Afhistotaux(db.Model):
    __tablename__ = "afhistotaux"
    __table_args__ = {"schema": "analyse"}

    htcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    htdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    httauxmoyenmensuel = db.Column(db.Numeric(10, 5))


class Afhistotauxreference(db.Model):
    __tablename__ = "afhistotauxreference"
    __table_args__ = {"schema": "analyse"}

    htrdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    htrcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    htrtauxmm = db.Column(db.Numeric(10, 5))
    htrtauxanafi = db.Column(db.Numeric(10, 5))
    htrtauxannuel = db.Column(db.Numeric(10, 5))
    htrtauxannuelajuste = db.Column(db.Numeric(10, 5))
    htrtauxtrim = db.Column(db.Numeric(10, 5))
    htrtauxtrimajuste = db.Column(db.Numeric(10, 5))
    htrspot = db.Column(db.Numeric(10, 5))
    htrdateveriftaux = db.Column(db.DateTime, nullable=False)
    htrdatemaj = db.Column(db.DateTime, nullable=False)


class Afibe(db.Model):
    __tablename__ = "afibes"
    __table_args__ = {"schema": "analyse"}

    ibcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ibdateend = db.Column(db.DateTime, primary_key=True, nullable=False)
    ibtypevalue = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ibcv = db.Column(db.Numeric(10, 0, asdecimal=False))
    ibest = db.Column(db.Numeric(3, 0, asdecimal=False))
    ibmn = db.Column(db.Numeric(16, 5))
    ibhi = db.Column(db.Numeric(16, 5))
    iblo = db.Column(db.Numeric(16, 5))
    ibmn1m = db.Column(db.Numeric(16, 5))
    ibmn3m = db.Column(db.Numeric(16, 5))
    ibvalue = db.Column(db.Numeric(16, 5))
    ibrfmn = db.Column(db.Numeric(16, 5))
    ibdevise = db.Column(db.Numeric(8, 0, asdecimal=False))
    ibdatemaj = db.Column(db.DateTime)


class AfibesFirstcall(db.Model):
    __tablename__ = "afibes_firstcall"
    __table_args__ = {"schema": "analyse"}

    ibcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ibdateend = db.Column(db.DateTime, primary_key=True, nullable=False)
    ibtypevalue = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ibcv = db.Column(db.Numeric(16, 5))
    ibest = db.Column(db.Numeric(3, 0, asdecimal=False))
    ibmn = db.Column(db.Numeric(16, 5))
    ibhi = db.Column(db.Numeric(16, 5))
    iblo = db.Column(db.Numeric(16, 5))
    ibmn1m = db.Column(db.Numeric(16, 5))
    ibmn3m = db.Column(db.Numeric(16, 5))
    ibvalue = db.Column(db.Numeric(16, 5))
    ibrfmn = db.Column(db.Numeric(16, 5))
    ibdevise = db.Column(db.Numeric(8, 0, asdecimal=False))
    ibdatemaj = db.Column(db.DateTime)
    ibstddev = db.Column(db.Numeric(16, 5))
    ibstddev1m = db.Column(db.Numeric(16, 5))
    ibstddev3m = db.Column(db.Numeric(16, 5))


class Afideesforte(db.Model):
    __tablename__ = "afideesfortes"
    __table_args__ = {"schema": "analyse"}

    ifcode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    ifcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    ifcoach = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    ifsource = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    ifrefdocentree = db.Column(db.String(200))
    ifrefdocsortie = db.Column(db.String(200))
    ifdatecreation = db.Column(db.DateTime, nullable=False)
    ifrefdocpres = db.Column(
        db.String(200), info="Presentation Document of the company"
    )
    ifcomment = db.Column(db.String(2000))


class Afindicateurstechnique(db.Model):
    __tablename__ = "afindicateurstechniques"
    __table_args__ = {"schema": "analyse"}

    itcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    itdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    itcode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    itvaleur = db.Column(db.Numeric(15, 4))
    itdatemaj = db.Column(db.DateTime, nullable=False)


class Afindicateurv(db.Model):
    __tablename__ = "afindicateurv"
    __table_args__ = {"schema": "analyse"}

    ivcfin = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    ivspread = db.Column(db.Numeric(8, 4))
    ivmaturiteoption = db.Column(db.DateTime)
    ivvol = db.Column(db.Numeric(5, 2))
    ivtauxrecovery = db.Column(db.Numeric(5, 2))
    ivprobafaillite = db.Column(db.Numeric(6, 2))
    ivprobavol = db.Column(db.Numeric(6, 2))
    ivproba = db.Column(db.Numeric(6, 2))
    ivindicateur = db.Column(db.String(2))
    ivdatemaj = db.Column(db.DateTime, nullable=False)
    ivtyperecovery = db.Column(db.String(2))
    ivtypevol = db.Column(db.String(2))
    ivtypespread = db.Column(db.String(2))


class Afindicespay(db.Model):
    __tablename__ = "afindicespays"
    __table_args__ = (
        db.CheckConstraint("INBIGMID BETWEEN 0 AND 3"),
        db.CheckConstraint("INBIGMID BETWEEN 0 AND 3"),
        {"schema": "analyse"},
    )

    inpays = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code du pays/zone",
    )
    inindice = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Indice suivi",
    )
    inbigmid = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Drapeau indicateur Big cap 1 ou Mid cap 2, 3 pour les 2",
    )
    innom = db.Column(db.String(80), info="Nom de l'indice ( format analyse)")
    incap = db.Column(db.Numeric(8, 3))
    intypepond = db.Column(db.Numeric(2, 0, asdecimal=False))
    inrefmsci = db.Column(db.Numeric(8, 0, asdecimal=False), info="Ref MSCI for index")
    infixedpayscode = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code du pays associé à un indice"
    )
    inriskratecfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Cfin instrument risk rate pour allocation",
    )


class Afindvolstat(db.Model):
    __tablename__ = "afindvolstat"
    __table_args__ = {"schema": "analyse"}

    ivcfin = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    ivvolmin = db.Column(db.Numeric(7, 4))
    ivvolmax = db.Column(db.Numeric(7, 4))
    ivvolmoy = db.Column(db.Numeric(7, 4))
    ivmaj = db.Column(db.DateTime)


class AfinvestmentListWeight(db.Model):
    __tablename__ = "afinvestment_list_weights"
    __table_args__ = {"schema": "analyse"}

    list_id = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Id de la liste",
    )
    cfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Cfin du sous jacent",
    )
    isin = db.Column(db.String(100), nullable=False, info="ISIN du sous jacent")
    sedol = db.Column(db.String(100), nullable=False, info="SEDOL du sous jacent")
    weight = db.Column(
        db.Numeric(10, 7), nullable=False, info="Poids du sous jacent dans la liste"
    )
    golivedate = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Date de golive des poids + composition",
    )


class Aflistecfincodif(db.Model):
    __tablename__ = "aflistecfincodif"
    __table_args__ = {"schema": "analyse"}

    lccfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    lctypecodif = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    lccodeexterne = db.Column(db.String(30), primary_key=True, nullable=False)


class Afliste(db.Model):
    __tablename__ = "aflistes"
    __table_args__ = {"schema": "analyse"}

    licode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Code de la liste"
    )
    liuser = db.Column(db.Numeric(3, 0, asdecimal=False), info="Code de l'utilisateur")
    lilibellefr = db.Column(db.String(40), info="Descriptif de la liste")
    lilibellegb = db.Column(db.String(40))
    litypesociete = db.Column(db.Numeric(8, 0, asdecimal=False), info="Type de secteur")
    litypegrille = db.Column(db.Numeric(3, 0, asdecimal=False))
    liordre = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="ordre d'affichage de la liste dans l'ihm Sake",
    )


class Aflistesclassement(db.Model):
    __tablename__ = "aflistesclassement"
    __table_args__ = {"schema": "analyse"}

    lccode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    lclibellefr = db.Column(db.String(80))
    lclibellegb = db.Column(db.String(80))
    lcindicateur = db.Column(db.Numeric(8, 0, asdecimal=False))
    lctypesociete = db.Column(db.Numeric(8, 0, asdecimal=False))
    lctyperatio = db.Column(db.Numeric(1, 0, asdecimal=False))
    lcfonctionexeousoc = db.Column(db.Numeric(1, 0, asdecimal=False))


class Afnotegraham(db.Model):
    __tablename__ = "afnotegraham"
    __table_args__ = (
        db.CheckConstraint("(NGCFIN IS NOT NULL) AND (NGDATE IS NOT NULL)"),
        db.CheckConstraint("(NGCFIN IS NOT NULL) AND (NGDATE IS NOT NULL)"),
        {"schema": "analyse"},
    )

    ngcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    ngdate = db.Column(db.DateTime)
    ngcriterepe = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngcriterepesurpanpa = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngcriterevecesurrocewacc = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngnotevalorisationabs = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngcriteredettesvscapi = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngcriteredettesvsbfr = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngcriterecouvfinan = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngnotesolvabiliteabs = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngcriteredividendes = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngcriterebn = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngnotestabiliteabs = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngnoteabsolue = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngdatemaj = db.Column(db.DateTime)


class Afnotegrahamhisto(db.Model):
    __tablename__ = "afnotegrahamhisto"
    __table_args__ = (
        db.CheckConstraint("(NGCFIN IS NOT NULL) AND (NGDATE IS NOT NULL)"),
        db.CheckConstraint("(NGCFIN IS NOT NULL) AND (NGDATE IS NOT NULL)"),
        db.Index("idx1_afnotegrahamhisto", "ngcfin", "ngdate"),
        {"schema": "analyse"},
    )

    ngcfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    ngdate = db.Column(db.DateTime)
    ngcriterepe = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngcriterepesurpanpa = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngcriterevecesurrocewacc = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngnotevalorisationabs = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngcriteredettesvscapi = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngcriteredettesvsbfr = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngcriterecouvfinan = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngnotesolvabiliteabs = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngcriteredividendes = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngcriterebn = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngnotestabiliteabs = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngnoteabsolue = db.Column(db.Numeric(1, 0, asdecimal=False))
    ngdatemaj = db.Column(db.DateTime)


class Afnoterisk(db.Model):
    __tablename__ = "afnoterisk"
    __table_args__ = (
        db.Index("unique_alternate_on_date", "nrcfin", "nrdate"),
        {"schema": "analyse"},
    )

    nrcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de l instrument financier",
    )
    nrdate = db.Column(db.DateTime, nullable=False, info="Date de mise a jour")
    nrglobale = db.Column(db.Numeric(6, 2), info="Note de 0 a 20")
    nrnote = db.Column(db.Numeric(1, 0, asdecimal=False), info="Note de 1 a 5")
    nrliquidite = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Note de liquidite 0 a 20"
    )
    nrvolhisto = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Note de volatilite des cours"
    )
    nrvolbn = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Note de volatilite des BN"
    )
    nrmedaf = db.Column(db.Numeric(5, 2), info="Note de 0.5 a 1.5")
    nrerreur = db.Column(
        db.Numeric(10, 0, asdecimal=False), info="Code d errreur de calcul"
    )
    nrmedafexp = db.Column(db.Numeric(5, 2), info="Note de 0.5 a 2.5")
    nrdatemaj = db.Column(db.DateTime)


class Afnoterisksake(db.Model):
    __tablename__ = "afnoterisksake"
    __table_args__ = {"schema": "analyse"}

    nrcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    nrdate = db.Column(db.DateTime, nullable=False, info="Date de mise a jour")
    nrglobale = db.Column(db.Numeric(6, 2), info="Note de 0 a 20")
    nrnote = db.Column(db.Numeric(1, 0, asdecimal=False), info="Note de 1 a 5")
    nrliquidite = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Note de liquidite 0 a 20"
    )
    nrvolhisto = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Note de volatilite des cours"
    )
    nrvolbn = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Note de volatilite des BN"
    )
    nrmedaf = db.Column(db.Numeric(5, 2), info="Note de 0.5 a 1.5")
    nrerreur = db.Column(
        db.Numeric(10, 0, asdecimal=False), info="Code d errreur de calcul"
    )
    nrmedafexp = db.Column(db.Numeric(5, 2), info="Note de 0.5 a 2.5")


class Afnoterisksakehisto(db.Model):
    __tablename__ = "afnoterisksakehisto"
    __table_args__ = {"schema": "analyse"}

    nrcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de l'instrument financier",
    )
    nrdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    nrglobale = db.Column(db.Numeric(6, 2), info="Note de 0 a 20")
    nrnote = db.Column(db.Numeric(1, 0, asdecimal=False), info="Note de 1 a 5")
    nrliquidite = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Note de liquidite 0 a 20"
    )
    nrvolhisto = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Note de volatilite des cours"
    )
    nrvolbn = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Note de volatilite des BN"
    )
    nrmedaf = db.Column(db.Numeric(5, 2), info="Note de 0.5 a 1.5")
    nrerreur = db.Column(
        db.Numeric(10, 0, asdecimal=False), info="Code d errreur de calcul"
    )
    nrmedafexp = db.Column(db.Numeric(5, 2), info="Note de 0.5 a 2.5")
    nrdatemaj = db.Column(db.DateTime)


class Afnotesdespread(db.Model):
    __tablename__ = "afnotesdespread"
    __table_args__ = {"schema": "analyse"}

    nscfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code du produit ( cf RKPRODUIT ou AFSOCIETE)",
    )
    nscodespread = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code type de spread (cf AFTYPENOTESPREAD)",
    )
    nscoderating = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de type de rating (cf AFCODERATING)",
    )
    nsmaturite = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de la maturité (cf RKDEFTAUX)",
    )
    nspointsdebase = db.Column(
        db.Numeric(8, 4), info="Valeurs en points de base ( en % x 100)"
    )
    nsdatemaj = db.Column(
        db.DateTime,
        nullable=False,
        info="Date de mise à jour du calcul ou de la saisie",
    )


class Afnotesdespreadsake(db.Model):
    __tablename__ = "afnotesdespreadsake"
    __table_args__ = {"schema": "analyse"}

    nscfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de l'instrument financier",
    )
    nscodespread = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code type de spread (cf AFTYPENOTESPREAD)",
    )
    nscoderating = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de type de rating (cf AFCODERATING)",
    )
    nsmaturite = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de la maturité (cf RKDEFTAUX)",
    )
    nspointsdebase = db.Column(
        db.Numeric(8, 4), info="Valeurs en points de base ( en % x 100)"
    )
    nsdatemaj = db.Column(
        db.DateTime,
        nullable=False,
        info="Date de mise à jour du calcul ou de la saisie",
    )


class Afnotesdespreadsakehisto(db.Model):
    __tablename__ = "afnotesdespreadsakehisto"
    __table_args__ = {"schema": "analyse"}

    nscfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de l'instrument financier",
    )
    nscodespread = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code type de spread (cf AFTYPENOTESPREAD)",
    )
    nscoderating = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de type de rating (cf AFCODERATING)",
    )
    nsmaturite = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de la maturité (cf RKDEFTAUX)",
    )
    nspointsdebase = db.Column(
        db.Numeric(8, 4), info="Valeurs en points de base ( en % x 100)"
    )
    nsdatemaj = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Date de mise à jour du calcul ou de la saisie",
    )


class Afnouvellenotederisque(db.Model):
    __tablename__ = "afnouvellenotederisque"
    __table_args__ = {"schema": "analyse"}

    nrcfin = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    nrdate = db.Column(db.DateTime, nullable=False)
    nrvolatiliteabsolue = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrvolatilitenormee = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrvolatilitedebrayee = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrdispersionconsensus12m = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrdispersionnormee = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrdispersiondebrayee = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrcyclicite = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrcyclicitenormee = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrcyclicitedebrayee = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrecarttypemargeebitda = db.Column(db.Numeric(4, 2))
    nrmargeebitda12mois = db.Column(db.Numeric(4, 2))
    nrincertitudeabsolue = db.Column(db.Numeric(2, 0, asdecimal=False))
    nrincertitudenormee = db.Column(db.Numeric(2, 0, asdecimal=False))
    nrincertitudedebrayee = db.Column(db.Numeric(2, 0, asdecimal=False))
    nrecarttypeebitdaparbroker = db.Column(db.Numeric(4, 2))
    nrcroiebitdaparbrokermedian = db.Column(db.Numeric(4, 2))
    nrratiocashconversionperiode = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrratiocashconversionnormee = db.Column(db.Numeric(4, 0, asdecimal=False))
    nrratiocashcoversiondebrayee = db.Column(db.Numeric(4, 0, asdecimal=False))
    nretcashconvebitdaencfdopborne = db.Column(db.Numeric(4, 2))
    nrmdcashconvebitdaencfdopborne = db.Column(db.Numeric(4, 2))
    nrnoteoperationnelle = db.Column(db.Numeric(6, 2))
    nrnoteoperationnelledebrayee = db.Column(db.Numeric(6, 2))
    nrlevierfinancier = db.Column(db.Numeric(4, 2))
    nrlevierfinancierdebraye = db.Column(db.Numeric(4, 2))
    nrfacteurajustementsf = db.Column(db.Numeric(4, 2))
    nrfacteurajustementsfdebraye = db.Column(db.Numeric(4, 2))
    nrtauxisnormatif12mois = db.Column(db.Numeric(4, 2))
    nrtauxisdebraye = db.Column(db.Numeric(4, 2))
    nrnoteoprajusteenormee = db.Column(db.Numeric(4, 2))
    nrnoteoprajusteedebrayeenormee = db.Column(db.Numeric(4, 2))
    nrnotefinale = db.Column(db.Numeric(4, 2))
    datemaj = db.Column(db.DateTime, nullable=False)


class Afofficeobject(db.Model):
    __tablename__ = "afofficeobjects"
    __table_args__ = {"schema": "analyse"}

    societe = db.Column(db.ForeignKey("analyse.afsociete.socfin"), nullable=False)
    exercice = db.Column(db.Numeric(4, 0, asdecimal=False))
    id = db.Column(db.Numeric(10, 0, asdecimal=False), primary_key=True)
    parentid = db.Column(db.ForeignKey("analyse.afofficeobjects.id"))
    position = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    type = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    top = db.Column(db.Numeric(10, 4))
    height = db.Column(db.Numeric(10, 4))
    left = db.Column(db.Numeric(10, 4))
    width = db.Column(db.Numeric(10, 4))
    nom = db.Column(db.String(100))
    titre = db.Column(db.String(100))
    indicateursplit = db.Column(db.Numeric(5, 0, asdecimal=False))
    typeventilation = db.Column(db.Numeric(2, 0, asdecimal=False))

    parent = db.relationship(
        "Afofficeobject",
        remote_side=[id],
        primaryjoin="Afofficeobject.parentid == Afofficeobject.id",
        backref="afofficeobjects",
    )
    afsociete = db.relationship(
        "Afsociete",
        primaryjoin="Afofficeobject.societe == Afsociete.socfin",
        backref="afofficeobjects",
    )


class Afopinion(db.Model):
    __tablename__ = "afopinions"
    __table_args__ = (
        db.CheckConstraint("OPCODE IN (0, 1, 2, 4, 8)"),
        {"schema": "analyse"},
    )

    opcode = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        primary_key=True,
        server_default=db.FetchedValue(),
        info="Code opinion",
    )
    oplibellefr = db.Column(db.String(40), info="Libellé français")
    oplibellegb = db.Column(db.String(40), info="Libellé anglais")
    oplibellecourtfr = db.Column(db.String(10))
    oplibellecourtgb = db.Column(db.String(10))


class Afpaysparam(db.Model):
    __tablename__ = "afpaysparam"
    __table_args__ = {"schema": "analyse"}

    spmcode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    spmdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    spmtypeparam = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    spmvaleur = db.Column(db.Numeric(12, 5))


class Afpaysparamtype(db.Model):
    __tablename__ = "afpaysparamtype"
    __table_args__ = {"schema": "analyse"}

    sptcodeparam = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    sptdescparam = db.Column(db.String(150))


class Afpayszone(db.Model):
    __tablename__ = "afpayszones"
    __table_args__ = {"schema": "analyse"}

    pacode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    paiszone = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    padeviseprincipale = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    padevisesecond = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    panomlongfr = db.Column(db.String(40))
    panomlonggb = db.Column(db.String(40))
    panomcourtfr = db.Column(db.String(5))
    panomcourtgb = db.Column(db.String(5))
    paprimerisque = db.Column(db.Numeric(13, 5))
    padateprime = db.Column(db.DateTime)


class Afperfratio(db.Model):
    __tablename__ = "afperfratios"
    __table_args__ = {"schema": "analyse"}

    prcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    prdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    prexefiscal = db.Column(
        db.Numeric(4, 0, asdecimal=False), primary_key=True, nullable=False
    )
    prmaturite = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    prve = db.Column(db.Numeric(16, 5))
    prcapi = db.Column(db.Numeric(16, 5))
    prpeavtsvl = db.Column(db.Numeric(12, 5))
    prpeaprsvl = db.Column(db.Numeric(12, 5))
    prpcfpa = db.Column(db.Numeric(12, 5))
    prpanpa = db.Column(db.Numeric(12, 5))
    prvesurca = db.Column(db.Numeric(12, 5))
    prvesurebitda = db.Column(db.Numeric(12, 5))
    prvesurebit = db.Column(db.Numeric(12, 5))
    prvesuropfcf = db.Column(db.Numeric(12, 5))
    prvesurce = db.Column(db.Numeric(12, 5))
    prgearing = db.Column(db.Numeric(12, 5))
    prcouvff = db.Column(db.Numeric(12, 5))
    prrocesurwacc = db.Column(db.Numeric(12, 5))
    prpesurcagrnopat = db.Column(db.Numeric(12, 5))
    prdnsurve = db.Column(db.Numeric(12, 5))
    prrendementnet = db.Column(db.Numeric(12, 5))
    prroe = db.Column(db.Numeric(12, 5))
    prroce = db.Column(db.Numeric(12, 5))
    prfv = db.Column(db.Numeric(12, 5))
    prpayout = db.Column(db.Numeric(12, 5))
    prpeavtsvl_neg = db.Column(db.Numeric(12, 5))
    prpeaprsvl_neg = db.Column(db.Numeric(12, 5))
    prdatemaj = db.Column(db.DateTime, nullable=False)


class Afprimesmoyenne(db.Model):
    __tablename__ = "afprimesmoyennes"
    __table_args__ = {"schema": "analyse"}

    pmcodeind = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    pmdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    pmbpa = db.Column(db.Numeric(10, 3))
    pmpayout = db.Column(db.Numeric(10, 3))
    pmavf = db.Column(db.Numeric(10, 3))
    pmprogress = db.Column(db.Numeric(10, 3))
    pmprime = db.Column(db.Numeric(10, 5))


class Afptsbasecentre(db.Model):
    __tablename__ = "afptsbasecentre"
    __table_args__ = {"schema": "analyse"}

    ptdevise = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Devise des points de base",
    )
    ptmaturite = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de la maturité (cf RKDEFTAUX)",
    )
    ptptsbase = db.Column(
        db.Numeric(8, 4), info="Valeurs des points de base ( en % x 100)"
    )
    ptmaj = db.Column(db.DateTime, nullable=False, info="Date de mise à jour")


class Afquintile(db.Model):
    __tablename__ = "afquintiles"
    __table_args__ = {"schema": "analyse"}

    aqcfin = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    aqeval = db.Column(db.Numeric(1, 0, asdecimal=False))
    aqrev = db.Column(db.Numeric(1, 0, asdecimal=False))
    aqcrois = db.Column(db.Numeric(1, 0, asdecimal=False))
    aqsm = db.Column(db.Numeric(1, 0, asdecimal=False))
    aqsmrel = db.Column(db.Numeric(1, 0, asdecimal=False))
    aqdatemaj = db.Column(db.DateTime)
    aqvalrev = db.Column(db.Numeric(8, 3))
    aqvaleval = db.Column(db.Numeric(8, 3))
    aqvalcrois = db.Column(db.Numeric(8, 3))
    aqvalsm = db.Column(db.Numeric(8, 3))
    aqvalsmrel = db.Column(db.Numeric(8, 3))


class Afratioshisto(db.Model):
    __tablename__ = "afratioshisto"
    __table_args__ = (
        db.Index("ixafratioshisto", "rhcfin", "rhdate", "rhexefiscal"),
        {"schema": "analyse"},
    )

    rhcfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    rhdate = db.Column(db.DateTime, nullable=False)
    rhexefiscal = db.Column(db.Numeric(4, 0, asdecimal=False), nullable=False)
    rhve = db.Column(db.Numeric(16, 5))
    rhcapi = db.Column(db.Numeric(16, 5))
    rhpeavtsvl = db.Column(db.Numeric(12, 5))
    rhpeaprsvl = db.Column(db.Numeric(12, 5))
    rhpcfpa = db.Column(db.Numeric(12, 5))
    rhpanpa = db.Column(db.Numeric(12, 5))
    rhvesurca = db.Column(db.Numeric(12, 5))
    rhvesurebitda = db.Column(db.Numeric(12, 5))
    rhvesurebit = db.Column(db.Numeric(12, 5))
    rhvesuropfcf = db.Column(db.Numeric(12, 5))
    rhvesurce = db.Column(db.Numeric(12, 5))
    rhgearing = db.Column(db.Numeric(12, 5))
    rhcouvff = db.Column(db.Numeric(12, 5))
    rhrocesurwacc = db.Column(db.Numeric(12, 5))
    rhpesurcagrnopat = db.Column(db.Numeric(12, 5))
    rhdnsurve = db.Column(db.Numeric(12, 5))
    rhrendementnet = db.Column(db.Numeric(16, 9))
    rhroe = db.Column(db.Numeric(12, 5))
    rhroce = db.Column(db.Numeric(12, 5))
    rhfv = db.Column(db.Numeric(12, 5))
    rhpayout = db.Column(db.Numeric(12, 5))
    rhpeavtsvl_neg = db.Column(db.Numeric(12, 5))
    rhpeaprsvl_neg = db.Column(db.Numeric(12, 5))
    rhcapisurbnpdgapressvl = db.Column(db.Numeric(16, 5))
    rhcapisurbnpdgavantsvl = db.Column(db.Numeric(16, 5))
    rhdevcours = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Devise de cours",
    )
    rhdevprevision = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Devise de Prevision",
    )
    rhnbtitresreelfinexe = db.Column(
        db.Numeric(21, 3), info="Nombre de titres reels fin d exercice"
    )
    rhnbtitresdiluemoyen = db.Column(
        db.Numeric(21, 3), info="Nombre de titres dilues moyen"
    )
    rhnbtitresdiluefinexe = db.Column(
        db.Numeric(21, 3), info="Nombre de titres dilues fin d exercice"
    )
    rhecoffmoyenapris = db.Column(
        db.Numeric(15, 4), info="Ecomonie Frais Financier après IS"
    )
    rhupdatedate = db.Column(
        db.DateTime,
        info="Dernière date de mise à jour par le batch saveratios boursiers",
    )
    rhfcfyield = db.Column(
        db.Numeric(15, 4), info="Historisation indicateur FCF Yield id = 2352"
    )
    rhnavps = db.Column(
        db.Numeric(15, 4), info="Historisation indicateur NAV Per Share id = 20704"
    )
    rhnbtitresreelmoyen = db.Column(db.Numeric(21, 3), info="Nb Titres Reels moyen")
    rhdatediffusion = db.Column(
        db.DateTime,
        info="Date de diffusion du changement (= toujours J + heure de diffusion)  ",
    )


class Afratiossectoriel(db.Model):
    __tablename__ = "afratiossectoriels"
    __table_args__ = {"schema": "analyse"}

    rscodesecteur = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code du secteur, de l'indice, ou du stock guide ( pour le marché)",
    )
    rscodestockguide = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code du stock guide associé",
    )
    rsanneeexercice = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Année d'exercice fiscal",
    )
    rsdatedecalcul = db.Column(db.DateTime, info="Date de calcul de valeurs")
    rscapitalisation = db.Column(
        db.Numeric(13, 5), info="Calcul de la capitalisation de la série"
    )
    rscapipct = db.Column(
        db.Numeric(13, 5), info="Pourcentage de la capitalisation globale"
    )
    rspbpamedian = db.Column(db.Numeric(13, 5), info="Médiane des P/BPA=PER+SVL")
    rspbnpamedian = db.Column(db.Numeric(13, 5), info="Médiane des P/BNPA=PER")
    rspbparelatifmedian = db.Column(
        db.Numeric(13, 5),
        info="Médiane des  P/ BPA relatifs au marché ( grand stock guide)",
    )
    rscroisspbpamedian = db.Column(
        db.Numeric(13, 5), info="Calcul de la médiane des croissances des BNPA"
    )
    rscroisspbnpamedian = db.Column(
        db.Numeric(13, 5), info="Calcul de la croissance ponderée des BNPA"
    )
    rscroisscfpamedian = db.Column(
        db.Numeric(13, 5), info="Calcul  de la médiane des croissances des CFPA"
    )
    rscapidettemedian = db.Column(
        db.Numeric(13, 5), info="Calcul de la médiane des ratio (Capi + Dette)/CA"
    )
    rsrendementmedian = db.Column(
        db.Numeric(13, 5), info="Calcul de la médiane des rendements"
    )
    rscouvfraisfi = db.Column(
        db.Numeric(13, 5),
        info="Calcul de la mediane des ratio Couverture des frais financiers",
    )
    rspcfpamedian = db.Column(
        db.Numeric(13, 5), info="Calcul de la médiane des ratio P/CFPA"
    )
    rspanpamedian = db.Column(
        db.Numeric(13, 5), info="Cacul de la médiane des ratio P/ANPA"
    )
    rsdettefpmedian = db.Column(
        db.Numeric(13, 5), info="Mediane des Dettes/Fonds propres"
    )
    rscroissbpapondere = db.Column(
        db.Numeric(13, 5), info="Calcul de la croissance pondérée des BPA"
    )
    rscroissbnpapondere = db.Column(
        db.Numeric(13, 5), info="Calcul de la croissance pondérée des BNPA"
    )
    rsrendementpondere = db.Column(
        db.Numeric(13, 5), info="Calcul de la médiane des ratios rendements"
    )
    rsdecotepondere = db.Column(
        db.Numeric(13, 5), info="Calcul de la décote pondérée d'un échantillon"
    )
    rscroisscfpapondere = db.Column(
        db.Numeric(13, 5), info="Calcul de la médiane des croissances des CFPA"
    )
    rsbpaaftergw = db.Column(db.Numeric(13, 5), info="BPA après Goodwill source:JH")
    rsbpaaftergw_exane = db.Column(
        db.Numeric(13, 5), info="BPA Exane après Goodwill source:JH"
    )
    rsbpabeforegw = db.Column(db.Numeric(13, 5), info="BPA avant Goodwill source:JH")
    rsbpabeforegw_exane = db.Column(
        db.Numeric(13, 5), info="BPA Exane avant Goodwill source:JH"
    )


class Afreserve(db.Model):
    __tablename__ = "afreserves"
    __table_args__ = {"schema": "analyse"}

    recfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Code société"
    )
    retextefr = db.Column(db.String(40), info="Réserve commisaire FR")
    retextegb = db.Column(db.String(40), info="Réserve commisaire GB")


class Afrisk(db.Model):
    __tablename__ = "afrisk"
    __table_args__ = {"schema": "analyse"}

    ricfin = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    rinote = db.Column(db.Numeric(1, 0, asdecimal=False))
    riglobal = db.Column(db.Numeric(5, 1))
    riliquidite = db.Column(db.Numeric(2, 0, asdecimal=False))
    rivol_histo = db.Column(db.Numeric(2, 0, asdecimal=False))
    rivol_bn = db.Column(db.Numeric(2, 0, asdecimal=False))
    ridispersion = db.Column(db.Numeric(2, 0, asdecimal=False))
    ristrucfi = db.Column(db.Numeric(2, 0, asdecimal=False))
    rimanagement = db.Column(db.String(2))
    risecteur = db.Column(db.String(2))
    riflag = db.Column(db.Numeric(5, 0, asdecimal=False))


class Afriskparam(db.Model):
    __tablename__ = "afriskparams"
    __table_args__ = {"schema": "analyse"}

    rptype = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        primary_key=True,
        info="Code ( clef) du parametre voir AFRPTYPE",
    )
    rpdate = db.Column(db.DateTime, nullable=False, info="Date de la mise a jour")
    rpparam = db.Column(db.Numeric(13, 5), info="valeur")
    rpparamsect = db.Column(db.Numeric(13, 5))
    rpdesc = db.Column(db.String(80))


class Afriskparamssake(db.Model):
    __tablename__ = "afriskparamssake"
    __table_args__ = {"schema": "analyse"}

    rptype = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code ( clef) du parametre voir AFRPTYPE",
    )
    rpdate = db.Column(db.DateTime, nullable=False, info="Date de la mise a jour")
    rpparam = db.Column(db.Numeric(13, 5), info="valeur")
    rpparamsect = db.Column(db.Numeric(13, 5))


class Afriskvolbn(db.Model):
    __tablename__ = "afriskvolbn"
    __table_args__ = {"schema": "analyse"}

    rvcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code ( clef) cfin voir RKPRODUIT",
    )
    rvvolbn = db.Column(db.Numeric(2, 0, asdecimal=False), info="Volatilite forcee")


class Afrptype(db.Model):
    __tablename__ = "afrptype"
    __table_args__ = {"schema": "analyse"}

    rptype = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code ( clef) du parametre voir AFRISKPARAMS",
    )
    rplibelle = db.Column(db.String(30), info="Libelle de la valeur")


class Afsakeparam(db.Model):
    __tablename__ = "afsakeparam"
    __table_args__ = {"schema": "analyse"}

    spcode = db.Column(db.Numeric(4, 0, asdecimal=False), primary_key=True)
    spdesc = db.Column(db.String(40))
    spvaleur = db.Column(db.Numeric(10, 3))
    sptext = db.Column(db.String(1024))


class Afscenarioeditiquehisto(db.Model):
    __tablename__ = "afscenarioeditiquehisto"
    __table_args__ = {"schema": "analyse"}

    sesocfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    sesccfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    sedate = db.Column(db.DateTime, primary_key=True, nullable=False)


class Afscenario(db.Model):
    __tablename__ = "afscenarios"
    __table_args__ = {"schema": "analyse"}

    sccfin = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    sclibellefr = db.Column(db.String(80))
    sclibellegb = db.Column(db.String(80))
    scdatecreation = db.Column(db.DateTime, nullable=False)
    scdescfr = db.Column(db.String(100), info="Description du scnério (FR)")
    scdescgb = db.Column(db.String(100), info="Description du scnério (GB)")
    sccomptes = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info=" 1/0 : Données de Comptes prises en compte (ou non) par le scénario",
    )
    sctargetprice = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info=" 1/0 : Données de Target Price prises en compte (ou non) par le scénario",
    )
    scrating = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info=" 1/0 : Données de Rating prises en compte (ou non) par le scénario",
    )
    scnoterisque = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info=" 1/0 : Données de Note De Risque spread prises en compte (ou non) par le scénario",
    )
    scbasetitre = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info=" 1/0 : Données de la Base Titre prises en compte (ou non) par le scénario",
    )
    sccompliance = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info=" 1/0 : Prise en charge (ou non) des compliances par le scénario",
    )
    scordre = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Ordre pour l affichage du scenario"
    )


class Afsecteur(db.Model):
    __tablename__ = "afsecteur"
    __table_args__ = (
        db.CheckConstraint("SEOPINION IN (0, 1, 2, 4, 8)"),
        {"schema": "analyse"},
    )

    secfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code du secteur",
    )
    setypesecteur = db.Column(db.Numeric(8, 0, asdecimal=False), info="Type de secteur")
    seordre = db.Column(db.Numeric(3, 0, asdecimal=False), info="Ordre de présentation")
    senomfrancais = db.Column(db.String(40), info="Libellé du secteur en francais")
    senomanglais = db.Column(db.String(40), info="libellé du secteur en anglais")
    seopinion = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Code opinion",
    )
    seindice = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        server_default=db.FetchedValue(),
        info="Indice sectoriel",
    )
    sepath = db.Column(db.String(80), info="Path réseau")
    seabreviation = db.Column(db.String(5), info="Abréviation du secteur (5 lettres)")
    setypegrille = db.Column(db.Numeric(8, 0, asdecimal=False))
    secodeds = db.Column(db.String(40))
    soanalysteprincipal = db.Column(db.Numeric(3, 0, asdecimal=False))
    sovalpref1 = db.Column(db.Numeric(8, 0, asdecimal=False))
    sovalpref2 = db.Column(db.Numeric(8, 0, asdecimal=False))
    sovalpref3 = db.Column(db.Numeric(8, 0, asdecimal=False))
    semailclient = db.Column(db.String(255))
    selibellerelfr = db.Column(db.String(40))
    selibellerelgb = db.Column(db.String(40))
    senomcourt = db.Column(db.String(20))
    senomcourtgb = db.Column(db.String(20))
    separamnotederisque = db.Column(db.Numeric(1, 0, asdecimal=False))
    segamme = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        info="Gamme associee au secteur afin de pouvoir gerer des droits d'acces specifiques a ce secteur",
    )
    seseuil = db.Column(
        db.Numeric(15, 4), info="Seuil pour les révisions d estimations du secteur"
    )
    seindicenamefr = db.Column(db.String(80), info="Name of attached index in french")
    seindicenamegb = db.Column(db.String(80), info="Name of attached index in english")
    serefmsci = db.Column(db.Numeric(8, 0, asdecimal=False), info="Ref MSCI for sector")
    sevaluationsheet = db.Column(db.String(100))


class Afsecteurcompo(db.Model):
    __tablename__ = "afsecteurcompo"
    __table_args__ = {"schema": "analyse"}

    ascodesecteur = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code du secteur analyse (afsecteur)",
    )
    ascodeteam = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de la team (afteam)",
    )


class Afsecteurparam(db.Model):
    __tablename__ = "afsecteurparam"
    __table_args__ = {"schema": "analyse"}

    smcode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    smdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    smtypeparam = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    smvaleur = db.Column(db.Numeric(12, 5))


class Afsecteurparamtype(db.Model):
    __tablename__ = "afsecteurparamtype"
    __table_args__ = {"schema": "analyse"}

    stcodeparam = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    stdescparam = db.Column(db.String(150))


class Afsecteurperf(db.Model):
    __tablename__ = "afsecteurperf"
    __table_args__ = {"schema": "analyse"}

    spcfin = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    spdatemaj = db.Column(db.DateTime)
    spperf1s = db.Column(db.Numeric(10, 2))
    spperf1m = db.Column(db.Numeric(10, 2))
    spperf3m = db.Column(db.Numeric(10, 2))
    spperf6m = db.Column(db.Numeric(10, 2))
    spperf12m = db.Column(db.Numeric(10, 2))
    spdateperf = db.Column(db.DateTime)
    spsource = db.Column(db.Numeric(1, 0, asdecimal=False))
    spperf1j = db.Column(db.Numeric(10, 2))
    spperfytd = db.Column(db.Numeric(10, 2))
    spperf3y = db.Column(db.Numeric(10, 2))
    spperf5y = db.Column(db.Numeric(10, 2))
    spperf2y = db.Column(db.Numeric(10, 2))
    spperf10y = db.Column(db.Numeric(10, 2))
    spperf15y = db.Column(db.Numeric(10, 2), info="Performance 15 ans")


class Afsecteurstrategie(db.Model):
    __tablename__ = "afsecteurstrategie"
    __table_args__ = {"schema": "analyse"}

    sscfin = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    sstypesecteur = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info=" 1 = Secteur Anafi  2 = Somme de Secteurs  3 = Secteur Personnalise",
    )
    ssordre = db.Column(db.Numeric(3, 0, asdecimal=False))
    ssnomfrancais = db.Column(db.String(40))
    ssnomanglais = db.Column(db.String(40))
    ssopinion = db.Column(db.Numeric(1, 0, asdecimal=False))
    ssindice = db.Column(db.Numeric(8, 0, asdecimal=False))
    sspath = db.Column(db.String(80))
    ssabreviation = db.Column(db.String(5))
    sstypegrille = db.Column(db.Numeric(8, 0, asdecimal=False))
    sscodeds = db.Column(db.String(40))
    ssanalysteprincipal = db.Column(db.Numeric(3, 0, asdecimal=False))
    ssvalpref1 = db.Column(db.Numeric(8, 0, asdecimal=False))
    ssvalpref2 = db.Column(db.Numeric(8, 0, asdecimal=False))
    ssvalpref3 = db.Column(db.Numeric(8, 0, asdecimal=False))
    ssmailclient = db.Column(db.String(255))
    sslibellerelfr = db.Column(db.String(40))
    sslibellerelgb = db.Column(db.String(40))
    ssnomcourt = db.Column(db.String(20))
    ssnomcourtgb = db.Column(db.String(20))
    ssparamnotederisque = db.Column(db.Numeric(1, 0, asdecimal=False))
    ssindicenamefr = db.Column(db.String(80), info="Name of attached index in french")
    ssindicenamegb = db.Column(db.String(80), info="Name of attached index in english")


class Afsecteursuivi(db.Model):
    __tablename__ = "afsecteursuivi"
    __table_args__ = {"schema": "analyse"}

    ssanalyste = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de l'utilisateur",
    )
    sssecteur = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code du secteur suivi",
    )


class Afsocietecomment(db.Model):
    __tablename__ = "afsocietecomments"
    __table_args__ = (
        db.Index("idx_afsocietecomments", "sccfin", "scfonction", "scexe"),
        {"schema": "analyse"},
    )

    sccfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    scfonction = db.Column(db.Numeric(8, 0, asdecimal=False))
    scexe = db.Column(db.DateTime)
    sccommentfr = db.Column(db.String(800))
    scdatemodifcommentfr = db.Column(db.DateTime)
    sccommentgb = db.Column(db.String(800))
    scdatemodifcommentgb = db.Column(db.DateTime)
    sctypepublication = db.Column(db.Numeric(3, 0, asdecimal=False))


class Afsocieteparam(db.Model):
    __tablename__ = "afsocieteparam"
    __table_args__ = {"schema": "analyse"}

    somcode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    somdate = db.Column(db.DateTime, primary_key=True, nullable=False)
    somtypeparam = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    somvaleur = db.Column(db.Numeric(12, 5))


class Afsocieteparamtype(db.Model):
    __tablename__ = "afsocieteparamtype"
    __table_args__ = {"schema": "analyse"}

    sotcodeparam = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    sotdescparam = db.Column(db.String(150))


class Afstatibe(db.Model):
    __tablename__ = "afstatibes"
    __table_args__ = {"schema": "analyse"}

    sicfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    simesure = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    siecarttype = db.Column(db.Numeric(13, 5))
    sinbprevisions = db.Column(db.Numeric(8, 0, asdecimal=False))
    simediane = db.Column(db.Numeric(13, 5))
    sidatemaj = db.Column(db.DateTime)


class Afstockoption(db.Model):
    __tablename__ = "afstockoption"
    __table_args__ = {"schema": "analyse"}

    skcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    skstrike = db.Column(db.Numeric(13, 5), nullable=False)
    skdevstrike = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    skdateemission = db.Column(db.DateTime, nullable=False)
    skdateleveedebut = db.Column(db.DateTime, nullable=False)
    skdateleveefin = db.Column(db.DateTime, nullable=False)
    sklibellefr = db.Column(db.String(80))
    sklibellegb = db.Column(db.String(80))
    skcommentfr = db.Column(db.String(80))
    skcommentgb = db.Column(db.String(80))
    skparite = db.Column(db.Numeric(11, 5))
    skproportion = db.Column(db.Numeric(11, 5))
    skscenario = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        server_default=db.FetchedValue(),
        info="ID du scenario de la Stock Option",
    )


class AfstoxxSector(db.Model):
    __tablename__ = "afstoxx_sectors"
    __table_args__ = {"schema": "analyse"}

    code = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        unique=True,
        info="Code of Stoxx sector",
    )
    shortlabel = db.Column(
        db.String(100), nullable=False, info="Short label for stoxx sector"
    )
    longlabel = db.Column(
        db.String(200), nullable=False, info="Long label for stoxx sector"
    )
    opinion = db.Column(db.Numeric(1, 0, asdecimal=False), info="Opinion for sector")
    codeds = db.Column(db.String(40), info="Datastream code for stoxx sector")
    updatedate = db.Column(db.DateTime, info="Last update of sector")


class AfstoxxSectorsLink(db.Model):
    __tablename__ = "afstoxx_sectors_link"
    __table_args__ = {"schema": "analyse"}

    codestoxx = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code of Stoxx sector",
    )
    codeexane = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code of Exane Sector",
    )
    startdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Start date of link"
    )
    enddate = db.Column(db.DateTime, info="End date of link")


class Afsuviworkflow(db.Model):
    __tablename__ = "afsuviworkflow"
    __table_args__ = {"schema": "analyse"}

    swfichier = db.Column(
        db.String(50), primary_key=True, nullable=False, info="Nom du fichier"
    )
    swuser = db.Column(
        db.String(50), primary_key=True, nullable=False, info="Utilisateur windows"
    )
    swmachine = db.Column(
        db.String(50), primary_key=True, nullable=False, info="Nom de la machine"
    )
    swpath = db.Column(
        db.String(200), primary_key=True, nullable=False, info="Chemin du fichier"
    )
    swdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date d'ouverture"
    )
    swfuseau = db.Column(
        db.String(50), info="Fuseau horaire du poste qui insere la ligne"
    )
    swtype = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        server_default=db.FetchedValue(),
        info="Type de l operation (0->Send 1->Open 2->Close 3->Move 4->Open(RO) 5->Close(RO) 6->Save)",
    )
    swdestination = db.Column(
        db.String(200), info="Destination du fichier en cas de deplacement"
    )


class Aftaux(db.Model):
    __tablename__ = "aftaux"
    __table_args__ = {"schema": "analyse"}

    txcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Identifiant du taux"
    )
    txdate = db.Column(db.DateTime, nullable=False, info="Date du taux")
    txclose = db.Column(db.Numeric(16, 5), info="Valeur du taux en cloture")


class Aftauxexercice(db.Model):
    __tablename__ = "aftauxexercice"
    __table_args__ = {"schema": "analyse"}

    teannee = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Année d'exercice fiscal",
    )
    tedevise = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    tetauxisdist = db.Column(
        db.Numeric(8, 4), info="Taux d'impot sur les sociétés, distribué"
    )
    tetauxisnondist = db.Column(
        db.Numeric(8, 4), info="Taux d'impot sur les sociétés, non distribué"
    )
    tetaux10ans = db.Column(
        db.Numeric(8, 4), info="Taux de l'OAT 10 ans historique ( moyen)"
    )
    tecrossusdmoyen = db.Column(db.Numeric(13, 5), info="Taux de change moyen à USD")


class Afteam(db.Model):
    __tablename__ = "afteam"
    __table_args__ = {"schema": "analyse"}

    atcodeteam = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    atnomfr = db.Column(db.String(40))
    atnomuk = db.Column(db.String(40))
    atmail = db.Column(db.String(100))
    attel = db.Column(db.String(20))
    atresp = db.Column(db.Numeric(8, 0, asdecimal=False))
    atcoach = db.Column(db.Numeric(8, 0, asdecimal=False))
    atresp2 = db.Column(db.Numeric(8, 0, asdecimal=False))
    atismidcaps = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="0 si pas mid cap, 1 si mid cap",
    )
    atgamme = db.Column(db.Numeric(5, 0, asdecimal=False))
    isreadershipavalaible = db.Column(db.Numeric(1, 0, asdecimal=False))


class Afteamcompo(db.Model):
    __tablename__ = "afteamcompo"
    __table_args__ = {"schema": "analyse"}

    accodeteam = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    accodeuser = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    acentree = db.Column(db.DateTime, primary_key=True, nullable=False)
    acsortie = db.Column(db.DateTime, primary_key=True, nullable=False)


class Aftextsociete(db.Model):
    __tablename__ = "aftextsociete"
    __table_args__ = {"schema": "analyse"}

    tscfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    tstypecomment = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    tslangue = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    tstext = db.Column(db.String(4000))
    tstexthtml = db.Column(db.String(4000))
    tsdatemodif = db.Column(db.DateTime)


class Aftitre(db.Model):
    __tablename__ = "aftitres"
    __table_args__ = {"schema": "analyse"}

    tdcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de l'instrument financier",
    )
    tdfinexercice = db.Column(db.DateTime, primary_key=True, nullable=False)
    tdtypeproduit = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Code du type d'instrument"
    )
    tdcfinderive = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de l'instrument financier",
    )
    tdnbtitres = db.Column(
        db.Numeric(21, 3),
        server_default=db.FetchedValue(),
        info="Nombre de titres fin d exercice fiscal",
    )
    tdnbtitresmoyen = db.Column(
        db.Numeric(21, 3),
        server_default=db.FetchedValue(),
        info="Nombre de titres moyen de l exercice fiscal",
    )
    tdparite = db.Column(
        db.Numeric(11, 5),
        server_default=db.FetchedValue(),
        info="Parité du produit dérivé",
    )
    tdproportion = db.Column(
        db.Numeric(11, 5),
        server_default=db.FetchedValue(),
        info="Proportion du titre associé",
    )
    tdconversion = db.Column(
        db.Numeric(11, 5),
        server_default=db.FetchedValue(),
        info="Parité / Proportion ou facteur de conversion",
    )
    tdcoupon = db.Column(
        db.Numeric(11, 5), info="Montant du coupon de la convertible sur la période"
    )
    tddevisecoupon = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code de l'instrument financier"
    )
    tdstrike = db.Column(db.Numeric(11, 5), info="Prix d exerice de l option")
    tddevisestrike = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code du prix d exercice"
    )
    tdnominal = db.Column(db.Numeric(15, 5), info="Nominal de la convertible")
    tdevisenominal = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Code de la devise du nominal"
    )
    tdcoeffajustement = db.Column(
        db.Numeric(12, 6),
        server_default=db.FetchedValue(),
        info="Coefficient d ajustement des titres",
    )
    tdcoursmin = db.Column(db.Numeric(13, 5), info="Cours minimum de la période")
    tdcoursmoyen = db.Column(db.Numeric(13, 5), info="Cours moyen de la période")
    tdcoursmax = db.Column(db.Numeric(13, 5), info="Cours maximum de la période")
    tdcapimin = db.Column(
        db.Numeric(16, 2), info="Capitalisation minimum de la période"
    )
    tdcapimoyenne = db.Column(
        db.Numeric(16, 2), info="Capitalisation moyenne de la période"
    )
    tdcapimax = db.Column(
        db.Numeric(16, 2), info="Capitalisation maximum de la période"
    )
    tddeltanorme = db.Column(db.Numeric(12, 2), info="Delta normé ou delta normé moyen")
    tdautocontrole = db.Column(
        db.Numeric(12, 6), server_default=db.FetchedValue(), info="Autocontrôle"
    )
    tdnbtitresdilues = db.Column(db.Numeric(21, 3))
    tdnbtitresdiluesmoyen = db.Column(db.Numeric(21, 3))
    tdstopdilution = db.Column(db.Numeric(1, 0, asdecimal=False))
    tdautocontrolefinexercice = db.Column(db.Numeric(12, 6))
    tdscenario = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        server_default=db.FetchedValue(),
        info="ID du scenario de produit derive",
    )
    tdautoctrlnbtitres = db.Column(
        db.Numeric(12, 0, asdecimal=False),
        info="Autocontrole exprime en nombre de titres",
    )
    tdautoctrlfinexecnbtitres = db.Column(
        db.Numeric(12, 0, asdecimal=False),
        info="Autocontrole fin exercice exprime en nombre de titres",
    )
    tdtypeautocontrole = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Type de autocontrole 0= pourcentage, 1=Nombre de titres",
    )
    tdhorodatecours = db.Column(
        db.DateTime,
        info="Dernière date de mise à jour des cours moyen par le batch ou l interface",
    )
    tdcourscalendar = db.Column(db.Numeric(13, 5), info="Cours calendarise")
    tdcapicalendar = db.Column(db.Numeric(16, 2), info="Capi calendarise")
    tdcoursmaxcalendar = db.Column(
        db.Numeric(13, 5), info="Cours Max sur annee calendaire"
    )
    tdcoursmincalendar = db.Column(
        db.Numeric(13, 5), info="Cours Min sur annee calendaire"
    )


class Aftypecodif(db.Model):
    __tablename__ = "aftypecodif"
    __table_args__ = {"schema": "analyse"}

    tctypecodif = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tclibelle = db.Column(db.String(100))
    tccomment = db.Column(db.String(2000))


class Aftypemult(db.Model):
    __tablename__ = "aftypemult"
    __table_args__ = {"schema": "analyse"}

    tytype = db.Column(db.Numeric(8, 0, asdecimal=False))
    tylibelle = db.Column(db.String(20))


class Aftypenotespread(db.Model):
    __tablename__ = "aftypenotespread"
    __table_args__ = {"schema": "analyse"}

    tscodespread = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de type de spread",
    )
    tslibelle = db.Column(db.String(20), info="Nom du type de spread")


class Aftypepersonne(db.Model):
    __tablename__ = "aftypepersonnes"
    __table_args__ = {"schema": "analyse"}

    tetype = db.Column(db.Numeric(4, 0, asdecimal=False), primary_key=True)
    telabelfr = db.Column(db.String(80))
    telabelgb = db.Column(db.String(80))


class Aftypesecteur(db.Model):
    __tablename__ = "aftypesecteur"
    __table_args__ = {"schema": "analyse"}

    tstypesecteur = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Type de secteur"
    )
    tslibelle = db.Column(db.String(20), info="Libellé du type de secteur")


class Aftypesuivi(db.Model):
    __tablename__ = "aftypesuivi"
    __table_args__ = {"schema": "analyse"}

    tscodesuivi = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        primary_key=True,
        server_default=db.FetchedValue(),
        info="Types de suivi de la société : 0 Non suivi, 1 Complet, 2 Partiel, 3 Data",
    )
    tslibelle = db.Column(db.String(20), info="Libellé du mode de suivi")


class Afunite(db.Model):
    __tablename__ = "afunite"
    __table_args__ = {"schema": "analyse"}

    uncode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Code de l'unité"
    )
    unmultiple = db.Column(db.Numeric(16, 4), info="Multiplicateur de l'unité")
    unlibellelongfr = db.Column(db.String(40), info="Libellé Francais de l'unité")
    unlibellelonggb = db.Column(db.String(40), info="Libellé Anglais de l'unité")
    unlibellecourtfr = db.Column(db.String(5), info="Expression de l'unité en Francais")
    unlibellecourtgb = db.Column(db.String(5), info="Expression de l'unité en Anglais")


class Afusergroup(db.Model):
    __tablename__ = "afusergroups"
    __table_args__ = {"schema": "analyse"}

    code = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de simulation ( clef)",
    )
    libelle = db.Column(db.String(50), info="valeur")


class Afuser(db.Model):
    __tablename__ = "afusers"
    __table_args__ = {"schema": "analyse"}

    uscode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de l'utilisateur",
    )
    usgroupe = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Code du groupe utilisateur",
    )
    usnom = db.Column(db.String(40), info="Nom de l'analyste")
    usprenom = db.Column(db.String(40), info="Prénom de l'analyste")
    usinitiales = db.Column(db.String(3), info="Initiales de l'analyste")
    usphone = db.Column(db.String(20), info="Téléphone de l'analyste")
    usemail = db.Column(db.String(200), info="Adresse email")
    uscodeservice = db.Column(db.Numeric(8, 0, asdecimal=False))
    uslogin = db.Column(db.String(40))
    uslocalisation = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Localisation de l analyste : PARIS=0 LONDRES=1",
    )
    ustypeanalyste = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Type de l'analyste (0->undef, 1->Equity, 2->Marketing, 3->TradingArbitrage, 4->Strategy, 5->Economy)",
    )
    uscfa = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="L'analyste a le diplome CFA",
    )
    ussfaf = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="L'analyste a le diplome SFAF",
    )
    usactif = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="L'analyste est present ou non dans l'efectif (0->non actif, 1->actif)",
    )


class Afverifindic(db.Model):
    __tablename__ = "afverifindic"
    __table_args__ = {"schema": "analyse"}

    viindic = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    viexefiscal = db.Column(
        db.Numeric(4, 0, asdecimal=False), primary_key=True, nullable=False
    )
    viinterface = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    vitypecours = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    vitypeannualisation = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    vityperatio = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    vitypefonction = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    vioperateur = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, nullable=False
    )
    vivaleur1 = db.Column(db.Numeric(16, 3))
    vivaleur2 = db.Column(db.Numeric(16, 3))
    vitypepb = db.Column(db.Numeric(2, 0, asdecimal=False))
    vikindofcie = db.Column(db.Numeric(2, 0, asdecimal=False))
    viparamkind = db.Column(db.Numeric(16, 3))


class Afxmlsummary(db.Model):
    __tablename__ = "afxmlsummary"
    __table_args__ = {"schema": "analyse"}

    xmcfin = db.Column(db.String(100), primary_key=True)
    xmdatemaj = db.Column(db.Numeric(asdecimal=False))
    xmdata = db.Column(db.NullType)


class Anprime(db.Model):
    __tablename__ = "anprime"
    __table_args__ = {"schema": "analyse"}

    prcodepr = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="code de la prime de risque r¿pertori¿ dans la table anprconst",
    )
    prdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="date de calcul"
    )
    prbpa = db.Column(
        db.Numeric(10, 3),
        info="bpa du produit dont le cfin est anprconst.cocfinsj (table anprconst)",
    )
    prpayout = db.Column(
        db.Numeric(10, 3),
        info="payout du produit dont le cfin est anprconst.cocfinsj (table anprconst)",
    )
    pravf = db.Column(
        db.Numeric(10, 3),
        info="avoir fiscal du produit dont le cfin est anprconst.cocfinsj (table anprconst)",
    )
    prprogress = db.Column(
        db.Numeric(10, 3),
        info="progression du produit dont le cfin est anprconst.cocfinsj (table anprconst)",
    )
    prprime = db.Column(
        db.Numeric(10, 5),
        info="r¿sultat : prime de risque du produit dont le cfin est anprconst.cocfinsj (table anprconst)",
    )


class CalAttribut(db.Model):
    __tablename__ = "cal_attributs"
    __table_args__ = {"schema": "analyse"}

    att_cfinevt = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    att_type = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    att_valeur = db.Column(db.String(50))
    att_ordre = db.Column(
        db.Numeric(3, 0, asdecimal=False), server_default=db.FetchedValue()
    )


class CalCategorie(db.Model):
    __tablename__ = "cal_categorie"
    __table_args__ = {"schema": "analyse"}

    cat_code = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    cat_libfr = db.Column(db.String(50))
    cat_libuk = db.Column(db.String(50))


class CalChiffresTypevaleur(db.Model):
    __tablename__ = "cal_chiffres_typevaleur"
    __table_args__ = {"schema": "analyse"}

    dic_indicateur = db.Column(db.Numeric(4, 0, asdecimal=False))
    tyv_code = db.Column(db.Numeric(4, 0, asdecimal=False))


class CalCompo(db.Model):
    __tablename__ = "cal_compo"
    __table_args__ = {"schema": "analyse"}

    com_cin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    com_cout = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    com_type = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    com_ordre = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )


class CalCompofiltre(db.Model):
    __tablename__ = "cal_compofiltre"
    __table_args__ = {"schema": "analyse"}

    cfcodefiltre = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cftype = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cfcodeprop = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )


class CalCompoliste(db.Model):
    __tablename__ = "cal_compoliste"
    __table_args__ = {"schema": "analyse"}

    com_code = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    com_libfr = db.Column(db.String(50))
    com_libuk = db.Column(db.String(50))
    com_ordre = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    com_indicateur = db.Column(db.Numeric(8, 0, asdecimal=False))


class CalDescattribut(db.Model):
    __tablename__ = "cal_descattributs"
    __table_args__ = {"schema": "analyse"}

    des_type = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    des_libfr = db.Column(db.String(50))
    des_libuk = db.Column(db.String(50))


class CalDico(db.Model):
    __tablename__ = "cal_dico"
    __table_args__ = {"schema": "analyse"}

    dico_code = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    dico_nom = db.Column(db.String(80))
    dico_libellefr = db.Column(db.String(80))
    dico_libellegb = db.Column(db.String(80))
    dico_ordre = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )


class CalDicochiffre(db.Model):
    __tablename__ = "cal_dicochiffres"
    __table_args__ = {"schema": "analyse"}

    dic_indicateur = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    dic_codesake = db.Column(db.Numeric(8, 0, asdecimal=False))
    dic_libfr = db.Column(db.String(50))
    dic_libuk = db.Column(db.String(50))


class CalDomaine(db.Model):
    __tablename__ = "cal_domaine"
    __table_args__ = {"schema": "analyse"}

    dom_code = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    dom_libfr = db.Column(db.String(50))
    dom_libuk = db.Column(db.String(50))


class CalEvenement(db.Model):
    __tablename__ = "cal_evenements"
    __table_args__ = {"schema": "analyse"}

    evt_cfinevt = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    evt_typeevt = db.Column(db.Numeric(3, 0, asdecimal=False))
    evt_fuseau = db.Column(db.Numeric(3, 0, asdecimal=False))
    evt_datedeb = db.Column(db.DateTime)
    evt_typeheuredeb = db.Column(db.Numeric(3, 0, asdecimal=False))
    evt_datefin = db.Column(db.DateTime)
    evt_typeheurefin = db.Column(db.Numeric(3, 0, asdecimal=False))
    evt_statut = db.Column(db.Numeric(2, 0, asdecimal=False))
    evt_datecreation = db.Column(db.DateTime)
    evt_datemaj = db.Column(db.DateTime)
    evt_usercreation = db.Column(db.Numeric(8, 0, asdecimal=False))
    evt_exercice = db.Column(db.DateTime)
    evt_typeventil = db.Column(db.Numeric(asdecimal=False))
    evt_periode = db.Column(db.Numeric(4, 0, asdecimal=False))
    evt_cfin = db.Column(db.Numeric(8, 0, asdecimal=False))
    evt_titrefr = db.Column(db.String(255))
    evt_titreuk = db.Column(db.String(255))
    evt_lieu = db.Column(db.String(100))
    evt_usermaj = db.Column(db.Numeric(8, 0, asdecimal=False))
    evt_isalinkedevt = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    evt_cfinlinkedevt = db.Column(db.Numeric(8, 0, asdecimal=False))
    evt_numtel = db.Column(db.String(100))
    evt_source = db.Column(
        db.Numeric(3, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    evt_titreukcourt = db.Column(db.String(100))
    evt_titrefrcourt = db.Column(db.String(100))
    evt_visibilite = db.Column(
        db.Numeric(2, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    evt_lockdate = db.Column(db.DateTime)
    evt_lockuser = db.Column(db.Integer)
    evt_newfuseau = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="ID du fuseau horaire utilisé par le CALFI Outlook en remplacement de EVT_FUSEAU qui est toujours NULL ie CET",
    )


class CalEvtcfin(db.Model):
    __tablename__ = "cal_evtcfin"
    __table_args__ = {"schema": "analyse"}

    ecf_cfinevt = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ecf_cfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ecf_typecfin = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )


class CalEvtcompocomment(db.Model):
    __tablename__ = "cal_evtcompocomment"
    __table_args__ = {"schema": "analyse"}

    ecc_cfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ecc_pos = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    ecc_titre = db.Column(db.String(50))
    ecc_comment = db.Column(db.String(2000))


class CalEvtcompoevt(db.Model):
    __tablename__ = "cal_evtcompoevt"
    __table_args__ = {"schema": "analyse"}

    eca_cfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    eca_evt = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    eca_ordre = db.Column(db.Numeric(3, 0, asdecimal=False))


class CalEvtrelation(db.Model):
    __tablename__ = "cal_evtrelation"
    __table_args__ = {"schema": "analyse"}

    evr_evtcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    evr_typerel = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    evr_cfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    evr_param = db.Column(db.Numeric(3, 0, asdecimal=False))
    evr_ordre = db.Column(db.Numeric(3, 0, asdecimal=False))
    evr_collection = db.Column(db.Numeric(3, 0, asdecimal=False))


class CalEvtrelationtype(db.Model):
    __tablename__ = "cal_evtrelationtype"
    __table_args__ = {"schema": "analyse"}

    ert_codetyperel = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    ert_libelle = db.Column(db.String(50))


class CalFiltre(db.Model):
    __tablename__ = "cal_filtre"
    __table_args__ = {"schema": "analyse"}

    ficode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    fival = db.Column(db.Text)
    fidate = db.Column(db.DateTime)
    finom = db.Column(db.String(30))
    ficreateur = db.Column(db.Numeric(8, 0, asdecimal=False))
    fitype = db.Column(db.Numeric(3, 0, asdecimal=False))
    firemarque = db.Column(db.String(1000))
    fimyteam = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    fimydata = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )


class CalFuseauhoraire(db.Model):
    __tablename__ = "cal_fuseauhoraire"
    __table_args__ = {"schema": "analyse"}

    fus_code = db.Column(db.Numeric(4, 0, asdecimal=False), primary_key=True)
    fus_libfr = db.Column(db.String(50))
    fus_libuk = db.Column(db.String(50))
    pacode = db.Column(db.Numeric(8, 0, asdecimal=False))
    fus_fuseau = db.Column(db.Numeric(2, 0, asdecimal=False))
    fus_windowsid = db.Column(
        db.String(100),
        info="ID Windows de la timezone. ex : Central European Standard Time",
    )
    fus_bias = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="delta en minutes de la time zone par rapport à UTC",
    )


class CalImpact(db.Model):
    __tablename__ = "cal_impacts"
    __table_args__ = {"schema": "analyse"}

    imp_cfinevt = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    imp_cfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    imp_typecfin = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    imp_libfr = db.Column(db.String(50))
    imp_libuk = db.Column(db.String(50))


class CalLibevt(db.Model):
    __tablename__ = "cal_libevt"
    __table_args__ = {"schema": "analyse"}

    lib_cfinevt = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    lib_langue = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )
    lib_datemaj = db.Column(db.DateTime)
    lib_usermaj = db.Column(db.Numeric(4, 0, asdecimal=False))
    lib_libelle = db.Column(db.String(2000))
    lib_statut = db.Column(db.Numeric(3, 0, asdecimal=False))
    lib_type = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        server_default=db.FetchedValue(),
    )


class CalLiendoc(db.Model):
    __tablename__ = "cal_liendoc"
    __table_args__ = {"schema": "analyse"}

    ld_cfinevt = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    ld_fichier = db.Column(db.String(255))


class CalListe(db.Model):
    __tablename__ = "cal_liste"
    __table_args__ = {"schema": "analyse"}

    lis_code = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    lis_libfr = db.Column(db.String(50))
    lis_libuk = db.Column(db.String(50))
    lis_typesoc = db.Column(db.Numeric(8, 0, asdecimal=False))
    lis_typeevt = db.Column(db.Numeric(3, 0, asdecimal=False))


class CalMailalerte(db.Model):
    __tablename__ = "cal_mailalerte"
    __table_args__ = {"schema": "analyse"}

    macfinevt = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    maalert = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    madateenvoi = db.Column(db.DateTime)
    mauserenvoi = db.Column(db.String(15))
    maanalyste = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )


class CalMailprofdef(db.Model):
    __tablename__ = "cal_mailprofdef"
    __table_args__ = {"schema": "analyse"}

    maprofil = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    maalert = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )


class CalMailprofil(db.Model):
    __tablename__ = "cal_mailprofil"
    __table_args__ = {"schema": "analyse"}

    mpuser = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    mpprofil = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    mpcontext = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )


class CalParticipant(db.Model):
    __tablename__ = "cal_participants"
    __table_args__ = {"schema": "analyse"}

    par_cfinevt = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    par_codeuser = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )


class CalPeriode(db.Model):
    __tablename__ = "cal_periode"
    __table_args__ = {"schema": "analyse"}

    per_code = db.Column(db.Numeric(4, 0, asdecimal=False), nullable=False)
    per_libfr = db.Column(db.String(10))
    per_liben = db.Column(db.String(10))
    per_ordre = db.Column(db.Numeric(2, 0, asdecimal=False))


class CalProfil(db.Model):
    __tablename__ = "cal_profil"
    __table_args__ = {"schema": "analyse"}

    cpuser = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cpprofil = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cpcontext = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )


class CalProfilFiltre(db.Model):
    __tablename__ = "cal_profil_filtre"
    __table_args__ = {"schema": "analyse"}

    cpfprofil = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cpffiltre = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )


class CalProfildico(db.Model):
    __tablename__ = "cal_profildico"
    __table_args__ = {"schema": "analyse"}

    cpdcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    cpdlibellefr = db.Column(db.String(50))
    cpdlibelleuk = db.Column(db.String(50))
    cpcontext = db.Column(db.Numeric(3, 0, asdecimal=False))


class CalStatu(db.Model):
    __tablename__ = "cal_status"
    __table_args__ = {"schema": "analyse"}

    sta_code = db.Column(db.Numeric(2, 0, asdecimal=False), primary_key=True)
    sta_libfr = db.Column(db.String(50))
    sta_libuk = db.Column(db.String(50))
    sta_comment = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )


class CalTreeview(db.Model):
    __tablename__ = "cal_treeview"
    __table_args__ = {"schema": "analyse"}

    trv_position = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    trv_niveau = db.Column(db.Numeric(3, 0, asdecimal=False), nullable=False)
    trv_codetypeven = db.Column(db.Numeric(3, 0, asdecimal=False))
    trv_libellefr = db.Column(db.String(70))
    trv_libelleuk = db.Column(db.String(70))
    trv_tooltiptext = db.Column(db.String(50))
    trv_typeuser = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )


class CalTypeevt(db.Model):
    __tablename__ = "cal_typeevt"
    __table_args__ = {"schema": "analyse"}

    tev_code = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tev_libfr = db.Column(db.String(50))
    tev_libuk = db.Column(db.String(50))
    tev_domaine = db.Column(db.Numeric(3, 0, asdecimal=False))
    tev_categorie = db.Column(db.Numeric(3, 0, asdecimal=False))
    tev_isalinkedtype = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    tev_libfrcourt = db.Column(db.String(100))
    tev_libukcourt = db.Column(db.String(100))
    tev_couleur = db.Column(
        db.Numeric(3, 0, asdecimal=False), server_default=db.FetchedValue()
    )


class CalTypevaleur(db.Model):
    __tablename__ = "cal_typevaleur"
    __table_args__ = {"schema": "analyse"}

    tyv_code = db.Column(db.Numeric(4, 0, asdecimal=False), primary_key=True)
    tyv_libfr = db.Column(db.String(50))
    tyv_libuk = db.Column(db.String(50))


class ContribCode(db.Model):
    __tablename__ = "contrib_codes"
    __table_args__ = {"schema": "analyse"}

    cc_exane_code = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cc_langue = db.Column(db.String(2), primary_key=True, nullable=False)
    cc_ext_code = db.Column(db.Numeric(5, 0, asdecimal=False))
    cc_type = db.Column(db.Numeric(4, 0, asdecimal=False))


class ContribSynopsi(db.Model):
    __tablename__ = "contrib_synopsis"
    __table_args__ = {"schema": "analyse"}

    cs_exane_code = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    cs_syn_fr = db.Column(db.String(2000))
    cs_syn_uk = db.Column(db.String(2000))
    cs_type = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    cfichierfr = db.Column(db.String(255))
    cfichieruk = db.Column(db.String(255))


class Contribution(db.Model):
    __tablename__ = "contribution"
    __table_args__ = {"schema": "analyse"}

    cofin = db.Column(db.String(12), primary_key=True, nullable=False)
    coext = db.Column(db.String(12), primary_key=True, nullable=False)
    cotype = db.Column(db.String(2), primary_key=True, nullable=False)
    cosource = db.Column(db.String(2))
    codate = db.Column(db.DateTime)
    couser = db.Column(db.String(40))
    cotitre = db.Column(db.String(60))
    coetat = db.Column(db.String(2))
    cocomment = db.Column(db.String(10))


class Dcaffectationattr(db.Model):
    __tablename__ = "dcaffectationattr"
    __table_args__ = {"schema": "analyse"}

    dccode1 = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    dccode2 = db.Column(db.Numeric(8, 0, asdecimal=False))
    dctypeobj = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    dcattr = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    dcattrval = db.Column(db.Float)
    dcattrvalstr = db.Column(db.Text)
    dcattrvaldate = db.Column(db.DateTime)
    dccomment = db.Column(db.String(300))


class Dcatome(db.Model):
    __tablename__ = "dcatomes"
    __table_args__ = {"schema": "analyse"}

    dcatcode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    dcatlibelle = db.Column(db.String(255))
    dcatparametres = db.Column(db.String(1000))


class Dcattrfctiongrille(db.Model):
    __tablename__ = "dcattrfctiongrille"
    __table_args__ = {"schema": "analyse"}

    dccodegrille = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    dcposition = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    dcattr = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    dcattrval = db.Column(db.Float)
    dcattrvalstr = db.Column(db.Text)
    dcattrvaldate = db.Column(db.DateTime)
    dccomment = db.Column(db.String(300))


class Dcattribut(db.Model):
    __tablename__ = "dcattribut"
    __table_args__ = {"schema": "analyse"}

    dccode = db.Column(db.Numeric(asdecimal=False), primary_key=True, nullable=False)
    dcname = db.Column(db.String(80), primary_key=True, nullable=False)
    dctypeatt = db.Column(db.Numeric(asdecimal=False), nullable=False)
    dccomment = db.Column(db.String(300))


class Dcbnmodifiessake(db.Model):
    __tablename__ = "dcbnmodifiessake"
    __table_args__ = {"schema": "analyse"}

    mocfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Cfin de la societe",
    )
    moexercice = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Exercice de la societe",
    )
    modevise = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        nullable=False,
        info="Devise de movalchangement",
    )
    modate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date de modification"
    )
    movalchangement = db.Column(db.Numeric(16, 5), info="Valeur ` la date modate")
    motypechangement = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="1->BN, 2->BPA",
    )
    modatemaj = db.Column(db.DateTime, info="Date de maj par le batch")


class Dccolonne(db.Model):
    __tablename__ = "dccolonne"
    __table_args__ = {"schema": "analyse"}

    dccode = db.Column(db.Numeric(8, 0, asdecimal=False))
    dclibellefr = db.Column(db.String(100))
    dclibellegb = db.Column(db.String(100))


class Dccompoattribut(db.Model):
    __tablename__ = "dccompoattribut"
    __table_args__ = {"schema": "analyse"}

    dccode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    dcordre = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    dclib = db.Column(db.String(80))
    dcval = db.Column(db.Numeric(8, 0, asdecimal=False))
    dcvalstr = db.Column(db.String(100))
    dcvaldate = db.Column(db.DateTime)


class Dccompogrille(db.Model):
    __tablename__ = "dccompogrille"
    __table_args__ = {"schema": "analyse"}

    dccodegrille = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    dcposition = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    dclibellefr = db.Column(db.String(80))
    dclibellegb = db.Column(db.String(80))
    dcidfonctionsake = db.Column(db.Numeric(8, 0, asdecimal=False))
    dcparamfonction = db.Column(db.String(500))
    dcprecision = db.Column(db.Numeric(1, 0, asdecimal=False))
    dchref = db.Column(db.String(200))
    dcaffiche = db.Column(db.Numeric(1, 0, asdecimal=False))
    dcgrilleliee = db.Column(db.Numeric(8, 0, asdecimal=False))
    dcgrilleaffichage = db.Column(db.Numeric(8, 0, asdecimal=False))
    dcformataffichage = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="0 affichage normal, 1 en gras, 2 en italique, 3 en italique et gras",
    )
    dccomment = db.Column(db.String(300))
    dcmasqueaffichage = db.Column(db.String(50))
    dctypetri = db.Column(
        db.Numeric(2, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    dcparamtri = db.Column(db.String(500))
    dcalign = db.Column(db.Numeric(1, 0, asdecimal=False))
    dclibellecourtfr = db.Column(db.String(80))
    dclibellecourtgb = db.Column(db.String(80))
    dcidfonctiongrille = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )


class Dccompoliste(db.Model):
    __tablename__ = "dccompoliste"
    __table_args__ = {"schema": "analyse"}

    dclliste = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    dclordre = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    dclindicateur = db.Column(db.Numeric(8, 0, asdecimal=False))
    dcltypedevise = db.Column(db.Numeric(4, 0, asdecimal=False))
    dcltyperatio = db.Column(db.Numeric(1, 0, asdecimal=False))
    dclannualisation = db.Column(db.Numeric(1, 0, asdecimal=False))
    dcltypecours = db.Column(db.Numeric(1, 0, asdecimal=False))
    dcllibellefr = db.Column(db.String(80))
    dcllibellegb = db.Column(db.String(80))
    dclfctderive = db.Column(db.Numeric(1, 0, asdecimal=False))
    dclformat = db.Column(db.Numeric(2, 0, asdecimal=False))
    dcltypesociete = db.Column(db.Numeric(8, 0, asdecimal=False))
    dclannee = db.Column(db.Numeric(4, 0, asdecimal=False))
    dclparamsplit = db.Column(db.Numeric(3, 0, asdecimal=False))
    dclprecision = db.Column(db.Numeric(2, 0, asdecimal=False))
    dclatomes = db.Column(db.Numeric(8, 0, asdecimal=False))
    dclresumemode = db.Column(db.String(1), info="Ligne affichable en mode résumé ?")


class Dccompopage(db.Model):
    __tablename__ = "dccompopage"
    __table_args__ = {"schema": "analyse"}

    dccodepage = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de la page, lié avec DCPAGE",
    )
    dccodegrille = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="à la page, lié avec DCGRILLE",
    )
    dclibellegrillefr = db.Column(
        db.String(100), info="Permet la surcharde du libelleFR de la grille"
    )
    dclibellegrilleuk = db.Column(
        db.String(100), info="Permet la surcharge du libelleUK de la grille"
    )
    dcgrillefigee = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="équivalent à la notion de colonnes ou lignes figés dans EXCEL. 1 si la grille est figée, 0 sinon",
    )
    dcordre = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Classement de la grille dans la page",
    )


class Dcdico(db.Model):
    __tablename__ = "dcdico"
    __table_args__ = {"schema": "analyse"}

    dccode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    dclibellefr = db.Column(db.String(100), nullable=False)
    dclibelleuk = db.Column(db.String(100), nullable=False)


class Dcenumgrille(db.Model):
    __tablename__ = "dcenumgrille"
    __table_args__ = {"schema": "analyse"}

    dccode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    dclibelle = db.Column(db.String(100))


class Dcfonctionsakesyno(db.Model):
    __tablename__ = "dcfonctionsakesyno"
    __table_args__ = {"schema": "analyse"}

    dccodefonction = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    dclibellefr = db.Column(db.String(100), nullable=False, unique=True)
    dclibelleuk = db.Column(db.String(100), nullable=False, unique=True)


class Dcgrille(db.Model):
    __tablename__ = "dcgrille"
    __table_args__ = {"schema": "analyse"}

    dccode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    dclibellefr = db.Column(db.String(80))
    dclibellegb = db.Column(db.String(80))
    dccommentaire = db.Column(db.String(300))
    dcperimetre = db.Column(db.Numeric(8, 0, asdecimal=False))


class Dcgrilleliee(db.Model):
    __tablename__ = "dcgrilleliee"
    __table_args__ = {"schema": "analyse"}

    glcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de la société ou du secteur",
    )
    glcodegrille = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de la grille",
    )
    glordre = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        server_default=db.FetchedValue(),
        info="Ordre de la grille parmis les grilles associées à une société/un secteur",
    )


class Dcliste(db.Model):
    __tablename__ = "dclistes"
    __table_args__ = {"schema": "analyse"}

    dlicode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    dliuser = db.Column(db.Numeric(3, 0, asdecimal=False))
    dlilibellefr = db.Column(db.String(40))
    dlilibellegb = db.Column(db.String(40))
    dlitypesociete = db.Column(db.Numeric(8, 0, asdecimal=False))
    dlitypegrille = db.Column(db.Numeric(3, 0, asdecimal=False))


class Dcpage(db.Model):
    __tablename__ = "dcpage"
    __table_args__ = {"schema": "analyse"}

    dccode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Code de la page"
    )
    dclibellefr = db.Column(db.String(100), info="LibelleFR de la page")
    dccommentaire = db.Column(
        db.String(255), info="Commentaire non utilisé par le framework"
    )
    dclibellegb = db.Column(db.String(100))


class GraphCompo(db.Model):
    __tablename__ = "graph_compo"
    __table_args__ = {"schema": "analyse"}

    gc_cfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    gc_code = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    gc_ordre = db.Column(
        db.Numeric(4, 0, asdecimal=False), primary_key=True, nullable=False
    )
    gc_type = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    gc_parametre = db.Column(db.Numeric(8, 0, asdecimal=False))


class GraphEnum(db.Model):
    __tablename__ = "graph_enum"
    __table_args__ = {"schema": "analyse"}

    gse_code = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    gse_name = db.Column(db.String(50))
    gse_comment = db.Column(db.String(100))
    gse_typesociete = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    gse_visible = db.Column(db.Numeric(1, 0, asdecimal=False))
    gse_namexl = db.Column(db.String(50))


class GraphParametre(db.Model):
    __tablename__ = "graph_parametres"
    __table_args__ = {"schema": "analyse"}

    gs_cfin = db.Column(db.String(6), primary_key=True, nullable=False)
    gs_type = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, nullable=False
    )
    gs_datedeb = db.Column(db.DateTime)
    gs_datefin = db.Column(db.DateTime)
    gs_minig = db.Column(db.Numeric(13, 5))
    gs_maxig = db.Column(db.Numeric(13, 5))
    gs_uniteg = db.Column(db.Numeric(13, 5))
    gs_minid = db.Column(db.Numeric(13, 5))
    gs_maxid = db.Column(db.Numeric(13, 5))
    gs_united = db.Column(db.Numeric(13, 5))
    gs_rem = db.Column(db.String(50))


class HistoOpinion(db.Model):
    __tablename__ = "histo_opinion"
    __table_args__ = {"schema": "analyse"}

    opcfin = db.Column(
        db.Numeric(6, 0, asdecimal=False), info="Code CFIN de la valeur concernee"
    )
    opinion_old = db.Column(db.String(20), info="Nouvelle opinion")
    opinion_new = db.Column(db.String(20), info="Ancienne opinion")
    opdate = db.Column(db.DateTime)


class Historique(db.Model):
    __tablename__ = "historique"
    __table_args__ = (
        db.Index("id_histori", "fin_exer", "hicfin", "date_mod"),
        {"schema": "analyse"},
    )

    hicfin = db.Column(
        db.Numeric(15, 0, asdecimal=False), info="Code CFIN de la valeur"
    )
    fin_exer = db.Column(db.DateTime)
    date_mod = db.Column(
        db.DateTime,
        info="Date de fin de validite des modifications (i.e nouvelle modification apportee)",
    )
    opinion = db.Column(db.String(20))
    benefice = db.Column(db.Numeric(9, 2), info="Benefice Net")
    bpa = db.Column(db.Numeric(9, 2), info="Benefice Par Action")
    decote = db.Column(db.Numeric(9, 2), info="Decote de la valeur")
    per_rel = db.Column(db.Numeric(9, 2), info="PER relatif")
    per_abs = db.Column(db.Numeric(9, 2), info="PER absolu")
    p_cf = db.Column(db.Numeric(9, 2), info="Price / Cash Flow")
    rendemen = db.Column(db.Numeric(9, 2), info="Rendement de la valeur")
    cfpa = db.Column(db.Numeric(9, 2), info="Cash Flow Par Action")
    anpa = db.Column(db.Numeric(9, 2), info="Actif Net Par Action")
    bn_mo = db.Column(db.Numeric(9, 2))
    bpa_mo = db.Column(db.Numeric(9, 2))
    date_cre = db.Column(
        db.DateTime, info="Date de debut de validite des modifications "
    )
    bpa_surv = db.Column(db.Numeric(9, 2), info="BPA integrant la survaleur")
    dfnpa = db.Column(db.Numeric(9, 2), info="Dette Financiere Nette Par Action")
    p_repa = db.Column(db.Numeric(9, 2))


class IbesActualsFile(db.Model):
    __tablename__ = "ibes_actuals_file"
    __table_args__ = {"schema": "analyse"}

    af_ibes_ticker = db.Column(db.String(6), primary_key=True, nullable=False)
    af_measure = db.Column(db.String(6), primary_key=True, nullable=False)
    af_fiscal_period = db.Column(db.String(3), primary_key=True, nullable=False)
    af_fiscal_period_year = db.Column(db.String(4), primary_key=True, nullable=False)
    af_fiscal_period_month = db.Column(db.String(2), primary_key=True, nullable=False)
    af_entry_date = db.Column(db.DateTime)
    af_actual_value = db.Column(db.Numeric(12, 3))
    af_surprise_mean = db.Column(db.Numeric(12, 3))
    af_surprise_number_of_ests = db.Column(db.Numeric(4, 0, asdecimal=False))
    af_standard_deviation = db.Column(db.Numeric(12, 3))
    af_status_flag = db.Column(db.String(1))
    af_currency_at_cie_level = db.Column(db.String(3))
    af_bd_flag = db.Column(db.String(1))
    af_dilution_factor = db.Column(db.Numeric(3, 2))
    af_date_maj = db.Column(db.DateTime)


class IbesBrokerFile(db.Model):
    __tablename__ = "ibes_broker_file"
    __table_args__ = {"schema": "analyse"}

    bf_estimator_code = db.Column(db.String(8), primary_key=True)
    bf_estimator_name = db.Column(db.String(40))
    bf_estimator_status = db.Column(db.String(3))
    bf_entry_date = db.Column(db.DateTime)
    bf_reserved = db.Column(db.String(10))
    bf_date_maj = db.Column(db.DateTime)


class IbesCountry(db.Model):
    __tablename__ = "ibes_country"
    __table_args__ = {"schema": "analyse"}

    co_country_code = db.Column(db.String(2), primary_key=True)
    co_country_lng_name = db.Column(db.String(32))
    co_reserved = db.Column(db.String(64))
    co_date_maj = db.Column(db.DateTime)


class IbesCpyExpectedReportDate(db.Model):
    __tablename__ = "ibes_cpy_expected_report_date"
    __table_args__ = {"schema": "analyse"}

    cerd_ibes_ticker = db.Column(db.String(6), primary_key=True, nullable=False)
    cerd_measure = db.Column(db.String(6), primary_key=True, nullable=False)
    cerd_fiscal_period = db.Column(db.String(3), primary_key=True, nullable=False)
    cerd_fiscal_qt1_end_date = db.Column(db.DateTime)
    cerd_fiscal_qt1_exp_rep_date = db.Column(db.DateTime)
    cerd_fiscal_qt2_end_date = db.Column(db.DateTime)
    cerd_fiscal_qt2_exp_rep_date = db.Column(db.DateTime)
    cerd_fiscal_qt1_status_flag = db.Column(db.String(1))
    cerd_fiscal_qt2_status_flag = db.Column(db.String(1))
    cerd_reserved = db.Column(db.String(8))
    cerd_date_maj = db.Column(db.DateTime)


class IbesCurrency(db.Model):
    __tablename__ = "ibes_currency"
    __table_args__ = {"schema": "analyse"}

    cu_currency_code = db.Column(db.String(3), primary_key=True)
    cu_currency_lng_name = db.Column(db.String(25))
    cu_representation = db.Column(db.String(1))
    cu_reserved = db.Column(db.String(68))
    cu_date_maj = db.Column(db.DateTime)


class IbesDelDetailFootnoteFile(db.Model):
    __tablename__ = "ibes_del_detail_footnote_file"
    __table_args__ = {"schema": "analyse"}

    ddff_ibes_ticker = db.Column(db.String(6), primary_key=True, nullable=False)
    ddff_measure = db.Column(db.String(6), primary_key=True, nullable=False)
    ddff_fiscal_period = db.Column(db.String(3), primary_key=True, nullable=False)
    ddff_fiscal_period_year = db.Column(db.String(4), primary_key=True, nullable=False)
    ddff_forecast_period_month = db.Column(
        db.String(2), primary_key=True, nullable=False
    )
    ddff_estimator = db.Column(db.String(8), primary_key=True, nullable=False)
    ddff_analyst_name = db.Column(db.String(17))
    ddff_footnote_type = db.Column(db.String(1))
    ddff_entry_date = db.Column(db.DateTime, primary_key=True, nullable=False)
    ddff_analyst_code = db.Column(db.Numeric(6, 0, asdecimal=False))
    ddff_reserved = db.Column(db.String(3))
    ddff_date_maj = db.Column(db.DateTime)
    ddff_flag_maj = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )


class IbesDeleteEstimatesFile(db.Model):
    __tablename__ = "ibes_delete_estimates_file"
    __table_args__ = {"schema": "analyse"}

    dlef_ibes_ticker = db.Column(db.String(6), primary_key=True, nullable=False)
    dlef_measure = db.Column(db.String(6), primary_key=True, nullable=False)
    dlef_fiscal_period = db.Column(db.String(3), primary_key=True, nullable=False)
    dlef_fiscal_period_year = db.Column(db.String(4), primary_key=True, nullable=False)
    dlef_fiscal_period_month = db.Column(db.String(2), primary_key=True, nullable=False)
    dlef_forecast_period_ind = db.Column(db.String(1))
    dlef_estimator = db.Column(db.String(8), primary_key=True, nullable=False)
    dlef_analyst_name = db.Column(db.String(17))
    dlef_est_entry_date = db.Column(db.DateTime, primary_key=True, nullable=False)
    dlef_val = db.Column(db.Numeric(12, 3))
    dlef_est_bd_flag = db.Column(db.String(1))
    dlef_est_currency = db.Column(db.String(3))
    dlef_analyst_code = db.Column(db.Numeric(6, 0, asdecimal=False))
    dlef_reserved = db.Column(db.String(3))
    dlef_date_maj = db.Column(db.DateTime)
    dlef_flag_maj = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )


class IbesDeleteRecoFile(db.Model):
    __tablename__ = "ibes_delete_reco_file"
    __table_args__ = {"schema": "analyse"}

    dlrf_ibes_ticker = db.Column(db.String(6), primary_key=True, nullable=False)
    dlrf_estimator = db.Column(db.String(8), primary_key=True, nullable=False)
    dlrf_analyst_name = db.Column(db.String(17))
    dlrf_entry_date = db.Column(db.DateTime, primary_key=True, nullable=False)
    dlrf_analyst_code = db.Column(db.Numeric(6, 0, asdecimal=False))
    dlrf_reserved = db.Column(db.String(3))
    dlrf_date_maj = db.Column(db.DateTime)
    dlrf_flag_maj = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )


class IbesDeleteTargetPriceFile(db.Model):
    __tablename__ = "ibes_delete_target_price_file"
    __table_args__ = {"schema": "analyse"}

    dltpf_ibes_ticker = db.Column(db.String(6), primary_key=True, nullable=False)
    dltpf_estimator = db.Column(db.String(8), primary_key=True, nullable=False)
    dltpf_analyst_name = db.Column(db.String(17))
    dltpf_horizon = db.Column(db.String(3))
    dltpf_value = db.Column(db.Numeric(9, 3))
    dltpf_entry_date = db.Column(db.DateTime, primary_key=True, nullable=False)
    dltpf_analyst_code = db.Column(db.Numeric(6, 0, asdecimal=False))
    dltpf_reserved = db.Column(db.String(3))
    dltpf_date_maj = db.Column(db.DateTime)
    dltpf_flag_maj = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )


class IbesDetailEstimatesFile(db.Model):
    __tablename__ = "ibes_detail_estimates_file"
    __table_args__ = {"schema": "analyse"}

    def_ibes_ticker = db.Column(db.String(6), primary_key=True, nullable=False)
    def_measure = db.Column(db.String(6), primary_key=True, nullable=False)
    def_fiscal_period = db.Column(db.String(3), primary_key=True, nullable=False)
    def_fiscal_period_year = db.Column(db.String(4), primary_key=True, nullable=False)
    def_fiscal_period_month = db.Column(db.String(2), primary_key=True, nullable=False)
    def_forecast_period_ind = db.Column(db.String(1))
    def_estimator = db.Column(db.String(8), primary_key=True, nullable=False)
    def_analyst_name = db.Column(db.String(17))
    def_curr_est_val = db.Column(db.Numeric(13, 3))
    def_curr_est_entry_date = db.Column(db.DateTime, primary_key=True, nullable=False)
    def_curr_est_bd_flag = db.Column(db.String(1))
    def_curr_est_exclude_flag = db.Column(db.String(1))
    def_curr_est_currency = db.Column(db.String(3))
    def_curr_est_status = db.Column(db.String(1))
    def_prev_est_val = db.Column(db.Numeric(13, 3))
    def_prev_est_entry_date = db.Column(db.DateTime)
    def_prev_bd_flag = db.Column(db.String(1))
    def_prev_est_exclude_flag = db.Column(db.String(1))
    def_prev_est_currency = db.Column(db.String(3))
    def_prev_est_status = db.Column(db.String(1))
    def_analyst_code = db.Column(db.Numeric(6, 0, asdecimal=False))
    def_currency_cie_lvl = db.Column(db.String(3))
    def_date_maj = db.Column(db.DateTime)
    def_flag_maj = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )


class IbesDetailFootnoteFile(db.Model):
    __tablename__ = "ibes_detail_footnote_file"
    __table_args__ = {"schema": "analyse"}

    dff_ibes_ticker = db.Column(db.String(6), primary_key=True, nullable=False)
    dff_measure = db.Column(db.String(6), primary_key=True, nullable=False)
    dff_fiscal_period = db.Column(db.String(3), primary_key=True, nullable=False)
    dff_fiscal_period_year = db.Column(db.String(4), primary_key=True, nullable=False)
    dff_fiscal_period_month = db.Column(db.String(2), primary_key=True, nullable=False)
    dff_forecast_period_ind = db.Column(db.String(1))
    dff_estimator = db.Column(db.String(8), primary_key=True, nullable=False)
    dff_analyst_name = db.Column(db.String(17))
    dff_est_entry_date = db.Column(db.DateTime, primary_key=True, nullable=False)
    dff_est_flag = db.Column(db.String(1))
    dff_footnote_type = db.Column(db.String(1))
    dff_entry_date = db.Column(db.DateTime, primary_key=True, nullable=False)
    dff_expiration_date = db.Column(db.DateTime)
    dff_footnote_text = db.Column(db.String(120))
    dff_analyst_code = db.Column(db.Numeric(6, 0, asdecimal=False))
    dff_reserved = db.Column(db.String(3))
    dff_date_maj = db.Column(db.DateTime)
    dff_flag_maj = db.Column(db.Numeric(1, 0, asdecimal=False))


class IbesDetailRecoFile(db.Model):
    __tablename__ = "ibes_detail_reco_file"
    __table_args__ = {"schema": "analyse"}

    drf_ibes_ticker = db.Column(db.String(6), primary_key=True, nullable=False)
    drf_estimator = db.Column(db.String(8), primary_key=True, nullable=False)
    drf_analyst_name = db.Column(db.String(17))
    drf_curr_entry_date = db.Column(db.DateTime, primary_key=True, nullable=False)
    drf_curr_estimator_code = db.Column(db.String(5))
    drf_curr_estimator_text = db.Column(db.String(20))
    drf_curr_ibes_code = db.Column(db.String(2))
    drf_curr_ibes_text = db.Column(db.String(20))
    drf_prev_entry_date = db.Column(db.DateTime)
    drf_prev_estimator_code = db.Column(db.String(5))
    drf_prev_estimator_text = db.Column(db.String(20))
    drf_prev_ibes_code = db.Column(db.String(2))
    drf_prev_ibes_text = db.Column(db.String(20))
    drf_prev_analyst_code = db.Column(db.String(6))
    drf_curr_rec_status = db.Column(db.String(1))
    drf_prev_rec_status = db.Column(db.String(1))
    drf_date_maj = db.Column(db.DateTime)
    drf_flag_maj = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )


class IbesDetailTargetPriceFile(db.Model):
    __tablename__ = "ibes_detail_target_price_file"
    __table_args__ = {"schema": "analyse"}

    dtpf_ibes_ticker = db.Column(db.String(6), primary_key=True, nullable=False)
    dtpf_estimator = db.Column(db.String(8), primary_key=True, nullable=False)
    dtpf_analyst_name = db.Column(db.String(17))
    dtpf_curr_horizon = db.Column(db.String(3))
    dtpf_curr_value = db.Column(db.Numeric(15, 3))
    dtpf_curr_est_currency = db.Column(db.String(3))
    dtpf_curr_entry_date = db.Column(db.DateTime, primary_key=True, nullable=False)
    dtpf_curr_target_status = db.Column(db.String(1))
    dtpf_prev_horizon = db.Column(db.String(3))
    dtpf_prev_value = db.Column(db.Numeric(15, 3))
    dtpf_prev_est_currency = db.Column(db.String(3))
    dtpf_prev_entry_date = db.Column(db.DateTime)
    dtpf_prev_target_status = db.Column(db.String(1))
    dtpf_analyst_code = db.Column(db.String(6))
    dtpf_currency_cie_lvl = db.Column(db.String(3))
    dtpf_reserved = db.Column(db.String(1))
    dtpf_date_maj = db.Column(db.DateTime)
    dtpf_flag_maj = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )


class IbesExpectedReportDateFile(db.Model):
    __tablename__ = "ibes_expected_report_date_file"
    __table_args__ = {"schema": "analyse"}

    erdf_ibes_ticker = db.Column(db.String(6), primary_key=True, nullable=False)
    erdf_measure = db.Column(db.String(6), primary_key=True, nullable=False)
    erdf_fiscal_period = db.Column(db.String(3), primary_key=True, nullable=False)
    erdf_fiscal_qt1_end_date = db.Column(db.DateTime)
    erdf_fiscal_qt1_exp_rep_date = db.Column(db.DateTime)
    erdf_fiscal_qt2_end_date = db.Column(db.DateTime)
    erdf_fiscal_qt2_exp_rep_date = db.Column(db.DateTime)
    erdf_reserved = db.Column(db.String(10))
    erdf_date_maj = db.Column(db.DateTime)


class IbesIdentificationFile(db.Model):
    __tablename__ = "ibes_identification_file"
    __table_args__ = {"schema": "analyse"}

    if_ibes_ticker = db.Column(db.String(6), primary_key=True)
    if_official_ticker = db.Column(db.String(6))
    if_home_market_code = db.Column(db.String(8))
    if_ibes_cusip = db.Column(db.String(8))
    if_company_name = db.Column(db.String(40))
    if_basic_diluted_ind = db.Column(db.String(1))
    if_dilution_factor = db.Column(db.Numeric(8, 3))
    if_price = db.Column(db.Numeric(10, 3))
    if_price_date = db.Column(db.DateTime)
    if_eps_data_ind = db.Column(db.Numeric(1, 0, asdecimal=False))
    if_cps_data_ind = db.Column(db.Numeric(1, 0, asdecimal=False))
    if_dps_data_ind = db.Column(db.Numeric(1, 0, asdecimal=False))
    if_pretax_profit_data_ind = db.Column(db.Numeric(1, 0, asdecimal=False))
    if_net_income_data_ind = db.Column(db.Numeric(1, 0, asdecimal=False))
    if_rec_data_ind = db.Column(db.Numeric(1, 0, asdecimal=False))
    if_shares = db.Column(db.Numeric(10, 3))
    if_date_maj = db.Column(db.DateTime)


class IbesRecoSummaryFile(db.Model):
    __tablename__ = "ibes_reco_summary_file"
    __table_args__ = {"schema": "analyse"}

    rs_ibes_ticker = db.Column(db.String(6), primary_key=True)
    rs_nb_of_rec = db.Column(db.Numeric(3, 0, asdecimal=False))
    rs_nb_of_rec_raised_4wks = db.Column(db.Numeric(3, 0, asdecimal=False))
    rs_nb_of_rec_lowered_4wks = db.Column(db.Numeric(3, 0, asdecimal=False))
    rs_rec_cons = db.Column(db.Numeric(6, 3))
    rs_reserved = db.Column(db.String(10))
    rs_date_maj = db.Column(db.DateTime)


class IbesRegion(db.Model):
    __tablename__ = "ibes_regions"
    __table_args__ = {"schema": "analyse"}

    r_country_code = db.Column(db.String(2), primary_key=True)
    r_country_lng_name = db.Column(db.String(32))
    r_region = db.Column(db.String(10))
    r_region_name = db.Column(db.String(40))
    r_reserved = db.Column(db.String(62))
    r_date_maj = db.Column(db.DateTime)


class IbesSplitFile(db.Model):
    __tablename__ = "ibes_split_file"
    __table_args__ = {"schema": "analyse"}

    s_ibes_ticker = db.Column(db.String(6), primary_key=True, nullable=False)
    s_activation_date = db.Column(db.DateTime, primary_key=True, nullable=False)
    s_split_factor = db.Column(db.Numeric(13, 5))
    s_status = db.Column(db.String(3))
    s_entry_date = db.Column(db.DateTime)
    s_entry_time = db.Column(db.String(8))
    s_reserved = db.Column(db.String(10))
    s_date_maj = db.Column(db.DateTime)


class IbesStopEstimatesFile(db.Model):
    __tablename__ = "ibes_stop_estimates_file"
    __table_args__ = {"schema": "analyse"}

    sef_ibes_ticker = db.Column(db.String(6), primary_key=True, nullable=False)
    sef_measure = db.Column(db.String(6), primary_key=True, nullable=False)
    sef_fiscal_period = db.Column(db.String(3), primary_key=True, nullable=False)
    sef_fiscal_period_year = db.Column(db.String(4), primary_key=True, nullable=False)
    sef_fiscal_period_month = db.Column(db.String(2), primary_key=True, nullable=False)
    sef_forecast_period_ind = db.Column(db.String(1))
    sef_estimator = db.Column(db.String(8), primary_key=True, nullable=False)
    sef_analyst_name = db.Column(db.String(17))
    sef_est_entry_date = db.Column(db.DateTime, primary_key=True, nullable=False)
    sef_analyst_code = db.Column(db.Numeric(6, 0, asdecimal=False))
    sef_reserved = db.Column(db.String(3))
    sef_date_maj = db.Column(db.DateTime)
    sef_flag_maj = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )


class IbesStopRecoFile(db.Model):
    __tablename__ = "ibes_stop_reco_file"
    __table_args__ = {"schema": "analyse"}

    srf_ibes_ticker = db.Column(db.String(6), primary_key=True, nullable=False)
    srf_estimator = db.Column(db.String(8), primary_key=True, nullable=False)
    srf_analyst_name = db.Column(db.String(17))
    srf_entry_date = db.Column(db.DateTime, primary_key=True, nullable=False)
    srf_analyst_code = db.Column(db.Numeric(6, 0, asdecimal=False))
    srf_reserved = db.Column(db.String(3))
    srf_date_maj = db.Column(db.DateTime)
    srf_flag_maj = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )


class IbesStopTargetPriceFile(db.Model):
    __tablename__ = "ibes_stop_target_price_file"
    __table_args__ = {"schema": "analyse"}

    stpf_ibes_ticker = db.Column(db.String(6), primary_key=True, nullable=False)
    stpf_estimator = db.Column(db.String(8), primary_key=True, nullable=False)
    stpf_analyst_name = db.Column(db.String(17))
    stpf_horizon = db.Column(db.String(3))
    stpf_value = db.Column(db.Numeric(9, 3))
    stpf_entry_date = db.Column(db.DateTime, primary_key=True, nullable=False)
    stpf_analyst_code = db.Column(db.Numeric(6, 0, asdecimal=False))
    stpf_reserved = db.Column(db.String(3))
    stpf_date_maj = db.Column(db.DateTime)
    stpf_flag_maj = db.Column(
        db.Numeric(1, 0, asdecimal=False), primary_key=True, nullable=False
    )


class IbesSummaryEstimatesFile(db.Model):
    __tablename__ = "ibes_summary_estimates_file"
    __table_args__ = {"schema": "analyse"}

    sef_ibes_ticker = db.Column(db.String(6), primary_key=True, nullable=False)
    sef_measure = db.Column(db.String(6), primary_key=True, nullable=False)
    sef_fiscal_period = db.Column(db.String(3), primary_key=True, nullable=False)
    sef_fiscal_period_year = db.Column(db.String(4), primary_key=True, nullable=False)
    sef_fiscal_period_month = db.Column(db.String(2), primary_key=True, nullable=False)
    sef_forecast_period_ind = db.Column(db.String(1))
    sef_nb_est_raised_4wks = db.Column(db.Numeric(4, 0, asdecimal=False))
    sef_nb_est_lowered_4wks = db.Column(db.Numeric(4, 0, asdecimal=False))
    sef_nb_est_raised_1mth = db.Column(db.Numeric(4, 0, asdecimal=False))
    sef_nb_est_lowered_1mth = db.Column(db.Numeric(4, 0, asdecimal=False))
    sef_mean = db.Column(db.Numeric(16, 3))
    sef_nb_est = db.Column(db.Numeric(4, 0, asdecimal=False))
    sef_median = db.Column(db.Numeric(16, 3))
    sef_standard_deviation = db.Column(db.Numeric(16, 3))
    sef_high_est = db.Column(db.Numeric(16, 3))
    sef_low_est = db.Column(db.Numeric(16, 3))
    sef_mean_4wks_ago = db.Column(db.Numeric(16, 3))
    sef_nb_est_4wks_ago = db.Column(db.Numeric(4, 0, asdecimal=False))
    sef_median_4wks_ago = db.Column(db.Numeric(16, 3))
    sef_std_deviation_4wks_ago = db.Column(db.Numeric(16, 3))
    sef_high_est_4wks_ago = db.Column(db.Numeric(16, 3))
    sef_low_est_4wks_ago = db.Column(db.Numeric(16, 3))
    sef_mean_3mths_ago = db.Column(db.Numeric(16, 3))
    sef_nb_est_3mths_ago = db.Column(db.Numeric(4, 0, asdecimal=False))
    sef_median_3mths_ago = db.Column(db.Numeric(16, 3))
    sef_std_deviation_3mths_ago = db.Column(db.Numeric(16, 3))
    sef_high_est_3mths_ago = db.Column(db.Numeric(16, 3))
    sef_low_est_3mths_ago = db.Column(db.Numeric(16, 3))
    sef_flash_mean = db.Column(db.Numeric(16, 3))
    sef_flash_nb_est = db.Column(db.Numeric(16, 3))
    sef_flash_standard_deviation = db.Column(db.Numeric(16, 3))
    sef_currency_at_cie_level = db.Column(db.String(3))
    sef_nb_est_raised_1wk = db.Column(db.Numeric(4, 0, asdecimal=False))
    sef_nb_est_lowered_1wk = db.Column(db.Numeric(4, 0, asdecimal=False))
    sef_reserved = db.Column(db.String(1))
    sef_date_maj = db.Column(db.DateTime)


class IbesSupplInfoAddFile(db.Model):
    __tablename__ = "ibes_suppl_info_add_file"
    __table_args__ = {"schema": "analyse"}

    siaf_ibes_ticker = db.Column(db.String(6), primary_key=True)
    siaf_total_return = db.Column(db.Numeric(10, 3))
    siaf_dividend_ex_date = db.Column(db.DateTime)
    siaf_price_1day_ago = db.Column(db.Numeric(10, 3))
    siaf_10th_company_flag = db.Column(db.String(1))
    siaf_wkly_chng_price_lst_mth = db.Column(db.Numeric(11, 3))
    siaf_wkly_52_wk_price_high = db.Column(db.Numeric(11, 3))
    siaf_wkly_52_wk_price_low = db.Column(db.Numeric(11, 3))
    siaf_wkly_26_wk_price = db.Column(db.Numeric(11, 3))
    siaf_wkly_10_wk_median_vol = db.Column(db.Numeric(11, 3))
    siaf_reserved = db.Column(db.String(1))
    siaf_date_maj = db.Column(db.DateTime)


class IbesSupplInformationFile(db.Model):
    __tablename__ = "ibes_suppl_information_file"
    __table_args__ = {"schema": "analyse"}

    sif_ibes_ticker = db.Column(db.String(6), primary_key=True)
    sif_indicated_annual_dividend = db.Column(db.Numeric(10, 3))
    sif_stability_5year = db.Column(db.Numeric(10, 3))
    sif_growth_5year = db.Column(db.Numeric(10, 3))
    sif_exchange_code = db.Column(db.String(1))
    sif_actual_eps_last_4quarters = db.Column(db.Numeric(10, 3))
    sif_sp_500_indicator = db.Column(db.String(1))
    sif_market_beta = db.Column(db.Numeric(10, 3))
    sif_country_id = db.Column(db.String(2))
    sif_nb_of_shares_out = db.Column(db.Numeric(10, 3))
    sif_sector_number = db.Column(db.String(2))
    sif_industry_number = db.Column(db.String(2))
    sif_group_number = db.Column(db.String(2))
    sif_sector_name = db.Column(db.String(24))
    sif_industry_name = db.Column(db.String(24))
    sif_group_name = db.Column(db.String(24))
    sif_instrument_type = db.Column(db.String(1))
    sif_date_maj = db.Column(db.DateTime)


class Lizsauvegarde(db.Model):
    __tablename__ = "lizsauvegarde"
    __table_args__ = (
        db.CheckConstraint("EXERCICE >= to_date('01011950','DDMMYYYY')\n"),
        db.CheckConstraint("EXERCICE >= to_date('01011950','DDMMYYYY')\n     "),
        {"schema": "analyse"},
    )

    exercice = db.Column(db.DateTime, primary_key=True, nullable=False)
    gesjac = db.Column(
        db.Numeric(10, 0, asdecimal=False), primary_key=True, nullable=False
    )
    gecfin = db.Column(
        db.Numeric(10, 0, asdecimal=False), primary_key=True, nullable=False
    )
    getprod = db.Column(db.Numeric(2, 0, asdecimal=False))
    gepdesc = db.Column(db.String(30))
    hicours = db.Column(db.Numeric(15, 3))
    geoutst = db.Column(db.Numeric(21, 3))
    geshperp = db.Column(db.Numeric(15, 3))
    camount = db.Column(db.Numeric(15, 3))
    wtexpri = db.Column(db.Numeric(15, 3))
    gecntr = db.Column(db.Numeric(5, 0, asdecimal=False))
    genomina = db.Column(db.Numeric(15, 3))
    flag = db.Column(db.Numeric(1, 0, asdecimal=False))


class NAttribut(db.Model):
    __tablename__ = "n_attributs"
    __table_args__ = {"schema": "analyse"}

    atcode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    attypeval = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info=" renvoie sur N_TypeValeur.tvcode ",
    )
    atlib = db.Column(db.String(80))
    atdesc = db.Column(db.String(80))


class NCompotypeval(db.Model):
    __tablename__ = "n_compotypeval"
    __table_args__ = {"schema": "analyse"}

    cvcode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cvvalattribut = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    cvordre = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    cvlibfr = db.Column(db.String(80))
    cvlibgb = db.Column(db.String(80))
    cvlibcourtfr = db.Column(db.String(80))
    cvlibcourtgb = db.Column(db.String(80))
    cvdesc = db.Column(db.String(80))


class NContrainte(db.Model):
    __tablename__ = "n_contraintes"
    __table_args__ = {"schema": "analyse"}

    cncode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    cncodeindic = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cntype = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    cnvaleur = db.Column(db.String(80))
    cncompose = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    cnordre = db.Column(db.Numeric(2, 0, asdecimal=False))
    cnlinkedcte = db.Column(db.Numeric(8, 0, asdecimal=False))
    cntypesociete = db.Column(db.Numeric(8, 0, asdecimal=False))


class NDescsociete(db.Model):
    __tablename__ = "n_descsocietes"
    __table_args__ = {"schema": "analyse"}

    dscfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    dscodeindic = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info=" renvoie sur N_Indicateur.incode ",
    )
    dsvalnum = db.Column(db.Numeric(18, 5))
    dsvalstr = db.Column(db.String(2048))
    dsvaldate = db.Column(db.DateTime)
    dschargement = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="si la ligne est chargée dans le load global ou celui de la soc ",
    )
    dsordre = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    dsdesc = db.Column(db.String(80))


class NExercice(db.Model):
    __tablename__ = "n_exercices"
    __table_args__ = {"schema": "analyse"}

    excfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    exfinexercice = db.Column(db.DateTime, primary_key=True, nullable=False)
    excodeindic = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info=" renvoie sur N_Indicateur.incode ",
    )
    exvalnum = db.Column(db.Numeric(18, 5))
    exvalstr = db.Column(db.String(80))
    exvaldate = db.Column(db.DateTime)
    exordre = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    exdesc = db.Column(db.String(80))


class NIndicateur(db.Model):
    __tablename__ = "n_indicateur"
    __table_args__ = {"schema": "analyse"}

    incode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, nullable=False
    )
    inattribut = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info=" renvoie sur N_Attributs.atcode ",
    )
    invalnum = db.Column(db.Numeric(18, 5))
    invalstr = db.Column(db.String(400))
    invaldate = db.Column(db.DateTime)
    indesc = db.Column(db.String(80))


class NTypeindicateur(db.Model):
    __tablename__ = "n_typeindicateur"
    __table_args__ = {"schema": "analyse"}

    ticode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info=" renvoie sur N_Indicateur.incode ",
    )
    titypeval = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info=" renvoie sur N_TypeValeur.tvcode ",
    )
    tidesc = db.Column(db.String(80))


class NTypevaleur(db.Model):
    __tablename__ = "n_typevaleur"
    __table_args__ = {"schema": "analyse"}

    tvcode = db.Column(db.Numeric(8, 0, asdecimal=False), primary_key=True)
    tvtype = db.Column(db.String(40), nullable=False)
    tvtypecompose = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info=" renvoie sur N_compotypeval.cvcode si tvtypecompose = 1 ",
    )
    tvdesc = db.Column(db.String(80))


class WrkModifLibel(db.Model):
    __tablename__ = "wrk_modif_libel"
    __table_args__ = {"schema": "analyse"}

    cfin = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    olddesc = db.Column(db.String(100))
    newdesc = db.Column(db.String(100))
    ref_pc = db.Column(db.String(100))
    ref_usr = db.Column(db.String(100))
    horodate = db.Column(db.DateTime)


class Famille(db.Model):
    __tablename__ = "famille"
    __table_args__ = {"schema": "exane"}

    facode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de la famille d'un type dinstruments",
    )
    fanom = db.Column(
        db.String(15), nullable=False, info="Nom de la famille d'un type dinstruments"
    )


class Instrument(db.Model):
    __tablename__ = "instruments"
    __table_args__ = (
        db.CheckConstraint(
            "IFVALIDATION = 'N' OR IFVALIDATION = 'M' OR IFVALIDATION = 'R' OR IFVALIDATION = 'V'"
        ),
        db.CheckConstraint("ifcfin <> 0"),
        db.Index("idx1_instrument", "ifcfin", "ifpayoff", "iftype"),
        {"schema": "exane"},
    )

    ifcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    ifstatut = db.Column(
        db.ForeignKey("exane.typestatut.tstcode"),
        nullable=False,
        index=True,
        info="Code du statut d'un instrument financier",
    )
    iftype = db.Column(
        db.ForeignKey("exane.typeinstrument.tycode"),
        nullable=False,
        index=True,
        info="Code du type d'instrument",
    )
    ifnom = db.Column(db.String(60), nullable=False, info="Nom de l'instrument")
    ifmaj = db.Column(
        db.DateTime, nullable=False, info="Date de mise à jour de l'instrument"
    )
    ifpayoff = db.Column(
        db.ForeignKey("exane.typepayoff.tflcode"),
        index=True,
        server_default=db.FetchedValue(),
        info="type de payoff de l'instrument",
    )
    ifcontrat = db.Column(
        db.ForeignKey("exane.typecontrat.tctcode"),
        index=True,
        server_default=db.FetchedValue(),
        info="type de contrat de l'instrument",
    )
    ifvalidation = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Gere la validation des instruments, toutes les caracteristiques du produit qui peuvent influencer le prix  agissent sur le champ IFVALIDATION",
    )
    ifproprietaire = db.Column(
        db.ForeignKey("exane.typeproprietaire.tpcode"),
        info="Propriétaire de l'instument",
    )
    iftypofo = db.Column(
        db.ForeignKey("exane.typofoinstrumentsautorisees.tacode"),
        index=True,
        info="Nouvelle typologie Front des produits cf. EXANE.TYPOFOINSTRUMENTSAUTORISEES",
    )

    typecontrat = db.relationship(
        "Typecontrat",
        primaryjoin="Instrument.ifcontrat == Typecontrat.tctcode",
        backref="instruments",
    )
    typepayoff = db.relationship(
        "Typepayoff",
        primaryjoin="Instrument.ifpayoff == Typepayoff.tflcode",
        backref="instruments",
    )
    typeproprietaire = db.relationship(
        "Typeproprietaire",
        primaryjoin="Instrument.ifproprietaire == Typeproprietaire.tpcode",
        backref="instruments",
    )
    typestatut = db.relationship(
        "Typestatut",
        primaryjoin="Instrument.ifstatut == Typestatut.tstcode",
        backref="instruments",
    )
    typeinstrument = db.relationship(
        "Typeinstrument",
        primaryjoin="Instrument.iftype == Typeinstrument.tycode",
        backref="instruments",
    )
    typofoinstrumentsautorisee = db.relationship(
        "Typofoinstrumentsautorisee",
        primaryjoin="Instrument.iftypofo == Typofoinstrumentsautorisee.tacode",
        backref="instruments",
    )


class Afsociete(Instrument):
    __tablename__ = "afsociete"
    __table_args__ = (
        db.CheckConstraint("SOOPINIONVALEUR IN (0, 1, 2, 4, 8)"),
        db.CheckConstraint("SORESULTAT12M BETWEEN 1 AND 12"),
        db.CheckConstraint("SORESULTAT6M BETWEEN 1 AND 12"),
        {"schema": "analyse"},
    )

    socfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"), primary_key=True, info="Code société"
    )
    sotypesecteur = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Type de secteur",
    )
    sodevise = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Devise de suivi",
    )
    sounite = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Unité par défaut de la société",
    )
    sodevisecompte = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Code devise de comptes",
    )
    sopdesc = db.Column(db.String(40), nullable=False, info="Nom de la société")
    socodesuivi = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Code type de suivi",
    )
    soanalysteprincipal = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Analyste principal",
    )
    soindiceref = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Indice de référence",
    )
    sosicovam = db.Column(db.Numeric(6, 0, asdecimal=False), info="Code sicovam")
    sopays = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    soreuter = db.Column(db.String(8), info="Code reuter")
    sotopval = db.Column(db.String(6), info="Code topval")
    sost_guide = db.Column(
        db.String(1), server_default=db.FetchedValue(), info="Drapeau stock guide"
    )
    sonote = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Opinion",
    )
    sosmall_st_guide = db.Column(
        db.String(1), server_default=db.FetchedValue(), info="Drapeau small stock guide"
    )
    soopinionvaleur = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    soobjhaut = db.Column(db.Numeric(7, 2), info="Objectif cours haut")
    soobjbas = db.Column(db.Numeric(7, 2), info="Objectif cours bas")
    soflottant = db.Column(
        db.Numeric(7, 2),
        server_default=db.FetchedValue(),
        info="Pourcentage de flottant",
    )
    sotypemult = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Type de multiple",
    )
    somultiple = db.Column(db.Numeric(7, 2), info="Multiple")
    sostrucfi = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Note de structure financière",
    )
    somanagement = db.Column(
        db.String(1), server_default=db.FetchedValue(), info="Note de management"
    )
    sorisquespec = db.Column(
        db.String(1), server_default=db.FetchedValue(), info="Risque spécifique"
    )
    sobigmidcap = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Définit si la société est de type Big ou Mid",
    )
    soresultat6m = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Mois du résultat semestriel",
    )
    soresultat12m = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Mois du résultat annuel",
    )
    sosensibdollar = db.Column(
        db.Numeric(9, 3),
        server_default=db.FetchedValue(),
        info="Sensibilité à une hausse de 10% du cross devise dollar",
    )
    sosensibtaux = db.Column(
        db.Numeric(9, 3),
        server_default=db.FetchedValue(),
        info="Sensibilité à une hausse de 1% des taux",
    )
    sosensibvolume = db.Column(
        db.Numeric(9, 3),
        server_default=db.FetchedValue(),
        info="Sensibilité à une hausse de 1% des volumes",
    )
    sotypesensib = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="0(C) consolidation, 1(X) exportation",
    )
    sosensibdevise = db.Column(
        db.Numeric(9, 3),
        server_default=db.FetchedValue(),
        info="Sensibilité à une baisse de 10% de la devise",
    )
    sopath = db.Column(db.String(80), info="Répertoire de stockage")
    sofile = db.Column(db.String(100), info="Fichier par défaut")
    sourl = db.Column(db.String(160), info="Addresse du site internet")
    sotypesociete = db.Column(
        db.Numeric(8, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    sotypegrille = db.Column(db.Numeric(3, 0, asdecimal=False))
    sotypevalo = db.Column(db.Numeric(2, 0, asdecimal=False))
    sovaluegrowth = db.Column(db.Numeric(2, 0, asdecimal=False))
    sodatemodif = db.Column(db.DateTime)
    sotauxltg = db.Column(db.Numeric(9, 3))
    sourlgb = db.Column(db.String(160))
    sourlprive = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    soaffecteopsecteur = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    sodilutionflag = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    anneedepartfichesoc = db.Column(db.Numeric(4, 0, asdecimal=False))
    anneefinfichesoc = db.Column(db.Numeric(4, 0, asdecimal=False))
    publierfichesoc = db.Column(
        db.Numeric(1, 0, asdecimal=False), server_default=db.FetchedValue()
    )
    somailclient = db.Column(db.String(255))
    soflottantddv = db.Column(db.Numeric(7, 2))
    sodatemodifcdc = db.Column(db.DateTime)
    socodechamp1 = db.Column(db.Numeric(8, 0, asdecimal=False))
    socodechamp2 = db.Column(db.Numeric(8, 0, asdecimal=False))
    socodechamp3 = db.Column(db.Numeric(8, 0, asdecimal=False))
    sotypepublication = db.Column(db.Numeric(2, 0, asdecimal=False))
    sogroupcomp = db.Column(db.String(40))
    sogroupcompgb = db.Column(db.String(40))
    socodechamp4 = db.Column(db.Numeric(8, 0, asdecimal=False))
    socodechamp5 = db.Column(db.Numeric(8, 0, asdecimal=False))
    sochamplibreaff1 = db.Column(db.Numeric(8, 0, asdecimal=False))
    sochamplibreaff2 = db.Column(db.Numeric(8, 0, asdecimal=False))
    sochamplibreaff3 = db.Column(db.Numeric(8, 0, asdecimal=False))
    sochamplibreaff4 = db.Column(db.Numeric(8, 0, asdecimal=False))
    sochamplibreaff5 = db.Column(db.Numeric(8, 0, asdecimal=False))
    sodesccourt = db.Column(db.String(15))
    socodechamp6 = db.Column(db.Numeric(8, 0, asdecimal=False))
    socodechamp7 = db.Column(db.Numeric(8, 0, asdecimal=False))
    socodechamp8 = db.Column(db.Numeric(8, 0, asdecimal=False))
    socodechamp9 = db.Column(db.Numeric(8, 0, asdecimal=False))
    socodechamp10 = db.Column(db.Numeric(8, 0, asdecimal=False))
    soclasse = db.Column(db.Numeric(3, 0, asdecimal=False))
    socoefdebr = db.Column(db.Numeric(3, 0, asdecimal=False))
    sonotevoldebr = db.Column(db.Numeric(6, 2))
    sonotedispdebr = db.Column(db.Numeric(6, 2))
    sonotecycldebr = db.Column(db.Numeric(6, 2))
    sonoteincertdebr = db.Column(db.Numeric(6, 2))
    sonotecashconvdebr = db.Column(db.Numeric(6, 2))
    sofacteurajustdebr = db.Column(db.Numeric(6, 2))
    solevierfinancierdebr = db.Column(db.Numeric(6, 2))
    sotauxisdebr = db.Column(db.Numeric(6, 2))
    sodatedernieresereinguecorr = db.Column(db.DateTime)
    sodatedernieresereingue = db.Column(db.DateTime)
    soparamnotederisque = db.Column(db.Numeric(1, 0, asdecimal=False))
    soprecisiongrille = db.Column(db.Numeric(1, 0, asdecimal=False))
    sotypegraph = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Détermine le type de graphique pour la grille 14 ans (normal ou logarithmique)",
    )
    sotypecroissorg = db.Column(db.String(2))
    soanalysteprincipal2 = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
    )
    sotypebt = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Type de la base titres 0 = Sake 1 = Excel",
    )


class Typecontrat(db.Model):
    __tablename__ = "typecontrat"
    __table_args__ = {"schema": "exane"}

    tctcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tctnom = db.Column(db.String(60), nullable=False)


class Typeinstrument(db.Model):
    __tablename__ = "typeinstrument"
    __table_args__ = {"schema": "exane"}

    tycode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du type d'instrument",
    )
    tyfamille = db.Column(
        db.ForeignKey("exane.famille.facode"),
        nullable=False,
        index=True,
        info="Code de la famille d'un type dinstruments",
    )
    tynom = db.Column(db.String(60), info="Libelle du type d'instrument")
    tyname = db.Column(db.String(60))

    famille = db.relationship(
        "Famille",
        primaryjoin="Typeinstrument.tyfamille == Famille.facode",
        backref="typeinstruments",
    )


class Typepayoff(db.Model):
    __tablename__ = "typepayoff"
    __table_args__ = {"schema": "exane"}

    tflcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tflnom = db.Column(db.String(60), nullable=False)


class Typeproprietaire(db.Model):
    __tablename__ = "typeproprietaire"
    __table_args__ = {"schema": "exane"}

    tpcode = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, info="Code du propriétaire"
    )
    tplibelle = db.Column(db.String(60), info="Libellé du propriétaire")


class Typestatut(db.Model):
    __tablename__ = "typestatut"
    __table_args__ = {"schema": "exane"}

    tstcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du statut d'un instrument financier",
    )
    tstnom = db.Column(
        db.String(15),
        nullable=False,
        info="Libellé du statut d'un instrument financier",
    )


class Typofoinstrument(db.Model):
    __tablename__ = "typofoinstrument"
    __table_args__ = (db.CheckConstraint("TICODE>=1000"), {"schema": "exane"})

    ticode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de la nouvelle typologie FO",
    )
    tilibelle = db.Column(
        db.String(200), nullable=False, info="Libellé de la nouvelle typologie FO"
    )


class Typofoinstrumentsautorisee(db.Model):
    __tablename__ = "typofoinstrumentsautorisees"
    __table_args__ = (
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACONTRATINDEFINI Is Not Null AND TACONTRATINDEFINI IN ('O','N')"
        ),
        db.CheckConstraint(
            "TACONTRATLISTE Is Not Null AND TACONTRATLISTE IN ('O','N')"
        ),
        db.CheckConstraint("TACONTRATOTC Is Not Null AND TACONTRATOTC IN ('O','N')"),
        db.CheckConstraint(
            "TACONTRATTITRE Is Not Null AND TACONTRATTITRE IN ('O','N')"
        ),
        db.Index(
            "uk_typofoinstrumentsautorisees",
            "tacodetypoinstrument",
            "tacodetypoinstsjac",
        ),
        {"schema": "exane"},
    )

    tacode = db.Column(
        db.Numeric(9, 0, asdecimal=False),
        primary_key=True,
        info="Code d'association de la typologie instrument et de la typologie sous jacent",
    )
    tacodetypoinstrument = db.Column(
        db.ForeignKey("exane.typofoinstrument.ticode"),
        nullable=False,
        info="Code de la typologie instrument cf. EXANE.TYPOFOINSTRUMENT",
    )
    tacodetypoinstsjac = db.Column(
        db.ForeignKey("exane.typofoinstrumentsjac.tscode"),
        info="Code de la typologie sous jacent cf. EXANE.TYPOFOINSTRUMENTSJAC",
    )
    tacontrattitre = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Titre",
    )
    tacontratliste = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Liste",
    )
    tacontratotc = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat OTC",
    )
    tacontratindefini = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Indéfini",
    )

    typofoinstrument = db.relationship(
        "Typofoinstrument",
        primaryjoin="Typofoinstrumentsautorisee.tacodetypoinstrument == Typofoinstrument.ticode",
        backref="typofoinstrumentsautorisees",
    )
    typofoinstrumentsjac = db.relationship(
        "Typofoinstrumentsjac",
        primaryjoin="Typofoinstrumentsautorisee.tacodetypoinstsjac == Typofoinstrumentsjac.tscode",
        backref="typofoinstrumentsautorisees",
    )


class Typofoinstrumentsjac(db.Model):
    __tablename__ = "typofoinstrumentsjac"
    __table_args__ = {"schema": "exane"}

    tscode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de la nouvelle typologie sous jacent",
    )
    tslibellesjac = db.Column(
        db.String(200), nullable=False, info="Libellé du type de sous jacent du produit"
    )

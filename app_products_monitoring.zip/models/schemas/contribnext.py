# coding: utf-8
from local_db_mgt import db


class Aeptier(db.Model):
    __tablename__ = "aeptier"
    __table_args__ = {"schema": "contribnext"}

    ask_quantity = db.Column(db.Float)
    bid_quantity = db.Column(db.Float)
    enabled = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    spread_factor = db.Column(db.Float)
    cfin = db.Column(
        db.ForeignKey("contribnext.aep_configuration.instrument_cfin"),
        primary_key=True,
        nullable=False,
    )
    rank = db.Column(
        db.Numeric(10, 0, asdecimal=False), primary_key=True, nullable=False
    )

    aep_configuration = db.relationship(
        "AepConfiguration",
        primaryjoin="Aeptier.cfin == AepConfiguration.instrument_cfin",
        backref="aeptiers",
    )


class CloseOverwrite(db.Model):
    __tablename__ = "close_overwrite"
    __table_args__ = {"schema": "contribnext"}

    request_id = db.Column(db.String(255), primary_key=True, nullable=False)
    value_date = db.Column(db.DateTime, nullable=False)
    instrument_cfin = db.Column(
        db.Numeric(19, 0, asdecimal=False), primary_key=True, nullable=False
    )
    instrument_ask_price = db.Column(db.Float, nullable=False)
    instrument_bid_price = db.Column(db.Float, nullable=False)
    price_timestamp = db.Column(db.DateTime, nullable=False)


class CloserH(db.Model):
    __tablename__ = "closer_h"
    __table_args__ = {"schema": "contribnext"}

    user_id = db.Column(db.String(40), nullable=False)
    request_id = db.Column(db.String(255), primary_key=True, nullable=False)
    instrument_valuedate = db.Column(db.DateTime, nullable=False, index=True)
    instrument_cfin = db.Column(
        db.Numeric(10, 0, asdecimal=False), primary_key=True, nullable=False
    )
    underlying_valuedate = db.Column(db.DateTime, nullable=False)
    underlying_cfin = db.Column(
        db.Numeric(10, 0, asdecimal=False), primary_key=True, nullable=False
    )
    underlying_price = db.Column(db.Numeric(13, 5), nullable=False)
    underlying_type = db.Column(db.String(2), primary_key=True, nullable=False)
    instrument_profile = db.Column(db.Numeric(4, 0, asdecimal=False))
    underlying_spot_mode = db.Column(db.String(2))
    creation_date = db.Column(db.DateTime)


class CloserIndexH(db.Model):
    __tablename__ = "closer_index_h"
    __table_args__ = {"schema": "contribnext"}

    request_id = db.Column(db.String(255), primary_key=True, nullable=False)
    instrument_valuedate = db.Column(db.DateTime, nullable=False)
    instrument_cfin = db.Column(
        db.Numeric(19, 0, asdecimal=False), primary_key=True, nullable=False
    )
    instrument_price = db.Column(db.Float, nullable=False)
    price_timestamp = db.Column(db.DateTime)


class CloserShredderH(db.Model):
    __tablename__ = "closer_shredder_h"
    __table_args__ = {"schema": "contribnext"}

    request_id = db.Column(db.String(255), primary_key=True, nullable=False)
    instrument_valuedate = db.Column(db.DateTime, nullable=False)
    instrument_cfin = db.Column(
        db.Numeric(19, 0, asdecimal=False), primary_key=True, nullable=False
    )
    bid = db.Column(db.Float, nullable=False)
    ask = db.Column(db.Float, nullable=False)
    last = db.Column(db.Float)
    price_timestamp = db.Column(db.DateTime)


class CronConfiguration(db.Model):
    __tablename__ = "cron_configuration"
    __table_args__ = {"schema": "contribnext"}

    cron_key = db.Column(db.String(255), primary_key=True)
    cron = db.Column(db.String(255))


class Currency(db.Model):
    __tablename__ = "currency"
    __table_args__ = {"schema": "contribnext"}

    cfin = db.Column(db.Numeric(19, 0, asdecimal=False), primary_key=True)
    name = db.Column(db.String(255))


class ExchangeRate(db.Model):
    __tablename__ = "exchange_rate"
    __table_args__ = {"schema": "contribnext"}

    cfin = db.Column(db.Numeric(19, 0, asdecimal=False), primary_key=True)
    name = db.Column(db.String(255))
    ric = db.Column(db.String(255))
    base_currency_cfin = db.Column(db.ForeignKey("contribnext.currency.cfin"))
    currency_cfin = db.Column(db.ForeignKey("contribnext.currency.cfin"))
    price_coeff = db.Column(db.Float)

    currency = db.relationship(
        "Currency",
        primaryjoin="ExchangeRate.base_currency_cfin == Currency.cfin",
        backref="currency_exchange_rates",
    )
    currency1 = db.relationship(
        "Currency",
        primaryjoin="ExchangeRate.currency_cfin == Currency.cfin",
        backref="currency_exchange_rates_0",
    )


class ExternalField(db.Model):
    __tablename__ = "external_field"
    __table_args__ = {"schema": "contribnext"}

    id = db.Column(db.String(255), primary_key=True)


class ExternalInstrument(db.Model):
    __tablename__ = "external_instrument"
    __table_args__ = (
        db.CheckConstraint(
            "\n    bid_field_id IS NOT NULL\n    OR ask_field_id IS NOT NULL\n    OR last_field_id IS NOT NULL\n    OR mid_field_id IS NOT NULL\n  "
        ),
        db.CheckConstraint(
            "\n    bid_field_id IS NOT NULL\n    OR ask_field_id IS NOT NULL\n    OR last_field_id IS NOT NULL\n    OR mid_field_id IS NOT NULL\n  "
        ),
        db.CheckConstraint(
            "\n    bid_field_id IS NOT NULL\n    OR ask_field_id IS NOT NULL\n    OR last_field_id IS NOT NULL\n    OR mid_field_id IS NOT NULL\n  "
        ),
        db.CheckConstraint(
            "\n    bid_field_id IS NOT NULL\n    OR ask_field_id IS NOT NULL\n    OR last_field_id IS NOT NULL\n    OR mid_field_id IS NOT NULL\n  "
        ),
        {"schema": "contribnext"},
    )

    instrument_cfin = db.Column(db.Numeric(19, 0, asdecimal=False), primary_key=True)
    ric = db.Column(db.String(255), nullable=False)
    bid_field_id = db.Column(db.ForeignKey("contribnext.external_field.id"))
    ask_field_id = db.Column(db.ForeignKey("contribnext.external_field.id"))
    last_field_id = db.Column(db.ForeignKey("contribnext.external_field.id"))
    mid_field_id = db.Column(db.ForeignKey("contribnext.external_field.id"))
    open_time = db.Column(db.DateTime, nullable=False)
    close_time = db.Column(db.DateTime, nullable=False)

    ask_field = db.relationship(
        "ExternalField",
        primaryjoin="ExternalInstrument.ask_field_id == ExternalField.id",
        backref="externalfield_externalfield_externalfield_external_instruments",
    )
    bid_field = db.relationship(
        "ExternalField",
        primaryjoin="ExternalInstrument.bid_field_id == ExternalField.id",
        backref="externalfield_externalfield_externalfield_external_instruments_0",
    )
    last_field = db.relationship(
        "ExternalField",
        primaryjoin="ExternalInstrument.last_field_id == ExternalField.id",
        backref="externalfield_externalfield_externalfield_external_instruments",
    )
    mid_field = db.relationship(
        "ExternalField",
        primaryjoin="ExternalInstrument.mid_field_id == ExternalField.id",
        backref="externalfield_externalfield_externalfield_external_instruments_0",
    )


class ExternalInstrumentClose(db.Model):
    __tablename__ = "external_instrument_close"
    __table_args__ = (
        db.CheckConstraint(
            "\n    bid IS NOT NULL\n    OR ask IS NOT NULL\n    OR last IS NOT NULL\n  "
        ),
        db.CheckConstraint(
            "\n    bid IS NOT NULL\n    OR ask IS NOT NULL\n    OR last IS NOT NULL\n  "
        ),
        db.CheckConstraint(
            "\n    bid IS NOT NULL\n    OR ask IS NOT NULL\n    OR last IS NOT NULL\n  "
        ),
        {"schema": "contribnext"},
    )

    id = db.Column(db.Numeric(19, 0, asdecimal=False), primary_key=True)
    cfin = db.Column(db.Numeric(19, 0, asdecimal=False), nullable=False)
    ric = db.Column(db.String(255), nullable=False)
    bid = db.Column(db.Float)
    ask = db.Column(db.Float)
    last = db.Column(db.Float)
    timestamp = db.Column(db.DateTime, nullable=False)


class Indicator(db.Model):
    __tablename__ = "indicator"
    __table_args__ = {"schema": "contribnext"}

    castor_id = db.Column(db.Numeric(10, 0, asdecimal=False), primary_key=True)
    name = db.Column(db.String(255), unique=True)
    requiring_currency = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    requiring_forex_conversion = db.Column(
        db.Numeric(1, 0, asdecimal=False), nullable=False
    )
    requiring_underlying = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)


class Instrument(db.Model):
    __tablename__ = "instrument"
    __table_args__ = {"schema": "contribnext"}

    cfin = db.Column(db.Numeric(19, 0, asdecimal=False), primary_key=True)
    bloomberg_code = db.Column(db.String(255))
    business_name = db.Column(db.String(255))
    camelot_id = db.Column(db.String(255))
    category = db.Column(db.String(255))
    cusip = db.Column(db.String(255))
    high_volume = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    isin = db.Column(db.String(255))
    listing_type = db.Column(db.String(255))
    long_name = db.Column(db.String(255))
    market_code = db.Column(db.String(255))
    maturity = db.Column(db.DateTime)
    name = db.Column(db.String(255))
    nominal = db.Column(db.Float)
    payoff = db.Column(db.String(255))
    payoff_type = db.Column(db.String(255))
    ric = db.Column(db.String(255))
    ted_id = db.Column(db.String(255))
    currency_cfin = db.Column(db.ForeignKey("contribnext.currency.cfin"))
    nominal_currency_cfin = db.Column(db.ForeignKey("contribnext.currency.cfin"))
    price_coeff = db.Column(db.Float)
    active = db.Column(db.Numeric(1, 0, asdecimal=False))
    basket = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    basket_type = db.Column(db.String(255))
    option_instrument = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    option_type = db.Column(db.String(255))
    parity = db.Column(db.Float)
    proportion = db.Column(db.Float)
    strike = db.Column(db.Float)
    facial = db.Column(db.Float)
    modification_date = db.Column(db.DateTime)
    modification_user = db.Column(db.String(255))
    bloomberg_label = db.Column(db.String(255))
    payoff_code = db.Column(db.Numeric(3, 0, asdecimal=False))

    currency = db.relationship(
        "Currency",
        primaryjoin="Instrument.currency_cfin == Currency.cfin",
        backref="currency_instruments",
    )
    currency1 = db.relationship(
        "Currency",
        primaryjoin="Instrument.nominal_currency_cfin == Currency.cfin",
        backref="currency_instruments_0",
    )


class AepConfiguration(Instrument):
    __tablename__ = "aep_configuration"
    __table_args__ = {"schema": "contribnext"}

    enabled = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    instrument_cfin = db.Column(
        db.ForeignKey("contribnext.instrument.cfin"), primary_key=True
    )


class ContribInstrument(Instrument):
    __tablename__ = "contrib_instrument"
    __table_args__ = {"schema": "contribnext"}

    contribution_method = db.Column(db.String(255))
    discount = db.Column(db.Float)
    end_date = db.Column(db.DateTime)
    end_of_day_processing_active = db.Column(
        db.Numeric(1, 0, asdecimal=False), nullable=False
    )
    position_cfin = db.Column(db.Numeric(19, 0, asdecimal=False))
    pricing_method = db.Column(db.String(255))
    rubbish_ask = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    rubbish_bid = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    rubbish_spot = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    sold_out = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    start_date = db.Column(db.DateTime)
    status = db.Column(db.String(255))
    tempo = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    threshold = db.Column(db.String(255))
    instrument_cfin = db.Column(
        db.ForeignKey("contribnext.instrument.cfin"), primary_key=True
    )
    pricing_profile_code = db.Column(db.ForeignKey("contribnext.pricing_profile.code"))

    pricing_profile = db.relationship(
        "PricingProfile",
        primaryjoin="ContribInstrument.pricing_profile_code == PricingProfile.code",
        backref="contrib_instruments",
    )


class CrmDatum(Instrument):
    __tablename__ = "crm_data"
    __table_args__ = {"schema": "contribnext"}

    bought_quantity = db.Column(db.Float, nullable=False)
    issued_quantity = db.Column(db.Float, nullable=False)
    sold_quantity = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime)
    instrument_cfin = db.Column(
        db.ForeignKey("contribnext.instrument.cfin"), primary_key=True
    )


class InitialSalesMargin(Instrument):
    __tablename__ = "initial_sales_margins"
    __table_args__ = {"schema": "contribnext"}

    ask_margin = db.Column(db.Float)
    bid_margin = db.Column(db.Float)
    last_update_time = db.Column(db.DateTime)
    loginad = db.Column(db.String(255))
    instrument_cfin = db.Column(
        db.ForeignKey("contribnext.instrument.cfin"), primary_key=True
    )


class Overwrite(Instrument):
    __tablename__ = "overwrites"
    __table_args__ = {"schema": "contribnext"}

    ask = db.Column(db.Float)
    bid = db.Column(db.Float)
    end_date = db.Column(db.DateTime)
    mid = db.Column(db.Float)
    start_date = db.Column(db.DateTime)
    instrument_cfin = db.Column(
        db.ForeignKey("contribnext.instrument.cfin"), primary_key=True
    )


class ShredderConfiguration(Instrument):
    __tablename__ = "shredder_configuration"
    __table_args__ = {"schema": "contribnext"}

    code = db.Column(db.String(255))
    source = db.Column(db.String(255))
    type = db.Column(db.String(255))
    instrument_cfin = db.Column(
        db.ForeignKey("contribnext.instrument.cfin"), primary_key=True
    )
    ask_field_id = db.Column(db.ForeignKey("contribnext.shredder_field.id"))
    bid_field_id = db.Column(db.ForeignKey("contribnext.shredder_field.id"))
    last_field_id = db.Column(db.ForeignKey("contribnext.shredder_field.id"))
    mid_field_id = db.Column(db.ForeignKey("contribnext.shredder_field.id"))

    ask_field = db.relationship(
        "ShredderField",
        primaryjoin="ShredderConfiguration.ask_field_id == ShredderField.id",
        backref="shredderfield_shredderfield_shredderfield_shredder_configurations",
    )
    bid_field = db.relationship(
        "ShredderField",
        primaryjoin="ShredderConfiguration.bid_field_id == ShredderField.id",
        backref="shredderfield_shredderfield_shredderfield_shredder_configurations_0",
    )
    last_field = db.relationship(
        "ShredderField",
        primaryjoin="ShredderConfiguration.last_field_id == ShredderField.id",
        backref="shredderfield_shredderfield_shredderfield_shredder_configurations",
    )
    mid_field = db.relationship(
        "ShredderField",
        primaryjoin="ShredderConfiguration.mid_field_id == ShredderField.id",
        backref="shredderfield_shredderfield_shredderfield_shredder_configurations_0",
    )


class InstrumentExchangeRate(db.Model):
    __tablename__ = "instrument_exchange_rate"
    __table_args__ = {"schema": "contribnext"}

    forced_spot = db.Column(db.Float)
    spot_mode = db.Column(db.String(255))
    instrument_cfin = db.Column(
        db.ForeignKey("contribnext.instrument.cfin"), primary_key=True, nullable=False
    )
    exchange_rate_cfin = db.Column(
        db.ForeignKey("contribnext.exchange_rate.cfin"),
        primary_key=True,
        nullable=False,
    )

    exchange_rate = db.relationship(
        "ExchangeRate",
        primaryjoin="InstrumentExchangeRate.exchange_rate_cfin == ExchangeRate.cfin",
        backref="instrument_exchange_rates",
    )
    instrument = db.relationship(
        "Instrument",
        primaryjoin="InstrumentExchangeRate.instrument_cfin == Instrument.cfin",
        backref="instrument_exchange_rates",
    )


class InstrumentUnderlying(db.Model):
    __tablename__ = "instrument_underlying"
    __table_args__ = {"schema": "contribnext"}

    forced_spot = db.Column(db.Float)
    spot_mode = db.Column(db.String(255))
    underlying_cfin = db.Column(
        db.ForeignKey("contribnext.underlying.cfin"), primary_key=True, nullable=False
    )
    instrument_cfin = db.Column(
        db.ForeignKey("contribnext.instrument.cfin"), primary_key=True, nullable=False
    )
    close_day_offset = db.Column(db.Numeric(10, 0, asdecimal=False))
    weight = db.Column(db.Float, nullable=False)

    instrument = db.relationship(
        "Instrument",
        primaryjoin="InstrumentUnderlying.instrument_cfin == Instrument.cfin",
        backref="instrument_underlyings",
    )
    underlying = db.relationship(
        "Underlying",
        primaryjoin="InstrumentUnderlying.underlying_cfin == Underlying.cfin",
        backref="instrument_underlyings",
    )


class Intraday(db.Model):
    __tablename__ = "intraday"
    __table_args__ = {"schema": "contribnext"}

    iddstamp = db.Column(db.DateTime, primary_key=True, nullable=False)
    iddcfin = db.Column(
        db.Numeric(19, 0, asdecimal=False), primary_key=True, nullable=False
    )
    iddbid = db.Column(db.Float)
    iddask = db.Column(db.Float)
    iddpxtheo = db.Column(db.Float)
    iddminbid = db.Column(db.Float)
    iddmaxbid = db.Column(db.Float)
    iddminask = db.Column(db.Float)
    iddmaxask = db.Column(db.Float)
    iddminpxtheo = db.Column(db.Float)
    iddmaxpxtheo = db.Column(db.Float)


class Margin(db.Model):
    __tablename__ = "margin"
    __table_args__ = {"schema": "contribnext"}

    cfin = db.Column(
        db.ForeignKey("contribnext.instrument.cfin"), primary_key=True, nullable=False
    )
    margin_profile = db.Column(db.String(255), primary_key=True, nullable=False)
    order = db.Column(
        db.Numeric(10, 0, asdecimal=False), primary_key=True, nullable=False
    )
    calculation_method = db.Column(db.String(255))
    margin_comment = db.Column(db.String(255))
    end_date = db.Column(db.DateTime)
    start_date = db.Column(db.DateTime)
    type = db.Column(db.String(255))
    unary_operator = db.Column(db.String(255))
    currency_cfin = db.Column(db.ForeignKey("contribnext.currency.cfin"))
    indicator_castor_id = db.Column(db.ForeignKey("contribnext.indicator.castor_id"))
    underlying_cfin = db.Column(db.ForeignKey("contribnext.underlying.cfin"))

    instrument = db.relationship(
        "Instrument", primaryjoin="Margin.cfin == Instrument.cfin", backref="margins"
    )
    currency = db.relationship(
        "Currency",
        primaryjoin="Margin.currency_cfin == Currency.cfin",
        backref="margins",
    )
    indicator_castor = db.relationship(
        "Indicator",
        primaryjoin="Margin.indicator_castor_id == Indicator.castor_id",
        backref="margins",
    )
    underlying = db.relationship(
        "Underlying",
        primaryjoin="Margin.underlying_cfin == Underlying.cfin",
        backref="margins",
    )


class AskMargin(Margin):
    __tablename__ = "ask_margin"
    __table_args__ = (
        db.ForeignKeyConstraint(
            ["cfin", "margin_profile", "order"],
            [
                "contribnext.margin.cfin",
                "contribnext.margin.margin_profile",
                "contribnext.margin.order",
            ],
        ),
        {"schema": "contribnext"},
    )

    cfin = db.Column(
        db.Numeric(19, 0, asdecimal=False), primary_key=True, nullable=False
    )
    margin_profile = db.Column(db.String(255), primary_key=True, nullable=False)
    order = db.Column(
        db.Numeric(10, 0, asdecimal=False), primary_key=True, nullable=False
    )
    end_value = db.Column(db.Float)
    equal_to_bid_margin = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    extra_spread = db.Column(db.Float)
    formula = db.Column(db.String(255))
    named_type = db.Column(db.String(255))
    start_value = db.Column(db.Float)


class BidMargin(Margin):
    __tablename__ = "bid_margin"
    __table_args__ = (
        db.ForeignKeyConstraint(
            ["cfin", "margin_profile", "order"],
            [
                "contribnext.margin.cfin",
                "contribnext.margin.margin_profile",
                "contribnext.margin.order",
            ],
        ),
        {"schema": "contribnext"},
    )

    cfin = db.Column(
        db.Numeric(19, 0, asdecimal=False), primary_key=True, nullable=False
    )
    margin_profile = db.Column(db.String(255), primary_key=True, nullable=False)
    order = db.Column(
        db.Numeric(10, 0, asdecimal=False), primary_key=True, nullable=False
    )
    end_value = db.Column(db.Float)
    formula = db.Column(db.String(255))
    named_type = db.Column(db.String(255))
    start_value = db.Column(db.Float)


class Market(db.Model):
    __tablename__ = "market"
    __table_args__ = {"schema": "contribnext"}

    code = db.Column(db.Numeric(19, 0, asdecimal=False), primary_key=True)
    closing_time = db.Column(db.DateTime)
    name = db.Column(db.String(255))


class PricingProfile(db.Model):
    __tablename__ = "pricing_profile"
    __table_args__ = {"schema": "contribnext"}

    code = db.Column(db.Numeric(19, 0, asdecimal=False), primary_key=True)


class PublishSuspended(db.Model):
    __tablename__ = "publish_suspended"
    __table_args__ = {"schema": "contribnext"}

    origin = db.Column(db.String(10), primary_key=True, nullable=False)
    publish_date = db.Column(db.DateTime, primary_key=True, nullable=False)
    cfin = db.Column(
        db.Numeric(19, 0, asdecimal=False), primary_key=True, nullable=False
    )
    reason = db.Column(db.Numeric(4, 0, asdecimal=False))


class ShredderField(db.Model):
    __tablename__ = "shredder_field"
    __table_args__ = (
        db.Index("shredder_field_unique", "extract", "col", "length", "line"),
        {"schema": "contribnext"},
    )

    id = db.Column(db.Numeric(19, 0, asdecimal=False), primary_key=True)
    col = db.Column(db.Numeric(10, 0, asdecimal=False))
    extract = db.Column(db.String(255), nullable=False)
    length = db.Column(db.Numeric(10, 0, asdecimal=False))
    line = db.Column(db.Numeric(10, 0, asdecimal=False))


class StaticDataReload(db.Model):
    __tablename__ = "static_data_reload"
    __table_args__ = {"schema": "contribnext"}

    id = db.Column(db.Numeric(19, 0, asdecimal=False), primary_key=True)
    currencies_loaded = db.Column(db.Numeric(19, 0, asdecimal=False), nullable=False)
    currencies_to_load = db.Column(db.Numeric(19, 0, asdecimal=False), nullable=False)
    end_date = db.Column(db.DateTime)
    instruments_loaded = db.Column(db.Numeric(19, 0, asdecimal=False), nullable=False)
    instruments_to_load = db.Column(db.Numeric(19, 0, asdecimal=False), nullable=False)
    reload_currencies = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    reload_instruments = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    reload_underlyings = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    requestor = db.Column(db.String(255))
    start_date = db.Column(db.DateTime)
    status = db.Column(db.String(255))
    underlyings_loaded = db.Column(db.Numeric(19, 0, asdecimal=False), nullable=False)
    underlyings_to_load = db.Column(db.Numeric(19, 0, asdecimal=False), nullable=False)


class Underlying(db.Model):
    __tablename__ = "underlying"
    __table_args__ = {"schema": "contribnext"}

    cfin = db.Column(db.Numeric(19, 0, asdecimal=False), primary_key=True)
    bloomberg_code = db.Column(db.String(255))
    camelot_id = db.Column(db.String(255))
    country = db.Column(db.Numeric(19, 0, asdecimal=False), nullable=False)
    isin = db.Column(db.String(255))
    listing_type = db.Column(db.String(255))
    market_code = db.Column(db.String(255))
    market_code_type = db.Column(db.String(255))
    name = db.Column(db.String(255))
    nominal = db.Column(db.Float)
    quotation_method = db.Column(db.String(255))
    ric = db.Column(db.String(255))
    ted_id = db.Column(db.String(255))
    currency_cfin = db.Column(db.ForeignKey("contribnext.currency.cfin"))
    nominal_currency_cfin = db.Column(db.ForeignKey("contribnext.currency.cfin"))
    price_coeff = db.Column(db.Float)
    basket = db.Column(db.Numeric(1, 0, asdecimal=False), nullable=False)
    basket_type = db.Column(db.String(255))
    payoff = db.Column(db.String(255))
    payoff_type = db.Column(db.String(255))
    payoff_code = db.Column(db.Numeric(3, 0, asdecimal=False))

    currency = db.relationship(
        "Currency",
        primaryjoin="Underlying.currency_cfin == Currency.cfin",
        backref="currency_underlyings",
    )
    currency1 = db.relationship(
        "Currency",
        primaryjoin="Underlying.nominal_currency_cfin == Currency.cfin",
        backref="currency_underlyings_0",
    )


class UnderlyingCloseDayOffset(Underlying):
    __tablename__ = "underlying_close_day_offset"
    __table_args__ = {"schema": "contribnext"}

    close_day_offset = db.Column(db.Numeric(10, 0, asdecimal=False), nullable=False)
    underlying_cfin = db.Column(
        db.ForeignKey("contribnext.underlying.cfin"), primary_key=True
    )


class UnderlyingUpdateFrequency(Underlying):
    __tablename__ = "underlying_update_frequency"
    __table_args__ = {"schema": "contribnext"}

    update_frequency_in_days = db.Column(
        db.Numeric(10, 0, asdecimal=False), nullable=False
    )
    underlying_cfin = db.Column(
        db.ForeignKey("contribnext.underlying.cfin"), primary_key=True
    )

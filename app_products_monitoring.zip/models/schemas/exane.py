# coding: utf-8
from local_db_mgt import db


class Typeattributfamille(db.Model):
    __tablename__ = "typeattributfamille"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tafcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    taflibelle = db.Column(db.String(60), nullable=False)


class Typebarriere(db.Model):
    __tablename__ = "typebarriere"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tbacode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tbalibelle = db.Column(db.String(32))


class Typecalcul(db.Model):
    __tablename__ = "typecalcul"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tccode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code du type de calcul de l'indice",
    )
    tcnom = db.Column(
        db.String(20), nullable=False, info="Libellé du type de calcul de l'indice"
    )


class Typeclient(db.Model):
    __tablename__ = "typeclient"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tccode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="Code type client"
    )
    tclibelle = db.Column(db.String(60), nullable=False, info="Libellé type client")
    tclibelle_unique = db.Column(
        db.String(4000), unique=True, server_default=db.FetchedValue()
    )


class Typecontrat(db.Model):
    __tablename__ = "typecontrat"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tctcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tctnom = db.Column(db.String(60), nullable=False)


class Typecontratcadre(db.Model):
    __tablename__ = "typecontratcadre"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tccode = db.Column(db.Numeric(2, 0, asdecimal=False), primary_key=True)
    tcnom = db.Column(db.String(15))
    tcstatut = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Statut",
    )


class Typecoupon(db.Model):
    __tablename__ = "typecoupon"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tcnum = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du type de Coupon",
    )
    tcnomfr = db.Column(db.String(60), nullable=False)
    tcnomuk = db.Column(db.String(60))


class Typecross(db.Model):
    __tablename__ = "typecross"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tccode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="code type du cross"
    )
    tclibelle = db.Column(db.String(60), info="Libellé du type du cross")


class Typedatarecup(db.Model):
    __tablename__ = "typedatarecup"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    trcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du type de donnees à récupérer",
    )
    trnom = db.Column(
        db.String(30), nullable=False, info="Libellé du type de donnees à récupérer"
    )
    trcoeff = db.Column(
        db.Numeric(6, 0, asdecimal=False),
        info="Coefficient à appliquer en fonction du type de donnees à récupérer",
    )
    trdata = db.Column(db.String(20))


class Typediffusion(db.Model):
    __tablename__ = "typediffusion"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tdcode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de l'autorisation de diffusion",
    )
    tdlibelle = db.Column(db.String(60), info="Libellé de l'autorisation de diffusion")


class Typeetatdevie(db.Model):
    __tablename__ = "typeetatdevie"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tvcode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de l'état de vie",
    )
    tvlibelle = db.Column(db.String(60), info="Libellé de l'état de vie")


class Typefamillefond(db.Model):
    __tablename__ = "typefamillefonds"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tfdcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tfdattribut = db.Column(db.ForeignKey("exane.typeattributfamille.tafcode"))
    tfdlibelle = db.Column(db.String(60))

    typeattributfamille = db.relationship(
        "Typeattributfamille",
        primaryjoin="Typefamillefond.tfdattribut == Typeattributfamille.tafcode",
        lazy=True,
        backref="typefamillefonds",
    )


class Typeinstrument(db.Model):
    __tablename__ = "typeinstrument"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tycode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du type d'instrument",
    )
    tyfamille = db.Column(
        db.ForeignKey("exane.famille.facode"),
        nullable=False,
        index=True,
        info="Code de la famille d'un type dinstruments",
    )
    tynom = db.Column(db.String(60), info="Libelle du type d'instrument")
    tyname = db.Column(db.String(60))

    famille = db.relationship(
        "Famille",
        primaryjoin="Typeinstrument.tyfamille == Famille.facode",
        lazy=True,
        backref="typeinstruments",
    )


class Typeintermediation(db.Model):
    __tablename__ = "typeintermediation"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    ticode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de l'autorisation d'intermédiation",
    )
    tilibelle = db.Column(
        db.String(60), info="Libellé de l'autorisation d'intermédiation"
    )


class Typelevier(db.Model):
    __tablename__ = "typelevier"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tlvcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tlvlibelle = db.Column(db.String(32))


class Typelien(db.Model):
    __tablename__ = "typelien"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tlcode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de la nature de relation entre deux instruments",
    )
    tlnom = db.Column(
        db.String(60),
        nullable=False,
        info="Nom de la nature de relation entre dex instruments",
    )


class Typenote(db.Model):
    __tablename__ = "typenote"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tnnote = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de la note attribuée par une agence de rating",
    )
    tnagence = db.Column(
        db.ForeignKey("exane.agence.agcode"),
        nullable=False,
        index=True,
        info="Code agence de notation",
    )
    tnrating = db.Column(db.String(20), nullable=False, info="Code du rating")
    tnhorizon = db.Column(
        db.String(4), info="Spécifie si le rating attribué est CT ou LT"
    )
    tnsignif = db.Column(
        db.String(20),
        info="Signification de la note attribuée par une agence de rating",
    )
    tntype = db.Column(db.ForeignKey("exane.typescale.tstype"))
    tnratingordre = db.Column(
        db.Numeric(4, 0, asdecimal=False),
        info="Ordonnancement du code du rating au sein d'une agence",
    )

    agence = db.relationship(
        "Agence",
        primaryjoin="Typenote.tnagence == Agence.agcode",
        lazy=True,
        backref="typenotes",
    )
    typescale = db.relationship(
        "Typescale",
        primaryjoin="Typenote.tntype == Typescale.tstype",
        lazy=True,
        backref="typenotes",
    )


class Typepayoff(db.Model):
    __tablename__ = "typepayoff"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tflcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    tflnom = db.Column(db.String(60), nullable=False)


class Typeposition(db.Model):
    __tablename__ = "typeposition"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tpcode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de l'autorisation de position",
    )
    tplibelle = db.Column(db.String(60), info="Libellé de l'autorisation de position")


class Typeproprietaire(db.Model):
    __tablename__ = "typeproprietaire"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tpcode = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, info="Code du propriétaire"
    )
    tplibelle = db.Column(db.String(60), info="Libellé du propriétaire")


class Typeproprietairevalidation(db.Model):
    __tablename__ = "typeproprietairevalidation"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tvcode = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, info="Code du propriétaire"
    )
    tvlibelle = db.Column(db.String(60), info="Libellé du propriétaire")


class Typeprotection(db.Model):
    __tablename__ = "typeprotection"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tpnum = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du type de protection",
    )
    tpnomfr = db.Column(db.String(60), nullable=False)
    tpnomuk = db.Column(db.String(60))


class Typerevenu(db.Model):
    __tablename__ = "typerevenu"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tucode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code du type de revenu pris en compte dans le calcul d'un indice ou d'un panier",
    )
    tunom = db.Column(
        db.String(20),
        nullable=False,
        info="Libellé du type de revenu pris en compte dans le calcul d'un indice ou d'un panier",
    )


class Typescale(db.Model):
    __tablename__ = "typescale"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tstype = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="Type scale"
    )
    tsnom = db.Column(db.String(20), info="Scale")


class Typesecteur(db.Model):
    __tablename__ = "typesecteurs"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tsecode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de la nomenclature des secteurs",
    )
    tsenom = db.Column(
        db.String(15), nullable=False, info="Libellé de la nomenclature des secteurs"
    )


class Typesjcemisstructuree(db.Model):
    __tablename__ = "typesjcemisstructuree"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tsecode = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, info="Code du type sjc"
    )
    tselibelle = db.Column(db.String(60), info="Type sous-jacent")


class Typestatut(db.Model):
    __tablename__ = "typestatut"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tstcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du statut d'un instrument financier",
    )
    tstnom = db.Column(
        db.String(15),
        nullable=False,
        info="Libellé du statut d'un instrument financier",
    )


class Typestatutdiffusioncsd(db.Model):
    __tablename__ = "typestatutdiffusioncsd"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    sdcode = db.Column(
        db.String(2),
        primary_key=True,
        info="Code du statut diffusion CSD (Dépositaire Central, ex EuroClear)",
    )
    sdlibelle = db.Column(
        db.String(60),
        nullable=False,
        info="Libellé statut diffusion CSD (Dépositaire Central, ex EuroClear)",
    )
    sdlibelle_unique = db.Column(
        db.String(4000), unique=True, server_default=db.FetchedValue()
    )


class Typeupside(db.Model):
    __tablename__ = "typeupside"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tunum = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du type d'Upside",
    )
    tunomfr = db.Column(db.String(60), nullable=False)
    tunomuk = db.Column(db.String(60))


class Typevalidationattribut(db.Model):
    __tablename__ = "typevalidationattribut"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tvcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code identifiant du sous état de validation",
    )
    tvlibelle = db.Column(db.String(60), info="Libéllé du sous état de validation")


class Typevolat(db.Model):
    __tablename__ = "typevolat"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tvcode = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, info="Type volatilite"
    )
    tvnom = db.Column(db.String(20), info="Libel type volat")


class Typofoinstrument(db.Model):
    __tablename__ = "typofoinstrument"
    __bind_key__ = "exane_analyse"
    __table_args__ = (db.CheckConstraint("TICODE>=1000"), {"schema": "exane"})

    ticode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de la nouvelle typologie FO",
    )
    tilibelle = db.Column(
        db.String(200), nullable=False, info="Libellé de la nouvelle typologie FO"
    )


class Typofoinstrumentsautorisee(db.Model):
    __tablename__ = "typofoinstrumentsautorisees"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACODE = Nvl(TACODETYPOINSTRUMENT,0) + Nvl(TACODETYPOINSTSJAC,0)"
        ),
        db.CheckConstraint(
            "TACONTRATINDEFINI Is Not Null AND TACONTRATINDEFINI IN ('O','N')"
        ),
        db.CheckConstraint(
            "TACONTRATLISTE Is Not Null AND TACONTRATLISTE IN ('O','N')"
        ),
        db.CheckConstraint("TACONTRATOTC Is Not Null AND TACONTRATOTC IN ('O','N')"),
        db.CheckConstraint(
            "TACONTRATTITRE Is Not Null AND TACONTRATTITRE IN ('O','N')"
        ),
        db.Index(
            "uk_typofoinstrumentsautorisees",
            "tacodetypoinstrument",
            "tacodetypoinstsjac",
        ),
        {"schema": "exane"},
    )

    tacode = db.Column(
        db.Numeric(9, 0, asdecimal=False),
        primary_key=True,
        info="Code d'association de la typologie instrument et de la typologie sous jacent",
    )
    tacodetypoinstrument = db.Column(
        db.ForeignKey("exane.typofoinstrument.ticode"),
        nullable=False,
        info="Code de la typologie instrument cf. EXANE.TYPOFOINSTRUMENT",
    )
    tacodetypoinstsjac = db.Column(
        db.ForeignKey("exane.typofoinstrumentsjac.tscode"),
        info="Code de la typologie sous jacent cf. EXANE.TYPOFOINSTRUMENTSJAC",
    )
    tacontrattitre = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Titre",
    )
    tacontratliste = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Liste",
    )
    tacontratotc = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat OTC",
    )
    tacontratindefini = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Indique si la valeur est possible pour un contrat Indéfini",
    )

    typofoinstrument = db.relationship(
        "Typofoinstrument",
        primaryjoin="Typofoinstrumentsautorisee.tacodetypoinstrument == Typofoinstrument.ticode",
        lazy=True,
        backref="typofoinstrumentsautorisees",
    )
    typofoinstrumentsjac = db.relationship(
        "Typofoinstrumentsjac",
        primaryjoin="Typofoinstrumentsautorisee.tacodetypoinstsjac == Typofoinstrumentsjac.tscode",
        lazy=True,
        backref="typofoinstrumentsautorisees",
    )


class Typofoinstrumentsjac(db.Model):
    __tablename__ = "typofoinstrumentsjac"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    tscode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de la nouvelle typologie sous jacent",
    )
    tslibellesjac = db.Column(
        db.String(200), nullable=False, info="Libellé du type de sous jacent du produit"
    )


class VTauxchangeEuroRef(db.Model):
    __tablename__ = "v_tauxchange_euro_ref"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tcrcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="CFin du Cross"
    )
    tcrlibcross = db.Column(db.String(60), nullable=False)
    tcrdateref = db.Column(
        db.DateTime, nullable=False, info="Date du cutoff / date de validité"
    )
    tcrpriclos = db.Column(db.Numeric(13, 5), info="Cours du cross")
    tcrdevnominal = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code devise contre valeur EURO",
    )


class VTypofoLibelles(db.Model):
    __tablename__ = "v_typofo_libelles"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    code_typo = db.Column(db.Numeric(9, 0, asdecimal=False), nullable=False)
    libelle_deduit = db.Column(db.String(403))
    code_typo_instrument = db.Column(db.Numeric(8, 0, asdecimal=False), nullable=False)
    libelle_typo_instrument = db.Column(db.String(200), nullable=False)
    code_typo_sjac = db.Column(db.Numeric(3, 0, asdecimal=False))
    libelle_typo_sjac = db.Column(db.String(200))
    autorise_contrat_titre = db.Column(db.String(1))
    autorise_contrat_liste = db.Column(db.String(1))
    autorise_contrat_otc = db.Column(db.String(1))
    autorise_contrat_indefini = db.Column(db.String(1))


class VTypologie(db.Model):
    __tablename__ = "v_typologie"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    code_valeur_typee = db.Column(
        db.Numeric(12, 0, asdecimal=False),
        nullable=False,
        info="Valeur typée (Produit, Opérations, Paramètre...)",
    )
    horodate_typologie = db.Column(
        db.DateTime, nullable=False, info="Horodatage de la typologie"
    )
    flag_typologie = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        info="Flag état de la typologie",
    )
    code_valeur_typologie = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code interne de la typologie",
    )
    libelle_typologie = db.Column(
        db.String(60), nullable=False, info="Libéllé de la typologie"
    )
    code_famille_typologie = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        info="Code interne de la famille de typologie",
    )
    libelle_famille_typologie = db.Column(
        db.String(100), nullable=False, info="Libéllé de la famille de typologie"
    )
    nature_famille_typologie = db.Column(
        db.String(1),
        nullable=False,
        info="Code de la nature de la typologie (Instrument/opération..)",
    )
    libelle_nature_famille_typo = db.Column(
        db.String(10),
        info="Libéllé de la nature de la typologie (Instrument/ Opération...)",
    )
    partition_famille_typologie = db.Column(
        db.String(1),
        nullable=False,
        info="Etat de partitionnement de la famille de la typologie",
    )
    code_proprietaire_famille_typo = db.Column(
        db.Numeric(5, 0, asdecimal=False),
        nullable=False,
        info="Code interne du propriétaire de la typologie",
    )
    libelle_propriet_famille_typo = db.Column(
        db.String(60), nullable=False, info="Libéllé du propriétaire de la typologie."
    )


class Instrument(db.Model):
    __tablename__ = "instruments"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint(
            "IFVALIDATION = 'N' OR IFVALIDATION = 'M' OR IFVALIDATION = 'R' OR IFVALIDATION = 'V'"
        ),
        db.CheckConstraint("ifcfin <> 0"),
        db.Index("idx1_instrument", "ifcfin", "ifpayoff", "iftype"),
        {"schema": "exane"},
    )

    ifcfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    ifstatut = db.Column(
        db.ForeignKey("exane.typestatut.tstcode"),
        nullable=False,
        index=True,
        info="Code du statut d'un instrument financier",
    )
    iftype = db.Column(
        db.ForeignKey("exane.typeinstrument.tycode"),
        nullable=False,
        index=True,
        info="Code du type d'instrument",
    )
    ifnom = db.Column(db.String(60), nullable=False, info="Nom de l'instrument")
    ifmaj = db.Column(
        db.DateTime, nullable=False, info="Date de mise à jour de l'instrument"
    )
    ifpayoff = db.Column(
        db.ForeignKey("exane.typepayoff.tflcode"),
        index=True,
        server_default=db.FetchedValue(),
        info="type de payoff de l'instrument",
    )
    ifcontrat = db.Column(
        db.ForeignKey("exane.typecontrat.tctcode"),
        index=True,
        server_default=db.FetchedValue(),
        info="type de contrat de l'instrument",
    )
    ifvalidation = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Gere la validation des instruments, toutes les caracteristiques du produit qui peuvent influencer le prix  agissent sur le champ IFVALIDATION",
    )
    ifproprietaire = db.Column(
        db.ForeignKey("exane.typeproprietaire.tpcode"),
        info="Propriétaire de l'instument",
    )
    iftypofo = db.Column(
        db.ForeignKey("exane.typofoinstrumentsautorisees.tacode"),
        index=True,
        info="Nouvelle typologie Front des produits cf. EXANE.TYPOFOINSTRUMENTSAUTORISEES",
    )

    typecontrat = db.relationship(
        "Typecontrat",
        primaryjoin="Instrument.ifcontrat == Typecontrat.tctcode",
        lazy=True,
        backref="instruments",
    )
    typepayoff = db.relationship(
        "Typepayoff",
        primaryjoin="Instrument.ifpayoff == Typepayoff.tflcode",
        lazy=True,
        backref="instruments",
    )
    typeproprietaire = db.relationship(
        "Typeproprietaire",
        primaryjoin="Instrument.ifproprietaire == Typeproprietaire.tpcode",
        lazy=True,
        backref="instruments",
    )
    typestatut = db.relationship(
        "Typestatut",
        primaryjoin="Instrument.ifstatut == Typestatut.tstcode",
        lazy=True,
        backref="instruments",
    )
    typeinstrument = db.relationship(
        "Typeinstrument",
        primaryjoin="Instrument.iftype == Typeinstrument.tycode",
        lazy=True,
        backref="instruments",
    )
    typofoinstrumentsautorisee = db.relationship(
        "Typofoinstrumentsautorisee",
        primaryjoin="Instrument.iftypofo == Typofoinstrumentsautorisee.tacode",
        lazy=True,
        backref="instruments",
    )


class Produit(Instrument):
    __tablename__ = "produits"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    prcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    prcourbe = db.Column(
        db.ForeignKey("exane.courbetx.cbcfin"),
        index=True,
        info="Code de l'instrument financier",
    )
    prmodecot = db.Column(
        db.ForeignKey("exane.modecot.mocode"),
        nullable=False,
        index=True,
        info="Code mode cotation",
    )
    prpays = db.Column(
        db.ForeignKey("exane.pays.pacode"), nullable=False, index=True, info="Code pays"
    )
    prmarche = db.Column(
        db.ForeignKey("exane.marche.macode"),
        nullable=False,
        index=True,
        info="Code du marché de cotation",
    )
    prdev = db.Column(
        db.ForeignKey("exane.devise.dvcfin"),
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    prdevnominal = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    prquotite = db.Column(
        db.Numeric(12, 4), nullable=False, info="Quotité minimale de transaction"
    )
    prcalendrier = db.Column(db.ForeignKey("exane.calendriersdescription.cncode"))

    calendriersdescription = db.relationship(
        "Calendriersdescription",
        primaryjoin="Produit.prcalendrier == Calendriersdescription.cncode",
        lazy=True,
        backref="produits",
    )
    courbetx = db.relationship(
        "Courbetx",
        primaryjoin="Produit.prcourbe == Courbetx.cbcfin",
        lazy=True,
        backref="produits",
    )
    devise = db.relationship(
        "Devise",
        primaryjoin="Produit.prdev == Devise.dvcfin",
        lazy=True,
        backref="devise_produits",
    )
    marche = db.relationship(
        "Marche",
        primaryjoin="Produit.prmarche == Marche.macode",
        lazy=True,
        backref="produits",
    )
    modecot = db.relationship(
        "Modecot",
        primaryjoin="Produit.prmodecot == Modecot.mocode",
        lazy=True,
        backref="produits",
    )
    pays = db.relationship(
        "Pays",
        primaryjoin="Produit.prpays == Pays.pacode",
        lazy=True,
        backref="produits",
    )


class Agence(db.Model):
    __tablename__ = "agence"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    agcode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code agence de notation",
    )
    agnom = db.Column(db.String(20), nullable=False, info="Nom agence de notation")


class Alien(db.Model):
    __tablename__ = "alien"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("ALCFIN <> ALSJAC"),
        db.CheckConstraint("ALCFIN <> ALSJAC"),
        {"schema": "exane"},
    )

    alcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    alsjac = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    altype = db.Column(
        db.ForeignKey("exane.typelien.tlcode"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de la nature de relation entre deux instruments",
    )
    almaj = db.Column(
        db.DateTime,
        nullable=False,
        info="Date de mise à jour du lien entre deux instruments financiers",
    )
    alparite = db.Column(db.Numeric(11, 5), info="Parité")
    alproportion = db.Column(db.Numeric(11, 5), info="Proportion")

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Alien.alcfin == Instrument.ifcfin",
        lazy=True,
        backref="instrument_aliens",
    )
    # instrument1 = db.relationship(
    #     "Instrument",
    #     primaryjoin="Alien.alsjac == Instrument.ifcfin",
    #     lazy=True,
    #     backref="instrument_aliens_0",
    # )
    typelien = db.relationship(
        "Typelien",
        primaryjoin="Alien.altype == Typelien.tlcode",
        lazy=True,
        backref="aliens",
    )


class Calendriersdescription(db.Model):
    __tablename__ = "calendriersdescription"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("CNDefiniParJourOuvre IN ('O','N')"),
        {"schema": "exane"},
    )

    cncode = db.Column(db.Numeric(10, 0, asdecimal=False), primary_key=True)
    cndefiniparjourouvre = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="O Indique si les jours définissant le calendrier sont des jours ouverts de type 33",
    )
    cnnom = db.Column(db.String(256), info="Libellé du calendrier")


class Code(db.Model):
    __tablename__ = "codes"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint(
            "\n       ( cfsource <> 331 OR (cfsource =  331 AND ( LENGTH(CFCODE) = 6 AND CFCODE = UPPER(CFCODE) )) )\n       AND\n       ( CFSOURCE = (311) OR (CFSOURCE <> 311 AND LENGTH(CFCODE) <= 30))\n       AND\n       ( CFSOURCE <>  6 OR (CFSOURCE = 6 AND LENGTH(CFCODE) = 12) )\n     "
        ),
        db.CheckConstraint(
            "\n       ( cfsource <> 331 OR (cfsource =  331 AND ( LENGTH(CFCODE) = 6 AND CFCODE = UPPER(CFCODE) )) )\n       AND\n       ( CFSOURCE = (311) OR (CFSOURCE <> 311 AND LENGTH(CFCODE) <= 30))\n       AND\n       ( CFSOURCE <>  6 OR (CFSOURCE = 6 AND LENGTH(CFCODE) = 12) )\n     "
        ),
        db.Index("idx1_codif_cfinmarche", "cfcfin", "cfmarche"),
        db.Index("unq_codif", "cfcfin", "cfsource", "cfmarche", "cftype"),
        {"schema": "exane"},
    )

    cfcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    cfsource = db.Column(
        db.ForeignKey("exane.source.socode"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de la source du flux",
    )
    cfmarche = db.Column(
        db.ForeignKey("exane.marche.macode"),
        primary_key=True,
        nullable=False,
        server_default=db.FetchedValue(),
        info="Code du marché de cotation",
    )
    cftype = db.Column(
        db.ForeignKey("exane.typedatarecup.trcode"),
        primary_key=True,
        nullable=False,
        info="Code du type de donnees à récupérer",
    )
    cfcode = db.Column(db.String(50), primary_key=True, nullable=False, info="Code RIC")
    cfmodecot = db.Column(
        db.ForeignKey("exane.modecot.mocode"), info="Code mode cotation"
    )
    cfdesc = db.Column(
        db.String(120), info="Liste des codes informatiques des flux d'informations"
    )
    cfstatut = db.Column(
        db.Numeric(1, 0, asdecimal=False), info="Statut de la source de flux"
    )
    cfmarge = db.Column(db.Numeric(6, 2), info="Seuil d'erreur d'une donnée récupérée")
    cfcoeff = db.Column(
        db.Numeric(6, 0, asdecimal=False),
        info="Coefficient correctif appliqué sur la valeur d'un flux",
    )
    cfrecup = db.Column(
        db.Numeric(1, 0, asdecimal=False), info="Récupération du flux souhaité ou pas"
    )
    cfhorodate = db.Column(db.DateTime)

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Code.cfcfin == Instrument.ifcfin",
        lazy=True,
        backref="codes",
    )
    marche = db.relationship(
        "Marche",
        primaryjoin="Code.cfmarche == Marche.macode",
        lazy=True,
        backref="codes",
    )
    modecot = db.relationship(
        "Modecot",
        primaryjoin="Code.cfmodecot == Modecot.mocode",
        lazy=True,
        backref="codes",
    )
    source = db.relationship(
        "Source",
        primaryjoin="Code.cfsource == Source.socode",
        lazy=True,
        backref="codes",
    )
    typedatarecup = db.relationship(
        "Typedatarecup",
        primaryjoin="Code.cftype == Typedatarecup.trcode",
        lazy=True,
        backref="codes",
    )


class Collection(db.Model):
    __tablename__ = "collection"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    clcollect = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    clsjac = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    cldatein = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Date d'entrée du Sjac de la collection",
    )
    cldateout = db.Column(db.DateTime, info="Date de sortie du Sjac de la collection")
    cltypecollect = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Type de collection.  cf GDN\t"
    )
    cldiviseur = db.Column(
        db.Numeric(24, 15),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Diviseur ou coefficient d'ajustement\t",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Collection.clcollect == Instrument.ifcfin",
        lazy=True,
        backref="instrument_collections",
    )
    # instrument1 = db.relationship(
    #     "Instrument",
    #     primaryjoin="Collection.clsjac == Instrument.ifcfin",
    #     lazy=True,
    #     backref="instrument_collections_0",
    # )


class Composition(db.Model):
    __tablename__ = "composition"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("CPCFIN<>CPSJAC"),
        db.CheckConstraint("CPCFIN<>CPSJAC"),
        db.Index("est_sjac_pdtstructure_fk", "cpcollect", "cpsjac"),
        {"schema": "exane"},
    )

    cpcfin = db.Column(
        db.ForeignKey("exane.pdtcompo.pccfin"),
        primary_key=True,
        nullable=False,
        index=True,
        info="CFIN de la composition",
    )
    cpsjac = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        index=True,
        info="CFIN de l’élément de composition",
    )
    cpcollect = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        index=True,
        info="CFIN de la collection rattachée à la composition",
    )
    cpcoeffajust = db.Column(
        db.Numeric(24, 15), info="Coefficient d'ajustement du sjac de la composition"
    )
    cppoids = db.Column(
        db.Numeric(11, 5), info="Poids du sjac au sein de la composition"
    )
    cpquantite = db.Column(db.Numeric(24, 15), info="Quantité de titres")
    cpcashsettlpart = db.Column(
        db.Numeric(4, 3),
        info="Coefficient de répartition du cash livré (option sur panier)",
    )

    pdtcompo = db.relationship(
        "Pdtcompo",
        primaryjoin="Composition.cpcfin == Pdtcompo.pccfin",
        lazy=True,
        backref="pdtcompo_pdtcompo_compositions",
    )
    # instrument = db.relationship(
    #     "Instrument",
    #     primaryjoin="Composition.cpcollect == Instrument.ifcfin",
    #     lazy=True,
    #     backref="instrument_compositions",
    # )
    # instrument1 = db.relationship(
    #     "Instrument",
    #     primaryjoin="Composition.cpsjac == Instrument.ifcfin",
    #     lazy=True,
    #     backref="instrument_pdtcompo_compositions",
    # )


class CompositionH(db.Model):
    __tablename__ = "composition_h"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    rowid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cphcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        nullable=False,
        index=True,
        info="CFIN de la composition",
    )
    cphsjac = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        nullable=False,
        index=True,
        info="CFIN de l’élément de composition",
    )
    cphcollect = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        index=True,
        info="CFIN de la collection rattachée à la composition",
    )
    cphdate = db.Column(
        db.DateTime,
        nullable=False,
        index=True,
        server_default=db.FetchedValue(),
        info="date de mise à jour",
    )
    cphcoeffajust = db.Column(
        db.Numeric(24, 15), info="Coefficient d'ajustement du sjac de la composition"
    )
    cphpoids = db.Column(
        db.Numeric(11, 5), info="Poids du sjac au sein de la composition"
    )
    cphquantite = db.Column(db.Numeric(24, 15), info="Quantité de titres")
    cphcashsettlpart = db.Column(
        db.Numeric(12, 5),
        info="Pourcentage de settlement cash à appliquer sur l’élément de composition pour les options sur basket (exemple 0.95 signifie 95%).",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="CompositionH.cphcfin == Instrument.ifcfin",
        lazy=True,
        backref="instrument_instrument_composition_hs",
    )
    # instrument1 = db.relationship(
    #     "Instrument",
    #     primaryjoin="CompositionH.cphcollect == Instrument.ifcfin",
    #     lazy=True,
    #     backref="instrument_instrument_composition_hs_0",
    # )
    # instrument2 = db.relationship(
    #     "Instrument",
    #     primaryjoin="CompositionH.cphsjac == Instrument.ifcfin",
    #     lazy=True,
    #     backref="instrument_instrument_composition_hs",
    # )


class Contributeur(db.Model):
    __tablename__ = "contributeur"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    cocode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="Code contributeur"
    )
    conom = db.Column(db.String(15), info="Nom contributeur")


class Marche(db.Model):
    __tablename__ = "marche"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    macode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code du marché de cotation",
    )
    maplace = db.Column(
        db.ForeignKey("exane.place.plcode"),
        nullable=False,
        index=True,
        info="Code de la place de cotation",
    )
    manom = db.Column(db.String(60), nullable=False, info="Nom du marché de cotation")
    mamic = db.Column(db.String(4), info="Code MIC du marché")
    mafininfo = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Code FinInfo du marché"
    )
    mareuter = db.Column(db.String(3), info="Code Reuter du marché")
    macamelot = db.Column(
        db.String(3), info="Préfixe du code Camelot de la place associée."
    )

    place = db.relationship(
        "Place",
        primaryjoin="Marche.maplace == Place.plcode",
        lazy=True,
        backref="marches",
    )


class Cotation(db.Model):
    __tablename__ = "cotation"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    cotcfin = db.Column(
        db.ForeignKey("exane.produits.prcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        info="Code de l'instrument financier",
    )
    cotmarche = db.Column(
        db.ForeignKey("exane.marche.macode"),
        primary_key=True,
        nullable=False,
        info="Code du marché de cotation",
    )
    cotstatut = db.Column(db.ForeignKey("exane.typestatut.tstcode"))

    produit = db.relationship(
        "Produit",
        primaryjoin="Cotation.cotcfin == Produit.prcfin",
        lazy=True,
        backref="cotations",
    )
    marche = db.relationship(
        "Marche",
        primaryjoin="Cotation.cotmarche == Marche.macode",
        lazy=True,
        backref="cotations",
    )
    typestatut = db.relationship(
        "Typestatut",
        primaryjoin="Cotation.cotstatut == Typestatut.tstcode",
        lazy=True,
        backref="cotations",
    )


class Last(Cotation):
    __tablename__ = "last"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("lapriclos is not null"),
        db.ForeignKeyConstraint(
            ["lacfin", "lamarche"],
            ["exane.cotation.cotcfin", "exane.cotation.cotmarche"],
            ondelete="CASCADE",
        ),
        {"schema": "exane"},
    )

    lacfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de l'instrument financier",
    )
    lamarche = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code du marché de cotation",
    )
    ladate = db.Column(db.DateTime, nullable=False, info="LADATE")
    lapriclos = db.Column(db.Numeric(13, 5), info="LAPRICLOS")
    lapriopen = db.Column(db.Numeric(13, 5), info="LAPRIOPEN")
    laprimoypond = db.Column(db.Numeric(13, 5), info="LAPRIMOYPOND")
    lapo = db.Column(db.Numeric(16, 5), info="LAPO")
    lavolqute = db.Column(db.Numeric(18, 2), info="LAVOLQUTE")
    lavolcapi = db.Column(db.Numeric(18, 2), info="LAVOLCAPI")
    ladatepr = db.Column(db.DateTime, info="LADATEPR")
    lapriclospr = db.Column(db.Numeric(13, 5), info="LAPRICLOSPR")
    lapriopenpr = db.Column(db.Numeric(13, 5), info="LAPRIOPENPR")
    laprimoypondpr = db.Column(db.Numeric(13, 5), info="LAPRIMOYPONDPR")
    lapopr = db.Column(db.Numeric(16, 2), info="LAPOPR")
    lavolqutepr = db.Column(db.Numeric(18, 2), info="LAVOLQUTEPR")
    lavolcapipr = db.Column(db.Numeric(18, 2), info="LAVOLCAPIPR")
    lahigh = db.Column(db.Numeric(13, 5), info="Cours plus haut derniere cotation\t")
    lahighpr = db.Column(db.Numeric(13, 5), info="Cours plus haut jour précedant\t")
    lalow = db.Column(db.Numeric(13, 5), info="Cours plus bas derniere cotation\t")
    lalowpr = db.Column(db.Numeric(13, 5), info="Cours plus bas jour précedant\t")
    labid = db.Column(db.Numeric(13, 5), info=" Prix achat Jour")
    laask = db.Column(db.Numeric(13, 5), info=" Prix vente  Jour")
    labidpr = db.Column(db.Numeric(13, 5), info=" Prix achat Jour-1")
    laaskpr = db.Column(db.Numeric(13, 5), info=" Prix vente Jour-1")
    ladatecotation = db.Column(db.DateTime, info="Date source de la cotation")


class Crosshistorique(db.Model):
    __tablename__ = "crosshistorique"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    chcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        nullable=False,
        info="cfin cross",
    )
    chdate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="date de valeur du cross"
    )
    chvaleur = db.Column(db.Numeric(20, 10), nullable=False, info="valeur du cross")
    chtype = db.Column(
        db.ForeignKey("exane.typecross.tccode"),
        primary_key=True,
        nullable=False,
        info="source du cross",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Crosshistorique.chcfin == Instrument.ifcfin",
        lazy=True,
        backref="crosshistoriques",
    )
    typecros = db.relationship(
        "Typecros",
        primaryjoin="Crosshistorique.chtype == Typecros.tccode",
        lazy=True,
        backref="crosshistoriques",
    )


class Famille(db.Model):
    __tablename__ = "famille"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    facode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code de la famille d'un type dinstruments",
    )
    fanom = db.Column(
        db.String(15), nullable=False, info="Nom de la famille d'un type dinstruments"
    )


class Grpuser(db.Model):
    __tablename__ = "grpuser"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    gucode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code du groupe d'utilisateurs",
    )
    gunom = db.Column(db.String(15), nullable=False, info="Nomdu groupe d'utilisateurs")


class Historique(db.Model):
    __tablename__ = "historiques"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("hoclose is not null"),
        db.ForeignKeyConstraint(
            ["hocfin", "homarche"],
            ["exane.cotation.cotcfin", "exane.cotation.cotmarche"],
            ondelete="CASCADE",
        ),
        db.Index("idx2_hist_cfinmarche", "hocfin", "homarche"),
        {"schema": "exane"},
    )

    hocfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code de l'instrument financier",
    )
    homarche = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        nullable=False,
        info="Code du marché de cotation",
    )
    hodate = db.Column(
        db.DateTime, primary_key=True, nullable=False, info="Date historisation"
    )
    hoopen = db.Column(db.Numeric(13, 5), info="Cours ouverture")
    hoclosbrut = db.Column(db.Numeric(13, 5), info="Closing non modifie meme apres OST")
    hoclose = db.Column(db.Numeric(13, 5), info="Cours cloture")
    houpper = db.Column(db.Numeric(13, 5), info="Cours le plus haut")
    hodown = db.Column(db.Numeric(13, 5), info="Cours le plus bas")
    hovolume = db.Column(db.Numeric(18, 2), info="Volume traite")
    hocapi = db.Column(db.Numeric(18, 2), info="Capitaux traites")
    hobid = db.Column(db.Numeric(13, 5), info=" Prix achat Jour")
    hoask = db.Column(db.Numeric(13, 5), info=" Prix vente Jour")

    cotation = db.relationship(
        "Cotation",
        primaryjoin="and_(Historique.hocfin == Cotation.cotcfin, Historique.homarche == Cotation.cotmarche)",
        lazy=True,
        backref="historiques",
    )


class Hsectorisation(db.Model):
    __tablename__ = "hsectorisation"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    hstiers = db.Column(
        db.ForeignKey("exane.tiers.ticode", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code d'une personne physique ou morale",
    )
    hscode = db.Column(
        db.ForeignKey("exane.secteur.secode"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code secteur",
    )
    hsdatein = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Date d'entrée d'une société dans un secteur d'activité",
    )
    hsdateout = db.Column(
        db.DateTime, info="Date de sortie d'une société dans un secteur d'activité"
    )

    secteur = db.relationship(
        "Secteur",
        primaryjoin="Hsectorisation.hscode == Secteur.secode",
        lazy=True,
        backref="hsectorisations",
    )
    tier = db.relationship(
        "Tier",
        primaryjoin="Hsectorisation.hstiers == Tier.ticode",
        lazy=True,
        backref="hsectorisations",
    )


class Instrumentcomplement(db.Model):
    __tablename__ = "instrumentcomplement"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("ICAETEENPOSITION IN (2,1,0)"),
        db.CheckConstraint("ICAETEINTERMEDIE IN (1,0)"),
        db.CheckConstraint("ICDOUBLON IN (1,0)"),
        db.CheckConstraint("ICValidation in ('N', 'M', 'R', 'C', 'V', 'A')"),
        {"schema": "exane"},
    )

    iccfin = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="CFIN sur le quel porte les informations complémentaires",
    )
    icvalidation = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="N : Non validé | M : Modifié | R : Refusé Non Validé | C : Refusé Non Conforme | V : Validé | A : A modifier",
    )
    icpropagationvalidation = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="0 : Pas de propagation du status de validation | 1 : Propagation du status de validation",
    )
    icetatdevie = db.Column(
        db.ForeignKey("exane.typeetatdevie.tvcode"), info="Etat de vie de l'instrument."
    )
    icposition = db.Column(
        db.ForeignKey("exane.typeposition.tpcode"),
        info="Définit si l'instrument peut être en position.",
    )
    icintermediation = db.Column(
        db.ForeignKey("exane.typeintermediation.ticode"),
        info="Définit si l'instrument peut être intermédié.",
    )
    icdiffusion = db.Column(
        db.ForeignKey("exane.typediffusion.tdcode"),
        info="Définit si l'instrument peut être diffusé.",
    )
    icdoublon = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        info="Définit si l'instrument est un doublon (1 si oui 0 sinon).",
    )
    icaeteenposition = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        info='Définit si l\'instrument est ou a étéen position (1 si "en position", 2 si "a été" 0 si "jamais en pos").',
    )
    icaeteintermedie = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Définit si l'instrument a été en intermédié (1 si oui 0 sinon).",
    )
    icvalidationattribut = db.Column(
        db.ForeignKey("exane.typevalidationattribut.tvcode"),
        info="Sous statut de validation : Validé Non Conforme, Conforme gestion... (liaison avec les scripts)",
    )
    icvalideur = db.Column(
        db.ForeignKey("exane.typeproprietairevalidation.tvcode"),
        info="Code du propriétaire du statut de validation (cf. TYPEPROPRIETAIREVALIDATION)",
    )

    typediffusion = db.relationship(
        "Typediffusion",
        primaryjoin="Instrumentcomplement.icdiffusion == Typediffusion.tdcode",
        lazy=True,
        backref="instrumentcomplements",
    )
    typeetatdevie = db.relationship(
        "Typeetatdevie",
        primaryjoin="Instrumentcomplement.icetatdevie == Typeetatdevie.tvcode",
        lazy=True,
        backref="instrumentcomplements",
    )
    typeintermediation = db.relationship(
        "Typeintermediation",
        primaryjoin="Instrumentcomplement.icintermediation == Typeintermediation.ticode",
        lazy=True,
        backref="instrumentcomplements",
    )
    typeposition = db.relationship(
        "Typeposition",
        primaryjoin="Instrumentcomplement.icposition == Typeposition.tpcode",
        lazy=True,
        backref="instrumentcomplements",
    )
    typevalidationattribut = db.relationship(
        "Typevalidationattribut",
        primaryjoin="Instrumentcomplement.icvalidationattribut == Typevalidationattribut.tvcode",
        lazy=True,
        backref="instrumentcomplements",
    )
    typeproprietairevalidation = db.relationship(
        "Typeproprietairevalidation",
        primaryjoin="Instrumentcomplement.icvalideur == Typeproprietairevalidation.tvcode",
        lazy=True,
        backref="instrumentcomplements",
    )


class Courbetx(Instrument):
    __tablename__ = "courbetx"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    cbcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    cbfwd = db.Column(
        db.ForeignKey("exane.maturite.mtcode"),
        index=True,
        info="Code maturite d'un taux, d'une volatilité",
    )
    cbcontrib = db.Column(
        db.ForeignKey("exane.contributeur.cocode"), index=True, info="Code contributeur"
    )
    cbnature = db.Column(
        db.ForeignKey("exane.nature.nacode"),
        nullable=False,
        index=True,
        info="Code nature",
    )
    cbmethode = db.Column(
        db.ForeignKey("exane.methode.mecode"),
        nullable=False,
        index=True,
        info="Code methode construction de courbe",
    )
    cbdev = db.Column(
        db.ForeignKey("exane.devise.dvcfin"),
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )

    contributeur = db.relationship(
        "Contributeur",
        primaryjoin="Courbetx.cbcontrib == Contributeur.cocode",
        lazy=True,
        backref="courbetxes",
    )
    devise = db.relationship(
        "Devise",
        primaryjoin="Courbetx.cbdev == Devise.dvcfin",
        lazy=True,
        backref="courbetxes",
    )
    maturite = db.relationship(
        "Maturite",
        primaryjoin="Courbetx.cbfwd == Maturite.mtcode",
        lazy=True,
        backref="courbetxes",
    )
    methode = db.relationship(
        "Methode",
        primaryjoin="Courbetx.cbmethode == Methode.mecode",
        lazy=True,
        backref="courbetxes",
    )
    nature = db.relationship(
        "Nature",
        primaryjoin="Courbetx.cbnature == Nature.nacode",
        lazy=True,
        backref="courbetxes",
    )


class Devise(Instrument):
    __tablename__ = "devise"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    dvcfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    dvpays = db.Column(
        db.ForeignKey("exane.pays.pacode"), nullable=False, index=True, info="Code pays"
    )
    dvcodeiso = db.Column(db.String(3), unique=True)
    dvlibelle = db.Column(db.String(60), info="Libelle de la devise ")

    pays = db.relationship(
        "Pays", primaryjoin="Devise.dvpays == Pays.pacode", lazy=True, backref="devises"
    )


class Tier(db.Model):
    __tablename__ = "tiers"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("TITYPE IN ('T','G','P')"),
        db.CheckConstraint("TITYPE IN ('T','G','P')"),
        {"schema": "exane"},
    )

    ticode = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        primary_key=True,
        info="Code d'une personne physique ou morale",
    )
    tipays = db.Column(
        db.ForeignKey("exane.pays.pacode"), nullable=False, index=True, info="Code pays"
    )
    tinom = db.Column(
        db.String(60), nullable=False, info="Nom d'une personne physique ou morale"
    )
    timemo = db.Column(db.String(4), nullable=False, info="Abréviation du nom du tiers")
    tisuivi = db.Column(
        db.String(1),
        info="Type de suivi sur une société assuré par un analyste financier",
    )
    titype = db.Column(db.String(1), nullable=False)
    tiappartenance = db.Column(db.ForeignKey("exane.grpuser.gucode"))
    tistatut = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Statut",
    )
    tivaliderdc = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Ce champ ne doit plus être utilisé (remplacé par REFDOC.KYCINFORMATION.KIVALIDERDC)",
    )
    tiratingconf = db.Column(db.ForeignKey("exane.ratconformitetiers.rgcode"))
    tipaysrisk = db.Column(db.Numeric(3, 0, asdecimal=False), info="Code pays risque")
    tiformejuridique = db.Column(
        db.Numeric(2, 0, asdecimal=False), info="Forme juridique du tiers"
    )

    grpuser = db.relationship(
        "Grpuser",
        primaryjoin="Tier.tiappartenance == Grpuser.gucode",
        lazy=True,
        backref="tiers",
    )
    pays = db.relationship(
        "Pays", primaryjoin="Tier.tipays == Pays.pacode", lazy=True, backref="pay_tiers"
    )
    pays1 = db.relationship(
        "Pays",
        primaryjoin="Tier.tipaysrisk == Pays.pacode",
        lazy=True,
        backref="pay_tiers_0",
    )
    ratconformitetier = db.relationship(
        "Ratconformitetier",
        primaryjoin="Tier.tiratingconf == Ratconformitetier.rgcode",
        lazy=True,
        backref="tiers",
    )


class Emisstructuree(Instrument):
    __tablename__ = "emisstructuree"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("ESCALLABLE is null or ( ESCALLABLE in ('O','N') )"),
        db.CheckConstraint("ESCALLABLE is null or ( ESTYPESETTLEMENT in (1,2) )"),
        db.CheckConstraint("ESCALLABLE is null or ( ESTYPESETTLEMENT in (1,2) )"),
        db.CheckConstraint("ESESTFLUX IN ('O','N')"),
        db.CheckConstraint("ESFREQUENCE >= 1 AND ESFREQUENCE <= 8"),
        db.CheckConstraint("ESINDEX is null or ( ESINDEX in ('O','N') )"),
        {"schema": "exane"},
    )

    escfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    estprotect = db.Column(
        db.ForeignKey("exane.typeprotection.tpnum"), info="Type de protection"
    )
    estupside = db.Column(db.ForeignKey("exane.typeupside.tunum"), info="Type d'Upside")
    estcoupon = db.Column(
        db.ForeignKey("exane.typecoupon.tcnum"), info="Type de coupon"
    )
    escallable = db.Column(
        db.String(1), server_default=db.FetchedValue(), info="Es callable"
    )
    esindex = db.Column(
        db.String(1), server_default=db.FetchedValue(), info="est Indexation"
    )
    descriptif_fr = db.Column(db.String(1024), info="Description longue FR")
    descriptif_uk = db.Column(db.String(1024), info="Description longue UK")
    libelle_fr = db.Column(db.String(255), info="Libelle court FR")
    libelle_uk = db.Column(db.String(255), info="Libelle court UK")
    esscogestion = db.Column(db.ForeignKey("exane.tiers.ticode"))
    esdistrib = db.Column(
        db.Numeric(8, 0, asdecimal=False), db.ForeignKey("exane.tiers.ticode")
    )
    esmulti = db.Column(db.String(1), server_default=db.FetchedValue())
    escadrefiscal = db.Column(db.ForeignKey("exane.typefamillefonds.tfdcode"))
    esgestion = db.Column(db.Numeric(3, 0, asdecimal=False))
    esprofil = db.Column(db.Numeric(3, 0, asdecimal=False))
    espayoff = db.Column(db.String(4000))
    esbarriere = db.Column(db.ForeignKey("exane.typebarriere.tbacode"))
    esmontantcoupon = db.Column(
        db.Numeric(8, 4), info="Montant annuel initial (en % du nominal)"
    )
    eslevier = db.Column(db.ForeignKey("exane.typelevier.tlvcode"))
    estspread = db.Column(db.Numeric(10, 3), info="Spread Bid/Ask")
    esfrequence = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="FrÃ©ence pour le montant du coupon (Annuel=1, Semestriel=2, Trimestriel=3, Mensuel=4, In Fine=5, Bi-mensuel=6,Quadrimestriel=7,Bimestriel=8)",
    )
    esproccoupon = db.Column(db.DateTime, info="Date prochain coupon")
    esnumcoupon = db.Column(
        db.Numeric(8, 0, asdecimal=False), info="Nombre de coupons payés"
    )
    esextype = db.Column(db.String(1), info="Exercice Américain ou Européen")
    esrembanticip = db.Column(
        db.DateTime, info="Date de remboursement par anticipation"
    )
    estypesjc = db.Column(
        db.ForeignKey("exane.typesjcemisstructuree.tsecode"), info="Code du type sjc"
    )
    estypesettlement = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        info="Type de Settlement (Physical=1, Cash=2)",
    )
    escouponannualise = db.Column(db.Numeric(8, 4), info="Montant coupon annualisé")
    esestflux = db.Column(
        db.String(1),
        info="Cette colonne n'est plus utilisee, elle est remplacee par MFSSTFLUX de MARGEFLUXSTRUCTURE",
    )
    esmargeflux = db.Column(
        db.Numeric(13, 5),
        info="Cette colonne n'est plus utilisee, elle est remplacee par MFSMARGEFLUX de MARGEFLUXSTRUCTURE",
    )
    esupfrontfee = db.Column(db.Numeric(8, 4), info="Montant Upfront Fee (DF)")
    esannualfee = db.Column(db.Numeric(8, 4), info="Montant Annual Fee (SF)")
    estypeclient = db.Column(
        db.ForeignKey("exane.typeclient.tccode"), info="Type du client"
    )
    esstatutdiffusioncsd = db.Column(
        db.ForeignKey("exane.typestatutdiffusioncsd.sdcode"),
        info="Statut diffusion CSD (Dépositaire Central, ex EuroClear)",
    )
    esexplicationstatutdiffcsd = db.Column(
        db.String(4000),
        info="Explication du statut de diffusion CSD (Dépositaire Central, ex EuroClear)",
    )
    esdatemajstatutdiffcsd = db.Column(
        db.DateTime,
        info="Date maj statut diffusion CSD (Dépositaire Central, ex EuroClear)",
    )
    esstrike = db.Column(db.Numeric(13, 5), info="Strike")
    esdevstrike = db.Column(
        db.ForeignKey("exane.devise.dvcfin"), info="Devise du strike"
    )
    esprotectionbarrier = db.Column(
        db.Numeric(asdecimal=False), info="Valeur barrière de protection"
    )
    escoupon = db.Column(
        db.Numeric(18, 7), info="Valeur nominale du coupon payé par le crescendo"
    )
    esparite = db.Column(db.Numeric(11, 5), info="Parité")
    esproportion = db.Column(db.Numeric(11, 5), info="Proportion")

    typebarriere = db.relationship(
        "Typebarriere",
        primaryjoin="Emisstructuree.esbarriere == Typebarriere.tbacode",
        lazy=True,
        backref="emisstructurees",
    )
    typefamillefond = db.relationship(
        "Typefamillefond",
        primaryjoin="Emisstructuree.escadrefiscal == Typefamillefond.tfdcode",
        lazy=True,
        backref="typefamillefond_typefamillefond_emisstructurees",
    )
    devise = db.relationship(
        "Devise",
        primaryjoin="Emisstructuree.esdevstrike == Devise.dvcfin",
        lazy=True,
        backref="emisstructurees",
    )
    tier = db.relationship(
        "Tier",
        primaryjoin="Emisstructuree.esdistrib == Tier.ticode",
        lazy=True,
        backref="tier_emisstructurees",
    )
    # typefamillefond1 = db.relationship(
    #     "Typefamillefond",
    #     primaryjoin="Emisstructuree.esgestion == Typefamillefond.tfdcode",
    #     lazy=True,
    #     backref="typefamillefond_typefamillefond_emisstructurees_0",
    # )
    typelevier = db.relationship(
        "Typelevier",
        primaryjoin="Emisstructuree.eslevier == Typelevier.tlvcode",
        lazy=True,
        backref="emisstructurees",
    )
    # typefamillefond2 = db.relationship(
    #     "Typefamillefond",
    #     primaryjoin="Emisstructuree.esprofil == Typefamillefond.tfdcode",
    #     lazy=True,
    #     backref="typefamillefond_typefamillefond_emisstructurees",
    # )
    # tier1 = db.relationship(
    #     "Tier",
    #     primaryjoin="Emisstructuree.esscogestion == Tier.ticode",
    #     lazy=True,
    #     backref="tier_emisstructurees_0",
    # )
    typestatutdiffusioncsd = db.relationship(
        "Typestatutdiffusioncsd",
        primaryjoin="Emisstructuree.esstatutdiffusioncsd == Typestatutdiffusioncsd.sdcode",
        lazy=True,
        backref="emisstructurees",
    )
    typecoupon = db.relationship(
        "Typecoupon",
        primaryjoin="Emisstructuree.estcoupon == Typecoupon.tcnum",
        lazy=True,
        backref="emisstructurees",
    )
    typeprotection = db.relationship(
        "Typeprotection",
        primaryjoin="Emisstructuree.estprotect == Typeprotection.tpnum",
        lazy=True,
        backref="emisstructurees",
    )
    typeupside = db.relationship(
        "Typeupside",
        primaryjoin="Emisstructuree.estupside == Typeupside.tunum",
        lazy=True,
        backref="emisstructurees",
    )
    typeclient = db.relationship(
        "Typeclient",
        primaryjoin="Emisstructuree.estypeclient == Typeclient.tccode",
        lazy=True,
        backref="emisstructurees",
    )
    typesjcemisstructuree = db.relationship(
        "Typesjcemisstructuree",
        primaryjoin="Emisstructuree.estypesjc == Typesjcemisstructuree.tsecode",
        lazy=True,
        backref="emisstructurees",
    )


class Derive(Produit):
    __tablename__ = "derives"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("DECFIN<>DESJAC"),
        db.CheckConstraint("DECFIN<>DESJAC"),
        {"schema": "exane"},
    )

    decfin = db.Column(
        db.ForeignKey("exane.produits.prcfin", ondelete="CASCADE"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    desjac = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        index=True,
        info="Code de l'instrument financier",
    )
    dereg = db.Column(
        db.ForeignKey("exane.mode_reglement.mrcode"),
        info="Libelle du mode de reglement",
    )
    decouv = db.Column(db.String(1), info="Type de couverture")
    deassim = db.Column(db.String(1), info="Type d'assimilation")
    desoulteuro = db.Column(db.Numeric(8, 2), info="Soulte Euro")
    deappelmarge = db.Column(
        db.Enum("O", "N"),
        server_default=db.FetchedValue(),
        info="Précise si le derive fonctionne avec appel de marge et non pas avec une prime (O/N)",
    )

    mode_reglement = db.relationship(
        "ModeReglement",
        primaryjoin="Derive.dereg == ModeReglement.mrcode",
        lazy=True,
        backref="derives",
    )
    instrument = db.relationship(
        "Instrument",
        primaryjoin="Derive.desjac == Instrument.ifcfin",
        lazy=True,
        backref="derives",
    )


class Script(Derive):
    __tablename__ = "script"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("SCSTATUT IN ('P','M','V','I')"),
        db.CheckConstraint("SCSTATUTCONTRACTUEL IN ('P', 'M','V','I')"),
        {"schema": "exane"},
    )

    sccfin = db.Column(
        db.ForeignKey("exane.derives.decfin", ondelete="CASCADE"), primary_key=True
    )
    sctype = db.Column(db.Numeric(3, 0, asdecimal=False))
    scstrike = db.Column(db.Numeric(13, 5))
    scdevstrike = db.Column(db.Numeric(8, 0, asdecimal=False))
    scparite = db.Column(db.Numeric(11, 5))
    scproportion = db.Column(db.Numeric(11, 5))
    scstatut = db.Column(db.String(1))
    scscript = db.Column(db.Text)
    scstatutcontractuel = db.Column(db.String(1))
    scscriptcontractuel = db.Column(db.Text)


class Emission(Produit):
    __tablename__ = "emission"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("EMKIBI IN ('Y','N')"),
        db.CheckConstraint("EMOPENEND IN ('Y','N')"),
        db.CheckConstraint("EMTYPETRADING IN ('C','F')"),
        db.Index("idx1_emission", "emcfin", "emissuer"),
        {"schema": "exane"},
    )

    emcfin = db.Column(
        db.ForeignKey("exane.produits.prcfin", ondelete="CASCADE"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    emissuer = db.Column(
        db.ForeignKey("exane.tiers.ticode"),
        nullable=False,
        index=True,
        info="Code d'une personne physique ou morale",
    )
    emtype = db.Column(db.String(1), info="Emission (P)ublique ou privée(X)")
    emdate = db.Column(db.DateTime, info="Date de l'émission de l'instrument")
    empaiement = db.Column(
        db.DateTime, info="Date initiale de calcul des intérêts sur l'instrument"
    )
    emnominal = db.Column(db.Numeric(18, 5), info="Valeur du nominal")
    emnomieuro = db.Column(db.Numeric(10, 2), info="Nominal marche en euro")
    emprix = db.Column(db.Numeric(18, 5), info="Prix d'emission")
    emspread = db.Column(db.Numeric(13, 5), info="Spread à l'émission")
    emnomport = db.Column(db.String(1), info="Type souscription")
    emprixpoint = db.Column(
        db.Numeric(10, 2), server_default=db.FetchedValue(), info="Prix du point"
    )
    emcapiinit = db.Column(db.Numeric(18, 2), info="Capitalisation initiale")
    emprime = db.Column(db.Numeric(13, 5), info="Prime d'emission")
    emrdt = db.Column(db.Numeric(13, 5), info="Rendement à maturité")
    emmaturite = db.Column(db.DateTime, info="Echeance ou maturité de l'instrument")
    emcapigarantie = db.Column(db.Numeric(18, 2), info="Capital garanti")
    emdatestrike = db.Column(db.DateTime, info="Date du strike")
    emopenend = db.Column(
        db.String(1), info="Definit si l'emission est un OpenEnd ou pas (Null <=> N)"
    )
    emtypetrading = db.Column(
        db.String(1), info="Mode de cotation : Continu ou Fixing "
    )
    emkibi = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info="Knock-In By Issuer pour répliquer la liste intraday",
    )

    tier = db.relationship(
        "Tier",
        primaryjoin="Emission.emissuer == Tier.ticode",
        lazy=True,
        backref="emissions",
    )


class Pdtcompo(Produit):
    __tablename__ = "pdtcompo"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("PCtypeRebalancement IN (0,1)"),
        db.CheckConstraint("pcSensAlimCollection IN ('E','S')"),
        db.Index("uk_pdtcompo", "pccfin", "pccollect"),
        {"schema": "exane"},
    )

    pccfin = db.Column(
        db.ForeignKey("exane.produits.prcfin", ondelete="CASCADE"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    pccollect = db.Column(
        db.ForeignKey("exane.instruments.ifcfin"),
        index=True,
        info="Code de l'instrument financier",
    )
    pctyperevenu = db.Column(
        db.ForeignKey("exane.typerevenu.tucode"),
        nullable=False,
        index=True,
        info="Code du type de revenu pris en compte dans le calcul d'un indice ou d'un panier",
    )
    pctypecalcul = db.Column(
        db.ForeignKey("exane.typecalcul.tccode"),
        nullable=False,
        index=True,
        info="Code du type de calcul de l'indice",
    )
    pccalc = db.Column(
        db.Numeric(1, 0, asdecimal=False), info="Calculé ou non calculé par Exane"
    )
    pccalendrier = db.Column(
        db.ForeignKey("exane.pays.pacode"),
        info="Code pays du calendrier de calcul de l'indice",
    )
    pctyperebalancement = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        info="Type de rebalancement : 0 continuité sur cours veille, continuité 1 cours jour",
    )
    pcindicereference = db.Column(
        db.Numeric(asdecimal=False),
        # db.ForeignKey("exane.produits.prcfin"),
        db.ForeignKey(Produit.ifcfin),
        info="Indice de reference",
    )
    pcsensalimcollection = db.Column(
        db.String(1),
        server_default=db.FetchedValue(),
        info='Indique si la collection associée à la composition est la source de la composition (en entrée "E" ou Null) ou si elle cible (en sortie "S"). Cela définit quand / comment elle est mise à jour (cf Epix / RDR).',
    )

    pay = db.relationship(
        "Pays",
        primaryjoin="Pdtcompo.pccalendrier == Pays.pacode",
        lazy=True,
        backref="pdtcompoes",
    )
    instrument = db.relationship(
        "Instrument",
        primaryjoin="Pdtcompo.pccollect == Instrument.ifcfin",
        lazy=True,
        backref="pdtcompoes",
    )
    # produit = db.relationship(
    #     "Produit",
    #     # primaryjoin="Pdtcompo.pcindicereference == Produit.prcfin",
    #     primaryjoin="Pdtcompo.pcindicereference == Produit.prcfin",
    #     lazy=True,
    #     backref="produit",
    # )
    typecalcul = db.relationship(
        "Typecalcul",
        primaryjoin="Pdtcompo.pctypecalcul == Typecalcul.tccode",
        lazy=True,
        backref="pdtcompoes",
    )
    typerevenu = db.relationship(
        "Typerevenu",
        primaryjoin="Pdtcompo.pctyperevenu == Typerevenu.tucode",
        lazy=True,
        backref="pdtcompoes",
    )


class Langue(db.Model):
    __tablename__ = "langue"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    lacode = db.Column(
        db.Numeric(3, 0, asdecimal=False), primary_key=True, info="code de la langue"
    )
    lanom = db.Column(
        db.String(50), nullable=False, info="libellé francais de la langue"
    )


class Maturite(db.Model):
    __tablename__ = "maturite"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    mtcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code maturite d'un taux, d'une volatilité",
    )
    mtday = db.Column(db.Numeric(5, 1), info="Maturite en jours")
    mtmonth = db.Column(db.Numeric(5, 1), info="Maturite en mois")
    mtyear = db.Column(db.Numeric(5, 1), info="Maturite en annees")


class Methode(db.Model):
    __tablename__ = "methode"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    mecode = db.Column(
        db.Numeric(2, 0, asdecimal=False),
        primary_key=True,
        info="Code methode construction de courbe",
    )
    menom = db.Column(
        db.String(15),
        nullable=False,
        info="Nom methode construction courbe, indicateur taux, volatilité",
    )


class ModeReglement(db.Model):
    __tablename__ = "mode_reglement"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    mrcode = db.Column(
        db.String(1), primary_key=True, info="Code du mode de réglement."
    )
    mrlibelle = db.Column(
        db.String(60), nullable=False, info="Libéllé du mode de réglement."
    )


class Modecot(db.Model):
    __tablename__ = "modecot"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    mocode = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, info="Code mode cotation"
    )
    monom = db.Column(db.String(20), nullable=False, info="Libelle mode cotation")


class Nature(db.Model):
    __tablename__ = "nature"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    nacode = db.Column(
        db.Numeric(2, 0, asdecimal=False), primary_key=True, info="Code nature"
    )
    nanom = db.Column(db.String(40), nullable=False, info="Nom nature")


class Place(db.Model):
    __tablename__ = "place"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    plcode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de la place de cotation",
    )
    plnom = db.Column(db.String(20), nullable=False, info="Nom de la place de cotation")


class Posrelative(db.Model):
    __tablename__ = "posrelative"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    pocode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code position relative",
    )
    ponom = db.Column(db.String(20), nullable=False, info="Nom position relative")
    poval = db.Column(db.String(20), info="Valeur position")


class Ratconformitetier(db.Model):
    __tablename__ = "ratconformitetiers"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    rgcode = db.Column(db.Numeric(3, 0, asdecimal=False), primary_key=True)
    rgstatut = db.Column(db.ForeignKey("exane.typestatut.tstcode"))
    rgnote = db.Column(db.String(60))

    typestatut = db.relationship(
        "Typestatut",
        primaryjoin="Ratconformitetier.rgstatut == Typestatut.tstcode",
        lazy=True,
        backref="ratconformitetiers",
    )


class Secteur(db.Model):
    __tablename__ = "secteur"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    secode = db.Column(
        db.Numeric(8, 0, asdecimal=False), primary_key=True, info="Code secteur"
    )
    setype = db.Column(
        db.ForeignKey("exane.typesecteurs.tsecode"),
        nullable=False,
        index=True,
        info="Code de la nomenclature des secteurs",
    )
    senom = db.Column(db.String(250), nullable=False, info="Nom du secteur")
    sename = db.Column(db.String(250), nullable=False, info="Nom du secteur en anglais")
    seordre = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        info="Ordre de presentation d'un secteur au sein d'une nomenclature",
    )
    selevel = db.Column(
        db.Numeric(3, 0, asdecimal=False), info="Niveau de composition du secteur"
    )
    senote = db.Column(
        db.ForeignKey("exane.typenote.tnnote"),
        index=True,
        info="Code de la note attribuée par une agence de rating",
    )
    seabrege = db.Column(db.String(20))

    typenote = db.relationship(
        "Typenote",
        primaryjoin="Secteur.senote == Typenote.tnnote",
        lazy=True,
        backref="secteurs",
    )
    typesecteur = db.relationship(
        "Typesecteur",
        primaryjoin="Secteur.setype == Typesecteur.tsecode",
        lazy=True,
        backref="secteurs",
    )


class Source(db.Model):
    __tablename__ = "source"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    socode = db.Column(
        db.Numeric(3, 0, asdecimal=False),
        primary_key=True,
        info="Code de la source du flux",
    )
    sonom = db.Column(db.String(15), nullable=False, info="Nomde la source du flux")
    sotype = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        info="Récupération automatique ou pas",
    )
    sounicite = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        nullable=False,
        info="Cette source emet des codes uniques. donnée Informelle : Valeur  0 (no check) ou 1(check+alien) ou 2(check)",
    )
    soctrlunique = db.Column(
        db.Numeric(1, 0, asdecimal=False),
        server_default=db.FetchedValue(),
        info="Les codes de cette source doivent être unique : Controle via trigger sur CODIF / par défaut pas unicite ",
    )


class Volinstr(db.Model):
    __tablename__ = "volinstr"
    __bind_key__ = "exane_analyse"
    __table_args__ = {"schema": "exane"}

    vicfin = db.Column(
        db.ForeignKey("exane.instruments.ifcfin", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code de l'instrument financier",
    )
    vimaturite = db.Column(
        db.ForeignKey("exane.maturite.mtcode"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code maturite d'un taux, d'une volatilité",
    )
    vimaj = db.Column(
        db.DateTime,
        primary_key=True,
        nullable=False,
        info="Date de mise à jour de la volatilité",
    )
    vitype = db.Column(
        db.ForeignKey("exane.typevolat.tvcode"),
        primary_key=True,
        nullable=False,
        info="Type de volatilité",
    )
    videv = db.Column(
        db.ForeignKey("exane.devise.dvcfin"),
        primary_key=True,
        nullable=False,
        info="Code de l'instrument financier",
    )
    vigroupe = db.Column(
        db.ForeignKey("exane.grpuser.gucode"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code du groupe d'utilisateurs",
    )
    viposition = db.Column(
        db.ForeignKey("exane.posrelative.pocode"),
        primary_key=True,
        nullable=False,
        index=True,
        info="Code position relative",
    )
    vivolat = db.Column(
        db.Numeric(8, 3),
        nullable=False,
        info="Valeur de la volatilité saise par un expert",
    )

    instrument = db.relationship(
        "Instrument",
        primaryjoin="Volinstr.vicfin == Instrument.ifcfin",
        lazy=True,
        backref="volinstrs",
    )
    devise = db.relationship(
        "Devise",
        primaryjoin="Volinstr.videv == Devise.dvcfin",
        lazy=True,
        backref="devise_volinstrs",
    )
    grpuser = db.relationship(
        "Grpuser",
        primaryjoin="Volinstr.vigroupe == Grpuser.gucode",
        lazy=True,
        backref="volinstrs",
    )
    maturite = db.relationship(
        "Maturite",
        primaryjoin="Volinstr.vimaturite == Maturite.mtcode",
        lazy=True,
        backref="volinstrs",
    )
    posrelative = db.relationship(
        "Posrelative",
        primaryjoin="Volinstr.viposition == Posrelative.pocode",
        lazy=True,
        backref="volinstrs",
    )
    typevolat = db.relationship(
        "Typevolat",
        primaryjoin="Volinstr.vitype == Typevolat.tvcode",
        lazy=True,
        backref="volinstrs",
    )


class Contrat(Produit):
    __tablename__ = "contrats"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint("CTAUTOEXERC  in ('O','N')"),
        db.CheckConstraint("CTAUTOEXERC  in ('O','N')"),
        {"schema": "exane"},
    )

    ctcfin = db.Column(
        db.ForeignKey("exane.produits.prcfin", ondelete="CASCADE"),
        primary_key=True,
        info="Code de l'instrument financier",
    )
    ctpremiumrule = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Nombre de jours ouvrés"
    )
    ctmaturite = db.Column(db.DateTime)
    cthorodate = db.Column(
        db.DateTime,
        server_default=db.FetchedValue(),
        info="Date de derniere mise à jour\t",
    )
    ctautoexerc = db.Column(db.String(1))


class Contratotc(Contrat):
    __tablename__ = "contratotcs"
    __bind_key__ = "exane_analyse"
    __table_args__ = (
        db.CheckConstraint(
            "COVALIDATION = 'N' OR COVALIDATION = 'M' OR COVALIDATION = 'R' OR COVALIDATION = 'V'"
        ),
        {"schema": "exane"},
    )

    cocfin = db.Column(
        db.ForeignKey("exane.contrats.ctcfin", ondelete="CASCADE"),
        primary_key=True,
        info="Code de l'instrument financier\t",
    )
    copayeur = db.Column(
        db.ForeignKey("exane.tiers.ticode"),
        nullable=False,
        info="Code tier identifiant le payeur",
    )
    coreceveur = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        db.ForeignKey(Tier.ticode),
        nullable=False,
        info="Code tier identifiant le receveur",
    )
    cocontratcadre = db.Column(
        db.ForeignKey("exane.typecontratcadre.tccode"), info="Contrat qui regit le swap"
    )
    coagent = db.Column(
        db.Numeric(8, 0, asdecimal=False), nullable=False, info="Code tier de l'agent\t"
    )
    cohorodate = db.Column(
        db.DateTime,
        server_default=db.FetchedValue(),
        info="Date de derniere mise à jour\t",
    )
    covalidation = db.Column(
        db.String(1),
        nullable=False,
        server_default=db.FetchedValue(),
        info="Gere la validation des contrats otc, toutes les caracteristiques qui peuvent influencer le contrat  agissent sur le champ COVALIDATION",
    )
    coreceveurinitial = db.Column(
        db.Numeric(8, 0, asdecimal=False),
        db.ForeignKey(Tier.ticode),
        info="Code tiers de la contrepartie initiale et qui sera renseigné uniquement pour les OTC clearés.",
    )

    typecontratcadre = db.relationship(
        "Typecontratcadre",
        primaryjoin="Contratotc.cocontratcadre == Typecontratcadre.tccode",
        backref="contratotcs",
    )
    tier = db.relationship(
        "Tier",
        primaryjoin="Contratotc.copayeur == Tier.ticode",
        backref="tier_tier_contratotcs",
    )
    tier1 = db.relationship(
        "Tier",
        primaryjoin="Contratotc.coreceveur == Tier.ticode",
        backref="tier_tier_contratotcs_0",
    )
    tier2 = db.relationship(
        "Tier",
        primaryjoin="Contratotc.coreceveurinitial == Tier.ticode",
        backref="tier_tier_contratotcs_1",
    )


if __name__ == "__main__":
    from app import server
    import pandas as pd

    pd.options.display.width = 800
    pd.set_option("max_rows", 35)
    pd.set_option("max_columns", 15)

    # Get types from DB
    with server.app_context():
        test = Instrument.query.filter_by(ifcfin=45088035).first()
        test = Produit.query.filter_by(prcfin=45088035).first()
        print(test.ifnom)

# -*- coding: utf-8 -*-
import os
import ast
import json

from dash import dcc
from dash import html
import dash_bootstrap_components as dbc
from dash.dependencies import Input, Output, State, ALL, MATCH

from flask import redirect, send_from_directory, request
from flask_apscheduler.api import delete_job
from flask_login import current_user, logout_user, login_required

from app import app, server, cache, scheduler, PATH
from views import login, users, jobs, logs, not_found
from apps import (
    stocks,
    home,
    trades,
    clients,
    bdd,
    backtest,
    products,
    isin,
    excel,
    excel_admin,
    rfq,
    rfq_structu,
    multipricer,
)
from local_db_mgt import create_user_table
from models.storing import cached_all_products
from models.menus_and_elements import header, footer

from utils.termsheets import get_termsheets
from utils.api_open_positions import OpenPositions
from utils.api.db_structuring import ExaneDataPoint, ExaneDataHistory, ExaneDataSet


app.layout = html.Div(
    [
        dcc.Location(id="url", refresh=False),
        html.Div(id="empty-div-for-title"),
        header,
        html.Div(id="page-content", style={"flex": 1,},),
        footer,
    ],
    # These settings are used to keep the footer at the end of the page
    style={"display": "flex", "min-height": " 100vh", "flex-direction": "column"},
)


@app.callback(
    Output("page-content", "children"),
    Input("url", "pathname"),
    Input("url", "search"),
)
def display_page(pn, search):
    if not current_user or not current_user.is_authenticated:
        return login.layout
    if pn is None:
        return home.serve_layout()
    if pn == "/remove-all-jobs":
        scheduler.remove_all_jobs()
        return home.serve_layout()
    if pn == "/clients" in pn:
        return clients.serve_layout()
    if pn == "/logs":
        return logs.serve_layout()
    elif pn == "/isin":
        return isin.serve_layout()
    elif "/products" in pn:
        return products.serve_layout(search)
    elif "/trades" in pn:
        return trades.serve_layout(search)
    if pn in [None, "/", "/login"] or "/home" in pn:
        return home.serve_layout()
    elif pn == "/logout":
        logout_user()
        redirect("/home")
        return login.layout
    elif pn == "/delete_job":
        delete_job(search[1:])
        return jobs.serve_layout()
    elif pn == "/create_user_table":
        create_user_table()
        return users.serve_layout()
    elif "/stocks" in pn:
        return stocks.serve_layout()
    elif "/clearcache" in pn:
        cache.clear()
        return home.serve_layout()
    elif "/backtest" in pn:
        return backtest.serve_layout()
    elif "/packages" in pn:
        from pip._internal.operations import freeze

        return " | ".join(x for x in freeze.freeze())
    elif "/excel/admin" in pn:
        return excel_admin.serve_layout()
    elif "/excel" in pn:
        return excel.serve_layout()
    elif pn == "/users":
        if "STR" in current_user.department_id:
            return users.serve_layout()
    elif pn == "/rfq-structu":
        if "STR" in current_user.department_id:
            return rfq_structu.serve_layout()
    elif pn == "/rfq":
        if "STR" in current_user.department_id:
            return rfq.serve_layout()
    elif "/jobs" in pn:
        if "STR" in current_user.department_id:
            return jobs.serve_layout()
    elif "/bdd" in pn:
        if "STR" in current_user.department_id:
            return bdd.serve_layout()
    elif "/multipricer" in pn:
        auth_id = ["STR", "TDS", "TDO"]
        if any(x in current_user.department_id for x in auth_id):
            return multipricer.serve_layout()
    return not_found.layout


@server.route("/env")
def read_env():
    with open(".env", "r") as myfile:
        text = myfile.readlines()
    server.logger.info(text)
    return f"{text}"


@server.route("/delete-file")
@login_required
def delete_specified_file():
    """Use this routing to delete specific files on the server
    Ex: http://turfu/delete-file?filename=test.txt

    """
    filename = request.args.get("filename")
    if os.path.exists(filename):
        os.remove(filename)
        app.logger.info(f"File {filename} deleted")
        return f"File {filename} deleted"
    else:
        app.logger.info(f"File {filename} does not exist")
        return f"File {filename} does not exist"


@server.route("/all-files")
@login_required
def display_all_files():
    return ", <br>".join(
        [
            f"Folder {f} | "
            + " / ".join([x for x in os.listdir(os.path.join(PATH, f))])
            if not os.path.isfile(os.path.join(PATH, f))
            else f
            for f in os.listdir(PATH)
        ]
    )


@server.route("/lottie/<path:path>")
def serving_lottie_loader(path):
    directory = os.path.join(os.getcwd(), "assets/lottie")
    return send_from_directory(directory, path)


@app.callback(
    Output({"type": "icon-ts", "cfin": MATCH}, "style"),
    Output({"type": "popover-termsheets-body", "cfin": MATCH}, "children"),
    Input({"type": "url", "page": ALL}, "href"),
    State({"type": "popover-termsheets", "cfin": MATCH}, "id"),
)
def tooltip_and_link_termsheet(href, id):
    cfin = str(id["cfin"]).replace("-checked", "")

    termsheets = get_termsheets(cfin)

    content = []

    for type in termsheets:
        if termsheets.get(type):
            content.append(
                html.A(
                    dbc.Row(
                        [
                            dbc.Col(
                                [
                                    html.Div(
                                        [
                                            html.A(
                                                html.I(
                                                    className="far fa-file-pdf",
                                                    style={"fontSize": "1.15em"},
                                                ),
                                                style={"color": "black"},
                                            ),
                                        ],
                                        className="h-auto",
                                    ),
                                ],
                                width=2,
                            ),
                            dbc.Col(
                                html.P(  # Name of the Termsheet
                                    type, className="text-popover-termsheets",
                                ),
                                width="auto",
                                className="h-auto pr-0",
                                align="start",
                            ),
                        ],
                    ),
                    href=termsheets.get(type),
                    target="_blank",
                )
            )

    if content:
        style = {"color": "#e74c3c"}
        tooltip = dbc.Container(content)
    else:
        style = {"color": "black"}
        tooltip = html.P("No Termsheets", style={"fontSize": "13px"})

    return style, tooltip


@app.callback(
    Output("turfu-list-suggested", "children"),
    Input({"type": "url", "page": ALL}, "id"),
)
def set_list_options_for_input(id):
    if not id:
        return []

    name_app = id[0].get("page")

    if name_app == "home":
        df = cached_all_products()
        df["Options"] = df.apply(lambda x: f"Cfin: {x.Cfin} - ISIN: {x.ISIN}", axis=1)
        return [html.Option(value=x[0], label=x[1]) for x in zip(df.Options, df.Name)]

    elif name_app == "clients":
        data = OpenPositions().all_accounts_and_contacts()
        return [
            html.Option(
                value=x["institution"],
                label=f"Contact: {x['contact']} | Sales: {x['vendeurRepreneur']}",
            )
            for x in data
            if "ARNEODO" in x["vendeurRepreneur"]  # to comment
        ]

    return []


app.clientside_callback(
    """
    function(name_path) {
        var nameTab = name_path.charAt(1).toUpperCase() + name_path.slice(2)
        if (name_path === '/') {
            document.title = 'Turfu | Home'
        } else {
            document.title = 'Turfu | ' + nameTab
        }
    }
    """,
    Output("empty-div-for-title", "children"),
    Input("url", "pathname"),
)


if __name__ == "__main__":
    app.run_server(port=5000)

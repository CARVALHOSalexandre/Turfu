import re
import uuid

import pandas as pd
from sqlalchemy import Table, func
from sqlalchemy.sql import select
from flask_sqlalchemy import SQLAlchemy
from flask import jsonify
from config import engine
from typing import Callable
import datetime as dt


class MySQLAlchemy(SQLAlchemy):
    Column: Callable
    String: Callable
    Text: Callable
    DateTime: Callable
    Boolean: Callable
    Numeric: Callable
    NullType: Callable
    Integer: Callable
    Float: Callable
    ForeignKey: Callable
    ForeignKeyConstraint: Callable
    relationship: Callable
    FetchedValue: Callable
    CheckConstraint: Callable
    Table: Callable
    Index: Callable
    Enum: Callable


db = MySQLAlchemy()


class ExcelFunction(db.Model):
    __tablename__ = "excel_function"
    id = db.Column(db.Integer, primary_key=True)
    function = db.Column(db.String(3), unique=False, nullable=True)
    parameter = db.Column(db.String(50), unique=False, nullable=True)
    description = db.Column(db.String(100), unique=False, nullable=True)
    formula = db.Column(db.String(50), unique=False, nullable=True)
    output = db.Column(db.String(50), unique=False, nullable=True)
    datetime = db.Column(
        db.DateTime,
        nullable=False,
        default=dt.datetime.now(),
        onupdate=func.current_timestamp(),
    )
    user = db.Column(db.String, nullable=False,)

    def __repr__(self):
        return f"<Function {self.id}> - {self.function} - {self.parameter}"


ExcelFunction_tbl = Table("excel_function", ExcelFunction.metadata)


def create_excel_function_table():
    ExcelFunction.metadata.create_all(engine)


def delete_excel_function_table():
    ExcelFunction.__table__.drop(engine)


def add_excel_function(function, parameter, description, formula, output, user):
    ins = ExcelFunction_tbl.insert().values(
        function=function,
        parameter=parameter,
        description=description,
        formula=formula,
        output=output,
        user=user,
    )
    conn = engine.connect()
    conn.execute(ins)
    conn.close()


def delete_excel_function(id):
    ins = ExcelFunction_tbl.delete().where(ExcelFunction.id.in_([id]))
    conn = engine.connect()
    conn.execute(ins)
    conn.close()


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(15), unique=True)
    displayname = db.Column(db.String(50), unique=True)
    email = db.Column(db.String(50), unique=True)
    title = db.Column(db.String(50))
    department = db.Column(db.String(15))
    department_id = db.Column(db.String(15))

    # exane_id = db.Column(db.Integer)

    def cols(self):
        return []

    def __repr__(self):
        return f"<User {self.id}> - {self.username} - {self.department_id}"


class CandidatesIsin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    cfin = db.Column(db.Integer, nullable=True)
    isin = db.Column(db.String, nullable=True)
    long_name = db.Column(db.String, nullable=True, info="Long Name")
    short_name = db.Column(db.String, nullable=True, info="Short name")
    description = db.Column(db.String, nullable=True, info="Description")
    ticker = db.Column(db.String, nullable=True)
    code = db.Column(db.String, nullable=True)
    is_sent = db.Column(db.Boolean, nullable=False, default=False,)
    datetime = db.Column(
        db.DateTime,
        nullable=False,
        default=dt.datetime.now(),
        onupdate=func.current_timestamp(),
    )
    user = db.Column(db.String, nullable=False,)


class RfqTickets(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    id_ticket = db.Column(db.String, nullable=False)
    sales_id = db.Column(db.String, nullable=False)
    sales_name = db.Column(db.String, nullable=False)
    structurer = db.Column(db.String, nullable=False)
    client_id = db.Column(db.String, nullable=False)
    client_name = db.Column(db.String, nullable=False)
    description = db.Column(db.String, nullable=False)
    currency = db.Column(db.String, nullable=False)
    size = db.Column(db.Float, nullable=False)
    asset_class = db.Column(db.String, nullable=True)
    is_otc = db.Column(db.Boolean, nullable=True, default=False)
    is_note = db.Column(db.Boolean, nullable=True, default=False)
    is_live = db.Column(db.Boolean, default=False,)
    time_price_needed = db.Column(db.DateTime, nullable=True)
    distribution_zone = db.Column(db.String, nullable=True)
    comment = db.Column(db.String, nullable=True)
    settlement = db.Column(db.String, nullable=True, default="Physical")
    is_pricers_only = db.Column(db.Boolean, default=False,)
    is_kid_needed = db.Column(db.Boolean, default=False,)
    is_listed = db.Column(db.Boolean, default=False,)
    is_ts_indic_needed = db.Column(db.Boolean, default=False,)
    is_traded = db.Column(db.Boolean, default=False)
    last_edit = db.Column(db.DateTime, nullable=False, default=dt.datetime.now(),)


def get_details_from_ticket_id(id_ticket):
    r = (
        db.session.query(
            RfqTickets.id,
            RfqTickets.id_ticket,
            RfqTickets.sales_id,
            RfqTickets.sales_name,
            RfqTickets.structurer,
            RfqTickets.client_id,
            RfqTickets.client_name,
            RfqTickets.description,
            RfqTickets.currency,
            RfqTickets.size,
            RfqTickets.asset_class,
            RfqTickets.is_otc,
            RfqTickets.is_note,
            RfqTickets.is_live,
            RfqTickets.time_price_needed,
            RfqTickets.distribution_zone,
            RfqTickets.comment,
            RfqTickets.settlement,
            RfqTickets.is_pricers_only,
            RfqTickets.is_kid_needed,
            RfqTickets.is_ts_indic_needed,
            RfqTickets.is_traded,
            RfqTickets.last_edit,
        )
        .join()
        .filter(RfqTickets.id_ticket == id_ticket,)
        .order_by(RfqTickets.last_edit.desc())
    ).all()

    return pd.DataFrame(r)


def get_details_from_id(id):
    r = (
        db.session.query(
            RfqTickets.id,
            RfqTickets.id_ticket,
            RfqTickets.sales_id,
            RfqTickets.sales_name,
            RfqTickets.structurer,
            RfqTickets.client_id,
            RfqTickets.client_name,
            RfqTickets.description,
            RfqTickets.currency,
            RfqTickets.size,
            RfqTickets.asset_class,
            RfqTickets.is_otc,
            RfqTickets.is_note,
            RfqTickets.is_live,
            RfqTickets.time_price_needed,
            RfqTickets.distribution_zone,
            RfqTickets.comment,
            RfqTickets.settlement,
            RfqTickets.is_pricers_only,
            RfqTickets.is_kid_needed,
            RfqTickets.is_ts_indic_needed,
            RfqTickets.is_traded,
            RfqTickets.last_edit,
        )
        .filter(RfqTickets.id == id,)
        .order_by(RfqTickets.last_edit.desc())
    ).all()

    return pd.DataFrame(r)


def set_details_from_id(
    id,
    sales_id,
    sales_name,
    structurer,
    client_id,
    client_name,
    description,
    currency,
    size,
    asset_class,
    comment,
    is_note,
    is_otc,
    is_live,
    is_traded,
    id_ticket,
):
    if not isinstance(id, str):
        id = str(id)

    db.session.query(RfqTickets).filter(RfqTickets.id == id).update(
        {
            "sales_id": sales_id,
            "sales_name": sales_name,
            "structurer": structurer,
            "client_id": client_id,
            "client_name": client_name,
            "description": description,
            "currency": currency,
            "size": size,
            "asset_class": asset_class,
            "comment": comment,
            "is_note": is_note,
            "is_otc": is_otc,
            "is_live": is_live,
            "is_traded": is_traded,
            "id_ticket": id_ticket,
        }
    )
    db.session.commit()

    return True


class Issuers(db.Model):
    __tablename__ = "issuers"
    __table_args__ = {"extend_existing": True}
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    code_exane = db.Column(db.Integer, nullable=True)
    name = db.Column(db.String, nullable=False)
    short_name = db.Column(db.String, nullable=False)
    ric_extension_1 = db.Column(db.String, nullable=True)
    ric_extension_2 = db.Column(db.String, nullable=True)
    has_web_pricer = db.Column(db.Boolean, default=False)
    has_api_pricer = db.Column(db.Boolean, default=False)
    has_mail_pricer_note = db.Column(db.Boolean, default=False)
    has_mail_pricer_swap = db.Column(db.Boolean, default=False)


def all_issuers_codes_and_names():
    return db.session.query(Issuers.short_name, Issuers.code_exane,).all()


class PricingSources(db.Model):
    __tablename__ = "pricing_sources"
    __table_args__ = {"extend_existing": True}
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    short_name = db.Column(db.String, nullable=False)
    source1 = db.Column(db.String, nullable=False)
    source2 = db.Column(db.String, nullable=True)
    source3 = db.Column(db.String, nullable=True)
    source4 = db.Column(db.String, nullable=True)
    source5 = db.Column(db.String, nullable=True)
    source6 = db.Column(db.String, nullable=True)


class IssuerRename(db.Model):
    __tablename__ = "issuer_rename"
    __table_args__ = {"extend_existing": True}
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    weird_name = db.Column(db.String, nullable=False)
    name = db.Column(db.String, nullable=False)
    short_name = db.Column(db.String, nullable=False)


class ClientsTalkTo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    id_client = db.Column(db.Integer, nullable=False)
    id_issuer = db.Column(db.Integer, nullable=False)
    last_edit = db.Column(
        db.DateTime,
        nullable=False,
        default=dt.datetime.now(),
        onupdate=func.current_timestamp(),
    )


def get_talks_to_from_client(client_id):
    r = (
        db.session.query(ClientsTalkTo.id_issuer,).filter(
            ClientsTalkTo.id_client == client_id,
        )
    ).all()

    return pd.DataFrame(r)


def set_client_talks_to(id_issuers, id_client):

    if not isinstance(id_issuers, list):

        id_issuers = [id_issuers]

    df_talks_to = get_talks_to_from_client(id_client)

    if not df_talks_to.empty:
        prev_issuers = df_talks_to.id_issuer.to_list()
    else:
        prev_issuers = []

    # Suppress previous issuers not in new issuers
    for x in prev_issuers:
        if x not in id_issuers:
            addresses = db.session.query(ClientsTalkTo).filter(
                ClientsTalkTo.id_client == id_client, ClientsTalkTo.id_issuer == x,
            )
            addresses.delete(synchronize_session=False)

    # Add new issuers not in previous issuers
    for x in id_issuers:
        if x not in prev_issuers:

            client_issuers = ClientsTalkTo(
                id_client=id_client, id_issuer=x, last_edit=dt.datetime.now()
            )

            db.session.add(client_issuers)
            db.session.commit()


class RfqSentTo(db.Model):
    id = db.Column(db.Integer, primary_key=True, nullable=False)
    id_rfq = db.Column(db.Integer, nullable=False)
    id_issuer = db.Column(db.Integer, nullable=False)
    last_edit = db.Column(
        db.DateTime,
        nullable=False,
        default=dt.datetime.now(),
        onupdate=func.current_timestamp(),
    )


def get_issuers_sent_to_from_rfq(rfq_id):
    r = (
        db.session.query(RfqSentTo.id_rfq, RfqSentTo.id_issuer, Issuers.short_name)
        .join((Issuers, Issuers.code_exane == RfqSentTo.id_issuer))
        .filter(RfqSentTo.id_rfq == rfq_id,)
    ).all()

    return pd.DataFrame(r)


def set_rfq_sent_to(id_issuer, id):

    if not isinstance(id_issuer, list):

        id_issuer = [id_issuer]

    if not isinstance(id, str):
        id = str(id)

    for x in id_issuer:

        rfq_sent_issuers = RfqSentTo(
            id_rfq=id, id_issuer=x, last_edit=dt.datetime.now()
        )

        db.session.add(rfq_sent_issuers)
        db.session.commit()


class RfqTraded(db.Model):
    id = db.Column(db.Integer, primary_key=True, nullable=False)
    id_rfq = db.Column(db.Integer, nullable=False)
    id_ticket = db.Column(db.Integer, nullable=False)
    id_issuer = db.Column(db.Integer, nullable=False)
    last_edit = db.Column(
        db.DateTime,
        nullable=False,
        default=dt.datetime.now(),
        onupdate=func.current_timestamp(),
    )


def set_rfq_traded(id_issuer, id_rfq, id_ticket):

    if not isinstance(id_issuer, str):

        id_issuer = str(id_issuer)

    if not isinstance(id_rfq, str):
        id_rfq = str(id_rfq)

    rfq_traded = RfqTraded(
        id_rfq=id_rfq,
        id_ticket=id_ticket,
        id_issuer=id_issuer,
        last_edit=dt.datetime.now(),
    )

    db.session.add(rfq_traded)
    db.session.commit()


def delete_rfq_traded(rfq_id):

    if not isinstance(rfq_id, str):
        rfq_id = str(rfq_id)

    db.session.query(RfqTraded).filter(RfqTraded.id == rfq_id).delete()
    db.session.commit()

    return True


User_tbl = Table("user", User.metadata)


def rfq_history():

    # max ids by id_ticket
    sub = (
        db.session.query(
            func.max(RfqTickets.id).label("id_rfq"), RfqTickets.id_ticket,
        ).group_by(RfqTickets.id_ticket,)
    ).subquery()

    r = (
        db.session.query(
            RfqTickets.id.label("id_rfq"),
            RfqTickets.id_ticket,
            RfqTickets.sales_name,
            RfqTickets.structurer,
            RfqTickets.description,
            RfqTickets.asset_class,
            RfqTickets.currency,
            RfqTickets.size,
            RfqTickets.client_name,
            RfqTickets.comment,
            RfqTickets.is_traded,
        )
        .join(sub, sub.c.id_rfq == RfqTickets.id)
        .order_by(RfqTickets.last_edit.desc())
        .all()
    )

    return pd.DataFrame(r)


def add_rfq_ticket(
    sales_id,
    sales_name,
    structurer,
    client_id,
    client_name,
    description,
    currency,
    size,
    asset_class,
    comment,
    is_note,
    is_otc,
    is_live,
    is_traded,
    id_ticket=None,
    # time_price_needed,
    # distribution_zone,
    # settlement,
    # is_pricers_only,
    # is_kid_needed,
    # is_listed,
    # is_ts_indic_needed,
):
    if not id_ticket:
        id_ticket = str(uuid.uuid4())

    ticket = RfqTickets(
        id_ticket=id_ticket,
        sales_id=sales_id,
        sales_name=sales_name,
        structurer=structurer,
        client_id=client_id,
        client_name=client_name,
        description=description,
        currency=currency,
        size=float(size),
        asset_class=asset_class,
        comment=comment,
        is_live=is_live,
        is_otc=is_otc,
        is_note=is_note,
        is_traded=is_traded,
        last_edit=dt.datetime.now(),
    )

    db.session.add(ticket)
    db.session.commit()

    id = ticket.id

    return id, id_ticket


def delete_rfq_ticket(rfq_id):

    if not isinstance(rfq_id, str):
        rfq_id = str(rfq_id)

    db.session.query(RfqTickets).filter(RfqTickets.id == rfq_id).delete()
    db.session.commit()

    return True


def delete_sent_to_from_rfq_id(rfq_id):

    if not isinstance(rfq_id, str):
        rfq_id = str(rfq_id)

    db.session.query(RfqSentTo).filter(RfqSentTo.id_rfq == rfq_id).delete()
    db.session.commit()

    return True


def set_ticket_status_as_traded(rfq_id):

    if not isinstance(rfq_id, str):
        rfq_id = str(rfq_id)

    db.session.query(RfqTickets).filter(RfqTickets.id == rfq_id).update(
        {"is_traded": True, "last_edit": dt.datetime.now()}
    )
    db.session.commit()

    return True


def set_ticket_status_as_untraded(rfq_id):

    if not isinstance(rfq_id, str):
        rfq_id = str(rfq_id)

    db.session.query(RfqTickets).filter(RfqTickets.id == rfq_id).update(
        {"is_traded": False, "last_edit": dt.datetime.now()}
    )
    db.session.commit()

    return True


def create_user_table():
    User.metadata.create_all(engine)


def add_user(
    username, displayname, email, title, department, department_id, exane_id=None
):
    ins = User_tbl.insert().values(
        username=username,
        displayname=displayname,
        email=email,
        title=title,
        department=department,
        department_id=department_id,
        # exane_id=exane_id,
    )

    conn = engine.connect()
    conn.execute(ins)
    conn.close()


def add_ldap_user(ldap_result):
    username = ldap_result.user_id
    displayname = ldap_result.user_info.get("displayName", username)
    title = re.sub(r"\W+", " ", ldap_result.user_info.get("title", ""))
    email = ldap_result.user_info.get("mail", "")
    department = re.sub(r"\W+", " ", ldap_result.user_info.get("department", ""))
    department_id = ""
    # exane_id = ldap_result.user_info.get("employeeID", "")

    try:
        values = ldap_result.user_info.get("departmentNumber")
        department_id = ", ".join(values)
    except Exception as e:
        jsonify(error_message=f"Error Adding User: {repr(e)}", status=400)

    ins = User_tbl.insert().values(
        username=username,
        displayname=displayname,
        title=title,
        department=department,
        department_id=department_id,
        email=email,
        # exane_id=exane_id,
    )

    conn = engine.connect()
    conn.execute(ins)
    conn.close()

    return jsonify(message="Added Successfully", status=404)


def del_user(username):
    delete = User_tbl.delete().where(User_tbl.c.username == username)

    conn = engine.connect()
    conn.execute(delete)
    conn.close()


def show_users():
    select_st = select([User_tbl.c.username, User_tbl.c.email])

    conn = engine.connect()
    rs = conn.execute(select_st)

    for row in rs:
        print(row)

    conn.close()


def get_db_data():
    try:
        db_values = ExcelFunction.query.all()
    except:
        db.create_all()
        db_values = ExcelFunction.query.all()
    finally:
        return [
            {
                "id": x.id,
                "function": x.function,
                "parameter": x.parameter,
                "description": x.description,
                "formula": x.formula,
                "output": x.output,
                "datetime": x.datetime.strftime("%Y-%m-%d"),
                "user": x.user,
            }
            for x in db_values
        ]


if __name__ == "__main__":
    create_user_table()

    # add_user(
    #     username="theo_joignant2",
    #     displayname="Theo Joignant 2",
    #     email="theo.joignant2@exane.com",
    #     title="Product Development Group",
    #     department="derive",
    #     department_id="STRf",
    #     exane_id="STRfd",
    # )

    # create excel_function table
    # create_excel_function_table()

    # delete excel_function table
    # delete_excel_function_table()

    # Add excel function
    # add_excel_function(
    #     function="EDP",
    #     parameter="sector",
    #     description="Returns the Sector for a given Security",
    #     formula='=EDP("AAPL", "sector")',
    #     output="technology",
    #     user="theo",
    # )

    # Delete excel function
    # delete_excel_function(id=2)

    # Query All Excel Function
    from app import server

    with server.app_context():
        # engine.execute('alter table excel_function drop column keywords')
        # engine.execute('alter table excel_function add datetime String')
        db_date = get_db_data()
        print(db_date)

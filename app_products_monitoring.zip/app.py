# -*- coding: utf-8 -*-
import pathlib

from dash import Dash
import dash_bootstrap_components as dbc

from flask_apscheduler import APScheduler
from flask_caching import Cache
from flask_ldap3_login import LDAP3LoginManager
from flask_mail import Mail
from flask_restx import Api
from flask_login import (
    LoginManager,
    UserMixin,
)
from config import Config
from local_db_mgt import User as base, db
import flask_monitoringdashboard as dashboard


PATH = pathlib.Path(__file__).parent

# Link FontAwesome to get awesome icons
FA = "https://use.fontawesome.com/releases/v5.13.0/css/all.css"


app = Dash(
    __name__,
    external_stylesheets=[dbc.themes.MATERIA, FA],
    suppress_callback_exceptions=True,
    title="Structuring Toolbox",
    update_title=None,
)

server = app.server

# Load the configuration variables or our server
env = Config(server)
mail = Mail(server)
cache = Cache(server)

# Set the Flask Monitoring Dashboard
f_dashboard = PATH / "dashboard"
dashboard.config.init_from(file=f_dashboard / "config.cfg")
dashboard.config.database_name = "sqlite:///" + str(f_dashboard / "data.db")
dashboard.bind(server)

# Set the LDAP3 Login Manager for Exane's users DB
ldap_manager = LDAP3LoginManager(server)

# Set the a Flask-Login Manager
login_manager = LoginManager(server)
login_manager.login_view = "/login"

# Initiate SQLAlchemy
db.init_app(server)

# Initiate APScheduler
scheduler = APScheduler(app=server)
scheduler.start()

# Initiate the API
api = Api(
    server,
    version="1.0",
    title="db_structuring API",
    description="Data provider for db_structuring XLA",
)
ns = api.namespace("api", description="test")


# Create User class with UserMixin
class User(UserMixin, base):
    pass


# callback to reload the user object
@login_manager.user_loader
def load_user(user_id):
    users = []
    try:
        users = User.query.get(int(user_id))
    except Exception as e:
        db.create_all()
        users = User.query.get(int(user_id))
    finally:
        return users

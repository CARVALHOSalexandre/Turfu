import pandas as pd


def italian_most_traded(df, nb_trades=10):
    dff = (
        df[
            [
                "issuer",
                "cfin",
                "isin",
                "initial_date",
                "sales",
                "name",
                "currency",
                "maturity_date",
                "margin",
                "cash_traded",
                "size_traded",
            ]
        ]
        .groupby(
            [
                "cfin",
                "isin",
                "initial_date",
                "maturity_date",
                "issuer",
                "name",
                "sales",
                # "type_order",
                "currency",
            ],
            observed=True,
        )
        .agg(
            nb_trade=("margin", "count"),
            margin=("margin", "sum"),
            cash_traded=("cash_traded", "sum"),
            size_traded=("size_traded", "sum"),
        )
        .reset_index()
        .sort_values("size_traded", ascending=False)
    )
    dff["L"] = ""
    dff["TS"] = ""
    dff = dff[
        [
            "L",
            "TS",
            "cfin",
            "isin",
            "initial_date",
            "maturity_date",
            "issuer",
            "name",
            "sales",
            "nb_trade",
            "currency",
            "margin",
            "cash_traded",
            "size_traded",
        ]
    ]
    dff.columns = [
        "L",
        "TS",
        "Cfin",
        "ISIN",
        "Initial Date",
        "Maturity",
        "Issuer",
        "Name",
        "Sales",
        "Nb Trd",
        "Ccy",
        "Margin",
        "Cash Traded",
        "Size Traded",
    ]

    if nb_trades:
        dff = dff.head(nb_trades)

    return dff.to_dict("records")


def group_italian_trades(df):
    dff = (
        df[
            [
                "issuer",
                "cfin",
                "isin",
                "initial_date",
                "sales",
                "name",
                "type_order",
                "currency",
                "maturity_date",
                "margin",
                "cash_traded",
                "size_traded",
            ]
        ]
        .groupby(
            [
                "cfin",
                "isin",
                "initial_date",
                "maturity_date",
                "issuer",
                "name",
                "sales",
                "type_order",
                "currency",
            ],
            observed=True,
        )
        .agg(
            nb_trade=("margin", "count"),
            margin=("margin", "sum"),
            size_traded=("size_traded", "sum"),
            cash_traded=("cash_traded", "sum"),
        )
        .reset_index()
        .sort_values("cash_traded", ascending=False)
    )
    dff = dff[dff["margin"] > 0]
    dff["L"] = ""
    dff["TS"] = ""
    dff = dff[
        [
            "L",
            "TS",
            "cfin",
            "isin",
            "initial_date",
            "maturity_date",
            "issuer",
            "name",
            "sales",
            "type_order",
            "nb_trade",
            "currency",
            "margin",
            "cash_traded",
            "size_traded",
        ]
    ]
    dff.columns = [
        "L",
        "TS",
        "Cfin",
        "ISIN",
        "Initial Date",
        "Maturity",
        "Issuer",
        "Name",
        "Sales",
        "Type",
        "Nb Trd",
        "Ccy",
        "Margin",
        "Cash Traded",
        "Size Traded",
    ]

    return dff.to_dict("records")


def worst_buy_trades(df, nb_trades=None):
    dff = (
        df[df.type_order == "Buy"][
            [
                "issuer",
                "cfin",
                "isin",
                "initial_date",
                "sales",
                "name",
                "type_order",
                "currency",
                "maturity_date",
                "margin",
                "cash_traded",
                "size_traded",
            ]
        ]
        .groupby(
            [
                "cfin",
                "isin",
                "initial_date",
                "maturity_date",
                "issuer",
                "name",
                "sales",
                "type_order",
                "currency",
            ],
            observed=True,
        )
        .agg(
            nb_trade=("margin", "count"),
            margin=("margin", "sum"),
            size_traded=("size_traded", "sum"),
            cash_traded=("cash_traded", "sum"),
        )
        .reset_index()
        .sort_values("size_traded", ascending=False)
    )
    dff = dff[dff["margin"] > 0]
    dff["L"] = ""
    dff["TS"] = ""
    dff = dff[
        [
            "L",
            "TS",
            "cfin",
            "isin",
            "initial_date",
            "maturity_date",
            "issuer",
            "name",
            "sales",
            "type_order",
            "nb_trade",
            "currency",
            "margin",
            "cash_traded",
            "size_traded",
        ]
    ]
    dff.columns = [
        "L",
        "TS",
        "Cfin",
        "ISIN",
        "Initial Date",
        "Maturity",
        "Issuer",
        "Name",
        "Sales",
        "Type",
        "Nb Trd",
        "Ccy",
        "Margin",
        "Cash Traded",
        "Size Traded",
    ]

    if nb_trades:
        dff = dff.head(nb_trades)

    return dff.to_dict("records")

# -*- coding: utf-8 -*-
import os
import math
import smtplib
import datetime
import requests as rq
from email import encoders
from email.header import Header
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import plotly.graph_objs as go

import numpy as np
import pandas as pd
from plotly.subplots import make_subplots
from flask_apscheduler.api import get_scheduler_info
from jinja2 import Environment, FileSystemLoader

from app import app, db, server, PATH

from emails.mail_reader import SharedAccount

from models.storing import *
from models.base import Rkvendeurcircus

import utils.sql as sql
from utils import osiris, sql_amc
from utils.api_sg import SGPricer
from utils.api_open_positions import OpenPositions
from utils.api_crm import CrmPersonne
from utils.api_exane import ExaneInstruments
from utils.api_book_positions import Positions
from utils.basics import to_str_date, dt_today, prev_bday
from utils.dictionnaries import issuers_pnl_target_dict, issuers_size_traded_target_dict
from pandas.tseries.offsets import BDay
from datetime import timedelta


colors_graphs = {
    "Yellow": "rgba(255, 214, 153, 0.62)",
    "Green": "rgba(47, 154, 152, 0.62)",
    "Blue": "rgba(52, 152, 219, 0.62)",
    "Dark_Blue": "rgba(41, 128, 185, 1)",
    "Red": "rgba(231, 76, 60, 0.62)",
    "Dark_Red": "rgba(192, 57, 43, 1)",
}


def comments_mail_trades(df, category, df_ytd=None):

    result = {"details": []}

    if category == "key_figures":
        result["title"] = "📈 Key Figures"
        dff = df

    elif category == "italy":
        result["title"] = "🛵 Italian Market Overview"
        dff = df[df.sales.isin(["SEDEX Team", "EUROTLX Team"])]

    elif category == "primary":
        result["title"] = "🏅 Primary Market"
        dff = df[df.is_primary]

    elif category == "secondary":
        result["title"] = "♻ Secondary Market"
        dff = df[~df.is_primary]

    elif category == "best_trade":
        result["title"] = "🏆 Trade of the week "
        dff = df

    else:
        raise TypeError("Type can be Primary, Secondary or Italian only")

    try:
        if category != "primary":
            # Number of trades
            nb_buy_trades = dff[dff.type_order == "Buy"].shape[0]
            nb_sell_trades = dff[dff.type_order == "Sell"].shape[0]
            nb_trades = nb_buy_trades + nb_sell_trades
            text = f"{nb_trades} trades ({nb_buy_trades} Buy / {nb_sell_trades} Sell)"
        else:
            nb_products = len(dff.cfin.unique())
            text = f"{nb_products} new products"

        # Amounts and Margins
        margin = dff.margin.sum() / 1000.0
        margin_positive = dff[dff.margin > 0].margin.sum() / 1000.0
        margin_negative = dff[dff.margin < 0].margin.sum() / 1000.0
        dff.loc[:, "change"] = dff.change.apply(lambda x: 1.0 if x == 0 else x)
        size_traded = (dff.size_traded / dff.change).sum() / 1000000.0
        text += f" - Nominal: EUR {size_traded:,.0f} Mio - PnL: EUR {margin:,.0f}k"
        if margin_negative < -5:
            text += f" (+{margin_positive:,.0f}k, {margin_negative:,.0f}k)"
        result["details"].append(text)

        if category == "best_trade":
            # Trade of the week
            dfff = dff[dff.is_primary]
            cfin = dfff[dfff.margin == dfff.margin.max()].cfin.values[0]
            dfff = dfff[dfff.cfin == cfin]
            result["title"] += f" - {dfff.name.values[0]}"

            result["details"] = []
            text = f"Nominal: {dfff.currency.values[0]} {dfff.size_traded.sum() / 1000000:,.0f} Mio"
            text += f" - PnL: EUR {dfff.margin.sum() / 1000:,.0f}k"
            text += f" - Sales: {dfff.sales.values[0]}"
            result["details"].append(text)

        if category == "italy":

            # Average activity over the last 10 weeks
            dff_ytd = df_ytd[df_ytd.sales.isin(["SEDEX Team", "EUROTLX Team"])]
            dfff_ytd = dff_ytd.groupby(pd.Grouper(key="trade_date", freq="W")).agg(
                {"quantity": "count", "size_traded": "sum", "margin": "sum"}
            )
            dfff_ytd = dfff_ytd[dfff_ytd.index < dt_today("dt")].iloc[-10:, :]
            average_size = dfff_ytd.size_traded.mean() / 1000000
            average_quantity = dfff_ytd.quantity.mean()
            average_margin = dfff_ytd.margin.mean() / 1000
            msg = f"(average over the last 10 weeks: {average_quantity:,.0f} trades"
            msg += f" - Nominal: EUR {average_size:,.0f} Mio - PnL: EUR {average_margin:,.0f}k)"
            result["details"].append(msg)

            # Most popular products
            dfff = dff.groupby("name").agg({"size_traded": "sum", "quantity": "count"})
            dfff = dfff.sort_values(by=["quantity", "size_traded"], ascending=False)
            result["details"].append("Most popular")
            for i in range(0, 3):
                result["details"].append(
                    f" - {dfff.iat[i, 1]} trades on {dfff.index[i]}"
                )

        result["title"] = (
            result["title"].encode("ascii", "xmlcharrefreplace").decode("utf-8")
        )

    except Exception:
        msg = "Issue creating comments for Trades' email"
        app.logger.exception(msg)

    return result


class Mailer:
    MAIL_SERVER_PROD = "smtp.exane.com"
    MAIL_SERVER_INT = "smtp-exch-int"
    port = 25

    def __init__(self, env="prod", debug=False, **kwargs):

        self.debug = debug

        self.mail_server = self.MAIL_SERVER_PROD

        if env == "int":
            self.mail_server = self.MAIL_SERVER_INT

        self.name = "email"
        self.sender = "Structuring Report <exane.structuring@exane.com>"

        self.to = ["dev-turfu@exane.com"]
        self.cc = []

        if "to" in kwargs:
            self.to = kwargs["to"]

        if "cc" in kwargs:
            self.cc = kwargs["cc"]

        self.subject = "Turfu - Automatic Email"
        self.content = None

        self.data = {}
        self.folder = None

    def _set_server(self):
        try:
            s = smtplib.SMTP(self.mail_server, self.port)
            return s
        except Exception as e:
            return f"Error: {repr(e)}"

    @staticmethod
    def _encode(name):
        return name.encode("ascii", "xmlcharrefreplace").decode("utf-8")

    def _set_template(self, folder, **kwargs):
        path_template = "emails/template/" + folder
        if __name__ == "__main__":
            working_dir = os.getcwd()
            path_template = os.path.join(working_dir, "template", folder)
        try:
            environment = Environment(loader=FileSystemLoader(path_template),)
            template = environment.get_template("child.html")
            rendered = template.render(data=self.data, **kwargs)
            return self._encode(rendered)
        except Exception as e:
            msg = f"Issue creating template for {self._encode(self.subject)} | {e}"
            app.logger.exception(msg)

    def send_mail(self):

        msg = MIMEMultipart("alternative")

        msg.set_charset("utf-8")

        if self.debug:
            self.to = self.cc = ["dev-turfu@exane.com"]

        msg["Subject"] = Header(self.subject, "utf-8").encode()
        msg["From"] = self.sender
        msg["To"] = ", ".join(set(self.to))
        if self.cc:
            msg["Cc"] = ", ".join(set(self.cc))

        # attache a MIMEText object to save email template
        msg.attach(MIMEText(self.content, "html", "utf-8"))

        # to add an attachment is just add a MIMEBase object to read a picture locally.
        images_path = os.path.join(PATH, f"emails/images")
        images_path_temp = os.path.join(PATH, "emails", "images", "temp")
        if not os.path.exists(images_path_temp):
            os.makedirs(images_path_temp)
        images_list = [
            f
            for f in os.listdir(images_path)
            if os.path.isfile(os.path.join(images_path, f))
        ]
        images_list_temp = [
            f
            for f in os.listdir(images_path_temp)
            if os.path.isfile(os.path.join(images_path_temp, f))
        ]
        images_list = [x[:-4] for x in images_list]
        images_list_temp = [x[:-4] for x in images_list_temp]
        for name_pic in images_list:
            if name_pic in self.content:
                path_pic = f"emails/images/{name_pic}.jpg"
                if __name__ == "__main__":
                    path_pic = os.path.join(os.getcwd(), "images", f"{name_pic}.jpg")
                with open(path_pic, "rb") as f:
                    # set attachment mime and file name, the image type is png
                    mime = MIMEBase("image", "jpg", filename=f"{name_pic}.jpg")
                    # add required header data:
                    mime.add_header(
                        "Content-Disposition", "attachment", filename=f"{name_pic}.jpg"
                    )
                    mime.add_header("X-Attachment-Id", name_pic)
                    mime.add_header("Content-ID", f"<{name_pic}>")
                    # read attachment file content into the MIMEBase object
                    mime.set_payload(f.read())
                    # encode with base64
                    encoders.encode_base64(mime)
                    # add MIMEBase object to MIMEMultipart object
                    msg.attach(mime)
        for name_pic in images_list_temp:
            if name_pic in self.content:
                path_pic = f"emails/images/temp/{name_pic}.jpg"
                if __name__ == "__main__":
                    path_pic = os.path.join(
                        os.getcwd(), "images/temp", f"{name_pic}.jpg"
                    )
                with open(path_pic, "rb") as f:
                    # set attachment mime and file name, the image type is png
                    mime = MIMEBase("image", "jpg", filename=f"{name_pic}.jpg")
                    # add required header data:
                    mime.add_header(
                        "Content-Disposition", "attachment", filename=f"{name_pic}.jpg"
                    )
                    mime.add_header("X-Attachment-Id", name_pic)
                    mime.add_header("Content-ID", f"<{name_pic}>")
                    # read attachment file content into the MIMEBase object
                    mime.set_payload(f.read())
                    # encode with base64
                    encoders.encode_base64(mime)
                    # add MIMEBase object to MIMEMultipart object
                    msg.attach(mime)

        # Prepare list of receivers
        if self.cc:
            self.to.extend(set(self.cc))

        mail_server = self._set_server()
        try:
            mail_server.sendmail(self.sender, set(self.to), msg.as_string())
            msg = f"Mail sent | Subject: {self._encode(self.subject)} - To: {', '.join(self.to)}"
            app.logger.info(msg)
        except Exception as e:
            msg = f"Mail Error | Subject: {self._encode(self.subject)} - To: {', '.join(self.to)} - {e}"
            app.logger.exception(msg)
        finally:
            mail_server.quit()


class MailContrib(Mailer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.data = self._get_products()

        self.to = ["montage@exane.com"]
        self.cc = ["structuring@exane.com"]

        self.name = "🔔 Contribution Issues 🔔"
        self.subject = self.name + " - " + dt_today("string_date")

        if self.data:
            self.content = self._set_template("contribution")
            self.send_mail()

    @staticmethod
    def _get_products():
        from utils.sql import (
            contribution_issues,
            colors_highlights_for_cause,
            tip_for_cause,
        )

        df = contribution_issues()

        if df.empty:
            return

        df = df[df.days_late >= 0]

        df.name = df.name.apply(lambda x: f"{x[:35]} ..." if len(x) > 35 else x)

        causes = df.cause.unique().tolist()

        d = df.to_dict("records")

        result = {
            cause: {
                "products": [y for y in d if y["cause"] == cause],
                "colors": colors_highlights_for_cause(cause),
                "tip": tip_for_cause(cause),
            }
            for cause in causes
        }

        return result


class MailLastOpinions(Mailer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.data = sql.last_updated_opinions([1, 4])
        self.content = self._set_template("last_opinions")

        self.to = ["vente-structures@exane.com"]
        self.cc = ["structuring@exane.com", "sales.analysts@exane.com"]

        self.name = "🔬 BNPP - Positive and Negative Opinions 🔬"

        self.subject = self.name + " - " + dt_today("string_date")

        if self.data:
            self.send_mail()


class MailMiniFutures(Mailer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Execute SQL Query to Retrieve Minifuts Database
        df = sql.execute_sql_query("minifut_positions", "exane_risque")

        # Compute "% To Stop" Column
        df["% To Stop"] = df["UL Last Bid"] / df["Stop Loss"] - 1

        # Filter Primary (last 5 Business Days) vs Secondary (other)
        df["Trade Date"] = pd.to_datetime(
            df["Trade Date"], dayfirst=True, format="%d/%m/%Y"
        )
        df.loc[df["Trade Date"] >= dt.today().date() - BDay(5), "Market"] = "Primary"
        df.Market = df.Market.fillna("Secondary")

        # Sort By Bull Then Bear (used in group_by function)
        df.sort_values(by="Type", ascending=False, inplace=True, na_position="first")

        # Replace column of product's close with live values
        cfins = [
            int(x)
            for x in df["Cfin Contrib"].dropna().tolist() + df["Cfin"].dropna().tolist()
        ]
        bids = sql.live_contrib_for_cfins(cfins)
        df["Last Bid"] = df.apply(
            lambda x: bids.get(x["Cfin"]).get("bid")
            if bids.get(x["Cfin"])
            else bids.get(x["Cfin Contrib"]).get("bid")
            if bids.get(x["Cfin Contrib"])
            else x["Last Bid"],
            axis=1,
        )

        # Group By Cfin To Concatenate Long / Short Positions
        df = df.groupby("Cfin", sort=False).aggregate(
            Isin=(
                "Isin",
                lambda x: (x if len(x) == 1 else list(x)[0])
                if list(x)[0] != None
                else "TBD ({})".format(df[df["Isin"].isnull()]["Cfin"].iloc[0]),
            ),
            Trade_Date=("Trade Date", "first"),
            Market=("Market", "first"),
            Ccy=("Ccy", "first"),
            Ticker=(
                "Ticker",
                lambda x: x if len(x) == 1 else "/".join(y for y in list(x)),
            ),
            Ticker_bis=(
                "Ticker",
                lambda x: x + " - " if (len(x) == 1 and list(x)[0] != "Basket") else "",
            ),
            UL_Name=(
                "UL Name",
                lambda x: " / ".join(
                    [
                        y
                        if len(x) == 1
                        else (
                            (
                                "Long " + df[df["UL Name"] == y]["Ticker"].iloc[0]
                                if float(df[df["UL Name"] == y]["UL Delta"].iloc[0])
                                >= 0
                                else "Long " + df[df["UL Name"] == y]["Ticker"].iloc[1]
                            )
                            if y == list(x)[0]
                            else (
                                "Short " + df[df["UL Name"] == y]["Ticker"].iloc[0]
                                if float(df[df["UL Name"] == y]["UL Delta"].iloc[0]) < 0
                                else "Short " + df[df["UL Name"] == y]["Ticker"].iloc[1]
                            )
                        )
                        for y in list(x)
                    ]
                ),
            ),
            Leverage=("Leverage", lambda x: abs(x) if len(x) == 1 else -1),
            Leverage_Init=(
                "Leverage Initial",
                lambda x: (abs(x) if len(x) == 1 else -1)
                if math.isnan(list(x)[0]) != True
                else df[df["Leverage Initial"].isnull()]["Leverage"].iloc[0],
            ),
            Strike=("Strike", "first"),
            Stop_Loss=("Stop Loss", "first"),
            Last_Bid=(
                "Last Bid",
                lambda x: round(x, 1) if len(x) == 1 else round(list(x)[0], 2),
            ),
            UL_Last_Bid=(
                "UL Last Bid",
                lambda x: round(x, 1) if len(x) == 1 else round(list(x)[0], 2),
            ),
            Dist_Barr=(
                "% To Stop",
                lambda x: round(100 * x, 0) if len(x) == 1 else "N/A",
            ),
            Type=("Type", lambda x: x if len(x) == 1 else ""),
            Type_on=("Type", lambda x: x + " on " if len(x) == 1 else ""),
        )

        # Update Strike / Stop Loss / Dist_Barr / Sales Margin Columns Format
        df["Strike"] = df["Strike"].round(2)
        df["Stop_Loss"] = df["Stop_Loss"].round(2)
        df["Dist_Barr"] = df["Dist_Barr"].apply(
            lambda x: x if (x or x == None == "N/A") else str(int(x)) + "%"
        )

        # Update "Leverage" / "Name" / "UL Name" Columns
        df["Leverage"] = df["Leverage"].fillna(-1)
        df["Leverage_Rounded"] = df["Leverage"].apply(lambda x: int(round(x, 0)))
        df["Leverage_Rounded"] = df["Leverage_Rounded"].apply(
            lambda x: f"{x}x " if x >= 0 else ""
        )
        df["Name"] = (
            df["Leverage_Rounded"] + df["Type_on"] + df["Ticker_bis"] + df["UL_Name"]
        )
        df["Leverage"] = df["Leverage"].apply(
            lambda x: f"{round(x, 1)} " if x >= 0 else "N/A"
        )
        df["Leverage_Init"] = df["Leverage_Init"].apply(
            lambda x: (f"  ({round(x, 1)})" if x >= 0 else "")
            if x != "TBD"
            else "(TBD)"
        )
        df["Name"] = (
            df["Name"].astype(str).apply(lambda x: f"{x[:40]}..." if len(x) > 40 else x)
        )

        # Retrieve / Merge / Modify Trade Categories
        data = sql.category_for_cfins(df.index)
        data.set_index("Cfin", inplace=True)
        df = pd.merge(df, data, left_index=True, right_index=True)
        df["Category"] = df["Name"].apply(
            lambda x: "Commodities/Forex"
            if (
                "commodities" in df[df["Name"] == x]["Category"].iloc[0].lower()
                or "change" in df[df["Name"] == x]["Category"].iloc[0].lower()
                or "us dollar" in x.lower()
            )
            else "Long/Short"
            if "long" in x.lower() and "short" in x.lower()
            else "Basket"
            if "basket" in df[df["Name"] == x]["Category"].iloc[0].lower()
            or "basket" in x.lower()
            else "Indice"
            if "indice" in df[df["Name"] == x]["Category"].iloc[0].lower()
            else ("Single Name US" if "US" in x else "Single Name EU")
            if "action" in df[df["Name"] == x]["Category"].iloc[0].lower()
            else "Other"
        )

        # Sort By Type & Trade Date
        df = df.sort_values(["Type", "Trade_Date"], ascending=[False, False])
        df["Trade_Date"] = df["Trade_Date"].astype(str)

        # Set Mail Data
        self.data = df.T.to_dict()

        # Set Mail Recipients
        self.to = ["vente-structures@exane.com"]
        self.cc = ["structuring@exane.com", "maxence.chauffour@exane.com"]

        # Assemble The Mail Title
        nb_products = 0
        title = ""
        for trade in self.data:
            if self.data[trade]["Market"] == "Primary":
                ticker = self.data[trade]["Ticker"]
                if ticker is None:
                    ticker = "Unknown"
                type = str(self.data[trade]["Type"])
                nb_products += 1
                title = title + type + " on " + ticker + ", "

        # Send Mail Only If There Is New Trades
        if nb_products > 0:

            # Set Mail Title Attributes
            if nb_products == 1:
                product = "Product"
            else:
                product = "Products"

            last_friday = dt_today()
            # last_friday = pd.to_datetime(last_friday)
            last_monday = dt.today() - BDay(4)
            week_number = last_monday.isocalendar()[1]

            # Convert Dates in Strings
            last_monday = last_monday.strftime("%b %d")
            last_friday = last_friday.strftime("%b %d, %Y")

            # Set Mail Title
            self.subject = "✨ New Minifutures ✨  |  {} {} - {}  |  Week {} - {} to {}".format(
                nb_products, product, title[:-2], week_number, last_monday, last_friday,
            )
            self.content = self._set_template("last_minifuts")

            # Send Mail
            if self.data:
                self.send_mail()


class MailAutocall(Mailer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.data = self._get_data(proba=kwargs.get("proba"), bdays=kwargs.get("bdays"))

        if self.data:
            if self.data.get("nb_products") > 0:

                self.content = self._set_template("autocall")

                self.to = ["vente-structures@exane.com"]

                self.cc = [
                    "Sales.Analysts@exane.com",
                    "structuring@exane.com",
                    "convex.trading@exane.com",
                ]

                self.name = "High Autocall Probabilities"
                self.subject = self.name + " - " + dt_today("string_date")

                self.send_mail()

    @staticmethod
    def _get_data(proba=None, bdays=None):
        from utils.sql import autocall_proba, autocall_distances, sales_involved

        if not proba:
            proba = 0.75

        if not bdays:
            bdays = 10

        products = autocall_proba(proba, bdays)

        if products:

            cfins = products.keys()
            worsts = autocall_distances(cfins)

            result = {x: {**worsts[x], **products[x]} for x in products.keys()}

            d_sales = sales_involved(cfins)

            for sale in d_sales:
                d_sales[sale] = [
                    {"cfin": x, "details": result[x]} for x in d_sales[sale]
                ]

            return {
                "products": d_sales,
                "nb_products": len(list(cfins)),
                "all_sales": ", ".join(d_sales.keys()),
            }


class MailNotification(Mailer):
    def __init__(self, subject, content, **kwargs):

        super().__init__(**kwargs)

        self.subject = subject
        self.errors = self._set_errors(content)
        self.server_name = self._set_server_name()

        self.data = self._set_data()
        self.content = self._set_template("notification")

        self.title = f"⚠ {subject} ⚠ - " + dt_today("string_datetime")

        self.sender = "Turfu Notification <turfu-no-reply@exane.com>"

        self.send_mail()

    @staticmethod
    def _set_errors(content):
        if isinstance(content, Exception):
            return {content.__class__.__name__: str(content)}

        if isinstance(content, str):
            return {"Error": content}

        return content

    @staticmethod
    def _set_server_name():
        scheduler_info = get_scheduler_info().json
        return scheduler_info["current_host"].upper()

    def _set_data(self):
        return {
            "subject": self.subject,
            "errors": self.errors,
            "server": self.server_name,
        }


class MailReportCertif(Mailer):
    def __init__(self, cfin, **kwargs):
        super().__init__(**kwargs)
        self.cfin = cfin
        self.data = sql_amc.report_from_certif(cfin, format=True)

        self.content = self._set_template("certif_amc")

        today = dt.today().strftime("%b %d, %Y")
        isin_certif = self.data.get("amc").get("isin")
        ticker_amc = self.data.get("amc").get("ticker")
        self.title = (
            f"📈 Exane Report 📈 - Certif {isin_certif} - AMC {ticker_amc} - {today}"
        )

        self.sender = "Exane Report <exane-no-reply@exane.com>"

        self.send_mail()


class MailControlListedInventory(Mailer):
    TRIGGER = 200

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.data = self._get_data()

        if self.data:

            nb_products = len(self.data)
            today = dt.today().strftime("%b %d, %Y")

            msg = f"{nb_products} listed products below {self.TRIGGER} units of inventory - {today}"
            self.subject = "🚨 Listed Market 🚨  | " + msg

            self.to = ["Convex.Trading@exane.com", "montage@exane.com"]
            self.cc = ["dev-turfu@exane.com"]

            self.content = self._set_template("control_size_listed_market")
            self.send_mail()

    def _get_data(self):
        df = sql.execute_sql_query(
            "positions",
            "exane_risque",
            min_date=dt(2000, 1, 1).date(),
            max_date=dt_today(),
            filter_sales="",
            filter_alive="AND ifstatut NOT IN (7, 22)",
            filter_market="AND prmarche in (184, 218, 919)",
            filter_back_to_back="",
            filter_traded="",
        )
        cfins = df["Cfin"].unique().tolist()

        # Add the issued positions from internal service
        positions = Positions().positions_for_cfins(cfins)

        d_issued = {}
        for data in positions:
            issued_details = data.get("issueDetails")

            if issued_details:

                issued = issued_details.get("issuedPosition")
                if issued != 0:

                    cfin = data.get("cfin")

                    if cfin not in d_issued.keys():
                        d_issued[cfin] = 0

                    d_issued[cfin] += issued

        df_issued = pd.DataFrame.from_dict(d_issued, orient="index")
        df_issued = df_issued.reset_index()
        df_issued.columns = ["Cfin", "Units Issued"]

        dff = df.merge(df_issued, on="Cfin", how="left")
        dff = dff[dff["Units Issued"] - df["Total Units"] < self.TRIGGER]

        # Control if the product is not in Bid only already
        # Data refreshes every night
        cfins = list(dff.Cfin)

        def ask_disabled(cfin):
            url = f"http://contrib/contrib-referential/instrument/{cfin}"
            try:
                r = rq.get(url)
                r.raise_for_status()
                data = r.json()
                if data:
                    return data["eraseAsk"]
            except:
                return False

        cfins_not_bid_only = [x for x in cfins if not ask_disabled(x)]
        dff = dff[dff.Cfin.isin(cfins_not_bid_only)]

        dff["Units Issued"] = dff["Units Issued"].apply(lambda x: int(x))
        dff["Total Units"] = dff["Total Units"].apply(lambda x: int(x))

        dff["Name"] = dff["Name"].apply(
            lambda x: f"{x[:35]}..." if x and len(x) > 50 else x
        )

        return dff.to_dict(orient="records")


class MailTrades(Mailer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.data = self._get_data()
        self.content = self._set_template("trades")

        self.to = ["vente-structures@exane.com"]
        self.cc = [
            "Sales.Analysts@exane.com",
            "structuring@exane.com",
            "mathieu.bernard@exane.com",
        ]

        last_monday = dt.today().date() - timedelta(days=7 + dt.today().weekday())
        last_friday = last_monday + BDay(4)

        week_number = last_monday.isocalendar()[1]

        # Convert Dates in Strings
        last_monday = last_monday.strftime("%b %d")
        last_friday = last_friday.strftime("%b %d, %Y")

        self.name = "📝 Trades Report 💰"

        self.subject = (
            f"{self.name} - Week {week_number} - {last_monday} to {last_friday}"
        )

        self.send_mail()

    @staticmethod
    def _get_data():
        from models.storing import (
            cached_ytd_trades,
            primary_trades,
            secondary_sales,
            losing_trades,
        )

        last_monday = dt.today().date() - BDay(5 + dt.today().weekday())
        last_friday = last_monday + BDay(4) + timedelta(hours=23)

        df = cached_ytd_trades()

        # df = sql.trades(dt(2020, 11, 1), dt(2020, 12, 31))

        # df.groupby('sales').sum().sort_values(by='margin', ascending=False)['margin']

        # Exclude Luu from trades report
        df = df[df.sales != "Luu"]

        df.loc[:, "trade_date"] = pd.to_datetime(df.trade_date)
        dff = df[(df.trade_date >= last_monday) & (df.trade_date <= last_friday)]

        dff.loc[:, "issuer"] = dff.loc[:, "issuer"].apply(
            lambda x: x.replace(", OTC ", " - ")
        )

        nb_trades = 10

        result = {
            "trades": {
                "primary": primary_trades(dff),
                "secondary": secondary_sales(dff, nb_trades=nb_trades),
                "losing": losing_trades(dff, nb_trades=nb_trades),
            },
            "comments": {},
        }

        # Comment on italian market
        for x in ["best_trade", "primary", "secondary", "italy"]:
            result["comments"][x] = comments_mail_trades(dff, category=x, df_ytd=df)

        return result


class MailItalianListedMarket(Mailer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.last_monday = None
        self.last_friday = None

        self.data = self._get_data()

        if self.data:
            self.content = self._set_template("italian_listed_market")

            self.to = ["italian.derivatives@exane.com"]
            self.cc = [
                "Sales.Analysts@exane.com",
                "structuring@exane.com",
                "Convex.Trading@exane.com",
            ]

            week_number = self.last_monday.isocalendar()[1]

            # Convert Dates in Strings
            last_monday = self.last_monday.strftime("%b %d")
            last_friday = self.last_friday.strftime("%b %d, %Y")

            self.name = "📝 Italian Listed Market 💰"
            info_dates = f" - Week {week_number} - {last_monday} to {last_friday}"
            self.subject = self.name + info_dates
            self.send_mail()

    def _get_data(self):
        from models.storing import cached_ytd_trades

        last_friday = dt_today()
        last_friday = pd.to_datetime(last_friday)
        last_monday = dt.today() - BDay(4)

        # Check if today is indeed a Friday, if not select last Friday
        if last_friday.weekday() != 4:
            last_monday = dt_today() - timedelta(days=7 + dt.today().weekday())
            last_monday = pd.to_datetime(last_monday)
            last_friday = last_monday + BDay(4) + timedelta(hours=23)

        # last_monday = dt(2020, 12, 1)
        # last_friday = dt.today()

        self.last_monday = last_monday
        self.last_friday = last_friday

        df = cached_ytd_trades()

        df.loc[:, "trade_date"] = pd.to_datetime(df.trade_date)
        dff = df[(df.trade_date >= last_monday) & (df.trade_date <= last_friday)]

        # Filter on the Sales involved
        dff = dff[dff.sales.isin(["SEDEX Team", "EUROTLX Team"])]

        dff.loc[:, "issuer"] = dff.loc[:, "issuer"].apply(
            lambda x: x.replace(", OTC ", ", ")
        )

        from emails.formatting import group_italian_trades, italian_most_traded

        data = group_italian_trades(dff)

        result = {
            "trades": {
                "Top 10 - Most Traded by Size Traded": italian_most_traded(dff),
                "Top 10 - Buy Trades by Size Bought": data[:10],
                "Top 10 - Sell Trades by Size Sold": data[-10:][::-1],
            },
            "comments": {},
        }

        for x in ["key_figures"]:
            result["comments"][x] = comments_mail_trades(dff, category=x)

        return result


class MailRFQ(Mailer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.data = self._get_data()

        name = "📊 RFQ Report 📊  |  Sales vs Issuers & Indicative vs Live"
        self.subject = f"{name} - {dt_today('string_date')}"

        self.to = ["vente-structures@exane.com"]
        self.cc = ["Structuring@exane.com", "Mathieu.Bernard@exane.com"]

        # self.to = self.cc = ["dev-turfu@exane.com"]

        if self.data:
            self.content = self._set_template("rfq")
            self.send_mail()

    @staticmethod
    def _get_data():
        sa = SharedAccount()

        start_date = dt.today() - datetime.timedelta(days=8)
        end_date = dt.today() - datetime.timedelta(days=2)

        df_sales = sa.sales_requests(start_date, end_date)
        df_issuers = sa.external_requests(start_date, end_date, primary_only=True)
        df_sales["Sales RFQ"] = 1
        df_issuers["Issuers RFQ"] = 1
        df_issuers_requests = (
            df_issuers.groupby(["description"])
            .aggregate(count=("Issuers RFQ", "sum"))
            .reset_index()
        )

        df_trades = cached_trades_and_products()
        df_trades_week = df_trades[
            (df_trades["Issue Date"] >= pd.to_datetime(start_date))
            & (df_trades["Issue Date"] <= pd.to_datetime(end_date))
        ]
        df_trades_week = (
            df_trades_week.groupby(["Cfin"])
            .aggregate(Margin=("Trade Margin", "sum"))
            .reset_index()
        )

        wording = {}
        key_figures = {
            "nb_sales_requests": sum(df_sales["Sales RFQ"]),
            "nb_issuers_requests": sum(df_issuers["Issuers RFQ"]),
            "avg_nb_email": int(
                sum(df_sales["count"].astype(int)) / sum(df_sales["Sales RFQ"])
            ),
            "avg_issuer_requests": round(
                sum(df_issuers_requests["count"]) / len(df_issuers_requests.index)
            ),
            "nb_trades": len(df_trades_week.index),
            "pnl": f"{int(sum(df_trades_week['Margin'])):,}",
        }

        # BAR CHART - RFQ / Days
        rfq_per_days_df_sales = df_sales.resample("D", on="datetime")["Sales RFQ"].sum()
        rfq_per_days_df_issuers = df_issuers.resample("D", on="datetime")[
            "Issuers RFQ"
        ].sum()
        rfq_per_days_df_sales.reset_index()
        rfq_per_days_df_issuers.reset_index()
        rfq_per_days_df = pd.merge(
            rfq_per_days_df_sales,
            rfq_per_days_df_issuers,
            how="outer",
            on=["datetime"],
        ).reset_index()
        rfq_per_days_df["datetime"] = rfq_per_days_df["datetime"].apply(
            lambda x: x.strftime("%Y-%m-%d")
        )
        df_time = pd.DataFrame(
            index=[i for i in range(0, 5)],
            data=[
                pd.to_datetime(start_date + timedelta(days=i + 1)).strftime("%Y-%m-%d")
                for i in range(0, 5)
            ],
            columns=["datetime"],
        )
        rfq_per_days_df = pd.merge(
            df_time, rfq_per_days_df, how="left", on=["datetime"],
        )
        rfq_per_days_df = rfq_per_days_df.fillna(0)
        rfq_per_days_df["datetime"] = rfq_per_days_df["datetime"].apply(
            lambda x: pd.to_datetime(x)
        )
        trace1 = go.Bar(
            x=rfq_per_days_df["datetime"].dt.strftime("%b-%d").astype(str),
            y=list(rfq_per_days_df["Sales RFQ"]),
            name="Sales",
            marker={"color": colors_graphs.get("Green")},
        )
        trace2 = go.Bar(
            x=rfq_per_days_df["datetime"].dt.strftime("%b-%d").astype(str),
            y=list(rfq_per_days_df["Issuers RFQ"]),
            name="Issuers",
            marker={"color": colors_graphs.get("Yellow")},
        )
        rfq_per_days_fig = go.Figure(data=[trace1, trace2], layout=go.Layout(),)
        rfq_per_days_fig.update_layout(
            margin=dict(t=32),
            font_family="Arial",
            title_font_size=20,
            template="plotly_white",
            title=dict(text="Sales & Issuers' Daily Requests", x=0.5,),
            legend=dict(y=-0.08, x=0.35, orientation="h",),
        )
        # PIE CHART - RFQ / Types
        nb_live_sales_request = len(df_sales[df_sales["Type"] == "Trading"].index)
        nb_indic_sales_request = len(df_sales[df_sales["Type"] != "Trading"].index)
        nb_live_issuers_request = len(df_issuers[df_issuers["type"] == "Trading"].index)
        nb_indic_issuers_request = len(
            df_issuers[df_issuers["type"] != "Trading"].index
        )
        rfq_per_type_fig = make_subplots(
            rows=1,
            cols=2,
            specs=[[{"type": "domain"}, {"type": "domain"}]],
            subplot_titles=["Sales", "Issuers"],
        )
        rfq_per_type_fig.add_trace(
            go.Pie(
                labels=["Live", "Indicative"],
                values=[nb_live_sales_request, nb_indic_sales_request],
                marker=dict(
                    colors=[colors_graphs.get("Red"), colors_graphs.get("Blue"),]
                ),
            ),
            row=1,
            col=1,
        )
        rfq_per_type_fig.add_trace(
            go.Pie(
                labels=["Live", "Indicative"],
                values=[nb_live_issuers_request, nb_indic_issuers_request],
            ),
            row=1,
            col=2,
        )
        rfq_per_type_fig.update_traces(hole=0.65)
        rfq_per_type_fig.update_layout(
            margin=dict(t=0, b=0),
            font_family="Arial",
            title_font_size=20,
            title=dict(text="Indicative & Live Breakdown", x=0.5, y=0.83),
            legend=dict(y=0.19, x=0.35, orientation="h",),
            annotations=[
                dict(
                    text="Sales", x=0.22, y=0.48, showarrow=False, font_family="Arial",
                ),
                dict(
                    text="Issuers",
                    x=0.78,
                    y=0.48,
                    showarrow=False,
                    font_family="Arial",
                ),
            ],
        )

        # BAR CHART - RFQ / Issuers & Sales
        rfq_per_sales_df = (
            df_sales.groupby(["author", "Type"])
            .aggregate(count=("Sales RFQ", "sum"))
            .reset_index()
        )
        rfq_per_issuers_df = (
            df_issuers.groupby(["issuer_short_name", "type"])
            .aggregate(count=("Issuers RFQ", "sum"))
            .reset_index()
        )
        rfq_per_sales_issuers_fig = make_subplots(
            rows=2, cols=1, specs=[[{"type": "bar"}], [{"type": "bar"}]],
        )
        rfq_per_sales_issuers_fig.add_trace(
            go.Bar(
                x=list(
                    rfq_per_sales_df[rfq_per_sales_df["Type"] == "Indicative"]["author"]
                ),
                y=list(
                    rfq_per_sales_df[rfq_per_sales_df["Type"] == "Indicative"]["count"]
                ),
                orientation="v",
                name="Indicative",
                marker={"color": colors_graphs.get("Blue")},
            ),
            row=2,
            col=1,
        )
        rfq_per_sales_issuers_fig.add_trace(
            go.Bar(
                x=list(
                    rfq_per_sales_df[rfq_per_sales_df["Type"] == "Trading"]["author"]
                ),
                y=list(
                    rfq_per_sales_df[rfq_per_sales_df["Type"] == "Trading"]["count"]
                ),
                orientation="v",
                name="Live",
                marker={"color": colors_graphs.get("Red")},
            ),
            row=2,
            col=1,
        )
        rfq_per_sales_issuers_fig.add_trace(
            go.Bar(
                x=list(
                    rfq_per_issuers_df[rfq_per_issuers_df["type"] == "Indicative"][
                        "issuer_short_name"
                    ]
                ),
                y=list(
                    rfq_per_issuers_df[rfq_per_issuers_df["type"] == "Indicative"][
                        "count"
                    ]
                ),
                orientation="v",
                name="Indicative",
                showlegend=False,
                marker={"color": colors_graphs.get("Blue")},
            ),
            row=1,
            col=1,
        )
        rfq_per_sales_issuers_fig.add_trace(
            go.Bar(
                x=list(
                    rfq_per_issuers_df[rfq_per_issuers_df["type"] == "Trading"][
                        "issuer_short_name"
                    ]
                ),
                y=list(
                    rfq_per_issuers_df[rfq_per_issuers_df["type"] == "Trading"]["count"]
                ),
                orientation="v",
                name="Live",
                showlegend=False,
                marker={"color": colors_graphs.get("Red")},
            ),
            row=1,
            col=1,
        )
        rfq_per_sales_issuers_fig.update_layout(
            margin=dict(t=32),
            font_family="Arial",
            title_font_size=20,
            title=dict(text="Sales & Issuers' Breakdown", x=0.5,),
            template="plotly_white",
            legend=dict(y=-0.26, x=0.35, orientation="h",),
        )

        # BAR CHART - Hit Ratio / Issuers
        start_date = dt(year=2021, month=1, day=1)
        end_date = dt.today() - datetime.timedelta(days=1)

        df_issuers = sa.external_requests(start_date, end_date, primary_only=True)
        df_issuers["Issuers RFQ"] = 1

        df_trades = df_trades.replace("BNP Paribas", "BNP")
        df_trades = df_trades.replace("Credit Suisse", "CS")
        df_trades = df_trades.replace("Goldman Sachs", "GS")
        df_trades = df_trades.replace("JP Morgan", "JPM")
        df_trades = df_trades.replace("Morgan Stanley", "MS")
        df_trades = df_trades.replace("Societe Generale", "SG")
        df_trades = df_trades.replace("Leonteq", "LTQ")

        issuers = [
            "BBVA",
            "BNP",
            "Barclays",
            "CIBC",
            "CIC",
            "CS",
            "GS",
            "JPM",
            "LTQ",
            "MS",
            "Marex",
            "Nomura",
            "SG",
        ]
        df_trades = df_trades[
            (df_trades["Issuer"].isin(issuers))
            | (df_trades["Issuer OTC"].isin(issuers))
        ]
        df_trades.loc[df_trades["Issuer"] == "Exane", "Issuer"] = df_trades[
            "Issuer OTC"
        ]
        df_trades = df_trades[df_trades["Trade Date"] >= pd.to_datetime(dt(2020, 1, 1))]
        # Convert Size Traded To Euro
        df_trades["Size Traded"] = df_trades.apply(
            lambda x: float(abs(x["Size Traded"]))
            * float(
                sql.xccy_benchmark_vs_cfins(
                    [int(x["Cfin"])], 47179611, min(x["Trade Date"], prev_bday(1)),
                )[0].get("value")
                if x["Ccy"] != "EUR"
                else 1
            ),
            axis=1,
        )
        df_2020_traded = df_trades[
            (df_trades["Trade Date"] >= pd.to_datetime(dt(year=2020, month=1, day=1),))
            & (
                df_trades["Trade Date"]
                <= pd.to_datetime(dt(year=2021, month=1, day=1),)
            )
        ]
        df_ytd_issued = df_trades[
            (df_trades["Issue Date"] >= pd.to_datetime(start_date))
            & (df_trades["Issue Date"] <= pd.to_datetime(end_date))
        ]
        df_ytd_traded = df_trades[
            (df_trades["Trade Date"] >= pd.to_datetime(start_date))
            & (df_trades["Trade Date"] <= pd.to_datetime(end_date))
        ]
        df_ytd_issued = (
            df_ytd_issued.groupby(["Cfin", "Issuer"])
            .aggregate(
                margin=("Trade Margin", "sum"), size_traded=("Size Traded", "sum")
            )
            .reset_index()
        )
        df_ytd_issued["Count"] = 1
        df_ytd_traded["Count"] = 1
        df_2020_traded["Count"] = 1
        df_ytd_issued = (
            df_ytd_issued.groupby(["Issuer"])
            .aggregate(count_issue=("Count", "sum"), size_traded=("size_traded", "sum"))
            .reset_index()
        )
        df_ytd_traded = (
            df_ytd_traded.groupby(["Issuer"])
            .aggregate(
                count_trade=("Count", "sum"),
                margin=("Trade Margin", "sum"),
                size_traded=("Size Traded", "sum"),
            )
            .reset_index()
        )
        df_2020_traded = (
            df_2020_traded.groupby(["Issuer"])
            .aggregate(
                count_trade_2020=("Count", "sum"),
                margin_2020=("Trade Margin", "sum"),
                size_traded_2020=("Size Traded", "sum"),
            )
            .reset_index()
        )
        rfq_per_issuers_df = (
            df_issuers.groupby(["issuer_short_name", "type"])
            .aggregate(count_rfq=("Issuers RFQ", "sum"))
            .reset_index()
        )
        df_hit_ratio = pd.DataFrame(issuers, columns=["Issuer"])
        rfq_indic_per_issuers_df = rfq_per_issuers_df[
            rfq_per_issuers_df["type"] == "Indicative"
        ]
        rfq_indic_per_issuers_df["Indicative"] = rfq_indic_per_issuers_df["count_rfq"]
        rfq_indic_per_issuers_df = rfq_indic_per_issuers_df[
            ["issuer_short_name", "Indicative"]
        ]
        rfq_live_per_issuers_df = rfq_per_issuers_df[
            rfq_per_issuers_df["type"] == "Trading"
        ]
        rfq_live_per_issuers_df["Trading"] = rfq_live_per_issuers_df["count_rfq"]
        rfq_live_per_issuers_df = rfq_live_per_issuers_df[
            ["issuer_short_name", "Trading"]
        ]
        df_hit_ratio = df_hit_ratio.merge(
            rfq_indic_per_issuers_df,
            left_on="Issuer",
            right_on="issuer_short_name",
            how="left",
        )
        df_hit_ratio = df_hit_ratio.drop(columns="issuer_short_name")
        df_hit_ratio = df_hit_ratio.merge(
            rfq_live_per_issuers_df,
            left_on="Issuer",
            right_on="issuer_short_name",
            how="left",
        )
        df_hit_ratio = df_hit_ratio.drop(columns="issuer_short_name")
        df_hit_ratio = df_hit_ratio.merge(df_ytd_issued, on="Issuer", how="left",)
        df_hit_ratio = df_hit_ratio.drop(columns="size_traded")
        df_hit_ratio = df_hit_ratio.merge(df_ytd_traded, on="Issuer", how="left",)
        df_hit_ratio = df_hit_ratio.fillna(0)
        df_hit_ratio["Live Hit Ratio"] = (
            df_hit_ratio["count_issue"] / (df_hit_ratio["Trading"]) * 100
        )
        df_hit_ratio["Total Hit Ratio"] = (
            df_hit_ratio["count_issue"]
            / (df_hit_ratio["Indicative"] + df_hit_ratio["Trading"])
            * 100
        )
        df_hit_ratio = df_hit_ratio.sort_values(by="Live Hit Ratio", ascending=True)

        hit_ratio_fig = make_subplots(
            rows=2, cols=1, specs=[[{"secondary_y": True}], [{"secondary_y": True}]],
        )
        hit_ratio_fig.add_trace(
            go.Bar(
                x=df_hit_ratio["Issuer"],
                y=df_hit_ratio["Indicative"],
                orientation="v",
                name="Indicative",
                marker={"color": colors_graphs.get("Blue")},
            ),
            secondary_y=False,
            row=1,
            col=1,
        )
        hit_ratio_fig.add_trace(
            go.Bar(
                x=df_hit_ratio["Issuer"],
                y=df_hit_ratio["Trading"],
                orientation="v",
                name="Live",
                marker={"color": colors_graphs.get("Red")},
            ),
            secondary_y=False,
            row=1,
            col=1,
        )
        hit_ratio_fig.add_trace(
            go.Scatter(
                x=df_hit_ratio["Issuer"],
                y=df_hit_ratio["Total Hit Ratio"],
                name="Total Requests Hit Ratio",
                marker={"color": colors_graphs.get("Dark_Blue")},
                showlegend=False,
            ),
            secondary_y=True,
            row=1,
            col=1,
        )
        hit_ratio_fig.add_trace(
            go.Scatter(
                x=df_hit_ratio["Issuer"],
                y=df_hit_ratio["Live Hit Ratio"],
                name="Live Requests Hit Ratio",
                marker={"color": colors_graphs.get("Dark_Red")},
                showlegend=False,
            ),
            secondary_y=True,
            row=1,
            col=1,
        )
        hit_ratio_fig.add_trace(
            go.Bar(
                x=df_hit_ratio["Issuer"],
                y=df_hit_ratio["size_traded"].abs(),
                name="Nominal Traded",
                marker={"color": colors_graphs.get("Yellow")},
            ),
            row=2,
            col=1,
        )
        hit_ratio_fig.add_trace(
            go.Scatter(
                x=df_hit_ratio["Issuer"],
                y=df_hit_ratio["Total Hit Ratio"],
                name="Total Requests Hit Ratio",
                marker={"color": colors_graphs.get("Dark_Blue")},
            ),
            secondary_y=True,
            row=2,
            col=1,
        )
        hit_ratio_fig.add_trace(
            go.Scatter(
                x=df_hit_ratio["Issuer"],
                y=df_hit_ratio["Live Hit Ratio"],
                name="Live Requests Hit Ratio",
                marker={"color": colors_graphs.get("Dark_Red")},
            ),
            secondary_y=True,
            row=2,
            col=1,
        )
        hit_ratio_fig.update_layout(
            margin=dict(t=80, r=10, l=10, b=15,),
            font_family="Arial",
            title_font_size=20,
            title=dict(text="Issuers' Hit Ratio Breakdown", x=0.5,),
            template="plotly_white",
            legend=dict(y=-0.15, x=0.08, orientation="h",),
            yaxis=dict(title_text="Nb Requests"),
            yaxis2=dict(title_text="Hit Ratio", overlaying="y", side="right"),
            yaxis3=dict(title_text="Nominal Traded"),
            yaxis4=dict(title_text="Hit Ratio", overlaying="y3", side="right"),
        )
        hit_ratio_fig.update_yaxes(secondary_y=True, ticksuffix="%", rangemode="tozero")

        df_poor_hit_ratio = df_hit_ratio[
            (df_hit_ratio["Live Hit Ratio"] < 40) & (df_hit_ratio["Trading"] > 5)
        ]

        df_poor_hit_ratio["size_traded"] = (
            df_poor_hit_ratio["size_traded"]
            .abs()
            .apply(
                lambda x: f"{round(x / 1000000, 1)}Mio"
                if x > 999999
                else (f"{int(x / 1000)}K" if x > 999 else str(int(x)))
            )
        )

        if not df_poor_hit_ratio.empty:
            df_poor_hit_ratio = df_poor_hit_ratio.reset_index(drop=True)
            html = "Poor Live Hit Ratios:</br>"
            for i in df_poor_hit_ratio.index:
                html = (
                    html
                    + " - "
                    + str(df_poor_hit_ratio["Issuer"].iloc[i])
                    + " | "
                    + "<span style='font-weight: bold;'>"
                    + str(int(df_poor_hit_ratio["Live Hit Ratio"].iloc[i]))
                    + "%"
                    + "</span>"
                    + " traded over the "
                    + str(df_poor_hit_ratio["Trading"].iloc[i])
                    + " live requests (total requests: "
                    + str(
                        df_poor_hit_ratio["Trading"].iloc[i]
                        + df_poor_hit_ratio["Indicative"].iloc[i]
                    )
                    + ", nominal: EUR "
                    + str(df_poor_hit_ratio["size_traded"].iloc[i])
                    + ")"
                    + "</br>"
                )
            wording["hit_ratio"] = html
        else:
            wording["hit_ratio"] = ""

        # BAR CHART - P&L / Issuers
        df_target = df_ytd_traded.merge(df_2020_traded, on="Issuer", how="left")
        df_target = df_target[df_target["Issuer"] != "Exane Finance gage"]
        df_target["Target P&L"] = (
            df_target["Issuer"].map(issuers_pnl_target_dict).fillna(0)
        )
        df_target["Target Size Traded"] = (
            df_target["Issuer"].map(issuers_size_traded_target_dict).fillna(0)
        )
        df_target = df_target.sort_values(by="margin", ascending=True)
        target_fig = make_subplots(
            rows=2, cols=1, specs=[[{"secondary_y": False}], [{"secondary_y": False}]],
        )
        target_fig.add_trace(
            go.Bar(
                x=df_target["Issuer"],
                y=df_target["margin_2020"],
                orientation="v",
                name="2020",
                marker={"color": colors_graphs.get("Green")},
            ),
            row=1,
            col=1,
        )
        target_fig.add_trace(
            go.Bar(
                x=df_target["Issuer"],
                y=df_target["margin"],
                orientation="v",
                name="2021",
                marker={"color": colors_graphs.get("Yellow")},
            ),
            row=1,
            col=1,
        )
        target_fig.add_trace(
            go.Scatter(
                x=df_target["Issuer"],
                y=df_target["Target P&L"],
                name="Target",
                marker={"color": colors_graphs.get("Dark_Red")},
            ),
            row=1,
            col=1,
        )
        target_fig.add_trace(
            go.Bar(
                x=df_target["Issuer"],
                y=df_target["size_traded_2020"].abs(),
                orientation="v",
                name="Size Traded 2020",
                marker={"color": colors_graphs.get("Green")},
                showlegend=False,
            ),
            row=2,
            col=1,
            secondary_y=False,
        )
        target_fig.add_trace(
            go.Bar(
                x=df_target["Issuer"],
                y=df_target["size_traded"].abs(),
                orientation="v",
                name="Size Traded 2021",
                marker={"color": colors_graphs.get("Yellow")},
                showlegend=False,
            ),
            row=2,
            col=1,
        )
        target_fig.update_layout(
            margin=dict(t=80, r=10, l=10, b=15,),
            font_family="Arial",
            title_font_size=20,
            title=dict(text="Issuers' Target Breakdown", x=0.5,),
            template="plotly_white",
            legend=dict(y=-0.06, x=0.28, orientation="h",),
            yaxis=dict(title_text="P&L"),
            yaxis2=dict(title_text="Nominal Traded"),
            yaxis3=dict(title_text="P&L Target", overlaying="y2", side="right"),
        )

        df_target["pnl_per_target"] = df_target["margin"] / df_target["Target P&L"]
        yearly_per = int(format(dt.today(), "%j")) / 365
        df_poor_target = df_target[df_target["pnl_per_target"] < yearly_per]
        if not df_poor_target.empty:
            df_poor_target = df_poor_target.reset_index(drop=True)
            df_poor_target["margin_formatted"] = df_poor_target["margin"].apply(
                lambda x: f"{round(x / 1000000, 1)}Mio"
                if x > 999999
                else (f"{int(x / 1000)}K" if x > 999 else str(int(x)))
            )
            df_poor_target["target_formatted"] = df_poor_target["Target P&L"].apply(
                lambda x: f"{round(x / 1000000, 1)}Mio"
                if x > 999999
                else (f"{int(x / 1000)}K" if x > 999 else str(int(x)))
            )
            remaining_weeks = int((365 - int(format(dt.today(), "%j"))) / 7)
            html = f"Behind Annualised P&L Target ({remaining_weeks} weeks remaining):</br>"
            for i in df_poor_target.index:
                html = (
                    html
                    + " - "
                    + str(df_poor_target["Issuer"].iloc[i])
                    + " | P&L "
                    + "<span style='font-weight: bold;'>"
                    + str(df_poor_target["margin_formatted"].iloc[i])
                    + "</span>"
                    + ", Target "
                    + str(df_poor_target["target_formatted"].iloc[i])
                    + " ("
                    + str(round(df_poor_target["pnl_per_target"].iloc[i] * 100, 2))
                    + "%)"
                    + "</br>"
                )
        else:
            html = ""
        wording["target"] = html

        # Export Figures
        path = os.path.join(PATH, "emails", "images", "temp")
        if not os.path.exists(path):
            os.makedirs(path)
        rfq_per_days_path = path + "/rfq_per_days.jpg"
        rfq_per_type_path = path + "/rfq_per_type.jpg"
        rfq_per_sales_issuers_path = path + "/rfq_per_sales_issuers.jpg"
        hit_ratio_path = path + "/hit_ratio.jpg"
        target_path = path + "/target.jpg"
        try:
            os.remove(rfq_per_days_path)
            os.remove(rfq_per_type_path)
            os.remove(rfq_per_sales_issuers_path)
            os.remove(hit_ratio_path)
            os.remove(target_path)
        except:
            pass
        rfq_per_days_fig.write_image(rfq_per_days_path)
        rfq_per_type_fig.write_image(rfq_per_type_path)
        rfq_per_sales_issuers_fig.write_image(rfq_per_sales_issuers_path)
        hit_ratio_fig.write_image(hit_ratio_path)
        target_fig.write_image(target_path)

        # Return Dict With Figures
        charts = {
            "rfq_per_days": "cid:rfq_per_days",
            "rfq_per_type": "cid:rfq_per_type",
            "rfq_per_sales_issuers": "cid:rfq_per_sales_issuers",
            "hit_ratio": "cid:hit_ratio",
            "target": "cid:target",
        }
        return {"key_figures": key_figures, "charts": charts, "wording": wording}


class MailBNPInteractions(Mailer):
    def __init__(self, start_date=None, end_date=None, **kwargs):
        super().__init__(**kwargs)

        self.data = self._get_data(start_date, end_date)

        name = "📊 BNP Interactions 📊  | Price Requests & Trades"
        self.subject = f"{name} - {dt_today('string_date')}"

        self.to = [
            "lara.andari-yammine@exane.com",
            "julien.morizot@exane.com",
            "mathieu.bernard@exane.com",
        ]

        self.cc = ["dev-turfu@exane.com"]

        if self.data:
            self.content = self._set_template("bnp_interactions")
            self.send_mail()

    @staticmethod
    def _get_data(start_date=None, end_date=None):

        # Set the Start Date
        if not start_date:
            start_date = prev_bday()
        start_date = dt.combine(start_date, dt.min.time())

        # Set the End Date
        if not end_date:
            end_date = start_date + BDay(1)
        end_date = dt.combine(end_date, dt.min.time())

        # Connect to the Shares Mailbox
        sa = SharedAccount()

        # Set DataFrame of the Smart Derivatives' RFQ
        df_rfq_auto = sa.mail_sent_bnp_smart_der(start_date, end_date)

        smartder_request = 0
        if not df_rfq_auto.empty:
            smartder_request = len(df_rfq_auto.index)

        # Set DataFrame of the emails sent to and received from BNP
        df_rfq_mail = sa.external_requests(
            start_date, end_date, primary_only=False, issuer="BNP"
        )

        nb_sujects_issuers_requests = 0
        if not df_rfq_mail.empty:
            # Count the number of exchanges per subject
            df_issuers_requests = (
                df_rfq_mail.groupby(["description"])
                .agg(count=("description", "count"))
                .reset_index()
            )
            nb_sujects_issuers_requests = len(df_issuers_requests)

        # Count the trades done with BNP recently
        df = cached_ytd_trades()
        df.trade_date = pd.to_datetime(df.trade_date)
        df.payment_date = pd.to_datetime(df.payment_date)

        # Prepare DataFrame of older trades
        start_date_old = start_date - BDay(5)
        end_date_old = start_date - BDay(1)
        df_old = df[(df.trade_date >= start_date_old) & (df.trade_date <= end_date_old)]
        if not df_old.empty:
            # Filter to have Note and OTC trades with BNP
            df_old = df_old[
                df_old.issuer.str.contains("BNP")
                | df_old.issuer_hedge.str.contains("BNP")
            ]
            df_old = df_old.sort_values(by=["margin", "sales"], ascending=False)
            df_old.margin = df_old.margin.apply(lambda x: f"{x:,.0f}")
            df_old.trade_date = df_old.trade_date.dt.strftime("%Y-%m-%d")

        # Filter on selected date range
        df = df[(df.trade_date >= start_date) & (df.trade_date < end_date)]

        # Initialize data on the trades
        nb_trades_primary = 0
        nb_trades_secondary = 0
        nb_products_secondary = 0
        primary_pnl = 0
        secondary_pnl = 0
        total_pnl = 0

        if not df.empty:
            # Filter to have Note and OTC trades with BNP
            df = df[df.issuer.str.contains("BNP") | df.issuer_hedge.str.contains("BNP")]

            if not df.empty:
                # Add column to distinguish "primary" and "secondary' trades
                df["primary"] = df.payment_date >= df.trade_date

                nb_trades_primary = len(df[df.primary])
                nb_trades_secondary = len(df[~df.primary])
                nb_products_secondary = len(df[~df.primary].cfin.unique())
                primary_pnl = f"{df[df.primary].margin.sum():,.0f}"
                secondary_pnl = f"{df[~df.primary].margin.sum():,.0f}"
                total_pnl = f"{df.margin.sum():,.0f}"

                # Sort values by sales / margin
                df = df.sort_values(by=["margin", "sales"], ascending=False)

                # Convert Margin column to strings
                df.margin = df.margin.apply(lambda x: f"{x:,.0f}")

        key_figures = {
            "nb_issuers_requests": len(df_rfq_mail),
            "nb_sujects_issuers_requests": nb_sujects_issuers_requests,
            "nb_trades_primary": nb_trades_primary,
            "nb_trades_secondary": nb_trades_secondary,
            "nb_products_secondary": nb_products_secondary,
            "primary_pnl": primary_pnl,
            "secondary_pnl": secondary_pnl,
            "total_pnl": total_pnl,
            "smartder_request": smartder_request,
        }

        # Convert dates to string
        df.trade_date = df.trade_date.dt.strftime("%Y-%m-%d")

        return {
            "dates": {
                "start_date": start_date.strftime("%b %d, %Y"),
                "end_date": start_date.strftime("%b %d, %Y"),
                "start_date_old": start_date_old.strftime("%b %d, %Y"),
                "end_date_old": end_date_old.strftime("%b %d, %Y"),
            },
            "key_figures": key_figures,
            "trades_one_date": df.to_dict(orient="records"),
            "trades_previous_dates": df_old.to_dict(orient="records"),
        }


class MailAMCCashOrders(Mailer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.data = self._get_data(kwargs.get("nb_days", 1))

        if self.data:

            nb_certifs = self.data.get("nb_certifs")

            if nb_certifs:
                nb_amcs = self.data.get("nb_amcs")

                name = "💱 Flex Orders vs Cash 💱"
                name += f" | {nb_certifs} Certificates for {nb_amcs} AMCs"

                nb_buy_orders = self.data.get("nb_buy_orders")
                nb_sell_orders = self.data.get("nb_sell_orders")
                name += f" ({nb_buy_orders} Buy, {nb_sell_orders} Sell)"

                self.subject = f"{name} - {dt_today('string_date')}"

                self.to = ["exane.flex@exane.com"]
                self.cc = ["dev-turfu@exane.com", "alexandre.michelon@exane.com"]

                # if self.data.get("emails"):
                #     self.cc.extend(self.data.get("emails"))

                self.to = ["pierre.bichon@exane.com"]
                self.cc = ["alexandre.michelon@exane.com"]

                self.content = self._set_template("flex_orders_daily_recap")
                self.send_mail()

    @staticmethod
    def _get_data(nb_days=1):
        from emails.projects.FlexOrdersDailyRecap.main import get_data

        return get_data(nb_days=nb_days)


class MailMultiPricing(Mailer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        from multipricer.pricing_runs.pricing_runs import get_pricing_run_data

        self.data = get_pricing_run_data()

        name = "📝 Pricing Runs 📝"
        themes = "Themes: " + ", ".join([x.split(";")[-1][1:] for x in self.data])
        today = dt_today("string_date")
        self.subject = " - ".join([name, themes, today])

        self.to = ["vente-structures@exane.com"]
        self.cc = ["Sales.Analysts@exane.com", "structuring@exane.com"]

        if self.data:
            self.content = self._set_template("multipricing_runs", zip=zip, len=len,)
            self.send_mail()


class MailPricing(Mailer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.data = self._get_data()

        name = "📝 Pricing Runs 📝"
        themes = "Themes: " + ", ".join([x for x in self.data])
        today = dt_today("string_date")
        self.subject = " - ".join([name, themes, today])

        self.to = ["vente-structures@exane.com"]
        self.cc = ["Sales.Analysts@exane.com", "structuring@exane.com"]

        if self.data:
            self.content = self._set_template("pricing_runs")
            self.send_mail()

    def _get_data_etienne(self):
        sg = SGPricer()

        data = {}

        pricing_currencies = ["GBP"]

        # themes = {
        #     "Indices": {
        #         "tickers": ["KOSPI2", "RTY", "NDX", "EWA US", "DAX", "SPX", "NKY"],
        #         "params": {
        #             "reoffer": 97,
        #             "maturity_in_months": 36,
        #             "cpn_barrier": 75,
        #             "ki_barrier": 75,
        #             "option_type": "WorstOf",
        #         },
        #     },
        # }

        themes = {
            "Infra EU": {
                "tickers": [
                    "ATL IM",
                    "IBE SM",
                    "NG/ LN",
                    "FHZN SW",
                    "RWE GR",
                    "ENGI FP",
                    "EOAN GR",
                    "VPK NA",
                ],
                "params": {
                    "reoffer": 97,
                    "maturity_in_months": 36,
                    "cpn_barrier": 55,
                    "ki_barrier": 55,
                },
            },
            "Infra US": {
                "tickers": [
                    "ETRN US",
                    "TRGP US",
                    "OKE US",
                    "MIC US",
                    "LNG US",
                    "KMI US",
                    "WMB US",
                    "NEE US",
                    "PEG US",
                    "ES US",
                    "EXC US",
                    "SRE US",
                    "AWK US",
                    "SO US",
                    "D US",
                    "DUK US",
                    "AEP US",
                ],
                "params": {
                    "reoffer": 97,
                    "maturity_in_months": 36,
                    "cpn_barrier": 70,
                    "ki_barrier": 70,
                },
            },
            "Banks EU": {
                "tickers": [
                    "CBK GY",
                    "BAMI IM",
                    "SAN SQ",
                    "GLE FP",
                    "EBS AV",
                    "ABN NA",
                    "LLOY LN",
                    "NWG LN",
                    "BARC LN",
                    "BBVA SQ",
                    "UCG IM",
                    "CABK SQ",
                    "INGA NA",
                    "BKT SQ",
                    "ACA FP",
                    "BNP FP",
                ],
                "params": {
                    "reoffer": 97,
                    "maturity_in_months": 36,
                    "cpn_barrier": 50,
                    "ki_barrier": 50,
                },
            },
            "Apollo": {
                "tickers": [
                    "MT NA",
                    "BPE IM",
                    "FR FP",
                    "PSON LN",
                    "IFX GY",
                    "LLOY LN",
                    "WLN FP",
                    "LSE LN",
                    "VOW3 GY",
                    "AAL LN",
                    "ERICB SS",
                    "ATO FP",
                    "EN FP",
                    "EQNR NO",
                    "GRF SM",
                    "VIE FP",
                ],
                "params": {
                    "reoffer": 97,
                    "maturity_in_months": 36,
                    "cpn_barrier": 50,
                    "ki_barrier": 50,
                },
            },
            "Brexit Domestic": {
                "tickers": [
                    "LLOY LN",
                    "ITV LN",
                    "BARC LN",
                    "MKS LN",
                    "LAND LN",
                    "BLND LN",
                    "LGEN LN",
                    "SBRY LN",
                    "SLA LN",
                    "AV/ LN",
                    "MRW LN",
                ],
                "params": {
                    "reoffer": 97,
                    "maturity_in_months": 36,
                    "cpn_barrier": 50,
                    "ki_barrier": 50,
                },
            },
        }

        for theme in themes:
            payoffs = ["autocall"]

            tickers = themes.get(theme).get("tickers")
            params = themes.get(theme).get("params")

            try:
                results = sg.pricing_run_with_details(
                    tickers=tickers,
                    payoffs=payoffs,
                    currencies=pricing_currencies,
                    nb_ul=3,
                    **params,
                )

                if results:
                    data[theme] = {
                        "title": theme,
                        "prices": results[0],
                        **results[1],
                    }
            except Exception as e:
                print(repr(e))

        return data

    def _get_data_tarek(self):
        sg = SGPricer()

        data = {}

        pricing_currencies = ["EUR"]

        # themes = {
        #     "barrier30": {
        #         "tickers": [
        #             "ORA FP",
        #             "GSK LN",
        #             "VOD LN",
        #             "NG/ LN",
        #             "SSE LN",
        #             "ENGI FP",
        #             "EN FP",
        #             "BT/A LN",
        #             "VIE FP",
        #             "TATE LN",
        #             "SAN FP",
        #         ],
        #         "params": {
        #             "payoffs": ["reverse"],
        #             "reoffer": 98,
        #             "maturity_in_months": 12,
        #             "frequency": "12M",
        #             "ki_barrier": 70,
        #         },
        #     },
        #     "barrier40": {
        #         "tickers": [
        #             "ORA FP",
        #             "GSK LN",
        #             "VOD LN",
        #             "NG/ LN ",
        #             "SSE LN",
        #             "ENGI FP",
        #             "EN FP",
        #             "BT/A LN",
        #             "VIE FP",
        #             "TATE LN",
        #             "SAN FP",
        #         ],
        #         "params": {
        #             "payoffs": ["reverse"],
        #             "reoffer": 98,
        #             "frequency": "12M",
        #             "maturity_in_months": 12,
        #             "ki_barrier": 60,
        #         },
        #     },
        #     "barrier50": {
        #         "tickers": [
        #             "ORA FP",
        #             "GSK LN",
        #             "VOD LN",
        #             "NG/ LN ",
        #             "SSE LN",
        #             "ENGI FP",
        #             "EN FP",
        #             "BT/A LN",
        #             "VIE FP",
        #             "TATE LN",
        #             "SAN FP",
        #         ],
        #         "params": {
        #             "payoffs": ["reverse"],
        #             "reoffer": 98,
        #             "frequency": "12M",
        #             "maturity_in_months": 12,
        #             "ki_barrier": 50,
        #         },
        #     },
        # }

        themes = {
            "barrier30": {
                "tickers": [
                    "ORA FP",
                    "GSK LN",
                    "VOD LN",
                    "NG/ LN",
                    "SSE LN",
                    "ENGI FP",
                    "EN FP",
                    "BT/A LN",
                    "VIE FP",
                    "TATE LN",
                    "SAN FP",
                ],
                "params": {
                    "payoffs": ["autocall"],
                    "reoffer": 98,
                    "maturity_in_months": 18,
                    "frequency": "3M",
                    "ki_barrier": 70,
                    "atk_start_period": 2,
                },
            },
            "barrier40": {
                "tickers": [
                    "ORA FP",
                    "GSK LN",
                    "VOD LN",
                    "NG/ LN ",
                    "SSE LN",
                    "ENGI FP",
                    "EN FP",
                    "BT/A LN",
                    "VIE FP",
                    "TATE LN",
                    "SAN FP",
                ],
                "params": {
                    "payoffs": ["autocall"],
                    "reoffer": 98,
                    "maturity_in_months": 18,
                    "frequency": "3M",
                    "ki_barrier": 60,
                    "atk_start_period": 2,
                },
            },
            "barrier50": {
                "tickers": [
                    "ORA FP",
                    "GSK LN",
                    "VOD LN",
                    "NG/ LN ",
                    "SSE LN",
                    "ENGI FP",
                    "EN FP",
                    "BT/A LN",
                    "VIE FP",
                    "TATE LN",
                    "SAN FP",
                ],
                "params": {
                    "payoffs": ["autocall"],
                    "reoffer": 98,
                    "maturity_in_months": 18,
                    "frequency": "3M",
                    "ki_barrier": 50,
                    "atk_start_period": 2,
                },
            },
        }

        for theme in themes:

            tickers = themes.get(theme).get("tickers")
            params = themes.get(theme).get("params")

            try:
                results = sg.pricing_run_with_details(
                    tickers=tickers, currencies=pricing_currencies, nb_ul=1, **params,
                )

                if results:
                    data[theme] = {
                        "title": theme,
                        "prices": results[0],
                        **results[1],
                    }
            except Exception as e:
                print(repr(e))

        return data

    def _get_data_cindy(self):
        sg = SGPricer()

        data = {}

        pricing_currencies = ["EUR"]

        themes = {
            "Vol Opportunities": {
                "tickers": [
                    "GRF SM",
                    "SESG FP",
                    "BAS GY",
                    "HD US",
                    "HEI GY",
                    "VIE FP",
                    "BX US",
                    "CSGN SW",
                    "PSM GY",
                    "CA FP",
                ],
                "params": {
                    "reoffer": 98,
                    "maturity_in_months": 18,
                    "cpn_barrier": 70,
                    "ki_barrier": 70,
                },
            },
        }

        for theme in themes:
            payoffs = ["autocall"]

            tickers = themes.get(theme).get("tickers")
            params = themes.get(theme).get("params")

            try:
                results = sg.pricing_run_with_details(
                    tickers=tickers,
                    payoffs=payoffs,
                    currencies=pricing_currencies,
                    nb_ul=3,
                    **params,
                )

                if results:
                    data[theme] = {
                        "title": theme,
                        "prices": results[0],
                        **results[1],
                    }
            except Exception as e:
                print(repr(e))

        return data

    def _get_data(self):
        sg = SGPricer()

        data = {}

        try:

            prices, quote_ids, details = sg.pricing_run_with_details(
                theme="bnpp_opinions"
            )

            data["BNPP"] = {
                "title": self._encode("🔬 Exane BNPP Opinions"),
                "comment": "Selection is made on last week's top recommendations from Exane BNPP",
                "prices": prices,
                "quote_ids": quote_ids,
                **details,
            }

        except:
            pass

        try:
            prices, quote_ids, details = sg.pricing_run_with_details(theme="apollo")

            data["Apollo"] = {
                "title": self._encode("🛰️ Exane Apollo"),
                "comment": "Prices on the current components of the index",
                "prices": prices,
                "quote_ids": quote_ids,
                **details,
            }
        except:
            pass

        try:

            prices, quote_ids, details = sg.pricing_run_with_details(
                tickers=[
                    "SPX",
                    "SX5E",
                    "SMI",
                    "CAC",
                    "RTY",
                    "UKX",
                    "NDX",
                    "HSCEI",
                    "DAX",
                    "SD3E",
                    "MXEU",
                    "MXWO",
                    "CS90",
                ],
                ki_barrier=90,
                cpn_barrier=90,
            )

            data["Indices"] = {
                "title": self._encode("🌍 Main Indices"),
                "comment": "Selection of popular indices",
                "prices": prices,
                "quote_ids": quote_ids,
                **details,
            }

            themes = {
                "Thematic ETFs": {
                    "tickers": [
                        "LSEG LN",
                        "XLP UP",
                        "XLI UP",
                        "IYT UF",
                        "IYF UP",
                        "IYR UP",
                        "OIL FP",
                        "XLF UP",
                        "XLB UP",
                        "XME UP",
                        "USO UP",
                        "GDX UP",
                        "XLV UP",
                        "XLY UP",
                        "XLU UP",
                        "DBA UP",
                        "XHB UP",
                        "XOP UP",
                        "XBI UP",
                        "IYH UP",
                    ],
                    "params": {
                        "reoffer": 98,
                        "maturity_in_months": 18,
                        "cpn_barrier": 75,
                        "ki_barrier": 75,
                    },
                }
            }

            for theme in themes:

                tickers = themes.get(theme).get("tickers")
                params = themes.get(theme).get("params")

                try:
                    results = sg.pricing_run_with_details(tickers=tickers, **params,)

                    if results:
                        data[theme] = {
                            "title": theme,
                            "prices": results[0],
                            "quote_ids": results[1],
                            **results[2],
                        }
                except Exception as e:
                    print(repr(e))

        except Exception as e:
            msg = "Error getting data in Pricing Runs"
            app.logger.exception(msg)

        finally:
            return data

    def _get_data_baskets_bnpp(self):
        sg = SGPricer()

        data = {}

        pricing_currencies = ["GBP"]

        params = {
            "reoffer": 97,
            "maturity_in_months": 36,
            "cpn_barrier": 70,
            "ki_barrier": 70,
            "option_type": "WorstOf",
        }

        themes = {
            "Automobiles & Components": {
                "tickers": ["RNO FP", "FR FP", "FCA IM", "PAH3 GY", "DAI GY",],
                "params": {
                    "reoffer": 97,
                    "maturity_in_months": 36,
                    "cpn_barrier": 70,
                    "ki_barrier": 70,
                    "option_type": "WorstOf",
                },
            },
            "Capital Goods": {
                "tickers": ["ELUXB SS", "LR FP", "SIE GY", "SU FP", "IP IM",],
                "params": params,
            },
            "Chemicals": {
                "tickers": ["DD UN", "PPG UN", "FMC UN", "BAS GY", "APD UN",],
                "params": params,
            },
            "Construction": {
                "tickers": ["LUV UN", "MLM UN", "OC UN", "MAERSKB DC", "ACS SQ",],
                "params": params,
            },
            "Diversified Financials": {
                "tickers": ["KKR UN", "BX UN", "BLK UN", "LSE LN", "AMUN FP",],
                "params": params,
            },
            "Energy": {
                "tickers": ["SUBC NO", "RDSA NA", "RDSB LN", "AKERBP NO", "NESTE FH",],
                "params": params,
            },
            "Food & Staples Retail": {
                "tickers": ["SBRY LN", "CA FP", "DGE LN", "MRW LN", "TSCO LN",],
                "params": params,
            },
            "General Retail": {
                "tickers": ["RL UN", "SKX UN", "VFC UN", "BBY UN", "KGF LN", "NKE UN",],
                "params": params,
            },
            "Health Care": {
                "tickers": ["GN DC", "FRE GY", "KORI FP", "FME GY", "EL FP",],
                "params": params,
            },
            "Insurance": {
                "tickers": ["SCR FP", "LGEN LN", "MUV2 GY", "NN NA", "AV/ LN",],
                "params": params,
            },
            "Media & Entertainment": {
                "tickers": ["PSON LN", "UBI FP", "PSM GY", "ATVI UW", "EA UW",],
                "params": params,
            },
            "Telecommunication Services": {
                "tickers": ["ILD FP", "EN FP", "TMUS UW", "CLNX SQ", "VOD LN",],
                "params": params,
            },
            "Utilities": {
                "tickers": ["EDF FP", "VIE FP", "ENGI FP", "SSE LN", "NG/ LN",],
                "params": params,
            },
        }

        for theme in themes:
            payoffs = ["autocall"]

            tickers = themes.get(theme).get("tickers")
            params = themes.get(theme).get("params")

            try:
                results = sg.get_prices_combinations(
                    tickers=tickers,
                    payoffs=payoffs,
                    currencies=pricing_currencies,
                    nb_ul=3,
                    **params,
                )

                if results:
                    data[theme] = {
                        "title": theme,
                        "prices": results[0],
                        **results[1],
                    }
            except Exception as e:
                print(repr(e))

        return data


class MailEvents(Mailer):
    def __init__(self, events_date=None, cfins=None, **kwargs):
        super().__init__(**kwargs)

        if events_date is None:
            events_date = prev_bday(1)

        event_type_plurial = {
            "Maturity": "Maturities",
            "Coupon": "Coupons",
            "Autocall": "Autocalls",
        }

        self.data_mail = self._get_data(events_date, cfins)

        if self.data_mail:

            for mail in self.data_mail:

                if mail.get("events"):

                    self.to = []

                    self.cc = [
                        "montage@exane.com",
                        "dev-turfu@exane.com",
                        "exane.structuring@exane.com",
                    ]

                    # Check if the mail is for a sales or a flex
                    if mail.get("email"):
                        self.to += [mail["email"]]
                    else:
                        username = mail["name"]
                        email = self._get_mail(username)
                        self.to += email

                    events = []
                    for event_type in mail["events"]:
                        nb = len(mail["events"][event_type])
                        description = (
                            f"{nb} {event_type_plurial[event_type.capitalize()]}"
                            if nb > 1
                            else f"{nb} {event_type.capitalize()}"
                        )
                        events.append(description)
                    description_events = ", ".join(events)

                    self.name = f"🔔 Events - {mail['sales']} 🔔"
                    elements_subject = [
                        self.name,
                        description_events,
                        dt_today("string_date"),
                    ]
                    self.subject = " - ".join(elements_subject)

                    if mail["sales"] == "EUROTLX Team":
                        self.to += [
                            "italian.derivatives@exane.com",
                            "convex.trading@exane.com",
                        ]

                        if "Autocall" in self.subject or "Maturity" in self.subject:
                            self.to.append("itd-support@exane.com")

                    self.data = mail
                    self.content = self._set_template(
                        "events", subtitles=self._subtitles
                    )
                    self.send_mail()

    @property
    def _subtitles(self):
        return {
            "maturity": self._encode("🏴 Maturity"),
            "autocall": self._encode("🏁 Autocall"),
            "coupon": self._encode("💸 Coupon"),
        }

    def _get_data(self, events_date=None, cfins=None):

        op = OpenPositions()
        to_str_percent = (
            lambda x: f"{x/100:,.3%}".replace("0%", "%") if x != "TBD" else x
        )

        # Get events from the cubes
        d_cubes_events = sql.events_cpns_or_autocalls(events_date)

        # Get maturity products from products alive
        d_maturity = sql.events_maturity(events_date)

        data = d_cubes_events + d_maturity

        for product in data:
            if not product.get("isin"):
                data.remove(product)

        if not data:
            return None

        if cfins:
            data = [x for x in data if x["cfin"] in cfins]

        for product in data:

            cfin = product["cfin"]

            ############################################################
            ### Find clients and positions by cfin (excluding AMC) ###
            ############################################################

            # Formating
            to_str_price = lambda x: "{:,.0f}".format(x) if x else "N/A"
            to_qty = lambda x: x["Quantity"] if x["Type"] == "Buy" else -x["Quantity"]
            to_cash = (
                lambda x: x["Units"]
                * product["nominal"]
                * product["percent_paid"]
                / 100
            )

            pos_total = 0
            pose_by_client = pd.DataFrame()
            df_operations = op.formatted_trades_for_cfin(cfin)

            if not df_operations.empty:
                df_operations["Units"] = df_operations.apply(to_qty, 1)

                if product["event_type"] == "maturity":
                    pose_by_client = df_operations.groupby("Client").aggregate(
                        Quantity=("Units", "sum")
                    )
                    pose_by_client = pose_by_client[pose_by_client["Quantity"] != 0]
                else:
                    df_operations["Cash"] = df_operations.apply(to_cash, 1)
                    if not df_operations.get("Sales Status", pd.DataFrame()).empty:
                        pose_by_client = df_operations.groupby("Client").aggregate(
                            Sales=(
                                "Sales",
                                lambda x: ", ".join(
                                    [
                                        y
                                        for y in set(x)
                                        if df_operations[df_operations["Sales"] == y][
                                            "Sales Status"
                                        ].unique()[0]
                                        == 1
                                    ]
                                ),
                            ),
                            Quantity=("Units", "sum"),
                            Cash=("Cash", "sum"),
                        )
                    else:
                        pose_by_client = df_operations.groupby("Client").aggregate(
                            Quantity=("Units", "sum"), Cash=("Cash", "sum"),
                        )
                    pose_by_client = pose_by_client[pose_by_client["Quantity"] != 0]
                    pose_by_client["Cash"] = pose_by_client["Cash"].apply(to_str_price)

                pos_total = pose_by_client["Quantity"].sum() * product["nominal"]

            ############################################################
            ### Find AMCs linked to the product and positions in AMC ###
            ############################################################

            if cfin == 43029113:
                print(cfin)

            summary = sql.positions_details(cfin, date=events_date)

            if summary:

                # If no client but a trading position, then its an AMC position
                if pos_total == 0 and summary["positions"] != 0:
                    pos_amc = abs(summary["positions"])
                else:
                    pos_amc = summary["positions_amc"]

                pos_total += pos_amc
                df_clients_amc = pd.DataFrame()
                if pos_amc > 0:
                    try:
                        cfins_amc = sql_amc.cfins_amc_from_cfin_underlying(
                            cfin, date=events_date
                        )
                        if not cfins_amc:
                            pos_amc = 0
                        else:
                            df_clients_amc = pd.DataFrame(
                                columns=["Client", "Cfin_amc", "Ticker_amc", "Name_amc"]
                            )
                            for x in cfins_amc:
                                # Get the email to be sent to
                                email_amc = sql.get_email_from_cfin_amc(x["cfin_index"])

                                # Get the Advisor Name
                                advisor = "Advisor Name Missing"
                                contacts = ExaneInstruments().service.getPersonIdFromCfin(
                                    x["cfin_index"]
                                )
                                crm_ids = [
                                    x["id"] for x in contacts if not x["toDelete"]
                                ]
                                if crm_ids:
                                    crm_first_id = crm_ids[0]
                                    contact_details = CrmPersonne().service.getDataPersonneFromIdCRM(
                                        crm_first_id
                                    )
                                    advisor = contact_details["institutionName"]

                                # In case no advisor was found, take

                                df_clients_amc = df_clients_amc.append(
                                    {
                                        "Client": advisor,
                                        "Cfin_amc": f"{x['cfin_index']:.0f}",
                                        "Ticker_amc": x["ticker_index"],
                                        "Name_amc": x["name_index"],
                                    },
                                    ignore_index=True,
                                )
                                if "email_amc" not in product.keys():
                                    product["email_amc"] = {email_amc: x["name_index"]}
                                else:
                                    product["email_amc"][email_amc] = x["name_index"]

                    except Exception as e:
                        print(repr(e))

                product["percent_paid"] = to_str_percent(product["percent_paid"])
                product["pos_amc"] = to_str_price(pos_amc)
                product["pos_total"] = to_str_price(pos_total)
                product["positions_out_amc"] = pose_by_client.reset_index()
                product["positions_in_amc"] = df_clients_amc

        data_nested = self.formating_data_nested(data)

        return data_nested

    def formating_data_nested(self, data):

        cfins = [x["cfin"] for x in data]

        # Dictionnary by cfin
        d_data = {x["cfin"]: x for x in data}

        # Dictionnary email by cfin
        d_amc_mail = {x["cfin"]: x["email_amc"] for x in data if x.get("email_amc")}

        data_nested = []

        #######################################
        ## Add emails for each AMC email-box ##
        #######################################

        # Regroup cfins by AMC
        cfins_by_amc = {}
        for cfin, emails in sorted(d_amc_mail.items()):
            for email in emails:
                if email not in cfins_by_amc:
                    cfins_by_amc[email] = [cfin]
                else:
                    cfins_by_amc[email].append(cfin)

        # Dictionnary formatted by AMC and by events
        for amc in cfins_by_amc:
            res = {
                "email": amc,
                "sales": "",
                "events": {},
            }
            for cfin in cfins_by_amc[amc]:
                event = d_data[cfin]["event_type"]
                res["events"].setdefault(event, []).append(d_data[cfin])
            res["sales"] = d_data[cfin]["email_amc"].get(amc)

            data_nested.append(res)

        #########################
        ## Add emails by sales ##
        #########################

        # Group data by sales
        cfins_by_sales = sql.username_sales_involved(cfins)

        # Dictionnary formatted by sales and by events
        for sales in cfins_by_sales:
            res = {
                "sales": sales[0],
                "name": sales[1],
                "events": {},
            }

            calendar = osiris.instruments_calendars(cfins_by_sales[sales])

            for cfin in cfins_by_sales[sales]:

                data = d_data[cfin]

                # Add ex dates for Trading for EUROTLX events
                if sales[0] == "EUROTLX Team" and calendar.get(cfin):

                    dates = calendar[cfin].get("dates")

                    if dates.empty:
                        continue

                    observation_dates = dates[
                        dates["fixing"] == prev_bday(1, "datetime")
                    ]

                    if observation_dates.empty:
                        continue

                    ex_date = dates[dates["fixing"] == prev_bday(1, "datetime")][
                        "ex"
                    ].iloc[0]
                    data["ex_date"] = to_str_date(ex_date)

                event = data["event_type"]
                res["events"].setdefault(event, []).append(data)

            data_nested.append(res)

        return data_nested

    @staticmethod
    def _get_mail(username):
        r = Rkvendeurcircus.query.filter_by(vcloginad=username).first()
        if r:
            crm = CrmPersonne()
            data = crm.service.getDataPersonneFromIdCRM(r.vcidcrm)
            if data:
                if data.mailPrincipal in [
                    "antonio.manfre@exane.com",
                    "carlo.ceriani@exane.com",
                ]:
                    return ["italian.derivatives@exane.com"]
                return [data.mailPrincipal]
        return ["sales.analysts@exane.com"]


class MailEuroclear(Mailer):
    def __init__(self, data, **kwargs):

        if data:

            super().__init__(**kwargs)

            self.data = data

            self.sender = "Exane Solutions <exane.structuring@exane.com>"

            self.to = [
                "afc@euroclear.com",
                "laurence.villaldea@euroclear.com",
            ]

            self.cc = [
                "IndexStructuring@exane.com",
                "CalculationAgent@exane.com",
            ]

            self.content = self._set_template("euroclear")
            self.subject = f"Exane | Réservation ISINs - " + dt_today("string_date")

            self.send_mail()


if __name__ == "__main__":
    with server.app_context():
        MailBNPInteractions(start_date=dt(2021, 12, 19), end_date=dt(2021, 12, 21))
        MailControlListedInventory()
        # MailAMCCashOrders(nb_days=1)
        MailEvents(cfins=[47461604])
        # MailEvents(cfins=[47461604], events_date=dt(2021, 12, 29))

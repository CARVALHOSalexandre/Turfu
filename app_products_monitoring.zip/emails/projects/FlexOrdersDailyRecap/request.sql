WITH orders as (
    SELECT "Certif Cfin"
            ,"Certif Name"
            ,"Flex Cfin"
            ,"Flex Name"
            ,"Typo"
            ,"Units"
            ,"Trade Date"
            , TO_DATE("Close Str", 'DD/MM') "Close Date"
            ,"Mail"
            ,"Comment"
    FROM (
        SELECT opcfin "Certif Cfin"
            ,instruments_certif.ifnom "Certif Name"
            ,instruments_flex.ifcfin "Flex Cfin"
            ,instruments_flex.ifnom "Flex Name"
            ,- opquantite "Units"
            ,opdatenego "Trade Date"
            ,SUBSTR(REGEXP_SUBSTR(LOWER(TO_CHAR(opcommentaire)), '(close|du|of) \d{1,2}[-/]\d{1,2}'), -5) "Close Str"
            ,opcommentaire "Comment"
            ,libelle_typologie "Typo"
            ,xavaleurstring "Mail"
        FROM risque.rkoperation
        JOIN exane.instruments instruments_certif on instruments_certif.ifcfin = opcfin
        JOIN EXANE.alien alien_flex ON alien_flex.alsjac = ifcfin AND alien_flex.altype = 56
        JOIN exane.instruments instruments_flex on instruments_flex.ifcfin = alcfin
        LEFT JOIN derives.idxattributs on xacfin = alcfin and xatypeattribut = 71
        JOIN exane.v_typologie
            ON code_valeur_typee = alcfin
            AND flag_typologie != 3
            AND code_famille_typologie = 86
            AND code_valeur_typologie = 16370
        WHERE
            opdate > sysdate - nb_days
            AND opquantite != 0
            AND opflag != 3
            AND opotype = 51
    )
)
SELECT "Certif Cfin"
    ,"Certif Name"
    ,"Flex Cfin"
    ,"Flex Name"
    ,"Mail"
    ,"Trade Date"
    ,"Close Date"
    ,sum("Units") "Sum Units"
    ,CASE
        WHEN "Close Date" IS null THEN LISTAGG("Comment", '; ')
                                            WITHIN GROUP (ORDER BY "Trade Date", "Comment")
        ELSE null
    END "PoTT Comments"
FROM orders
GROUP BY "Certif Cfin"
    ,"Certif Name"
    ,"Flex Cfin"
    ,"Flex Name"
    ,"Mail"
    ,"Trade Date"
    ,"Close Date"
ORDER BY "Sum Units" DESC
import os
import pandas as pd
import utils.sql as sql
from app import PATH

pd.set_option("display.width", 400)
pd.set_option("display.max_columns", 10)


def encode(value):
    return value.encode("ascii", "xmlcharrefreplace").decode("utf-8")


def get_data(nb_days=1):
    path_query = os.path.join(PATH, f"emails/projects/FlexOrdersDailyRecap/request.sql")
    df = sql.execute_sql_query(path_sql_query=path_query, nb_days=nb_days)

    # Replace PoTT comments to empty string if missing
    df["PoTT Comments"] = df["PoTT Comments"].apply(lambda x: x if x else "")

    # Define numbers of AMCs and Certificates
    nb_amcs = len(df["Flex Cfin"].unique())
    nb_certifs = len(df["Certif Cfin"].unique())

    # Define number of Buy and Sell orders
    nb_buy_orders = len(df[df["Sum Units"] > 0])
    nb_sell_orders = len(df[df["Sum Units"] < 0])

    # Create list of all emails
    dff = df[~df.Mail.isna()].drop_duplicates(["Flex Cfin"])
    emails = dff.Mail.tolist()

    # Initiate missing data
    missing = []

    # Check for missing emails
    df_missing_emails = df[df.Mail.isna()].drop_duplicates(["Flex Cfin"])
    if not df_missing_emails.empty:
        title = "⚠️  The emails of the following AMCs are missing  📧"
        missing.append(
            {
                "title": encode(title),
                "data": df_missing_emails[["Flex Cfin", "Flex Name"]].to_dict(
                    "records"
                ),
            }
        )

    # Check for missing Close Date
    df_missing_close_date = df[df["Close Date"] == ""]
    if not df_missing_close_date.empty:
        title = "⚠️  The Close Date of the following orders are not readable   📅"
        columns = [
            "Certif Cfin",
            "Certif Name",
            "Trade Date",
            "Sum Units",
            "PoTT Comments",
        ]
        missing.append(
            {
                "title": encode(title),
                "data": df_missing_close_date[columns].to_dict("records"),
            }
        )

    # Pre format data for the email
    orders = []
    columns = ["Certif Cfin", "Certif Name", "Trade Date", "Close Date", "Sum Units"]
    amcs = (
        df[["Flex Cfin", "Flex Name"]].drop_duplicates(["Flex Cfin"]).to_dict("records")
    )
    for amc in amcs:
        dff = df[df["Flex Cfin"] == amc.get("Flex Cfin")][columns]
        orders.append(
            {
                "cfin": amc.get("Flex Cfin"),
                "name": amc.get("Flex Name"),
                "data": dff.to_dict("records"),
            }
        )

    return {
        "emails": emails,
        "nb_amcs": nb_amcs,
        "nb_certifs": nb_certifs,
        "nb_sell_orders": nb_sell_orders,
        "nb_buy_orders": nb_buy_orders,
        "missing": missing,
        "orders": orders,
    }


if __name__ == "__main__":
    from app import server

    with server.app_context():
        pass

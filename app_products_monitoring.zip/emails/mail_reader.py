import re
import pandas as pd
import urllib3
from datetime import datetime as dt
from datetime import timedelta

try:
    import zoneinfo
except ImportError:
    from backports import zoneinfo
from exchangelib import (
    Credentials,
    Account,
    Configuration,
    DELEGATE,
    Message,
    EWSTimeZone,
    EWSDateTime,
    Q,
)
from exchangelib.protocol import BaseProtocol, NoVerifyHTTPAdapter
from app import server, db
from local_db_mgt import User


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
BaseProtocol.HTTP_ADAPTER_CLS = NoVerifyHTTPAdapter


def turfu_users_and_departments():
    # Get dictionnary of Turfu's users
    users = db.session.query(User.displayname, User.department_id)
    df = pd.DataFrame(users)
    df.department_id = df.department_id.apply(lambda x: str(x).replace("\r", ""))
    return {x["displayname"]: x["department_id"] for k, x in df.iterrows()}


def list_involved(row, departments):
    structurers, sales, others = [], [], []

    names = row.get("involved")
    if names:
        for name in names:
            department = departments.get(name)
            if department and department == "STR":
                structurers.append(name)
            elif department and department[0] == "V":
                sales.append(name)
            else:
                others.append(name)

    return structurers, sales, others


def set_author(row, departments):
    authors = str(row["author"]).split("; ")
    if authors:
        for author in authors:
            department = departments.get(author)
            if department and department[0] == "V":
                return author

    # If no sales was found in the authors return the first Sales in the list
    sales = row["sales"]
    if sales:
        return sales[0]

    # If there is no sales available, return the first Author
    return authors[0]


class SharedAccount:

    SERVER = "https://mail.exane.com/EWS/Exchange.asmx"
    MAIL = "exane.structuring@exane.com"
    LOGIN = "exane.structuring"
    PASSWORD = "!hFsCc7FQSiRQxKs7ez"

    def __init__(self):
        self.credentials = Credentials(self.LOGIN, self.PASSWORD)
        self.config = Configuration(
            credentials=self.credentials, service_endpoint=self.SERVER
        )
        self.account = Account(
            primary_smtp_address=self.MAIL,
            credentials=self.credentials,
            autodiscover=False,
            config=self.config,
            access_type=DELEGATE,
        )
        self.tz = EWSTimeZone.timezone("Europe/Paris")

    def send_email(self, subject, body, to: list, cc=None, bcc=None):
        message = Message(
            account=self.account,
            subject=subject,
            body=body,
            to_recipients=to,
        )

        if cc:
            message.cc_recipients = cc

        if bcc:
            message.bcc_recipients = bcc

        message.send()

    def reply_email(self, subject, body):
        requests_folder = self.account.inbox / "3 - Sales Requests"
        email = requests_folder.get(subject=subject)
        email.reply_all(subject=f"Re: {subject}", body=body)

    def tag_email(self, subject, tags=None, start_date=None, end_date=None):
        # Set Filters & Tags
        if start_date is None:
            start_date = dt.today() - timedelta(days=3)
        if end_date is None:
            end_date = dt.today()

        # Convert Dates To EWS Format
        start_date = self.tz.localize(EWSDateTime.from_datetime(start_date))
        end_date = self.tz.localize(EWSDateTime.from_datetime(end_date))

        # Set Request Folder
        requests_folder = self.account.inbox / "3 - Sales Requests"

        # Tag Filtered Emails
        email = requests_folder.get(subject=subject)
        emails = requests_folder.filter(
            conversation_id=email.conversation_id,
            datetime_received__range=(start_date, end_date),
        )
        for email in emails:
            email.categories = [tags]
            email.save()

    def sales_requests(self, start_date, end_date):

        # Convert the date to EWS format
        start_date = self.tz.localize(EWSDateTime.from_datetime(start_date))
        end_date = self.tz.localize(EWSDateTime.from_datetime(end_date))

        # Prepare query to filter the emails
        q = (
            Q(datetime_received__range=(start_date, end_date))
            & Q(conversation_topic__icontains="RFQ")
            & ~Q(conversation_topic__icontains="DEAL DONE")
        )

        # Focus on the folder and archive folder that contains the sales requests
        requests_folder = self.account.inbox / "3 - Sales Requests"
        requests_archive_folder = None
        try:
            requests_archive_folder = (
                self.account.archive_root
                / "Top of Information Store"
                / "Inbox"
                / "3 - Sales Requests"
            )
        except:
            pass

        data = []
        for folder in [requests_folder, requests_archive_folder]:
            if folder:

                filtered_items = folder.filter(q).only(
                    "conversation_topic",
                    "author",
                    "datetime_received",
                    "display_to",
                    "display_cc",
                    "categories",
                    "text_body",
                )

                data += [
                    {
                        "subject": x.conversation_topic,
                        "author": x.author.name,
                        "involved": "; ".join(
                            set(str(x) for x in [x.display_to, x.display_cc] if x)
                        ),
                        "tags": x.categories,
                        "datetime": x.datetime_received + timedelta(hours=2),
                        "body": x.text_body[
                            0 : min(
                                i
                                for i in [
                                    x.text_body.find("From: "),
                                    x.text_body.find("De : "),
                                    x.text_body.find("Le 0"),
                                    x.text_body.find("Le 1"),
                                    x.text_body.find("Le 2"),
                                    x.text_body.find("[cid:"),
                                ]
                                if i > 0
                            )
                            if len(
                                [
                                    i
                                    for i in [
                                        x.text_body.find("From: "),
                                        x.text_body.find("De : "),
                                        x.text_body.find("Le 0"),
                                        x.text_body.find("Le 1"),
                                        x.text_body.find("Le 2"),
                                        x.text_body.find("[cid:"),
                                    ]
                                    if i > 0
                                ]
                            )
                            > 0
                            else -1
                        ],
                    }
                    for x in filtered_items
                ]

        df = pd.DataFrame(data)

        # Sort DataFrame
        df = df.sort_values(by=["datetime"], ascending=True)

        # Set column of people involved
        dff = df.groupby("subject").aggregate(
            involved=("involved", lambda x: list(set(("; ".join(x)).split("; ")))),
            author=("author", lambda x: "; ".join(x)),
            datetime=("datetime", "min"),
            last_datetime=("datetime", "max"),
            count=("datetime", "count"),
            tags=(
                "tags",
                lambda x: list(set(("; ".join([i[0] for i in x if i]).split("; ")))),
            ),
            body=("body", "first"),
        )

        dff["tags"] = dff["tags"].apply(lambda x: ", ".join(map(str, x)))

        users = turfu_users_and_departments()
        dff[["structurers", "sales", "others"]] = dff.apply(
            lambda x: pd.Series(list_involved(x, users)), axis=1
        )

        # Add request type column
        dff.loc[
            (dff.index.str.lower().str.contains("trad") == True)
            | (dff.index.str.lower().str.contains("liv") == True),
            "Type",
        ] = "Trading"
        dff.loc[dff["Type"] != "Trading", "Type"] = "Indicative"

        # Set the author as the first Sales in the list order
        dff["author"] = dff.apply(lambda x: set_author(x, users), axis=1)

        return dff

    def external_issuers(self, request, issuer):

        folder = self.account.inbox / "10 - Auto Pricing"

        # Mark as read all related emails
        q = Q(subject__contains="Exane | ") & Q(subject__contains=request)
        filtered_items = folder.filter(q).only("conversation_topic")
        for item in filtered_items:
            item.is_read = True
            item.save(update_fields=["is_read"])

        # Prepare query to filter the answer emails
        q = (
            # Q(subject__contains="RE: ")
            ~Q(author__contains="exane.com")
            & Q(subject__contains="Exane")
            & Q(subject__contains=request)
            & Q(subject__contains=issuer)
        )
        # Retrieve Wanted Emails
        data = []
        filtered_items = folder.filter(q).only(
            "conversation_topic",
            "author",
            "datetime_received",
            "body",
        )
        data += [
            {
                "subject": x.conversation_topic,
                "body": x.body,
                "datetime": x.datetime_received + timedelta(hours=2),
                "author": x.author.name,
            }
            for x in filtered_items
        ]

        df = pd.DataFrame(data)

        if not df.empty:
            # Sort DataFrame
            df = df.sort_values(by=["datetime"], ascending=False)

            # Set column of people involved
            dff = (
                df.groupby("subject")
                .aggregate(
                    author=("author", lambda x: ", ".join(x)),
                    datetime=("datetime", "max"),
                    body=("body", "first"),
                )
                .reset_index()
            )
        else:
            dff = None

        return dff

    def external_requests(self, start_date, end_date, primary_only=True, issuer=None):

        # Convert the date to EWS format
        start_date = self.tz.localize(EWSDateTime.from_datetime(start_date))
        end_date = self.tz.localize(EWSDateTime.from_datetime(end_date))

        # Prepare query to filter the emails
        q = (
            Q(datetime_received__range=(start_date, end_date))
            & Q(subject__contains="Exane |")
            & ~Q(subject__contains="Pricing Access")
        )

        if primary_only:
            q = q & ~Q(in_reply_to__startswith="")  # Equivalent to in_reply_to is null

        if issuer:
            q = q & Q(subject__contains=issuer)

        # Focus on the folder and archive folder that contains the price requests
        requests_folder = self.account.inbox / "2 - Price Requests"
        requests_archive_folder = None
        try:
            requests_archive_folder = (
                self.account.archive_root
                / "Top of Information Store"
                / "Inbox"
                / "2 - Price Requests"
            )
        except:
            pass

        data = []
        for folder in [requests_folder, requests_archive_folder]:
            if folder:
                filtered_items = folder.filter(q).only(
                    "conversation_topic", "author", "datetime_received"
                )

                data += [
                    {
                        "subject": x.conversation_topic,
                        "sent_from_mail": x.author.email_address,
                        "sent_from_name": x.author.name,
                        "datetime": x.datetime_received,
                    }
                    for x in filtered_items
                ]

        for k, x in enumerate(data):

            try:
                subject = x.pop("subject")
                details = subject.split("| ")[1].split(" - ")

                # Subject always starts with issuer's short name
                issuer = details.pop(0).strip()
                if issuer != "Exane":
                    data[k]["issuer_short_name"] = issuer

                    # Rename Issuer (if needed)
                    if data[k]["issuer_short_name"] == "Crédit Suisse":
                        data[k]["issuer_short_name"] = "CS"
                    elif data[k]["issuer_short_name"] in ["Leonteq", "Ltq"]:
                        data[k]["issuer_short_name"] = "LTQ"
                    elif data[k]["issuer_short_name"] == "JP":
                        data[k]["issuer_short_name"] = "JPM"

                    # Second parameter is the type
                    if "Trad" in details.pop(0):
                        data[k]["type"] = "Trading"
                    else:
                        data[k]["type"] = "Indicative"

                    # Get the sales, which should be the last 4 characters
                    if re.match(r"^[A-Z]{4}$", details[-1]):
                        data[k]["sales"] = details.pop(-1)

                    # If the object matches the correct length
                    if len(details) == 4:
                        data[k]["size_ccy"] = str(details[0]).strip()
                        data[k]["format"] = str(details[1]).strip()
                        data[k]["asset_class"] = str(details[2]).strip()
                        data[k]["description"] = str(details[3]).strip()

                    # If the sender sent the email manually
                    else:
                        # The description is always the longest string
                        index_description = details.index(str(max(details, key=len)))
                        description = details.pop(index_description)
                        data[k]["description"] = str(description).strip()

                        # If user mentioned OTC then it is an OTC
                        data[k]["format"] = "Note"
                        if any("OTC" in x for x in details):
                            data[k]["format"] = "OTC"

            except Exception as e:
                print(e)

        df = pd.DataFrame(data)

        if df.empty:
            return pd.DataFrame()

        if primary_only:
            # Filter rows if the author is not working at Exane
            df = df[df.sent_from_mail.str.contains("@exane.com")]

        # Filter rows that have no description
        df = df[~df.description.isna()]

        return df

    def find_price_request(self, start_date=None, end_date=None):

        # Prepare query to filter the emails
        q = (
            Q(datetime_received__range=(start_date, end_date))
            & Q(subject__contains="Exane |")
            & ~Q(subject__contains="Pricing Access")
            & ~Q(in_reply_to__startswith="")  # Equivalent to in_reply_to is null
        )

        # Focus on the folder and archive folder that contains the price requests
        folder = self.account.inbox / "3 - Sales Requests"

        with self.account.inbox.streaming_subscription() as subscription_id:
            print(subscription_id)

        data = []

        filtered_items = folder.filter(q).only(
            "conversation_topic", "author", "datetime_received"
        )

        data += [
            {
                "subject": x.conversation_topic,
                "sent_from_mail": x.author.email_address,
                "sent_from_name": x.author.name,
                "datetime": x.datetime_received,
            }
            for x in filtered_items
        ]

        for k, x in enumerate(data):

            try:
                subject = x.pop("subject")
                details = subject.split("| ")[1].split(" - ")

                # Subject always starts with issuer's short name
                issuer = details.pop(0).strip()
                if issuer != "Exane":
                    data[k]["issuer_short_name"] = issuer

                    # Rename Issuer (if needed)
                    if data[k]["issuer_short_name"] == "Crédit Suisse":
                        data[k]["issuer_short_name"] = "CS"
                    elif data[k]["issuer_short_name"] in ["Leonteq", "Ltq"]:
                        data[k]["issuer_short_name"] = "LTQ"
                    elif data[k]["issuer_short_name"] == "JP":
                        data[k]["issuer_short_name"] = "JPM"

                    # Second parameter is the type
                    if "Trad" in details.pop(0):
                        data[k]["type"] = "Trading"
                    else:
                        data[k]["type"] = "Indicative"

                    # Get the sales, which should be the last 4 characters
                    if re.match(r"^[A-Z]{4}$", details[-1]):
                        data[k]["sales"] = details.pop(-1)

                    # If the object matches the correct length
                    if len(details) == 4:
                        data[k]["size_ccy"] = str(details[0]).strip()
                        data[k]["format"] = str(details[1]).strip()
                        data[k]["asset_class"] = str(details[2]).strip()
                        data[k]["description"] = str(details[3]).strip()

                    # If the sender sent the email manually
                    else:
                        # The description is always the longest string
                        index_description = details.index(str(max(details, key=len)))
                        description = details.pop(index_description)
                        data[k]["description"] = str(description).strip()

                        # If user mentioned OTC then it is an OTC
                        data[k]["format"] = "Note"
                        if any("OTC" in x for x in details):
                            data[k]["format"] = "OTC"

            except Exception as e:
                print(e)

        df = pd.DataFrame(data)

        # Filter rows if the author is not working at Exane
        df = df[df.sent_from_mail.str.contains("@exane.com")]

        # Filter rows that have no description
        df = df[~df.description.isna()]

        return df

    def mail_sent_bnp_smart_der(self, start_date, end_date):

        # Convert the date to EWS format
        start_date = self.tz.localize(EWSDateTime.from_datetime(start_date))
        end_date = self.tz.localize(EWSDateTime.from_datetime(end_date))

        folder = self.account.inbox / "2 - Price Requests"

        # Prepare query to filter the emails
        q = Q(datetime_received__range=(start_date, end_date)) & Q(
            subject__contains="Price request sent to"
        )

        # Retrieve Wanted Emails
        data = []
        filtered_items = folder.filter(q).only(
            "conversation_topic",
            "author",
            "datetime_received",
        )
        data += [
            {
                "subject": x.conversation_topic,
                "datetime": x.datetime_received + timedelta(hours=2),
                "author": x.author.name,
            }
            for x in filtered_items
        ]

        return pd.DataFrame(data)


if __name__ == "__main__":
    pd.options.display.width = 800
    pd.set_option("max_rows", 35)
    pd.set_option("max_columns", 35)

    with server.app_context():

        start_date = dt.today() - timedelta(days=3)
        end_date = dt.today()

        sa = SharedAccount()

        # df = sa.external_issuers(start_date, end_date)
        # print(df)

        # sa.reply_email(subject="RFQ - Test Only", user="Theo")

        df_sales = sa.sales_requests(start_date, end_date)
        print(df_sales)

        # df_external = sa.external_requests(start_date, end_date)
        # print(df_external)

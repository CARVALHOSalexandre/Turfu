import os
import pathlib
import logging
from logging.handlers import RotatingFileHandler

from flask_dotenv import DotEnv
from sqlalchemy import create_engine
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore


class Config:
    DEBUG = True

    PATH = pathlib.Path(__file__).parent

    SECRET_KEY = b"\x81\xdf\x1a\xbf\xfc\x99$r\xb8\xe4\xfc\x80\x8bQ\x9cnu\xb3\xd4\xa8r\x17\xb6r\xc6\x85\x9e\xc5\x12PW\xbc"
    SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(PATH, "users.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {"max_identifier_length": 128}

    LDAP_HOST = "ldap.ad.exane.com"  # Port 636
    LDAP_BASE_DN = "dc=insitu,dc=ad,dc=exane,dc=com"
    LDAP_GET_USER_ATTRIBUTES = [
        "employeeID",  # 7080
        "sAMAccountName",  # Bichon_P
        "cn",  # Pierre Bichon
        "displayName",  # Pierre Bichon
        "name",  # Pierre Bichon
        "co",  # Switzerland
        "l",  # Geneva
        "company",  # Exane Derivatives
        "title",  # Product Development Group
        "department",  # Dérivés\\Structuration
        "departmentNumber",  # ['STR']
        "mail",  # Pierre.Bichon@exane.com
        "telephoneNumber",  # +41 22 737 1868
    ]
    LDAP_SEARCH_FOR_GROUPS = False
    LDAP_USER_SEARCH_SCOPE = "SUBTREE"
    LDAP_USER_RDN_ATTR = "cn"
    LDAP_USER_LOGIN_ATTR = "sAMAccountName"

    MAIL_SERVER = "smtp.exane.com"
    MAIL_PORT = 25
    MAIL_DEFAULT_SENDER = "Structuring <exane.structuring@exane.com>"
    MAIL_FLEX_SENDER = "Exane <composition@exane.com>"
    MAIL_INTERNAL_SUBJECT_PREFIX = "[Turfu] "
    MAIL_EXTERNAL_SUBJECT_PREFIX = "Exane | "
    MAIL_ADMIN = "dev-turfu@exane.com"

    JOBS = [
        # {
        #     # Weekly email with an update of Last Weekly Opinions
        #     "id": "weekly_email_last_opinions",
        #     "func": "utils.jobs:weekly_email_last_opinions",
        #     "trigger": "cron",
        #     "day_of_week": "mon",
        #     "hour": 9,
        #     "minute": 45,
        #     "misfire_grace_time": 30,
        #     "replace_existing": True,
        # },
        # {
        #     # Daily email with current Contribution Issues
        #     "id": "daily_email_contrib_issues",
        #     "func": "utils.jobs:daily_email_contrib_issues",
        #     "trigger": "cron",
        #     "day_of_week": "mon-fri",
        #     "hour": 9,
        #     "minute": 50,
        #     "misfire_grace_time": 30,
        #     "replace_existing": True,
        # },
        # {
        #     # Weekly email with probable autocall
        #     "id": "weekly_email_autocall",
        #     "func": "utils.jobs:weekly_email_autocall",
        #     "trigger": "cron",
        #     "day_of_week": "tue",
        #     "hour": 9,
        #     "minute": 45,
        #     "misfire_grace_time": 30,
        #     "replace_existing": True,
        # },
        # {
        #     # Weekly email with last week's trades
        #     "id": "weekly_email_trades",
        #     "func": "utils.jobs:weekly_email_trades",
        #     "trigger": "cron",
        #     "day_of_week": "mon",
        #     "hour": 8,
        #     "minute": 10,
        #     "misfire_grace_time": 30,
        #     "replace_existing": True,
        # },
        # {
        #     # Reload main cache elements
        #     "id": "cache_reload",
        #     "func": "utils.jobs:cache_reload",
        #     "trigger": "cron",
        #     "day_of_week": "mon-fri",
        #     "hour": 7,
        #     "minute": 15,
        #     "misfire_grace_time": 30,
        #     "replace_existing": True,
        # },
        # {
        #     # Weekly email with pricing runs
        #     "id": "weekly_email_pricing_runs",
        #     "func": "utils.jobs:weekly_email_pricing_runs",
        #     "trigger": "cron",
        #     "day_of_week": "mon",
        #     "hour": 13,
        #     "minute": 15,
        #     "misfire_grace_time": 30,
        #     "replace_existing": True,
        # },
        # {
        #     # Weekly email on Italian listed products
        #     "id": "weekly_email_italian_listed_trades",
        #     "func": "utils.jobs:weekly_email_italian_listed_trades",
        #     "trigger": "cron",
        #     "day_of_week": "fri",
        #     "hour": 18,
        #     "minute": 45,
        #     "misfire_grace_time": 30,
        #     "replace_existing": True,
        # },
        # {
        #     # Daily email with product Events
        #     "id": "daily_email_products_events",
        #     "func": "utils.jobs:daily_email_products_events",
        #     "trigger": "cron",
        #     "day_of_week": "mon-fri",
        #     "hour": 8,
        #     "minute": 10,
        #     "misfire_grace_time": 30,
        #     "replace_existing": True,
        # },
        # {
        #     # Weekly email with product MiniFutures
        #     "id": "weekly_email_minifuts",
        #     "func": "utils.jobs:weekly_email_minifuts",
        #     "trigger": "cron",
        #     "day_of_week": "fri",
        #     "hour": 9,
        #     "minute": 45,
        #     "misfire_grace_time": 30,
        #     "replace_existing": True,
        # },
        # {
        #     # Daily Website Update
        #     "id": "daily_website_update",
        #     "func": "utils.jobs:daily_website_update",
        #     "trigger": "cron",
        #     "day_of_week": "mon-sun",
        #     "hour": 7,
        #     "minute": 45,
        #     "misfire_grace_time": 30,
        #     "replace_existing": True,
        # },
        # {
        #     # Daily Website Update
        #     "id": "weekly_email_rfq",
        #     "func": "utils.jobs:weekly_email_rfq",
        #     "trigger": "cron",
        #     "day_of_week": "mon",
        #     "hour": 12,
        #     "minute": 45,
        #     "misfire_grace_time": 30,
        #     "replace_existing": True,
        # },
        # {
        #     # Daily Alert Inventory Listed Market
        #     "id": "daily_email_alert_listed_inventory",
        #     "func": "utils.jobs:daily_email_alert_listed_inventory",
        #     "trigger": "cron",
        #     "day_of_week": "mon-fri",
        #     "hour": "8, 11, 14, 17",
        #     "minute": 5,
        #     "misfire_grace_time": 30,
        #     "replace_existing": True,
        # },
        # {
        #     # Live Monitoring
        #     "id": "live_monitoring",
        #     "func": "utils.jobs:live_monitoring",
        #     "trigger": "cron",
        #     "day_of_week": "mon-fri",
        #     "hour": "8-20",
        #     "minute": "0-59",
        #     "misfire_grace_time": 1,
        #     "replace_existing": True,
        # },
        # {
        #     # Daily Delta Certifs Update
        #     "id": "daily_delta_certif_update",
        #     "func": "utils.jobs:daily_delta_certif_update",
        #     "trigger": "cron",
        #     "day_of_week": "mon-fri",
        #     "hour": 20,
        #     "minute": 5,
        #     "misfire_grace_time": 30,
        #     "replace_existing": True,
        # },
        # {
        #     # Daily BNP Interactions
        #     "id": "daily_email_bnp_interactions",
        #     "func": "utils.jobs:daily_email_bnp_interactions",
        #     "trigger": "cron",
        #     "day_of_week": "mon-fri",
        #     "hour": 8,
        #     "minute": 5,
        #     "misfire_grace_time": 30,
        #     "replace_existing": True,
        # },
        # {
        #     # Daily Email Cash Flex Orders
        #     "id": "daily_email_cash_flex_orders",
        #     "func": "utils.jobs:daily_email_cash_flex_orders",
        #     "trigger": "cron",
        #     "day_of_week": "mon-fri",
        #     "hour": 18,
        #     "minute": 35,
        #     "misfire_grace_time": 30,
        #     "replace_existing": True,
        # },
    ]

    SCHEDULER_JOBSTORES = {
        "default": SQLAlchemyJobStore(
            url="sqlite:///" + os.path.join(PATH, "jobs.sqlite")
        )
    }
    SCHEDULER_EXECUTORS = {"default": {"type": "threadpool", "max_workers": 2}}
    SCHEDULER_JOB_DEFAULTS = {"coalesce": False, "max_instances": 2}
    SCHEDULER_API_ENABLED = True

    CACHE_TYPE = "filesystem"
    CACHE_DIR = os.path.join(PATH, "cache-directory")
    CACHE_THRESHOLD = 150

    def __init__(self, app=None):
        self.app = app
        if app is not None:
            self.init_app(app)

    def init_app(self, app):
        # Load variables in .env
        env = DotEnv()
        env.init_app(app, env_file=self.PATH.joinpath(".env"))

        # Load cls parameters
        app.config.from_object(self)

        # Set SQLAlchemy binds

        dsn = """(DESCRIPTION = 
                      (FAILOVER = ON)                
                      (ADDRESS_LIST =              
                         (ADDRESS = (COMMUNITY = tcp.world) (PROTOCOL = TCP) (Host = racprod-front) (Port = 1521))
                         (ADDRESS = (COMMUNITY = tcp.world) (PROTOCOL = TCP) (Host = racstby-front) (Port = 1521))
                      )
                      (CONNECT_DATA = (SERVICE_NAME=DER_Flux_G)(SERVER = DEDICATED))
                   )"""

        # Activate if you need to use Integration connection
        # dsn = """(DESCRIPTION =
        #         (ADDRESS = (PROTOCOL = TCP)(HOST = racint1-front)(PORT = 1521))
        #         (CONNECT_DATA = (SERVICE_NAME = DER_Flux_G_int1)(SERVER = DEDICATED))
        # )"""

        names = ["risque", "analyse", "analyse_structuration", "derives", "contrib"]

        app.config["SQLALCHEMY_BINDS"] = {
            f"exane_{name}": f"{app.config.get(f'exane_{name}'.upper())}@{dsn}"
            for name in names
        }

        try:
            # Set logger
            formatter = logging.Formatter(
                "%(asctime)s %(levelname)s %(process)d ---- %(threadName)s  "
                "%(module)s : %(funcName)s {%(pathname)s:%(lineno)d} %(message)s",
                "%Y-%m-%dT%H:%M:%SZ",
            )

            folder_log = os.path.join(self.PATH, "logs")

            if not os.path.exists(folder_log):
                os.makedirs(folder_log)

            handler = RotatingFileHandler(
                filename=os.path.join(self.PATH, "logs/turfu.log"), maxBytes=2000,
            )
            handler.setFormatter(formatter)
            handler.setLevel(logging.DEBUG)
            app.logger.addHandler(handler)

        except:
            pass


engine = create_engine(Config.SQLALCHEMY_DATABASE_URI)

import datetime as dt

from dash import dcc
from sqlalchemy import func, or_

from utils.basics import dt_today
from utils.components import *
from dash import callback_context
from dash.dependencies import Input, Output, State
from dash.dash_table import DataTable

from flask_login import current_user
from local_db_mgt import ExcelFunction

from app import app, server, db


style_hidden = {"display": "none"}

colors = {"red": "#c0392b", "green": "#16a085"}

background_colors = {
    "red": "rgba(231, 76, 60, 0.1)",
    "green": "rgba(22, 160, 133, 0.1)",
    "blue": "rgba(52, 152, 219, 0.1)",
}

params = {
    "function": {"id": "function", "name": "Function", "type": "text",},
    "parameter": {"id": "parameter", "name": "Parameter", "type": "text",},
    "description": {"id": "description", "name": "Description", "type": "text",},
    "formula": {"id": "formula", "name": "Formula", "type": "text",},
    "output": {"id": "output", "name": "Result", "type": "text",},
    "datetime": {
        "id": "datetime",
        "name": "Date",
        "default": dt_today(),
        "type": "datetime",
    },
    "user": {"id": "user", "name": "Added by", "type": "text",},
}

style_data_conditional = [
    {"if": {"column_id": "function"}, "width": "70px", "maxWidth": "70px",},
    {"if": {"column_id": "parameter"}, "width": "100px", "maxWidth": "100px",},
    {"if": {"column_id": "description"}, "width": "285px", "maxWidth": "285px",},
    {"if": {"column_id": "formula"}, "width": "165px", "maxWidth": "1605px",},
    {"if": {"column_id": "output"}, "width": "320px", "maxWidth": "320px",},
    {
        "if": {"column_id": "datetime"},
        "width": "100px",
        "maxWidth": "100px",
        "paddingRight": "10px",
        "cursor": "not-allowed",
    },
    {
        "if": {"column_id": "user"},
        "width": "100px",
        "maxWidth": "100px",
        "cursor": "not-allowed",
    },
    {"if": {"column_id": "is_sent"}, "width": "80px", "maxWidth": "80px",},
    {
        "if": {"state": "active"},
        "backgroundColor": background_colors["blue"],
        "border": "none",
        "color": "rgb(44, 62, 80)",
        "border-top": "1px solid rgb(236, 240, 241)",
        "border-bottom": "1px solid rgb(236, 240, 241)",
    },
    {
        "if": {"state": "selected"},
        "backgroundColor": background_colors["blue"],
        "border-top": "1px solid rgb(236, 240, 241)",
        "border-bottom": "1px solid rgb(236, 240, 241)",
    },
]


def update_value_in_db(id: int, field, value):
    c = ExcelFunction.query.filter_by(id=id).first()

    if isinstance(value, str):
        value = value.strip().rstrip()

    if field == "is_sent":
        value = True if (value == "TRUE") else False

    if field == "datetime":
        if value:
            if isinstance(value, dt.datetime):
                value = value.date()
            if isinstance(value, str):
                value = dt.datetime.strptime(value, "%Y-%m-%d").date()
        else:
            value = dt_today()

    if field == "user":
        if not value:
            value = current_user.username

    setattr(c, field, value)
    db.session.commit()


def get_db_data(filter=None):
    try:
        if filter is not None and filter != "":
            filter = filter.lower()
            db_values = (
                ExcelFunction.query.filter(
                    or_(
                        func.lower(ExcelFunction.function).contains(filter),
                        func.lower(ExcelFunction.parameter).contains(filter),
                        func.lower(ExcelFunction.description).contains(filter),
                    )
                )
                .order_by(ExcelFunction.id.desc())
                .all()
            )
        else:
            db_values = ExcelFunction.query.order_by(ExcelFunction.id.desc()).all()
    except:
        try:
            ExcelFunction.__table__.create(db.session.bind)
            db_values = ExcelFunction.query.order_by(ExcelFunction.id.desc()).all()
        except Exception as e:
            server.logger.exception(e)
    finally:
        return [
            {
                "id": x.id,
                "function": x.function,
                "parameter": x.parameter,
                "description": x.description,
                "formula": x.formula,
                "output": x.output,
                "datetime": x.datetime.strftime("%Y-%m-%d"),
                "user": x.user,
            }
            for x in db_values
        ]


def new_excel_function(**kwargs):
    try:
        # Add the line in the database
        excel_function = ExcelFunction(user=current_user.username)

        # If user wants to set default elements for this new row
        for key, value in kwargs.items():
            if key not in ["datetime", "user", "is_sent"]:
                if value:
                    setattr(excel_function, key, value)

        # Add and Commit in internal database
        db.session.add(excel_function)
        db.session.commit()

        return excel_function

    except Exception as e:
        app.logger.exception(e)


df_modal = pd.DataFrame(columns=["Column 1", "Column 2"], index=[0, 1])

json_table_modal = df_modal.to_dict("records")

modal = dbc.Modal(
    [
        dbc.ModalHeader("Convert Table To JSON"),
        dbc.ModalBody(
            [
                dbc.Alert(
                    "Formula Copied To Clipboard",
                    color="success",
                    duration=3500,
                    id="excel-admin-copy-to-clipboard-alert",
                    fade=True,
                    is_open=False,
                ),
                html.I("Paste a table in the first cell and rename the columns"),
                html.Div(
                    DataTable(
                        columns=[
                            {"name": i, "id": i, "deletable": True, "renamable": True,}
                            for i in list(df_modal.columns)
                        ],
                        id="excel-admin-functions-table",
                        data=df_modal.to_dict("records"),
                        editable=True,
                        row_deletable=True,
                        include_headers_on_copy_paste=True,
                        style_data_conditional=style_data_conditional,
                        style_header={
                            "fontWeight": "bold",
                            "backgroundColor": "white",
                        },
                        style_cell={
                            # "overflow": "hidden",
                            "textOverflow": "ellipsis",
                            "minWidth": "0px",
                            "padding": "5px",
                            "font-family": "Roboto",
                            "font-size": "12px",
                            "text-align": "left",
                            "backgroundColor": "transparent",
                            "padding-top": "10px",
                            "padding-bottom": "10px",
                            "border-top": "0.1px solid rgb(240, 240, 240)",
                            "border-bottom": "0.1px solid rgb(240, 240, 240)",
                            "border-right": " 0px",
                            "border-left": "0px",
                        },
                    ),
                    id="excel-admin-functions-table-modal",
                ),
                html.Div(
                    children=[
                        html.P(f"JSON :", style={"display": "inline-block"},),
                        html.P(
                            f"{json_table_modal}",
                            style={
                                "display": "inline-block",
                                "margin-left": "10px",
                                "font-weight": "bold",
                            },
                            id="excel-admin-json-text-output",
                        ),
                        dbc.Button(
                            "Copy",
                            id="excel-admin-copy-json-button",
                            style={"display": "inline-block", "float": "right"},
                            className="ml-auto",
                        ),
                    ],
                    id="excel-admin-json-output-div",
                ),
            ],
        ),
    ],
    id="excel-admin-add-table-modal",
    size="xl",
    backdrop=True,
    centered=True,
    fade=True,
    is_open=False,
    keyboard=True,
    autoFocus=True,
)


def serve_layout(search=None):

    functions = get_db_data()

    return html.Div(
        [
            dcc.Location(
                id={"type": "url", "page": "excel_admin"}, search=search, refresh=False
            ),
            dbc.Container(
                [
                    dbc.Row(  # Row of the tile and Button
                        [
                            dbc.Col(
                                [
                                    html.H1("Excel Functions Documentation"),
                                    html.H4("(admin)"),
                                ],
                                align="center",
                                width=8,
                            ),
                            dbc.Col(
                                dbc.Input(
                                    id="excel-admin-functions-filter-keywords",
                                    type="text",
                                    debounce=True,
                                    placeholder="Filter by keywords...",
                                    value="",
                                ),
                            ),
                            dbc.Col(
                                [
                                    dbc.Button(
                                        children="Add Table",
                                        id="excel-admin-add-table-button",
                                        n_clicks=0,
                                    ),
                                    modal,
                                ],
                                style={"padding-right": "5px"},
                            ),
                            dbc.Col(
                                dbc.Button(
                                    children="Add Line",
                                    id="excel-admin-add-line-button",
                                    n_clicks=0,
                                ),
                            ),
                        ],
                        className="mb-4",
                    ),
                    dbc.Row(  # Row of the New Function
                        dbc.Col(
                            DataTable(
                                data=functions,
                                id="excel-admin-functions-table-function",
                                columns=[{**params[x]} for x in params],
                                hidden_columns=["id",],
                                dropdown={
                                    i: params[i]["dropdown"]
                                    for i in params
                                    if "dropdown" in params[i]
                                },
                                editable=True,
                                row_deletable=True,
                                style_header={
                                    "fontWeight": "bold",
                                    "backgroundColor": "white",
                                },
                                style_cell={
                                    "textOverflow": "ellipsis",
                                    "minWidth": "0px",
                                    "padding": "5px",
                                    "font-family": "Roboto",
                                    "font-size": "12px",
                                    "text-align": "left",
                                    "backgroundColor": "transparent",
                                    "padding-top": "10px",
                                    "padding-bottom": "10px",
                                    "border-top": "0.1px solid rgb(240, 240, 240)",
                                    "border-bottom": "0.1px solid rgb(240, 240, 240)",
                                    "border-right": " 0px",
                                    "border-left": "0px",
                                },
                                style_data_conditional=style_data_conditional,
                                tooltip_header={"function": "Exactly 3 characters",},
                                tooltip_delay=0,
                                tooltip_duration=40000,
                            ),
                        ),
                        className="mb-2",
                    ),
                ],
                fluid=True,
                style={"maxWidth": "90%"},
                className="borded-card p-5 mt-3 mb-5",
            ),
        ]
    )


@app.callback(
    Output("excel-admin-functions-table-function", "data"),
    Input("excel-admin-functions-table-function", "data_timestamp"),
    Input("excel-admin-add-line-button", "n_clicks"),
    Input("excel-admin-functions-filter-keywords", "value"),
    State("excel-admin-functions-table-function", "data"),
    State("excel-admin-functions-table-function", "data_previous"),
    prevent_initial_call=True,
)
def update_admin_table(time, n_click, keywords_filter, data_table, data_table_previous):
    ctx = callback_context
    triggered = ctx.triggered[0]["prop_id"].split(".")[0]

    # If admin filter by keywords
    if triggered == "excel-admin-functions-filter-keywords":
        return get_db_data(filter=keywords_filter)

    # If user wants to add a line in the first table
    if triggered == "excel-admin-add-line-button":
        # Insert new line in the database
        new_excel_function()

    # If any update in the table
    if triggered == "excel-admin-functions-table-function":
        # Check if a Row has been deleted
        if len(data_table) != len(data_table_previous):
            # Find which name has been deleted and update db
            for x in data_table_previous:
                if x not in data_table:
                    id_deleted = x["id"]
            # Delete the row in the database
            ExcelFunction.query.filter_by(id=id_deleted).delete()
            db.session.commit()
            return get_db_data()

    # If you are here, one or more cells have been updated
    # We compare the data in the table with the data in the database
    data_db = get_db_data()
    for i, data_row in enumerate(data_table):

        # Find the id and key of the new values
        if data_row != data_db[i]:
            id = data_row["id"]
            for key in data_row.keys():
                value = data_row[key]
                if value != data_db[i][key]:
                    # Update the database
                    update_value_in_db(id, key, value)

    # Return the database
    return get_db_data()


@app.callback(
    Output(component_id="excel-admin-json-text-output", component_property="children"),
    Output(component_id="excel-admin-json-output-div", component_property="style"),
    Output(component_id="excel-admin-add-table-modal", component_property="is_open"),
    Output(component_id="excel-admin-functions-table", component_property="data"),
    Output(component_id="excel-admin-functions-table", component_property="columns"),
    Input(component_id="excel-admin-functions-table", component_property="data"),
    Input(component_id="excel-admin-functions-table", component_property="columns"),
    Input(component_id="excel-admin-add-table-button", component_property="n_clicks"),
    State(component_id="excel-admin-add-table-modal", component_property="is_open"),
    State(component_id="excel-admin-functions-table", component_property="data"),
    State(component_id="excel-admin-functions-table", component_property="columns"),
    prevent_initial_call=True,
)
def toggle_admin_modal(data_input, columns_input, open_modal, is_open, data, columns):
    # Parse Trigger
    ctx = callback_context
    trigger = ctx.triggered[0]["prop_id"].split(".")[0]

    # If Add Table Button Clicked Create Empty Table
    if trigger == "excel-admin-add-table-button":
        df = pd.DataFrame(index=[0, 1], columns=["Column 1", "Column 2"])
        json_table = df.to_dict("records")
        columns = [
            {"name": i, "id": i, "deletable": True, "renamable": True,}
            for i in list(df.columns)
        ]
    # Else Retrieve Table
    else:
        columns_name = [column.get("name") for column in columns]
        df = pd.DataFrame(data)
        df.columns = columns_name
        json_table = df.to_dict("records")
        columns = [
            {"name": i, "id": i, "deletable": True, "renamable": True,}
            for i in list(df.columns)
        ]

    # Set Json Paragraph
    children = [f"{json_table}"]

    # If Not Empty Table Display JSON & Copy Button
    if (
        str(json_table)
        != "[{'Column 1': nan, 'Column 2': nan}, {'Column 1': nan, 'Column 2': nan}]"
    ):
        style = {"margin-top": "20px", "display": "block"}
    # Else Hide Them
    else:
        style = {"margin-top": "0px", "display": "none"}

    if trigger in ["excel-admin-add-table-button", "excel-admin-functions-table"]:
        return [children, style, True, json_table, columns]
    else:
        return [children, style, False, json_table, columns]


# Copy From Store To Clipboard (admin)
app.clientside_callback(
    """
    function(click, json_table) {
        var dummy = document.createElement("textarea");
        document.body.appendChild(dummy);
        dummy.value = json_table;
        dummy.select();
        document.execCommand("copy");
        document.body.removeChild(dummy);
        return true;
    }
    """,
    Output(
        component_id="excel-admin-copy-to-clipboard-alert", component_property="is_open"
    ),
    Input(component_id="excel-admin-copy-json-button", component_property="n_clicks"),
    State(component_id="excel-admin-json-text-output", component_property="children"),
    prevent_initial_call=True,
)

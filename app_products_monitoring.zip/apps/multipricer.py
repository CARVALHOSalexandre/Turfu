from dash.dependencies import Input, Output, State, ALL, MATCH
import dash_extensions as de
from dash import dcc
from dash.dash_table.Format import Format, Group, Scheme, Symbol
from flask_login import current_user

import dash
import uuid
import json
import itertools
from pandas import NaT

from sqlalchemy import and_, or_

from multipricer.models.base_multipricer import *
from utils.components import *
from utils.basics import *
from utils.api_sg import cached_sg_underlying_universe, SGPricer
from utils.api_barclays import BarclaysPricer
from dash.dash_table import DataTable

from multipricer.issuers import (
    leonteq,
    morgan_stanley,
    jp_morgan,
    bbva,
    goldman_sachs,
    societe_generale,
    barclays,
    bnp,
    cacib,
    bnp_mail,
)


from app import app, server
from local_db_mgt import Issuers, User
from utils.exceptions import ApiPricingConnectionError


def custom_trigger(maturity, frequency, nc_periods, barrier, step, floor):
    frequency_nb_months = (
        Frequencies.query.filter(Frequencies.id == frequency).first().nb_months
    )
    nb_obs = int(maturity / frequency_nb_months - nc_periods)
    obs = [barrier]
    for i in range(1, nb_obs):
        if obs[i - 1] + step >= floor:
            obs.append(obs[i - 1] + step)
        else:
            obs.append(obs[i - 1])

    return "-".join(list(map(str, obs)))


def create_card_request(data):
    # Load Request Result Table
    df_results = pd.DataFrame(
        db.session.query(
            PricingResults.id_issuer,
            PricingResults.id_quote,
            PricingResults.id_line,
            PricingResults.timestamp_received,
            PricingResults.result,
            PricingResults.tickers_ccy,
            PricingResults.is_best_result,
            PricingResults.is_error,
        )
        .filter(PricingResults.id_request_email == data.get("id_request_email"))
        .filter(PricingResults.comments == None)
        .all()
    )

    if df_results.empty:
        return []
    else:
        df_results["issuer"] = df_results["id_issuer"].apply(
            lambda x: Issuers.query.filter(Issuers.id == x).first().short_name
        )
        df_results = df_results.rename(
            columns={
                "timestamp_received": "Received At",
                "result": "Result",
                "issuer": "Issuer",
                "is_best_result": "Best Result?",
                "is_error": "Error?",
                "id_quote": "Quote ID",
                "id_line": "Line",
                "tickers_ccy": "Tickers (Ccy)",
            }
        )

        # Reformat DataFrame
        df_results = df_results.drop(columns=["id_issuer"])

        # Split DataFrames Per Issuer
        issuers = df_results["Issuer"].unique()
        table_list = []
        for issuer in issuers:
            link_text = ""
            link_href = ""
            if issuer in ["SG", "BBVA", "GS", "Barclays"]:
                link_text = f"Open {issuer} Pricer"
                if issuer == "SG":
                    link_href = "https://sp.sgmarkets.com/#/quote-blotter"
                elif issuer == "BBVA":
                    link_href = "https://bbvaepricer.equity-connect.com/FinIQWebApp/FinIQ_Connect/#/PreviousQuotes"
                elif issuer == "GS":
                    link_href = "https://marquee.gs.com/s/structured-products/discovery"
                elif issuer == "Barclays":
                    link_href = "https://live.barcap.com/UAB/S/ecom/logon/1/barxis?returnUrl=https%3a%2f%2fbarxis.barcap.com%2fCH%2f2%2fen%2ftrading%2fcomet-refresh%2fcomet-ui.app"
            dff = df_results[df_results["Issuer"] == issuer]
            dff = dff.drop(columns=["Issuer"])
            dff = dff[
                [
                    "Line",
                    "Tickers (Ccy)",
                    "Received At",
                    "Quote ID",
                    "Result",
                    "Best Result?",
                    "Error?",
                ]
            ]
            dff["Best Result?"] = dff["Best Result?"].apply(lambda x: None if x else x)
            dff["Error?"] = dff["Error?"].apply(lambda x: None if x else x)
            dff["Received At"] = dff["Received At"].apply(
                lambda x: x.strftime("%Hh%M") if x not in [NaT, None, "", " ",] else x
            )
            tab_style_cell_conditional = [
                {
                    "if": {"state": "selected"},
                    "backgroundColor": "inherit !important",
                    "border": "1px solid blue",
                },
                {"if": {"column_id": "Line"}, "width": "8%"},
                {"if": {"column_id": "Tickers (Ccy)"}, "width": "24%"},
                {"if": {"column_id": "Received At"}, "width": "8%"},
                {"if": {"column_id": "Quote ID"}, "width": "30%"},
                {"if": {"column_id": "Result"}, "width": "30%"},
            ]
            tab_style_data_conditional = [
                {
                    "if": {
                        "filter_query": "{Best Result?} is blank",
                        "column_id": "Result",
                    },
                    "color": "darkgreen",
                    "fontWeight": "bold",
                },
                {
                    "if": {"filter_query": "{Error?} is blank", "column_id": "Result",},
                    "color": "red",
                    "fontWeight": "bold",
                },
            ]
            result_table = DataTable(
                id="multipricer-result-table",
                data=dff.to_dict("records"),
                columns=[{"id": x, "name": x} for x in dff.columns],
                style_cell_conditional=tab_style_cell_conditional,
                style_data_conditional=tab_style_data_conditional,
                hidden_columns=["Best Result?", "Error?"],
            )
            table_list.append(
                dbc.Col(
                    dbc.Row(
                        [
                            dbc.Col(
                                html.H5(issuer),
                                className="mt-4",
                                align="center",
                                width="auto",
                            ),
                            dbc.Col(
                                dcc.Link(link_text, href=link_href, target="_blank"),
                                className="mt-4",
                                align="center",
                                width="auto",
                            ),
                        ],
                        justify="between",
                    ),
                    width=12,
                )
            )
            table_list.append(dbc.Col(result_table, width=12))

        return dbc.Row(
            [
                dbc.Col(
                    dbc.Row(
                        [
                            dbc.Col(
                                card_title(data.get("id_request_email")), width="auto"
                            ),
                            dbc.Col(
                                [
                                    html.Div(
                                        html.H3(
                                            "...",
                                            id=f"multipricer-popover-{data.get('id_request_email')}",
                                        ),
                                        id=f"multipricer-popover-wrapper-{data.get('id_request_email')}",
                                    ),
                                    dbc.Tooltip(
                                        dbc.Row(
                                            [
                                                dbc.Col(
                                                    dbc.Button(
                                                        "Load",
                                                        id={
                                                            "type": "multipricer-load-button",
                                                            "index": data.get(
                                                                "id_request_email"
                                                            ),
                                                        },
                                                        size="sm",
                                                        color="secondary",
                                                    ),
                                                    width="auto",
                                                ),
                                                dbc.Col(
                                                    dbc.Button(
                                                        "Delete",
                                                        id={
                                                            "type": "multipricer-delete-button",
                                                            "index": data.get(
                                                                "id_request_email"
                                                            ),
                                                        },
                                                        size="sm",
                                                        color="secondary",
                                                    ),
                                                    width="auto",
                                                ),
                                            ]
                                        ),
                                        target=f"multipricer-popover-wrapper-{data.get('id_request_email')}",
                                        placement="bottom",
                                        # autohide=False,
                                        delay={"show": 250, "hide": 400,},
                                    ),
                                ],
                                width="auto",
                                className="text-right",
                            ),
                        ],
                        justify="between",
                    )
                ),
                dbc.Col(
                    dbc.Row(
                        [
                            dbc.Col(
                                html.Div(
                                    [
                                        html.P(
                                            "Product:", style={"padding-right": "5px"},
                                        ),
                                        html.P(
                                            f"{data.get('product')}",
                                            style={
                                                "font-weight": "bold",
                                                "padding-right": "12px",
                                            },
                                        ),
                                        html.P(
                                            "Wrapper:", style={"padding-right": "5px"}
                                        ),
                                        html.P(
                                            f"{data.get('wrapper')}",
                                            style={
                                                "font-weight": "bold",
                                                "padding-right": "12px",
                                            },
                                        ),
                                        html.P(
                                            "Solving For:",
                                            style={"padding-right": "5px"},
                                        ),
                                        html.P(
                                            f"{data.get('solve_for')}",
                                            style={
                                                "font-weight": "bold",
                                                "padding-right": "12px",
                                            },
                                        ),
                                        html.P(
                                            "Author:", style={"padding-right": "5px"}
                                        ),
                                        html.P(
                                            f"{data.get('user').split(' ')[0]}",
                                            style={
                                                "font-weight": "bold",
                                                "padding-right": "12px",
                                            },
                                        ),
                                    ],
                                    style={"display": "flex"},
                                ),
                                width="auto",
                            ),
                            dbc.Col(
                                [
                                    html.H6(
                                        data.get("timestamp").strftime("%b %d, %Y"),
                                        className="mb-0",
                                    ),
                                    html.H6(
                                        pd.to_datetime(data.get("timestamp")).strftime(
                                            "%Hh%M"
                                        )
                                    ),
                                ],
                                width="auto",
                                className="align-right text-right",
                            ),
                        ],
                        justify="between",
                    ),
                    width=12,
                ),
            ]
            + table_list
            # Hidden Components
            + [
                dbc.Col(
                    html.Div(
                        data.get("id_request_email"),
                        id={
                            "type": "multipricer-card-hidden-div",
                            "index": data.get("id_request_email"),
                        },
                        style={"display": "none"},
                    ),
                    width=12,
                ),
                dbc.Col(
                    html.Div(
                        id={
                            "type": "multipricer-card-hidden-div-2",
                            "index": data.get("id_request_email"),
                        },
                        style={"display": "none"},
                    ),
                    width=12,
                ),
                dbc.Toast(
                    id={
                        "type": "multipricer-card-toast",
                        "index": data.get("id_request_email"),
                    },
                    is_open=False,
                    dismissable=True,
                    icon="success",
                    headerClassName="home-notif-header",
                    bodyClassName="home-notif-body",
                    className="home-notif-toast",
                    duration=5000,
                ),
            ],
            className="borded-card p-3 pb-1 m-2 mb-3",
        )


def send_rfq(request_id, issuer_id):
    # Retrieve Request Data
    df = pd.DataFrame(
        db.session.query(
            PricingRequests.id,
            PricingRequests.id_protection_type,
            PricingRequests.id_product,
            PricingRequests.id_barrier_type,
            PricingRequests.id_currency,
            PricingRequests.id_wrapper,
            PricingRequests.id_frequency,
            PricingRequests.id_solve_for,
            PricingRequests.id_user,
            PricingRequests.id_issuer,
            PricingRequests.id_request,
            PricingRequests.id_request_email,
            PricingRequests.offer_price,
            PricingRequests.months_to_maturity,
            PricingRequests.barrier_strike,
            PricingRequests.barrier_level,
            PricingRequests.coupon_level,
            PricingRequests.coupon_barrier,
            PricingRequests.autocall_barrier,
            PricingRequests.autocall_start_period,
            PricingRequests.notional,
            PricingRequests.funding_spread,
            PricingRequests.is_memory,
            PricingRequests.is_live,
            PricingRequests.timestamp,
            PricingRequests.ticker_1,
            PricingRequests.ticker_2,
            PricingRequests.ticker_3,
            PricingRequests.ticker_4,
            PricingRequests.ticker_5,
        )
        .filter(
            and_(
                PricingRequests.id_request_email == request_id,
                PricingRequests.id_issuer == issuer_id,
            )
        )
        .all()
    )

    # Reformat Barrier Type Column
    df["id_barrier_type"].fillna(4)
    df["id_barrier_type"].astype(int)

    # Mail Pricer -- > Send Mail
    if issuer_id in [2, 3, 4, 8, 9, 10, 12]:

        # Set Issuer Request Table Format
        if issuer_id == 10:
            mail_pricer = leonteq.MailPricingLTQ()
        elif issuer_id == 12:
            mail_pricer = morgan_stanley.MailPricingMS()
        elif issuer_id == 9:
            mail_pricer = jp_morgan.MailPricingJPM()
        elif issuer_id == 2:
            mail_pricer = bbva.MailPricingBBVA()
        elif issuer_id == 8:
            mail_pricer = goldman_sachs.MailPricingGS()
        elif issuer_id == 4:
            mail_pricer = cacib.MailPricingCACIB()
        elif issuer_id == 3:
            mail_pricer = bnp_mail.MailPricingBNP()
        else:
            msg = f"{Issuers.query.filter(Issuers.id == issuer_id).first().short_name} not available"
            return msg

        mail_pricer.sender = "exane.structuring@exane.com"
        mail_pricer.data = mail_pricer.to_issuer_format(df)
        mail_pricer.subject = f"Exane | {Issuers.query.filter(Issuers.id == issuer_id).first().short_name} | {request_id}"
        mail_pricer.send_mail()
        return None

    # API Pricer --> Send Request
    else:
        # Get underlying universe
        tickers_list = (
            list(df["ticker_1"])
            + list(df["ticker_2"])
            + list(df["ticker_3"])
            + list(df["ticker_4"])
            + list(df["ticker_5"])
        )
        tickers_list = [i for i in list(set(tickers_list)) if i]
        tickers_df = pd.DataFrame(data=tickers_list, columns=["ticker"])

        # Set corresponding pricer
        if issuer_id == 1:
            api_pricer = BarclaysPricer()
            set_template = barclays.set_template
        elif issuer_id == 15:
            api_pricer = SGPricer()
            set_template = societe_generale.set_template
        else:
            msg = f"{Issuers.query.filter(Issuers.id == issuer_id).first().short_name} not available"
            return msg

        # Setting The Tickers Universe
        tickers_api = api_pricer.corresponding_tickers(tickers_list)
        tickers_df = pd.merge(tickers_df, tickers_api, on="ticker", how="outer")

        # Send Each Request
        for i in range(0, len(df)):
            dff = df.iloc[[i]]
            data = set_template(dff.to_dict(orient="records")[0], tickers_df)
            [quote_id, error_msg] = api_pricer.post_price_request(data)
            if quote_id:
                db.session.query(PricingResults).filter(
                    PricingResults.id_request == df.iloc[i].loc["id_request"]
                ).update({"id_quote": quote_id})
                db.session.commit()
            else:
                db.session.query(PricingResults).filter(
                    PricingResults.id_request == df.iloc[i].loc["id_request"]
                ).update({"is_error": True, "result": error_msg})
                db.session.commit()
        return None


def create_rfq(issuers, df, is_live, user_id, solve_for):
    # Set Email Request ID
    id_request_email = str(uuid.uuid4())
    result = []
    # For Each Issuer
    for issuer in issuers:
        # Set Issuer ID
        id_issuer = Issuers.query.filter(Issuers.short_name == issuer).first().id
        # For Each Line In Multi Pricer
        for i in range(0, len(df.index)):
            # Convert Memory To Boolean
            if df.iloc[i].loc["Memory"] == "Yes":
                is_memory = True
            else:
                is_memory = False
            # Store RFQ
            df["Tickers (Ccy)"] = df["Ticker 1"]
            df["Tickers (Ccy)"] = df.apply(
                lambda x: x["Tickers (Ccy)"] + " - " + x["Ticker 2"]
                if x["Ticker 2"]
                else x["Tickers (Ccy)"],
                axis=1,
            )
            df["Tickers (Ccy)"] = df.apply(
                lambda x: x["Tickers (Ccy)"] + " - " + x["Ticker 3"]
                if x["Ticker 3"]
                else x["Tickers (Ccy)"],
                axis=1,
            )
            df["Tickers (Ccy)"] = df.apply(
                lambda x: x["Tickers (Ccy)"] + " - " + x["Ticker 4"]
                if x["Ticker 4"]
                else x["Tickers (Ccy)"],
                axis=1,
            )
            df["Tickers (Ccy)"] = df.apply(
                lambda x: x["Tickers (Ccy)"] + " - " + x["Ticker 5"]
                if x["Ticker 5"]
                else x["Tickers (Ccy)"],
                axis=1,
            )
            df["Tickers (Ccy)"] = df.apply(
                lambda x: f"{x['Tickers (Ccy)']} ({x['Currency']})", axis=1
            )
            params = dict(
                id_protection_type=ProtectionTypes.query.filter(
                    ProtectionTypes.type == df.iloc[i].loc["Type"]
                )
                .first()
                .id,
                id_product=Products.query.filter(
                    Products.name == df.iloc[i].loc["Product"]
                )
                .first()
                .id,
                id_barrier_type=(
                    BarrierTypes.query.filter(
                        BarrierTypes.type == df.iloc[i].loc["Barrier Type"]
                    )
                    .first()
                    .id
                )
                if df.iloc[i].loc["Barrier Type"] is not None
                else 4,
                id_currency=Currencies.query.filter(
                    Currencies.code == df.iloc[i].loc["Currency"]
                )
                .first()
                .id,
                id_wrapper=Wrappers.query.filter(
                    Wrappers.name == df.iloc[i].loc["Wrapper"]
                )
                .first()
                .id,
                id_solve_for=SolveFor.query.filter(SolveFor.code == solve_for)
                .first()
                .id,
                id_frequency=Frequencies.query.filter(
                    Frequencies.code == df.iloc[i].loc["Frequency"]
                )
                .first()
                .id,
                id_user=user_id,
                id_issuer=id_issuer,
                id_line=i + 1,
                id_request=str(uuid.uuid4()),
                id_request_email=id_request_email,
                offer_price=df.iloc[i].loc["Reoffer / UF"],
                months_to_maturity=int(df.iloc[i].loc["Maturity"]),
                barrier_strike=df.iloc[i].loc["Strike"],
                barrier_level=df.iloc[i].loc["Barrier"],
                coupon_level=df.iloc[i].loc["Cpn (p.a)"],
                coupon_barrier=df.iloc[i].loc["Cpn Trigger"],
                autocall_barrier=(
                    df.iloc[i].loc["AC Trigger"][0:-2]
                    if df.iloc[i].loc["AC Trigger"] is not None
                    else None
                ),
                autocall_start_period=(
                    int(df.iloc[i].loc["NC Periods"]) + 1
                    if df.iloc[i].loc["NC Periods"] is not None
                    else None
                ),
                notional=int(df.iloc[i].loc["Notional"]),
                funding_spread=df.iloc[i].loc["Funding"],
                is_memory=is_memory,
                is_live=is_live,
                is_auto=False,
                comments=None,
                timestamp=datetime.datetime.now(),
                ticker_1=df.iloc[i].loc["Ticker 1"].upper()
                if df.iloc[i].loc["Ticker 1"]
                else df.iloc[i].loc["Ticker 1"],
                ticker_2=df.iloc[i].loc["Ticker 2"].upper()
                if df.iloc[i].loc["Ticker 2"]
                else df.iloc[i].loc["Ticker 2"],
                ticker_3=df.iloc[i].loc["Ticker 3"].upper()
                if df.iloc[i].loc["Ticker 3"]
                else df.iloc[i].loc["Ticker 3"],
                ticker_4=df.iloc[i].loc["Ticker 4"].upper()
                if df.iloc[i].loc["Ticker 4"]
                else df.iloc[i].loc["Ticker 4"],
                ticker_5=df.iloc[i].loc["Ticker 5"].upper()
                if df.iloc[i].loc["Ticker 5"]
                else df.iloc[i].loc["Ticker 5"],
                tickers_ccy=df.iloc[i].loc["Tickers (Ccy)"].upper(),
            )
            insert_request(params)
        # Send RFQ
        try:
            result.append(send_rfq(id_request_email, id_issuer))
        except Exception as e:
            server.logger.exception(f"Error Sending Request To {issuer} | {e}")
            result.append(f"Issue with {issuer}")
    return result


def trigger_format_checked(trigger, maturity, frequency, nb_non_call_periods):
    try:
        if nb_non_call_periods in [None, "", " "]:
            nb_non_call_periods = 0
        if trigger is not None:
            if "-" in trigger:
                trigger_list = trigger.split("-")
                frequency_months = (
                    Frequencies.query.filter(Frequencies.code == frequency)
                    .first()
                    .nb_months
                )
                if maturity / frequency_months - nb_non_call_periods == len(
                    trigger_list
                ):
                    return True
                else:
                    return False
            else:
                return True
        else:
            return False
    except Exception as e:
        return False


def change_table_input(df, dropdown):
    if len(dropdown) > 0:
        df["Ticker 1"] = dropdown[0]
    if len(dropdown) > 1:
        df["Ticker 2"] = dropdown[1]
    if len(dropdown) > 2:
        df["Ticker 3"] = dropdown[2]
    if len(dropdown) > 3:
        df["Ticker 4"] = dropdown[3]
    if len(dropdown) > 4:
        df["Ticker 5"] = dropdown[4]

    # Allow for copy-paste from Excel cells by suppressing "carriage return"
    df[["Ticker 1", "Ticker 2", "Ticker 3", "Ticker 4", "Ticker 5"]] = df[
        ["Ticker 1", "Ticker 2", "Ticker 3", "Ticker 4", "Ticker 5"]
    ].applymap(lambda x: x.replace("\r", "") if x else None,)

    df["AC Trigger"] = df["AC Trigger"].apply(
        lambda x: x[0:-1] if x not in [None, "", " "] and x[-1] == "-" else x
    )
    df["AC Trigger"] = df["AC Trigger"].apply(
        lambda x: (
            f"{x.split(' %')[0]} %" if x.split(" %")[0] not in ["N/A", "", " ",] else x
        )
        if x is not None
        else x
    )
    df = df.replace({"": None, " ": None, "N/A": None})
    df["Cpn (p.a)"] = df["Cpn (p.a)"].replace({0: None})
    df["Reoffer / UF"] = df["Reoffer / UF"].replace({0: None})
    for i in range(0, len(df.index)):
        if df.iloc[i].loc["Wrapper"] == "Note":
            df.at[i, "Funding"] = None
        if df.iloc[i].loc["Type"] == "Low Strike":
            df.at[i, "Barrier Type"] = None
            df.at[i, "Barrier"] = None
        if df.iloc[i].loc["Product"] == "Reverse Convertible":
            df.at[i, "AC Trigger"] = None
            df.at[i, "NC Periods"] = None
            df.at[i, "Cpn Trigger"] = None
            df.at[i, "Memory"] = None
    return df


def solve_for_msg(df):
    msg = []
    for i in range(0, len(df.index)):
        if df.iloc[i].loc["Cpn (p.a)"] in [None, "", " "] and df.iloc[i].loc[
            "Reoffer / UF"
        ] in [None, "", " "]:
            msg = ["UNDEFINED"]
            break
        elif df.iloc[i].loc["Cpn (p.a)"] in [None, "", " "] and df.iloc[i].loc[
            "Reoffer / UF"
        ] not in [None, "", " ",]:
            if "UPFRONT" in msg or "REOFFER" in msg:
                msg = ["UNDEFINED"]
                break
            else:
                msg.append("COUPON")
        elif df.iloc[i].loc["Cpn (p.a)"] not in [None, "", " "] and df.iloc[i].loc[
            "Reoffer / UF"
        ] in [None, "", " ",]:
            if "COUPON" in msg:
                msg = ["UNDEFINED"]
                break
            else:
                if df.iloc[i].loc["Wrapper"] == "Swap":
                    msg.append("UPFRONT")
                else:
                    msg.append("REOFFER")
    if len(msg) == 0:
        msg = ["UNDEFINED"]
    return msg[0]


def check_table_is_completed(df, msg):
    table_completed = True
    tooltip_msg = "Table filled correctly"
    if len(df["Wrapper"].unique()) > 1:
        table_completed = False
        tooltip_msg = "2 Wrappers selected"
    elif len(df["Product"].unique()) > 1:
        table_completed = False
        tooltip_msg = "2 Product selected"
    elif msg == "UNDEFINED":
        table_completed = False
        tooltip_msg = "Undefined Solving For"
    else:
        for i in range(0, len(df.index)):

            if df.iloc[i].loc["Product"] in [None, "", " "]:
                table_completed = False
                tooltip_msg = "Missing Product"
                break

            if df.iloc[i].loc["Wrapper"] in [None, "", " "]:
                table_completed = False
                tooltip_msg = "Missing Wrapper"
                break

            if df.iloc[i].loc["Notional"] in [None, "", " "]:
                table_completed = False
                tooltip_msg = "Missing Notional"
                break

            if df.iloc[i].loc["Notional"] < 200000:
                table_completed = False
                tooltip_msg = "Notional Too Low"
                break

            if df.iloc[i].loc["Currency"] in [None, "", " "]:
                table_completed = False
                tooltip_msg = "Missing Currency"
                break

            if df.iloc[i].loc["Maturity"] in [None, "", " "]:
                table_completed = False
                tooltip_msg = "Missing Maturity"
                break

            if df.iloc[i].loc["Maturity"] < 3:
                table_completed = False
                tooltip_msg = "Maturity Too Low"
                break

            if df.iloc[i].loc["Maturity"] > 120:
                table_completed = False
                tooltip_msg = "Maturity Too High"
                break

            if df.iloc[i].loc["Frequency"] in [None, "", " "]:
                table_completed = False
                tooltip_msg = "Missing Frequency"
                break

            if df.iloc[i].loc["Ticker 1"] in [None, "", " "]:
                table_completed = False
                tooltip_msg = "Missing Ticker"
                break

            if df.iloc[i].loc["Type"] in [None, "", " "]:
                table_completed = False
                tooltip_msg = "Missing Protection Type"
                break

            if df.iloc[i].loc["Strike"] in [None, "", " "]:
                table_completed = False
                tooltip_msg = "Missing Protection Strike"
                break

            if df.iloc[i].loc["Strike"] < 50:
                table_completed = False
                tooltip_msg = "Protection Strike Too Low"
                break

            if df.iloc[i].loc["Strike"] > 100:
                table_completed = False
                tooltip_msg = "Protection Strike Too High"
                break

            if (
                df.iloc[i].loc["Reoffer / UF"] in [None, "", " ", 0]
                and df.iloc[i].loc["Cpn (p.a)"] <= 0
            ):
                table_completed = False
                tooltip_msg = "Cpn (p.a) Too Low"
                break

            if (
                df.iloc[i].loc["Reoffer / UF"] in [None, "", " ", 0]
                and df.iloc[i].loc["Cpn (p.a)"] > 50
            ):
                table_completed = False
                tooltip_msg = "Cpn (p.a) Too High"
                break

            if df.iloc[i].loc["Product"] == "Autocall":

                if df.iloc[i].loc["AC Trigger"] in [None, "", " "]:
                    table_completed = False
                    tooltip_msg = "Missing AC Trigger"
                    break

                if "%" in df.iloc[i].loc["AC Trigger"]:
                    df.at[i, "AC Trigger"] = df.iloc[i].loc["AC Trigger"][0:-2]

                if (
                    "-" not in df.iloc[i].loc["AC Trigger"]
                    and float(df.iloc[i].loc["AC Trigger"]) < 80
                ):
                    table_completed = False
                    tooltip_msg = "AC Trigger Too Low"
                    break

                if (
                    "-" not in df.iloc[i].loc["AC Trigger"]
                    and float(df.iloc[i].loc["AC Trigger"]) > 120
                ):
                    table_completed = False
                    tooltip_msg = "AC Trigger Too High"
                    break

                if df.iloc[i].loc["NC Periods"] is None:
                    table_completed = False
                    tooltip_msg = "NC Periods Empty"
                    break

                if df.iloc[i].loc["NC Periods"] < 0:
                    table_completed = False
                    tooltip_msg = "NC Periods Too Low"
                    break

                if (
                    df.iloc[i].loc["NC Periods"]
                    >= df.iloc[i].loc["Maturity"]
                    / Frequencies.query.filter(
                        Frequencies.code == df.iloc[i].loc["Frequency"]
                    )
                    .first()
                    .nb_months
                ):
                    table_completed = False
                    tooltip_msg = "NC Periods Too High"
                    break

                if df.iloc[i].loc["Cpn Trigger"] in [None, "", " "]:
                    table_completed = False
                    tooltip_msg = "Missing Cpn Trigger"
                    break

                if df.iloc[i].loc["Cpn Trigger"] < 0:
                    table_completed = False
                    tooltip_msg = "Cpn Trigger Too Low"
                    break

                if df.iloc[i].loc["Cpn Trigger"] > 100:
                    table_completed = False
                    tooltip_msg = "Cpn Trigger Too High"
                    break

                if df.iloc[i].loc["Memory"] in [None, "", " "]:
                    table_completed = False
                    tooltip_msg = "Missing Coupon Memory"
                    break

                if (
                    trigger_format_checked(
                        df.iloc[i].loc["AC Trigger"],
                        df.iloc[i].loc["Maturity"],
                        df.iloc[i].loc["Frequency"],
                        df.iloc[i].loc["NC Periods"],
                    )
                    is False
                ):
                    table_completed = False
                    tooltip_msg = "Invalid AC Trigger"
                    break

            if df.iloc[i].loc["Wrapper"] == "Swap" and df.iloc[i].loc["Funding"] in [
                None,
                "",
                " ",
            ]:
                table_completed = False
                tooltip_msg = "Missing Funding"
                break

            if (
                df.iloc[i].loc["Wrapper"] == "Swap"
                and df.iloc[i].loc["Reoffer / UF"] not in [None, "", " "]
                and df.iloc[i].loc["Reoffer / UF"] > 50
            ):
                table_completed = False
                tooltip_msg = "Upfront Too High"
                break

            if (
                df.iloc[i].loc["Wrapper"] == "Swap"
                and df.iloc[i].loc["Reoffer / UF"] not in [None, "", " "]
                and df.iloc[i].loc["Reoffer / UF"] < 0
            ):
                table_completed = False
                tooltip_msg = "Upfront Too Low"
                break

            if (
                df.iloc[i].loc["Reoffer / UF"] not in [None, "", " "]
                and df.iloc[i].loc["Wrapper"] == "Swap"
                and df.iloc[i].loc["Reoffer / UF"] > 50
            ):
                table_completed = False
                tooltip_msg = "Upfront Too High"
                break

            if (
                df.iloc[i].loc["Reoffer / UF"] not in [None, "", " "]
                and df.iloc[i].loc["Wrapper"] == "Note"
                and df.iloc[i].loc["Reoffer / UF"] < 50
            ):
                tooltip_msg = "Reoffer Too Low"
                table_completed = False
                break

            if (
                df.iloc[i].loc["Reoffer / UF"] not in [None, "", " "]
                and df.iloc[i].loc["Wrapper"] == "Note"
                and df.iloc[i].loc["Reoffer / UF"] > 100
            ):
                tooltip_msg = "Reoffer Too High"
                table_completed = False
                break

            if df.iloc[i].loc["Type"] == "PDI" and df.iloc[i].loc["Barrier Type"] in [
                None,
                "",
                " ",
            ]:
                table_completed = False
                tooltip_msg = "Missing Barrier Type"
                break

            if df.iloc[i].loc["Type"] == "PDI" and df.iloc[i].loc["Barrier"] in [
                None,
                "",
                " ",
            ]:
                table_completed = False
                tooltip_msg = "Missing Barrier"
                break

    return table_completed, tooltip_msg


def shuffle_lottie():
    return de.Lottie(
        options=dict(
            loop=False,
            autoplay=False,
            rendererSettings=dict(preserveAspectRatio="xMidYMid slice"),
        ),
        width=27,
        height=27,
        isStopped=True,
        id="multipricer-shuffle-lottie",
        url=f"/lottie/script-eye.json",
    )


def multipricer_table():
    tab_style_cell = {
        "textOverflow": "ellipsis",
        "font-family": "Roboto",
        "font-size": "12px",
        "textAlign": "center",
    }

    tab_style_cell_conditional = [
        {"if": {"column_id": "Product"}, "width": "149px"},
        {"if": {"column_id": "Wrapper"}, "width": "95px"},
        {"if": {"column_id": "Funding"}, "width": "55px"},
        {"if": {"column_id": "Notional"}, "width": "65px"},
        {"if": {"column_id": "Currency"}, "width": "74px"},
        {"if": {"column_id": "Maturity"}, "width": "69px"},
        {"if": {"column_id": "Frequency"}, "width": "115px"},
        {"if": {"column_id": "Offer / UF"}, "width": "71px"},
        {"if": {"column_id": "Ticker 1"}, "width": "55px"},
        {"if": {"column_id": "Ticker 2"}, "width": "55px"},
        {"if": {"column_id": "Ticker 3"}, "width": "55px"},
        {"if": {"column_id": "Ticker 4"}, "width": "55px"},
        {"if": {"column_id": "Ticker 5"}, "width": "55px"},
        {"if": {"column_id": "AC Trigger"}, "width": "110px"},
        {"if": {"column_id": "NC Periods"}, "width": "75px"},
        {"if": {"column_id": "Cpn Trigger"}, "width": "104px"},
        {"if": {"column_id": "Cpn (p.a)"}, "width": "55px"},
        {"if": {"column_id": "Memory"}, "width": "83px"},
        {"if": {"column_id": "Type"}, "width": "106px"},
        {"if": {"column_id": "Barrier Type"}, "width": "154px"},
        {"if": {"column_id": "Strike"}, "width": "45px"},
        {"if": {"column_id": "Barrier"}, "width": "45px"},
        {
            "if": {"state": "selected"},  # 'active' | 'selected'
            "backgroundColor": "rgba(0, 116, 217, 0.3)",
            "border": "1px solid blue",
        },
    ]

    tab_style_data_conditional = [
        {
            "if": {
                "filter_query": "{Product} = 'Reverse Convertible'",
                "column_id": "AC Trigger",
            },
            "backgroundColor": "rgba(218, 223, 225, 1)",
        },
        {
            "if": {
                "filter_query": "{Product} = 'Reverse Convertible'",
                "column_id": "NC Periods",
            },
            "backgroundColor": "rgba(218, 223, 225, 1)",
        },
        {
            "if": {
                "filter_query": "{Product} = 'Reverse Convertible'",
                "column_id": "Memory",
            },
            "backgroundColor": "rgba(218, 223, 225, 1)",
        },
        {
            "if": {
                "filter_query": "{Product} = 'Reverse Convertible'",
                "column_id": "Cpn Trigger",
            },
            "backgroundColor": "rgba(218, 223, 225, 1)",
        },
        {
            "if": {"filter_query": "{Wrapper} = 'Note'", "column_id": "Funding",},
            "backgroundColor": "rgba(218, 223, 225, 1)",
        },
        {
            "if": {
                "filter_query": "{Type} = 'Low Strike'",
                "column_id": "Barrier Type",
            },
            "backgroundColor": "rgba(218, 223, 225, 1)",
        },
        {
            "if": {"filter_query": "{Type} = 'Low Strike'", "column_id": "Barrier",},
            "backgroundColor": "rgba(218, 223, 225, 1)",
        },
        {
            "if": {
                "filter_query": "{Cpn (p.a)} is num && {Reoffer / UF} is blank",
                "column_id": "Reoffer / UF",
            },
            "backgroundColor": "rgba(227, 42, 42, 0.57)",
        },
        {
            "if": {
                "filter_query": "{Cpn (p.a)} is blank && {Reoffer / UF} is num",
                "column_id": "Cpn (p.a)",
            },
            "backgroundColor": "rgba(227, 42, 42, 0.57)",
        },
    ]

    tab_style_header_conditional = [
        {"if": {"header_index": 0}, "fontWeight": "bold",},
        {"if": {"header_index": 1}, "fontWeight": "bold",},
    ]

    columns = [
        {"id": "Product", "name": ["GENERAL", "Product"], "presentation": "dropdown"},
        {"id": "Wrapper", "name": ["GENERAL", "Wrapper"], "presentation": "dropdown"},
        {
            "id": "Funding",
            "name": ["GENERAL", "Funding"],
            "type": "numeric",
            "format": Format(symbol=Symbol.yes, symbol_suffix=" %"),
        },
        {
            "id": "Notional",
            "name": ["GENERAL", "Notional"],
            "type": "numeric",
            "format": Format(scheme=Scheme.fixed, precision=0, group=Group.yes,),
        },
        {"id": "Currency", "name": ["GENERAL", "Currency"], "presentation": "dropdown"},
        {
            "id": "Maturity",
            "name": ["GENERAL", "Maturity"],
            "type": "numeric",
            "format": Format(symbol=Symbol.yes, symbol_suffix=" months"),
        },
        {
            "id": "Frequency",
            "name": ["GENERAL", "Frequency"],
            "presentation": "dropdown",
        },
        {
            "id": "Reoffer / UF",
            "name": ["GENERAL", "Reoffer / UF"],
            "type": "numeric",
            "format": Format(symbol=Symbol.yes, symbol_suffix=" %"),
        },
        {"id": "Ticker 1", "name": ["UNDERLYINGS", "Ticker 1"]},
        {"id": "Ticker 2", "name": ["UNDERLYINGS", "Ticker 2"]},
        {"id": "Ticker 3", "name": ["UNDERLYINGS", "Ticker 3"]},
        {"id": "Ticker 4", "name": ["UNDERLYINGS", "Ticker 4"]},
        {"id": "Ticker 5", "name": ["UNDERLYINGS", "Ticker 5"]},
        {
            "id": "AC Trigger",
            "name": ["EARLY REDEMPTION", "AC Trigger"],
            "type": "text",
        },
        {
            "id": "NC Periods",
            "name": ["EARLY REDEMPTION", "NC Periods"],
            "type": "numeric",
        },
        {
            "id": "Cpn Trigger",
            "name": ["COUPON", "Cpn Trigger"],
            "type": "numeric",
            "format": Format(symbol=Symbol.yes, symbol_suffix=" %"),
        },
        {
            "id": "Cpn (p.a)",
            "name": ["COUPON", "Cpn (p.a)"],
            "type": "numeric",
            "format": Format(symbol=Symbol.yes, symbol_suffix=" %"),
        },
        {"id": "Memory", "name": ["COUPON", "Memory"], "presentation": "dropdown"},
        {"id": "Type", "name": ["PROTECTION", "Type"], "presentation": "dropdown"},
        {
            "id": "Barrier Type",
            "name": ["PROTECTION", "Barrier Type"],
            "presentation": "dropdown",
        },
        {
            "id": "Barrier",
            "name": ["PROTECTION", "Barrier"],
            "type": "numeric",
            "format": Format(symbol=Symbol.yes, symbol_suffix=" %"),
        },
        {
            "id": "Strike",
            "name": ["PROTECTION", "Strike"],
            "type": "numeric",
            "format": Format(symbol=Symbol.yes, symbol_suffix=" %"),
        },
    ]

    products_list = [x.name for x in Products.query.all()]
    wrappers_list = [x.name for x in Wrappers.query.all()]
    currencies_list = [x.code for x in Currencies.query.all()]
    frequencies_list = [x.code for x in Frequencies.query.all()]
    protections_list = [x.type for x in ProtectionTypes.query.all()]
    barriers_list = [x.type for x in BarrierTypes.query.all()]
    memory_list = ["Yes", "No"]

    default_data = [
        {
            "Product": "Autocall",
            "Wrapper": "Note",
            "Funding": None,
            "Notional": 500000,
            "Currency": None,
            "Maturity": None,
            "Frequency": None,
            "Reoffer / UF": None,
            "Ticker 1": None,
            "Ticker 2": None,
            "Ticker 3": None,
            "Ticker 4": None,
            "Ticker 5": None,
            "AC Trigger": "100 %",
            "NC Periods": None,
            "Cpn Trigger": None,
            "Cpn (p.a)": None,
            "Memory": "Yes",
            "Type": "PDI",
            "Barrier Type": "European",
            "Barrier": None,
            "Strike": 100,
        }
    ]
    tooltip_header = {
        "Funding": ["", "in %"],
        "Maturity": ["", "in months"],
    }

    table = DataTable(
        id="multipricer-table",
        data=default_data,
        columns=columns,
        editable=True,
        row_deletable=True,
        style_cell=tab_style_cell,
        style_cell_conditional=tab_style_cell_conditional,
        style_data_conditional=tab_style_data_conditional,
        style_header_conditional=tab_style_header_conditional,
        merge_duplicate_headers=True,
        tooltip_header=tooltip_header,
        tooltip_delay=0,
        tooltip_duration=40000,
        dropdown={
            "Product": {"options": [{"label": i, "value": i} for i in products_list]},
            "Wrapper": {"options": [{"label": i, "value": i} for i in wrappers_list]},
            "Currency": {
                "options": [{"label": i, "value": i} for i in currencies_list]
            },
            "Frequency": {
                "options": [{"label": i, "value": i} for i in frequencies_list]
            },
            "Type": {"options": [{"label": i, "value": i} for i in protections_list]},
            "Barrier Type": {
                "options": [{"label": i, "value": i} for i in barriers_list]
            },
            "Memory": {"options": [{"label": i, "value": i} for i in memory_list]},
        },
    )

    return table


def serve_layout():
    location = dcc.Location(id={"type": "url", "page": "multipricer"}, refresh=True)
    dropdown_tickers_options = []
    try:
        ticker_data = cached_sg_underlying_universe()
        ticker_data = ticker_data.get("EquityUnderlyings")
        dropdown_tickers_options = [
            {
                "label": f"{x.get('Name')} - {x.get('BloombergTickerCode')}",
                "value": x.get("BloombergTickerCode"),
            }
            for x in ticker_data
        ]
    except ApiPricingConnectionError as err:
        print(err)

    dropdown_shuffle_options = [{"label": 1, "value": 1,}]
    maturity_options = [
        {"label": f"{x} months", "value": x,} for x in [3 * i for i in range(1, 50)]
    ]
    frequency_df = pd.DataFrame(
        db.session.query(Frequencies.id, Frequencies.code).all()
    )
    frequency_data = frequency_df.to_dict(orient="records")
    frequency_options = [
        {"label": f"{x.get('code')}", "value": x.get("id"),} for x in frequency_data
    ]
    nc_periods_options = [
        {"label": x, "value": x,} for x in [0 + i for i in range(0, 50)]
    ]
    barrier_floor_options = [
        {"label": f"{x} %", "value": x,} for x in [100 - i for i in range(0, 40)]
    ]
    step_options = [
        {"label": f"{x} %", "value": x,} for x in [-i / 2 for i in range(1, 22)]
    ]

    body = dbc.Container(
        [
            # Buttons Row
            dbc.Row(
                [
                    dbc.Col(
                        dbc.Row(
                            [
                                dbc.Col(
                                    dbc.Button(
                                        "Add Line", id="multipricer-add-line-button",
                                    ),
                                    width="auto",
                                ),
                                dbc.Col(
                                    dbc.Button(
                                        "Duplicate Line",
                                        id="multipricer-duplicate-line-button",
                                    ),
                                    width="auto",
                                ),
                                dbc.Col(
                                    dbc.Button(
                                        "Custom Trigger",
                                        id="multipricer-add-custom-trigger-button",
                                        color="secondary",
                                    ),
                                    width="auto",
                                ),
                            ]
                        )
                    ),
                    dbc.Col(
                        [
                            dbc.Row(
                                [
                                    dbc.Col(
                                        html.A(
                                            html.I(
                                                className="fas fa-info-circle",
                                                id="multipricer-table-info",
                                            ),
                                            id="multipricer-table-info-wrapper",
                                            style={"color": "rgb(179, 0, 0)"},
                                        ),
                                        width="auto",
                                        align="center",
                                    ),
                                    dbc.Col(
                                        dbc.Button(
                                            "Send RFQ",
                                            id="multipricer-open-modal-button",
                                            disabled=True,
                                            color="success",
                                        ),
                                        width="auto",
                                    ),
                                ]
                            ),
                            dbc.Tooltip(
                                f"Table not filled",
                                target=f"multipricer-table-info-wrapper",
                                id="multipricer-table-info-tooltip",
                                placement="top",
                            ),
                        ],
                        width="auto",
                    ),
                ],
                justify="between",
                className="mt-5",
            ),
            # Information Row
            dbc.Row(
                [
                    dbc.Col(
                        dbc.Row(
                            [
                                dbc.Col(
                                    dcc.Dropdown(
                                        id="multipricer-ticker-dropdown",
                                        options=dropdown_tickers_options,
                                        disabled=True
                                        if not dropdown_tickers_options
                                        else False,
                                        multi=True,
                                        placeholder="Select Up To 5 Tickers..."
                                        if dropdown_tickers_options
                                        else "Error Getting SG Universe",
                                        value=[],
                                    ),
                                    width=6,
                                    align="center",
                                ),
                                dbc.Col(
                                    dcc.Dropdown(
                                        id="multipricer-shuffle-dropdown",
                                        options=dropdown_shuffle_options,
                                        multi=False,
                                        value=1,
                                        clearable=False,
                                    ),
                                    width="auto",
                                    align="center",
                                ),
                                dbc.Col(
                                    html.Div(
                                        html.Div(
                                            shuffle_lottie(),
                                            n_clicks=0,
                                            id="multipricer-shuffle-button",
                                        ),
                                        id="multipricer-shuffle-wrapper",
                                    ),
                                    width="auto",
                                    align="center",
                                ),
                                dbc.Tooltip(
                                    children="Shuffle the tickers into combinations of 1",
                                    target="multipricer-shuffle-wrapper",
                                    # autohide=False,
                                    delay={"show": 250, "hide": 250},
                                    placement="bottom-left",
                                    class_name="p-2",
                                    id="multipricer-shuffle-wrapper-id",
                                ),
                            ],
                        )
                    ),
                    dbc.Col(
                        html.H5("Solving for UNDEFINED", id="multipricer-solving-for"),
                        width="auto",
                    ),
                ],
                justify="between",
                className="mt-5",
            ),
            dbc.Row(
                dbc.Col(
                    dbc.Checklist(
                        id="multipricer-is-live-checklist",
                        options=[{"label": "Live Request", "value": 1}],
                        value=[],
                        inline=True,
                        switch=True,
                    )
                ),
                className="mt-4",
                style={"display": "none"},
            ),
            # Pricer Table Row
            html.Div(
                [
                    dbc.Row(
                        [dbc.Col(multipricer_table(), width=12,),],
                        justify="between",
                        className="mt-5",
                    ),
                    # Indications Table Row
                    dbc.Row(
                        [
                            dbc.Col(
                                html.P(
                                    "AC Trigger must either be fixed (100 %) or variable from the first callable period (100-95-90-85 %)",
                                    style={"font-style": "italic"},
                                ),
                                width="auto",
                            ),
                            dbc.Col(
                                html.P(
                                    "Nb Request(s) 1/10",
                                    id="multipricer-nb-lines",
                                    style={"font-style": "italic"},
                                ),
                                width="auto",
                            ),
                        ],
                        justify="between",
                        className="mt-2",
                    ),
                ],
                style={"min-height": "450px"},
            ),
            # Separator Row
            dbc.Row(dbc.Col(html.Hr(className="my-2"))),
            # History Filter Row
            dbc.Row(
                [
                    dbc.Col(
                        dcc.Dropdown(
                            id="multipricer-user-dropdown",
                            options=[
                                {"label": "Myself", "value": "myself"},
                                {"label": "My Team", "value": "myteam"},
                                {"label": "All", "value": "all"},
                            ],
                            value="myself",
                        ),
                        width=2,
                    ),
                    dbc.Col(
                        dcc.Dropdown(
                            id="multipricer-date-dropdown",
                            options=[
                                {"label": "Today", "value": "today"},
                                {"label": "This Week", "value": "week"},
                                {"label": "All", "value": "all"},
                            ],
                            value="today",
                        ),
                        width=2,
                    ),
                ],
                justify="end",
                className="pl-2 pr-2 mt-2 mb-2",
            ),
            # Request History Row
            dbc.Row(dbc.Col(id="multipricer-history-col", width=12)),
            # Load More Button Row
            dbc.Row(
                dbc.Col(
                    dbc.Button("Load More", id="multipricer-load-more-button",),
                    width="auto",
                ),
                justify="center",
            ),
            # Hidden Components
            dcc.Store(
                id={"type": "multipricer-store", "index": 1},
                storage_type="session",
                clear_data=True,
            ),
            dcc.Store(
                id={"type": "multipricer-store", "index": 2},
                storage_type="session",
                clear_data=True,
            ),
            dbc.Modal(
                [
                    dbc.ModalHeader("Issuers Selection"),
                    dbc.ModalBody(
                        html.Div(
                            [
                                dbc.Col(
                                    id="multipricer-issuer-selection-modal-text",
                                    width=12,
                                ),
                                dbc.Col(
                                    dcc.Checklist(
                                        id="multipricer-issuer-selection-modal-issuers-checklist",
                                        options=[],
                                        value=[],
                                        labelStyle={"display": "block"},
                                        inputStyle={
                                            "margin-right": "10px",
                                            "vertical-align": "text-top",
                                        },
                                    ),
                                    className="mt-3",
                                ),
                            ],
                        ),
                        id="multipricer-issuer-selection-modal-body",
                    ),
                    dbc.ModalFooter(
                        dbc.Row(
                            [
                                dbc.Col(
                                    dbc.Button(
                                        "Select All",
                                        id="multipricer-issuer-selection-modal-select-all-button",
                                    ),
                                    width="auto",
                                ),
                                dbc.Col(
                                    dbc.Button(
                                        "Send RFQ",
                                        id="multipricer-issuer-selection-modal-send-rfq-button",
                                    ),
                                ),
                            ],
                            justify="between",
                        )
                    ),
                ],
                id="multipricer-issuer-selection-modal",
                size="xl",
                backdrop=True,
                centered=True,
                fade=True,
                is_open=False,
                keyboard=True,
                autoFocus=True,
            ),
            dbc.Modal(
                [
                    dbc.ModalHeader("Custom Trigger"),
                    dbc.ModalBody(
                        [
                            dbc.Row(
                                [
                                    dbc.Col("Maturity", width=4),
                                    dbc.Col("Frequency", width=4),
                                    dbc.Col("NC Periods (opt.)", width=4),
                                    dbc.Col(
                                        dcc.Dropdown(
                                            id="multipricer-maturity-dropdown",
                                            options=maturity_options,
                                        ),
                                        width=4,
                                        className="mb-3",
                                    ),
                                    dbc.Col(
                                        dcc.Dropdown(
                                            id="multipricer-frequency-dropdown",
                                            options=frequency_options,
                                        ),
                                        width=4,
                                        className="mb-3",
                                    ),
                                    dbc.Col(
                                        dcc.Dropdown(
                                            id="multipricer-nc-periods-dropdown",
                                            options=nc_periods_options,
                                        ),
                                        width=4,
                                        className="mb-3",
                                    ),
                                    dbc.Col("First Barrier", width=4),
                                    dbc.Col("Step Down", width=4),
                                    dbc.Col("Floor (opt.)", width=4),
                                    dbc.Col(
                                        dcc.Dropdown(
                                            id="multipricer-barrier-dropdown",
                                            options=barrier_floor_options,
                                        ),
                                        width=4,
                                        className="mb-3",
                                    ),
                                    dbc.Col(
                                        dcc.Dropdown(
                                            id="multipricer-step-dropdown",
                                            options=step_options,
                                        ),
                                        width=4,
                                        className="mb-3",
                                    ),
                                    dbc.Col(
                                        dcc.Dropdown(
                                            id="multipricer-floor-dropdown",
                                            options=barrier_floor_options,
                                        ),
                                        width=4,
                                        className="mb-3",
                                    ),
                                ],
                                justify="around",
                                className="mb-2",
                            ),
                            dbc.Row(
                                [
                                    dbc.Col("Trigger :", width="auto"),
                                    dbc.Col(
                                        html.P(
                                            id="multipricer-trigger-output-paragraph",
                                            style={"font-weight": "bold"},
                                        )
                                    ),
                                ]
                            ),
                        ],
                    ),
                    dbc.ModalFooter(
                        dbc.Row(
                            [
                                dbc.Col(
                                    dbc.Button(
                                        "Copy",
                                        id="multipricer-custom-trigger-modal-copy-button",
                                    ),
                                ),
                            ],
                            justify="between",
                        )
                    ),
                ],
                id="multipricer-custom-trigger-modal",
                size="xl",
                backdrop=True,
                centered=True,
                fade=True,
                is_open=False,
                keyboard=True,
                autoFocus=True,
            ),
            dbc.Toast(
                id="multipricer-toast",
                is_open=False,
                dismissable=True,
                icon="success",
                headerClassName="home-notif-header",
                bodyClassName="home-notif-body",
                className="home-notif-toast",
                duration=5000,
            ),
            dbc.Toast(
                id="multipricer-toast-2",
                is_open=False,
                dismissable=True,
                icon="success",
                headerClassName="home-notif-header",
                bodyClassName="home-notif-body",
                className="home-notif-toast",
                duration=5000,
            ),
            dbc.Toast(
                "Custom Trigger Copied To Clipboard",
                id="multipricer-toast-3",
                header="Copy To Clipboard",
                is_open=False,
                dismissable=True,
                icon="success",
                headerClassName="home-notif-header",
                bodyClassName="home-notif-body",
                className="home-notif-toast",
                duration=5000,
            ),
            dcc.Interval(id="multipricer-interval", interval=30000, n_intervals=0),
        ],
        fluid=True,
        style={"maxWidth": "95%"},
    )

    return [location, body]


@app.callback(
    Output("multipricer-history-col", "children"),
    Output("multipricer-load-more-button", "style"),
    Input({"type": "url", "page": "multipricer"}, "href"),
    Input("multipricer-interval", "n_intervals"),
    Input("multipricer-toast", "is_open"),
    Input("multipricer-user-dropdown", "value"),
    Input("multipricer-date-dropdown", "value"),
    Input("multipricer-load-more-button", "n_clicks"),
)
def refresh_history(
    href, n_intervals, toast, user_filter, date_filter, load_more_clicks
):
    # Set Date Filter
    if date_filter == "today":
        start_date = dt_today()
        date_msg = "today"
    elif date_filter == "week":
        start_date = dt_today() - timedelta(days=7 + dt_today().weekday())
        date_msg = "this week"
    else:
        start_date = dt(2021, 1, 1)
        date_msg = ""
    # Set User Filter
    current_user_id = current_user.id
    all_users_id = [i for i in range(0, 150)]
    if user_filter == "myself":
        user_list = [current_user_id]
        user_msg = "for you"
    elif user_filter == "myteam":
        user_msg = "for your team"
        user_list = list(set(all_users_id) - {current_user_id})
    else:
        user_msg = ""
        user_list = all_users_id
    df_mail = pd.DataFrame(
        db.session.query(
            PricingRequests.id_request_email,
            PricingRequests.id_request,
            PricingRequests.id_user,
            PricingRequests.timestamp,
        )
        .filter(PricingRequests.timestamp >= start_date)
        .filter(PricingRequests.id_user.in_(user_list))
        .order_by(PricingRequests.timestamp.desc())
        .all()
    )
    if df_mail.empty:
        return (
            [
                dbc.Col(
                    html.P(
                        f"No quote found {user_msg} {date_msg}",
                        style={"font-style": "italic"},
                    ),
                    width="auto",
                ),
            ],
            {"display": "none"},
        )
    else:
        df_mail = df_mail.drop_duplicates("id_request_email").reset_index()

        if not load_more_clicks:
            load_more_clicks = 0

        max_request_shown = 3 * (1 + load_more_clicks)

        if len(df_mail.index) > max_request_shown:
            button_style = {"display": "inline"}
        else:
            button_style = {"display": "none"}

        df_mail = df_mail.iloc[0 : min(max_request_shown, len(df_mail.index))]

        card_request_history = []

        for email in df_mail["id_request"]:
            df_mail = pd.DataFrame(
                db.session.query(
                    PricingRequests.id_product,
                    PricingRequests.id_solve_for,
                    PricingRequests.id_wrapper,
                    PricingRequests.id_user,
                    PricingRequests.id_request,
                    PricingRequests.id_request_email,
                    PricingRequests.timestamp,
                )
                .filter(PricingRequests.id_request == email)
                .all()
            )
            df_mail["product"] = df_mail["id_product"].apply(
                lambda x: Products.query.filter(Products.id == x).first().name
            )
            df_mail["wrapper"] = df_mail["id_wrapper"].apply(
                lambda x: Wrappers.query.filter(Wrappers.id == x).first().name
            )
            df_mail["solve_for"] = df_mail["id_solve_for"].apply(
                lambda x: SolveFor.query.filter(SolveFor.id == x).first().code
            )
            df_mail["user"] = df_mail["id_user"].apply(
                lambda x: User.query.filter(User.id == x).first().displayname
            )
            df_mail = df_mail.drop(
                columns=["id_product", "id_wrapper", "id_solve_for", "id_user"]
            )

            mail_data = df_mail.to_dict(orient="records")[0]
            card_request_history.append(create_card_request(mail_data))

        return card_request_history, button_style


@app.callback(
    Output("multipricer-table", "data"),
    Output("multipricer-table-info-tooltip", "children"),
    Output("multipricer-table-info-wrapper", "style"),
    Output("multipricer-solving-for", "children"),
    Output("multipricer-ticker-dropdown", "value"),
    Output("multipricer-open-modal-button", "disabled"),
    Output("multipricer-open-modal-button", "colour"),
    Output("multipricer-nb-lines", "children"),
    Output("multipricer-toast-2", "header"),
    Output("multipricer-toast-2", "children"),
    Output("multipricer-toast-2", "is_open"),
    Output("multipricer-toast-2", "icon"),
    Output("multipricer-shuffle-dropdown", "options"),
    Output("multipricer-shuffle-dropdown", "value"),
    Input("multipricer-duplicate-line-button", "n_clicks"),
    Input("multipricer-add-line-button", "n_clicks"),
    Input("multipricer-shuffle-button", "n_clicks"),
    Input("multipricer-table", "data"),
    Input("multipricer-ticker-dropdown", "value"),
    Input({"type": "multipricer-store", "index": 1}, "data"),
    State({"type": "multipricer-store", "index": 2}, "data"),
    State("multipricer-table", "columns"),
    State("multipricer-shuffle-dropdown", "value"),
    prevent_initial_call=True,
)
def update_table(
    n_clicks_1,
    n_clicks_2,
    n_clicks_3,
    rows,
    dropdown,
    store_data,
    store_clicks,
    columns,
    shuffle_nb_tickers,
):
    # Compute Trigger
    ctx = dash.callback_context
    trigger = ctx.triggered[0]["prop_id"].split(".")[0]

    # Set maximum number of shuffles
    shuffle_options = [
        {"label": i, "value": i,} for i in range(1, max(2, len(dropdown)))
    ]
    shuffle_value = max(2, len(dropdown)) - 1

    # Convert Trigger to json (if possible)
    try:
        json_trigger = json.loads(trigger).get("type")
    except:
        json_trigger = None

    # Load Previous Request
    if json_trigger and store_clicks and len([i for i in store_clicks if i]) > 0:
        rows = store_data[0]

    # Load DataFrame
    df = pd.DataFrame(rows)

    # Set Solving For Text
    if len(df.index) == 0:
        msg = "UNDEFINED"
    else:
        msg = solve_for_msg(df)
    solving_msg = f"Solving for {msg}"

    # Set Nb Lines Text
    nb_lines = f"Nb Request(s) {len(df.index)}/10"

    # Set Open Modal Button Status
    table_completed, info_msg = check_table_is_completed(df, msg)
    if len(df.index) == 0 or not table_completed:
        open_modal_disabled = True
        info_style = {"color": "rgb(179, 0, 0)"}
    else:
        open_modal_disabled = False
        info_style = {"color": "rgb(179, 0, 0)", "display": "none"}

    # Set "Send RFQ" Button Colour
    if open_modal_disabled:
        color_button = "secondary"
    else:
        color_button = "primary"

    # Set Toast Parameters
    toast_header = ""
    toast_children = ""
    toast_is_open = False
    toast_icon = "success"

    # Add Line
    if trigger == "multipricer-add-line-button":
        if len(df.index) <= 9:
            rows.append({c["id"]: None for c in columns})
        else:
            toast_header = "Warning - Add New Line Failed"
            toast_children = "Maximum number of lines reached (10)"
            toast_is_open = True
            toast_icon = "warning"
        nb_lines = f"Nb Request(s) {len(df.index + 1)}/10"
        return (
            rows,
            info_msg,
            info_style,
            solving_msg,
            dropdown,
            open_modal_disabled,
            color_button,
            nb_lines,
            toast_header,
            toast_children,
            toast_is_open,
            toast_icon,
            shuffle_options,
            shuffle_value,
        )

    # Duplicate Line
    elif trigger == "multipricer-duplicate-line-button":
        if len(df.index) == 0:
            rows.append({c["id"]: None for c in columns})
        elif len(df.index) <= 9:
            df = df.append(df.iloc[-1, :], ignore_index=True)
            rows = df.to_dict(orient="records")
        else:
            toast_header = "Warning - Add New Line Failed"
            toast_children = "Maximum number of lines reached (10)"
            toast_is_open = True
            toast_icon = "warning"
        nb_lines = f"Nb Request(s) {len(df.index + 1)}/10"
        return (
            rows,
            info_msg,
            info_style,
            solving_msg,
            dropdown,
            open_modal_disabled,
            color_button,
            nb_lines,
            toast_header,
            toast_children,
            toast_is_open,
            toast_icon,
            shuffle_options,
            shuffle_value,
        )

    # Shuffle The Tickers
    elif trigger == "multipricer-shuffle-button":
        if len(dropdown) >= 1:
            df = df.head(1)
            cpt = 0
            for combination in itertools.combinations(dropdown, shuffle_nb_tickers):
                cpt += 1
                if cpt > 20:
                    break
                else:
                    new_line = df.iloc[0, :]
                    new_line["Ticker 1"] = combination[0]
                    new_line["Ticker 2"] = None
                    new_line["Ticker 3"] = None
                    new_line["Ticker 4"] = None
                    new_line["Ticker 5"] = None
                    if shuffle_nb_tickers > 1:
                        new_line["Ticker 2"] = combination[1]
                    if shuffle_nb_tickers > 2:
                        new_line["Ticker 3"] = combination[2]
                    if shuffle_nb_tickers > 3:
                        new_line["Ticker 4"] = combination[3]
                    df = df.append(new_line, ignore_index=True)
            df = df.iloc[1:]
            nb_lines = f"Nb Request(s) {len(df.index)}/10"
        else:
            toast_header = "Warning - Tickers Selection"
            toast_children = "Select at least 2 tickers"
            toast_is_open = True
            toast_icon = "warning"
        return (
            df.to_dict(orient="records"),
            info_msg,
            info_style,
            solving_msg,
            [],
            open_modal_disabled,
            color_button,
            nb_lines,
            toast_header,
            toast_children,
            toast_is_open,
            toast_icon,
            shuffle_options,
            shuffle_value,
        )

    # Data Changed In Table
    else:
        if len(df.index) > 0:
            df = change_table_input(df, dropdown)
        return (
            df.to_dict(orient="records"),
            info_msg,
            info_style,
            solving_msg,
            dropdown,
            open_modal_disabled,
            color_button,
            nb_lines,
            toast_header,
            toast_children,
            toast_is_open,
            toast_icon,
            shuffle_options,
            shuffle_value,
        )


@app.callback(
    Output("multipricer-issuer-selection-modal", "is_open"),
    Output("multipricer-issuer-selection-modal-text", "children"),
    Output("multipricer-issuer-selection-modal-issuers-checklist", "options"),
    Output("multipricer-issuer-selection-modal-issuers-checklist", "value"),
    Output("multipricer-issuer-selection-modal-send-rfq-button", "disabled"),
    Output("multipricer-toast", "header"),
    Output("multipricer-toast", "children"),
    Output("multipricer-toast", "is_open"),
    Output("multipricer-toast", "icon"),
    Input("multipricer-open-modal-button", "n_clicks"),
    Input("multipricer-issuer-selection-modal-send-rfq-button", "n_clicks"),
    Input("multipricer-issuer-selection-modal-select-all-button", "n_clicks"),
    Input("multipricer-issuer-selection-modal-issuers-checklist", "value"),
    State("multipricer-table", "data"),
    State("multipricer-is-live-checklist", "value"),
    State("multipricer-solving-for", "children"),
    prevent_initial_call=True,
)
def toggle_issuer_selection_modal(
    n_clicks,
    n_clicks_modal_1,
    n_clicks_modal_2,
    selected_issuers,
    rows,
    live_checklist,
    solve_for_text,
):
    # Compute Trigger
    ctx = dash.callback_context
    trigger = ctx.triggered[0]["prop_id"].split(".")[0]

    # Retrieve Data From Multipricer Table
    df = pd.DataFrame(rows)

    # Set Open / Close Modal
    if (
        trigger == "multipricer-open-modal-button"
        or trigger == "multipricer-issuer-selection-modal-select-all-button"
        or trigger == "multipricer-issuer-selection-modal-issuers-checklist"
    ):
        open_modal = True
    else:
        open_modal = False

    # Set Live Request Boolean
    if 1 in live_checklist:
        is_live = True
    else:
        is_live = False

    # Set Solve For
    solve_for_text = solve_for_text.split(" ")[-1]
    if solve_for_text == "COUPON":
        solve_for = "Coupon"
    elif solve_for_text == "REOFFER":
        solve_for = "Reoffer"
    else:
        solve_for = "Upfront"

    # Set Issuers Selection List
    wrappers_list = df["Wrapper"].unique()
    products_list = df["Product"].unique()
    wrapper_selected = " & ".join(wrappers_list)
    if wrappers_list[0] == "Note" and products_list[0] == "Autocall":
        issuers_list_options = [
            {"label": x.short_name, "value": x.id}
            for x in Issuers.query.filter(
                or_(Issuers.has_mail_pricer_note == 1, Issuers.has_api_pricer == 1)
            ).all()
        ]

    elif wrappers_list[0] == "Swap" and products_list[0] == "Autocall":
        issuers_list_options = [
            {"label": x.short_name, "value": x.id}
            for x in Issuers.query.filter(
                or_(Issuers.has_mail_pricer_swap == 1, Issuers.has_api_pricer == 1)
            ).all()
        ]
        issuers_list_options.remove({"label": "Barclays", "value": 1})

    elif wrappers_list[0] == "Note" and products_list[0] == "Reverse Convertible":
        issuers_list_options = [
            {"label": x.short_name, "value": x.id}
            for x in Issuers.query.filter(
                or_(Issuers.has_mail_pricer_note == 1, Issuers.has_api_pricer == 1)
            ).all()
        ]
        # issuers_list_options.remove({"label": "Barclays", "value": 1})
        issuers_list_options.remove({"label": "CACIB", "value": 4})
        issuers_list_options.remove({"label": "MS", "value": 12})
        issuers_list_options.remove({"label": "LTQ", "value": 10})

    elif wrappers_list[0] == "Swap" and products_list[0] == "Reverse Convertible":
        issuers_list_options = [
            {"label": x.short_name, "value": x.id}
            for x in Issuers.query.filter(
                or_(Issuers.has_mail_pricer_swap == 1, Issuers.has_api_pricer == 1)
            ).all()
        ]
        issuers_list_options.remove({"label": "Barclays", "value": 1})
        issuers_list_options.remove({"label": "MS", "value": 12})
        issuers_list_options.remove({"label": "JPM", "value": 9})
        issuers_list_options.remove({"label": "GS", "value": 8})

    # if {"label": "Barclays", "value": 1} in issuers_list_options:
    #     issuers_list_options.remove({"label": "Barclays", "value": 1})
    #     issuers_list_options.append({"label": "Barclays", "value": 1})
    modal_text = (
        f"List of issuers with API or Mail pricer available for {wrapper_selected} :"
    )

    # Set Selected Issuers
    if trigger == "multipricer-issuer-selection-modal-select-all-button":
        selected_issuers = [x.get("value") for x in issuers_list_options]
    if trigger == "multipricer-open-modal-button":
        selected_issuers = []

    # Send Button Status
    if not selected_issuers:
        send_button_disable = True
    else:
        send_button_disable = False

    # Set Toast Parameters
    toast_header = ""
    toast_children = ""
    toast_is_open = False
    toast_icon = "success"

    # Send RFQ & Set Toast
    if trigger == "multipricer-issuer-selection-modal-send-rfq-button":
        for i in range(0, len(selected_issuers)):
            x = Issuers.query.filter(
                or_(
                    Issuers.id == selected_issuers[i],
                    Issuers.short_name == selected_issuers[i],
                )
            ).first()
            selected_issuers[i] = x.short_name
        # Set API Pricer Issuers To Last
        if "SG" in selected_issuers:
            selected_issuers.remove("SG")
            selected_issuers.append("SG")
        if "Barclays" in selected_issuers:
            selected_issuers.remove("Barclays")
            selected_issuers.append("Barclays")
        result = create_rfq(selected_issuers, df, is_live, current_user.id, solve_for)
        result = list(filter(None, result))
        if len(result) > 0:
            toast_header = "Warning - Issuer Selection"
            toast_children = " - ".join(result)
            toast_is_open = True
            toast_icon = "warning"
        else:
            toast_header = "RFQ Sent"
            toast_children = f"RFQ Sent To {(' - '.join(selected_issuers))}"
            toast_is_open = True
            toast_icon = "success"

    return (
        open_modal,
        modal_text,
        issuers_list_options,
        selected_issuers,
        send_button_disable,
        toast_header,
        toast_children,
        toast_is_open,
        toast_icon,
    )


@app.callback(
    Output("multipricer-custom-trigger-modal", "is_open"),
    Output("multipricer-trigger-output-paragraph", "children"),
    Input("multipricer-add-custom-trigger-button", "n_clicks"),
    Input("multipricer-maturity-dropdown", "value"),
    Input("multipricer-frequency-dropdown", "value"),
    Input("multipricer-nc-periods-dropdown", "value"),
    Input("multipricer-barrier-dropdown", "value"),
    Input("multipricer-step-dropdown", "value"),
    Input("multipricer-floor-dropdown", "value"),
    Input("multipricer-toast-3", "is_open"),
    prevent_initial_call=True,
)
def toggle_custom_trigger_modal(
    n_clicks, maturity, frequency, nc_periods, barrier, step, floor, toast_open,
):

    # Compute Trigger
    ctx = dash.callback_context
    trigger = ctx.triggered[0]["prop_id"].split(".")[0]

    # Set Open or Close Modal
    if trigger == "multipricer-toast-3":
        open_modal = False
    else:
        open_modal = True

    # Convert NC Periods
    if nc_periods is None:
        nc_periods = 0

    # Convert Floor Periods
    if floor is None:
        floor = 0

    # Set Trigger Text:
    if maturity is None or frequency is None or barrier is None or step is None:
        trigger = "Undefined"
    else:
        trigger = custom_trigger(maturity, frequency, nc_periods, barrier, step, floor)

    return open_modal, trigger


@app.callback(
    Output({"type": "multipricer-load-button", "index": ALL}, "n_clicks"),
    Output({"type": "multipricer-delete-button", "index": ALL}, "n_clicks"),
    Output({"type": "multipricer-store", "index": 1}, "data"),
    Output({"type": "multipricer-store", "index": 2}, "data"),
    Output({"type": "multipricer-card-toast", "index": ALL}, "header"),
    Output({"type": "multipricer-card-toast", "index": ALL}, "children"),
    Output({"type": "multipricer-card-toast", "index": ALL}, "is_open"),
    Input({"type": "multipricer-load-button", "index": ALL}, "n_clicks"),
    Input({"type": "multipricer-delete-button", "index": ALL}, "n_clicks"),
    State({"type": "multipricer-card-hidden-div", "index": ALL}, "children"),
    State({"type": "multipricer-store", "index": 1}, "data"),
    prevent_initial_call=True,
)
def load_delete_request(load_clicks, delete_clicks, email_id, store_data):
    load_click_list = [None for i in load_clicks]
    delete_click_list = [None for i in load_clicks]
    is_open_list = [False for i in load_clicks]
    children_list = ["" for i in load_clicks]
    header_list = ["" for i in load_clicks]

    if len(load_clicks) > 0:
        for i in range(0, len(load_clicks)):
            # Load Request
            if load_clicks[i] is not None:
                df = pd.DataFrame(
                    db.session.query(
                        PricingRequests.id_protection_type.label("Type"),
                        PricingRequests.id_product.label("Product"),
                        PricingRequests.id_barrier_type.label("Barrier Type"),
                        PricingRequests.id_currency.label("Currency"),
                        PricingRequests.id_wrapper.label("Wrapper"),
                        PricingRequests.id_frequency.label("Frequency"),
                        PricingRequests.offer_price.label("Reoffer / UF"),
                        PricingRequests.months_to_maturity.label("Maturity"),
                        PricingRequests.barrier_strike.label("Strike"),
                        PricingRequests.barrier_level.label("Barrier"),
                        PricingRequests.coupon_level.label("Cpn (p.a)"),
                        PricingRequests.coupon_barrier.label("Cpn Trigger"),
                        PricingRequests.autocall_barrier.label("AC Trigger"),
                        PricingRequests.autocall_start_period.label("NC Periods"),
                        PricingRequests.notional.label("Notional"),
                        PricingRequests.funding_spread.label("Funding"),
                        PricingRequests.is_memory.label("Memory"),
                        PricingRequests.ticker_1.label("Ticker 1"),
                        PricingRequests.ticker_2.label("Ticker 2"),
                        PricingRequests.ticker_3.label("Ticker 3"),
                        PricingRequests.ticker_4.label("Ticker 4"),
                        PricingRequests.ticker_5.label("Ticker 5"),
                    )
                    .filter(and_(PricingRequests.id_request_email == email_id[i],))
                    .all()
                )
                df = df.drop_duplicates()
                df["Type"] = df["Type"].apply(
                    lambda x: ProtectionTypes.query.filter(ProtectionTypes.id == x)
                    .first()
                    .type
                )
                df["Barrier Type"] = df["Barrier Type"].apply(
                    lambda x: BarrierTypes.query.filter(BarrierTypes.id == x)
                    .first()
                    .type
                    if x != 4
                    else x
                )
                df["Product"] = df["Product"].apply(
                    lambda x: Products.query.filter(Products.id == x).first().name
                )
                df["Wrapper"] = df["Wrapper"].apply(
                    lambda x: Wrappers.query.filter(Wrappers.id == x).first().name
                )
                df["Currency"] = df["Currency"].apply(
                    lambda x: Currencies.query.filter(Currencies.id == x).first().code
                )
                df["Frequency"] = df["Frequency"].apply(
                    lambda x: Frequencies.query.filter(Frequencies.id == x).first().code
                )
                df["Memory"] = df["Memory"].apply(lambda x: "Yes" if x else "No")
                df["NC Periods"] = df["NC Periods"].apply(lambda x: x - 1 if x else x)
                is_open_list[0] = True
                header_list[0] = "Loading Request"
                children_list[0] = f"{email_id[i]} successfully loaded"
                return (
                    load_click_list,
                    delete_click_list,
                    [df.to_dict(orient="records")],
                    load_clicks,
                    header_list,
                    children_list,
                    is_open_list,
                )

            # Delete Request
            elif delete_clicks[i] is not None:

                # Find All Requests for this mail
                df = pd.DataFrame(
                    db.session.query(
                        PricingResults.id_request, PricingResults.id_request_email,
                    )
                    .select_from(PricingResults)
                    .filter(PricingResults.id_request_email == email_id[i])
                    .all()
                )

                for id_request in df["id_request"].unique():
                    # Delete Pricing Request
                    db.session.query(PricingRequests).filter(
                        PricingRequests.id_request == id_request
                    ).delete(synchronize_session=False)
                    db.session.commit()
                    # Delete Pricing Results
                    db.session.query(PricingResults).filter(
                        PricingResults.id_request == id_request
                    ).delete(synchronize_session=False)
                    db.session.commit()

                is_open_list[0] = True
                header_list[0] = "Deleting Request"
                children_list[0] = f"{email_id[i]} successfully deleted"
                return (
                    load_click_list,
                    delete_click_list,
                    store_data,
                    load_click_list,
                    header_list,
                    children_list,
                    is_open_list,
                )

    return (
        load_click_list,
        delete_click_list,
        store_data,
        load_click_list,
        header_list,
        children_list,
        is_open_list,
    )


@app.callback(
    Output("multipricer-shuffle-wrapper-id", "children"),
    Input("multipricer-shuffle-dropdown", "value"),
    prevent_initial_call=True,
)
def shuffle_tooltip(value):
    return f"Shuffle the tickers into combinations of {value}"


# Copy Custom Trigger
app.clientside_callback(
    """
    function(click, json_table) {
        var dummy = document.createElement("textarea");
        document.body.appendChild(dummy);
        dummy.value = json_table;
        dummy.select();
        document.execCommand("copy");
        document.body.removeChild(dummy);
        return true;
    }
    """,
    Output("multipricer-toast-3", "is_open"),
    Input("multipricer-custom-trigger-modal-copy-button", "n_clicks"),
    State("multipricer-trigger-output-paragraph", "children"),
    prevent_initial_call=True,
)

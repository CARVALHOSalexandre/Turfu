import pandas as pd
from app import app, db, server
from dash import callback_context
from dash.dependencies import Input, Output, State
from dash.dash_table import DataTable
from dash import dcc
from dash import html
import dash_bootstrap_components as dbc
from sqlalchemy.exc import OperationalError, IntegrityError
from sqlalchemy.types import Boolean, Integer, String, DateTime


def model_from_table_name(table_name):
    if "." in table_name:
        table_name = table_name.split(".")[1]
    data = {table.__tablename__: table for table in db.Model.__subclasses__()}
    return data.get(table_name)


def serve_layout():

    location = dcc.Location(id={"type": "url", "page": "bdd"}, refresh=False)

    tables = list(db.metadata.tables.keys())
    tables.sort()

    body = dbc.Container(
        [
            dbc.Row(
                [
                    dbc.Col(
                        dbc.Input(
                            id="bdd-input-filter",
                            debounce=True,
                            placeholder="SQL Filter",
                        ),
                        width=2,
                    ),
                    dbc.Col(
                        dbc.Select(
                            id="bdd-dropdown",
                            # placeholder="Select a table",
                            options=[
                                {"label": x, "value": x} for x in tables if "." not in x
                            ],
                        ),
                        width=2,
                    ),
                    dbc.Col(
                        dbc.Button(
                            "Add Line",
                            id="bdd-button-add-line",
                            n_clicks=0,
                        ),
                        width=1,
                    ),
                    dbc.Col(
                        dbc.Button(
                            "Reset Table",
                            id="bdd-button-reset-table",
                            n_clicks=0,
                        ),
                        width=2,
                    ),
                ],
                justify="end",
            ),
            dbc.Row(
                [
                    dbc.Col(
                        dbc.Spinner(
                            DataTable(
                                id="bdd-table",
                                editable=True,
                                row_deletable=True,
                                sort_action="native",
                                sort_mode="multi",
                                style_header={
                                    "fontWeight": "bold",
                                    "backgroundColor": "white",
                                },
                                style_cell={
                                    "textOverflow": "ellipsis",
                                    "minWidth": "0px",
                                    "padding": "5px",
                                    "font-family": "Roboto",
                                    "font-size": "12px",
                                    "text-align": "left",
                                    "backgroundColor": "transparent",
                                    "padding-top": "10px",
                                    "padding-bottom": "10px",
                                    "border-top": "0.1px solid rgb(240, 240, 240)",
                                    "border-bottom": "0.1px solid rgb(240, 240, 240)",
                                    "border-right": " 0px",
                                    "border-left": "0px",
                                },
                                style_data_conditional=[
                                    {
                                        "if": {"state": "active"},
                                        "backgroundColor": "transparent",
                                        "border": "none",
                                        "color": "rgb(44, 62, 80)",
                                        "border-top": "1px solid rgb(236, 240, 241)",
                                        "border-bottom": "1px solid rgb(236, 240, 241)",
                                    },
                                    {
                                        "if": {"state": "selected"},
                                        "backgroundColor": "transparent",
                                        "border-top": "1px solid rgb(236, 240, 241)",
                                        "border-bottom": "1px solid rgb(236, 240, 241)",
                                    },
                                ],
                                tooltip_delay=0,
                                tooltip_duration=None,
                                page_action="native",
                                page_current=0,
                                page_size=20,
                            ),
                            spinner_style={
                                "width": "3rem",
                                "height": "3rem",
                                "margin-top": "10rem",
                            },
                            size="sm",
                            type="grow",
                            color="primary",
                        )
                    )
                ],
                className="my-4",
            ),
        ],
        style={"maxWidth": "80%"},
        className="borded-card p-5 mt-3 container-fluid",
    )

    notification = dbc.Toast(
        id="bdd-notification",
        is_open=False,
        dismissable=True,
        duration=4000,
        style={
            "position": "fixed",
            "top": 110,
            "right": 25,
            "width": 300,
        },
    )

    return [location, body, notification]


def new_line_in_table(table_name, **kwargs):
    # Add the line in the database
    table = model_from_table_name(table_name)

    row = table()
    for key, value in kwargs.items():

        # Convert value in terms of datatype
        column_type = row.__table__.columns[key].type

        if isinstance(column_type, Integer):
            value = int(value)

        elif isinstance(column_type, Boolean):
            if value.isnumeric():
                value = int(value)
            value = bool(value)

        elif isinstance(column_type, String):
            value = str(value)

        elif isinstance(column_type, DateTime):
            value = pd.to_datetime(value)

        setattr(row, key, value)

    db.session.add(row)
    db.session.commit()

    return row.id


@app.callback(
    Output("bdd-table", "columns"),
    Output("bdd-table", "data"),
    Output("bdd-notification", "is_open"),
    Output("bdd-notification", "header"),
    Output("bdd-notification", "children"),
    Output("bdd-notification", "icon"),
    Input("bdd-dropdown", "value"),
    Input("bdd-button-add-line", "n_clicks"),
    Input("bdd-button-reset-table", "n_clicks"),
    Input("bdd-table", "data_timestamp"),
    Input("bdd-input-filter", "value"),
    State("bdd-table", "columns"),
    State("bdd-table", "data"),
    State("bdd-table", "data_previous"),
    State("bdd-dropdown", "value"),
    prevent_initial_call=True,
)
def sync_table_and_bdd_data(
    dropdown_value,
    n_clicks_add_line,
    n_clicks_drop_load_table,
    data_timestamp,
    string_filter,
    columns,
    data,
    data_previous,
    table_name,
):

    notification = {"is_open": False, "header": "", "body": "", "icon": "primary"}

    ctx = callback_context
    triggered = ctx.triggered[0]["prop_id"].split(".")[0]

    query, schema, binding = None, None, None
    if table_name:
        query = f"select * from {table_name}"
        if string_filter:
            query += f" where {string_filter}"

        binding = db.session.bind
        d_bind = {
            "exane": "exane_analyse",
            "analyse": "exane_analyse",
            "risque": "exane_risque",
            "derives": "exane_derives",
            "crs": "exane_contrib",
            "contribnext": "exane_contrib",
        }
        if "." in table_name:
            schema = table_name.split(".")[0]
            bind = d_bind.get(schema)
            binding = db.get_engine(server, bind)

    if triggered == "bdd-dropdown":
        try:
            df = pd.read_sql(query, binding)

        # If the table is missing, create it before fetching the data
        except OperationalError:
            table = model_from_table_name(table_name)
            table.__table__.create(db.engine)
            df = pd.read_sql(f"select * from {table_name}", db.session.bind)
        except Exception as e:
            server.logger.exception(e)
        finally:
            columns = [{"name": i, "id": i} for i in df.columns]
            try:
                data = df.to_dict("records")
            except Exception as e:
                server.logger.exception(e)
            return [columns, data] + list(notification.values())

    elif triggered == "bdd-table":
        if not schema:
            # Check if a Row has been deleted
            if len(data) != len(data_previous):

                # Find which row has been deleted and update db
                id_deleted = None
                for x in data_previous:
                    if x and x not in data:
                        id_deleted = x.get("id")

                if id_deleted:
                    # Delete the row in the database
                    table = model_from_table_name(table_name)
                    table.query.filter_by(id=id_deleted).delete()
                    db.session.commit()

                if schema:
                    table.query.filter(
                        table.flag_typologie == 3, table.code_valeur_typee == 46279680
                    ).delete()
                    db.session.commit()

            # If you are here, one or more cells have been updated
            # We compare the data in the table with the data in the database
            for i, data_row in enumerate(data):

                id = data_row.get("id")

                # Check if the row has an ID. If not, user added several lines at once
                if not id:

                    try:
                        # Insert the data in the database and set the ID
                        data_row = {k: v for k, v in data_row.items() if v}
                        id = new_line_in_table(table_name, **data_row)
                        data_row["id"] = id

                    except IntegrityError as e:
                        notification = {
                            "is_open": True,
                            "header": "Can't update table data",
                            "body": html.P(f"{e}", className="mb-0"),
                            "icon": "danger",
                        }

                if id:
                    table = model_from_table_name(table_name)
                    data_db = table.query.filter_by(id=id).first()
                    if data_db:
                        for key, value in data_row.items():
                            # Check if some values are different than local DB
                            if value != getattr(data_db, key):

                                # Convert value in terms of datatype
                                type = data_db.__table__.columns[key].type
                                if isinstance(type, Boolean):
                                    if value.isnumeric():
                                        value = int(value)
                                    value = bool(value)
                                if isinstance(type, DateTime):
                                    value = pd.to_datetime(value)

                                setattr(data_db, key, value)
                        db.session.commit()

        else:
            notification = {
                "is_open": True,
                "header": "Warning",
                "body": html.P("You can't edit Exane's DB", className="mb-0"),
                "icon": "danger",
            }

    # If user wants to add a line in the first table
    elif table_name and triggered == "bdd-button-add-line":
        if not schema:
            # Insert new line in the database
            data.append([])
            return [columns, data] + list(notification.values())
        else:
            notification = {
                "is_open": True,
                "header": "Warning",
                "body": html.P("You can't edit Exane's DB", className="mb-0"),
                "icon": "danger",
            }

    # If user wants to reset a table
    elif table_name and triggered == "bdd-button-reset-table":
        table = model_from_table_name(table_name)
        try:
            table.__table__.drop(db.engine)
        except Exception as e:
            server.logger.exception(f"Error Dropping {table_name} | {e}")
        table.__table__.create(db.engine)
        msg = f"You have successfully dropped and created {table_name}"
        notification = {
            "is_open": True,
            "header": "Reset Table",
            "body": html.P(msg, className="mb-0"),
            "icon": "success",
        }

    if table_name:
        df = pd.read_sql(query, binding)
        columns = [{"name": i, "id": i} for i in df.columns]
        data = df.to_dict("records")
    else:
        notification = {
            "is_open": True,
            "header": "No table selected",
            "body": html.P("Select a table in the dropdown", className="mb-0"),
            "icon": "danger",
        }

    return [columns, data] + list(notification.values())

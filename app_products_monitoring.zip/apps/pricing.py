import uuid

import dash_bootstrap_components as dbc
from dash import dcc
from dash import html
from dash import callback_context
from dash.dependencies import Input, Output, State
from dash.exceptions import PreventUpdate
from dash.dash_table.Format import Format
from dash.dash_table import DataTable

from app import app
from utils.api_sg import SGPricer
from utils.sql import *

colors = {"red": "#c0392b", "green": "#16a085"}

background_colors = {
    "red": "rgba(231, 76, 60, 0.1)",
    "green": "rgba(22, 160, 133, 0.1)",
    "blue": "rgba(52, 152, 219, 0.1)",
}

style_hidden = {"display": "none"}

try:
    sg = SGPricer()

    underlyings = sg.underlying_universe()

    options_tickers = [
        {
            # "label": f"{x['BloombergTickerCode']} - {x['Name']}",
            "label": x["BloombergTickerCode"],
            "value": x["BloombergTickerCode"],
        }
        for x in underlyings["EquityUnderlyings"]
    ]

    params = {
        "pricing_id": {
            "id": "pricing_id",
            "name": "ID",
            "default": "",
            "type": "text",
            "hideable": True,
        },
        "timestamp": {
            "id": "timestamp",
            "name": "Date & Time",
            "default": "",
            "type": "datetime",
        },
        "wrapper": {
            "id": "wrapper",
            "name": "Wrapper",
            "presentation": "dropdown",
            "default": "Note",
            "type": "text",
            "dropdown": {
                "options": [
                    {"label": "Note", "value": "Note"},
                    # {"label": "OTC", "value": "OTC"},
                ],
                "clearable": False,
            },
        },
        "ccy": {
            "id": "ccy",
            "name": "Ccy",
            "default": "USD",
            "type": "text",
            "presentation": "dropdown",
            "dropdown": {
                "options": [
                    {"label": "EUR", "value": "EUR"},
                    {"label": "USD", "value": "USD"},
                    {"label": "CHF", "value": "CHF"},
                    {"label": "GBP", "value": "GBP"},
                    {"label": "CAD", "value": "CAD"},
                ],
                "clearable": False,
            },
        },
        "payoff": {
            "id": "payoff",
            "name": "Payoff",
            "default": "Autocall",
            "type": "text",
            "presentation": "dropdown",
            "dropdown": {
                "options": [
                    {"label": "Autocall", "value": "Autocall"},
                    {"label": "Reverse", "value": "Reverse"},
                ],
                "clearable": False,
            },
        },
        "option_type": {
            "id": "option_type",
            "name": "Type",
            "default": "WorstOf",
            "type": "text",
            "presentation": "dropdown",
            "dropdown": {
                "options": [
                    {"label": "WorstOf", "value": "WorstOf"},
                    # {"label": "Basket", "value": "Basket"},
                ],
                "clearable": False,
            },
        },
        "frequency": {
            "id": "frequency",
            "name": "Frequency",
            "default": "3M",
            "type": "text",
            "presentation": "dropdown",
            "dropdown": {
                "options": [
                    {"label": "1M", "value": "1M"},
                    {"label": "3M", "value": "3M"},
                    {"label": "6M", "value": "6M"},
                    {"label": "12M", "value": "12M"},
                ],
                "clearable": False,
            },
        },
        "maturity_in_months": {
            "id": "maturity_in_months",
            "name": "Maturity",
            "default": 18,
            "type": "numeric",
            "validation": {"default": 18},
            "on_change": {"action": "coerce", "failure": "default"},
        },
        "ul_1": {
            "id": "ul_1",
            "name": "UL 1",
            "default": "SPX",
            "presentation": "dropdown",
            "dropdown": {"options": options_tickers, "clearable": False},
        },
        "ul_2": {
            "id": "ul_2",
            "name": "UL 2",
            "default": "",
            "presentation": "dropdown",
            "dropdown": {"options": options_tickers, "clearable": True},
        },
        "ul_3": {
            "id": "ul_3",
            "name": "UL 3",
            "default": "",
            "presentation": "dropdown",
            "dropdown": {"options": options_tickers, "clearable": True},
        },
        "ul_4": {
            "id": "ul_4",
            "name": "UL 4",
            "default": "",
            "type": "text",
            "presentation": "dropdown",
            "dropdown": {"options": options_tickers, "clearable": True},
            "hideable": True,
        },
        "ul_5": {
            "id": "ul_5",
            "name": "UL 5",
            "default": "",
            "type": "text",
            "presentation": "dropdown",
            "dropdown": {"options": options_tickers, "clearable": True},
            "hideable": True,
        },
        "barrier_type": {
            "id": "barrier_type",
            "name": "Barrier Type",
            "default": "European",
            "presentation": "dropdown",
            "dropdown": {
                "options": [
                    {"label": "European", "value": "European"},
                    {"label": "US Intraday", "value": "US Intraday"},
                    {"label": "US Close", "value": "US Close"},
                    {"label": "None", "value": "None"},
                ],
                "clearable": False,
            },
        },
        "strike": {
            "id": "strike",
            "name": "Strike",
            "default": 100,
            "type": "numeric",
            "validation": {"default": 100},
            "on_change": {"action": "coerce", "failure": "default"},
        },
        "ki_barrier": {
            "id": "ki_barrier",
            "name": "Barrier",
            "default": 70,
            "validation": {"default": 70},
            "on_change": {"action": "coerce", "failure": "default"},
        },
        "atk_barrier": {
            "id": "atk_barrier",
            "name": "Autocall",
            "default": 100,
            "validation": {"default": 100},
            "on_change": {"action": "coerce", "failure": "default"},
        },
        "atk_start_period": {
            "id": "atk_start_period",
            "name": "Start Period",
            "default": 1,
            "validation": {"default": 1},
            "on_change": {"action": "coerce", "failure": "default"},
        },
        "cpn_type": {
            "id": "cpn_type",
            "name": "Type Coupon",
            "default": "Memory",
            "presentation": "dropdown",
            "dropdown": {
                "options": [
                    {"label": "Memory", "value": "Memory"},
                    {"label": "Conditional", "value": "Conditional"},
                    {"label": "Fixed", "value": "Fixed"},
                ],
                "clearable": False,
            },
        },
        "cpn_barrier": {
            "id": "cpn_barrier",
            "name": "Coupon Barrier",
            "default": 70,
            "type": "numeric",
            "validation": {"default": 70},
            "on_change": {"action": "coerce", "failure": "default"},
        },
        "reoffer": {
            "id": "reoffer",
            "name": "Reoffer",
            "default": 98,
            "type": "numeric",
            "validation": {"default": 98},
            "on_change": {"action": "coerce", "failure": "default"},
        },
        "cpn_pa": {
            "id": "cpn_pa",
            "name": "Coupon p.a.",
            "editable": False,
            "default": "",
            "type": "numeric",
            "format": Format(precision=3),
        },
    }
except Exception as e:
    msg = "Issue launching SG service"
    app.logger.exception(msg)


def set_default_pricing_row():
    default = {i: params[i].get("default") for i in params}
    # Add pricing id as unique random key
    default["pricing_id"] = str(uuid.uuid4())
    return [default]


def serve_layout():

    body_pricing = dbc.Container(
        [
            dbc.Row(
                [
                    dbc.Col(html.H1("Pricing Parameters"), align="center", width=8),
                    dbc.Col(
                        dbc.Row(
                            [
                                dbc.Col(
                                    dbc.Button(
                                        "Add Row",
                                        id="button-add-pricing-row",
                                        n_clicks=0,
                                    ),
                                    width=4,
                                ),
                                dbc.Col(
                                    dbc.Button(
                                        dbc.Spinner(
                                            html.Div(
                                                "Price",
                                                id="button-pricing-spinner",
                                            ),
                                            size="sm",
                                            type="grow",
                                            color="secondary",
                                        ),
                                        id="button-pricing",
                                        n_clicks=0,
                                        color="primary",
                                    ),
                                    width=4,
                                ),
                            ],
                            justify="end",
                        ),
                        width=4,
                    ),
                ],
                className="mb-4",
            ),
            dbc.Row(  # Table of the Pricing Parameters
                [
                    dbc.Col(
                        [
                            DataTable(
                                id="table-pricing",
                                columns=[{**params[x]} for x in params],
                                dropdown={
                                    i: params[i]["dropdown"]
                                    for i in params
                                    if "dropdown" in params[i]
                                },
                                editable=True,
                                row_deletable=True,
                                hidden_columns=[
                                    "pricing_id",
                                    "timestamp",
                                    "option_type",
                                    "ul_4",
                                    "ul_5",
                                ],
                                style_header={
                                    "fontWeight": "bold",
                                    "backgroundColor": "white",
                                },
                                style_cell={
                                    # "overflow": "hidden",
                                    "textOverflow": "ellipsis",
                                    "minWidth": "0px",
                                    "padding": "5px",
                                    "font-family": "Roboto",
                                    "font-size": "12px",
                                    "text-align": "left",
                                    "backgroundColor": "transparent",
                                    "padding-top": "10px",
                                    "padding-bottom": "10px",
                                    "border-top": "0.1px solid rgb(240, 240, 240)",
                                    "border-bottom": "0.1px solid rgb(240, 240, 240)",
                                    "border-right": " 0px",
                                    "border-left": "0px",
                                },
                                style_data_conditional=[
                                    {
                                        "if": {"column_id": "wrapper"},
                                        "maxWidth": "65px",
                                    },
                                    {"if": {"column_id": "ccy"}, "maxWidth": "45px"},
                                    {"if": {"column_id": "payoff"}, "maxWidth": "70px"},
                                    {"if": {"column_id": "type"}, "maxWidth": "70px"},
                                    {
                                        "if": {"column_id": "frequency"},
                                        "maxWidth": "70px",
                                    },
                                    {
                                        "if": {"column_id": "ul_1"},
                                        "maxWidth": "85px",
                                    },
                                    {
                                        "if": {"column_id": "ul_2"},
                                        "maxWidth": "85px",
                                    },
                                    {
                                        "if": {"column_id": "ul_3"},
                                        "maxWidth": "85px",
                                    },
                                    {
                                        "if": {"column_id": "ul_4"},
                                        "maxWidth": "85px",
                                    },
                                    {
                                        "if": {"column_id": "ul_5"},
                                        "maxWidth": "85px",
                                    },
                                    {
                                        "if": {"column_id": "barrier_type"},
                                        "maxWidth": "90px",
                                    },
                                    {
                                        "if": {"column_id": "strike"},
                                        "maxWidth": "65px",
                                    },
                                    {
                                        "if": {"column_id": "cpn_type"},
                                        "maxWidth": "90px",
                                    },
                                    {
                                        "if": {"column_id": "cpn_pa"},
                                        "maxWidth": "90px",
                                        "color": colors["green"],
                                    },
                                    {
                                        "if": {
                                            "column_id": "atk_barrier",
                                            "filter_query": '{payoff} eq "Reverse"',
                                        },
                                        "color": "rgba(189, 195, 199, 0.1)",
                                        "cursor": "not-allowed",
                                    },
                                    {
                                        "if": {
                                            "column_id": "atk_start_period",
                                            "filter_query": '{payoff} eq "Reverse"',
                                        },
                                        "color": "rgba(189, 195, 199, 0.1)",
                                        "cursor": "not-allowed",
                                    },
                                    {
                                        "if": {
                                            "column_id": "cpn_barrier",
                                            "filter_query": '{cpn_type} eq "Fixed"',
                                        },
                                        "color": "rgba(189, 195, 199, 0.1)",
                                        "cursor": "not-allowed",
                                    },
                                    {
                                        "if": {
                                            "column_id": "ki_barrier",
                                            "filter_query": '{barrier_type} eq "Put"',
                                        },
                                        "color": "rgba(189, 195, 199, 0.1)",
                                        "cursor": "not-allowed",
                                    },
                                    {
                                        "if": {
                                            "column_id": "cpn_pa",
                                            "filter_query": '{cpn_pa} eq "N/A"',
                                        },
                                        "color": colors["red"],
                                    },
                                    {
                                        "if": {
                                            "column_id": "maturity_in_months",
                                            "filter_query": "{maturity_in_months} lt 6 or {maturity_in_months} gt 60",
                                        },
                                        "color": colors["red"],
                                        "backgroundColor": background_colors["red"],
                                    },
                                    {
                                        "if": {
                                            "column_id": "strike",
                                            "filter_query": "{strike} lt 50 or {strike} gt 100",
                                        },
                                        "color": colors["red"],
                                        "backgroundColor": background_colors["red"],
                                    },
                                    {
                                        "if": {
                                            "column_id": "ki_barrier",
                                            "filter_query": "{ki_barrier} lt 50 or {ki_barrier} gt 100",
                                        },
                                        "color": colors["red"],
                                        "backgroundColor": background_colors["red"],
                                    },
                                    {
                                        "if": {
                                            "column_id": "atk_barrier",
                                            "filter_query": "{atk_barrier} lt 50 or {atk_barrier} gt 1000",
                                        },
                                        "color": colors["red"],
                                        "backgroundColor": background_colors["red"],
                                    },
                                    {
                                        "if": {
                                            "column_id": "atk_start_period",
                                            "filter_query": "{atk_start_period} lt 1",
                                        },
                                        "color": colors["red"],
                                        "backgroundColor": background_colors["red"],
                                    },
                                    {
                                        "if": {
                                            "column_id": "cpn_barrier",
                                            "filter_query": "{cpn_barrier} lt 50 or {cpn_barrier} gt 1000",
                                        },
                                        "color": colors["red"],
                                        "backgroundColor": background_colors["red"],
                                    },
                                    {
                                        "if": {
                                            "column_id": "reoffer",
                                            "filter_query": "{reoffer} lt 0 or {cpn_barrier} gt 100",
                                        },
                                        "color": colors["red"],
                                        "backgroundColor": background_colors["red"],
                                    },
                                    {
                                        "if": {
                                            "column_id": "cpn_pa",
                                            "filter_query": "{cpn_pa} lt 0",
                                        },
                                        "color": colors["red"],
                                        "backgroundColor": background_colors["red"],
                                    },
                                    {
                                        "if": {"state": "active"},
                                        "backgroundColor": background_colors["blue"],
                                        "border": "none",
                                        "color": "rgb(44, 62, 80)",
                                        "border-top": "1px solid rgb(236, 240, 241)",
                                        "border-bottom": "1px solid rgb(236, 240, 241)",
                                    },
                                    {
                                        "if": {"state": "selected"},
                                        "backgroundColor": background_colors["blue"],
                                        "border-top": "1px solid rgb(236, 240, 241)",
                                        "border-bottom": "1px solid rgb(236, 240, 241)",
                                    },
                                ],
                            ),
                        ]
                    )
                ],
                className="mb-2",
            ),
        ],
        style={"maxWidth": "80%"},
        className="borded-card p-5 mt-3 mb-5 container-fluid",
    )

    body_previous_results = dbc.Container(
        [
            dbc.Row(
                [
                    dbc.Col(
                        [
                            html.H1("Pricing Results", className="mb-3"),
                            html.P(
                                "Here are your last pricing results. You can add a line in your pricing parameters by clicking on the corresponding circle"
                            ),
                        ],
                        align="center",
                        width=8,
                    ),
                    dbc.Col(
                        dbc.Row(
                            [
                                dbc.Col(
                                    dbc.Button("Clear", id="button-clear-results"),
                                    width=4,
                                ),
                            ],
                            justify="end",
                        ),
                        width=4,
                    ),
                ],
                className="mb-4",
            ),
            dbc.Row(  # Table of the Pricing Results
                [
                    dbc.Col(
                        [
                            DataTable(
                                id="table-results",
                                # row_deletable=True,
                                row_selectable="single",
                                filter_action="native",
                                fixed_rows={"headers": True},
                                style_table={"maxHeight": 400},  # defaults to 500
                                # sort_action="none",
                                hidden_columns=[
                                    "pricing_id",
                                    "option_type",
                                    "ul_4",
                                    "ul_5",
                                ],
                                columns=[{**params[x]} for x in params],
                                style_header={"fontWeight": "bold"},
                                style_cell={
                                    "textOverflow": "ellipsis",
                                    "minWidth": "0px",
                                    "padding": "5px",
                                    "font-family": "Roboto",
                                    "font-size": "12px",
                                    "text-align": "left",
                                    "backgroundColor": "transparent",
                                    "padding-top": "10px",
                                    "padding-bottom": "10px",
                                    "border-top": "0.1px solid rgb(240, 240, 240)",
                                    "border-bottom": "0.1px solid rgb(240, 240, 240)",
                                    "border-right": " 0px",
                                    "border-left": "0px",
                                },
                                style_data_conditional=[
                                    {
                                        "if": {"column_id": "timestamp"},
                                        "maxWidth": "135px",
                                    },
                                    {
                                        "if": {"column_id": "wrapper"},
                                        "maxWidth": "65px",
                                    },
                                    {"if": {"column_id": "ccy"}, "maxWidth": "45px"},
                                    {"if": {"column_id": "payoff"}, "maxWidth": "70px"},
                                    {"if": {"column_id": "type"}, "maxWidth": "70px"},
                                    {
                                        "if": {"column_id": "frequency"},
                                        "maxWidth": "70px",
                                    },
                                    {
                                        "if": {"column_id": "ul_1"},
                                        "maxWidth": "70px",
                                    },
                                    {
                                        "if": {"column_id": "ul_2"},
                                        "maxWidth": "70px",
                                    },
                                    {
                                        "if": {"column_id": "ul_3"},
                                        "maxWidth": "70px",
                                    },
                                    {
                                        "if": {"column_id": "barrier_type"},
                                        "maxWidth": "90px",
                                    },
                                    {
                                        "if": {"column_id": "strike"},
                                        "maxWidth": "65px",
                                    },
                                    {
                                        "if": {"column_id": "cpn_type"},
                                        "maxWidth": "90px",
                                    },
                                    {
                                        "if": {"column_id": "cpn_pa"},
                                        "maxWidth": "90px",
                                        "color": colors["green"],
                                    },
                                    {
                                        "if": {
                                            "column_id": "atk_barrier",
                                            "filter_query": '{payoff} eq "Reverse"',
                                        },
                                        "color": "rgba(189, 195, 199, 0.1)",
                                        "cursor": "not-allowed",
                                    },
                                    {
                                        "if": {
                                            "column_id": "atk_start_period",
                                            "filter_query": '{payoff} eq "Reverse"',
                                        },
                                        "color": "rgba(189, 195, 199, 0.1)",
                                        "cursor": "not-allowed",
                                    },
                                    {
                                        "if": {
                                            "column_id": "cpn_barrier",
                                            "filter_query": '{cpn_type} eq "Fixed"',
                                        },
                                        "color": "rgba(189, 195, 199, 0.1)",
                                        "cursor": "not-allowed",
                                    },
                                    {
                                        "if": {
                                            "column_id": "ki_barrier",
                                            "filter_query": '{barrier_type} eq "Put"',
                                        },
                                        "color": "rgba(189, 195, 199, 0.1)",
                                        "cursor": "not-allowed",
                                    },
                                    {
                                        "if": {
                                            "column_id": "cpn_pa",
                                            "filter_query": '{cpn_pa} eq "N/A"',
                                        },
                                        "color": colors["red"],
                                    },
                                    {
                                        "if": {"state": "active"},
                                        "backgroundColor": background_colors["blue"],
                                        "border": "none",
                                        "color": "rgb(44, 62, 80)",
                                        "border-top": "1px solid rgb(236, 240, 241)",
                                        "border-bottom": "1px solid rgb(236, 240, 241)",
                                    },
                                    {
                                        "if": {"state": "selected"},
                                        "backgroundColor": background_colors["blue"],
                                        "border-top": "1px solid rgb(236, 240, 241)",
                                        "border-bottom": "1px solid rgb(236, 240, 241)",
                                    },
                                ],
                            ),
                        ]
                    )
                ],
                className="mb-2",
            ),
        ],
        id="container-results",
        style=style_hidden,
        className="borded-card p-5 mt-3 mb-5 container-fluid",
    )

    prices_notification = dbc.Toast(
        id=f"notification-pricing",
        is_open=False,
        dismissable=True,
        duration=400000,
        icon="success",
        style={
            "position": "fixed",
            "top": 110,
            "right": 25,
            "width": 300,
        },
    )

    local_pricing_data = [
        dcc.Store(id="pricing-parameters", storage_type="local"),
        dcc.Store(id="pricing-results", storage_type="local"),
    ]

    last_modified_cells = [
        dcc.Store(id="last-cell-changed-parameters", storage_type="local"),
        dcc.Store(id="last-cell-changed-results", storage_type="local"),
    ]

    return [
        body_pricing,
        prices_notification,
        body_previous_results,
        *local_pricing_data,
        *last_modified_cells,
    ]


# @app.callback(
#     Output("button-add-pricing-row", "n_clicks"),
#     Input("keyboard", "keydown"),
#     State("button-add-pricing-row", "n_clicks"),
# )
# def trigger_close_line_with_ctrl_alt_c(keys, n_clicks):
#     if keys:
#         if keys["key"] == "c" and keys["altKey"] and keys["ctrlKey"]:
#             return n_clicks + 1
#     raise PreventUpdate


@app.callback(
    Output("table-pricing", "data"),
    Input("pricing-parameters", "data"),
)
def load_local_data_parameters(local_data):
    return local_data


@app.callback(
    Output("notification-pricing", "header"),
    Output("notification-pricing", "children"),
    Output("notification-pricing", "is_open"),
    Input("pricing-results", "data"),
)
def display_sg_prices_notifications(data):
    if data:
        level = data[-1].get("sg_cpn_pa")
        sg_id = data[-1].get("sg_id")
        return "Last SG Price Received", f"{sg_id} - Level: {level:.2f}%", True
    raise PreventUpdate


@app.callback(
    Output("pricing-parameters", "data"),
    Input("button-add-pricing-row", "n_clicks"),
    Input("table-results", "selected_rows"),
    Input("table-pricing", "data_timestamp"),
    Input("last-cell-changed-parameters", "data"),
    Input("pricing-results", "data"),
    State("pricing-parameters", "data"),
    State("table-pricing", "data"),
    State("table-pricing", "data_previous"),
)
def set_data_in_table_pricing_parameters(
    n_clicks,
    selected_rows_id,
    timestamp,
    cell_changed,
    data_results,
    data_local,
    data_table,
    data_table_previous,
):
    ctx = callback_context
    triggered = ctx.triggered[0]["prop_id"].split(".")[0]

    # If user deletes a Row of changes a cell
    if triggered == "table-pricing":
        # Check if a Row has been deleted
        if len(data_table) != len(data_table_previous):
            return data_table
        else:
            row_modif = int(cell_changed[0])
            # Reset the coupon value
            data_table[row_modif]["cpn_pa"] = ""
            # Update the pricing_id of the row of the modified cell
            data_table[row_modif]["pricing_id"] = str(uuid.uuid4())
            return data_table

    # If User adds a Row
    if triggered == "button-add-pricing-row":
        if data_local:
            if len(data_local) < 10:
                last_row = data_local[-1].copy()
                last_row["cpn_pa"] = ""
                # Add pricing id as unique random key
                last_row["pricing_id"] = str(uuid.uuid4())
                data_local.append(last_row)

    # If User wants to reprice from old quotes
    if triggered == "table-results":
        if not data_local:
            data_local = []
        row = data_results[::-1][selected_rows_id[0]]
        cleaned_row = {x: row[x] for x in params}
        data_local.append(cleaned_row)

    # Initialize data if local storage is empty
    if not data_local:
        data_local = set_default_pricing_row()

    # Add SG Result if any
    if data_results:
        if isinstance(data_results, list):
            for result in data_results:
                pricing_id = result.get("pricing_id")
                for row in data_local:
                    if pricing_id == row["pricing_id"]:
                        cpn_pa = result.get("sg_cpn_pa")
                        row["cpn_pa"] = cpn_pa if cpn_pa else "N/A"

    return data_local


@app.callback(
    Output("table-results", "data"),
    Output("container-results", "style"),
    # Input("button-add-pricing-row", "n_clicks"),
    Input("table-results", "data_timestamp"),
    Input("pricing-results", "data"),
)
def set_data_in_table_pricing_results(
    timestamp,
    data_results,
):
    # ctx = callback_context
    # triggered = ctx.triggered[0]["prop_id"].split(".")[0]
    if data_results:
        for result in data_results:
            best_issuer = "sg"
            cpn_pa = result["sg_cpn_pa"]
            result["cpn_pa"] = cpn_pa if cpn_pa else "N/A"
            timestamp = pd.to_datetime(result["sg_timestamp"])
            time = to_str_date(timestamp, "%b %d, %Y - %Hh%M")
            result["timestamp"] = time
        return data_results[::-1], {"maxWidth": "80%"}
    return [], style_hidden


default_result = [
    {
        "pricing_id": "c39be6d7-e8eb-4ce9-8ebc-c8e07c21f432",
        "sg_cpn_pa": 4.5064,
        "sg_id": "SGM-00004905142",
        "sg_timestamp": datetime.datetime(2020, 11, 26, 13, 26, 14, 854673),
    }
]


@app.callback(
    Output("pricing-results", "data"),
    Output("button-pricing-spinner", "children"),
    Input("button-pricing", "n_clicks"),
    Input("button-clear-results", "n_clicks"),
    State("pricing-parameters", "data"),
    State("pricing-results", "data"),
    State("table-results", "data"),
)
def send_price_requests(
    click_price, click_clear, pricing_params, data_results, table_results
):
    ctx = callback_context
    triggered = ctx.triggered[0]["prop_id"].split(".")[0]

    if triggered == "button-clear-results":
        return [], "Price"

    if triggered == "button-pricing":

        # Create DataFrame of the Pricing Parameters
        df_data = pd.DataFrame(pricing_params)

        # Prepare list of tickers for each row
        for row in pricing_params:
            tickers = [row[x] for x in row if "ul_" in x and row[x]]
            row["tickers"] = tickers

        # Send and get the prices from SocGen
        try:
            msg = "Prices | Sent " + ", ".join(
                [x["pricing_id"] for x in pricing_params]
            )
            app.logger.info(msg)

            sg_results = SGPricer().get_prices_pricer(pricing_params)

            msg = "Prices | Received: " + ", ".join(
                [
                    f"{x['pricing_id']} - {x['sg_id']} - Result: {x['sg_cpn_pa']:.2f}%"
                    for x in sg_results
                ]
            )
            app.logger.info(msg)

            # Create DataFrame of the Pricing Results
            df_result = pd.DataFrame(sg_results)

            app.logger.info("Prices | Step 1 Ok")

            # Merge Pricing Parameters with Pricing Results
            df = pd.merge(df_data, df_result, on="pricing_id", how="left")

            app.logger.info("Prices | Step 2 Ok")

            if not data_results:
                data_results = []
                app.logger.info("Prices | Step 2 bis Ok")

            data_results.extend(df.to_dict("records"))

            app.logger.info("Prices | Step 3 Ok")

            # Control size of the Pricing Results to max 30 quotes
            if len(data_results) > 30:
                data_results = data_results[-30:]

            app.logger.info("Prices | All good")

            return data_results, "Price"

        except Exception as e:
            app.logger.exception("Prices | Issue")

    raise PreventUpdate


app.clientside_callback(
    """
    function (input, old_input) {
        if(JSON.stringify(input) != JSON.stringify(old_input)) {
            for (i in Object.keys(input)) {
                newArray = Object.values(input[i])
                oldArray = Object.values(old_input[i])
                if (JSON.stringify(newArray) != JSON.stringify(oldArray)) {
                    entNew = Object.entries(input[i])
                    entOld = Object.entries(old_input[i])
                    for (const j in entNew) {
                        if (entNew[j][1] != entOld[j][1]) {
                            changeRef = [i, entNew[j][0]] 
                            break        
                        }
                    }
                }
            }
        }
        return changeRef
    }    
    """,
    Output("last-cell-changed-parameters", "data"),
    [Input("table-pricing", "data")],
    [State("table-pricing", "data_previous")],
)
"""Stores the last cell updated from the Pricing Parameters Table to a Store variable"""

app.clientside_callback(
    """
    function (input, old_input) {
        if(JSON.stringify(input) != JSON.stringify(old_input)) {
            for (i in Object.keys(input)) {
                newArray = Object.values(input[i])
                oldArray = Object.values(old_input[i])
                if (JSON.stringify(newArray) != JSON.stringify(oldArray)) {
                    entNew = Object.entries(input[i])
                    entOld = Object.entries(old_input[i])
                    for (const j in entNew) {
                        if (entNew[j][1] != entOld[j][1]) {
                            changeRef = [i, entNew[j][0]] 
                            break        
                        }
                    }
                }
            }
        }
        return changeRef
    }    
    """,
    Output("last-cell-changed-results", "data"),
    [Input("table-results", "data")],
    [State("table-results", "data_previous")],
)
"""Stores the last cell updated from the Pricing Results Table to a Store variable"""

import os
from app import app
from dash import dcc
from dash import html
import dash_bootstrap_components as dbc
from dash.dependencies import Input, Output, State
import requests as rq
from utils.api_crm import CrmPersonne
from os.path import isfile
from flask_login import current_user
from dash.exceptions import PreventUpdate

colors = {"red": "#c0392b", "green": "#16a085"}

import unicodedata
import re


def slugify(value, allow_unicode=False):
    """
    Taken from https://github.com/django/django/blob/master/django/utils/text.py
    Convert to ASCII if 'allow_unicode' is False. Convert spaces or repeated
    dashes to single dashes. Remove characters that aren't alphanumerics,
    underscores, or hyphens. Convert to lowercase. Also strip leading and
    trailing whitespace, dashes, and underscores.
    """
    value = str(value)
    if allow_unicode:
        value = unicodedata.normalize("NFKC", value)
    else:
        value = (
            unicodedata.normalize("NFKD", value)
            .encode("ascii", "ignore")
            .decode("ascii")
        )
    value = re.sub(r"[^\w\s-]", "", value.lower())
    return re.sub(r"[-\s]+", "-", value).strip("-_")


def serve_layout():

    user = {}
    try:
        user = {
            "first_name": current_user.displayname.split(" ")[0],
            "last_name": current_user.displayname.split(" ")[1],
            "email": current_user.email.lower(),
        }
    except:
        msg = "QR Code | Issue getting user parameters"
        app.logger.exception(msg)
    finally:
        return dbc.Container(
            [
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            html.Div(
                                                [
                                                    dbc.Label("Choose type"),
                                                    dbc.RadioItems(
                                                        options=[
                                                            {
                                                                "label": "URL",
                                                                "value": 1,
                                                            },
                                                            {
                                                                "label": "vCard",
                                                                "value": 2,
                                                            },
                                                        ],
                                                        value=1,
                                                        inline=True,
                                                        id="qrcode-input-type",
                                                    ),
                                                ]
                                            ),
                                        ),
                                        dbc.Col(
                                            [
                                                dbc.Spinner(
                                                    [
                                                        html.Div(
                                                            html.A(
                                                                html.I(
                                                                    className="fas fa-sync-alt dark-grey",
                                                                    style={
                                                                        "fontSize": "1.2rem"
                                                                    },
                                                                ),
                                                                # href="/",
                                                                target="_blank",
                                                                id="qrcode-icon-reload",
                                                            ),
                                                            n_clicks=0,
                                                            id="qrcode-button-reload",
                                                        ),
                                                        dbc.Tooltip(
                                                            "Delete Cached QR Codes",
                                                            target="qrcode-icon-reload",
                                                            placement="bottom",
                                                        ),
                                                    ],
                                                    size="sm",
                                                    type="grow",
                                                    color="secondary",
                                                    id="qrcode-button-reload-spinner",
                                                ),
                                            ],
                                            width=1,
                                        ),
                                    ]
                                ),
                                dbc.Row(
                                    dbc.Col(
                                        [  # URL Form Group
                                            html.Div(
                                                [
                                                    dbc.Input(
                                                        id="qrcode-input-url",
                                                        placeholder="Type your url",
                                                        type="text",
                                                        debounce=True,
                                                    ),
                                                    dbc.Input(
                                                        id="qrcode-input-color",
                                                        placeholder="Type your color, default: #353535",
                                                        type="text",
                                                        debounce=True,
                                                    ),
                                                ],
                                                id="qrcode-formgroup-url",
                                            ),
                                            # vCard Form Group
                                            html.Div(
                                                [
                                                    dbc.Input(
                                                        id="qrcode-input-firstname",
                                                        placeholder="First Name",
                                                        value=user.get("first_name"),
                                                        type="text",
                                                        debounce=True,
                                                    ),
                                                    dbc.Input(
                                                        id="qrcode-input-lastname",
                                                        placeholder="Name",
                                                        value=user.get("last_name"),
                                                        type="text",
                                                        debounce=True,
                                                    ),
                                                    dbc.Input(
                                                        id="qrcode-input-title",
                                                        placeholder="Title (Sales, Structurer, ...)",
                                                        type="text",
                                                        debounce=True,
                                                    ),
                                                    dbc.Input(
                                                        id="qrcode-input-email",
                                                        placeholder="Email",
                                                        value=user.get("email"),
                                                        type="email",
                                                        debounce=True,
                                                    ),
                                                    dbc.Input(
                                                        id="qrcode-input-linkedin",
                                                        placeholder="LinkedIn (default: http://solutions.exane.com/)",
                                                        type="url",
                                                        debounce=True,
                                                    ),
                                                    dbc.Input(
                                                        id="qrcode-input-phone-work",
                                                        placeholder="Phone Work",
                                                        type="tel",
                                                        debounce=True,
                                                    ),
                                                    dbc.Input(
                                                        id="qrcode-input-phone-mobile",
                                                        placeholder="Phone Mobile",
                                                        type="tel",
                                                        debounce=True,
                                                    ),
                                                ],
                                                id="qrcode-formgroup-vcard",
                                            ),
                                            dbc.Button(
                                                "Generate Code",
                                                id="qrcode-button-generate",
                                                n_clicks=0,
                                                size="sm",
                                                className="mr-1 my-3",
                                            ),
                                        ]
                                    )
                                ),
                            ],
                            width=5,
                            className="borded-card py-3 px-5",
                        ),
                        dbc.Col(
                            id="qrcode-image",
                            # style={"maxHeight": "520px", "overflow-y": "scroll"},
                            style={"textAlign": "center"},
                            width=5,
                            align="center",
                        ),
                    ],
                    justify="center",
                    align="center",
                    className="py-5",
                ),
                # dbc.Row(
                #     dbc.Col(
                #         id="qrcode-image",
                #         # style={"maxHeight": "520px", "overflow-y": "scroll"},
                #         style={"textAlign": "center"},
                #         width=6,
                #         align="center",
                #     ),
                #     align="center",
                #     justify="center",
                #     # className="borded-card",
                # ),
            ],
        )


@app.callback(
    Output("qrcode-button-reload-spinner", "children"),
    Input("qrcode-button-reload", "n_clicks"),
)
def data_delete_cached_qr_codes(n_clicks):
    if n_clicks > 0:
        working_dir = os.getcwd()
        path_qrcodes = os.path.join(working_dir, "assets/images/qrcodes")
        for f in os.listdir(path_qrcodes):
            if f not in ["center.png", "default_url.jpg", "default_vcard.jpg"]:
                path_f = os.path.join(path_qrcodes, f)
                os.remove(path_f)
                app.logger.info(f"Removed - QR Code {f}")
    raise PreventUpdate


@app.callback(
    Output("qrcode-formgroup-url", "style"),
    Output("qrcode-formgroup-vcard", "style"),
    Input("qrcode-input-type", "value"),
)
def display_type_form(value):
    hidden = {"display": "none"}
    display = {}
    if value == 1:
        return display, hidden
    return hidden, display


@app.callback(
    Output("qrcode-image", "children"),
    Input("qrcode-button-generate", "n_clicks"),
    Input("qrcode-input-type", "value"),
    State("qrcode-input-url", "value"),
    State("qrcode-input-color", "value"),
    State("qrcode-input-firstname", "value"),
    State("qrcode-input-lastname", "value"),
    State("qrcode-input-title", "value"),
    State("qrcode-input-email", "value"),
    State("qrcode-input-linkedin", "value"),
    State("qrcode-input-phone-work", "value"),
    State("qrcode-input-phone-mobile", "value"),
)
def display_generated_qrcode(
    n_clicks,
    type,
    value,
    color,
    first_name,
    last_name,
    title,
    email,
    linkedin,
    phone_work,
    phone_mobile,
):

    src = None

    if type == 1:
        default_src = "../assets/images/qrcodes/default_url.jpg"
    else:
        default_src = "../assets/images/qrcodes/default_vcard.jpg"

    if n_clicks:

        if type == 1:
            text = value
            filename = slugify(value + str(color or ""))

        else:
            filename = slugify(first_name + last_name)

            values = ["ORG:Exane Solutions"]

            if last_name and first_name:
                values.append(f"N:{last_name};{first_name};")
                values.append(f"FN:{last_name} {first_name}")

            if title:
                values.append(f"TITLE:{title}")

            if email:
                values.append(f"EMAIL;TYPE=Work:{email}")

            if linkedin:
                values.append(f"URL:{linkedin}")
            else:
                values.append("URL:http://solutions.exane.com/")

            if phone_work:
                values.append(f"TEL;TYPE=WORK:{phone_work}")

            if phone_mobile:
                waid = phone_mobile.replace(" ", "").replace("+", "")
                values.append(f"TEL;TYPE=CELL;type=VOICE;waid={waid}:{phone_mobile}")

            text_values = "\r\n".join(values)

            text = "BEGIN:VCARD\r\nVERSION:3.0\r\n{}\r\nEND:VCARD".format(text_values)

        url = "https://qrcode-supercharged.p.rapidapi.com/"
        src = f"assets/images/qrcodes/{filename}.jpg"

        json = {
            "text": text,
            "size": "600",
            "format": "png",
            "block_style": "round",
            "block_size": 0.7,
            "eye_style": "square",
            "gradient": 0,
            "gradient_type": "diagonal",
            "validate": 0,
            "gradient_color_start": "#008897",
            "gradient_color_end": "#4CB093",
            "logo_size": 0.25,
            "fg_color": color or "#353535",
            "bg_color": "#FFFFFF",
            "fill_logo": 0,
            "fill_logo_color": "#FFFFFF",
        }

        headers = {
            "x-rapidapi-key": "a39930e668mshb522999fd5b34a4p1b8f00jsn619ebb07c2bd",
            "x-rapidapi-host": "qrcode-supercharged.p.rapidapi.com",
        }

        files = {
            "logo_upload": (
                "center.png",
                open("assets/images/qrcodes/center.png", "rb"),
                "multipart/form-data",
                {"Expires": "0"},
            )
        }

        r = rq.post(url=url, params=json, files=files, headers=headers)

        if r.status_code == 200:
            with open(src, "wb") as f:
                f.write(r.content)

    return html.Img(src=src or default_src, height="400px")

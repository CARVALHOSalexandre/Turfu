from dash import dcc
from dash.dependencies import Input, Output, State, MATCH
from dash.exceptions import PreventUpdate

from utils.components import *
from utils.basics import to_str_date
from utils.api_open_positions import OpenPositions
from utils.osiris import (
    Osiris,
    structured_product_details_from_osiris_data,
    autocall_underlyings_details,
)
from models.menus_and_elements import turfu_subnav
from urllib.parse import urlencode, parse_qs

osiris = Osiris()


def is_valid_account(account):
    # Check if user input exists in all accounts
    accounts = OpenPositions().all_accounts_and_contacts()
    if any(d["institution"] == account for d in accounts):
        return True
    return False


def serve_layout(search=None):
    location = dcc.Location(
        id={"type": "url", "page": "clients"}, search=search, refresh=False
    )

    subnav = turfu_subnav("clients", style={"maxWidth": "85%"})

    title = html.Div([html.Div(id="clients-title"), html.Div(id="clients-subtitle")])

    body = html.Div(id="clients-positions")

    data = dcc.Store(id="contact-and-company", storage_type="memory")

    return [location, subnav, title, body, data]


@app.callback(
    Output("contact-and-company", "data"),
    Input("turfu-search-input", "value"),
    State({"type": "url", "page": "clients"}, "search"),
    State("contact-and-company", "data"),
)
def get_input_value_and_store_it(input, search, data):
    #
    if data:
        if not input:
            return

        if len(input) < 5:
            raise PreventUpdate

        # Check if user input exists in all accounts
        if is_valid_account(input):
            return input

    if search:
        value = parse_qs(search[1:])
        search_account = value.get("account")
        if search_account:
            if not input and is_valid_account(search_account[0]):
                return search_account[0]

    if not input or len(input) < 5:
        return

    # Check if user input exists in all accounts
    if is_valid_account(input):
        return input

    raise PreventUpdate


@app.callback(
    Output({"type": "url", "page": "clients"}, "search"),
    Input("contact-and-company", "data"),
)
def update_clients_url_with_account_name(data):
    if data:
        return "?" + urlencode({"account": data})
    return ""


@app.callback(
    Output({"type": "turfu-subnav", "page": "clients"}, "children"),
    Input("contact-and-company", "data"),
)
def update_clients_title(account_name):
    if account_name:
        return dbc.Row(  # First row of Products page
            [
                dbc.Col(  # Row of the Buttons and Details
                    [
                        dbc.Row(
                            [
                                dbc.Col(  # Name
                                    [
                                        html.H2(
                                            account_name,
                                            className="font-weight-bold m-0",
                                            style={
                                                "white-space": "nowrap",
                                                "text-overflow": "ellipsis",
                                                "overflow": "hidden",
                                                "color": "#2c3e50",
                                            },
                                        ),
                                    ],
                                ),
                            ],
                            className="mb-3",
                        ),
                        html.Div(id="clients-sales-and-contacts"),
                    ],
                    width=4,
                    align="center",
                ),
                dbc.Col(  # Main Figures
                    id="clients-main-figures", width=4, align="center"
                ),
                dbc.Col(  # Filters
                    [
                        dbc.Row(
                            dbc.Col(
                                html.P(
                                    "FILTERS",
                                    style={
                                        "fontFamily": "Roboto-Bold",
                                        "fontSize": "0.85rem",
                                        "color": "rgba(0, 0, 0, 0.54)",
                                    },
                                ),
                            )
                        ),
                        dbc.Row(
                            dbc.Col(
                                [
                                    html.P(
                                        "Sort Products",
                                        style={
                                            "fontFamily": "Roboto-Bold",
                                            "fontSize": "0.85rem",
                                        },
                                    ),
                                    html.Div(
                                        [
                                            dbc.RadioItems(
                                                options=[
                                                    {
                                                        "label": "Next Observation",
                                                        "value": 1,
                                                    },
                                                    {"label": "Bid Price", "value": 2},
                                                ],
                                                value=1,
                                                id="clients-filters-input",
                                            ),
                                        ]
                                    ),
                                ]
                            )
                        ),
                    ],
                    width=4,
                    align="center",
                ),
            ],
            justify="between",
            className="my-2 p-4",
        )
    return


@app.callback(
    Output("clients-sales-and-contacts", "children"),
    Output("clients-main-figures", "children"),
    Output("clients-positions", "children"),
    Input("contact-and-company", "data"),
)
def table_clients_positions(account):
    if not account:
        return None, None, None

    accounts = OpenPositions().all_accounts_and_contacts()
    products = OpenPositions().trades_for_account(account)

    list_contacts, list_sales = [], []
    for value in accounts:
        if value["institution"] == account:
            list_sales.append(value["vendeurRepreneur"])
            list_contacts.append(value["contact"])

    sales = ", ".join(set(list_sales))
    contacts = ", ".join(set(list_contacts))

    def bidask_or_spot(product):
        cfin = product["cfin"]
        bid = product["bid"]
        ask = product["ask"]
        mask = product["MAsk"]
        mbid = product["MBid"]
        init_bid = product["marginSaleBidInitial"]

        if bid is None:
            spot = product["spot"]
            if not spot:
                return html.H4(f"No Price")
            return html.H4(f"{product['devise']} {product['spot']:,.2f}")

        result = [dbc.Row(dbc.Col(html.H4(f"{bid:,.2f} / {ask:,.2f}"), width="auto"))]

        if mask is not None and mask != 0 and mbid is not None and mbid != 0:
            result.append(
                dbc.Row(
                    dbc.Col(
                        html.H6(f"{mbid:,.2f} / {mask:,.2f}"),
                        width="auto",
                        id=f"clients-margins-{cfin}",
                    ),
                )
            )
        else:
            result.append(
                dbc.Row(
                    dbc.Col(
                        html.H6("No Margins"),
                        width="auto",
                        id=f"clients-margins-{cfin}",
                    ),
                )
            )

        # Add tooltip with initial bid margin if was given
        if init_bid is not None:
            result.append(
                dbc.Tooltip(
                    f"Bid Margin Init: {init_bid:,.2f}",
                    target=f"clients-margins-{cfin}",
                    placement="bottom",
                )
            )
        else:
            result.append(
                dbc.Tooltip(
                    "No init margin in the Database",
                    target=f"clients-margins-{cfin}",
                    placement="bottom",
                )
            )

        return result

    # Go through all products to aggregate positions and set main figures
    cfins, agg_products = [], []
    nominal_in_eur, risk_bid = 0, 0
    for p in products:
        try:
            risk_bid += p["riskBidEuro"] if p["riskBidEuro"] else 0
            nominal_in_eur += p.get("poseTitre") * p.get("nominal") / p.get("fxRate")

            cfin = p["cfin"]
            if cfin not in cfins:
                cfins.append(p["cfin"])
                agg_products.append(p)
            else:
                for product in agg_products:
                    if product["cfin"] == cfin:
                        product["poseTitre"] += p["poseTitre"]

        except Exception as e:
            msg = f"Clients | Issue computing main figures for cfin: {p.get('cfin')}"
            app.logger.exception(msg)

    sales_and_contacts = dbc.Row(
        dbc.Col(
            [
                dbc.Row(
                    [
                        dbc.Col(
                            html.P(
                                f"Sales",
                                className="mb-0",
                                style={
                                    "fontFamily": "Roboto-Bold",
                                    "fontSize": "0.9rem",
                                },
                            ),
                            width="auto",
                        ),
                        dbc.Col(
                            html.P(
                                sales,
                                className="mb-0",
                                style={"fontFamily": "Roboto", "fontSize": "0.85rem"},
                            )
                        ),
                    ],
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            html.P(
                                f"Contacts",
                                className="mb-0",
                                style={
                                    "fontFamily": "Roboto-Bold",
                                    "fontSize": "0.9rem",
                                },
                            ),
                            width="auto",
                        ),
                        dbc.Col(
                            html.P(
                                contacts,
                                className="mb-0",
                                style={"fontFamily": "Roboto", "fontSize": "0.85rem"},
                            )
                        ),
                    ],
                ),
            ],
        ),
        className="my-3",
    )

    figures = [
        ("Cash in EUR", nominal_in_eur),
        ("Risk Bid in EUR", risk_bid),
        ("Nb Products", len(cfins)),
    ]

    main_figures = dbc.Col(
        [
            html.P(
                "OVERVIEW",
                style={
                    "fontFamily": "Roboto-Bold",
                    "fontSize": "0.85rem",
                    "color": "rgba(0, 0, 0, 0.54)",
                },
            ),
            dbc.Table(
                [
                    html.Tbody(
                        [
                            html.Tr(
                                [
                                    html.Td(
                                        x[0],
                                        className="p-0 pb-1",
                                        style={
                                            "fontFamily": "Roboto-Bold",
                                            # "fontSize": "1rem",
                                            "lineHeight": "1.25rem",
                                            "color": "rgba(0, 0, 0, 0.87)",
                                        },
                                    ),
                                    html.Td(
                                        f"{x[1]:,.0f}",
                                        className="p-0 pb-1",
                                        style={
                                            "textAlign": "right",
                                            # "fontSize": "1rem",
                                        },
                                    ),
                                ]
                            )
                            for x in figures
                        ]
                    )
                ],
                size="sm",
                borderless=True,
                className="mb-0",
            ),
        ],
        width=5,
    )

    rows_products = []
    for product in agg_products:
        rows_products.extend(
            [
                dbc.Row(
                    [
                        dbc.Col(  # MAIN DETAILS
                            [
                                dbc.Row(
                                    dbc.Col(
                                        html.P(
                                            "MAIN DETAILS",
                                            style={
                                                "fontFamily": "Roboto-Bold",
                                                "fontSize": "0.75rem",
                                                "color": "rgba(0, 0, 0, 0.54)",
                                            },
                                        ),
                                    )
                                ),
                                dbc.Row(  # Title with product's name
                                    [
                                        icon_termsheet(
                                            product["cfin"], className="pr-0 pt-1",
                                        ),
                                        dbc.Col(
                                            html.H4(
                                                product["instrumentLibelle"],
                                                style={
                                                    "white-space": "nowrap",
                                                    "text-overflow": "ellipsis",
                                                    "overflow": "hidden",
                                                },
                                            ),
                                            width=11,
                                        ),
                                    ],
                                    justify="start",
                                ),
                                dbc.Row(  # Codes and Size
                                    [
                                        dbc.Col(
                                            html.H6(
                                                product["cfin"],
                                                style={"fontWeight": 400},
                                            ),
                                            width="auto",
                                        ),
                                        dbc.Col(
                                            html.H6(
                                                product["isin"],
                                                style={"fontWeight": 400},
                                            ),
                                            width="auto",
                                        ),
                                        dbc.Col(
                                            html.H6(
                                                product["devise"],
                                                style={"fontWeight": 400},
                                            ),
                                            width="auto",
                                        ),
                                        dbc.Col(
                                            html.H6(
                                                f"{product['poseTitre']:,} units",
                                                style={"fontWeight": 400},
                                            ),
                                            width="auto",
                                        ),
                                    ],
                                    justify="start",
                                ),
                                html.Div(
                                    id={
                                        "type": "clients-product-next-observation",
                                        "cfin": product["cfin"],
                                    }
                                ),
                            ],
                            width=3,
                        ),
                        dbc.Col(  # PRODUCT DETAILS
                            id={
                                "type": "clients-product-details",
                                "cfin": product["cfin"],
                            },
                            width=7,
                            className="px-3",
                        ),
                        dbc.Col(  # BID / ASK & MARGINS
                            [
                                dbc.Row(
                                    dbc.Col(
                                        html.P(
                                            "BID / ASK & MARGINS",
                                            style={
                                                "fontFamily": "Roboto-Bold",
                                                "fontSize": "0.75rem",
                                                "color": "rgba(0, 0, 0, 0.54)",
                                            },
                                        ),
                                    )
                                ),
                                dbc.Row(dbc.Col(bidask_or_spot(product))),
                            ],
                            width=2,
                            className="px-4",
                        ),
                    ],
                    justify="between",
                    className="borded-card px-3 py-4 my-2",
                ),
            ]
        )

    positions = dbc.Container(rows_products, fluid=True, style={"maxWidth": "85%"},)

    return sales_and_contacts, main_figures, positions


@app.callback(
    Output({"type": "clients-product-next-observation", "cfin": MATCH}, "children"),
    Output({"type": "clients-product-details", "cfin": MATCH}, "children"),
    Input({"type": "url", "page": "clients"}, "href"),
    State({"type": "clients-product-details", "cfin": MATCH}, "id"),
)
def details_structured_product(href, id):
    # Check if the product is an Autocall or a Reverse Convertible
    data = osiris.cfin_details(id.get("cfin"))
    if data:
        # Get a list of details on the product
        details = structured_product_details_from_osiris_data(data)
        if details:
            result = []
            # Add Next Observation in the displayed results
            next_obs = details[0]
            formatted_date = to_str_date(next_obs[1])

            next_observation = dbc.Col(
                [
                    html.P(
                        "NEXT OBSERVATION",
                        style={
                            "fontFamily": "Roboto-Bold",
                            "fontSize": "0.75rem",
                            "color": "rgba(0, 0, 0, 0.54)",
                        },
                    ),
                    html.H4(formatted_date),
                ],
                width="auto",
                className="px-0 mt-3",
            )

            table_details = dbc.Table(
                [
                    html.Tbody(
                        [
                            html.Tr(
                                [
                                    html.Td(
                                        x[0],
                                        className="p-0 pb-1",
                                        style={
                                            "fontFamily": "Roboto-Bold",
                                            "fontSize": "0.75rem",
                                            "lineHeight": "1.25rem",
                                            "color": "rgba(0, 0, 0, 0.87)",
                                        },
                                    ),
                                    html.Td(
                                        x[1],
                                        className="p-0 pb-1",
                                        style={
                                            "textAlign": "right",
                                            "fontSize": "0.75rem",
                                        },
                                    ),
                                ]
                            )
                            for x in details[1:]
                        ]
                    )
                ],
                size="sm",
                borderless=True,
                className="mb-0",
            )

            df_ul = autocall_underlyings_details(data)
            d_ul = df_ul.to_dict("records")
            ul_columns = ["ticker", "name", "ccy", "strike", "perf"]

            tbody = []
            colors = {"red": "#c0392b", "green": "#16a085"}
            for row in d_ul:
                tr = []
                for col in ul_columns:
                    # Add color to performance in case positive / negative
                    if col == "perf":
                        value = f"{row[col]:,.2%}"
                        color = colors["red"] if "-" in value else colors["green"]
                        tr.append(html.Td(value, style={"color": color}))
                    else:
                        tr.append(html.Td(row[col]))
                tbody.append(html.Tr(tr))

            table_underlyings = dbc.Table(
                [
                    html.Thead(html.Tr([html.Th(x.title(),) for x in ul_columns])),
                    html.Tbody(tbody),
                ],
                size="sm",
                borderless=True,
                className="mb-0",
            )

            result.append(
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                html.P(
                                    "PRODUCT DETAILS",
                                    style={
                                        "fontFamily": "Roboto-Bold",
                                        "fontSize": "0.75rem",
                                        "color": "rgba(0, 0, 0, 0.54)",
                                    },
                                ),
                                table_details,
                            ],
                            width="auto",
                            className="px-4",
                        ),
                        dbc.Col(
                            [
                                html.P(
                                    "UNDERLYINGS",
                                    style={
                                        "fontFamily": "Roboto-Bold",
                                        "fontSize": "0.75rem",
                                        "color": "rgba(0, 0, 0, 0.54)",
                                        "padding-left": "0.5rem",
                                    },
                                ),
                                html.Div(table_underlyings, className="fancy-table",),
                            ],
                            width=5,
                            className="px-4",
                        ),
                    ],
                    justify="around",
                )
            )
            return next_observation, result

    raise PreventUpdate


# @app.callback(
#     Output("clients-subtitle-fade", "is_in"),
#     [Input("clients-subtitle", "n_clicks")],
#     [State("clients-subtitle-fade", "is_in")],
# )
# def toggle_fade(n, is_in):
#     if not n:
#         # Button has never been clicked
#         return True
#     return not is_in

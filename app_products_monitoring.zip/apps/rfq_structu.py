from dash import callback_context
from dash.dependencies import Input, Output, State, ALL, MATCH
from dash.exceptions import PreventUpdate
from dash import dcc
from dash import html
import dash_bootstrap_components as dbc
from flask_login import current_user

from utils.mail_watcher import get_mails_rfq_db, tag_mail_rfq, untag_mail_rfq
from utils.notifs import send_notif
from utils.components import *
from utils.basics import *
from app import app

import dash
import json


def rfq_card(
    email_object,
    email_body,
    email_author,
    email_tags,
    email_datetime,
    request_type,
    request_count,
    request_id,
):
    card = dbc.Card(
        [
            dbc.CardBody(
                [
                    dbc.Row(
                        [
                            dbc.Col(
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            dbc.Badge(
                                                "Live"
                                                if request_type == "Trading"
                                                else "Indic",
                                                pill=True,
                                                color="danger"
                                                if request_type == "Trading"
                                                else "success",
                                                className="mr-1",
                                                style={"font-size": "medium"},
                                            ),
                                            width="auto",
                                            align="center",
                                        ),
                                        dbc.Col(
                                            html.H5(
                                                email_author,
                                                className="mb-0 text-left",
                                            ),
                                            width="auto",
                                            align="center",
                                        ),
                                    ]
                                ),
                            ),
                            dbc.Col(
                                [
                                    html.Div(
                                        html.H3("...", id=f"rfq-popover-{request_id}"),
                                        id=f"rfq-popover-wrapper-{request_id}",
                                    ),
                                    dbc.Tooltip(
                                        dbc.Row(
                                            [
                                                dbc.Col(
                                                    dbc.Button(
                                                        "Tag"
                                                        if (
                                                            email_tags is None
                                                            or email_tags == ""
                                                        )
                                                        else "Untag",
                                                        id={
                                                            "type": "rfq-structu-tag-email-button",
                                                            "index": request_id,
                                                        },
                                                        size="sm",
                                                        color="secondary",
                                                    ),
                                                    width="auto",
                                                ),
                                                dbc.Col(
                                                    dbc.Button(
                                                        "RFQ",
                                                        id={
                                                            "type": "rfq-structu-rfq-button",
                                                            "index": request_id,
                                                        },
                                                        href="/rfq",
                                                        external_link=True,
                                                        target="_blank",
                                                        size="sm",
                                                        color="secondary",
                                                    ),
                                                    width="auto",
                                                ),
                                            ]
                                        ),
                                        target=f"rfq-popover-wrapper-{request_id}",
                                        placement="bottom",
                                        # autohide=False,
                                        delay={
                                            "show": 250,
                                            "hide": 400,
                                        },
                                    ),
                                ],
                                width="auto",
                                className="text-right",
                            ),
                        ],
                        justify="between",
                    ),
                    dbc.Row(
                        [
                            dbc.Col(
                                html.H3(email_object),
                                width=11,
                                align="center",
                            ),
                            dbc.Col(
                                [
                                    html.H6(
                                        email_datetime.strftime("%b %d, %Y"),
                                        className="mb-0",
                                    ),
                                    html.H6(email_datetime.strftime("%Hh%M")),
                                ],
                                width="1",
                                className="align-right text-right",
                            ),
                        ],
                        className="mt-2",
                    ),
                ]
                + [
                    dbc.Row(dbc.Col(html.P(f"Tagged by {email_tags}"), align="center"))
                    if email_tags
                    else dbc.Row(className="mt-2")
                ]
                + [
                    dbc.Row(
                        dbc.Col(
                            html.Div(
                                children="« " + email_body + " »",
                                id="rfq-body-div",
                                className="overflow-auto scrollable-div",
                                style={"max-height": "60px"},
                            )
                        ),
                    )
                ]
            ),
            # Hidden Components
            dbc.Toast(
                id={"type": "rfq-structu-card-toast", "index": request_id},
                icon="success",
                is_open=False,
                dismissable=True,
                duration=5000,
                headerClassName="home-notif-header",
                bodyClassName="home-notif-body",
                className="home-notif-toast",
            ),
            dcc.Store(
                id={"type": "rfq-structu-card-store", "index": request_id},
                storage_type="memory",
                data={
                    "tags": email_tags,
                    "object": email_object,
                    "last_datetime": email_datetime,
                    "type": request_type,
                    "count": request_count,
                    "body": email_body,
                },
            ),
            dbc.Modal(
                [
                    dbc.ModalHeader("Reply Mail"),
                    dbc.ModalBody(
                        dbc.Textarea(
                            className="mb-3",
                            id={
                                "type": "rfq-structu-modal-text-area",
                                "index": request_id,
                            },
                            autoFocus=True,
                            debounce=True,
                            placeholder="Write mail reply here...",
                            value=f"On it,\n\nThanks,\n{current_user.displayname.split(' ')[0]}",
                        )
                    ),
                    dbc.ModalFooter(
                        dbc.Button(
                            "Send Mail",
                            id={
                                "type": "rfq-structu-modal-send-button",
                                "index": request_id,
                            },
                        )
                    ),
                ],
                id={"type": "rfq-structu-modal", "index": request_id},
                size="xl",
                backdrop=True,
                centered=True,
                fade=True,
                is_open=False,
                keyboard=True,
                autoFocus=True,
            ),
            html.Div(
                id={"type": "rfq-structu-card-hidden-div", "index": request_id},
                style={"display": "none"},
            ),
        ]
    )
    return card


def serve_layout():
    location = dcc.Location(id={"type": "url", "page": "rfq-structu"}, refresh=True)
    body = dbc.Container(
        [
            # Live Request Row
            dbc.Row(
                [
                    dbc.Col(card_title("New Request(s)"), width=4, align="center"),
                    dbc.Col(
                        html.H5(
                            "",
                            style={"text-align": "center", "color": "rgb(191, 63, 63)"},
                        ),
                        width=4,
                        align="center",
                    ),
                    dbc.Col(
                        html.P(
                            id="rfq-structu-last-update-text",
                            style={"text-align": "right", "font-style": "italic"},
                        ),
                        width=4,
                        align="center",
                    ),
                    dbc.Col(dbc.Row(id="live-request-cards-row"), width=12),
                ],
                align="between",
                className="mt-5",
            ),
            # Tagged Request Row
            dbc.Row(
                [
                    dbc.Col(id="tagged-request-title-col", width=10),
                    dbc.Col(
                        dbc.Checklist(
                            id="rfq-structu-filter-checklist",
                            options=[
                                {
                                    "label": "Show All",
                                    "value": 1,
                                },
                            ],
                            value=[1],
                            inline=True,
                            switch=True,
                        ),
                        width="auto",
                    ),
                    dbc.Col(dbc.Row(id="tagged-request-cards-row"), width=12),
                ],
                justify="between",
                className="mt-5",
            ),
            # Hidden Components
            dcc.Interval(id="rfq-structu-interval", interval=5 * 60000, n_intervals=0),
            html.Div(id="rfq-structu-hidden-div", style={"display": "none"}),
        ],
        fluid=True,
        style={"maxWidth": "85%"},
    )
    return [location, body]


@app.callback(
    Output("rfq-structu-last-update-text", "children"),
    Output("live-request-cards-row", "children"),
    Output("tagged-request-cards-row", "children"),
    Output("tagged-request-title-col", "children"),
    Input({"type": "url", "page": "rfq-structu"}, "href"),
    Input("rfq-structu-interval", "n_intervals"),
    Input("header-notif-toast", "children"),
    Input("rfq-structu-filter-checklist", "value"),
)
def update_page(href, n, notif_header, checklist):
    # Get RFQ Data
    data = get_mails_rfq_db()
    df_requests = pd.DataFrame(data)

    # Filter The Dataframes
    df_tagged_requests = df_requests[df_requests["tags"] != ""]
    df_live_requests = df_requests[df_requests["tags"] == ""]

    # Filter Tagged Requests
    tagged_request_title = card_title("Tagged Request(s)")
    if 1 not in checklist:
        df_tagged_requests = df_tagged_requests[
            df_tagged_requests["tags"] == current_user.displayname.split(" ")[0]
        ]
        tagged_request_title = card_title("My Tagged Request(s)")

    # Convert The Dataframes
    tagged_requests = df_tagged_requests.to_dict(orient="records")
    live_requests = df_live_requests.to_dict(orient="records")

    # Last Update Text
    last_update = f"Last Update: {dt.now().strftime('%H:%M')}"

    # Set Requests Card Lists
    live_requests_cards = [
        dbc.Col(
            rfq_card(
                email_object=request.get("object"),
                email_body=request.get("body"),
                email_author=request.get("author"),
                email_tags=request.get("tags"),
                email_datetime=request.get("last_datetime"),
                request_type=request.get("type"),
                request_count=request.get("count"),
                request_id=request.get("id"),
            ),
            width=12,
            className="mb-2",
        )
        for request in live_requests
    ]
    tagged_requests_cards = [
        dbc.Col(
            rfq_card(
                email_object=request.get("object"),
                email_body=request.get("body"),
                email_author=request.get("author"),
                email_tags=request.get("tags"),
                email_datetime=request.get("last_datetime"),
                request_type=request.get("type"),
                request_count=request.get("count"),
                request_id=request.get("id"),
            ),
            width=12,
            className="mb-2",
        )
        for request in tagged_requests
    ]
    return last_update, live_requests_cards, tagged_requests_cards, tagged_request_title


@app.callback(
    Output({"type": "rfq-structu-modal", "index": MATCH}, "is_open"),
    Input({"type": "rfq-structu-tag-email-button", "index": MATCH}, "n_clicks"),
    Input({"type": "rfq-structu-modal-send-button", "index": MATCH}, "n_clicks"),
    State({"type": "rfq-structu-card-store", "index": MATCH}, "data"),
    State({"type": "rfq-structu-modal-text-area", "index": MATCH}, "value"),
    prevent_initial_call=True,
)
def tag_send_email(n_tag, n_send, email, reply_body):
    # Compute Trigger
    ctx = dash.callback_context
    trigger = ctx.triggered[0]["prop_id"].split(".")[0]
    trigger = json.loads(trigger).get("type")

    # Set Username
    user = current_user.displayname.split(" ")[0]

    # If Trigger is "Tag" or "Untag"
    if trigger == "rfq-structu-tag-email-button":
        if email.get("tags") == "":
            return True
        elif n_tag is not None and email.get("tags") != "":
            send_notif(
                header="RFQ Untagged",
                children=f"{email.get('object')} untagged by {user}",
                dpt_id="STR",
                icon="warning",
            )
            untag_mail_rfq(email)
            return False
    # ELSE Trigger Is "Send Mail"
    else:
        send_notif(
            header="RFQ Tagged",
            children=f"{email.get('object')} tagged by {user}",
            dpt_id="STR",
            icon="success",
        )
        tag_mail_rfq(email, user, reply_body)
        return False

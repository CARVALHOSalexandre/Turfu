import json
import dash_extensions as de
from dash import dcc
from sqlalchemy import func, or_
from utils.components import *
from dash import callback_context
from dash.exceptions import PreventUpdate
from dash.dash_table import DataTable
from dash.dependencies import Input, Output, State, MATCH, ALL
from local_db_mgt import ExcelFunction
from app import app, server, db


lottie_otions = dict(
    loop=True,
    autoplay=False,
    rendererSettings=dict(preserveAspectRatio="xMidYMid slice"),
)


def excel_lottie(name):
    return de.Lottie(
        options=dict(
            loop=False,
            autoplay=False,
            rendererSettings=dict(preserveAspectRatio="xMidYMid slice"),
        ),
        width=27,
        height=27,
        isStopped=True,
        id="home-lottie-eye",
        url=f"/lottie/{name}.json",
    )


def get_db_data(filter=None):
    try:
        if filter is not None and filter != "":
            filter = filter.lower()
            db_values = (
                ExcelFunction.query.filter(
                    or_(
                        func.lower(ExcelFunction.function).contains(filter),
                        func.lower(ExcelFunction.parameter).contains(filter),
                        func.lower(ExcelFunction.description).contains(filter),
                    )
                )
                .order_by(ExcelFunction.id.desc())
                .all()
            )
        else:
            db_values = ExcelFunction.query.order_by(ExcelFunction.id.desc()).all()
    except:
        try:
            ExcelFunction.__table__.create(db.session.bind)
            db_values = ExcelFunction.query.order_by(ExcelFunction.id.desc()).all()
        except Exception as e:
            server.logger.exception(e)
    finally:
        return [
            {
                "id": x.id,
                "function": x.function,
                "parameter": x.parameter,
                "description": x.description,
                "formula": x.formula,
                "output": x.output,
                "datetime": x.datetime.strftime("%Y-%m-%d"),
                "user": x.user,
            }
            for x in db_values
        ]


def serve_layout(search=None):

    return html.Div(
        [
            dcc.Location(
                id={"type": "url", "page": "excel"}, search=search, refresh=False
            ),
            dbc.Container(
                [
                    # Row of the Title and Filters
                    dbc.Row(
                        [
                            # Column of the Title
                            dbc.Col(
                                card_title("Excel Functions Documentation"), width=8
                            ),
                            # Column of the Filters
                            dbc.Col(
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            dbc.Checklist(
                                                id="excel-filter-checklist",
                                                options=[
                                                    {
                                                        "label": "EDS",
                                                        "value": 1,
                                                    },
                                                    {
                                                        "label": "EDH",
                                                        "value": 2,
                                                    },
                                                    {
                                                        "label": "EDP",
                                                        "value": 3,
                                                    },
                                                ],
                                                value=[1, 2, 3],
                                                inline=True,
                                                switch=True,
                                            ),
                                            width=8,
                                        ),
                                        dbc.Col(
                                            dbc.Input(
                                                id="excel-filter-input",
                                                type="text",
                                                debounce=True,
                                                placeholder="Filter by keywords...",
                                                value="",
                                            ),
                                            width=4,
                                        ),
                                    ],
                                    justify="center",
                                    align="center",
                                ),
                                width=4,
                            ),
                        ],
                        align="center",
                        justify="between",
                        className="mx-4",
                    ),
                    # Row with all the Tiles
                    dbc.Row(id="excel-cards-row", className="mx-2"),
                ],
                fluid=True,
                className="mt-3",
            ),
        ]
    )


def excel_function_card(function, parameter, description, formula, output, id):
    # If output is a json table
    if output is not None and output != "" and output[0] == "[":

        output = output.replace("'", '"').replace("None", "NaN")

        formula_output = f"{formula} returns:"

        df = pd.read_json(output)

        if "Date" in list(df.columns.values):
            df["Date"] = df["Date"].astype(str)

        card = dbc.Card(
            dbc.CardBody(
                html.Div(
                    [
                        html.Div(
                            [
                                html.Div(
                                    html.H4(
                                        str(function),
                                        className="card-function",
                                    ),
                                    style={"display": "inline-block"},
                                ),
                                html.Div(
                                    html.Div(
                                        excel_lottie("copy-to-clipboard"),
                                        style={
                                            "float": "right",
                                            "top": "0px",
                                            "display": "inline-block",
                                        },
                                        n_clicks=0,
                                        id={
                                            "type": "excel-copy-to-clipboard-lottie",
                                            "index": id,
                                        },
                                    ),
                                    style={
                                        "float": "right",
                                        "top": "0px",
                                        "display": "inline-block",
                                    },
                                    id=f"excel-copy-to-clipboard-lottie-wrapper-{id}",
                                ),
                                html.Div(
                                    html.Div(
                                        excel_lottie("script-eye"),
                                        style={
                                            "float": "right",
                                            "top": "0px",
                                            "display": "inline-block",
                                        },
                                        n_clicks=0,
                                        id={
                                            "type": "eye-lottie",
                                            "index": id,
                                        },
                                    ),
                                    style={
                                        "float": "right",
                                        "top": "0px",
                                        "display": "inline-block",
                                    },
                                    id=f"eye-wrapper-{id}",
                                ),
                                dbc.Tooltip(
                                    children="Copy Formula To Clipboard",
                                    target=f"excel-copy-to-clipboard-lottie-wrapper-{id}",
                                    # autohide=False,
                                    delay={"show": 250, "hide": 250},
                                    placement="bottom-left",
                                    class_name="p-2",
                                ),
                                dbc.Tooltip(
                                    children="Hide/Show Result Table",
                                    target=f"eye-wrapper-{id}",
                                    # autohide=False,
                                    delay={"show": 250, "hide": 250},
                                    placement="bottom-left",
                                    class_name="p-2",
                                ),
                            ],
                        ),
                        html.H5(str(parameter), className="card-parameter"),
                        html.P(str(description), className="card-description"),
                        html.P(" ", className="card-description"),
                        html.P("Example: ", className="card-description"),
                        html.I(str(formula_output), className="card-form_out"),
                        html.Div(
                            DataTable(
                                data=df.to_dict("records"),
                                columns=[{"name": i, "id": i} for i in df.columns],
                                id={
                                    "type": "excel-table-function",
                                    "index": id,
                                },
                                style_header={
                                    "fontWeight": "bold",
                                    "backgroundColor": "white",
                                },
                                style_cell={
                                    "textOverflow": "ellipsis",
                                    "minWidth": "0px",
                                    "padding": "5px",
                                    "font-family": "Roboto",
                                    "font-size": "12px",
                                    "text-align": "left",
                                    "backgroundColor": "transparent",
                                    "padding-top": "10px",
                                    "padding-bottom": "10px",
                                    "border-top": "0.1px solid rgb(240, 240, 240)",
                                    "border-bottom": "0.1px solid rgb(240, 240, 240)",
                                    "border-right": " 0px",
                                    "border-left": "0px",
                                },
                            ),
                            id={
                                "type": "excel-table-wrapper",
                                "index": id,
                            },
                            style={"display": "block", "margin-top": "20px"},
                        ),
                        dbc.Toast(
                            id={
                                "type": "excel-notif-clipboard",
                                "index": id,
                            },
                            icon="success",
                            header="Formula Copied to Clipboard",
                            is_open=False,
                            dismissable=True,
                            duration=5000,
                            headerClassName="home-notif-header",
                            bodyClassName="home-notif-body",
                            className="home-notif-toast",
                        ),
                        dcc.Store(
                            id={
                                "type": "excel-copy-to-clipboard-store",
                                "index": id,
                            },
                            storage_type="session",
                        ),
                    ],
                    id={
                        "type": "excel-div-wrapper",
                        "index": id,
                    },
                    className="table-responsive overflow-y-auto scrollable-div",
                    style={"minHeight": "165px", "maxHeight": "165px"},
                ),
            ),
            className="m-4 px-0",
        )
    else:
        formula_output = f"{formula} returns: {output}"
        card = dbc.Card(
            [
                dbc.CardBody(
                    [
                        html.Div(
                            [
                                html.Div(
                                    [
                                        html.Div(
                                            html.H4(
                                                str(function),
                                                className="card-function",
                                            ),
                                            style={"display": "inline-block"},
                                        ),
                                        html.Div(
                                            html.Div(
                                                excel_lottie("copy-to-clipboard"),
                                                style={
                                                    "float": "right",
                                                    "top": "0px",
                                                    "display": "inline-block",
                                                },
                                                n_clicks=0,
                                                id={
                                                    "type": "excel-copy-to-clipboard-lottie",
                                                    "index": id,
                                                },
                                            ),
                                            style={
                                                "float": "right",
                                                "top": "0px",
                                                "display": "inline-block",
                                            },
                                            id=f"excel-copy-to-clipboard-lottie-wrapper-2-{id}",
                                        ),
                                        dbc.Tooltip(
                                            children="Copy Formula To Clipboard",
                                            target=f"excel-copy-to-clipboard-lottie-wrapper-2-{id}",
                                            # autohide=False,
                                            delay={"show": 250, "hide": 250},
                                            placement="bottom-left",
                                            class_name="p-2",
                                        ),
                                    ],
                                ),
                                html.H5(str(parameter), className="card-parameter"),
                                html.P(str(description), className="card-description"),
                                html.P(" ", className="card-description"),
                                html.P("Example: ", className="card-description"),
                                html.I(str(formula_output), className="card-form_out"),
                                dbc.Toast(
                                    id={
                                        "type": "excel-notif-clipboard",
                                        "index": id,
                                    },
                                    icon="success",
                                    header="Formula Copied to Clipboard",
                                    is_open=False,
                                    dismissable=True,
                                    duration=5000,
                                    headerClassName="home-notif-header",
                                    bodyClassName="home-notif-body",
                                    className="home-notif-toast",
                                ),
                                dcc.Store(
                                    id={
                                        "type": "excel-copy-to-clipboard-store",
                                        "index": id,
                                    },
                                    storage_type="session",
                                    clear_data=True,
                                ),
                            ],
                            className="scrollable-div",
                            style={"minHeight": "165px", "maxHeight": "165px"},
                        ),
                    ],
                ),
            ],
            className="m-4",
        )
    return card


@app.callback(
    Output({"type": "excel-div-wrapper", "index": MATCH}, "style"),
    Output({"type": "excel-col-wrapper", "index": MATCH}, "width"),
    Input({"type": "eye-lottie", "index": MATCH}, "n_clicks"),
    State({"type": "excel-div-wrapper", "index": MATCH}, "style"),
    State({"type": "excel-table-function", "index": MATCH}, "columns"),
    prevent_initial_call=True,
)
def hide_show_output_table(click, style, columns):
    if style == {"minHeight": "165px", "maxHeight": "165px"}:
        style.pop("maxHeight", None)
        if len(columns) > 10:
            return style, 12
        elif len(columns) > 5:
            style["overflow-x"] = "hidden"
            return style, 8
        return style, 4

    return {"minHeight": "165px", "maxHeight": "165px"}, 4


@app.callback(
    Output("excel-cards-row", "children"),
    Input("excel-filter-checklist", "value"),
    Input("excel-filter-input", "value"),
)
def display_filtered_cards(function_filter, keywords_filter):

    functions = get_db_data()

    df = pd.DataFrame(functions)

    if 1 not in function_filter:
        df = df[df.function != "EDS"]

    if 2 not in function_filter:
        df = df[df.function != "EDH"]

    if 3 not in function_filter:
        df = df[df.function != "EDP"]

    if keywords_filter != "":
        keywords_filter = keywords_filter.strip().lower()
        df = df[
            (df["function"].str.lower().str.contains(keywords_filter))
            | (df["description"].str.lower().str.contains(keywords_filter))
            | (df["parameter"].str.lower().str.contains(keywords_filter))
        ]

    functions = json.loads(df.to_json(orient="records"))

    return [
        dbc.Col(
            excel_function_card(
                function=function["function"],
                parameter=function["parameter"],
                description=function["description"],
                formula=function["formula"],
                output=function["output"],
                id=function.get("id"),
            ),
            id={"type": "excel-col-wrapper", "index": function.get("id")},
            width=4,
            className="px-0",
        )
        for function in functions
    ]


@app.callback(
    Output({"type": "excel-copy-to-clipboard-store", "index": MATCH}, "data"),
    Output({"type": "excel-notif-clipboard", "index": MATCH}, "children"),
    Output({"type": "excel-notif-clipboard", "index": MATCH}, "is_open"),
    Input({"type": "excel-copy-to-clipboard-lottie", "index": MATCH}, "n_clicks"),
    prevent_initial_call=True,
)
def copy_to_store(click):

    if click > 0:

        ctx = callback_context
        triggered = ctx.triggered[0]["prop_id"].split(".")[0]

        index = json.loads(triggered).get("index")

        df = pd.DataFrame(get_db_data())

        functions = json.loads(df.to_json(orient="records"))

        for function in functions:
            if function.get("id") == index:
                formula = str(function.get("formula"))
                return formula, formula, True

    raise PreventUpdate


# Copy From Store To Clipboard
app.clientside_callback(
    """
    function(formula, click) {
        if (click > 0) {
            var dummy = document.createElement("textarea");
            document.body.appendChild(dummy);
            dummy.value = formula;
            dummy.select();
            document.execCommand("copy");
            document.body.removeChild(dummy);
        }
        return 0;
    }
    """,
    Output({"type": "excel-copy-to-clipboard-lottie", "index": MATCH}, "n_clicks"),
    Input({"type": "excel-copy-to-clipboard-store", "index": MATCH}, "data"),
    State({"type": "excel-copy-to-clipboard-lottie", "index": MATCH}, "n_clicks"),
    prevent_initial_call=True,
)

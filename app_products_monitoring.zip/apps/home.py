from urllib.parse import parse_qs
import json

from dash import dcc
from dash.dependencies import Input, Output, State, MATCH
from dash.exceptions import PreventUpdate
import dash_extensions as de
from flask_login import current_user
from dash import callback_context

from models.storing import cached_data_missing_contrib
from utils.components import *
from utils.osiris import *
from utils.graphs import *
from utils.api_open_positions import OpenPositions
from models.menus_and_elements import turfu_subnav
import utils.sql as sql
import utils.sql_amc as sql_amc
from utils.basics import timeit
from utils.sql_write import (
    add_alien,
    update_alien,
    update_product_status,
    insert_or_update_code,
)
from utils.graphs import basis_graph_structured_product

from .templates.autocall import serve_layout_autocall
from .templates.minifut import serve_layout_minifut
from .templates.index import serve_layout_index
from .templates.templates import display_margins
from dash_dangerously_set_inner_html import DangerouslySetInnerHTML


def update_alien_bdd(add_or_update, link_nb, cfin_primary, cfin_secondary):
    style = {"color": "green"}

    # Add Link
    if add_or_update == "Add":
        feedback = "Link successfully inserted"
        if not add_alien(cfin_primary, cfin_secondary, link_nb):
            feedback = "Error inserting link"
            style = {"color": "red"}

    # Update Link
    else:
        feedback = "Link successfully updated"
        if not update_alien(cfin_primary, cfin_secondary, link_nb):
            feedback = "Error inserting link"
            style = {"color": "red"}

    return feedback, style


def cfin_from_search(search):
    if search:
        parsed_cfin = parse_qs(search[1:]).get("cfin")
        if parsed_cfin:
            return jsonify(cfin=parsed_cfin[0], status=200)
    return jsonify(error_message="No valid Cfin", status=404)


def text_days_late(value):
    if value == 0:
        return f"Issuing today"
    elif value == -1:
        return f"Issue in 1 bday"
    elif value == 1:
        return f"Issued 1 bday ago"
    elif value > 0:
        return f"Issued {value} bdays ago"
    else:
        return f"Issue in {abs(value)} bdays"


def text_days_late_from_date(value):
    nb_days = np.busday_count(value, dt.today().date())
    return text_days_late(nb_days)


def true_if_none(value):
    if not value:
        return True
    if value in ["nan", "N/A", "None"]:
        return True
    if isinstance(value, list) and len(value) > 0:
        return False
    if pd.isna(value):
        return True
    return False


def no_display_if_none(d, field):
    if true_if_none(d.get(field)):
        return {"display": "none"}
    return {}


def color_card(date):
    if date:
        if isinstance(date, datetime.datetime):
            date = date.date()
        if date - timedelta(days=14) <= dt_today() <= date:
            return {"background-color": "rgb(211,153,158)"}
        elif dt_today() < date:
            return {"background-color": "rgb(0, 118, 133)"}
        else:
            return {"background-color": "rgb(153,174,188)"}


color_state_life = {
    1: "rgb(21,175,21)",
    2: "rgb(255,140,0)",
    3: "rgb(255,0,0)",
    4: "rgb(255,0,0)",
    5: "rgb(255,0,0)",
    6: "rgb(255,0,0)",
    7: "rgb(255,0,0)",
}

graph_autocall = basis_graph_structured_product()


def serve_layout(search=None):
    if search:
        try:
            reg_search = re.search("(?<=cfin=)(.*?)(?=\?|$)", search)
            search = reg_search[0]
        except Exception as e:
            print(e)

    location = dcc.Location(
        id={"type": "url", "page": "home"}, search=search, refresh=False
    )

    subnav = turfu_subnav("home")

    body = dbc.Container(
        children=[
            html.Div(
                dbc.Spinner(
                    html.Div(id="home-searched-main-details"),
                    spinner_style={
                        "width": "3rem",
                        "height": "3rem",
                        "color": "#006266",
                        "margin-top": "5rem",
                    },
                ),
            ),
            html.Div(id="home-searched-graph"),
            html.Div(id="home-searched-osiris-template"),
            html.Div(id="home-searched-trades"),
            html.Div(id="home-searched-pricing"),
        ],
        id="home-check-container",
        style={"display": "none"},
        fluid=True,
    )

    products_with_issues = html.Div(id="products-with-issues")

    stored_data = [
        dcc.Store(id="home-search-cfin", storage_type="memory"),
        dcc.Store(id="data-api", storage_type="memory"),
        dcc.Store(id="data-contrib-issues", storage_type="memory", data=""),
    ]

    # return [location, subnav, body, *stored_data]
    return [location, subnav, body, products_with_issues, *stored_data]


@app.callback(Output("data-api", "data"), Input("home-search-cfin", "data"))
def store_data_osiris_api(j):
    if j:
        d = instrument_details(j)
        result = d.json
        result["cfin"] = j["cfin"]
        return result
    return ""


@app.callback(
    Output("store-searched-cfin", "children"), Input("empty-div-searched-cfin", "data")
)
def test_searched_cfin(data):
    if data:
        return data.get("cfin")
    raise PreventUpdate


@app.callback(
    Output({"type": "turfu-subnav", "page": "home"}, "children"),
    Input("home-search-cfin", "data"),
)
def check_product_main_details_in_subnav(d_display_margin):
    if not d_display_margin or d_display_margin.get("status") != 200:
        return ""

    cfin = d_display_margin.get("cfin")

    try:

        data = main_details_for_cfin(cfin)

        d = [
            {"name": "State", "value": data["main"].get("state_life_label")},
            {"name": "Status", "value": data["main"].get("status")},
            {"name": "Diffusion", "value": data["main"].get("etat_diff")},
            {"name": "Type", "value": data["main"].get("inst_type")},
            {"name": "Delivery", "value": data["main"].get("redemption_type", "N/A")},
            {
                "name": "Denom",
                "value": "{:,.0f}".format(data["main"].get("nominal") or 0.0),
            },
        ]

        d_display_margin = display_levels_margins(cfin)

        data_margin = display_margins(d_display_margin.get("cfin"))

        # Rows of the hedges
        hedges = dbc.Collapse(
            dbc.Container(
                [
                    dbc.Row(
                        [
                            dbc.Col(  # Cfin Hedge
                                [
                                    html.H6(
                                        hedge.get("cfin_hedge"),
                                        className="mb-0",
                                    ),
                                    html.P(
                                        f"Cfin Hedge {k + 1}",
                                        style={"font-size": "10px"},
                                        className="mb-0",
                                    ),
                                ],
                                width="auto my-1",
                            ),
                            dbc.Col(  # Type Hedge
                                [
                                    html.H6(
                                        hedge.get("type_hedge"),
                                        className="mb-0",
                                    ),
                                    html.P(
                                        f"Type Hedge {k + 1}",
                                        style={"font-size": "10px"},
                                        className="mb-0",
                                    ),
                                ],
                                width="auto my-1",
                            ),
                            dbc.Col(  # Issuer
                                [
                                    html.H6(
                                        hedge.get("issuer_hedge"),
                                        className="mb-0",
                                    ),
                                    html.P(
                                        f"Issuer {k + 1}",
                                        style={"font-size": "10px"},
                                        className="mb-0",
                                    ),
                                ],
                                width="auto my-1",
                            ),
                            dbc.Col(  # External Ref
                                [
                                    dbc.Input(
                                        id={
                                            "type": "home-input-search-external-ref",
                                            "cfin": hedge.get("cfin_hedge"),
                                        },
                                        value=hedge.get("external_ref") or "Missing",
                                        n_submit=0,
                                        placeholder=hedge.get("external_ref")
                                        or "Missing",
                                        type="text",
                                        className="home-input-field field-ref py-0",
                                    ),
                                    html.P(
                                        "External Ref",
                                        style={"font-size": "10px"},
                                        className="mb-0",
                                    ),
                                    dbc.Toast(
                                        id={
                                            "type": "home-notif-search-external-ref",
                                            "cfin": hedge.get("cfin_hedge"),
                                        },
                                        icon="success",
                                        header="External Ref Update",
                                        is_open=False,
                                        dismissable=True,
                                        duration=5000,
                                        headerClassName="home-notif-header",
                                        bodyClassName="home-notif-body",
                                        className="home-notif-toast",
                                    ),
                                ],
                                width="auto my-1",
                            ),
                            dbc.Col(  # Ric Code
                                [
                                    dbc.Input(
                                        id={
                                            "type": "home-input-external-ric",
                                            "cfin": hedge.get("cfin_hedge"),
                                        },
                                        value=hedge.get("ric_code") or "Missing",
                                        n_submit=0,
                                        placeholder=hedge.get("ric_code") or "Missing",
                                        type="text",
                                        className="home-input-field field-ric py-0",
                                    ),
                                    html.P(
                                        "RIC Code",
                                        style={"font-size": "10px"},
                                        className="mb-0",
                                    ),
                                    dbc.Toast(
                                        id={
                                            "type": "home-notif-external-ric",
                                            "cfin": hedge.get("cfin_hedge"),
                                        },
                                        icon="success",
                                        header="External RIC Update",
                                        is_open=False,
                                        dismissable=True,
                                        duration=5000,
                                        headerClassName="home-notif-header",
                                        bodyClassName="home-notif-body",
                                        className="home-notif-toast",
                                    ),
                                ],
                                width="auto my-1",
                                # style=no_display_if_none(hedge, "ric_code"),
                            ),
                            # dbc.Col(  # Ric Code
                            #     [
                            #         dbc.Input(
                            #             id={
                            #                 "type": "home-input-search-external-ric",
                            #                 "cfin": x["main"]["cfin"],
                            #             },
                            #             value=x["main"]["ric"] or "Missing",
                            #             n_submit=0,
                            #             placeholder=x["main"]["ric"] or "Missing",
                            #             type="text",
                            #             className="home-input-field field-ric py-0"
                            #             if x["main"]["ric"]
                            #                and "Exane" not in x["main"]["issuer"]
                            #             else "home-input-field field-ric-large py-0",
                            #         ),
                            #         html.P(
                            #             "External RIC",
                            #             style={"font-size": "11px"},
                            #             className="mb-0",
                            #         ),
                            #         dbc.Toast(
                            #             id={
                            #                 "type": "home-notif-search-external-ric",
                            #                 "cfin": x["main"]["cfin"],
                            #             },
                            #             icon="success",
                            #             header="External RIC Update",
                            #             is_open=False,
                            #             dismissable=True,
                            #             duration=5000,
                            #             headerClassName="home-notif-header",
                            #             bodyClassName="home-notif-body",
                            #             className="home-notif-toast",
                            #         ),
                            #     ],
                            #     width="auto my-1",
                            #     style={"display": "none"}
                            #     if (
                            #             "OTC" not in x["main"]["issuer"]
                            #             and "Note" not in x["main"]["issuer"]
                            #             and "Exane" in x["main"]["issuer"]
                            #     )
                            #     else None,
                            # )
                        ],
                        justify="start",
                    )
                    for k, hedge in enumerate(data["hedge"])
                ]
            ),
            id={"type": "home-hedge-collapse-values", "cfin": cfin},
            is_open=False,
        )

        return dbc.Row(  # First row of Products page
            [
                dbc.Col(  # Column of the Buttons and Details
                    [
                        dbc.Row(
                            [
                                dbc.Col(  # Information Button
                                    [
                                        html.Div(
                                            [
                                                html.A(
                                                    html.I(
                                                        className="fas fa-info-circle",
                                                        id="home-button-more-infos",
                                                    ),
                                                    id={
                                                        "type": "home-life-status-link",
                                                        "cfin": cfin,
                                                    },
                                                    style={
                                                        "color": color_state_life.get(
                                                            data["main"][
                                                                "state_life_code"
                                                            ],
                                                            "green",
                                                        )
                                                    },
                                                ),
                                            ],
                                            id="home-product-details-popover-target",
                                        ),
                                        dbc.Popover(
                                            [
                                                dbc.PopoverHeader("Product Details"),
                                                dbc.PopoverBody(
                                                    [
                                                        dbc.Table(
                                                            html.Tbody(
                                                                [
                                                                    html.Tr(
                                                                        [
                                                                            html.Td(
                                                                                _.get(
                                                                                    "name"
                                                                                ),
                                                                                style={
                                                                                    "padding": "0.4rem",
                                                                                    "border": "none",
                                                                                },
                                                                            ),
                                                                            html.Td(
                                                                                _.get(
                                                                                    "value"
                                                                                ),
                                                                                style={
                                                                                    "padding": "0.4rem",
                                                                                    "border": "none",
                                                                                },
                                                                            ),
                                                                        ]
                                                                    )
                                                                    for _ in d
                                                                ]
                                                            ),
                                                            bordered=False,
                                                            style={
                                                                "margin-bottom": "0px",
                                                            },
                                                        ),
                                                    ],
                                                    id="home-popover-more-infos-body",
                                                ),
                                            ],
                                            id="home-product-details-popover",
                                            target="home-product-details-popover-target",
                                            trigger="click",
                                            placement="bottom",
                                            is_open=False,
                                        ),
                                        dbc.Toast(
                                            id={
                                                "type": "home-notif-life-status",
                                                "cfin": cfin,
                                            },
                                            icon="success",
                                            header="Update Status",
                                            is_open=False,
                                            dismissable=True,
                                            duration=5000,
                                            headerClassName="home-notif-header",
                                            bodyClassName="home-notif-body",
                                            class_name="home-notif-toast",
                                        ),
                                    ],
                                    width="auto",
                                    className="pt-1",
                                ),
                                icon_termsheet(
                                    data["main"].get("cfin"),
                                    searched=True,
                                    class_name="px-0 pt-1",
                                ),
                                dbc.Col(  # Name
                                    [
                                        html.H2(
                                            data["main"].get("name"),
                                            className="font-weight-bold m-0",
                                            style={
                                                "white-space": "nowrap",
                                                "text-overflow": "ellipsis",
                                                "overflow": "hidden",
                                                "color": "#2c3e50",
                                            },
                                        ),
                                    ],
                                    width=10,
                                ),
                            ],
                            className="mb-3",
                        ),
                        dbc.Row(  # Row of the Codes for the Titre
                            [
                                dbc.Col(  # Issuer
                                    [
                                        html.H6(
                                            data["main"].get("issuer"),
                                            className="mb-0",
                                        ),
                                        html.P(
                                            "Issuer",
                                            style={"font-size": "11px"},
                                            className="mb-0",
                                        ),
                                    ],
                                    width="auto my-1",
                                ),
                                dbc.Col(  # Currency
                                    [
                                        html.H6(
                                            data["main"].get("ccy"),
                                            className="mb-0",
                                        ),
                                        html.P(
                                            "Currency",
                                            style={"font-size": "11px"},
                                            className="mb-0",
                                        ),
                                    ],
                                    width="auto my-1",
                                ),
                                dbc.Col(  # Cfin
                                    [
                                        html.H6(
                                            data["main"].get("cfin"),
                                            className="mb-0",
                                        ),
                                        html.P(
                                            "Cfin Product",
                                            style={"font-size": "11px"},
                                            className="mb-0",
                                        ),
                                    ],
                                    width="auto my-1",
                                ),
                                dbc.Col(  # Cfin Position
                                    [
                                        html.H6(
                                            data.get("cfin_position"),
                                            className="mb-0",
                                        ),
                                        html.P(
                                            "Cfin Position",
                                            style={"font-size": "11px"},
                                            className="mb-0",
                                        ),
                                    ],
                                    style=no_display_if_none(data, "cfin_position"),
                                    width="auto my-1",
                                ),
                                dbc.Col(  # ISIN
                                    [
                                        dbc.Input(
                                            id={
                                                "type": "home-input-search-isin",
                                                "cfin": data["main"]["cfin"],
                                            },
                                            value=data["main"]["isin"] or "Missing",
                                            n_submit=0,
                                            placeholder=data["main"]["isin"]
                                            or "Missing",
                                            type="text",
                                            className="home-input-field field-isin py-0",
                                        ),
                                        html.P(
                                            "ISIN",
                                            style={"font-size": "11px"},
                                            className="mb-0",
                                        ),
                                        dbc.Toast(
                                            id={
                                                "type": "home-notif-search-isin",
                                                "cfin": data["main"]["cfin"],
                                            },
                                            icon="success",
                                            header="ISIN Update",
                                            is_open=False,
                                            dismissable=True,
                                            duration=5000,
                                            headerClassName="home-notif-header",
                                            bodyClassName="home-notif-body",
                                            className="home-notif-toast",
                                        ),
                                    ],
                                    width="auto my-1",
                                ),
                                # dbc.Col(  # Cfin Hedge
                                #     [
                                #         html.H6(
                                #             x.get("cfin_hedge"),
                                #             className="mb-0",
                                #         ),
                                #         html.P(
                                #             "Cfin Hedge",
                                #             style={"font-size": "11px"},
                                #             className="mb-0",
                                #         ),
                                #     ],
                                #     style=no_display_if_none(x, "cfin_hedge"),
                                #     width="auto my-1",
                                # ),
                                dbc.Col(  # Ric Code
                                    [
                                        dbc.Input(
                                            id={
                                                "type": "home-input-search-external-ric",
                                                "cfin": data["main"]["cfin"],
                                            },
                                            value=data["main"]["ric"] or "Missing",
                                            n_submit=0,
                                            placeholder=data["main"]["ric"]
                                            or "Missing",
                                            type="text",
                                            className="home-input-field field-ric py-0"
                                            if data["main"]["ric"]
                                            and "Exane" not in data["main"]["issuer"]
                                            else "home-input-field field-ric-large py-0",
                                        ),
                                        html.P(
                                            "External RIC",
                                            style={"font-size": "11px"},
                                            className="mb-0",
                                        ),
                                        dbc.Toast(
                                            id={
                                                "type": "home-notif-search-external-ric",
                                                "cfin": data["main"]["cfin"],
                                            },
                                            icon="success",
                                            header="External RIC Update",
                                            is_open=False,
                                            dismissable=True,
                                            duration=5000,
                                            headerClassName="home-notif-header",
                                            bodyClassName="home-notif-body",
                                            className="home-notif-toast",
                                        ),
                                    ],
                                    width="auto my-1",
                                    style={"display": "none"}
                                    if (
                                        "OTC" not in data["main"].get("issuer", "")
                                        and "Note" not in data["main"].get("issuer", "")
                                        and "Exane" in data["main"].get("issuer", "")
                                    )
                                    else None,
                                ),
                                # dbc.Col(  # External Ref
                                #     [
                                #         dbc.Input(
                                #             id={
                                #                 "type": "home-input-search-external-ref",
                                #                 "cfin": x.get("cfin"),
                                #             },
                                #             value=x.get("external_ref") or "Missing",
                                #             n_submit=0,
                                #             placeholder=x.get("external_ref")
                                #             or "Missing",
                                #             type="text",
                                #             className="home-input-field field-ref py-0"
                                #             if x.get("external_ref")
                                #             and "&" not in x.get("external_ref")
                                #             else "home-input-field field-ref-large py-0",
                                #         ),
                                #         html.P(
                                #             "External Ref",
                                #             style={"font-size": "11px"},
                                #             className="mb-0",
                                #         ),
                                #         dbc.Toast(
                                #             id={
                                #                 "type": "home-notif-search-external-ref",
                                #                 "cfin": x["main"]["cfin"],
                                #             },
                                #             icon="success",
                                #             header="External Ref Update",
                                #             is_open=False,
                                #             dismissable=True,
                                #             duration=5000,
                                #             headerClassName="home-notif-header",
                                #             bodyClassName="home-notif-body",
                                #             className="home-notif-toast",
                                #         ),
                                #     ],
                                #     style=no_display_if_none(x, "cfin_hedge"),
                                #     width="auto my-1",
                                # ),
                                dbc.Col(  # Market
                                    [
                                        html.H6(
                                            data["main"].get("market") or "Not Listed",
                                            className="mb-0",
                                        ),
                                        html.P(
                                            "Market",
                                            style={"font-size": "11px"},
                                            className="mb-0",
                                        ),
                                    ],
                                    width="auto my-1",
                                ),
                            ],
                            justify="start",
                        ),
                        dbc.Row(
                            dbc.Col(
                                dbc.Button(
                                    "Hedge Details",
                                    id={
                                        "type": "home-hedge-collapse-button",
                                        "cfin": cfin,
                                    },
                                    className="my-3",
                                    color="light",
                                    n_clicks=0,
                                    size="sm",
                                    style=no_display_if_none(data, field="hedge"),
                                ),
                                width="auto",
                            )
                        ),
                        dbc.Row(hedges),
                    ],
                    width=5,
                    align="center",
                ),
                dbc.Col(  # Column of the Dates
                    [
                        dbc.Row(
                            [
                                # Fixing Initial
                                dbc.Col(
                                    [
                                        html.H6("Initial Fixing"),
                                        dbc.Card(
                                            [
                                                dbc.CardHeader(
                                                    style=color_card(
                                                        data["main"].get("trade_date"),
                                                    ),
                                                    className="py-1",
                                                ),
                                                dbc.CardBody(
                                                    [
                                                        html.H5(
                                                            f"{data['main'].get('trade_date').strftime('%b %d') if data['main'].get('trade_date') is not None else ''}",
                                                            className="text-center mb-1",
                                                        ),
                                                        html.H6(
                                                            f"{data['main'].get('trade_date').strftime('%Y') if data['main'].get('trade_date') is not None else ''}",
                                                            className="text-center",
                                                        ),
                                                    ],
                                                    className="px-1 py-1",
                                                ),
                                            ],
                                        ),
                                    ],
                                    width=3,
                                    style=no_display_if_none(
                                        data["main"], "trade_date"
                                    ),
                                ),
                                # Issue Date
                                dbc.Col(
                                    [
                                        html.H6("Issue Date"),
                                        dbc.Card(
                                            [
                                                dbc.CardHeader(
                                                    style=color_card(
                                                        data["main"].get("issue_date")
                                                    ),
                                                    className="py-1",
                                                ),
                                                dbc.CardBody(
                                                    [
                                                        html.H5(
                                                            f"{data['main'].get('issue_date').strftime('%b %d') if data['main'].get('issue_date') is not None else ''}",
                                                            className="text-center mb-1",
                                                        ),
                                                        html.H6(
                                                            f"{data['main'].get('issue_date').strftime('%Y') if data['main'].get('issue_date') is not None else ''}",
                                                            className="text-center",
                                                        ),
                                                    ],
                                                    className="px-1 py-1",
                                                ),
                                            ],
                                        ),
                                    ],
                                    width=3,
                                    style=no_display_if_none(
                                        data["main"], "issue_date"
                                    ),
                                ),
                                # Maturity Date
                                dbc.Col(
                                    [
                                        html.H6("Final Fixing"),
                                        dbc.Card(
                                            [
                                                dbc.CardHeader(
                                                    style=color_card(
                                                        data["main"].get(
                                                            "maturity_date"
                                                        )
                                                    ),
                                                    className="py-1",
                                                ),
                                                dbc.CardBody(
                                                    [
                                                        html.H5(
                                                            f"{data['main'].get('maturity_date').strftime('%b %d') if data['main'].get('maturity_date') is not None else ''}",
                                                            className="text-center mb-1",
                                                        ),
                                                        html.H6(
                                                            f"{data['main'].get('maturity_date').strftime('%Y') if data['main'].get('maturity_date') is not None else ''}",
                                                            className="text-center",
                                                        ),
                                                    ],
                                                    className="px-1 py-1",
                                                ),
                                            ],
                                        ),
                                    ],
                                    width=3,
                                    style=no_display_if_none(
                                        data["main"], "maturity_date"
                                    ),
                                ),
                                # Redemption Date
                                dbc.Col(
                                    [
                                        html.H6("Redemption"),
                                        dbc.Card(
                                            [
                                                dbc.CardHeader(
                                                    style=color_card(
                                                        data["main"].get(
                                                            "redemption_date"
                                                        )
                                                    ),
                                                    className="py-1",
                                                ),
                                                dbc.CardBody(
                                                    [
                                                        html.H5(
                                                            f"{data['main'].get('redemption_date').strftime('%b %d') if data['main'].get('redemption_date') is not None else ''}",
                                                            className="text-center mb-1",
                                                        ),
                                                        html.H6(
                                                            f"{data['main'].get('redemption_date').strftime('%Y') if data['main'].get('redemption_date') is not None else ''}",
                                                            className="text-center",
                                                        ),
                                                    ],
                                                    className="px-1 py-1",
                                                ),
                                            ],
                                        ),
                                    ],
                                    width=3,
                                    style=no_display_if_none(
                                        data["main"], "redemption_date"
                                    ),
                                ),
                            ]
                        )
                    ],
                    width=4,
                    align="center",
                ),
                dbc.Col(  # Column of the Last Levels
                    [
                        html.Div(
                            [
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            [
                                                html.P(
                                                    "BID/ASK & MARGINS",
                                                    className="mb-0",
                                                    style={
                                                        "fontFamily": "Roboto-Bold",
                                                        "fontSize": "1.0rem",
                                                        "color": "rgba(0, 0, 0, 0.54)",
                                                    },
                                                ),
                                                html.P(
                                                    d_display_margin.get(
                                                        "timestamp",
                                                    )
                                                    or d_display_margin.get(
                                                        "last_date"
                                                    ),
                                                    className="mb-1",
                                                    style={
                                                        "fontFamily": "Roboto-Bold",
                                                        "fontSize": "0.65rem",
                                                        "color": "rgba(0, 0, 0, 0.54)",
                                                    },
                                                ),
                                            ],
                                            style={"text-align": "right"},
                                        )
                                    ],
                                    justify="end",
                                ),
                                dbc.Row(
                                    [
                                        dbc.Col(  # Bid and Ask levels
                                            [
                                                html.P(
                                                    f"{d_display_margin.get('bid') or d_display_margin.get('last_bid')} / {d_display_margin.get('ask') or d_display_margin.get('last_ask')}",
                                                    className="mb-1",
                                                    style={
                                                        "fontFamily": "Roboto-Bold",
                                                        "fontSize": "1.4rem",
                                                    },
                                                ),
                                                html.P(
                                                    f"{d_display_margin.get('bid_margin', 'N/A'):,.2f} / {d_display_margin.get('ask_margin', 'N/A'):,.2f}"
                                                    if d_display_margin.get(
                                                        "bid_margin"
                                                    )
                                                    else "N/A",
                                                    id="home-margin",
                                                    className="mb-0",
                                                    style={
                                                        "fontFamily": "Roboto-Bold",
                                                        "fontSize": "1.1rem",
                                                    }
                                                    if d_display_margin
                                                    else {"display": "none"},
                                                ),
                                                dbc.Tooltip(
                                                    data_margin,
                                                    target="home-margin",
                                                    placement="bottom",
                                                    style={"display": "none"}
                                                    if not data_margin
                                                    else {
                                                        "width": "320px",
                                                        "max-width": "320px",
                                                    },
                                                ),
                                            ],
                                            width=12,
                                            style={"textAlign": "right"},
                                        ),
                                    ]
                                ),
                            ],
                            n_clicks=0,
                            id="home-checked-historical-values",
                        ),
                        dbc.Modal(
                            [
                                dbc.ModalHeader(dbc.ModalTitle("Exane's values in db")),
                                dbc.ModalBody(
                                    id="modal-body-check-exane",
                                ),
                            ],
                            id="modal-check-exane",
                            scrollable=True,
                            backdrop=True,
                            is_open=False,
                            size="lg",
                        ),
                    ],
                    width=2,
                ),
            ],
            justify="between",
            className="my-2 p-4",
        )

    except Exception as e:
        msg = "data front page issue"
        server.logger.exception(msg)


@app.callback(
    Output({"type": "home-hedge-collapse-values", "cfin": MATCH}, "is_open"),
    Input({"type": "home-hedge-collapse-button", "cfin": MATCH}, "n_clicks"),
    State({"type": "home-hedge-collapse-values", "cfin": MATCH}, "is_open"),
)
def home_hedge_information_collapse(n, is_open):
    if n:
        return not is_open
    return is_open


@app.callback(
    Output("home-searched-osiris-template", "children"), Input("data-api", "data")
)
def serve_additional_information_if_relevant(data):
    if not data:
        return ""

    if data and data.get("content"):
        data = data["content"][0]

        if data.get("type") in structured_products_templates:
            return serve_layout_autocall()

        if data.get("type") == "MINI_FUTURE_TEMPLATE":
            return serve_layout_minifut()

    try:
        # Check if is an index or underlying is
        cfin = data.get("cfin") or data.get("instrumentId")
        return serve_layout_index(cfin)
    except:
        return ""


@timeit
@app.callback(
    Output("data-contrib-issues", "data"),
    Output("home-button-scheduler-spinner", "children"),
    Input("home-button-contrib-issues-reload", "n_clicks"),
    State("home-button-scheduler-spinner", "children"),
)
def data_cached_contrib_issues(n_clicks, children):
    if n_clicks > 0:
        cache.delete("contrib")
        data = cached_data_missing_contrib()
        return data, children
    raise PreventUpdate


@app.callback(
    Output("products-with-issues", "children"),
    Input({"type": "url", "page": "home"}, "href"),
)
def display_products_with_issues(href):

    data = cached_data_missing_contrib()

    if not data:
        raise PreventUpdate

    rows_of_late_products = [
        dbc.Row(
            [
                dbc.Col(  # Column with Main Details
                    [
                        dbc.Row(  # Pill, Links, Issuer and Name
                            [
                                dbc.Col(
                                    [
                                        dbc.Badge(
                                            "Missing"
                                            if x.get("days_late") >= 0
                                            else "Not Issued",
                                            pill=True,
                                            color="danger"
                                            if x.get("days_late") >= 0
                                            else "primary",
                                            id=f"home-badge-{x['cfin']}",
                                        ),
                                        dbc.Tooltip(
                                            x.get("cause"),
                                            target=f"home-badge-{x['cfin']}",
                                        ),
                                    ],
                                    width="auto",
                                    className="pt-2 pr-0",
                                ),
                                icon_reuters(x["cfin"], x["ric"], className="px-2"),
                                dbc.Col(  # Issuer Name
                                    [
                                        html.H3(
                                            x.get("issuer"),
                                            className="m-0",
                                            style={
                                                "color": "#006266",
                                                "fontFamily": "Roboto-Bold",
                                            },
                                        ),
                                    ],
                                    width="auto",
                                    className="pl-0",
                                ),
                                dbc.Col(  # Product Name
                                    [
                                        html.H3(
                                            x.get("name"),
                                            style={
                                                "fontFamily": "Roboto-Bold",
                                                "font-weight": "200",
                                            },
                                            className="m-0",
                                        ),
                                    ],
                                    width="auto",
                                    className="pl-0",
                                ),
                                dbc.Col(  # Information Status
                                    [
                                        html.A(
                                            html.I(
                                                className="fas fa-circle fa-xs",
                                                id=f"home-life-status-{x['cfin']}",
                                            ),
                                            id={
                                                "type": "home-life-status-link",
                                                "cfin": x.get("cfin"),
                                            },
                                            style={"color": "#16a085"},
                                        ),
                                        dbc.Popover(
                                            dbc.PopoverBody(
                                                dbc.Row(
                                                    [
                                                        dbc.Col(
                                                            [
                                                                dbc.Row(
                                                                    dbc.Col(
                                                                        html.H6(
                                                                            "Update Product Status",
                                                                            style={
                                                                                "color": "rgba(0,0,0,0.87)"
                                                                            },
                                                                        )
                                                                    )
                                                                ),
                                                                dbc.Row(
                                                                    [
                                                                        dbc.Col(
                                                                            dbc.Button(
                                                                                dbc.Spinner(
                                                                                    html.Div(
                                                                                        "Inactive",
                                                                                        id=f"home-button-status-inactive-spinner-{x.get('cfin')}",
                                                                                    ),
                                                                                    size="sm",
                                                                                    type="grow",
                                                                                    color="secondary",
                                                                                ),
                                                                                id={
                                                                                    "type": "home-button-status-inactive",
                                                                                    "cfin": x.get(
                                                                                        "cfin"
                                                                                    ),
                                                                                },
                                                                                size="sm",
                                                                                n_clicks=0,
                                                                                color="secondary",
                                                                            )
                                                                        ),
                                                                        dbc.Col(
                                                                            dbc.Button(
                                                                                dbc.Spinner(
                                                                                    html.Div(
                                                                                        "Autocalled",
                                                                                        id=f"home-button-status-autocall-spinner-{x.get('cfin')}",
                                                                                    ),
                                                                                    size="sm",
                                                                                    type="grow",
                                                                                    color="secondary",
                                                                                ),
                                                                                id={
                                                                                    "type": "home-button-status-autocall",
                                                                                    "cfin": x.get(
                                                                                        "cfin"
                                                                                    ),
                                                                                },
                                                                                n_clicks=0,
                                                                                size="sm",
                                                                                color="secondary",
                                                                            )
                                                                        ),
                                                                    ],
                                                                    className="my-2",
                                                                    justify="center",
                                                                ),
                                                            ],
                                                        ),
                                                    ],
                                                    className="p-2",
                                                )
                                            ),
                                            target=f"home-life-status-{x['cfin']}",
                                            class_name="home-tooltip-life-status",
                                            placement="bottom",
                                            trigger="legacy",
                                            delay={
                                                "show": 250,
                                                "hide": 400,
                                            },
                                        ),
                                        dbc.Toast(
                                            id={
                                                "type": "home-notif-life-status",
                                                "cfin": x["cfin"],
                                            },
                                            icon="success",
                                            header="Update Status",
                                            is_open=False,
                                            dismissable=True,
                                            duration=5000,
                                            headerClassName="home-notif-header",
                                            bodyClassName="home-notif-body",
                                            className="home-notif-toast",
                                        ),
                                    ],
                                    width="auto",
                                    className="pl-0",
                                ),
                            ],
                            align="center",
                            className="mb-2",
                        ),
                        dbc.Row(  # Row of the Data
                            [
                                dbc.Col(  # Levels
                                    dbc.Row(
                                        [
                                            dbc.Col(  # Issue Date
                                                [
                                                    html.H6(
                                                        x.get("payment_date"),
                                                        className="mb-0",
                                                    ),
                                                    html.P(
                                                        text_days_late(
                                                            x.get("days_late")
                                                        ),
                                                        style={"font-size": "11px"},
                                                        className="mb-0",
                                                    ),
                                                ],
                                                width="auto",
                                            ),
                                            dbc.Col(  # Cfin
                                                [
                                                    html.H6(
                                                        x.get("cfin"),
                                                        className="mb-0",
                                                    ),
                                                    html.P(
                                                        "Cfin Product",
                                                        style={"font-size": "11px"},
                                                        className="mb-0",
                                                    ),
                                                ],
                                                width="auto",
                                            ),
                                            dbc.Col(  # Cfin OTC
                                                [
                                                    html.H6(
                                                        x.get("cfin_otc"),
                                                        className="mb-0",
                                                    ),
                                                    html.P(
                                                        "Cfin OTC",
                                                        style={"font-size": "11px"},
                                                        className="mb-0",
                                                    ),
                                                ],
                                                style=no_display_if_none(x, "cfin_otc"),
                                                width="auto",
                                            ),
                                            dbc.Col(  # ISIN
                                                [
                                                    dbc.Input(
                                                        id={
                                                            "type": "home-input-isin",
                                                            "cfin": x["cfin"],
                                                        },
                                                        value=x["isin"],
                                                        n_submit=0,
                                                        placeholder=x["isin"]
                                                        or "Missing",
                                                        type="text",
                                                        className="home-input-field field-isin py-0",
                                                    ),
                                                    html.P(
                                                        "ISIN",
                                                        style={"font-size": "11px"},
                                                        className="mb-0",
                                                    ),
                                                    dbc.Toast(
                                                        id={
                                                            "type": "home-notif-isin",
                                                            "cfin": x["cfin"],
                                                        },
                                                        icon="success",
                                                        header="ISIN Update",
                                                        is_open=False,
                                                        dismissable=True,
                                                        duration=5000,
                                                        headerClassName="home-notif-header",
                                                        bodyClassName="home-notif-body",
                                                        className="home-notif-toast",
                                                    ),
                                                ],
                                                width="auto",
                                            ),
                                            dbc.Col(  # Ric Code
                                                [
                                                    dbc.Input(
                                                        id={
                                                            "type": "home-input-external-ric",
                                                            "cfin": x["cfin"],
                                                        },
                                                        value=x["external_ric"]
                                                        or x["ric"],
                                                        n_submit=0,
                                                        placeholder=x["external_ric"]
                                                        or "Missing",
                                                        type="text",
                                                        className="home-input-field field-ric py-0",
                                                    ),
                                                    html.P(
                                                        "External RIC",
                                                        style={"font-size": "11px"},
                                                        className="mb-0",
                                                    ),
                                                    dbc.Toast(
                                                        id={
                                                            "type": "home-notif-external-ric",
                                                            "cfin": x.get("cfin"),
                                                        },
                                                        icon="success",
                                                        header="External RIC Update",
                                                        is_open=False,
                                                        dismissable=True,
                                                        duration=5000,
                                                        headerClassName="home-notif-header",
                                                        bodyClassName="home-notif-body",
                                                        className="home-notif-toast",
                                                    ),
                                                ],
                                                width="auto",
                                            ),
                                            dbc.Col(  # External Ref
                                                [
                                                    dbc.Input(
                                                        id={
                                                            "type": "home-input-external-ref",
                                                            "cfin": x.get("cfin"),
                                                        },
                                                        value=x["external_ref"],
                                                        n_submit=0,
                                                        placeholder=x["external_ref"]
                                                        or "Missing",
                                                        type="text",
                                                        className="home-input-field field-ref py-0",
                                                    ),
                                                    html.P(
                                                        "External Ref",
                                                        style={"font-size": "11px"},
                                                        className="mb-0",
                                                    ),
                                                    dbc.Toast(
                                                        id={
                                                            "type": "home-notif-external-ref",
                                                            "cfin": x.get("cfin"),
                                                        },
                                                        icon="success",
                                                        header="External Ref Update",
                                                        is_open=False,
                                                        dismissable=True,
                                                        duration=5000,
                                                        headerClassName="home-notif-header",
                                                        bodyClassName="home-notif-body",
                                                        className="home-notif-toast",
                                                    ),
                                                ],
                                                style=no_display_if_none(x, "cfin_otc"),
                                                width="auto",
                                            ),
                                            dbc.Col(  # Last Bid
                                                [
                                                    html.H6(
                                                        f"Last Bid {x.get('last_bid')}",
                                                        className="mb-0",
                                                    ),
                                                    html.P(
                                                        x.get("last_date"),
                                                        style={"font-size": "11px"},
                                                        className="mb-0",
                                                    ),
                                                ],
                                                style=no_display_if_none(x, "last_bid"),
                                                width="auto",
                                            ),
                                        ]
                                    ),
                                ),
                            ],
                            className="pt-2",
                        ),
                    ],
                    width="auto",
                    className="test-col",
                ),
                dbc.Col(  # Column with Lottie to copy Text and Termsheets
                    dbc.Row(
                        [
                            dbc.Col(  # Copy Text to Clipboard
                                [
                                    dbc.Row(
                                        dbc.Col(
                                            [
                                                html.Div(
                                                    html.Div(
                                                        de.Lottie(
                                                            options=dict(
                                                                loop=False,
                                                                autoplay=False,
                                                                rendererSettings=dict(
                                                                    preserveAspectRatio="xMidYMid slice"
                                                                ),
                                                            ),
                                                            width=40,
                                                            height=40,
                                                            isStopped=True,
                                                            # id="home-lottie-eye",
                                                            url=f"/lottie/copy-to-clipboard.json",
                                                        ),
                                                        style={
                                                            "float": "center",
                                                            "top": "0px",
                                                            "display": "inline-block",
                                                        },
                                                        id={
                                                            "type": "home-copy-to-clipboard-lottie",
                                                            "index": x.get("cfin"),
                                                        },
                                                        n_clicks=0,
                                                    ),
                                                    style={
                                                        "float": "center",
                                                        "top": "0px",
                                                        "display": "inline-block",
                                                    },
                                                    id=f"home-copy-to-clipboard-{x.get('cfin')}",
                                                ),
                                                dcc.Store(
                                                    id={
                                                        "type": "home-copy-to-clipboard-store",
                                                        "index": x.get("cfin"),
                                                    },
                                                    storage_type="session",
                                                ),
                                            ],
                                            style={"textAlign": "center"},
                                        ),
                                        className="py-0",
                                    ),
                                    dbc.Row(
                                        dbc.Col(
                                            html.H6(
                                                "BBG Msg",
                                                className="mb-0",
                                                style={"color": "rgba(0, 0, 0, 0.8)"},
                                                id={
                                                    "type": "title-copy-msg",
                                                    "cfin": x.get("cfin"),
                                                },
                                            )
                                        ),
                                        justify="center",
                                        className="py-0",
                                    ),
                                ],
                                width="auto",
                            ),
                            dbc.Col(  # External Termsheet
                                [
                                    dbc.Row(
                                        dbc.Col(
                                            [
                                                html.Div(
                                                    [
                                                        html.A(
                                                            html.I(
                                                                className="far fa-file-pdf fa-2x",
                                                            ),
                                                            target="_blank",
                                                            style={
                                                                "color": "rgba(231, 76, 60, 1.0)"
                                                            }
                                                            if x.get("Hedge 1")
                                                            else {
                                                                "color": "rgba(231, 76, 60, 0.2)"
                                                            },
                                                            href=x.get("Hedge 1")
                                                            or x.get("Issuer"),
                                                            id={
                                                                "type": "icon-external-ts",
                                                                "cfin": x.get("cfin"),
                                                            },
                                                        ),
                                                    ],
                                                    id=f"button-external-ts-{x.get('cfin')}",
                                                ),
                                            ],
                                            style={"textAlign": "center"},
                                        ),
                                        className="py-2",
                                    ),
                                    dbc.Row(
                                        dbc.Col(
                                            html.H6(
                                                "External",
                                                className="mb-0",
                                                style={"color": "rgba(0, 0, 0, 0.8)"}
                                                if x.get("Hedge 1")
                                                else {"color": "rgba(0, 0, 0, 0.2)"},
                                                id={
                                                    "type": "title-external-ts",
                                                    "cfin": x.get("cfin"),
                                                },
                                            )
                                        ),
                                        justify="center",
                                    ),
                                ],
                                width="auto",
                            ),
                            dbc.Col(  # Exane Termsheet
                                [
                                    dbc.Row(
                                        dbc.Col(
                                            [
                                                html.Div(
                                                    [
                                                        html.A(
                                                            html.I(
                                                                className="far fa-file-pdf fa-2x",
                                                            ),
                                                            href=x.get("Exane"),
                                                            style={
                                                                "color": "rgba(231, 76, 60, 1.0)"
                                                            }
                                                            if x.get("Exane")
                                                            else {
                                                                "color": "rgba(231, 76, 60, 0.2)"
                                                            },
                                                            target="_blank",
                                                            id={
                                                                "type": "icon-exane-ts",
                                                                "cfin": x.get("cfin"),
                                                            },
                                                        ),
                                                    ],
                                                    id=f"button-exane-ts-{x.get('cfin')}",
                                                ),
                                            ],
                                            style={"textAlign": "center"},
                                        ),
                                        className="py-2",
                                    ),
                                    dbc.Row(
                                        dbc.Col(
                                            html.H6(
                                                "Exane",
                                                className="mb-0",
                                                style={"color": "rgba(0, 0, 0, 0.8)"}
                                                if x.get("Exane")
                                                else {"color": "rgba(0, 0, 0, 0.2)"},
                                                id={
                                                    "type": "title-exane-ts",
                                                    "cfin": x.get("cfin"),
                                                },
                                            )
                                        ),
                                        justify="center",
                                    ),
                                ],
                                width="auto",
                            ),
                        ]
                    ),
                    width="auto mx-4",
                ),
            ],
            align="center",
            justify="between",
            className="py-3 mb-3 borded-card",
            style={"paddingLeft": "32px"},
        )
        for x in sorted(data, key=lambda i: i["days_late"], reverse=True)
        if x["days_late"] >= 0
    ]

    rows_of_future_products = [
        dbc.Row(
            [
                dbc.Col(  # Column with Main Details
                    [
                        dbc.Row(  # Pill, Links, Issuer and Name
                            [
                                dbc.Col(
                                    [
                                        dbc.Badge(
                                            "Missing"
                                            if x.get("days_late") >= 0
                                            else "Not Issued",
                                            pill=True,
                                            color="danger"
                                            if x.get("days_late") >= 0
                                            else "primary",
                                            id=f"home-badge-{x['cfin']}",
                                        ),
                                        dbc.Tooltip(
                                            x.get("cause"),
                                            target=f"home-badge-{x['cfin']}",
                                        ),
                                    ],
                                    width="auto",
                                    className="pt-2 pr-0",
                                ),
                                icon_reuters(x["cfin"], x["ric"], className="px-2"),
                                dbc.Col(  # Issuer Name
                                    [
                                        html.H3(
                                            x.get("issuer"),
                                            className="m-0",
                                            style={
                                                "color": "#006266",
                                                "fontFamily": "Roboto-Bold",
                                            },
                                        ),
                                    ],
                                    width="auto",
                                    className="pl-0",
                                ),
                                dbc.Col(  # Product Name
                                    [
                                        html.H3(
                                            x.get("name"),
                                            style={
                                                "fontFamily": "Roboto-Bold",
                                                "font-weight": "200",
                                            },
                                            className="m-0",
                                        ),
                                    ],
                                    width="auto",
                                    className="pl-0",
                                ),
                                dbc.Col(  # Information Status
                                    [
                                        html.A(
                                            html.I(
                                                className="fas fa-circle fa-xs",
                                                id=f"home-life-status-{x['cfin']}",
                                            ),
                                            id={
                                                "type": "home-life-status-link",
                                                "cfin": x.get("cfin"),
                                            },
                                            style={"color": "#16a085"},
                                        ),
                                        dbc.Tooltip(
                                            children=dbc.Col(
                                                dbc.Row(
                                                    [
                                                        dbc.Col(
                                                            [
                                                                dbc.Row(
                                                                    dbc.Col(
                                                                        html.H6(
                                                                            "Update Product Status",
                                                                            style={
                                                                                "color": "rgba(0,0,0,0.87)"
                                                                            },
                                                                        )
                                                                    )
                                                                ),
                                                                dbc.Row(
                                                                    [
                                                                        dbc.Col(
                                                                            dbc.Button(
                                                                                dbc.Spinner(
                                                                                    html.Div(
                                                                                        "Inactive",
                                                                                        id=f"home-button-status-inactive-spinner-{x.get('cfin')}",
                                                                                    ),
                                                                                    size="sm",
                                                                                    type="grow",
                                                                                    color="secondary",
                                                                                ),
                                                                                id={
                                                                                    "type": "home-button-status-inactive",
                                                                                    "cfin": x.get(
                                                                                        "cfin"
                                                                                    ),
                                                                                },
                                                                                size="sm",
                                                                                n_clicks=0,
                                                                                color="secondary",
                                                                            )
                                                                        ),
                                                                        dbc.Col(
                                                                            dbc.Button(
                                                                                dbc.Spinner(
                                                                                    html.Div(
                                                                                        "Autocalled",
                                                                                        id=f"home-button-status-autocall-spinner-{x.get('cfin')}",
                                                                                    ),
                                                                                    size="sm",
                                                                                    type="grow",
                                                                                    color="secondary",
                                                                                ),
                                                                                id={
                                                                                    "type": "home-button-status-autocall",
                                                                                    "cfin": x.get(
                                                                                        "cfin"
                                                                                    ),
                                                                                },
                                                                                n_clicks=0,
                                                                                size="sm",
                                                                                color="secondary",
                                                                            )
                                                                        ),
                                                                    ],
                                                                    className="my-2",
                                                                    justify="center",
                                                                ),
                                                            ],
                                                        ),
                                                    ],
                                                    className="p-2",
                                                )
                                            ),
                                            target=f"home-life-status-{x['cfin']}",
                                            class_name="home-tooltip-life-status",
                                            placement="bottom",
                                            # autohide=False,
                                            delay={
                                                "show": 250,
                                                "hide": 400,
                                            },
                                        ),
                                        dbc.Toast(
                                            id={
                                                "type": "home-notif-life-status",
                                                "cfin": x["cfin"],
                                            },
                                            icon="success",
                                            header="Update Status",
                                            is_open=False,
                                            dismissable=True,
                                            duration=5000,
                                            headerClassName="home-notif-header",
                                            bodyClassName="home-notif-body",
                                            className="home-notif-toast",
                                        ),
                                    ],
                                    width="auto",
                                    className="pl-0",
                                ),
                            ],
                            align="center",
                            className="mb-2",
                        ),
                        dbc.Row(  # Row of the Data
                            [
                                dbc.Col(  # Levels
                                    dbc.Row(
                                        [
                                            dbc.Col(  # Issue Date
                                                [
                                                    html.H6(
                                                        x.get("payment_date"),
                                                        className="mb-0",
                                                    ),
                                                    html.P(
                                                        text_days_late(
                                                            x.get("days_late")
                                                        ),
                                                        style={"font-size": "11px"},
                                                        className="mb-0",
                                                    ),
                                                ],
                                                width="auto",
                                            ),
                                            dbc.Col(  # Cfin
                                                [
                                                    html.H6(
                                                        x.get("cfin"),
                                                        className="mb-0",
                                                    ),
                                                    html.P(
                                                        "Cfin Product",
                                                        style={"font-size": "11px"},
                                                        className="mb-0",
                                                    ),
                                                ],
                                                width="auto",
                                            ),
                                            dbc.Col(  # Cfin OTC
                                                [
                                                    html.H6(
                                                        x.get("cfin_otc"),
                                                        className="mb-0",
                                                    ),
                                                    html.P(
                                                        "Cfin OTC",
                                                        style={"font-size": "11px"},
                                                        className="mb-0",
                                                    ),
                                                ],
                                                style=no_display_if_none(x, "cfin_otc"),
                                                width="auto",
                                            ),
                                            dbc.Col(  # ISIN
                                                [
                                                    dbc.Input(
                                                        id={
                                                            "type": "home-input-isin",
                                                            "cfin": x["cfin"],
                                                        },
                                                        value=x["isin"],
                                                        n_submit=0,
                                                        placeholder=x["isin"]
                                                        or "Missing",
                                                        type="text",
                                                        className="home-input-field field-isin py-0",
                                                    ),
                                                    html.P(
                                                        "ISIN",
                                                        style={"font-size": "11px"},
                                                        className="mb-0",
                                                    ),
                                                    dbc.Toast(
                                                        id={
                                                            "type": "home-notif-isin",
                                                            "cfin": x["cfin"],
                                                        },
                                                        icon="success",
                                                        header="ISIN Update",
                                                        is_open=False,
                                                        dismissable=True,
                                                        duration=5000,
                                                        headerClassName="home-notif-header",
                                                        bodyClassName="home-notif-body",
                                                        className="home-notif-toast",
                                                    ),
                                                ],
                                                width="auto",
                                            ),
                                            dbc.Col(  # Ric Code
                                                [
                                                    dbc.Input(
                                                        id={
                                                            "type": "home-input-external-ric",
                                                            "cfin": x["cfin"],
                                                        },
                                                        value=x["external_ric"]
                                                        or x["ric"],
                                                        n_submit=0,
                                                        placeholder=x["external_ric"]
                                                        or "Missing",
                                                        type="text",
                                                        className="home-input-field field-ric py-0",
                                                    ),
                                                    html.P(
                                                        "External RIC",
                                                        style={"font-size": "11px"},
                                                        className="mb-0",
                                                    ),
                                                    dbc.Toast(
                                                        id={
                                                            "type": "home-notif-external-ric",
                                                            "cfin": x.get("cfin"),
                                                        },
                                                        icon="success",
                                                        header="External RIC Update",
                                                        is_open=False,
                                                        dismissable=True,
                                                        duration=5000,
                                                        headerClassName="home-notif-header",
                                                        bodyClassName="home-notif-body",
                                                        className="home-notif-toast",
                                                    ),
                                                ],
                                                width="auto",
                                            ),
                                            dbc.Col(  # External Ref
                                                [
                                                    dbc.Input(
                                                        id={
                                                            "type": "home-input-external-ref",
                                                            "cfin": x.get("cfin"),
                                                        },
                                                        value=x["external_ref"],
                                                        n_submit=0,
                                                        placeholder=x["external_ref"]
                                                        or "Missing",
                                                        type="text",
                                                        className="home-input-field field-ref py-0",
                                                    ),
                                                    html.P(
                                                        "External Ref",
                                                        style={"font-size": "11px"},
                                                        className="mb-0",
                                                    ),
                                                    dbc.Toast(
                                                        id={
                                                            "type": "home-notif-external-ref",
                                                            "cfin": x.get("cfin"),
                                                        },
                                                        icon="success",
                                                        header="External Ref Update",
                                                        is_open=False,
                                                        dismissable=True,
                                                        duration=5000,
                                                        headerClassName="home-notif-header",
                                                        bodyClassName="home-notif-body",
                                                        className="home-notif-toast",
                                                    ),
                                                ],
                                                style=no_display_if_none(x, "cfin_otc"),
                                                width="auto",
                                            ),
                                            dbc.Col(  # Last Bid
                                                [
                                                    html.H6(
                                                        f"Last Bid {x.get('last_bid')}",
                                                        className="mb-0",
                                                    ),
                                                    html.P(
                                                        x.get("last_date"),
                                                        style={"font-size": "11px"},
                                                        className="mb-0",
                                                    ),
                                                ],
                                                style=no_display_if_none(x, "last_bid"),
                                                width="auto",
                                            ),
                                        ]
                                    ),
                                ),
                            ],
                            className="pt-2",
                        ),
                    ],
                    width="auto",
                    className="test-col",
                ),
                dbc.Col(  # Column with Lottie to copy Text and Termsheets
                    dbc.Row(
                        [
                            dbc.Col(  # Copy Text to Clipboard
                                [
                                    dbc.Row(
                                        dbc.Col(
                                            [
                                                html.Div(
                                                    html.Div(
                                                        de.Lottie(
                                                            options=dict(
                                                                loop=False,
                                                                autoplay=False,
                                                                rendererSettings=dict(
                                                                    preserveAspectRatio="xMidYMid slice"
                                                                ),
                                                            ),
                                                            width=40,
                                                            height=40,
                                                            isStopped=True,
                                                            # id="home-lottie-eye",
                                                            url=f"/lottie/copy-to-clipboard.json",
                                                        ),
                                                        style={
                                                            "float": "center",
                                                            "top": "0px",
                                                            "display": "inline-block",
                                                        },
                                                        id={
                                                            "type": "home-copy-to-clipboard-lottie",
                                                            "index": x.get("cfin"),
                                                        },
                                                        n_clicks=0,
                                                    ),
                                                    style={
                                                        "float": "center",
                                                        "top": "0px",
                                                        "display": "inline-block",
                                                    },
                                                    id=f"home-copy-to-clipboard-{x.get('cfin')}",
                                                ),
                                                dcc.Store(
                                                    id={
                                                        "type": "home-copy-to-clipboard-store",
                                                        "index": x.get("cfin"),
                                                    },
                                                    storage_type="session",
                                                ),
                                            ],
                                            style={"textAlign": "center"},
                                        ),
                                        className="py-0",
                                    ),
                                    dbc.Row(
                                        dbc.Col(
                                            html.H6(
                                                "BBG Msg",
                                                className="mb-0",
                                                style={"color": "rgba(0, 0, 0, 0.8)"},
                                                id={
                                                    "type": "title-copy-msg",
                                                    "cfin": x.get("cfin"),
                                                },
                                            )
                                        ),
                                        justify="center",
                                        className="py-0",
                                    ),
                                ],
                                width="auto",
                            ),
                            dbc.Col(  # External Termsheet
                                [
                                    dbc.Row(
                                        dbc.Col(
                                            [
                                                html.Div(
                                                    [
                                                        html.A(
                                                            html.I(
                                                                className="far fa-file-pdf fa-2x",
                                                            ),
                                                            target="_blank",
                                                            style={
                                                                "color": "rgba(231, 76, 60, 1.0)"
                                                            }
                                                            if x.get("Hedge 1")
                                                            else {
                                                                "color": "rgba(231, 76, 60, 0.2)"
                                                            },
                                                            href=x.get("Hedge 1")
                                                            or x.get("Issuer"),
                                                            id={
                                                                "type": "icon-external-ts",
                                                                "cfin": x.get("cfin"),
                                                            },
                                                        ),
                                                    ],
                                                    id=f"button-external-ts-{x.get('cfin')}",
                                                ),
                                            ],
                                            style={"textAlign": "center"},
                                        ),
                                        className="py-2",
                                    ),
                                    dbc.Row(
                                        dbc.Col(
                                            html.H6(
                                                "External",
                                                className="mb-0",
                                                style={"color": "rgba(0, 0, 0, 0.8)"}
                                                if x.get("Hedge 1")
                                                else {"color": "rgba(0, 0, 0, 0.2)"},
                                                id={
                                                    "type": "title-external-ts",
                                                    "cfin": x.get("cfin"),
                                                },
                                            )
                                        ),
                                        justify="center",
                                    ),
                                ],
                                width="auto",
                            ),
                            dbc.Col(  # Exane Termsheet
                                [
                                    dbc.Row(
                                        dbc.Col(
                                            [
                                                html.Div(
                                                    [
                                                        html.A(
                                                            html.I(
                                                                className="far fa-file-pdf fa-2x",
                                                            ),
                                                            href=x.get("Exane"),
                                                            style={
                                                                "color": "rgba(231, 76, 60, 1.0)"
                                                            }
                                                            if x.get("Exane")
                                                            else {
                                                                "color": "rgba(231, 76, 60, 0.2)"
                                                            },
                                                            target="_blank",
                                                            id={
                                                                "type": "icon-exane-ts",
                                                                "cfin": x.get("cfin"),
                                                            },
                                                        ),
                                                    ],
                                                    id=f"button-exane-ts-{x.get('cfin')}",
                                                ),
                                            ],
                                            style={"textAlign": "center"},
                                        ),
                                        className="py-2",
                                    ),
                                    dbc.Row(
                                        dbc.Col(
                                            html.H6(
                                                "Exane",
                                                className="mb-0",
                                                style={"color": "rgba(0, 0, 0, 0.8)"}
                                                if x.get("Exane")
                                                else {"color": "rgba(0, 0, 0, 0.2)"},
                                                id={
                                                    "type": "title-exane-ts",
                                                    "cfin": x.get("cfin"),
                                                },
                                            )
                                        ),
                                        justify="center",
                                    ),
                                ],
                                width="auto",
                            ),
                        ]
                    ),
                    width="auto mx-4",
                ),
            ],
            align="center",
            justify="between",
            className="py-3 mb-3 borded-card",
            style={"paddingLeft": "32px"},
        )
        for x in sorted(data, key=lambda i: i["days_late"], reverse=True)
        if x["days_late"] < 0
    ]

    accordion_items = []
    if rows_of_late_products:
        accordion_items.append(
            dbc.AccordionItem(
                rows_of_late_products,
                title="Issued Products",
                style={"background-color": "#f5f5f5"},
            )
        )

    if rows_of_future_products:
        accordion_items.append(
            dbc.AccordionItem(
                rows_of_future_products,
                title="Not Issued Products",
                style={"background-color": "#f5f5f5"},
            )
        )

    result = dbc.Container(
        [
            dbc.Row(
                [
                    dbc.Col(
                        html.H1("Contribution Issues", style={"fontWeight": 800}),
                        width="auto",
                    ),
                    dbc.Col(
                        [
                            dbc.Spinner(
                                [
                                    html.Div(
                                        html.A(
                                            html.I(
                                                className="fas fa-sync-alt dark-grey",
                                                style={"fontSize": "1.2rem"},
                                            ),
                                            # href="/",
                                            target="_blank",
                                            id="home-icon-contrib-issues-reload",
                                        ),
                                        n_clicks=0,
                                        id="home-button-contrib-issues-reload",
                                    ),
                                    dbc.Tooltip(
                                        "Reload Contrib Issues data",
                                        target="home-icon-contrib-issues-reload",
                                        placement="bottom",
                                    ),
                                ],
                                size="sm",
                                type="grow",
                                color="secondary",
                                id="home-button-scheduler-spinner",
                            ),
                        ],
                        width=1,
                    ),
                ],
                align="center",
            ),
            dbc.Row(
                dbc.Col(
                    dbc.Accordion(
                        accordion_items,
                        flush=True,
                        start_collapsed=True,
                    )
                )
            ),
            # *rows_of_late_products,
            # *rows_of_future_products,
        ],
        fluid=True,
        className="pt-4 pb-2",
        style={"maxWidth": "85%"},
    )

    # containers = [
    #     dbc.Container(
    #         [
    #             dbc.Row(
    #                 [
    #                     dbc.Col(  # Column with Main Details
    #                         [
    #                             dbc.Row(  # Pill, Links, Issuer and Name
    #                                 [
    #                                     dbc.Col(
    #                                         [
    #                                             dbc.Badge(
    #                                                 "Missing"
    #                                                 if x.get("days_late") >= 0
    #                                                 else "Not Issued",
    #                                                 pill=True,
    #                                                 color="danger"
    #                                                 if x.get("days_late") >= 0
    #                                                 else "primary",
    #                                                 id=f"home-badge-{x['cfin']}",
    #                                             ),
    #                                             dbc.Tooltip(
    #                                                 x.get("cause"),
    #                                                 target=f"home-badge-{x['cfin']}",
    #                                             ),
    #                                         ],
    #                                         width="auto",
    #                                         className="pt-2 pr-0",
    #                                     ),
    #                                     icon_reuters(
    #                                         x["cfin"], x["ric"], className="px-2"
    #                                     ),
    #                                     dbc.Col(  # Issuer Name
    #                                         [
    #                                             html.H3(
    #                                                 x.get("issuer"),
    #                                                 className="m-0",
    #                                                 style={
    #                                                     "color": "#006266",
    #                                                     "fontFamily": "Roboto-Bold",
    #                                                 },
    #                                             ),
    #                                         ],
    #                                         width="auto",
    #                                         className="pl-0",
    #                                     ),
    #                                     dbc.Col(  # Product Name
    #                                         [
    #                                             html.H3(
    #                                                 x.get("name"),
    #                                                 style={
    #                                                     "fontFamily": "Roboto-Bold",
    #                                                     "font-weight": "200",
    #                                                 },
    #                                                 className="m-0",
    #                                             ),
    #                                         ],
    #                                         width="auto",
    #                                         className="pl-0",
    #                                     ),
    #                                     dbc.Col(  # Information Status
    #                                         [
    #                                             html.A(
    #                                                 html.I(
    #                                                     className="fas fa-circle fa-xs",
    #                                                     id=f"home-life-status-{x['cfin']}",
    #                                                 ),
    #                                                 id={
    #                                                     "type": "home-life-status-link",
    #                                                     "cfin": x.get("cfin"),
    #                                                 },
    #                                                 style={"color": "#16a085"},
    #                                             ),
    #                                             dbc.Tooltip(
    #                                                 children=dbc.Col(
    #                                                     dbc.Row(
    #                                                         [
    #                                                             dbc.Col(
    #                                                                 [
    #                                                                     dbc.Row(
    #                                                                         dbc.Col(
    #                                                                             html.H6(
    #                                                                                 "Update Product Status",
    #                                                                                 style={
    #                                                                                     "color": "rgba(0,0,0,0.87)"
    #                                                                                 },
    #                                                                             )
    #                                                                         )
    #                                                                     ),
    #                                                                     dbc.Row(
    #                                                                         [
    #                                                                             dbc.Col(
    #                                                                                 dbc.Button(
    #                                                                                     dbc.Spinner(
    #                                                                                         html.Div(
    #                                                                                             "Inactive",
    #                                                                                             id=f"home-button-status-inactive-spinner-{x.get('cfin')}",
    #                                                                                         ),
    #                                                                                         size="sm",
    #                                                                                         type="grow",
    #                                                                                         color="secondary",
    #                                                                                     ),
    #                                                                                     id={
    #                                                                                         "type": "home-button-status-inactive",
    #                                                                                         "cfin": x.get(
    #                                                                                             "cfin"
    #                                                                                         ),
    #                                                                                     },
    #                                                                                     size="sm",
    #                                                                                     n_clicks=0,
    #                                                                                     color="secondary",
    #                                                                                 )
    #                                                                             ),
    #                                                                             dbc.Col(
    #                                                                                 dbc.Button(
    #                                                                                     dbc.Spinner(
    #                                                                                         html.Div(
    #                                                                                             "Autocalled",
    #                                                                                             id=f"home-button-status-autocall-spinner-{x.get('cfin')}",
    #                                                                                         ),
    #                                                                                         size="sm",
    #                                                                                         type="grow",
    #                                                                                         color="secondary",
    #                                                                                     ),
    #                                                                                     id={
    #                                                                                         "type": "home-button-status-autocall",
    #                                                                                         "cfin": x.get(
    #                                                                                             "cfin"
    #                                                                                         ),
    #                                                                                     },
    #                                                                                     n_clicks=0,
    #                                                                                     size="sm",
    #                                                                                     color="secondary",
    #                                                                                 )
    #                                                                             ),
    #                                                                         ],
    #                                                                         className="my-2",
    #                                                                         justify="center",
    #                                                                     ),
    #                                                                 ],
    #                                                             ),
    #                                                         ],
    #                                                         className="p-2",
    #                                                     )
    #                                                 ),
    #                                                 target=f"home-life-status-{x['cfin']}",
    #                                                 class_name="home-tooltip-life-status",
    #                                                 placement="bottom",
    #                                                 # autohide=False,
    #                                                 delay={
    #                                                     "show": 250,
    #                                                     "hide": 400,
    #                                                 },
    #                                             ),
    #                                             dbc.Toast(
    #                                                 id={
    #                                                     "type": "home-notif-life-status",
    #                                                     "cfin": x["cfin"],
    #                                                 },
    #                                                 icon="success",
    #                                                 header="Update Status",
    #                                                 is_open=False,
    #                                                 dismissable=True,
    #                                                 duration=5000,
    #                                                 headerClassName="home-notif-header",
    #                                                 bodyClassName="home-notif-body",
    #                                                 className="home-notif-toast",
    #                                             ),
    #                                         ],
    #                                         width="auto",
    #                                         className="pl-0",
    #                                     ),
    #                                 ],
    #                                 align="center",
    #                                 className="mb-2",
    #                             ),
    #                             dbc.Row(  # Row of the Data
    #                                 [
    #                                     dbc.Col(  # Levels
    #                                         dbc.Row(
    #                                             [
    #                                                 dbc.Col(  # Issue Date
    #                                                     [
    #                                                         html.H6(
    #                                                             x.get("payment_date"),
    #                                                             className="mb-0",
    #                                                         ),
    #                                                         html.P(
    #                                                             text_days_late(
    #                                                                 x.get("days_late")
    #                                                             ),
    #                                                             style={
    #                                                                 "font-size": "11px"
    #                                                             },
    #                                                             className="mb-0",
    #                                                         ),
    #                                                     ],
    #                                                     width="auto",
    #                                                 ),
    #                                                 dbc.Col(  # Cfin
    #                                                     [
    #                                                         html.H6(
    #                                                             x.get("cfin"),
    #                                                             className="mb-0",
    #                                                         ),
    #                                                         html.P(
    #                                                             "Cfin Product",
    #                                                             style={
    #                                                                 "font-size": "11px"
    #                                                             },
    #                                                             className="mb-0",
    #                                                         ),
    #                                                     ],
    #                                                     width="auto",
    #                                                 ),
    #                                                 dbc.Col(  # Cfin OTC
    #                                                     [
    #                                                         html.H6(
    #                                                             x.get("cfin_otc"),
    #                                                             className="mb-0",
    #                                                         ),
    #                                                         html.P(
    #                                                             "Cfin OTC",
    #                                                             style={
    #                                                                 "font-size": "11px"
    #                                                             },
    #                                                             className="mb-0",
    #                                                         ),
    #                                                     ],
    #                                                     style=no_display_if_none(
    #                                                         x, "cfin_otc"
    #                                                     ),
    #                                                     width="auto",
    #                                                 ),
    #                                                 dbc.Col(  # ISIN
    #                                                     [
    #                                                         dbc.Input(
    #                                                             id={
    #                                                                 "type": "home-input-isin",
    #                                                                 "cfin": x["cfin"],
    #                                                             },
    #                                                             value=x["isin"],
    #                                                             n_submit=0,
    #                                                             placeholder=x["isin"]
    #                                                             or "Missing",
    #                                                             type="text",
    #                                                             className="home-input-field field-isin py-0",
    #                                                         ),
    #                                                         html.P(
    #                                                             "ISIN",
    #                                                             style={
    #                                                                 "font-size": "11px"
    #                                                             },
    #                                                             className="mb-0",
    #                                                         ),
    #                                                         dbc.Toast(
    #                                                             id={
    #                                                                 "type": "home-notif-isin",
    #                                                                 "cfin": x["cfin"],
    #                                                             },
    #                                                             icon="success",
    #                                                             header="ISIN Update",
    #                                                             is_open=False,
    #                                                             dismissable=True,
    #                                                             duration=5000,
    #                                                             headerClassName="home-notif-header",
    #                                                             bodyClassName="home-notif-body",
    #                                                             className="home-notif-toast",
    #                                                         ),
    #                                                     ],
    #                                                     width="auto",
    #                                                 ),
    #                                                 dbc.Col(  # Ric Code
    #                                                     [
    #                                                         dbc.Input(
    #                                                             id={
    #                                                                 "type": "home-input-external-ric",
    #                                                                 "cfin": x["cfin"],
    #                                                             },
    #                                                             value=x["external_ric"]
    #                                                             or x["ric"],
    #                                                             n_submit=0,
    #                                                             placeholder=x[
    #                                                                 "external_ric"
    #                                                             ]
    #                                                             or "Missing",
    #                                                             type="text",
    #                                                             className="home-input-field field-ric py-0",
    #                                                         ),
    #                                                         html.P(
    #                                                             "External RIC",
    #                                                             style={
    #                                                                 "font-size": "11px"
    #                                                             },
    #                                                             className="mb-0",
    #                                                         ),
    #                                                         dbc.Toast(
    #                                                             id={
    #                                                                 "type": "home-notif-external-ric",
    #                                                                 "cfin": x.get(
    #                                                                     "cfin"
    #                                                                 ),
    #                                                             },
    #                                                             icon="success",
    #                                                             header="External RIC Update",
    #                                                             is_open=False,
    #                                                             dismissable=True,
    #                                                             duration=5000,
    #                                                             headerClassName="home-notif-header",
    #                                                             bodyClassName="home-notif-body",
    #                                                             className="home-notif-toast",
    #                                                         ),
    #                                                     ],
    #                                                     width="auto",
    #                                                 ),
    #                                                 dbc.Col(  # External Ref
    #                                                     [
    #                                                         dbc.Input(
    #                                                             id={
    #                                                                 "type": "home-input-external-ref",
    #                                                                 "cfin": x.get(
    #                                                                     "cfin"
    #                                                                 ),
    #                                                             },
    #                                                             value=x["external_ref"],
    #                                                             n_submit=0,
    #                                                             placeholder=x[
    #                                                                 "external_ref"
    #                                                             ]
    #                                                             or "Missing",
    #                                                             type="text",
    #                                                             className="home-input-field field-ref py-0",
    #                                                         ),
    #                                                         html.P(
    #                                                             "External Ref",
    #                                                             style={
    #                                                                 "font-size": "11px"
    #                                                             },
    #                                                             className="mb-0",
    #                                                         ),
    #                                                         dbc.Toast(
    #                                                             id={
    #                                                                 "type": "home-notif-external-ref",
    #                                                                 "cfin": x.get(
    #                                                                     "cfin"
    #                                                                 ),
    #                                                             },
    #                                                             icon="success",
    #                                                             header="External Ref Update",
    #                                                             is_open=False,
    #                                                             dismissable=True,
    #                                                             duration=5000,
    #                                                             headerClassName="home-notif-header",
    #                                                             bodyClassName="home-notif-body",
    #                                                             className="home-notif-toast",
    #                                                         ),
    #                                                     ],
    #                                                     style=no_display_if_none(
    #                                                         x, "cfin_otc"
    #                                                     ),
    #                                                     width="auto",
    #                                                 ),
    #                                                 dbc.Col(  # Last Bid
    #                                                     [
    #                                                         html.H6(
    #                                                             f"Last Bid {x.get('last_bid')}",
    #                                                             className="mb-0",
    #                                                         ),
    #                                                         html.P(
    #                                                             x.get("last_date"),
    #                                                             style={
    #                                                                 "font-size": "11px"
    #                                                             },
    #                                                             className="mb-0",
    #                                                         ),
    #                                                     ],
    #                                                     style=no_display_if_none(
    #                                                         x, "last_bid"
    #                                                     ),
    #                                                     width="auto",
    #                                                 ),
    #                                             ]
    #                                         ),
    #                                     ),
    #                                 ],
    #                                 className="pt-2",
    #                             ),
    #                         ],
    #                         width="auto",
    #                         className="test-col",
    #                     ),
    #                     dbc.Col(  # Column with Lottie to copy Text and Termsheets
    #                         dbc.Row(
    #                             [
    #                                 dbc.Col(  # Copy Text to Clipboard
    #                                     [
    #                                         dbc.Row(
    #                                             dbc.Col(
    #                                                 [
    #                                                     html.Div(
    #                                                         html.Div(
    #                                                             de.Lottie(
    #                                                                 options=dict(
    #                                                                     loop=False,
    #                                                                     autoplay=False,
    #                                                                     rendererSettings=dict(
    #                                                                         preserveAspectRatio="xMidYMid slice"
    #                                                                     ),
    #                                                                 ),
    #                                                                 width=40,
    #                                                                 height=40,
    #                                                                 isStopped=True,
    #                                                                 # id="home-lottie-eye",
    #                                                                 url=f"/lottie/copy-to-clipboard.json",
    #                                                             ),
    #                                                             style={
    #                                                                 "float": "center",
    #                                                                 "top": "0px",
    #                                                                 "display": "inline-block",
    #                                                             },
    #                                                             id={
    #                                                                 "type": "home-copy-to-clipboard-lottie",
    #                                                                 "index": x.get(
    #                                                                     "cfin"
    #                                                                 ),
    #                                                             },
    #                                                             n_clicks=0,
    #                                                         ),
    #                                                         style={
    #                                                             "float": "center",
    #                                                             "top": "0px",
    #                                                             "display": "inline-block",
    #                                                         },
    #                                                         id=f"home-copy-to-clipboard-{x.get('cfin')}",
    #                                                     ),
    #                                                     dcc.Store(
    #                                                         id={
    #                                                             "type": "home-copy-to-clipboard-store",
    #                                                             "index": x.get("cfin"),
    #                                                         },
    #                                                         storage_type="session",
    #                                                     ),
    #                                                 ],
    #                                                 style={"textAlign": "center"},
    #                                             ),
    #                                             className="py-0",
    #                                         ),
    #                                         dbc.Row(
    #                                             dbc.Col(
    #                                                 html.H6(
    #                                                     "BBG Msg",
    #                                                     className="mb-0",
    #                                                     style={
    #                                                         "color": "rgba(0, 0, 0, 0.8)"
    #                                                     },
    #                                                     id={
    #                                                         "type": "title-copy-msg",
    #                                                         "cfin": x.get("cfin"),
    #                                                     },
    #                                                 )
    #                                             ),
    #                                             justify="center",
    #                                             className="py-0",
    #                                         ),
    #                                     ],
    #                                     width="auto",
    #                                 ),
    #                                 dbc.Col(  # External Termsheet
    #                                     [
    #                                         dbc.Row(
    #                                             dbc.Col(
    #                                                 [
    #                                                     html.Div(
    #                                                         [
    #                                                             html.A(
    #                                                                 html.I(
    #                                                                     className="far fa-file-pdf fa-2x",
    #                                                                 ),
    #                                                                 target="_blank",
    #                                                                 style={
    #                                                                     "color": "rgba(231, 76, 60, 1.0)"
    #                                                                 }
    #                                                                 if x.get("Hedge 1")
    #                                                                 else {
    #                                                                     "color": "rgba(231, 76, 60, 0.2)"
    #                                                                 },
    #                                                                 href=x.get(
    #                                                                     "Hedge 1"
    #                                                                 )
    #                                                                 or x.get("Issuer"),
    #                                                                 id={
    #                                                                     "type": "icon-external-ts",
    #                                                                     "cfin": x.get(
    #                                                                         "cfin"
    #                                                                     ),
    #                                                                 },
    #                                                             ),
    #                                                         ],
    #                                                         id=f"button-external-ts-{x.get('cfin')}",
    #                                                     ),
    #                                                 ],
    #                                                 style={"textAlign": "center"},
    #                                             ),
    #                                             className="py-2",
    #                                         ),
    #                                         dbc.Row(
    #                                             dbc.Col(
    #                                                 html.H6(
    #                                                     "External",
    #                                                     className="mb-0",
    #                                                     style={
    #                                                         "color": "rgba(0, 0, 0, 0.8)"
    #                                                     }
    #                                                     if x.get("Hedge 1")
    #                                                     else {
    #                                                         "color": "rgba(0, 0, 0, 0.2)"
    #                                                     },
    #                                                     id={
    #                                                         "type": "title-external-ts",
    #                                                         "cfin": x.get("cfin"),
    #                                                     },
    #                                                 )
    #                                             ),
    #                                             justify="center",
    #                                         ),
    #                                     ],
    #                                     width="auto",
    #                                 ),
    #                                 dbc.Col(  # Exane Termsheet
    #                                     [
    #                                         dbc.Row(
    #                                             dbc.Col(
    #                                                 [
    #                                                     html.Div(
    #                                                         [
    #                                                             html.A(
    #                                                                 html.I(
    #                                                                     className="far fa-file-pdf fa-2x",
    #                                                                 ),
    #                                                                 href=x.get("Exane"),
    #                                                                 style={
    #                                                                     "color": "rgba(231, 76, 60, 1.0)"
    #                                                                 }
    #                                                                 if x.get("Exane")
    #                                                                 else {
    #                                                                     "color": "rgba(231, 76, 60, 0.2)"
    #                                                                 },
    #                                                                 target="_blank",
    #                                                                 id={
    #                                                                     "type": "icon-exane-ts",
    #                                                                     "cfin": x.get(
    #                                                                         "cfin"
    #                                                                     ),
    #                                                                 },
    #                                                             ),
    #                                                         ],
    #                                                         id=f"button-exane-ts-{x.get('cfin')}",
    #                                                     ),
    #                                                 ],
    #                                                 style={"textAlign": "center"},
    #                                             ),
    #                                             className="py-2",
    #                                         ),
    #                                         dbc.Row(
    #                                             dbc.Col(
    #                                                 html.H6(
    #                                                     "Exane",
    #                                                     className="mb-0",
    #                                                     style={
    #                                                         "color": "rgba(0, 0, 0, 0.8)"
    #                                                     }
    #                                                     if x.get("Exane")
    #                                                     else {
    #                                                         "color": "rgba(0, 0, 0, 0.2)"
    #                                                     },
    #                                                     id={
    #                                                         "type": "title-exane-ts",
    #                                                         "cfin": x.get("cfin"),
    #                                                     },
    #                                                 )
    #                                             ),
    #                                             justify="center",
    #                                         ),
    #                                     ],
    #                                     width="auto",
    #                                 ),
    #                             ]
    #                         ),
    #                         width="auto mx-4",
    #                     ),
    #                 ],
    #                 align="center",
    #                 justify="between",
    #                 className="py-3 mb-3 borded-card",
    #                 style={"paddingLeft": "32px", "maxWidth": "65%"},
    #             )
    #         ],
    #         # className="py-3 mb-3 borded-card",
    #         # style={"paddingLeft": "32px", "maxWidth": "65%"},
    #         # fluid=True,
    #         # className="pt-4 pb-2",
    #         # style={"maxWidth": "80%"},
    #     )
    #     for x in sorted(data, key=lambda i: i["days_late"], reverse=True)
    # ]

    return result


@app.callback(
    Output({"type": "home-notif-search-external-ref", "cfin": MATCH}, "children"),
    Output({"type": "home-notif-search-external-ref", "cfin": MATCH}, "icon"),
    Output({"type": "home-notif-search-external-ref", "cfin": MATCH}, "is_open"),
    Output({"type": "home-input-search-external-ref", "cfin": MATCH}, "value"),
    Input({"type": "home-input-search-external-ref", "cfin": MATCH}, "n_submit"),
    State({"type": "home-input-search-external-ref", "cfin": MATCH}, "value"),
    State({"type": "home-input-search-external-ref", "cfin": MATCH}, "placeholder"),
    State({"type": "home-input-search-external-ref", "cfin": MATCH}, "id"),
    prevent_initial_call=True,
)
def searched_product_update_external_ref(n_submit, value, placeholder, id):
    if n_submit > 0 and value:

        if value != placeholder:

            cfin = str(id["cfin"])

            if insert_or_update_code(cfin, value, kind="issuer_ref"):
                msg = html.P(f"You have set {value} for {cfin}", className="mb-0")
                return msg, "success", True, value

            else:
                msg = "You don't have enough rights or Code already in DataBase"
                p = html.P(msg, className="mb-0")
                return p, "danger", True, placeholder
    raise PreventUpdate


@app.callback(
    Output({"type": "home-notif-search-external-ric", "cfin": MATCH}, "children"),
    Output({"type": "home-notif-search-external-ric", "cfin": MATCH}, "icon"),
    Output({"type": "home-notif-search-external-ric", "cfin": MATCH}, "is_open"),
    Output({"type": "home-input-search-external-ric", "cfin": MATCH}, "value"),
    Input({"type": "home-input-search-external-ric", "cfin": MATCH}, "n_submit"),
    State({"type": "home-input-search-external-ric", "cfin": MATCH}, "value"),
    State({"type": "home-input-search-external-ric", "cfin": MATCH}, "placeholder"),
    State({"type": "home-input-search-external-ric", "cfin": MATCH}, "id"),
    prevent_initial_call=True,
)
def searched_product_update_external_ric(n_submit, value, placeholder, id):
    if n_submit > 0 and value:

        if value != placeholder:

            cfin = str(id["cfin"])

            if insert_or_update_code(cfin, value, kind="issuer_ric"):
                cache.delete("contrib")
                msg = html.P(f"You have set {value} for {cfin}", className="mb-0")
                return msg, "success", True, value

            else:
                msg = html.P("You don't have enough rights", className="mb-0")
                return msg, "danger", True, placeholder

    raise PreventUpdate


@app.callback(
    Output({"type": "home-notif-search-isin", "cfin": MATCH}, "children"),
    Output({"type": "home-notif-search-isin", "cfin": MATCH}, "icon"),
    Output({"type": "home-notif-search-isin", "cfin": MATCH}, "is_open"),
    Output({"type": "home-input-search-isin", "cfin": MATCH}, "value"),
    Input({"type": "home-input-search-isin", "cfin": MATCH}, "n_submit"),
    State({"type": "home-input-search-isin", "cfin": MATCH}, "value"),
    State({"type": "home-input-search-isin", "cfin": MATCH}, "placeholder"),
    State({"type": "home-input-search-isin", "cfin": MATCH}, "id"),
    prevent_initial_call=True,
)
def searched_product_update_code_isin(n_submit, value, placeholder, id):
    if n_submit > 0 and value:

        if value != placeholder:
            cfin = str(id["cfin"])

            # Check length of the input
            if not is_isin(value):
                msg = html.P(
                    "The code must have 12 characters and start with 2 or 5 letters",
                    className="mb-0",
                )
                return msg, "danger", True, placeholder

            if insert_or_update_code(cfin, value, kind="isin"):
                cache.delete("contrib")
                msg = html.P(f"You have set {value} for {cfin}", className="mb-0")
                return msg, "success", True, value

            else:
                msg = html.P("You don't have enough rights", className="mb-0")
                return msg, "danger", True, placeholder
    raise PreventUpdate


@app.callback(
    Output({"type": "home-life-status-link", "cfin": MATCH}, "style"),
    Output({"type": "home-notif-life-status", "cfin": MATCH}, "children"),
    Output({"type": "home-notif-life-status", "cfin": MATCH}, "icon"),
    Output({"type": "home-notif-life-status", "cfin": MATCH}, "is_open"),
    Input({"type": "home-button-status-inactive", "cfin": MATCH}, "n_clicks"),
    Input({"type": "home-button-status-autocall", "cfin": MATCH}, "n_clicks"),
    State({"type": "home-button-status-inactive", "cfin": MATCH}, "id"),
    State({"type": "home-button-status-inactive", "cfin": MATCH}, "children"),
    State({"type": "home-life-status-link", "cfin": MATCH}, "style"),
    prevent_initial_call=True,
)
def button_update_product_status(clicks_inactive, clicks_autocall, id, status, style):
    if clicks_inactive > 0 or clicks_autocall > 0:
        cfin = str(id["cfin"])

        # Get details on which button was triggered
        ctx = callback_context
        triggered = ctx.triggered[0]["prop_id"].split(".")[0]

        # If user clicked on button "Inactive"
        if "inactive" in triggered:
            # status = str(status).lower()
            status = "inactive"
            if update_product_status(cfin=cfin, status=status):
                cache.delete("contrib")
                style = {
                    "color": "#c0392b" if status == "inactive" else "rgb(21, 175, 21)"
                }
                msg = html.P(f"You have set {cfin} as {status}", className="mb-0")
                return style, msg, "success", True

        # If user clicked on button "Autocalled"
        if "autocall" in triggered:
            if update_product_status(cfin, status="autocall"):
                cache.delete("contrib")
                msg = html.P(f"You have set {cfin} as Autocalled", className="mb-0")
                style = {"color": "#d35400"}
                return style, msg, "success", True

        # Error message in case user does not have enough rights
        msg = html.P("You don't have enough rights", className="mb-0")
        return style, msg, "danger", True
    raise PreventUpdate


@app.callback(
    Output({"type": "home-notif-external-ref", "cfin": MATCH}, "children"),
    Output({"type": "home-notif-external-ref", "cfin": MATCH}, "icon"),
    Output({"type": "home-notif-external-ref", "cfin": MATCH}, "is_open"),
    Output({"type": "home-input-external-ref", "cfin": MATCH}, "value"),
    Input({"type": "home-input-external-ref", "cfin": MATCH}, "n_submit"),
    State({"type": "home-input-external-ref", "cfin": MATCH}, "value"),
    State({"type": "home-input-external-ref", "cfin": MATCH}, "placeholder"),
    State({"type": "home-input-external-ref", "cfin": MATCH}, "id"),
    prevent_initial_call=True,
)
def update_external_ref(n_submit, value, placeholder, id):
    if n_submit > 0 and value:

        if value != placeholder:

            cfin = str(id["cfin"])

            if insert_or_update_code(cfin, value, kind="issuer_ref"):
                cache.delete("contrib")
                msg = html.P(f"You have set {value} for {cfin}", className="mb-0")
                return msg, "success", True, value

            else:
                msg = html.P("You don't have enough rights", className="mb-0")
                return msg, "danger", True, placeholder
    raise PreventUpdate


@app.callback(
    Output({"type": "home-notif-external-ric", "cfin": MATCH}, "children"),
    Output({"type": "home-notif-external-ric", "cfin": MATCH}, "icon"),
    Output({"type": "home-notif-external-ric", "cfin": MATCH}, "is_open"),
    Output({"type": "home-input-external-ric", "cfin": MATCH}, "value"),
    Input({"type": "home-input-external-ric", "cfin": MATCH}, "n_submit"),
    State({"type": "home-input-external-ric", "cfin": MATCH}, "value"),
    State({"type": "home-input-external-ric", "cfin": MATCH}, "placeholder"),
    State({"type": "home-input-external-ric", "cfin": MATCH}, "id"),
    prevent_initial_call=True,
)
def update_external_ric(n_submit, value, placeholder, id):
    if n_submit > 0 and value:

        if value != placeholder:

            cfin = str(id["cfin"])

            if insert_or_update_code(cfin, value, kind="issuer_ric"):
                cache.delete("contrib")
                msg = html.P(f"You have set {value} for {cfin}", className="mb-0")
                return msg, "success", True, value

            else:
                msg = html.P("You don't have enough rights", className="mb-0")
                return msg, "danger", True, placeholder

    raise PreventUpdate


@app.callback(
    Output({"type": "home-notif-isin", "cfin": MATCH}, "children"),
    Output({"type": "home-notif-isin", "cfin": MATCH}, "icon"),
    Output({"type": "home-notif-isin", "cfin": MATCH}, "is_open"),
    Output({"type": "home-input-isin", "cfin": MATCH}, "value"),
    Input({"type": "home-input-isin", "cfin": MATCH}, "n_submit"),
    State({"type": "home-input-isin", "cfin": MATCH}, "value"),
    State({"type": "home-input-isin", "cfin": MATCH}, "placeholder"),
    State({"type": "home-input-isin", "cfin": MATCH}, "id"),
    prevent_initial_call=True,
)
def update_code_isin(n_submit, value, placeholder, id):
    if n_submit > 0 and value:

        if value != placeholder:
            cfin = str(id["cfin"])

            # Check length of the input
            if not is_isin(value):
                msg = html.P(
                    "The code must have 12 characters and start with 2 or 5 letters",
                    className="mb-0",
                )
                return msg, "danger", True, placeholder

            if insert_or_update_code(cfin, value, kind="isin"):
                cache.delete("contrib")
                msg = html.P(f"You have set {value} for {cfin}", className="mb-0")
                return msg, "success", True, value

            else:
                msg = html.P("You don't have enough rights", className="mb-0")
                return msg, "danger", True, placeholder
    raise PreventUpdate


@app.callback(
    Output("modal-check-exane", "is_open"),
    Output("modal-body-check-exane", "children"),
    Input("home-checked-historical-values", "n_clicks"),
    State("home-search-cfin", "data"),
    prevent_initial_call=True,
)
def modal_exane_histo_level_check(n_clicks, data):
    if not n_clicks:
        raise PreventUpdate

    df = historical_prices_exane_and_reuters(data.get("cfin"), formatting=True)

    if not df.empty:
        tbl = dbc.Table.from_dataframe(
            df,
            striped=True,
            bordered=True,
            hover=True,
            size="sm",
            className="bg-light",
        )
        return True, tbl

    return True, "Our historical database is empty"


@app.callback(
    Output("home-search-cfin", "data"),
    Output("home-search-cfin", "clear_data"),
    Output({"type": "url", "page": "home"}, "search"),
    Output("home-check-container", "style"),
    Input("turfu-search-input", "value"),
    State({"type": "url", "page": "home"}, "search"),
    State("home-search-cfin", "data"),
)
def convert_search_input_to_cfin(value_input, search, data):
    if not value_input and not data:
        j = cfin_from_search(search).json
        if j.get("status") == 200:
            return (
                j,
                False,
                f"?cfin={j.get('cfin')}",
                {"width": "1700px"},
            )
        raise PreventUpdate

    r = anything_to_cfin(value_input)

    no_result = ["", True, "", {"display": "none"}]

    if r.status_code != 200:
        return no_result

    j = r.json

    if j.get("status", 404) != 200:
        return no_result

    cfin = j.get("cfin")

    if search:
        parsed_cfin = parse_qs(search[1:]).get("cfin")
        if parsed_cfin:
            if parsed_cfin[0] == str(cfin):
                raise PreventUpdate

    msg = f"{current_user.displayname} is checking {cfin} on Home"
    app.logger.info(msg)

    return (
        j,
        False,
        f"?cfin={cfin}",
        {"width": "1700px"},
    )


@app.callback(
    Output("home-searched-graph", "children"), Input("home-search-cfin", "data")
)
def check_product_graph(data):
    if not data:
        return ""

    # Check if template Osiris is available
    d = instrument_details(data)
    if d.json.get("status") == 200:
        return ""

    g = graph_common_product(data)

    if g is None:
        return ""

    return dbc.Row(
        dbc.Col(
            [
                dbc.Row(
                    dbc.Col(
                        card_title("Performances"),
                    )
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            g,
                            width=12,
                        ),
                    ],
                ),
            ],
            className="borded-card p-4 m-1",
        ),
    )


@app.callback(
    Output("home-searched-trades", "children"), Input("home-search-cfin", "data")
)
def check_product_trades_pott_and_open_positions(data):
    if not data:
        return ""

    cfin = data.get("cfin")

    df_pott, details, status = trades_summary(cfin)

    op = OpenPositions()
    df_positions = op.formatted_trades_for_cfin(cfin)

    # Don't show the Sales Status in the main page
    if "Sales Status" in df_positions.columns:
        df_positions = df_positions.drop(columns="Sales Status")

    if status != 200:
        return ""

    # Initialize the list of data that will appear as KPIs in the Pricing card
    key_trades_data = []

    # Add sales margin if relevant
    sales_margin = details.get("total_margin")
    if sales_margin:
        key_trades_data.append({"name": "Sales Margin", "value": f"EUR {sales_margin}"})

    # Determine sales involved
    sales = ""
    if not df_positions.empty:
        sales = ", ".join(list(df_positions.Sales.unique()))
    if not sales:
        sales = details.get("sales")
    if sales:
        key_trades_data.append({"name": "Sales", "value": sales})

    # Add the Trading Positions if any
    if details.get("positions"):
        value = f"{details.get('ccy')} {details.get('positions')}"
        d = {"name": "Trading Position", "value": value, "tooltip": []}

        # Add the Issued Position as a tooltip if any
        issued = details.get("issued")
        if issued and issued != "0":
            value = f"{details.get('ccy')} {details.get('issued')}"
            d["tooltip"].append({"name": "Issued Position", "value": value})

        # Add the OTC Position as a tooltip if any
        positions_otc = details.get("positions_otc")
        if positions_otc and positions_otc != "0":
            value = f"{details.get('ccy')} {details.get('positions_otc')}"
            d["tooltip"].append({"name": "OTC Position", "value": value})

        key_trades_data.append(d)

    if not df_positions.empty:
        if "Amount" in df_positions.columns:
            # Add the Client Positions if any and if product is alive
            coeff = abs(
                df_positions.loc[0, "Amount"]
                / (df_positions.loc[0, "Price"] * df_positions.loc[0, "Quantity"])
            )
            value = f"{details.get('ccy')}  {(df_positions.Amount / df_positions.Price).sum() * details.get('nominal') / coeff:,.0f}"
            key_trades_data.append({"name": "Client Position", "value": value})
        elif "Quantity" in df_positions.columns:
            # Add the Client Positions if any and if product is alive
            value = f"{df_positions.Quantity.sum():,.0f} units"
            key_trades_data.append({"name": "Client Quantity", "value": value})

        trades_open_position = scrollable_table(
            df_positions, maxHeight="200px", fontSize="12px"
        )
    else:
        trades_open_position = html.H4(
            "No reference to a client or Service Down", style={"font-weight": 400}
        )

    # Check if the product is in a Flex
    lst_flex = sql_amc.cfins_amc_from_cfin_underlying(cfin)
    if lst_flex:
        if len(lst_flex) > 2:
            key_trades_data.append(
                {
                    "name": "Collection",
                    "value": f"Member of {len(lst_flex)} collections",
                }
            )
        else:
            flex_tickers = ", ".join(
                [x.get("ticker_index") for x in lst_flex if x.get("ticker_index")]
            )
            key_trades_data.append({"name": "Collection Ticker", "value": flex_tickers})
            flex_names = ", ".join([x.get("name_index") for x in lst_flex])
            key_trades_data.append({"name": "Collection Name", "value": flex_names})

    return dbc.Row(
        dbc.Col(
            [
                dbc.Row(
                    dbc.Col(
                        card_title("Trades"),
                    )
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                html.Div(
                                    [
                                        html.H4(
                                            d["value"],
                                            style={"font-weight": "400"},
                                            className="mb-1",
                                        ),
                                        html.H6(
                                            d["name"],
                                            style={"font-weight": "400"},
                                        ),
                                    ],
                                    id=f"home-trades-figures-{d['name'].replace(' ', '-')}",
                                ),
                                dbc.Popover(
                                    [
                                        dbc.PopoverHeader(f"{d['name']} in Details"),
                                        dbc.PopoverBody(
                                            [
                                                html.P(
                                                    f"{x.get('name')} - {x.get('value')}",
                                                    style={
                                                        "padding": "5px 0px 5px 0px",
                                                        "margin": "0",
                                                    },
                                                )
                                                for x in d.get("tooltip", [])
                                            ]
                                        ),
                                    ],
                                    id=f"home-trades-popover-{d['name'].replace(' ', '-')}",
                                    target=f"home-trades-figures-{d['name'].replace(' ', '-')}",
                                    trigger="hover",
                                    placement="top",
                                    hide_arrow=True,
                                    style=no_display_if_none(d, "tooltip"),
                                ),
                            ],
                            width="auto",
                            className="mr-3",
                        )
                        for d in key_trades_data
                    ],
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                card_subtitle("Booking"),
                                scrollable_table(
                                    df_pott, maxHeight="200px", fontSize="12px"
                                ),
                            ],
                            className="table-sm px-3",
                            width=6,
                        ),
                        dbc.Col(
                            [card_subtitle("Open Positions"), trades_open_position],
                            className="table-sm pl-4 pr-3",
                            width=6,
                        ),
                    ],
                    justify="between",
                ),
            ],
            className="borded-card p-4 m-1",
        ),
    )


@app.callback(
    Output("home-searched-pricing", "children"), Input("home-search-cfin", "data")
)
def check_product_pricing_details(data):
    if not data:
        return ""

    cfin = data.get("cfin")

    df = sql.greeks_from_pricing_results(cfin)

    return dbc.Row(
        dbc.Col(
            [
                dbc.Row(
                    dbc.Col(
                        card_title("Pricing"),
                    )
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                card_subtitle("Greeks"),
                                scrollable_table(df, maxHeight="200px", fontSize="12px")
                                if not df.empty
                                else html.H4(
                                    "No data for this product",
                                    style={"font-weight": 400},
                                ),
                            ],
                            className="table-sm px-3",
                            width=6,
                        ),
                        dbc.Col(
                            [
                                dbc.Row(
                                    [
                                        dbc.Col(card_subtitle("Script")),
                                        dbc.Col(
                                            html.Div(
                                                [
                                                    dbc.RadioItems(
                                                        options=[
                                                            {
                                                                "label": "Note",
                                                                "value": 1,
                                                            },
                                                            {
                                                                "label": "OTC",
                                                                "value": 2,
                                                            },
                                                        ],
                                                        value=1,
                                                        inline=True,
                                                        id="home-script-switch",
                                                    ),
                                                ],
                                                className="mb-0"
                                                if alien(cfin).get(53)
                                                else "d-none",
                                            ),
                                            width=4,
                                        ),
                                        dbc.Col(
                                            html.Div(
                                                [
                                                    de.Lottie(
                                                        options=dict(
                                                            loop=False,
                                                            autoplay=False,
                                                            rendererSettings=dict(
                                                                preserveAspectRatio="xMidYMid slice"
                                                            ),
                                                        ),
                                                        width="65%",
                                                        height="65%",
                                                        id="home-lottie-eye",
                                                        url="/lottie/script-eye.json",
                                                    )
                                                ],
                                                n_clicks=0,
                                                id="home-button-script-eye",
                                            ),
                                            width=1,
                                        ),
                                        dbc.Col(
                                            html.Div(
                                                [
                                                    html.A(
                                                        html.I(
                                                            className="fas fa-download dark-grey",
                                                            style={
                                                                "fontSize": "1.2rem"
                                                            },
                                                        ),
                                                        target="_blank",
                                                    ),
                                                ],
                                                n_clicks=0,
                                                id="home-button-script-download",
                                            ),
                                            width=1,
                                        ),
                                    ],
                                    justify="between",
                                    align="center",
                                ),
                                dbc.Tooltip(
                                    children="Display the Script",
                                    target="home-button-script-eye",
                                    # autohide=False,
                                    delay={"show": 250, "hide": 250},
                                    placement="bottom",
                                    class_name="p-2",
                                ),
                                dbc.Tooltip(
                                    children="Download the Script",
                                    target="home-button-script-download",
                                    # autohide=False,
                                    delay={"show": 250, "hide": 250},
                                    placement="bottom",
                                    class_name="p-2",
                                ),
                                de.Download(id="home-download-script"),
                                dbc.Row(
                                    dbc.Col(
                                        [
                                            html.Div(
                                                id="home-script-content",
                                                style={
                                                    "fontSize": "0.7rem",
                                                    "lineHeight": "1rem",
                                                    "maxHeight": "200px",
                                                },
                                                className="table-responsive overflow-auto scrollable-div",
                                            ),
                                            dcc.Store(
                                                id="home-script-data",
                                                storage_type="memory",
                                            ),
                                        ],
                                    )
                                ),
                            ],
                            width=6,
                        ),
                    ],
                ),
            ],
            className="borded-card p-4 m-1",
        ),
    )


@app.callback(
    Output("home-button-script-download", "className"),
    Output("home-button-script-eye", "className"),
    Input("home-script-data", "data"),
)
def hide_script_download_button_if_no_script(data):
    return (None, None) if data else ("d-none", "d-none")


@app.callback(
    Output("home-script-content", "children"),
    Input("home-script-data", "data"),
)
def display_script(data_script):
    if data_script:
        colors = {
            "red": "#e74c3c",
            "green": "#16a085",
            "blue": "#2980b9",
            "dark_blue": "#2c3e50",
        }

        mapping = {}

        red_values = ["begin", "end", ":for", ":next", ":define"]
        for x in red_values:
            mapping[x] = {"color": "red"}

        blue_and_bold = [
            "model ",
            "prec ",
            "float ",
            "date ",
            "int ",
            "svar ",
            "tvar ",
            "mvar ",
            "pvar ",
            "future ",
            "rate ",
            "volrate ",
        ]
        for x in blue_and_bold:
            mapping[x] = {"color": "blue", "weight": "bold"}

        bold = [
            " id",
            " sum",
            " diff",
            " mult",
            " div",
            " neg",
            " max",
            " min",
            " avg",
            " callput",
            " callputnom",
            " onebound",
            " twobound",
            " weightsum",
            " perf",
            " log",
            " exp",
            " pow",
            " ent",
            " shiftcal",
            " shiftwrk",
            " numdaycal",
            " numdaywrk",
            " validtime",
            " before",
            " notafter",
            " firsttime",
            " lasttime",
            " athit",
            " firstrank",
            " lastrank",
            " floatindex",
            " dateindex",
            " rtnvar",
            " large",
            " small",
            " maxseq",
            " abs",
            " largerank",
            " smallrank",
            " in",
            " weightavg",
            " eqmod",
            " shiftmonthcal",
            " ordsum",
            " subavg",
            " shiftmonthwrk",
            " volfwd",
            " polynom",
            " spline",
            " dividend<xy>",
            " eqdate",
            " istoday",
            " repodf",
            " extractspreaddefault",
            " normdist",
            " cumnormdist",
            " extractrecovery",
            " extractsmilefactor",
            " extractsmile",
            " extractcorrelrefspot",
            " onesoftbound",
            " twosoftbound",
        ]
        for x in bold:
            mapping[x] = {"weight": "bold"}

        span = "<span style='color:{}; font-weight: {}'>{}</span>"

        for k, v in mapping.items():
            data_script = data_script.replace(
                k, span.format(colors.get(v.get("color"), "black"), v.get("weight"), k)
            )

        split_script = data_script.splitlines()

        # Check schemas in elements
        for k, value in enumerate(split_script):
            if value[:2] == "/!":
                split_script[k] = "<span style='color:{}'>{}</span>".format(
                    colors["green"], split_script[k]
                )
            elif value[:1] == "/":
                split_script[
                    k
                ] = f"<span class='script comment'>{split_script[k]}</span>"

        split_script = [
            f"<pre class='script'>{x}</pre>" if x else "<br/>" for x in split_script
        ]

        text = "".join(split_script)

        return DangerouslySetInnerHTML(f"""{text}""")

    return html.H4("No Script for this product", style={"font-weight": 400})


@app.callback(
    Output("home-script-data", "data"),
    Input("home-script-switch", "value"),
    State("home-search-cfin", "data"),
)
def download_script(value, data):
    if data:
        script = ""
        cfin = data.get("cfin")

        # If user selects Note
        if value == 1:
            script = script_for_cfin(cfin=cfin)
            if not script:
                # Check if script is on product's component with type 122
                cfin_compo = components(cfin).get(122)

                # Check if there is a nested 122 component
                cfin_compo = components(cfin_compo).get(122, cfin_compo)

                # Check if script is on product's component of type 241
                if not cfin_compo:
                    cfin_script = components(cfin).get(241)
                    cfin_compo = components(cfin_script).get(122, cfin_script)
                script = script_for_cfin(cfin=cfin_compo)

        # If user selects OTC
        elif value == 2:
            cfin_lien = alien(cfin).get(53)
            if cfin_lien:
                cfin_lien = str(cfin_lien)
                script = script_for_cfin(cfin=cfin_lien)

        # Return the script if any
        if script:
            return script

    return ""


@app.callback(
    Output("home-script-content", "style"),
    Input("home-button-script-eye", "n_clicks"),
    State("home-script-content", "style"),
)
def display_script_button(n_clicks, style):
    if (n_clicks % 2) != 0:
        style.pop("maxHeight", None)
        return style
    style["maxHeight"] = "200px"
    return style


@app.callback(
    Output("home-download-script", "data"),
    Input("home-button-script-download", "n_clicks"),
    State("home-script-data", "data"),
    State("home-search-cfin", "data"),
)
def download_script_button(n_clicks, data_script, data_cfin):
    if n_clicks:

        cfin = data_cfin.get("cfin")

        if data_script:
            today = dt_today("string_figures")
            filename = f"script_{cfin}_{today}.txt"

            return {"content": data_script, "filename": filename}

    raise PreventUpdate


@app.callback(
    Output("turfu-search-input", "value"),
    Input({"type": "url", "page": "home"}, "search"),
    State("turfu-search-input", "value"),
    State("home-searched-main-details", "data"),
)
def contrib_parse_url_for_cfins(search, value, data):
    if not search or len(search) < 1:
        raise PreventUpdate

    if not data and not value:
        r = cfin_from_search(search)
        cfin = r.json.get("cfin")
        if cfin:
            return cfin

    raise PreventUpdate


@app.callback(
    Output("home-popover-more-infos-body", "children"),
    Input("home-product-details-popover", "is_open"),
    State("home-popover-more-infos-body", "children"),
    State("home-search-cfin", "data"),
    prevent_initial_call=True,
)
def add_options_to_edit_product_status(is_open, content, data):
    if is_open:

        # Check if the user is a structurer
        if any(x in current_user.department_id for x in ["STR", "DCO"]):

            # Get product's data
            cfin = data.get("cfin")
            cfin_alive = "mort" not in str(sql.status_for_cfin(cfin)).lower()

            result = (
                db.session.query(
                    Alien.alcfin.label("cfin"),
                    Instrument.ifnom.label("name"),
                    Alien.alsjac.label("sjac"),
                    Alien.altype.label("type"),
                    Typelien.tlnom.label("type_name"),
                )
                .join(
                    (Typelien, Typelien.tlcode == Alien.altype),
                    (Instrument, Instrument.ifcfin == Alien.alcfin),
                )
                .filter(or_(Alien.alsjac == cfin, Alien.alcfin == cfin))
            ).all()

            cfin_otc_list = []
            for x in result:
                if x.type == 53:
                    cfin_otc_list.append(str(x.cfin))
            if len(cfin_otc_list) > 1:
                cfin_otc = " / ".join(cfin_otc_list)
            else:
                cfin_otc = sql.alien(data.get("cfin")).get(53)

            drop_items = [
                dbc.DropdownMenuItem(
                    children="OTC",
                    id={
                        "type": "home-popover-dropdown-aliens-otc",
                        "cfin": cfin,
                    },
                ),
                dbc.DropdownMenuItem(
                    children="Flex",
                    id={
                        "type": "home-popover-dropdown-aliens-flex",
                        "cfin": cfin,
                    },
                ),
            ]

            return [content[0]] + [
                dbc.Row(dbc.Col(html.Hr(className="my-2"))),
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dbc.Row(
                                    dbc.Col(
                                        html.H6(
                                            "Update Product Status",
                                            style={"color": "rgba(0,0,0,0.87)"},
                                        )
                                    )
                                ),
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            dbc.Button(
                                                "Inactive" if cfin_alive else "active",
                                                id={
                                                    "type": "home-button-status-inactive",
                                                    "cfin": cfin,
                                                },
                                                size="sm",
                                                n_clicks=0,
                                                color="secondary",
                                            )
                                        ),
                                        dbc.Col(
                                            dbc.Button(
                                                "Autocalled",
                                                id={
                                                    "type": "home-button-status-autocall",
                                                    "cfin": cfin,
                                                },
                                                size="sm",
                                                n_clicks=0,
                                                color="secondary",
                                                style={
                                                    "display": ""
                                                    if cfin_alive
                                                    else "none"
                                                },
                                            ),
                                            width="auto",
                                        ),
                                    ],
                                    className="mt-2 mb-2",
                                    justify="between",
                                ),
                            ],
                        ),
                    ],
                    className="p-2",
                ),
                dbc.Row(dbc.Col(html.Hr(className="my-2"))),
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            html.H6(
                                                "Update Aliens",
                                                style={"color": "rgba(0,0,0,0.87)"},
                                                className="mt-1",
                                            ),
                                            width="auto",
                                            align="center",
                                        ),
                                        dbc.Col(
                                            dbc.DropdownMenu(
                                                id={
                                                    "type": "home-popover-dropdown-aliens",
                                                    "cfin": cfin,
                                                },
                                                label="OTC",
                                                size="sm",
                                                children=drop_items,
                                            ),
                                            width="auto",
                                        ),
                                    ],
                                    className="my-2",
                                    justify="between",
                                ),
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            dbc.Input(
                                                value=str(cfin_otc),
                                                placeholder="Cfin OTC",
                                                id={
                                                    "type": "home-input-add-alien",
                                                    "cfin": cfin,
                                                },
                                                size="sm",
                                            ),
                                        ),
                                        dbc.Col(
                                            dbc.Button(
                                                "Update Link 53"
                                                if cfin_otc
                                                else "Add Link 53",
                                                id={
                                                    "type": "home-button-add-alien",
                                                    "cfin": cfin,
                                                },
                                                size="sm",
                                                n_clicks=0,
                                                color="secondary",
                                            ),
                                            width="auto",
                                        ),
                                    ],
                                    className="my-2 mt-3",
                                    justify="between",
                                ),
                                dbc.Row(
                                    dbc.Col(
                                        dbc.Button(
                                            "Add Link 53",
                                            id={
                                                "type": "home-button-add-alien-bis",
                                                "cfin": cfin,
                                            },
                                            size="sm",
                                            n_clicks=0,
                                            color="secondary",
                                        ),
                                        width="auto",
                                        style={"display": "inline"}
                                        if cfin_otc
                                        else {"display": "none"},
                                    ),
                                    justify="end",
                                ),
                                dbc.Row(
                                    dbc.Col(
                                        html.P(
                                            id={
                                                "type": "home-feedback-add-alien",
                                                "cfin": cfin,
                                            },
                                        )
                                    )
                                ),
                            ],
                        ),
                    ],
                    className="pb-2 pr-2 pl-2",
                ),
            ]

    raise PreventUpdate


@app.callback(
    Output({"type": "home-popover-dropdown-aliens", "cfin": MATCH}, "label"),
    Output({"type": "home-button-add-alien", "cfin": MATCH}, "children"),
    Output({"type": "home-input-add-alien", "cfin": MATCH}, "placeholder"),
    Output({"type": "home-input-add-alien", "cfin": MATCH}, "value"),
    Output({"type": "home-button-add-alien-bis", "cfin": MATCH}, "children"),
    Output({"type": "home-button-add-alien-bis", "cfin": MATCH}, "style"),
    Input(
        {
            "type": "home-popover-dropdown-aliens-otc",
            "cfin": MATCH,
        },
        "n_clicks",
    ),
    Input(
        {
            "type": "home-popover-dropdown-aliens-flex",
            "cfin": MATCH,
        },
        "n_clicks",
    ),
    State(
        {
            "type": "home-feedback-add-alien",
            "cfin": MATCH,
        },
        "children",
    ),
    prevent_initial_call=True,
)
def change_alien_update_labels(click_otc, click_flex, data):
    ctx = callback_context
    trigger = json.loads(ctx.triggered[0]["prop_id"].split(".")[0]).get("type")
    cfin = json.loads(ctx.triggered[0]["prop_id"].split(".")[0]).get("cfin")

    # Get product's data
    cfin_otc = sql.alien(cfin).get(53)
    cfin_flex = sql.alien(cfin).get(56)

    if trigger == "home-popover-dropdown-aliens-otc":
        if cfin_otc:
            button_text = "Update Link 53"
            button_text_bis = "Add Link 53"
            style_button_bis = {"display": "inline"}
        else:
            button_text = "Add Link 53"
            button_text_bis = ""
            style_button_bis = {"display": "none"}
        return (
            "OTC",
            button_text,
            "Cfin OTC",
            cfin_otc,
            button_text_bis,
            style_button_bis,
        )
    elif trigger == "home-popover-dropdown-aliens-flex":
        if cfin_flex:
            button_text = "Update Link 56"
        else:
            button_text = "Add Link 56"
        return "Flex", button_text, "Cfin Flex", str(cfin_flex), "", {"display": "none"}
    raise PreventUpdate


@app.callback(
    Output({"type": "home-feedback-add-alien", "cfin": MATCH}, "children"),
    Output({"type": "home-feedback-add-alien", "cfin": MATCH}, "style"),
    Input({"type": "home-button-add-alien", "cfin": MATCH}, "n_clicks"),
    Input({"type": "home-button-add-alien-bis", "cfin": MATCH}, "n_clicks"),
    State({"type": "home-button-add-alien", "cfin": MATCH}, "children"),
    State({"type": "home-button-add-alien-bis", "cfin": MATCH}, "children"),
    State({"type": "home-input-add-alien", "cfin": MATCH}, "value"),
    prevent_initial_call=True,
)
def trigger_update_alien_bdd(
    n_click, n_click_bis, text_button, text_button_bis, cfin_secondary
):
    ctx = callback_context
    cfin = json.loads(ctx.triggered[0]["prop_id"].split(".")[0]).get("cfin")
    if (
        json.loads(ctx.triggered[0]["prop_id"].split(".")[0]).get("type")
        == "home-button-add-alien"
    ):
        add_or_update = str(text_button.split(" ")[0])
        link_nb = int(text_button.split(" ")[2])
    else:
        add_or_update = str(text_button_bis.split(" ")[0])
        link_nb = int(text_button_bis.split(" ")[2])
    return update_alien_bdd(add_or_update, link_nb, cfin, cfin_secondary)


@app.callback(
    Output({"type": "home-copy-to-clipboard-store", "index": MATCH}, "data"),
    Input(
        {
            "type": "home-copy-to-clipboard-lottie",
            "index": MATCH,
        },
        "n_clicks",
    ),
    prevent_initial_call=True,
)
def home_copy_to_clipboard(n_clicks):
    if n_clicks > 0:
        ctx = callback_context
        triggered = ctx.triggered[0]["prop_id"].split(".")[0]

        cfin = json.loads(triggered).get("index")

        df = pd.DataFrame(cached_data_missing_contrib())

        # Filter on messages that are late only
        df = df[df.days_late >= 0]

        if not df.empty:

            if cfin in list(df.cfin):

                # Classify products be two first letters of the RIC
                df["beginning_ric"] = df.ric.apply(lambda x: x.split("=")[1][:2])

                beginning_ric = str(list(df[df.cfin == cfin].beginning_ric)[0])

                df = df[df.beginning_ric == beginning_ric]

                df.reset_index(inplace=True)

                nb_price_missing = len(list(df.ric))
                ric_codes = ", ".join(list(df.ric))

                lines = [
                    f"🚨 Reuters Contrib Missing | {ric_codes}\n\n"
                    f"Hello Team, we are missing {nb_price_missing} Reuters price "
                    f"{'contribution' if nb_price_missing < 2 else 'contributions'}, "
                    f"could you please have a look ?\n\n"
                ]

                for k, x in df.iterrows():
                    msg = f"{k + 1} - {x['ric']} | VD: {x['payment_date']}"
                    if x["days_late"] > 0:
                        msg += f" ({x['days_late']} bdays ago)\n"
                    lines.append(msg)

                return "".join(lines)

    raise PreventUpdate


# Copy From Store To Clipboard
app.clientside_callback(
    """
    function(formula, click) {
        if (click > 0) {
            var dummy = document.createElement("textarea");
            document.body.appendChild(dummy);
            dummy.value = formula;
            dummy.select();
            document.execCommand("copy");
            document.body.removeChild(dummy);
        }
        return 0;
    }
    """,
    Output({"type": "home-copy-to-clipboard-lottie", "index": MATCH}, "n_clicks"),
    Input({"type": "home-copy-to-clipboard-store", "index": MATCH}, "data"),
    State({"type": "home-copy-to-clipboard-lottie", "index": MATCH}, "n_clicks"),
    prevent_initial_call=True,
)

from dash import dcc
import dash.dash_table.Format as Format
import pandas as pd
from dash.dependencies import Input, Output, State, ClientsideFunction
from dash.exceptions import PreventUpdate
from dash_extensions.snippets import send_data_frame
import dash_extensions as de

from models.menus_and_elements import title_and_search
from models.storing import (
    cached_ytd_trades,
    primary_trades,
    secondary_sales,
    losing_trades,
)
from utils.basics import *
from utils.components import *
from utils.osiris import *


def serve_layout(search=None):

    title = dcc.Location(
        id={"type": "url", "page": "trades"}, search=search, refresh=False
    )

    column_with_filters = dbc.Col(
        [
            dbc.Row([dbc.Col(card_title("Filters"))]),
            dbc.Row(
                dbc.Col(
                    [
                        card_subtitle("PRODUCTS"),
                        dbc.Checklist(
                            options=[
                                {
                                    "label": "External Only",
                                    "value": 1,
                                },
                                {
                                    "label": "Italian Listed Only",
                                    "value": 2,
                                },
                            ],
                            value=[],
                            id="trades-checklist",
                            switch=True,
                            class_name="pl-3",
                        ),
                        card_subtitle("DATES"),
                        dcc.DatePickerRange(
                            id="trades-datepicker",
                            display_format="MMM Do, YY",
                            min_date_allowed=dt(2021, 1, 1),
                            max_date_allowed=dt_today(),
                            start_date_placeholder_text="Start Period",
                            end_date_placeholder_text="End Period",
                            start_date=prev_bday(5),
                            end_date=dt_today(),
                            # with_portal=True,
                            style={"fontSize": "0.75rem"},
                        ),
                    ],
                )
            ),
        ],
        width=2,
        className="px-4",
    )

    column_with_data = dbc.Col(
        [
            # Row With Title & Download Button
            dbc.Row(
                [
                    dbc.Col(card_title("Trades"), width=11),
                    dbc.Col(
                        html.Div(
                            [
                                html.A(
                                    html.I(
                                        className="fas fa-download dark-grey",
                                        style={"fontSize": "1rem"},
                                    ),
                                    target="_blank",
                                ),
                            ],
                            n_clicks=0,
                            id="trades-button-download",
                            style={"text-align": "center"},
                        ),
                        width=1,
                        align="center",
                    ),
                    dbc.Tooltip(
                        children="Download Trades",
                        target="trades-button-download",
                        # autohide=False,
                        delay={"show": 250, "hide": 250},
                        placement="bottom",
                        class_name="p-2",
                    ),
                    de.Download(id="trades-download"),
                ]
            ),
            dbc.Row(
                dbc.Col(
                    [card_title("Primary"), trades_table("table-primary")],
                ),
                className="borded-card p-4 m-2",
            ),
            dbc.Row(
                dbc.Col(
                    [
                        card_title("Secondary"),
                        trades_table("table-secondary"),
                    ],
                ),
                className="borded-card p-4 mx-2 my-3",
            ),
            dbc.Row(
                dbc.Col(
                    [card_title("Losing"), trades_table("table-losing")],
                ),
                className="borded-card p-4 m-2",
            ),
            html.Div(id="trades-hidden-primary"),
            html.Div(id="trades-hidden-secondary"),
            html.Div(id="trades-hidden-losing"),
        ],
        width=10,
    )

    body = dbc.Container(
        dbc.Row([column_with_filters, column_with_data]),
        fluid=True,
        className="mt-3",
    )

    return [title, body]


@app.callback(
    [
        Output("table-primary", "columns"),
        Output("table-secondary", "columns"),
        Output("table-losing", "columns"),
    ],
    [Input({"type": "url", "page": "trades"}, "pathname")],
    [
        State("table-primary", "columns"),
    ],
)
def create_options_and_columns(href, columns):
    if columns:
        raise PreventUpdate

    ### Formating tables ###
    columns_name = [
        "L",
        "TS",
        "Cfin",
        "ISIN",
        "Initial Date",
        "Maturity",
        "Issuer",
        "Name",
        "Sales",
        "Type",
        "Nb Trd",
        "Ccy",
        "Margin",
        "Cash Traded",
        "Size Traded",
    ]
    columns = [{"name": i, "id": i} for i in columns_name]
    d = {
        "Margin": {
            "type": "numeric",
            "format": Format.Format(group=",", scheme=Format.Scheme.fixed, precision=0),
        },
        "Cash Traded": {
            "type": "numeric",
            "format": Format.Format(group=",", scheme=Format.Scheme.fixed, precision=0),
        },
        "Size Traded": {
            "type": "numeric",
            "format": Format.Format(group=",", scheme=Format.Scheme.fixed, precision=0),
        },
    }
    columns = [{**c, **d.get(c["name"], {})} for c in columns]

    return [columns, columns, columns]


@app.callback(
    [
        Output("table-primary", "data"),
        Output("table-secondary", "data"),
        Output("table-losing", "data"),
    ],
    [
        Input({"type": "url", "page": "trades"}, "pathname"),
        Input("trades-datepicker", "start_date"),
        Input("trades-datepicker", "end_date"),
        Input("trades-checklist", "value"),
    ],
)
def update_trades_in_datatable(url, start_date, end_date, value):
    if not start_date:
        raise PreventUpdate

    # Retrieve Trades from cache file
    df = cached_ytd_trades()

    # FILTER ON DATES FROM DATEPICKER

    # Convert everything to Datetime
    start_date = pd.to_datetime(start_date)
    end_date = pd.to_datetime(end_date)

    dff = df[
        (pd.to_datetime(df.trade_date) >= start_date)
        & (pd.to_datetime(df.trade_date) <= end_date)
    ]

    # FILTER ON PRODUCTS

    # User selected External Only
    if 1 in value:
        try:
            issuer_exane_names = [
                "Exane",
                "Exane Lux",
                "Exane Pledged",
                "Exane Lux Pledged",
            ]
            dff = dff[~dff.issuer.isin(issuer_exane_names)]
        except Exception as e:
            print(str(e))

    # User selected Italian Listed Only
    if 2 in value:
        try:
            italian_accounts = "|".join(["EUROTLX Team", "SEDEX Team"])
            dff.sales = dff.sales.fillna("-")
            df_listed = dff[dff.sales.str.contains(italian_accounts)]
            dff = dff[dff.cfin.isin(df_listed.cfin.unique())]
        except Exception as e:
            print(str(e))

    data_primary = primary_trades(dff)
    data_secondary = secondary_sales(dff)
    data_losing = losing_trades(dff)

    return [data_primary, data_secondary, data_losing]


@app.callback(
    Output("trades-download", "data"),
    Input("trades-button-download", "n_clicks"),
    State("table-primary", "data"),
    State("table-secondary", "data"),
    State("table-losing", "data"),
    State("trades-datepicker", "start_date"),
    State("trades-datepicker", "end_date"),
)
def download_trades(
    n_clicks, data_primary, data_secondary, data_losing, start_date, end_date
):

    if n_clicks:

        df_primary = pd.DataFrame(data_primary)
        df_primary["Type"] = "Primary"
        df_secondary = pd.DataFrame(data_secondary)
        df_secondary["Type"] = "Secondary"
        df_losing = pd.DataFrame(data_losing)
        df_losing["Type"] = "Losing"

        frames = [df_primary, df_secondary, df_losing]
        df = pd.concat(frames)

        if not df.empty:
            filename = f"trades_{start_date}_{end_date}.xlsx"
            return send_data_frame(df.to_excel, filename)

    raise PreventUpdate


app.clientside_callback(
    ClientsideFunction("ui", "replaceWithLinks_table_trades_primary"),
    Output("trades-hidden-primary", "children"),
    [Input("table-primary", "derived_viewport_data")],
)

app.clientside_callback(
    ClientsideFunction("ui", "replaceWithLinks_table_trades_secondary"),
    Output("trades-hidden-secondary", "children"),
    [Input("table-secondary", "derived_viewport_data")],
)

app.clientside_callback(
    ClientsideFunction("ui", "replaceWithLinks_table_trades_losing"),
    Output("trades-hidden-losing", "children"),
    [Input("table-losing", "derived_viewport_data")],
)

import dash_bootstrap_components as dbc
from dash import dcc
from dash import html
import dash_extensions as de
import dash
from dash.dependencies import ClientsideFunction, Input, Output, State
from dash.dash_table import FormatTemplate
from dash.dash_table.Format import Format, Group, Scheme
from dash_extensions.snippets import send_data_frame
from dash.exceptions import PreventUpdate

import plotly.express as px
import plotly.graph_objs as go
from plotly.subplots import make_subplots

from app import app, cache
from utils.basics import *
from models.storing import (
    cached_trades_and_products,
)
from datetime import datetime as dt
from operator import itemgetter
from utils.components import (
    products_products_table,
    products_trades_table,
    card_title,
)

import pandas as pd

config_graph = {
    "displaylogo": False,
    "displayModeBar": False,
}

style_filter_headers = {
    "fontFamily": "Roboto-Bold",
    "textAlign": "left",
    "fontSize": "1.2rem",
    "lineHeight": "2rem",
    "color": "rgba(0, 0, 0, 0.54)",
    "marginBottom": "0.35rem",
}


@cache.memoize(timeout=300)
def retrieve_cache_filtered_data(
    start_date, end_date, select_trade, select_format, select_market, dropdown
):
    # Retrieve Dataframes From Cache
    df = cached_trades_and_products()

    # Filter Dates
    start_date = pd.to_datetime(start_date, format="%Y-%m-%dT%H:%M:%S", errors="coerce")
    end_date = pd.to_datetime(end_date, format="%Y-%m-%dT%H:%M:%S", errors="coerce")
    df = df[(df["Trade Date"] >= start_date) | (df["Issue Date"] >= start_date)]
    df = df[(df["Trade Date"] <= end_date) | (df["Issue Date"] <= end_date)]

    # Filter Trade Type
    if select_trade == "exane_paper":
        df = df[(df["Issuer"] == "Exane") & (df["Issuer OTC"].isnull())]
        trade_filter_text = "Paper: Exane"
    elif select_trade == "external_paper":
        df = df[(df["Issuer"] != "Exane") | (df["Issuer OTC"].notnull())]
        trade_filter_text = "Paper: External"
    else:
        trade_filter_text = "Paper: All"

    # Filter Product Format
    if select_format == "otc":
        df = df[df["Issuer OTC"].notnull()]
        format_filter_text = "Format: OTC"
    elif select_format == "note":
        df = df[df["Issuer OTC"].isnull()]
        format_filter_text = "Format: Note"
    else:
        format_filter_text = "Format: All"

    # Filter Market Type
    if select_market == "primary":
        df = df[(df["Primary"] == True)]
        market_filter_text = "Market: Primary"
    elif select_market == "secondary":
        df = df[(df["Primary"] == False)]
        market_filter_text = "Market: Secondary"
    else:
        market_filter_text = "Market: All"

    # Set Products Dropdown Values
    dropdown_options = [{"label": x, "value": x} for x in df["Issuer"].unique()] + [
        {"label": str(x), "value": str(x)} for x in df["Issuer OTC"].unique()
    ]
    dropdown_options = sorted(
        list({v["value"]: v for v in dropdown_options}.values()),
        key=itemgetter("value"),
    )
    dropdown_options = dropdown_options[:-1]

    # Filter Issuers
    if len(dropdown) >= 1:
        df = df[
            ((df["Issuer"].isin(dropdown)) & (df["Issuer OTC"].isnull()))
            | ((df["Issuer OTC"].isin(dropdown)) & (df["Issuer OTC"].notnull()))
        ]
        issuer_filter_text = "Issuer: " + f"{' - '.join(dropdown)}"
    else:
        issuer_filter_text = "Issuer: All"

    # Product Issued And Traded During Selected TimeFrame
    df.loc[
        (df["Trade Date"] >= start_date) & (df["Trade Date"] <= end_date),
        "Traded?",
    ] = 1
    df.loc[
        (df["Issue Date"] >= start_date) & (df["Issue Date"] <= end_date),
        "Issued?",
    ] = 1

    # Compute Filter Text
    filter_text = html.P(
        f"From {start_date.strftime('%d/%m/%Y')} To {end_date.strftime('%d/%m/%Y')} / {trade_filter_text} / {format_filter_text} / {market_filter_text} / {issuer_filter_text}"
    )

    # Split Dataframe Into Trades Dataframe (fact table) & Products Dataframe (dimension table)
    df_trades, df_products = split_dataframe(df)

    return (df_trades, df_products, dropdown_options, filter_text)


def split_dataframe(df):
    # Split
    df_trades = df[
        [
            "Cfin",
            "Trade Date",
            "Nb Trd",
            "Trade Side",
            "Sales",
            "Trade Margin",
            "Win Margin",
            "Loss Margin",
            "Size Traded",
            "Traded?",
        ]
    ]
    df_products = df[
        [
            "Status",
            "Cfin",
            "ISIN",
            "Issuer",
            "Issuer OTC",
            "Name",
            "Issue Date",
            "Maturity Date",
            "Market",
            "Ccy",
            "Nominal",
            "Sales",
            "Last",
            "Bid",
            "Bid Margin",
            "Perf. 3M",
            "Ask",
            "Issuer Type",
            "Product Margin",
            "Issued?",
            "Size Traded",
        ]
    ]

    # Reset Indexes
    df_trades = df_trades.reset_index(drop=True)
    df_products.drop_duplicates(keep="first", inplace=True)
    df_products = df_products.reset_index(drop=True)
    return df_trades, df_products


def format_trades_table(df_trades, df_products):
    # Merge Wanted Columns
    df_trades = df_trades[df_trades["Traded?"] == 1]
    df_products = df_products.drop_duplicates(keep="first")
    df = pd.merge(
        df_trades,
        df_products,
        on=["Cfin", "Cfin"],
        how="left",
    )

    # Reorder Wanted Columns
    df = df[
        [
            "Status",
            "Cfin",
            "ISIN",
            "Name",
            "Issuer",
            "Trade Date",
            "Maturity Date",
            "Sales",
            "Nb Trd",
            "Trade Side",
            "Ccy",
            "Trade Margin",
            "Size Traded",
        ]
    ]

    # Rename Columns
    df = df.rename(
        columns={
            "Trade Date": "Trade",
            "Maturity Date": "Maturity",
            "Trade Margin": "Margin (€)",
            "Trade Side": "Type",
        }
    )

    # Convert dates to strings
    for c in ["Trade", "Maturity"]:
        df[c] = df[c].apply(
            lambda x: x if x == "" else to_str_date(pd.to_datetime(x), "%Y-%m-%d")
        )

    # Add Columns For Link & TS
    df.insert(loc=1, column="TS", value="")
    df.insert(loc=0, column="L", value="")

    # Format Output to Datatable
    trades_data = df.to_dict(orient="records")
    trades_columns = [{"name": i, "id": i} for i in df.columns[:-2]] + [
        {
            "id": "Margin (€)",
            "name": "Margin (€)",
            "type": "numeric",
            "format": Format(
                scheme=Scheme.fixed,
                precision=0,
                group=Group.yes,
            ),
        },
        {
            "id": "Size Traded",
            "name": "Size Traded",
            "type": "numeric",
            "format": Format(
                scheme=Scheme.fixed,
                precision=0,
                group=Group.yes,
            ),
        },
    ]

    return trades_data, trades_columns


def format_products_table(df_products):
    # Reorder Wanted Columns
    df = df_products[
        [
            "Status",
            "Cfin",
            "ISIN",
            "Name",
            "Issuer",
            "Issuer OTC",
            "Ccy",
            "Issue Date",
            "Maturity Date",
            "Sales",
            "Perf. 3M",
            "Ask",
            "Bid",
            "Bid Margin",
            "Size Traded",
        ]
    ]

    # Group By Products
    keys = [
        "Status",
        "Cfin",
        "ISIN",
        "Name",
        "Issuer",
        "Issuer OTC",
        "Ccy",
        "Issue Date",
        "Maturity Date",
        "Perf. 3M",
        "Bid",
        "Bid Margin",
    ]
    df = (
        df.groupby(keys, dropna=False)
        .agg(
            size_traded=("Size Traded", "sum"), Sales=("Sales", lambda x: list(set(x)))
        )
        .reset_index()
    )

    # Reformat Market & Size Traded Columns
    df["size_traded"] = df["size_traded"].abs()

    # Add Columns For Link & TS
    df.insert(loc=1, column="TS", value="")
    df.insert(loc=0, column="L", value="")

    # Rename Columns
    df = df.rename(
        columns={
            "Issue Date": "Issue",
            "Maturity Date": "Maturity",
            "size_traded": "Position",
        }
    )

    # Reorder Dataframe
    df = df.sort_values(by="Issue", ascending=False)

    # Convert dates to strings
    for c in ["Issue", "Maturity"]:
        df[c] = df[c].apply(
            lambda x: x if x == "" else to_str_date(pd.to_datetime(x), "%Y-%m-%d")
        )

    # Format Output to Datatable
    products_data = df.to_dict(orient="records")
    products_columns = [{"name": i, "id": i} for i in df.columns[:-5]] + [
        {
            "id": "Perf. 3M",
            "name": "Perf. 3M",
            "type": "numeric",
            "format": FormatTemplate.percentage(2),
        },
        {
            "id": "Bid",
            "name": "Bid",
            "type": "numeric",
            "format": Format(
                scheme=Scheme.fixed,
                precision=2,
                group=Group.yes,
            ),
        },
        {
            "id": "Bid Margin",
            "name": "Bid Margin",
            "type": "numeric",
            "format": Format(
                scheme=Scheme.fixed,
                precision=2,
                group=Group.yes,
            ),
        },
        {
            "id": "Position",
            "name": "Position",
            "type": "numeric",
            "format": Format(
                scheme=Scheme.fixed,
                precision=0,
                group=Group.yes,
            ),
        },
        {
            "id": "Sales",
            "name": "Sales",
        },
    ]
    return products_data, products_columns


def create_pie_chart(df_trades, df_products, dropdown):
    # Set Pie Chart DataFrames
    if dropdown in ["product_count"]:
        df = df_products.drop_duplicates(keep="first")
    elif dropdown in ["issued_product_count"]:
        df = df_products[df_products["Issued?"] == 1].drop_duplicates(keep="first")
    else:
        df_trades = df_trades[df_trades["Traded?"] == 1]
        df_products = df_products.drop_duplicates(keep="first")
        df = pd.merge(
            df_trades,
            df_products,
            on=["Cfin", "Cfin"],
            how="left",
        )

    # Add Count Column
    df["Count"] = 1

    # Set Pie Chart Values & Title
    if dropdown == "trade_margin":
        values = "Trade Margin"
        title = "Issuers Repartition by P&L"
    elif dropdown == "trade_count":
        values = "Count"
        title = "Issuers Repartition by Trade Count"
    elif dropdown == "product_count":
        values = "Count"
        title = "Issuers Repartition by Product Count"
    else:
        values = "Count"
        title = "Issuers Repartition by Issued Product Count"

    # Set Pie Chart Figure
    fig = px.pie(
        data_frame=df,
        values=values,
        title=title,
        names="Issuer Type",
        color="Issuer Type",
        color_discrete_map={
            "Exane": "rgba(96, 166, 220, 1)",  # Blue
            "External": "rgba(225, 192, 245, 1)",  # Magenta
            "Back to Back": "rgba(247, 170, 182, 1)",  # Red
        },
    )
    return fig


def create_bar_chart(df_trades, dropdown):
    # Only Keep The Traded Data
    df_trades = df_trades[df_trades["Traded?"] == 1]

    # Add Count Sell & Buy Columns
    df_trades.loc[df_trades["Trade Side"] == "Buy", "Count Buy"] = 1
    df_trades.loc[df_trades["Trade Side"] == "Sell", "Count Sell"] = 1

    # Hide Horizontal Axis By Default
    xaxis_visible = False

    # Group By Selected Time Interval
    df_trades["Trade Date"] = pd.to_datetime(df_trades["Trade Date"])
    if dropdown == "daily":
        df = df_trades.resample("D", on="Trade Date")[
            "Trade Margin", "Count Buy", "Count Sell"
        ].sum()
        df = df.reset_index(drop=False)
        df = df[df["Trade Margin"] != 0]
        df["Trade Date"] = df["Trade Date"].dt.strftime("%d/%m/%Y")
    elif dropdown == "weekly":
        df = df_trades.resample("W", on="Trade Date")[
            "Trade Margin", "Count Buy", "Count Sell"
        ].sum()
        df = df.reset_index(drop=False)
        # Reformat Trade Date Column
        df["Trade Date"] = df["Trade Date"].apply(
            lambda x: f'{x.strftime(format="%d/%m/%Y")} - {(x + timedelta(days=6)).strftime("%d/%m/%Y")}'
        )
    elif dropdown == "monthly":
        xaxis_visible = True
        df = df_trades.resample("M", on="Trade Date")[
            "Trade Margin", "Count Buy", "Count Sell"
        ].sum()
        df = df.reset_index(drop=False)
        # Reformat Trade Date Column
        df["Trade Date"] = df["Trade Date"].apply(
            lambda x: f'{x.strftime(format="%b - %Y")}'
        )
    else:
        xaxis_visible = True
        df = df_trades.resample("Q", on="Trade Date")[
            "Trade Margin", "Count Buy", "Count Sell"
        ].sum()
        df = df.reset_index(drop=False)

        # Reformat Trade Date Column
        def function(x):
            return (
                f"Q1" + " - " + x.strftime(format="%Y")
                if x.strftime(format="%m") == "03"
                else (
                    f"Q2"
                    if x.strftime(format="%m") == "06"
                    else (f"Q3" if x.strftime(format="%m") == "06" else f"Q4")
                    + f'- {x.strftime(format="%Y")}'
                )
                + " - "
                + x.strftime(format="%Y")
            )

        df["Trade Date"] = df["Trade Date"].apply(function)

    # Create Figure
    fig = make_subplots(specs=[[{"secondary_y": True}]])

    # Add Buy Trades Count Series (Bar)
    fig.add_trace(
        go.Bar(
            x=df["Trade Date"].values,
            y=df["Count Buy"].values,
            name="Buy Trades",
            marker={"color": "rgba(47, 154, 152, 0.61)"},
        ),
        secondary_y=False,
    )

    # Add Sell Trades Count Series (Bar)
    fig.add_trace(
        go.Bar(
            x=df["Trade Date"].values,
            y=df["Count Sell"].values,
            name="Sell Trades",
            marker={"color": "rgba(255, 214, 153, 0.61)"},
        ),
        secondary_y=False,
    )

    # Add Margin Series (Lines)
    fig.add_trace(
        go.Scatter(
            x=df["Trade Date"].values,
            y=df["Trade Margin"].values,
            mode="lines",
            name="Margins",
            marker={"color": "red"},
        ),
        secondary_y=True,
    )

    # Set Figure Layout
    fig.update_layout(
        title=dict(
            text=f"{capitalize_name(dropdown)} Trades & P&L Evolution",
        ),
        legend=dict(
            orientation="h",
            y=-0.15,
        ),
        xaxis=dict(
            showgrid=False,
            visible=xaxis_visible,
        ),
        yaxis=dict(
            rangemode="tozero",
            title="<b>Trades</b>",
            showgrid=True,
        ),
        yaxis2=dict(
            rangemode="tozero",
            title="<b>P&L</b>",
            showgrid=False,
        ),
        hovermode="x",  # change to "closest" to only show value for a single serie
        template="plotly_white",
    )

    return fig


def serve_layout(search=None):
    location = dcc.Location(
        id={"type": "url", "page": "products"}, search=search, refresh=False
    )

    body = dbc.Container(
        [
            # Row of Filters
            dbc.Row(
                [
                    dbc.Col(card_title("Filters"), width=0.5, className="ml-3"),
                    dbc.Col(
                        html.Div(
                            [
                                de.Lottie(
                                    options=dict(
                                        loop=False,
                                        autoplay=False,
                                        rendererSettings=dict(
                                            preserveAspectRatio="xMidYMid slice"
                                        ),
                                    ),
                                    width="65%",
                                    height="65%",
                                    id="products-filters-lottie-eye",
                                    url="/lottie/script-eye.json",
                                )
                            ],
                            style={
                                "maxHeight": "38px",
                                "maxWidth": "38px",
                                "text-align": "center",
                                "vertical-align": "middle",
                            },
                            n_clicks=0,
                            id="products-button-filter-eye",
                            className="mt-1",
                        ),
                        width=11,
                    ),
                    dbc.Col(
                        dbc.Collapse(is_open=True, id="products-collapse-info"),
                        width=12,
                    ),
                    dbc.Col(
                        dbc.Collapse(
                            [
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            html.P(
                                                "Dates",
                                                style=style_filter_headers,
                                            ),
                                            width=3,
                                        ),
                                        dbc.Col(
                                            html.P(
                                                "Products & Trades",
                                                style=style_filter_headers,
                                            ),
                                        ),
                                        dbc.Col(
                                            html.P(
                                                "Issuers",
                                                style=style_filter_headers,
                                            ),
                                            width=3,
                                        ),
                                    ],
                                    justify="between",
                                ),
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            dcc.DatePickerRange(
                                                id="products-datepicker",
                                                display_format="MMM Do, YY",
                                                min_date_allowed=dt(2010, 1, 1),
                                                max_date_allowed=dt_today(),
                                                start_date_placeholder_text="Start Period",
                                                end_date_placeholder_text="End Period",
                                                start_date=dt(2021, 1, 1),
                                                end_date=dt_today(),
                                                style={"fontSize": "0.75rem"},
                                            ),
                                            width=3,
                                        ),
                                        dbc.Col(
                                            [
                                                dbc.Row(
                                                    [
                                                        dbc.Col(
                                                            dbc.Select(
                                                                id="products-select-paper",
                                                                options=[
                                                                    {
                                                                        "label": "Exane & External Paper",
                                                                        "value": "all",
                                                                    },
                                                                    {
                                                                        "label": "Exane Paper Only",
                                                                        "value": "exane_paper",
                                                                    },
                                                                    {
                                                                        "label": "External Paper Only",
                                                                        "value": "external_paper",
                                                                    },
                                                                ],
                                                                value="all",
                                                            ),
                                                            width=3,
                                                        ),
                                                        dbc.Col(
                                                            dbc.Select(
                                                                id="products-select-format",
                                                                options=[
                                                                    {
                                                                        "label": "Note & OTC",
                                                                        "value": "all",
                                                                    },
                                                                    {
                                                                        "label": "Note Only",
                                                                        "value": "note",
                                                                    },
                                                                    {
                                                                        "label": "OTC Only",
                                                                        "value": "otc",
                                                                    },
                                                                ],
                                                                value="all",
                                                            ),
                                                            width=3,
                                                        ),
                                                        dbc.Col(
                                                            dbc.Select(
                                                                id="products-select-market",
                                                                options=[
                                                                    {
                                                                        "label": "Primary & Secondary",
                                                                        "value": "all",
                                                                    },
                                                                    {
                                                                        "label": "Primary Only",
                                                                        "value": "primary",
                                                                    },
                                                                    {
                                                                        "label": "Secondary Only",
                                                                        "value": "secondary",
                                                                    },
                                                                ],
                                                                value="all",
                                                            ),
                                                            width=3,
                                                        ),
                                                    ],
                                                ),
                                            ],
                                        ),
                                        dbc.Col(
                                            dcc.Dropdown(
                                                id="products-dropdown",
                                                options=[],
                                                multi=True,
                                                value=[],
                                            ),
                                            width=3,
                                        ),
                                        dbc.Tooltip(
                                            children="Hide/Show Filters",
                                            target="products-button-filter-eye",
                                            # autohide=False,
                                            delay={"show": 250, "hide": 250},
                                            placement="bottom",
                                            class_name="p-2",
                                        ),
                                    ],
                                    justify="between",
                                    className="mb-2",
                                ),
                            ],
                            id="products-collapse",
                            is_open=False,
                        ),
                        width=12,
                    ),
                ],
                className="m-3",
            ),
            # Row of Key Figures
            dbc.Row(
                [
                    dbc.Col(
                        dbc.Card(
                            [
                                dbc.CardHeader("P&L"),
                                dbc.CardBody(id="products-pnl-card"),
                            ],
                            style={"height": "170px"},
                            color="Secondary",
                            outline=True,
                        ),
                        width=2,
                    ),
                    dbc.Col(
                        dbc.Card(
                            [
                                dbc.CardHeader("Number of Products Issued"),
                                dbc.CardBody(id="products-issued-products-card"),
                            ],
                            style={"height": "170px"},
                            color="Secondary",
                            outline=True,
                        ),
                        width=2,
                    ),
                    dbc.Col(
                        dbc.Card(
                            [
                                dbc.CardHeader("Number of Issuers"),
                                dbc.CardBody(id="products-issuers-card"),
                            ],
                            style={"height": "170px"},
                            color="Secondary",
                            outline=True,
                        ),
                        width=2,
                    ),
                    dbc.Col(
                        dbc.Card(
                            [
                                dbc.CardHeader("Number of Trades"),
                                dbc.CardBody(id="products-trades-card"),
                            ],
                            style={"height": "170px"},
                            color="Secondary",
                            outline=True,
                        ),
                        width=2,
                    ),
                    dbc.Col(
                        dbc.Card(
                            [
                                dbc.CardHeader("Listed Products Proportion"),
                                dbc.CardBody(id="products-listed-proportion-card"),
                            ],
                            style={"height": "170px"},
                            color="Secondary",
                            outline=True,
                        ),
                        width=2,
                    ),
                ],
                justify="between",
                className="m-3 mb-4",
            ),
            # Row of Graphs
            dbc.Row(
                [
                    dbc.Col(card_title("KPI"), width=6),
                    dbc.Col(
                        dcc.Dropdown(
                            options=[
                                {"label": "Daily", "value": "daily"},
                                {"label": "Weekly", "value": "weekly"},
                                {"label": "Monthly", "value": "monthly"},
                                {"label": "Quarterly", "value": "quarterly"},
                            ],
                            id="products-bar-chart-dropdown",
                            value="monthly",
                            disabled=True,
                            clearable=False,
                        ),
                        width=2,
                        align="center",
                    ),
                    dbc.Col(width=2),
                    dbc.Col(
                        dcc.Dropdown(
                            options=[
                                {"label": "P&L", "value": "trade_margin"},
                                {"label": "Trade Count", "value": "trade_count"},
                                {"label": "Product Count", "value": "product_count"},
                                {
                                    "label": "Issued Product Count",
                                    "value": "issued_product_count",
                                },
                            ],
                            id="products-pie-chart-dropdown",
                            value="trade_margin",
                            disabled=True,
                            clearable=False,
                        ),
                        width=2,
                        align="center",
                    ),
                    # Graph Trades Values & Volumes Evolution
                    dbc.Col(
                        dbc.Spinner(
                            dcc.Graph(
                                id="products-bar-chart-graph",
                                config=config_graph,
                            ),
                            size="lg",
                            type="grow",
                            color="primary",
                        ),
                        id="products-bar-chart-graph-col",
                        width=8,
                    ),
                    # Graph Trades Repartition
                    dbc.Col(
                        dbc.Spinner(
                            dcc.Graph(
                                id="products-pie-chart-graph",
                                config=config_graph,
                            ),
                            size="lg",
                            type="grow",
                            color="primary",
                        ),
                        id="products-pie-chart-col",
                        width=4,
                    ),
                ],
                className="borded-card p-4 m-3",
            ),
            # # Row of Products Tables Card
            dbc.Row(
                dbc.Col(
                    [
                        # Row With Table Title and Lotties
                        dbc.Row(
                            [
                                dbc.Col(card_title("Products"), width=6),
                                dbc.Col(
                                    [
                                        dbc.Row(
                                            [
                                                dbc.Col(
                                                    dcc.Dropdown(
                                                        id="products-products-table-dropdown",
                                                        options=[
                                                            {
                                                                "label": "Dead & Alive",
                                                                "value": "dead_alive",
                                                            },
                                                            {
                                                                "label": "Alive Only",
                                                                "value": "alive_only",
                                                            },
                                                            {
                                                                "label": "Dead Only",
                                                                "value": "dead_only",
                                                            },
                                                        ],
                                                        value="dead_alive",
                                                        clearable=False,
                                                    ),
                                                    align="top",
                                                    width=2,
                                                ),
                                                dbc.Col(
                                                    html.Div(
                                                        [
                                                            de.Lottie(
                                                                options=dict(
                                                                    loop=False,
                                                                    autoplay=False,
                                                                    rendererSettings=dict(
                                                                        preserveAspectRatio="xMidYMid slice"
                                                                    ),
                                                                ),
                                                                width="65%",
                                                                height="65%",
                                                                id="products-products-lottie-eye",
                                                                url="/lottie/script-eye.json",
                                                            )
                                                        ],
                                                        style={
                                                            "maxHeight": "38px",
                                                            "maxWidth": "38px",
                                                            "align": "center",
                                                        },
                                                        n_clicks=0,
                                                        id="products-button-products-eye",
                                                    ),
                                                    width=1,
                                                ),
                                                dbc.Col(
                                                    html.Div(
                                                        [
                                                            html.A(
                                                                html.I(
                                                                    className="fas fa-download dark-grey",
                                                                    style={
                                                                        "fontSize": "1rem"
                                                                    },
                                                                ),
                                                                target="_blank",
                                                            ),
                                                        ],
                                                        n_clicks=0,
                                                        id="products-button-products-download",
                                                    ),
                                                    width=1,
                                                ),
                                            ],
                                            justify="end",
                                            align="center",
                                        ),
                                        dbc.Tooltip(
                                            children="Display All Products",
                                            target="products-button-products-eye",
                                            # autohide=False,
                                            delay={"show": 250, "hide": 250},
                                            placement="bottom",
                                            class_name="p-2",
                                        ),
                                        dbc.Tooltip(
                                            children="Download Products Table",
                                            target="products-button-products-download",
                                            # autohide=False,
                                            delay={"show": 250, "hide": 250},
                                            placement="bottom",
                                            class_name="p-2",
                                        ),
                                    ],
                                    width=6,
                                ),
                            ],
                        ),
                        # Row with Table
                        dbc.Row(
                            dbc.Col(
                                products_products_table(),
                                width=12,
                            ),
                        ),
                    ]
                ),
                className="borded-card p-4 m-3",
            ),
            # Row of Trades Tables Card
            dbc.Row(
                dbc.Col(
                    [
                        # Row With Table Title and Lotties
                        dbc.Row(
                            [
                                dbc.Col(card_title("Trades"), width=6),
                                dbc.Col(
                                    [
                                        dbc.Row(
                                            [
                                                dbc.Col(
                                                    dcc.Dropdown(
                                                        id="products-trades-table-dropdown",
                                                        options=[
                                                            {
                                                                "label": "Wins & Losses",
                                                                "value": "wins_losses",
                                                            },
                                                            {
                                                                "label": "Wins Only",
                                                                "value": "wins_only",
                                                            },
                                                            {
                                                                "label": "Losses Only",
                                                                "value": "losses_only",
                                                            },
                                                        ],
                                                        value="wins_losses",
                                                        clearable=False,
                                                    ),
                                                    align="top",
                                                    width=2,
                                                ),
                                                dbc.Col(
                                                    html.Div(
                                                        [
                                                            de.Lottie(
                                                                options=dict(
                                                                    loop=False,
                                                                    autoplay=False,
                                                                    rendererSettings=dict(
                                                                        preserveAspectRatio="xMidYMid slice"
                                                                    ),
                                                                ),
                                                                width="65%",
                                                                height="65%",
                                                                id="products-products-lottie-eye",
                                                                url="/lottie/script-eye.json",
                                                            )
                                                        ],
                                                        style={
                                                            "maxHeight": "38px",
                                                            "maxWidth": "38px",
                                                            "align": "center",
                                                        },
                                                        n_clicks=0,
                                                        id="products-button-trades-eye",
                                                    ),
                                                    width=1,
                                                ),
                                                dbc.Col(
                                                    html.Div(
                                                        [
                                                            html.A(
                                                                html.I(
                                                                    className="fas fa-download dark-grey",
                                                                    style={
                                                                        "fontSize": "1rem"
                                                                    },
                                                                ),
                                                                target="_blank",
                                                            ),
                                                        ],
                                                        n_clicks=0,
                                                        id="products-button-trades-download",
                                                    ),
                                                    width=1,
                                                ),
                                            ],
                                            justify="end",
                                            align="center",
                                        ),
                                        dbc.Tooltip(
                                            children="Display All Trades",
                                            target="products-button-trades-eye",
                                            # autohide=False,
                                            delay={"show": 250, "hide": 250},
                                            placement="bottom",
                                            class_name="p-2",
                                        ),
                                        dbc.Tooltip(
                                            children="Download Trades Table",
                                            target="products-button-trades-download",
                                            # autohide=False,
                                            delay={"show": 250, "hide": 250},
                                            placement="bottom",
                                            class_name="p-2",
                                        ),
                                    ],
                                    width=6,
                                ),
                            ],
                        ),
                        # Row with Table
                        dbc.Row(
                            dbc.Col(
                                products_trades_table(),
                                width=12,
                            ),
                        ),
                    ]
                ),
                className="borded-card p-4 m-3",
            ),
            de.Download(id="products-download"),
            html.Div(id="products-hidden-1-div", style={"display": "none"}),
            html.Div(id="products-hidden-2-div", style={"display": "none"}),
            html.Div(id="products-hidden-3-div", style={"display": "none"}),
        ],
        fluid=True,
        className="mt-3",
    )

    return [location, body]


@app.callback(
    Output("products-dropdown", "options"),
    Output("products-collapse-info", "children"),
    Output("products-hidden-3-div", "children"),
    Input({"type": "url", "page": "products"}, "href"),
    Input("products-datepicker", "start_date"),
    Input("products-datepicker", "end_date"),
    Input("products-select-paper", "value"),
    Input("products-select-format", "value"),
    Input("products-select-market", "value"),
    Input("products-dropdown", "value"),
)
def retrieve_filtered_data(
    href, start_date, end_date, select_trade, select_format, select_market, dropdown
):
    (
        df_trades,
        df_products,
        dropdown_options,
        filter_text,
    ) = retrieve_cache_filtered_data(
        start_date, end_date, select_trade, select_format, select_market, dropdown
    )
    return dropdown_options, filter_text, "data_retrieved"


@app.callback(
    Output("products-pnl-card", "children"),
    Output("products-issued-products-card", "children"),
    Output("products-issuers-card", "children"),
    Output("products-trades-card", "children"),
    Output("products-listed-proportion-card", "children"),
    Input("products-hidden-3-div", "children"),
    State("products-datepicker", "start_date"),
    State("products-datepicker", "end_date"),
    State("products-select-paper", "value"),
    State("products-select-format", "value"),
    State("products-select-market", "value"),
    State("products-dropdown", "value"),
    prevent_initial_call=True,
)
def display_key_figures(
    hid_div, start_date, end_date, select_trade, select_format, select_market, dropdown
):
    # Retrieve DataFrames
    (
        df_trades,
        df_products,
        dropdown_options,
        filter_text,
    ) = retrieve_cache_filtered_data(
        start_date, end_date, select_trade, select_format, select_market, dropdown
    )

    # Set "P&L" Card Text
    if df_trades.empty:
        pnl_card = html.Div(html.H5(f"N/A"))
    else:
        pnl_card = html.Div(
            [
                html.H5(f"{int(df_trades['Trade Margin'].sum()):,.0f} EUR"),
                html.P(f"Profit: + {int(df_trades['Win Margin'].sum()):,.0f}"),
                html.P(f"Loss: - {int(df_trades['Loss Margin'].abs().sum()):,.0f}"),
            ]
        )

    # Set "Number of Products Issued" Card Text
    df_issued_products = df_products[df_products["Issued?"] == 1]
    df_issued_products = df_issued_products.reset_index(drop=True)
    if df_issued_products.empty:
        top_product = ""
    else:
        top_product = f"Top Product: {df_issued_products.iloc[df_issued_products['Product Margin'].idxmax()]['Name']} (Margin: + {df_issued_products['Product Margin'].max():,.0f} EUR)"
    issued_products_card = html.Div(
        [
            html.H5(df_issued_products["Cfin"].nunique()),
            html.P(top_product),
        ]
    )

    # Set "Number of Issuers" Card Text
    df_external_paper_issuers_only = df_products[
        df_products["Issuer"].str.lower().str.contains("exane") == False
    ]
    issuer_nb = df_products["Issuer"].nunique()
    if df_external_paper_issuers_only.empty:
        issuer_txt = ""
    else:
        issuer_txt = f"external_paper Best: {df_external_paper_issuers_only['Issuer'].value_counts().index[0]} ({df_external_paper_issuers_only['Issuer'].value_counts()[0]} issued products)"
    issuers_card = html.Div(
        [
            html.H5(issuer_nb),
            html.P(issuer_txt),
        ]
    )

    # Set "Number of Trades" Card Text
    trades_card = html.Div(
        [
            html.H5(f"{len(df_trades.index):,.0f}"),
            html.P(
                f"Nb Sell: {len(df_trades[df_trades['Trade Side'] == 'Sell'].index):,.0f}"
            ),
            html.P(
                f"Nb Buy: {len(df_trades[df_trades['Trade Side'] == 'Buy'].index):,.0f}"
            ),
        ]
    )

    # Set "Listed Products Proportion" Card Text
    dff = df_products[["Cfin", "Market"]].drop_duplicates()
    df_products_listed = dff[dff["Market"] != "Not Listed"]
    if df_products_listed.empty:
        market = ""
    else:
        if len(df_products_listed["Market"].value_counts().index) == 3:
            market = (
                f"{df_products_listed['Market'].value_counts().index[0]} ({round(df_products_listed['Market'].value_counts()[0] / len(dff.index) * 100, 1)}%) - "
                f"{df_products_listed['Market'].value_counts().index[1]} ({round(df_products_listed['Market'].value_counts()[1] / len(dff.index) * 100, 1)}%) - "
                f"{df_products_listed['Market'].value_counts().index[2]} ({round(df_products_listed['Market'].value_counts()[2] / len(dff.index) * 100, 1)}%)"
            )
        elif len(df_products_listed["Market"].value_counts().index) == 2:
            market = (
                f"{df_products_listed['Market'].value_counts().index[0]} ({round(df_products_listed['Market'].value_counts()[0] / len(dff.index) * 100, 1)}%) - "
                f"{df_products_listed['Market'].value_counts().index[1]} ({round(df_products_listed['Market'].value_counts()[1] / len(dff.index) * 100, 1)}%)"
            )
        else:
            market = f"{df_products_listed['Market'].value_counts().index[0]} ({round(df_products_listed['Market'].value_counts()[0] / len(dff.index) * 100, 1)}%)"
    listed_proportion_card = html.Div(
        [
            html.H5(
                str(
                    round(
                        len(df_products_listed.index) / len(dff.index) * 100,
                        1,
                    )
                )
                + " %"
            ),
            html.P(market),
        ]
    )

    return (
        pnl_card,
        issued_products_card,
        issuers_card,
        trades_card,
        listed_proportion_card,
    )


@app.callback(
    Output("products-bar-chart-graph", "figure"),
    Output("products-bar-chart-dropdown", "disabled"),
    Input("products-hidden-3-div", "children"),
    Input("products-bar-chart-dropdown", "value"),
    State("products-datepicker", "start_date"),
    State("products-datepicker", "end_date"),
    State("products-select-paper", "value"),
    State("products-select-format", "value"),
    State("products-select-market", "value"),
    State("products-dropdown", "value"),
    prevent_initial_call=True,
)
def display_bar_chart(
    hid_div,
    bar_chart_dropdown,
    start_date,
    end_date,
    select_trade,
    select_format,
    select_market,
    dropdown,
):
    # Retrieve DataFrames
    (
        df_trades,
        df_products,
        dropdown_options,
        filter_text,
    ) = retrieve_cache_filtered_data(
        start_date, end_date, select_trade, select_format, select_market, dropdown
    )

    # Create & Return Bar Chart
    bar_chart_fig = create_bar_chart(
        df_trades[["Trade Date", "Trade Side", "Trade Margin", "Traded?"]],
        bar_chart_dropdown,
    )
    return bar_chart_fig, False


@app.callback(
    Output("products-pie-chart-graph", "figure"),
    Output("products-pie-chart-dropdown", "disabled"),
    Input("products-hidden-3-div", "children"),
    Input("products-pie-chart-dropdown", "value"),
    State("products-datepicker", "start_date"),
    State("products-datepicker", "end_date"),
    State("products-select-paper", "value"),
    State("products-select-format", "value"),
    State("products-select-market", "value"),
    State("products-dropdown", "value"),
    prevent_initial_call=True,
)
def display_pie_chart(
    hid_div,
    pie_chart_dropdown,
    start_date,
    end_date,
    select_trade,
    select_format,
    select_market,
    dropdown,
):
    # Retrieve DataFrames
    (
        df_trades,
        df_products,
        dropdown_options,
        filter_text,
    ) = retrieve_cache_filtered_data(
        start_date, end_date, select_trade, select_format, select_market, dropdown
    )

    # Create & Return Pie Chart
    pie_chart_fig = create_pie_chart(
        df_trades[["Cfin", "Trade Margin", "Traded?"]],
        df_products[["Cfin", "Issuer Type", "Issued?"]],
        pie_chart_dropdown,
    )
    return pie_chart_fig, False


@app.callback(
    Output("products-products-table", "data"),
    Output("products-products-table", "columns"),
    Input("products-hidden-3-div", "children"),
    Input("products-products-table", "filter_query"),
    Input("products-products-table-dropdown", "value"),
    State("products-datepicker", "start_date"),
    State("products-datepicker", "end_date"),
    State("products-select-paper", "value"),
    State("products-select-format", "value"),
    State("products-select-market", "value"),
    State("products-dropdown", "value"),
    prevent_initial_call=True,
)
def display_products_table(
    hid_div,
    filter_query,
    product_status,
    start_date,
    end_date,
    select_trade,
    select_format,
    select_market,
    dropdown,
):
    # Retrieve DataFrames
    (
        df_trades,
        df_products,
        dropdown_options,
        filter_text,
    ) = retrieve_cache_filtered_data(
        start_date, end_date, select_trade, select_format, select_market, dropdown
    )

    # Check If Filtered Column
    if filter_query != "":
        filter_col = filter_query.split(" ")[0][1:-1]
        filter_value = filter_query.split(" ")[-1]
        df_products = df_products[
            df_products[filter_col].astype(str).str.contains(filter_value)
        ]

    # Check If Status Filter
    if product_status == "dead_only":
        df_products = df_products[df_products["Status"] == "Dead"]
    elif product_status == "alive_only":
        df_products = df_products[df_products["Status"] == "Alive"]

    # Create & Return Products Table
    data, columns = format_products_table(df_products)
    return data, columns


@app.callback(
    Output("products-trades-table", "data"),
    Output("products-trades-table", "columns"),
    Input("products-hidden-3-div", "children"),
    Input("products-trades-table", "filter_query"),
    Input("products-trades-table-dropdown", "value"),
    State("products-datepicker", "start_date"),
    State("products-datepicker", "end_date"),
    State("products-select-paper", "value"),
    State("products-select-format", "value"),
    State("products-select-market", "value"),
    State("products-dropdown", "value"),
    prevent_initial_call=True,
)
def display_trades_table(
    hid_div,
    filter_query,
    trade_status,
    start_date,
    end_date,
    select_trade,
    select_format,
    select_market,
    dropdown,
):
    # Retrieve DataFrames
    (
        df_trades,
        df_products,
        dropdown_options,
        filter_text,
    ) = retrieve_cache_filtered_data(
        start_date, end_date, select_trade, select_format, select_market, dropdown
    )

    # Check If Filtered Column
    if filter_query != "":
        filter_col = filter_query.split(" ")[0][1:-1]
        filter_value = filter_query.split(" ")[-1]
        if filter_col in list(df_trades.columns):
            df_trades = df_trades[
                df_trades[filter_col].astype(str).str.contains(filter_value)
            ]
        else:
            df_products = df_products[
                df_products[filter_col].astype(str).str.contains(filter_value)
            ]

    # Check If Status Filter
    if trade_status == "wins_only":
        df_trades = df_trades[df_trades["Trade Margin"] > 0]
    elif trade_status == "losses_only":
        df_trades = df_trades[df_trades["Trade Margin"] < 0]

    # Create & Return Trades Table
    data, columns = format_trades_table(
        df_trades[
            [
                "Cfin",
                "Trade Margin",
                "Size Traded",
                "Trade Side",
                "Trade Date",
                "Sales",
                "Nb Trd",
                "Traded?",
            ]
        ],
        df_products[
            [
                "Cfin",
                "ISIN",
                "Name",
                "Issuer",
                "Ccy",
                "Maturity Date",
                "Status",
            ]
        ],
    )
    return data, columns


@app.callback(
    Output("products-download", "data"),
    Input("products-button-trades-download", "n_clicks"),
    Input("products-button-products-download", "n_clicks"),
    State("products-trades-table", "data"),
    State("products-products-table", "data"),
    State("products-datepicker", "start_date"),
    State("products-datepicker", "end_date"),
    prevent_initial_call=True,
)
def download_tables(
    button_1, button_2, trades_table, products_table, start_date, end_date
):
    ctx = dash.callback_context
    trigger = ctx.triggered[0]["prop_id"].split(".")[0]

    if trigger == "products-button-trades-download":
        df = pd.DataFrame(trades_table)
        title = "trades"
    else:
        df = pd.DataFrame(products_table)
        title = "products"

    if not df.empty:
        filename = f"{title}_{start_date}_{end_date}.xlsx"
        return send_data_frame(df.to_excel, filename)
    else:
        raise PreventUpdate


@app.callback(
    Output("products-trades-table", "style_table"),
    Input("products-button-trades-eye", "n_clicks"),
    State("products-trades-table", "style_table"),
    prevent_initial_call=True,
)
def display_all_trades(n_clicks, style):
    if (n_clicks % 2) != 0:
        style.pop("maxHeight", None)
        return style
    style["maxHeight"] = "500px"
    return style


@app.callback(
    Output("products-products-table", "style_table"),
    Input("products-button-products-eye", "n_clicks"),
    State("products-products-table", "style_table"),
    prevent_initial_call=True,
)
def display_all_products(n_clicks, style):
    if (n_clicks % 2) != 0:
        style.pop("maxHeight", None)
        return style
    style["maxHeight"] = "500px"
    return style


@app.callback(
    Output("products-collapse", "is_open"),
    Output("products-collapse-info", "is_open"),
    Input("products-button-filter-eye", "n_clicks"),
    State("products-collapse", "is_open"),
    prevent_initial_call=True,
)
def display_collapse(n_clicks, status):
    return not status, status


app.clientside_callback(
    ClientsideFunction("ui", "replaceWithLinks_table_products_trades"),
    Output("products-hidden-1-div", "children"),
    Input("products-trades-table", "derived_viewport_data"),
)

app.clientside_callback(
    ClientsideFunction("ui", "replaceWithLinks_table_products_products"),
    Output("products-hidden-2-div", "children"),
    Input("products-products-table", "derived_viewport_data"),
)

from app import app, db
from dash import dcc
from dash import html
import dash_bootstrap_components as dbc
from dash.dependencies import Input, Output, State
import requests as rq

from flask_login import current_user
from utils.basics import dt_today
from emails.mail_sender import MailEuroclear
from utils.sql_write import insert_or_update_code
from models.base import Codes
from dash import callback_context
from dash.dependencies import Input, Output, State
from dash.exceptions import PreventUpdate
from dash.dash_table import DataTable
from dash.dash_table.Format import Format

from local_db_mgt import CandidatesIsin
import datetime as dt

colors = {"red": "#c0392b", "green": "#16a085"}

background_colors = {
    "red": "rgba(231, 76, 60, 0.1)",
    "green": "rgba(22, 160, 133, 0.1)",
    "blue": "rgba(52, 152, 219, 0.1)",
}

style_hidden = {"display": "none"}

# the letters allowed in an ISIN
_alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def calc_check_digit(number):
    """Calculate the check digits for the number."""
    # convert to numeric first, then double some, then sum individual digits
    number = "".join(str(_alphabet.index(n)) for n in number)
    number = "".join(
        str((2, 1)[i % 2] * int(n)) for i, n in enumerate(reversed(number))
    )
    return str((10 - sum(int(n) for n in number)) % 10)


def update_value_in_db(id: int, field, value):
    c = CandidatesIsin.query.filter_by(id=id).first()

    if isinstance(value, str):
        value = value.strip().rstrip()

    if field == "is_sent":
        value = True if (value == "TRUE") else False

    if field == "datetime":
        if value:
            if isinstance(value, dt.datetime):
                value = value.date()
            if isinstance(value, str):
                value = dt.datetime.strptime(value, "%Y-%m-%d").date()
        else:
            value = dt_today()

    if field == "user":
        if not value:
            value = current_user.username

    setattr(c, field, value)
    db.session.commit()


def isin_generator(code):
    """Returns the ISIN for the given Code

    Checks if the code has 4 characters, otherwise returns an empty string

    """
    if len(code) == 4:

        # Generate the ISIN
        pre_isin = f"FREXI{code}00"
        check_digit = calc_check_digit(pre_isin)

        return f"{pre_isin}{check_digit}"

    return ""


def new_isin_candidate(**kwargs):
    try:
        # Add the line in the database
        candidate = CandidatesIsin(user=current_user.username)

        # If user wants to set default elements for this new row
        for key, value in kwargs.items():
            if key not in ["datetime", "user", "is_sent"]:
                if value:
                    setattr(candidate, key, value)

        # Add and Commit in internal database
        db.session.add(candidate)
        db.session.commit()

        return candidate

    except Exception as e:
        app.logger.exception(e)


def get_db_data(is_sent=False):
    try:
        db_values = CandidatesIsin.query.filter_by(is_sent=is_sent).all()
    except:
        db.create_all()
        db_values = CandidatesIsin.query.filter_by(is_sent=is_sent).all()
    finally:
        return [
            {
                "id": x.id,
                "cfin": x.cfin,
                "long_name": x.long_name,
                "short_name": x.short_name,
                "description": x.description,
                "ticker": x.ticker,
                "code": x.code,
                "isin": x.isin,
                "datetime": x.datetime.strftime("%Y-%m-%d"),
                "user": x.user,
                "is_sent": str(x.is_sent).upper(),
            }
            for x in db_values
        ][::-1]


params = {
    "id": {
        "id": "id",
        "name": "id",
        "type": "numeric",
    },
    "long_name": {
        "id": "long_name",
        "name": "Name",
        "type": "text",
    },
    "short_name": {
        "id": "short_name",
        "name": "Short Name",
        "type": "text",
    },
    "description": {
        "id": "description",
        "name": "Description",
        "type": "text",
    },
    "ticker": {
        "id": "ticker",
        "name": "Ticker",
        "type": "text",
    },
    "code": {
        "id": "code",
        "name": "Code",
        "type": "text",
    },
    "isin": {
        "id": "isin",
        "name": "ISIN",
        "type": "text",
    },
    "cfin": {
        "id": "cfin",
        "name": "Cfin",
        "type": "numeric",
    },
    "datetime": {
        "id": "datetime",
        "name": "Date",
        "default": dt_today(),
        "type": "datetime",
    },
    "user": {
        "id": "user",
        "name": "Added by",
        "type": "text",
    },
    "is_sent": {
        "id": "is_sent",
        "name": "Sent",
        "default": "FALSE",
        "type": "text",
        "presentation": "dropdown",
        "dropdown": {
            "options": [
                {"label": "TRUE", "value": "TRUE"},
                {"label": "FALSE", "value": "FALSE"},
            ],
            "clearable": False,
        },
    },
}

style_data_conditional = [
    {
        "if": {"column_id": "long_name"},
        "width": "250px",
        "maxWidth": "250px",
    },
    {
        "if": {"column_id": "short_name"},
        "width": "150px",
        "maxWidth": "150px",
    },
    {
        "if": {"column_id": "description"},
        "width": "300px",
        "maxWidth": "300px",
        "paddingRight": "30px",
    },
    {
        "if": {"column_id": "ticker"},
        "width": "110px",
        "maxWidth": "110px",
    },
    {
        "if": {"column_id": "code"},
        "width": "80px",
        "maxWidth": "80px",
    },
    {
        "if": {"column_id": "isin"},
        "width": "115px",
        "maxWidth": "115px",
        "cursor": "not-allowed",
    },
    {
        "if": {"column_id": "cfin"},
        "width": "80px",
        "maxWidth": "80px",
    },
    {
        "if": {"column_id": "datetime"},
        "width": "100px",
        "maxWidth": "100px",
        "cursor": "not-allowed",
    },
    {
        "if": {"column_id": "user"},
        "width": "100px",
        "maxWidth": "100px",
        "cursor": "not-allowed",
    },
    {
        "if": {"column_id": "is_sent"},
        "width": "80px",
        "maxWidth": "80px",
    },
    {
        "if": {
            "column_id": "isin",
            "filter_query": '{isin} contains "ISIN of"',
        },
        "color": colors["red"],
        "backgroundColor": background_colors["red"],
    },
    {
        "if": {
            "column_id": "is_sent",
            "filter_query": '{is_sent} eq "FALSE"',
        },
        "color": colors["red"],
        "backgroundColor": background_colors["red"],
    },
    {
        "if": {"state": "active"},
        "backgroundColor": background_colors["blue"],
        "border": "none",
        "color": "rgb(44, 62, 80)",
        "border-top": "1px solid rgb(236, 240, 241)",
        "border-bottom": "1px solid rgb(236, 240, 241)",
    },
    {
        "if": {"state": "selected"},
        "backgroundColor": background_colors["blue"],
        "border-top": "1px solid rgb(236, 240, 241)",
        "border-bottom": "1px solid rgb(236, 240, 241)",
    },
]

tooltip_header = {
    "short_name": "Max 18 characters",
    "code": "Exactly 4 characters",
}


def serve_layout():

    location = dcc.Location(id={"type": "url", "page": "isin"}, refresh=False)

    body_to_be_sent = dbc.Container(
        [
            dbc.Row(  # Row of the title
                [
                    dbc.Col(html.H1("New ISIN Candidates"), align="center", width=8),
                    dbc.Col(
                        dbc.Row(
                            [
                                dbc.Col(
                                    dbc.Button(
                                        "Add Line",
                                        id="isin-button-add-line",
                                        n_clicks=0,
                                    ),
                                    width=4,
                                ),
                                dbc.Col(
                                    dbc.Button(
                                        dbc.Spinner(
                                            html.Div(
                                                "Send Email",
                                                id="isin-button-send-email",
                                            ),
                                            size="sm",
                                            type="grow",
                                            color="secondary",
                                        ),
                                        id="button-pricing",
                                        n_clicks=0,
                                        color="primary",
                                    ),
                                    width=4,
                                ),
                            ],
                            justify="end",
                        ),
                        width=4,
                    ),
                ],
                className="mb-4",
            ),
            dbc.Row(  # Row of the Products
                [
                    dbc.Col(
                        [
                            DataTable(
                                id="isin-table-products",
                                columns=[{**params[x]} for x in params],
                                hidden_columns=[
                                    "id",
                                ],
                                dropdown={
                                    i: params[i]["dropdown"]
                                    for i in params
                                    if "dropdown" in params[i]
                                },
                                editable=True,
                                row_deletable=True,
                                style_header={
                                    "fontWeight": "bold",
                                    "backgroundColor": "white",
                                },
                                style_cell={
                                    # "overflow": "hidden",
                                    "textOverflow": "ellipsis",
                                    "minWidth": "0px",
                                    "padding": "5px",
                                    "font-family": "Roboto",
                                    "font-size": "12px",
                                    "text-align": "left",
                                    "backgroundColor": "transparent",
                                    "padding-top": "10px",
                                    "padding-bottom": "10px",
                                    "border-top": "0.1px solid rgb(240, 240, 240)",
                                    "border-bottom": "0.1px solid rgb(240, 240, 240)",
                                    "border-right": " 0px",
                                    "border-left": "0px",
                                },
                                style_data_conditional=style_data_conditional,
                                tooltip_header=tooltip_header,
                                tooltip_delay=0,
                                tooltip_duration=40000,
                            ),
                        ]
                    )
                ],
                className="mb-2",
            ),
        ],
        style={"maxWidth": "80%"},
        className="borded-card p-5 mt-3 mb-5 container-fluid",
    )

    body_already_sent = dbc.Container(
        [
            dbc.Row(  # Row of the title
                [
                    dbc.Col(
                        html.H1("ISIN Already Asked"),
                        align="center",
                        width=8,
                    ),
                ],
                className="mb-4",
            ),
            dbc.Row(  # Row of the Products
                [
                    dbc.Col(
                        [
                            DataTable(
                                id="isin-table-products-sent",
                                columns=[{**params[x]} for x in params],
                                hidden_columns=[
                                    "id",
                                ],
                                dropdown={
                                    i: params[i]["dropdown"]
                                    for i in params
                                    if "dropdown" in params[i]
                                },
                                editable=True,
                                row_deletable=True,
                                style_header={
                                    "fontWeight": "bold",
                                    "backgroundColor": "white",
                                },
                                style_cell={
                                    # "overflow": "hidden",
                                    "textOverflow": "ellipsis",
                                    "minWidth": "0px",
                                    "padding": "5px",
                                    "font-family": "Roboto",
                                    "font-size": "12px",
                                    "text-align": "left",
                                    "backgroundColor": "transparent",
                                    "padding-top": "10px",
                                    "padding-bottom": "10px",
                                    "border-top": "0.1px solid rgb(240, 240, 240)",
                                    "border-bottom": "0.1px solid rgb(240, 240, 240)",
                                    "border-right": " 0px",
                                    "border-left": "0px",
                                },
                                style_data_conditional=style_data_conditional,
                                tooltip_header=tooltip_header,
                                tooltip_delay=0,
                                tooltip_duration=None,
                            ),
                        ]
                    )
                ],
                className="mb-2",
            ),
        ],
        style={"maxWidth": "80%"},
        className="borded-card p-5 mt-3 mb-5 container-fluid",
    )

    modal = html.Div(
        [
            dbc.Modal(
                [
                    dbc.ModalHeader(
                        "Update Cfin in Exane Database", id="isin-modal-cfin-header"
                    ),
                    # dbc.ModalBody(id="isin-modal-cfin-body",),
                    dbc.ModalBody(
                        dbc.Row(
                            dbc.Button(
                                "Confirm",
                                id="isin-button-update-cfin",
                                n_clicks=0,
                                # size="sm",
                            ),
                            justify="center",
                            className="my-2",
                        ),
                    ),
                ],
                id="isin-modal-cfin",
                # size="sm",
                centered=True,
                is_open=False,
            ),
            dcc.Store(id="isin-modal-data", storage_type="memory"),
        ]
    )

    notification = dbc.Toast(
        id="isin-notification",
        is_open=False,
        dismissable=True,
        duration=4000,
        style={
            "position": "fixed",
            "top": 110,
            "right": 25,
            "width": 300,
        },
    )

    return [
        location,
        body_to_be_sent,
        body_already_sent,
        modal,
        notification,
    ]


@app.callback(
    Output("isin-table-products", "data"),
    Output("isin-table-products-sent", "data"),
    Output("isin-modal-data", "data"),
    Input("isin-table-products", "data_timestamp"),
    Input("isin-table-products-sent", "data_timestamp"),
    Input("isin-button-add-line", "n_clicks"),
    Input("isin-button-send-email", "n_clicks"),
    State("isin-table-products", "data"),
    State("isin-table-products", "data_previous"),
    State("isin-table-products-sent", "data"),
    State("isin-table-products-sent", "data_previous"),
)
def set_data_in_table_sent(
    time,
    time_sent,
    n_clicks,
    n_clicks2,
    data_table,
    data_table_previous,
    data_table_sent,
    data_table_sent_previous,
):
    ctx = callback_context
    triggered = ctx.triggered[0]["prop_id"].split(".")[0]

    # Initialize data for the Modal (for action confirmation)
    data_modal = {}

    # If any update in the table of not sent products
    if triggered == "isin-table-products":

        # Check if a Row has been deleted
        if len(data_table) != len(data_table_previous):

            # Find which name has been deleted and update db
            for x in data_table_previous:
                if x not in data_table:
                    id_deleted = x["id"]

            # Delete the row in the database
            CandidatesIsin.query.filter_by(id=id_deleted).delete()
            db.session.commit()

            return data_table, data_table_sent, data_modal

        # If you are here, one or more cells have been updated
        # We compare the data in the table with the data in the database
        data_db = get_db_data(is_sent=False)
        for i, data_row in enumerate(data_table):

            # Check if the row has an ID. If not, user added several lines at once
            if "id" not in data_row.keys():
                # Insert the data in the database
                c = new_isin_candidate(**data_row)
                # Set the new values to row data
                data_row = {x: getattr(c, x, data_row[x]) for x in data_row}
                data_row["id"] = c.id
                # Update the set of data to include the new row
                data_db = get_db_data(is_sent=False)

            if data_row != data_db[i]:
                id = data_row["id"]
                for key in data_row.keys():
                    value = data_row[key]
                    if value != data_db[i][key]:

                        # If user updates a Short Name
                        if key == "short_name":
                            value = value.rstrip().strip()

                            # Maximum number of characters is 18 for the Short Name
                            if len(value) > 18:
                                value = ""

                        # Update value as uppercase if type if relevant
                        if key in ["code", "ticker"]:
                            value = value.rstrip().strip().upper()

                        # If user adds a ticker, set default CODE to last 4 characters
                        if key == "ticker":
                            # 1 - Check if Ticker already exist in Exane database
                            # Check if the ISIN does not already exist in our database
                            r = Codes.query.filter(
                                Codes.cfcode == value, Codes.cfsource == 11
                            ).first()
                            if r:
                                # If the code already exists
                                if data_row["cfin"]:
                                    # Tel user if he put a Cfin already
                                    value = f"Ticker of {r.cfcfin}"
                                else:
                                    # If not, add the cfin in internal database
                                    update_value_in_db(id, "cfin", r.cfcfin)

                            # 2 - Check if user did not already set a CODE
                            if not data_row["code"]:
                                # If not, check if the Ticker is long enough and set default Code and ISIN
                                if len(value) >= 4:
                                    code = value[-4:]
                                    update_value_in_db(data_row["id"], "code", code)
                                    isin = isin_generator(code)
                                    update_value_in_db(id, "isin", isin)

                        # If user changes a code
                        if key == "code":
                            # 1 - Adapt the ISIN using the algorithm
                            isin = isin_generator(value)
                            update_value_in_db(id, "isin", isin)

                            # 2 - Set the product has not sent
                            update_value_in_db(id, "is_sent", "FALSE")

                        # If user adds or updates a Cfin
                        if key == "cfin":
                            # check if Cfin is not empty
                            if data_row["cfin"]:
                                isin = data_row["isin"]

                                # Check if Cfin already linked to ISIN
                                r = Codes.query.filter(
                                    Codes.cfcode == isin, Codes.cfsource == 6
                                ).first()

                                if r:
                                    if r.cfcode != isin:
                                        header = f"Set {isin} as {value}'s new ISIN Code. Current value is {r.cfcode}"
                                        data_modal["header"] = header
                                        data_modal["details"] = {
                                            "cfin": value,
                                            "isin": isin,
                                        }
                                else:
                                    header = f"Set {isin} as {value}'s new ISIN Code"
                                    data_modal["header"] = header
                                    data_modal["details"] = {
                                        "cfin": value,
                                        "isin": isin,
                                    }
                        # If tries to update an ISIN, set the code generator
                        if key == "isin":
                            value = isin_generator(data_row["code"])
                            # Check if ISIN does not already exist
                            r = Codes.query.filter(
                                Codes.cfcode == value, Codes.cfsource == 6
                            ).first()
                            if r:
                                # If the code already exists
                                if data_row["cfin"]:
                                    # Tel user if he put a Cfin already
                                    value = f"ISIN of {r.cfcfin}"
                                else:
                                    # If not, add the cfin in internal database
                                    update_value_in_db(id, "cfin", r.cfcfin)

                        # Update the value in Internal Database
                        update_value_in_db(id, key, value)

    # If any update in the table of sent products
    if triggered == "isin-table-products-sent":

        # Check if a Row has been deleted
        if len(data_table_sent) != len(data_table_sent_previous):
            # Find which name has been deleted and update db
            for x in data_table_sent_previous:
                if x not in data_table_sent:
                    id_deleted = x["id"]
            # Delete the row in the database
            CandidatesIsin.query.filter_by(id=id_deleted).delete()
            db.session.commit()
            return data_table, data_table_sent, data_modal

        # If you are here, one or more cells have been updated
        # We compare the data in the table with the data in the database
        data_db = get_db_data(is_sent=True)
        for i, data_row in enumerate(data_table_sent):
            if data_row != data_db[i]:
                for key in data_row.keys():
                    if data_row[key] != data_db[i][key]:
                        id = data_row["id"]
                        value = data_row[key]

                        # If user updates a Short Name
                        if key == "short_name":
                            value = value.rstrip().strip()
                            # Maximum number of characters is 18 for the Short Name
                            if len(value) > 18:
                                value = ""

                        # Update value as uppercase if type if relevant
                        if key in ["code", "ticker"]:
                            value = value.rstrip().strip().upper()

                        # If user changes a code
                        if key == "code":
                            # 1 - Adapt the ISIN using the algorithm
                            isin = isin_generator(value)
                            update_value_in_db(data_row["id"], "isin", isin)

                            # 2 - Set the product has not sent
                            update_value_in_db(data_row["id"], "is_sent", "FALSE")

                        # If user adds or updates a Cfin
                        if key == "cfin":
                            # check if Cfin is not empty
                            if data_row["cfin"]:
                                isin = data_row["isin"]
                                header = f"Set {isin} as {value}'s new ISIN Code"
                                data_modal["header"] = header
                                data_modal["details"] = {"cfin": value, "isin": isin}

                        # If tries to update an ISIN, set the code generator
                        if key == "isin":
                            value = isin_generator(data_row["code"])
                            # Check if ISIN does not already exist
                            r = Codes.query.filter(
                                Codes.cfcode == value, Codes.cfsource == 6
                            ).first()
                            if r:
                                # If the code already exists
                                if data_row["cfin"]:
                                    # Tel user if he put a Cfin already
                                    value = f"ISIN of {r.cfcfin}"
                                else:
                                    # If not, add the cfin in internal database
                                    update_value_in_db(id, "cfin", r.cfcfin)

                        # Update the value in Internal Database
                        update_value_in_db(id, key, value)

    # If user wants to add a line in the first table
    if triggered == "isin-button-add-line":
        # Insert new line in the database
        new_isin_candidate()

    # If user wants to send the email to Euroclear
    if triggered == "isin-button-send-email":

        # Send the email to Euroclear
        MailEuroclear(data_table)

        # Set all products as sent
        for row in data_table:
            update_value_in_db(row["id"], "is_sent", "TRUE")

    return (
        get_db_data(is_sent=False),
        get_db_data(is_sent=True),
        data_modal,
    )


@app.callback(
    Output("isin-modal-cfin", "is_open"),
    Output("isin-modal-cfin-header", "children"),
    Output("isin-notification", "is_open"),
    Output("isin-notification", "header"),
    Output("isin-notification", "children"),
    Output("isin-notification", "icon"),
    Input("isin-modal-data", "data"),
    Input("isin-button-update-cfin", "n_clicks"),
    State("isin-modal-cfin", "is_open"),
)
def open_modal_for_action_confirmation(data, n_clicks, is_open):
    notification = {"is_open": False, "header": "", "body": "", "icon": "primary"}
    if data and not is_open:
        return [True, data.get("header")] + list(notification.values())

    if data and n_clicks:
        cfin = data["details"].get("cfin")
        isin = data["details"].get("isin")

        update = insert_or_update_code(cfin, isin, "isin")

        # Check if the update was a success
        if update:
            # Insert_or_update_code(cfin, isin, kind="isin")
            notification = {
                "is_open": True,
                "header": f"ISIN update for Cfin {cfin}",
                "body": html.P(f"You have successfully set {isin}", className="mb-0"),
                "icon": "success",
            }
        else:
            # Update was not successful
            notification = {
                "is_open": True,
                "header": f"ISIN update for Cfin {cfin}",
                "body": html.P("You don't have sufficient rights", className="mb-0"),
                "icon": "danger",
            }
        return [False, ""] + list(notification.values())

    raise PreventUpdate

from dash.dash_table.Format import Format, Scheme, Group

from app import app

from dash import callback_context
from dash.dependencies import Input, Output, State, ALL, MATCH
from dash.exceptions import PreventUpdate
from dash.dash_table import DataTable
from dash import dcc
from dash import html
import dash_bootstrap_components as dbc

from flask_login import current_user
from utils.components import card_title
from utils.sql import *

from local_db_mgt import (
    rfq_history,
    all_issuers_codes_and_names,
    add_rfq_ticket,
    get_talks_to_from_client,
    set_client_talks_to,
    set_rfq_sent_to,
    get_details_from_ticket_id,
    get_details_from_id,
    get_issuers_sent_to_from_rfq,
    set_ticket_status_as_traded,
    delete_sent_to_from_rfq_id,
    delete_rfq_ticket,
    set_details_from_id,
    set_rfq_traded,
    delete_rfq_traded,
    set_ticket_status_as_untraded,
)

import ast


def formatting_size(x):
    if x >= 1000000:
        return f"{(x / 1000000):g}Mio"

    if x >= 100000:
        return f"{(x / 1000):g}k"

    return f"{x:,g}"


def serve_layout():
    location = dcc.Location(id={"type": "url", "page": "rfq"}, refresh=False)

    body = dbc.Container(
        [
            dbc.Row(  # Row of 'New Ticket' and 'Ongoing Today'
                [
                    dbc.Col(  # Col of the 'New Ticket'
                        [
                            dbc.Row(
                                [
                                    dbc.Col(
                                        card_title(
                                            "New Ticket",
                                        ),
                                        id="rfq-title-card-ticket",
                                        width="auto",
                                    ),
                                    dbc.Col(
                                        [
                                            html.P(
                                                id="rfq-id-update-ticket",
                                                hidden=True,
                                            ),
                                            html.P(
                                                id="rfq-update-id",
                                                hidden=True,
                                            ),
                                        ],
                                        width="auto",
                                        style={
                                            "color": "rgba(0, 0, 0, .5)",
                                        },
                                        className="align-self-center text-right",
                                    ),
                                ],
                                justify="between",
                            ),
                            dbc.Row(
                                [
                                    dbc.Col(
                                        [
                                            dcc.Dropdown(
                                                placeholder="Sales",
                                                style=dict(
                                                    width="350px",
                                                ),
                                                id="rfq-sales-dropdown",
                                                className="mb-1",
                                            ),
                                            dcc.Dropdown(
                                                placeholder="Client",
                                                style=dict(width="400px"),
                                                id="rfq-client-dropdown",
                                                className="mb-1",
                                            ),
                                            dbc.Input(
                                                placeholder="Product Description",
                                                className="mr-3 p-1",
                                                id="rfq-desc-prod-input",
                                            ),
                                            dbc.Form(
                                                [
                                                    html.Div(
                                                        [
                                                            dcc.Dropdown(
                                                                placeholder="Currency",
                                                                style=dict(
                                                                    width="100px"
                                                                ),
                                                                id="rfq-ccy-dropdown",
                                                            )
                                                        ],
                                                        className="mr-3",
                                                    ),
                                                    html.Div(
                                                        [
                                                            dbc.Input(
                                                                placeholder="Size",
                                                                id="rfq-size-input",
                                                                type="number",
                                                                step=100000,
                                                            ),
                                                        ],
                                                        className="mr-3 p-1",
                                                    ),
                                                ],
                                                # inline=True,
                                            ),
                                            dcc.Dropdown(
                                                placeholder="Asset Class",
                                                className="mr-3",
                                                id="rfq-asset-class-dropdown",
                                            ),
                                            dbc.Input(
                                                placeholder="Comment (Optionnal)",
                                                className="mr-3 mb-1",
                                                id="rfq-comment-input",
                                            ),
                                            dbc.Form(
                                                [
                                                    html.Div(
                                                        [
                                                            dbc.Checklist(
                                                                options=[
                                                                    {
                                                                        "label": "Note",
                                                                        "value": "Note",
                                                                    },
                                                                    {
                                                                        "label": "OTC",
                                                                        "value": "OTC",
                                                                    },
                                                                ],
                                                                inline=True,
                                                                id="rfq-note-otc-list",
                                                            ),
                                                        ],
                                                        className="mr-3 p-1",
                                                    ),
                                                    html.Div(
                                                        [
                                                            dbc.Checklist(
                                                                options=[
                                                                    {
                                                                        "label": "Live",
                                                                        "value": True,
                                                                    },
                                                                ],
                                                                inputClassName="mr-1",
                                                                labelClassName="mr-1",
                                                                switch=True,
                                                                inline=True,
                                                                id="rfq-live-list",
                                                            ),
                                                        ],
                                                        className="mr-3 p-1",
                                                    ),
                                                ],
                                                # inline=True,
                                            ),
                                            html.Div(
                                                [
                                                    dbc.Button(
                                                        "Create Ticket",
                                                        color="success",
                                                        className="mt-3 mr-3",
                                                        id="rfq-button-validate-ticket",
                                                    ),
                                                ],
                                                id="rfq-div-button-validate-ticket",
                                            ),
                                            html.Div(
                                                [
                                                    dbc.Row(
                                                        [
                                                            dbc.Col(
                                                                [
                                                                    dbc.Button(
                                                                        "Add History",
                                                                        color="success",
                                                                        className="mt-3 mr-1",
                                                                        id="rfq-button-add-history-ticket",
                                                                    ),
                                                                ],
                                                                width="auto",
                                                            ),
                                                            dbc.Col(
                                                                [
                                                                    dbc.Button(
                                                                        "Update",
                                                                        color="warning",
                                                                        className="mt-3 mr-1",
                                                                        id="rfq-button-update-ticket",
                                                                    ),
                                                                ],
                                                                width="auto",
                                                            ),
                                                            dbc.Col(
                                                                [
                                                                    dbc.Button(
                                                                        "Create New",
                                                                        color="primary",
                                                                        className="mt-3 mr-3",
                                                                        id="rfq-button-cancel-ticket",
                                                                    ),
                                                                ]
                                                            ),
                                                        ]
                                                    ),
                                                ],
                                                hidden=True,
                                                id="rfq-div-button-update-ticket",
                                            ),
                                            dbc.Toast(
                                                id="rfq-notif-ticket",
                                                icon="success",
                                                header="Ticket Management",
                                                is_open=False,
                                                dismissable=True,
                                                duration=1000,
                                                headerClassName="home-notif-header",
                                                bodyClassName="home-notif-body",
                                                className="home-notif-toast",
                                            ),
                                        ],
                                        width=7,
                                    ),
                                    dbc.Col(
                                        [
                                            dbc.Row(
                                                [
                                                    dbc.Col(
                                                        [
                                                            html.H6(
                                                                "RFQ Sent To",
                                                                style={
                                                                    "fontFamily": "Roboto"
                                                                },
                                                            ),
                                                            dbc.Checklist(
                                                                id="rfq-sent-to-list",
                                                                inputStyle={
                                                                    "margin-right": "10px"
                                                                },
                                                            ),
                                                        ]
                                                    ),
                                                    dbc.Col(
                                                        [
                                                            html.H6(
                                                                "Client Talks To",
                                                                style={
                                                                    "fontFamily": "Roboto"
                                                                },
                                                            ),
                                                            dbc.Checklist(
                                                                id="rfq-talks-to-list",
                                                                inputStyle={
                                                                    "margin-right": "10px"
                                                                },
                                                            ),
                                                        ]
                                                    ),
                                                ]
                                            ),
                                        ]
                                    ),
                                ],
                            ),
                        ],
                        width=7,
                        id="rfq-ticket-input",
                        className="borded-card p-4 m-1",
                    ),
                    dbc.Col(  # Col of the tickets 'Ongoing Today'
                        [
                            dbc.Row(
                                [
                                    dbc.Col(
                                        card_title("Ticket's History"),
                                    ),
                                ]
                            ),
                            dbc.Row(
                                [  # Row of the ongoing tickets
                                    dbc.Col(
                                        [
                                            html.Div(
                                                id="rfq-tickets-history",
                                                style={
                                                    "overflow-y": "auto",
                                                    "height": "400px",
                                                },
                                            )
                                        ],
                                    )
                                ]
                            ),
                        ],
                        className="borded-card p-4 m-1",
                    ),
                ],
                className="mt-1",
                justify="between",
            ),
            dbc.Row(  # Row of 'History'
                [
                    dbc.Col(
                        [
                            dbc.Row(
                                dbc.Col(
                                    card_title("History"),
                                )
                            ),
                            dbc.Row(
                                [
                                    dbc.Col(
                                        [
                                            DataTable(
                                                filter_action="native",
                                                sort_action="native",
                                                style_as_list_view=True,
                                                style_header={
                                                    "backgroundColor": "white",
                                                    "fontWeight": "bold",
                                                    "fontFamily": "Roboto",
                                                },
                                                export_headers="display",
                                                style_cell={
                                                    "overflow": "hidden",
                                                    "textOverflow": "ellipsis",
                                                    "padding": "5px",
                                                    "fontFamily": "Roboto",
                                                    "backgroundColor": "transparent",
                                                    "text-align": "left",
                                                    "border-top": "1px solid rgb(236, 240, 241)",
                                                    "border-bottom": "1px solid rgb(236, 240, 241)",
                                                    "border-right": " 0px",
                                                    "border-left": "0px",
                                                },
                                                style_data={
                                                    "width": "15px",
                                                    "maxWidth": "180px",
                                                    "minWidth": "0px",
                                                    "paddingTop": "15px",
                                                    "paddingBottom": "15px",
                                                },
                                                style_data_conditional=[
                                                    {
                                                        "if": {
                                                            "state": "active"
                                                        },  # 'active' | 'selected'
                                                        "backgroundColor": "transparent",
                                                        "border": "none",
                                                        "color": "rgb(44, 62, 80)",
                                                        "border-top": "1px solid rgb(236, 240, 241)",
                                                        "border-bottom": "1px solid rgb(236, 240, 241)",
                                                    },
                                                    {
                                                        "if": {"state": "selected"},
                                                        "backgroundColor": "transparent",
                                                        "border-top": "1px solid rgb(236, 240, 241)",
                                                        "border-bottom": "1px solid rgb(236, 240, 241)",
                                                    },
                                                ],
                                                page_size=10,
                                                id="rfq-table-history",
                                            )
                                        ]
                                    )
                                ],
                            ),
                        ],
                        className="borded-card p-4 m-1",
                    )
                ]
            ),
        ],
        fluid=True,
        style={"maxWidth": "85%"},
    )

    hidden_divs = [
        html.Div(id="rfq-ticket-created", hidden=True),
        html.Div(id="rfq-ticket-updated", hidden=True),
        html.Div(id="rfq-id-update", hidden=True),
        html.Div(id="rfq-seleted-table", hidden=True),
        html.Div(id="rfq-cancel-update-ticket", hidden=True),
        html.Div(id="rfq-traded-ticket", hidden=True),
        html.Div(id="rfq-untraded-ticket", hidden=True),
        html.Div(id="rfq-deleted-ticket", hidden=True),
    ]

    return [location, body, *hidden_divs]


@app.callback(
    Output("rfq-sales-dropdown", "options"),
    Input({"type": "url", "page": "rfq"}, "href"),
)
@cache.memoize(timeout=86400)
def load_options_sales(
    href,
):
    df = all_sales_alive()

    # Options for the dropdown
    return [
        {"label": f"{x[0]} {x[1]} - {x[2]}", "value": f"{x[1]} {x[0]}/{x[2]}"}
        for x in zip(df.sales_name, df.sales_first_name, df.sales_code)
    ]


@app.callback(
    Output("rfq-client-dropdown", "options"),
    Input({"type": "url", "page": "rfq"}, "href"),
)
@cache.memoize(timeout=86400)
def load_options_client(
    href,
):
    data = OpenPositions().all_accounts()
    df = pd.DataFrame(data)
    df = df[~df.institution.str.contains("INACTIF")]

    return [
        {"label": x[0], "value": f"{x[0]}/{x[1]}"}
        for x in zip(df.institution, df.institutionId)
    ]


@app.callback(
    Output("rfq-ccy-dropdown", "options"),
    Input({"type": "url", "page": "rfq"}, "href"),
)
def load_options_ccy(
    href,
):
    df = all_currencies()
    return [{"label": f"{x[0]}", "value": x[0]} for x in zip(df.ccy)]


@app.callback(
    Output("rfq-asset-class-dropdown", "options"),
    Input({"type": "url", "page": "rfq"}, "href"),
)
def load_options_asset_class(
    href,
):
    return [
        {"label": x, "value": x}
        for x in ["Credit", "FX", "Equity", "Commo", "Taux", "AMC"]
    ]


@app.callback(
    Output("rfq-table-history", "data"),
    Output("rfq-table-history", "columns"),
    Output("rfq-table-history", "hidden_columns"),
    Input({"type": "url", "page": "rfq"}, "href"),
    Input("rfq-notif-ticket", "children"),
)
def load_bottom_table_with_tickets_history(
    href,
    notif,
):
    df = rfq_history()
    if not df.empty:
        data = df.rename_axis("id").reset_index(level=0).to_dict("records")
        columns = [
            {"name": i, "id": i}
            if i != "size"
            else {
                "name": i,
                "id": i,
                "type": "numeric",
                "format": Format(
                    scheme=Scheme.fixed,
                    precision=0,
                    group=Group.yes,
                ),
            }
            for i in df.columns
        ]
        return data, columns, ["id_ticket"]

    raise PreventUpdate


@app.callback(
    Output("rfq-talks-to-list", "options"),
    Output("rfq-sent-to-list", "options"),
    Input({"type": "url", "page": "rfq"}, "href"),
)
def load_options_issuers(
    href,
):
    issuers = all_issuers_codes_and_names()

    df = pd.DataFrame(issuers)

    options = [
        {"label": x[0], "value": f"{x[0]}/{x[1]}"}
        for x in zip(df.short_name, df.code_exane)
    ]

    return [options, options]


@app.callback(
    Output("rfq-talks-to-list", "value"),
    Input("rfq-client-dropdown", "value"),
)
def load_previous_client_counterparts(
    client,
):
    if client is None:
        return []

    client_name, client_id = client.split("/")
    df = get_talks_to_from_client(client_id)

    if not df.empty:
        issuers = all_issuers_codes_and_names()
        df_issuers = pd.DataFrame(issuers)
        lst_ids_previous_ccp = df.id_issuer.to_list()
        return [
            f"{x[0]}/{x[1]}"
            for x in zip(df_issuers.short_name, df_issuers.code_exane)
            if x[1] in lst_ids_previous_ccp
        ]

    return []


@app.callback(
    Output("rfq-tickets-history", "children"),
    Output("rfq-seleted-table", "data"),
    Input("rfq-table-history", "active_cell"),
    Input("rfq-ticket-updated", "data"),
    Input("rfq-ticket-created", "data"),
    Input("rfq-traded-ticket", "data"),
    Input("rfq-untraded-ticket", "data"),
    Input("rfq-button-cancel-ticket", "n_clicks"),
    Input("rfq-deleted-ticket", "data"),
    Input("rfq-update-id", "children"),
    State("rfq-table-history", "derived_viewport_data"),
    State("rfq-id-update-ticket", "children"),
    prevent_initial_call=True,
)
def update_tickets_history(
    active_cell,
    updated_ticket,
    created_ticket,
    traded_ticket,
    untraded_ticket,
    cancel_click,
    deleted_ticket,
    update_id,
    data,
    ticket_id_update,
):
    ctx = callback_context
    triggered = ctx.triggered[0]["prop_id"].split(".")[0]

    if triggered == "rfq-ticket-updated":

        details = get_details_from_ticket_id(ticket_id_update)

    elif triggered == "rfq-ticket-created":

        rfq_details = get_details_from_id(created_ticket).to_dict("records")[0]
        details = get_details_from_ticket_id(rfq_details["id_ticket"])

    elif triggered == "rfq-table-history":

        if active_cell == None:
            raise PreventUpdate

        row = data[active_cell["row"]]
        details = get_details_from_ticket_id(row["id_ticket"])

    elif triggered == "rfq-deleted-ticket":

        details = get_details_from_ticket_id(deleted_ticket)

    elif triggered == "rfq-update-id":

        rfq_details = get_details_from_id(update_id).to_dict("records")[0]
        details = get_details_from_ticket_id(rfq_details["id_ticket"])

    elif triggered == "rfq-traded-ticket":

        rfq_details = get_details_from_ticket_id(traded_ticket).to_dict("records")[0]
        details = get_details_from_ticket_id(rfq_details["id_ticket"])

    elif triggered == "rfq-untraded-ticket":

        rfq_details = get_details_from_id(untraded_ticket).to_dict("records")[0]
        details = get_details_from_ticket_id(rfq_details["id_ticket"])

    else:

        return [], None

    content = []

    if not details.empty:

        for x in details.to_dict("records"):

            df_issuers_sent_to = get_issuers_sent_to_from_rfq(x["id"])

            if not df_issuers_sent_to.empty:
                lst_issuers_sent_to = df_issuers_sent_to.short_name.to_list()
            else:
                lst_issuers_sent_to = []

            content += [
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            [
                                                dbc.Row(
                                                    [
                                                        html.Div(
                                                            dbc.Col(
                                                                [
                                                                    html.H5(
                                                                        dbc.Badge(
                                                                            "Live"
                                                                            if x[
                                                                                "is_live"
                                                                            ]
                                                                            else "Indic",
                                                                            pill=True,
                                                                            color="danger"
                                                                            if x[
                                                                                "is_live"
                                                                            ]
                                                                            else "success",
                                                                            className="mr-1",
                                                                        ),
                                                                        className="py-1 px-1",
                                                                    )
                                                                ],
                                                                className="pr-0",
                                                                width="auto",
                                                            ),
                                                            hidden=True
                                                            if x["is_traded"]
                                                            else False,
                                                        ),
                                                        html.Div(
                                                            dbc.Col(
                                                                [
                                                                    html.H5(
                                                                        dbc.Badge(
                                                                            "Traded",
                                                                            pill=True,
                                                                            color="primary",
                                                                            className="mr-1",
                                                                        ),
                                                                        className="py-1 px-1",
                                                                    )
                                                                ],
                                                                width="auto",
                                                                className="pr-0",
                                                            ),
                                                            hidden=False
                                                            if x["is_traded"]
                                                            else True,
                                                        ),
                                                        dbc.Col(
                                                            [
                                                                html.H5(
                                                                    x["sales_name"],
                                                                    className="mb-0 text-left",
                                                                ),
                                                                html.H6(
                                                                    x["structurer"],
                                                                    className="text-left",
                                                                ),
                                                            ],
                                                            width="auto",
                                                            className="px-0 text-right",
                                                        ),
                                                        dbc.Col(
                                                            [
                                                                html.H6(
                                                                    x["client_name"],
                                                                    className="mb-0",
                                                                ),
                                                            ],
                                                            className="align-self-center text-right",
                                                            width="auto",
                                                        ),
                                                    ]
                                                )
                                            ]
                                        ),
                                        dbc.Col(
                                            [
                                                dbc.Row(
                                                    [
                                                        dbc.Col(
                                                            [
                                                                html.Div(
                                                                    dbc.Button(
                                                                        "...",
                                                                        id={
                                                                            "type": "popover-target",
                                                                            "index": x[
                                                                                "id"
                                                                            ],
                                                                        },
                                                                        outline=True,
                                                                        style={
                                                                            "font-size": "20px",
                                                                            "color": "#222",
                                                                        },
                                                                        className="shadow-none border-none p-0",
                                                                    ),
                                                                    id=f"popover-div-wrapper-{x['id']}",
                                                                ),
                                                                dbc.Popover(
                                                                    [
                                                                        dbc.PopoverHeader(
                                                                            "RFQ Update Status"
                                                                        ),
                                                                        dbc.PopoverBody(
                                                                            dbc.Row(
                                                                                [
                                                                                    dbc.Col(
                                                                                        dbc.Button(
                                                                                            "Modify",
                                                                                            id={
                                                                                                "type": "rfq-button-update-id",
                                                                                                "index": x[
                                                                                                    "id"
                                                                                                ],
                                                                                            },
                                                                                            size="sm",
                                                                                            color="secondary",
                                                                                        ),
                                                                                        width="auto",
                                                                                    ),
                                                                                    html.Div(
                                                                                        dbc.Col(
                                                                                            dbc.Button(
                                                                                                "Traded",
                                                                                                id={
                                                                                                    "type": "rfq-button-modify-ticket",
                                                                                                    "index": x[
                                                                                                        "id"
                                                                                                    ],
                                                                                                },
                                                                                                size="sm",
                                                                                                color="secondary",
                                                                                            ),
                                                                                            width="auto",
                                                                                        ),
                                                                                        hidden=True
                                                                                        if x[
                                                                                            "is_traded"
                                                                                        ]
                                                                                        else False,
                                                                                    ),
                                                                                    html.Div(
                                                                                        dbc.Col(
                                                                                            dbc.Button(
                                                                                                "Untraded",
                                                                                                id={
                                                                                                    "type": "rfq-button-delete-traded-ticket",
                                                                                                    "index": x[
                                                                                                        "id"
                                                                                                    ],
                                                                                                },
                                                                                                size="sm",
                                                                                                color="secondary",
                                                                                            ),
                                                                                            width="auto",
                                                                                        ),
                                                                                        hidden=False
                                                                                        if x[
                                                                                            "is_traded"
                                                                                        ]
                                                                                        else True,
                                                                                    ),
                                                                                    dbc.Col(
                                                                                        dbc.Button(
                                                                                            "Delete",
                                                                                            id={
                                                                                                "type": "rfq-button-delete-ticket",
                                                                                                "index": x[
                                                                                                    "id"
                                                                                                ],
                                                                                            },
                                                                                            size="sm",
                                                                                            color="secondary",
                                                                                        ),
                                                                                        width="auto",
                                                                                    ),
                                                                                ],
                                                                                className="my-2",
                                                                                justify="center",
                                                                            ),
                                                                        ),
                                                                    ],
                                                                    id={
                                                                        "type": "popover",
                                                                        "index": x[
                                                                            "id"
                                                                        ],
                                                                    },
                                                                    # is_open=False,
                                                                    trigger="legacy",
                                                                    target=f"popover-div-wrapper-{x['id']}",
                                                                ),
                                                                dbc.Modal(
                                                                    [
                                                                        dbc.ModalHeader(
                                                                            "Traded With",
                                                                            className="justify-content-center",
                                                                        ),
                                                                        dbc.ModalBody(
                                                                            [
                                                                                dbc.RadioItems(
                                                                                    options=issuers_list_options(),
                                                                                    id={
                                                                                        "type": "rfq-issuer-traded-with-list",
                                                                                        "index": x[
                                                                                            "id"
                                                                                        ],
                                                                                    },
                                                                                )
                                                                            ]
                                                                        ),
                                                                        dbc.ModalFooter(
                                                                            dbc.Button(
                                                                                "Validate",
                                                                                id={
                                                                                    "type": "rfq-button-traded-with-list",
                                                                                    "index": x[
                                                                                        "id"
                                                                                    ],
                                                                                },
                                                                                className="ml-auto",
                                                                                color="success",
                                                                            ),
                                                                            className="justify-content-center",
                                                                        ),
                                                                    ],
                                                                    size="sm",
                                                                    centered=True,
                                                                    id={
                                                                        "type": "rfq-modal-traded-with-list",
                                                                        "index": x[
                                                                            "id"
                                                                        ],
                                                                    },
                                                                ),
                                                            ],
                                                            className="text-right",
                                                        ),
                                                    ]
                                                )
                                            ],
                                            width=1,
                                        ),
                                    ],
                                    className="mb-2",
                                ),
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            [
                                                html.H5(
                                                    f"{x['asset_class']} | {x['currency']} {formatting_size(x['size'])} | {x['description']}"
                                                ),
                                            ],
                                            className="pl-4",
                                        ),
                                        dbc.Col(
                                            [
                                                html.H6(
                                                    x["last_edit"].strftime(
                                                        "%b %d, %Y"
                                                    ),
                                                    className="mb-0",
                                                ),
                                                html.H6(
                                                    x["last_edit"].strftime("%Hh%M")
                                                ),
                                            ],
                                            width="auto",
                                            className="align-right text-right",
                                        ),
                                    ]
                                ),
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            [
                                                html.H6(
                                                    f"Format: {', '.join([i for (i, v) in zip(['Note', 'OTC'], [x['is_note'], x['is_otc']]) if v])}"
                                                ),
                                            ],
                                            width="auto",
                                            className="pl-4",
                                        ),
                                        dbc.Col(
                                            [
                                                html.H6(
                                                    f"Sent To: {', '.join(lst_issuers_sent_to)}"
                                                ),
                                            ],
                                            width="auto",
                                            className="pl-4",
                                        ),
                                    ]
                                ),
                            ],
                            className="p-0",
                        ),
                    ],
                    className="borded-card p-3 pb-1 m-2",
                    style={"background-color": "rgb(245,245,245)"}
                    if x["id"] == update_id
                    else {},
                )
            ]

        return content, details["id"].max()

    return [], None


@app.callback(
    Output("rfq-sales-dropdown", "value"),
    Output("rfq-client-dropdown", "value"),
    Output("rfq-desc-prod-input", "value"),
    Output("rfq-ccy-dropdown", "value"),
    Output("rfq-size-input", "value"),
    Output("rfq-asset-class-dropdown", "value"),
    Output("rfq-comment-input", "value"),
    Output("rfq-note-otc-list", "value"),
    Output("rfq-live-list", "value"),
    Output("rfq-sent-to-list", "value"),
    Output("rfq-notif-ticket", "children"),
    Output("rfq-notif-ticket", "icon"),
    Output("rfq-notif-ticket", "is_open"),
    Output("rfq-title-card-ticket", "children"),
    Output("rfq-id-update-ticket", "children"),
    Output("rfq-id-update-ticket", "hidden"),
    Output("rfq-div-button-validate-ticket", "hidden"),
    Output("rfq-div-button-update-ticket", "hidden"),
    Input("rfq-ticket-created", "data"),
    Input("rfq-seleted-table", "data"),
    Input("rfq-traded-ticket", "data"),
    Input("rfq-untraded-ticket", "data"),
    Input("rfq-deleted-ticket", "data"),
    Input("rfq-update-id", "children"),
    State("rfq-table-history", "derived_virtual_data"),
    prevent_initial_call=True,
)
def update_layout_ticket(
    created_ticket,
    selected_ticket,
    traded_ticket,
    untraded_ticket,
    deleted_ticket,
    rfq_id,
    data,
):
    ctx = callback_context
    triggered = ctx.triggered[0]["prop_id"].split(".")[0]

    if triggered == "rfq-ticket-created":

        details = get_details_from_id(created_ticket).to_dict("records")[0]

        sales = f"{details['sales_name']}/{details['sales_id']}"
        client = f"{details['client_name']}/{details['client_id']}"

        lst_note_otc = []
        if details["is_note"]:
            lst_note_otc.append("Note")
        if details["is_otc"]:
            lst_note_otc.append("OTC")

        df_sent_to = get_issuers_sent_to_from_rfq(created_ticket)

        if not df_sent_to.empty:
            lst_sent_to = [
                f"{name}/{code}"
                for code, name in zip(df_sent_to.id_issuer, df_sent_to.short_name)
            ]
        else:
            lst_sent_to = []

        return (
            sales,
            client,
            details.get("description"),
            details.get("currency"),
            details.get("size"),
            details.get("asset_class"),
            details.get("comment"),
            lst_note_otc,
            [True] if details["is_live"] else [],
            lst_sent_to,
            f"Created: {details['asset_class']} | {details['currency']} {formatting_size(details['size'])} | {details['description']}",
            "success",
            True,
            card_title("Modify Ticket"),
            details.get("id_ticket"),
            False,
            True,
            False,
        )

    if triggered == "rfq-seleted-table":
        if selected_ticket != None:

            details = get_details_from_id(selected_ticket).to_dict("records")[0]

            sales = f"{details['sales_name']}/{details['sales_id']}"
            client = f"{details['client_name']}/{details['client_id']}"

            lst_note_otc = []
            if details["is_note"]:
                lst_note_otc.append("Note")
            if details["is_otc"]:
                lst_note_otc.append("OTC")

            df_sent_to = get_issuers_sent_to_from_rfq(selected_ticket)

            if not df_sent_to.empty:
                lst_sent_to = [
                    f"{name}/{code}"
                    for code, name in zip(df_sent_to.id_issuer, df_sent_to.short_name)
                ]
            else:
                lst_sent_to = []

            return (
                sales,
                client,
                details.get("description"),
                details.get("currency"),
                details.get("size"),
                details.get("asset_class"),
                details.get("comment"),
                lst_note_otc,
                [True] if details["is_live"] else [],
                lst_sent_to,
                f"Loaded: {details['currency']} {formatting_size(details['size'])} | {details['description']}",
                "warning",
                True,
                card_title("Modify Ticket"),
                details.get("id_ticket"),
                False,
                True,
                False,
            )

    if triggered == "rfq-traded-ticket":
        details = get_details_from_id(selected_ticket).to_dict("records")[0]

        return (
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            [],
            [],
            [],
            f"Ticket Traded: {details['currency']} {formatting_size(details['size'])} | {details['description']}",
            "success",
            True,
            card_title("New Ticket"),
            "",
            True,
            False,
            True,
        )

    if triggered == "rfq-untraded-ticket":

        details = get_details_from_id(untraded_ticket).to_dict("records")[0]

        sales = f"{details['sales_name']}/{details['sales_id']}"
        client = f"{details['client_name']}/{details['client_id']}"

        lst_note_otc = []
        if details["is_note"]:
            lst_note_otc.append("Note")
        if details["is_otc"]:
            lst_note_otc.append("OTC")

        df_sent_to = get_issuers_sent_to_from_rfq(untraded_ticket)

        if not df_sent_to.empty:
            lst_sent_to = [
                f"{name}/{code}"
                for code, name in zip(df_sent_to.id_issuer, df_sent_to.short_name)
            ]
        else:
            lst_sent_to = []

        return (
            sales,
            client,
            details.get("description"),
            details.get("currency"),
            details.get("size"),
            details.get("asset_class"),
            details.get("comment"),
            lst_note_otc,
            [True] if details["is_live"] else [],
            lst_sent_to,
            f"Status changed to Untraded: {details['asset_class']} | {details['currency']} {formatting_size(details['size'])} | {details['description']}",
            "warning",
            True,
            card_title("Modify Ticket"),
            details.get("id_ticket"),
            False,
            True,
            False,
        )

    if triggered == "rfq-deleted-ticket":

        details = get_details_from_ticket_id(deleted_ticket)

        if not details.empty:

            details = details.to_dict("records")[0]

            sales = f"{details['sales_name']}/{details['sales_id']}"
            client = f"{details['client_name']}/{details['client_id']}"

            lst_note_otc = []
            if details["is_note"]:
                lst_note_otc.append("Note")
            if details["is_otc"]:
                lst_note_otc.append("OTC")

            df_sent_to = get_issuers_sent_to_from_rfq(selected_ticket)

            if not df_sent_to.empty:
                lst_sent_to = [
                    f"{name}/{code}"
                    for code, name in zip(df_sent_to.id_issuer, df_sent_to.short_name)
                ]
            else:
                lst_sent_to = []

            return (
                sales,
                client,
                details.get("description"),
                details.get("currency"),
                details.get("size"),
                details.get("asset_class"),
                details.get("comment"),
                lst_note_otc,
                [True] if details["is_live"] else [],
                lst_sent_to,
                f"RFQ Deleted | Loaded: {details['currency']} {formatting_size(details['size'])} | {details['description']}",
                "danger",
                True,
                card_title("Modify Ticket"),
                details.get("id_ticket"),
                False,
                True,
                False,
            )

    if triggered == "rfq-update-id":
        if rfq_id is not None:
            details = get_details_from_id(rfq_id).to_dict("records")[0]

            sales = f"{details['sales_name']}/{details['sales_id']}"
            client = f"{details['client_name']}/{details['client_id']}"

            lst_note_otc = []
            if details["is_note"]:
                lst_note_otc.append("Note")
            if details["is_otc"]:
                lst_note_otc.append("OTC")

            df_sent_to = get_issuers_sent_to_from_rfq(rfq_id)

            if not df_sent_to.empty:
                lst_sent_to = [
                    f"{name}/{code}"
                    for code, name in zip(df_sent_to.id_issuer, df_sent_to.short_name)
                ]
            else:
                lst_sent_to = []

            return (
                sales,
                client,
                details.get("description"),
                details.get("currency"),
                details.get("size"),
                details.get("asset_class"),
                details.get("comment"),
                lst_note_otc,
                [True] if details["is_live"] else [],
                lst_sent_to,
                f"Loaded: {details['currency']} {formatting_size(details['size'])} | {details['description']}",
                "warning",
                True,
                card_title("Modify Ticket"),
                details.get("id_ticket"),
                False,
                True,
                False,
            )

    return (
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        [],
        [],
        [],
        "",
        "warning",
        False,
        card_title("New Ticket"),
        "",
        True,
        False,
        True,
    )


@app.callback(
    Output("rfq-ticket-created", "data"),
    Input("rfq-button-validate-ticket", "n_clicks"),
    State("rfq-sales-dropdown", "value"),
    State("rfq-client-dropdown", "value"),
    State("rfq-desc-prod-input", "value"),
    State("rfq-ccy-dropdown", "value"),
    State("rfq-size-input", "value"),
    State("rfq-asset-class-dropdown", "value"),
    State("rfq-comment-input", "value"),
    State("rfq-note-otc-list", "value"),
    State("rfq-live-list", "value"),
    State("rfq-talks-to-list", "value"),
    State("rfq-sent-to-list", "value"),
    prevent_initial_call=True,
)
def create_ticket(
    n_click,
    sales,
    client,
    description,
    ccy,
    size,
    asset_class,
    comment,
    list_note_otc,
    is_live,
    talks_to,
    sent_to,
):
    if n_click is None:
        raise PreventUpdate

    # Reformating

    sales_name, sales_id = sales.split("/")
    client_name, client_id = client.split("/")

    structurer = current_user.displayname
    is_note = True if list_note_otc and "Note" in list_note_otc else False
    is_otc = True if list_note_otc and "OTC" in list_note_otc else False
    is_live = True if is_live else False

    id_rfq, id_ticket = add_rfq_ticket(
        sales_id,
        sales_name,
        structurer,
        client_id,
        client_name,
        description,
        ccy,
        size,
        asset_class,
        comment,
        is_note,
        is_otc,
        is_live,
        False,
    )

    if talks_to:
        talks_to_ids = [x.split("/")[1] for x in talks_to]
        set_client_talks_to(talks_to_ids, client_id)

    if sent_to:
        send_to_ids = [x.split("/")[1] for x in sent_to]
        set_rfq_sent_to(send_to_ids, id_rfq)

    return id_rfq


@app.callback(
    Output("rfq-ticket-updated", "data"),
    Input("rfq-button-update-ticket", "n_clicks"),
    Input("rfq-button-add-history-ticket", "n_clicks"),
    State("rfq-update-id", "children"),
    State("rfq-sales-dropdown", "value"),
    State("rfq-client-dropdown", "value"),
    State("rfq-desc-prod-input", "value"),
    State("rfq-ccy-dropdown", "value"),
    State("rfq-size-input", "value"),
    State("rfq-asset-class-dropdown", "value"),
    State("rfq-comment-input", "value"),
    State("rfq-note-otc-list", "value"),
    State("rfq-live-list", "value"),
    State("rfq-talks-to-list", "value"),
    State("rfq-sent-to-list", "value"),
    State("rfq-id-update-ticket", "children"),
    prevent_initial_call=True,
)
def update_ticket(
    n_click_update,
    n_click_add_hist,
    rfq_id,
    sales,
    client,
    description,
    ccy,
    size,
    asset_class,
    comment,
    list_note_otc,
    is_live,
    talks_to,
    sent_to,
    ticket_id,
):
    if (n_click_update or n_click_add_hist) is None:
        raise PreventUpdate

    ctx = callback_context
    triggered = ctx.triggered[0]["prop_id"].split(".")[0]

    if triggered == "rfq-button-update-ticket":

        if not rfq_id == None:

            sales_name, sales_id = sales.split("/")
            client_name, client_id = client.split("/")

            structurer = current_user.displayname
            is_note = True if list_note_otc and "Note" in list_note_otc else False
            is_otc = True if list_note_otc and "OTC" in list_note_otc else False
            is_live = True if is_live else False

            set_details_from_id(
                rfq_id,
                sales_id,
                sales_name,
                structurer,
                client_id,
                client_name,
                description,
                ccy,
                size,
                asset_class,
                comment,
                is_note,
                is_otc,
                is_live,
                False,
                ticket_id,
            )

            talks_to_ids = [x.split("/")[1] for x in talks_to]
            send_to_ids = [x.split("/")[1] for x in sent_to]

            if talks_to:
                set_client_talks_to(talks_to_ids, client_id)

            if sent_to:
                delete_sent_to_from_rfq_id(rfq_id)
                set_rfq_sent_to(send_to_ids, rfq_id)

            return ticket_id

        sales_name, sales_id = sales.split("/")
        client_name, client_id = client.split("/")

        structurer = current_user.displayname
        is_note = True if list_note_otc and "Note" in list_note_otc else False
        is_otc = True if list_note_otc and "OTC" in list_note_otc else False
        is_live = True if is_live else False

        last_id = get_details_from_ticket_id(ticket_id)["id"].max()

        set_details_from_id(
            last_id,
            sales_id,
            sales_name,
            structurer,
            client_id,
            client_name,
            description,
            ccy,
            size,
            asset_class,
            comment,
            is_note,
            is_otc,
            is_live,
            False,
            ticket_id,
        )

        talks_to_ids = [x.split("/")[1] for x in talks_to]
        send_to_ids = [x.split("/")[1] for x in sent_to]

        if talks_to:
            set_client_talks_to(talks_to_ids, client_id)

        if sent_to:
            delete_sent_to_from_rfq_id(last_id)
            set_rfq_sent_to(send_to_ids, last_id)

        return ticket_id

    sales_name, sales_id = sales.split("/")
    client_name, client_id = client.split("/")

    structurer = current_user.displayname
    is_note = True if list_note_otc and "Note" in list_note_otc else False
    is_otc = True if list_note_otc and "OTC" in list_note_otc else False
    is_live = True if is_live else False

    id_rfq, id_ticket = add_rfq_ticket(
        sales_id,
        sales_name,
        structurer,
        client_id,
        client_name,
        description,
        ccy,
        size,
        asset_class,
        comment,
        is_note,
        is_otc,
        is_live,
        False,
        ticket_id,
    )

    talks_to_ids = [x.split("/")[1] for x in talks_to]
    send_to_ids = [x.split("/")[1] for x in sent_to]

    if talks_to:
        set_client_talks_to(talks_to_ids, client_id)

    if sent_to:
        set_rfq_sent_to(send_to_ids, id_rfq)

    return id_ticket


@app.callback(
    Output("rfq-traded-ticket", "data"),
    Input({"type": "rfq-button-traded-with-list", "index": ALL}, "n_clicks"),
    State("rfq-id-update-ticket", "children"),
    State({"type": "rfq-issuer-traded-with-list", "index": ALL}, "value"),
    prevent_initial_call=True,
)
def update_traded_ticket(values, ticket_id, issuers):

    if not any(values):
        return None

    ctx = callback_context
    triggered = ctx.triggered[0]["prop_id"].split(".")[0]
    dict_params = ast.literal_eval(triggered)

    rfq_id = dict_params["index"]
    issuer = list(filter(None, issuers))[0]
    issuer_id = issuer.split("/")[1]

    set_ticket_status_as_traded(rfq_id)
    set_rfq_traded(issuer_id, rfq_id, ticket_id)

    return ticket_id


@app.callback(
    Output("rfq-deleted-ticket", "data"),
    Input({"type": "rfq-button-delete-ticket", "index": ALL}, "n_clicks"),
    prevent_initial_call=True,
)
def selected_rfq_delete(values):
    if not any(values):
        return None

    ctx = callback_context
    triggered = ctx.triggered[0]["prop_id"].split(".")[0]
    dict_params = ast.literal_eval(triggered)

    ticket_id = dict_params["index"]
    details = get_details_from_id(ticket_id)

    if details["is_traded"][0]:
        delete_rfq_traded(ticket_id)

    delete_rfq_ticket(ticket_id)
    delete_sent_to_from_rfq_id(ticket_id)

    return details["id_ticket"][0]


@app.callback(
    Output("rfq-update-id", "children"),
    Output("rfq-button-update-ticket", "children"),
    Input({"type": "rfq-button-update-id", "index": ALL}, "n_clicks"),
    Input("rfq-seleted-table", "data"),
    prevent_initial_call=True,
)
def seleted_rfq_update(values, selected_ticket):
    ctx = callback_context
    triggered = ctx.triggered[0]["prop_id"].split(".")[0]

    if not any(values) or (
        triggered == "rfq-seleted-table" and selected_ticket == None
    ):
        return None, "Update"

    dict_params = ast.literal_eval(triggered)
    ticket_id = dict_params["index"]

    return ticket_id, f"Update Selection"


@app.callback(
    Output({"type": "rfq-modal-traded-with-list", "index": MATCH}, "is_open"),
    Input({"type": "rfq-button-modify-ticket", "index": MATCH}, "n_clicks"),
    Input({"type": "rfq-button-traded-with-list", "index": MATCH}, "n_clicks"),
    State({"type": "rfq-modal-traded-with-list", "index": MATCH}, "is_open"),
)
def toggle_modal(n1, n2, is_open):

    if not any([n1, n2]):
        raise PreventUpdate

    if n1 or n2:
        return not is_open
    return is_open


def issuers_list_options():

    issuers = all_issuers_codes_and_names()
    df = pd.DataFrame(issuers)

    return [
        {"label": x[0], "value": f"{x[0]}/{x[1]}"}
        for x in zip(df.short_name, df.code_exane)
    ]


@app.callback(
    Output("rfq-untraded-ticket", "data"),
    Input({"type": "rfq-button-delete-traded-ticket", "index": ALL}, "n_clicks"),
    prevent_initial_call=True,
)
def set_untraded_ticket(values):

    ctx = callback_context
    triggered = ctx.triggered[0]["prop_id"].split(".")[0]

    if not any(values):
        raise PreventUpdate

    dict_params = ast.literal_eval(triggered)
    ticket_id = dict_params["index"]

    delete_rfq_traded(ticket_id)
    set_ticket_status_as_untraded(ticket_id)

    return ticket_id

import dash_bootstrap_components as dbc
from dash import dcc
from dash import html
from dash.dash_table import DataTable
import dash.dash_table.Format as Format
import dash.dash_table.FormatTemplate as FormatTemplate
import pandas as pd
from dash.dependencies import Input, Output, State

from app import app, server
from models.storing import cached_opinions_stocks
from utils.sql import implied_vol_live


def serve_layout():
    dcc.Location(id={"type": "url", "page": "stocks"}, refresh=True),

    # Prepare SQL requests to get Stocks' Opinions
    df = cached_opinions_stocks()

    # Set list of options: Companies, Sector or Opinions
    options = [
        {"label": f"{x[0]} - {x[1]}", "value": x[0]}
        for x in zip(df.Name.values, df.Ticker)
    ]
    options.extend(
        [{"label": f"Sector: {x}", "value": x} for x in list(df.Sector.unique())]
    )
    options.extend(
        [{"label": f"Opinion: {x}", "value": x} for x in list(df.Opinion.unique())]
    )

    body = dbc.Container(
        [
            dbc.Row(  # Search bar
                [
                    dbc.Col(
                        [
                            html.P(
                                "Select Companies or Sectors",
                                className="control_label",
                            ),
                            dcc.Dropdown(
                                id="dd_companies",
                                options=options,
                                multi=True,
                                value=[],
                                className="dcc_control",
                            ),
                        ]
                    ),
                ],
                style={"padding": "15px 10px"},
                justify="left",
            ),
            dbc.Row(
                [
                    dbc.Col(
                        [
                            html.Div(
                                children=[
                                    DataTable(
                                        id="table-stocks",
                                        columns=[],
                                        data=df.to_dict("records"),
                                        style_cell={
                                            "overflow": "hidden",
                                            "textOverflow": "ellipsis",
                                            "fontFamily": "Roboto",
                                            "backgroundColor": "transparent",
                                            "font-size": "small",
                                            "text-align": "left",
                                            "border-top": "1px solid rgb(236, 240, 241)",
                                            "border-bottom": "1px solid rgb(236, 240, 241)",
                                            "border-right": " 0px",
                                            "border-left": "0px",
                                        },
                                        style_as_list_view=True,
                                        style_data_conditional=[
                                            {
                                                "if": {"row_index": "odd"},
                                                "backgroundColor": "rgb(248, 248, 248)",
                                            },
                                            {
                                                "if": {
                                                    "column_id": "Opinion",
                                                    "filter_query": '{Opinion} eq "Outperform"',
                                                },
                                                "color": "#16a085",
                                            },
                                            {
                                                "if": {
                                                    "column_id": "Opinion",
                                                    "filter_query": '{Opinion} eq "Underperform"',
                                                },
                                                "color": "#e74c3c",
                                            },
                                            {
                                                "if": {
                                                    "column_id": "Opinion",
                                                    "filter_query": '{Opinion} eq "Neutral"',
                                                },
                                                "color": "#f39c12",
                                            },
                                            {
                                                "if": {
                                                    "column_id": "Opinion",
                                                    "filter_query": '{Opinion} eq "Outperform"',
                                                },
                                                "color": "#16a085",
                                            },
                                            {
                                                "if": {
                                                    "column_id": "Opinion Sector",
                                                    "filter_query": '{Opinion Sector} eq "Outperform"',
                                                },
                                                "color": "#16a085",
                                            },
                                            {
                                                "if": {
                                                    "column_id": "Opinion Sector",
                                                    "filter_query": '{Opinion Sector} eq "Underperform"',
                                                },
                                                "color": "#e74c3c",
                                            },
                                            {
                                                "if": {
                                                    "column_id": "Opinion Sector",
                                                    "filter_query": '{Opinion Sector} eq "Neutral"',
                                                },
                                                "color": "#f39c12",
                                            },
                                            {
                                                "if": {
                                                    "column_id": "Performance",
                                                    "filter_query": "{Performance} > 0",
                                                },
                                                "color": "#16a085",
                                            },
                                            {
                                                "if": {
                                                    "column_id": "Performance",
                                                    "filter_query": "{Performance} < 0",
                                                },
                                                "color": "#e74c3c",
                                            },
                                        ],
                                        style_header={
                                            "backgroundColor": "white",
                                            "fontWeight": "bold",
                                        },
                                        sort_action="native",
                                        filter_action="native",
                                        export_format="csv",
                                        export_headers="display",
                                        # css=[
                                        #     {
                                        #         "selector": ".row",
                                        #         "rule": "margin: 0; display: block",
                                        #     }
                                        # ],
                                    )
                                ],
                                id="table-wrapper",
                            )
                        ],
                    ),
                ]
            ),
            html.Div(
                children=df.to_json(date_format="iso", orient="split"),
                id="all_data",
                style={"display": "none"},
            ),
            html.Div(
                children=df.to_json(date_format="iso", orient="split"),
                id="filtered_data",
                style={"display": "none"},
            ),
            # html.Div(id="filtered_data", style={"display": "none"}),
        ],
        className="mt-4 w-75 borded-card",
        fluid=True,
        # style={"backgroundColor": "white"},
    )

    return [body]


@app.callback(
    Output("filtered_data", "children"),
    # Output("loading-filter-stocks", "children"),
    Input("dd_companies", "value"),
    State("all_data", "children"),
)
def filter_data(selection, data):
    if not selection:
        return data

    df = pd.read_json(data, orient="split")

    # Filter the companies
    dff = df[
        df.Name.isin(selection)
        | df.Ticker.isin(selection)
        | df.Sector.isin(selection)
        | df.Opinion.isin(selection)
    ]

    df_vol = implied_vol_live(cfins=list(dff.Cfin), nb_days=180, fields="vatm")
    try:
        dff = pd.merge(dff, df_vol, on="Cfin", how="outer")
    except Exception as e:
        print(f"Error: {e}")

    return dff.to_json(date_format="iso", orient="split")


@app.callback(
    Output("table-stocks", "data"),
    Output("table-stocks", "columns"),
    # Output("loading-display-stocks", "children"),
    Input("filtered_data", "children"),
)
def output_data(data):
    dff = pd.read_json(data, orient="split")

    # Drop duplicate values
    dff = dff.drop_duplicates(subset="Cfin", keep="first")

    # Convert Covered Since to dates
    dff["Covered Since"] = (
        dff["Covered Since"].apply(pd.to_datetime, errors="coerce").dt.date
    )

    # Round numeric values
    dff[["Last", "12m Target", "MCap EURm", "Next Div Yield"]] = dff[
        ["Last", "12m Target", "MCap EURm", "Next Div Yield"]
    ].round(2)

    if "Implied Vol" in dff.columns:
        dff["Implied Vol"] = dff["Implied Vol"].round(2)

    # Format Columns
    columns = [{"name": i, "id": i} for i in dff.columns]
    d = {
        "Performance": {
            "type": "numeric",
            "format": FormatTemplate.percentage(1).sign(Format.Sign.positive),
        },
        "MCap EURm": {"type": "numeric", "format": Format.Format(group=",")},
    }

    columns = [{**c, **d.get(c["name"], {})} for c in columns]

    return dff.to_dict("records"), columns


if __name__ == "__main__":
    with server.app_context():
        app.layout = html.Div(serve_layout())
        app.run_server(debug=True)

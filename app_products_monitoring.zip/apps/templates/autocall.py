import dash.dash_table.FormatTemplate as FormatTemplate
from dash.dependencies import Input, Output, State

from utils.components import *
from utils.graphs import *
from utils.osiris import *
from .templates import *
import utils.osiris as osiris
from flask_login import current_user


def no_display_if_none(d, field):
    return {"display": "none"} if not d.get(field) else {}


def serve_layout_autocall():

    return dbc.Row(
        [
            dbc.Col(
                [
                    dbc.Row(
                        [
                            dbc.Col(
                                html.Div(
                                    id="autocall-details",
                                    className="borded-card m-1 p-4 w-100",
                                ),
                                width=4,
                                className="px-0",
                                style={"display": "flex", "align-items": "stretch",},
                            ),
                            dbc.Col(
                                html.Div(
                                    id="autocall-calendar",
                                    className="borded-card m-1 p-4",
                                ),
                                width=8,
                                className="px-0",
                            ),
                        ],
                        justify="between",
                    ),
                    dbc.Row(
                        dbc.Col(
                            html.Div(
                                id="autocall-underlyings-details",
                                className="borded-card m-1 p-4",
                            ),
                            width=12,
                            className="px-0",
                        ),
                    ),
                ],
                width=6,
            ),
            dbc.Col(
                html.Div(
                    [card_title("Performances"), pre_graph_structured_product],
                    className="borded-card m-1 p-4 w-100",
                ),
                width=6,
                className="px-0",
                id="autocall-graph-card",
                style={"display": "flex", "align-items": "stretch",},
            ),
            html.Div(id="autocall-page-trigger", style={"display": "none"}),
        ],
        className="mt-1",
    )


@app.callback(
    Output("autocall-details", "children"),
    Input("autocall-page-trigger", "children"),
    State("data-api", "data"),
)
def check_autocall_details(t, details):

    data = details["content"][0]
    details = osiris.structured_product_details_from_osiris_data(data)

    return [
        card_title("Details"),
        dbc.Table(
            [
                html.Tbody(
                    [
                        html.Tr(
                            [
                                html.Td(
                                    x[0],
                                    className="p-0 pb-1",
                                    style={
                                        "fontFamily": "Roboto-Bold",
                                        "fontSize": "0.80rem",
                                        "lineHeight": "1.05rem",
                                        "color": "rgba(0, 0, 0, 0.87)",
                                    },
                                ),
                                html.Td(
                                    x[1],
                                    className="p-0 pb-1",
                                    style={
                                        "textAlign": "right",
                                        "fontSize": "0.80rem",
                                    },
                                ),
                            ]
                        )
                        for x in details[1:]
                    ]
                )
            ],
            borderless=True,
            className="mb-0",
        ),
    ]


@app.callback(
    Output("autocall-calendar", "children"),
    Input("autocall-page-trigger", "children"),
    State("data-api", "data"),
)
def check_autocall_calendar(t, details):

    d = details["content"][0]
    df = display_calendar(d)

    if "Trading" not in current_user.department:
        df = df.drop(columns="Ex")

    # Find next Observation Date to highlight it
    fixing_dates = list(pd.to_datetime(df.Fixing, format="%b %d, %Y"))
    today = pd.to_datetime(dt.today().date())
    next_obs_dates = [d for d in fixing_dates if d >= today]
    if next_obs_dates:
        next_cpn_date = min([d for d in fixing_dates if d >= today])
        next_cpn_date = next_cpn_date.strftime("%b %d, %Y")
    else:
        next_cpn_date = fixing_dates[-1]
        next_cpn_date = next_cpn_date.strftime("%b %d, %Y")

    style_data = {
        "width": "15px",
        "maxWidth": "180px",
        "minWidth": "0px",
    }

    style_table = {
        "maxHeight": "170px",
        "overflowY": "auto",
    }

    style_data_conditional = [
        {
            "if": {"filter_query": '{{Fixing}} = "{}"'.format(next_cpn_date),},
            "backgroundColor": " rgba(53, 146, 162, 0.05)",
        },
    ]

    table = data_table(
        df,
        id="home-table-coupons",
        style_data=style_data,
        style_table=style_table,
        style_data_conditional=style_data_conditional,
        fixed_rows={"headers": True},
    )

    return [card_title("Calendar"), table]


@app.callback(
    Output("autocall-underlyings-details", "children"),
    Input("autocall-page-trigger", "children"),
    State("data-api", "data"),
)
def check_autocall_underlyings_details(t, details):

    d = details["content"][0]
    df = autocall_underlyings_details(d)

    # Formating columns
    dic_cln = {
        "ticker": "Ticker",
        "name": "Name",
        "ccy": "Ccy",
        "last": "Last",
        "strike": "Strike",
        "perf": "Perf",
        "opinion": "BNPP",
        "upside": "Upside",
        "autocallBarrier": "Bar Atk",
        "autocallDist": "Dist Atk",
        "couponBarrier": "Bar Cpn",
        "couponDist": "Dist Cpn",
        "capitalBarrier": "Bar Cap",
        "capitalDist": "Dist Cap",
    }
    percentage_col = [
        "Perf",
        "Dist Atk",
        "Bar Atk",
        "Dist Cpn",
        "Bar Cpn",
        "Dist Cap",
        "Bar Cap",
        "Upside",
    ]
    d = {
        x: {"type": "numeric", "format": FormatTemplate.percentage(2)}
        for x in percentage_col
    }
    columns = [{"name": dic_cln[i], "id": i} for i in df.columns]
    columns = [{**c, **d.get(c["name"], {})} for c in columns]

    style_data_conditional = [
        {
            "if": {"column_id": "perf", "filter_query": "{perf} >= 0",},
            "color": "green",
        },
        {
            "if": {"column_id": "perf", "filter_query": "{perf} < 0",},
            "color": "tomato",
        },
        {
            "if": {"column_id": "upside", "filter_query": "{upside} >= 0",},
            "color": "green",
        },
        {
            "if": {"column_id": "upside", "filter_query": "{upside} < 0",},
            "color": "tomato",
        },
        {
            "if": {"column_id": "autocallDist", "filter_query": "{autocallDist} >= 0",},
            "color": "green",
        },
        {
            "if": {"column_id": "autocallDist", "filter_query": "{autocallDist} < 0",},
            "color": "tomato",
        },
        {
            "if": {"column_id": "couponDist", "filter_query": "{couponDist} >= 0",},
            "color": "green",
        },
        {
            "if": {"column_id": "couponDist", "filter_query": "{couponDist} < 0",},
            "color": "tomato",
        },
        {
            "if": {"column_id": "capitalDist", "filter_query": "{capitalDist} >= 0",},
            "color": "green",
        },
        {
            "if": {"column_id": "capitalDist", "filter_query": "{capitalDist} < 0",},
            "color": "tomato",
        },
    ]

    style_data = {
        "width": "15px",
        "maxWidth": "180px",
        "minWidth": "0px",
        "paddingTop": "15px",
        "paddingBottom": "15px",
    }

    table = data_table(
        df,
        columns=columns,
        style_data_conditional=style_data_conditional,
        style_data=style_data,
    )

    return [card_title("Underlyings"), table]


@app.callback(
    Output("autocall-graph-perf", "figure"),
    Output("autocall-graph-card", "classname"),
    Input("autocall-page-trigger", "children"),
    State("data-api", "data"),
    State("autocall-graph-perf", "figure"),
)
@cache.memoize(timeout=86400)
def check_autocall_graph_perf(t, data_api, figure):

    data = data_api["content"][0]
    figure["data"] = data_graph_structured_product(data)

    if figure:
        return figure, "px-0"

    return None, "d-none"

from dash import dcc
from dash.dependencies import Input, Output, State, MATCH
from dash.exceptions import PreventUpdate
import dash_extensions as de
from flask_login import current_user
from app import cache
from utils.components import *
from utils.api_open_positions import OpenPositions
from utils.osiris import *
import utils.sql as sql
from utils.graphs import basis_graph_structured_product


# @cache.cached(timeout=0, key_prefix="one_year_trades")
def yearly_trades(year):
    return sql.trades(dt(year, 12, 1), dt(year, 12, 31))


def layout_dashboard():

    row_title = dbc.Row([dbc.Col(html.H2("External Report - 2021"))])

    df = yearly_trades(2021)

    nominal_traded = (df.size_traded / df.change).sum()
    cash_traded = (df.cash_traded / df.change).sum()

    counterparts = set(
        [item for sublist in df.issuer.unique() for item in sublist.split(", OTC ")]
    )
    counterparts = set([sql.issuers_short_names.get(x, x) for x in counterparts])
    counterparts = [x for x in counterparts if "Exane" not in x]

    key_figures = {
        "Nb Trades": df[df.quantity != 0].trade_date.count(),
        "Nominal Traded": nominal_traded,
        "Cash Traded": cash_traded,
        "Generated": df.margin.sum(),
        "Counterparts": len(counterparts),
    }

    row_key_figures = dbc.Row(
        [
            dbc.Col(
                className="borded-card p-3 m-2",
            )
        ]
    )

    row_graphs = dbc.Row(
        [dbc.Col([dbc.Row([dbc.Col(), dbc.Col()]), dbc.Row([dbc.Col(), dbc.Col()])])]
    )

    container = dbc.Container([row_title, row_key_figures, row_graphs])

    return container

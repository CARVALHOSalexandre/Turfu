import dash.dash_table.FormatTemplate as FormatTemplate
from dash.dependencies import Input, Output, State
from dash.exceptions import PreventUpdate

from utils.components import *
from utils.graphs import *
from utils.osiris import *
from utils.components import card_title, card_subtitle
from .templates import *


def no_display_if_none(d, field):
    return {"display": "none"} if not d.get(field) else {}


def serve_layout_minifut():

    return [
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Row(
                            dbc.Col(
                                html.Div(
                                    id="minifut-details",
                                    className="borded-card p-4 m-1",
                                ),
                                className="px-0",
                            )
                        ),
                        html.Div(id="minifut-rolls", className="row pr-2"),
                        dbc.Row(
                            dbc.Col(
                                html.Div(
                                    id="minifut-underlyings-details",
                                    className="borded-card p-4 m-1",
                                ),
                                className="px-0",
                            ),
                        ),
                    ],
                    width=6,
                ),
                dbc.Col(
                    html.Div(
                        id="minifut-graph-perf",
                        className="borded-card p-4 m-1 w-100 h-100",
                    ),
                    width=6,
                    className="px-0",
                    style={
                        "display": "flex",
                        "align-items": "stretch",
                    },
                ),
            ],
            className="mt-1",
        ),
        html.Div(id="minifut-page-trigger", style={"display": "none"}),
    ]


@app.callback(
    Output("minifut-details", "children"),
    Input("minifut-page-trigger", "children"),
    State("data-api", "data"),
)
def check_minifut_details(t, details):

    data = details["content"][0]
    tbl = display_minifut_details(data)

    data = dbc.Row(
        [
            dbc.Col(
                [
                    html.Dl(
                        [
                            html.Dt(
                                "Initial Leverage",
                                className="col-sm-8 pr-0",
                                style=no_display_if_none(tbl, "initial_leverage"),
                            ),
                            html.Dd(
                                f"x{tbl.get('initial_leverage'):,.2f}"
                                if tbl.get("initial_leverage") is not None
                                else "",
                                className="col-sm-4 pr-1 pl-1",
                                style=no_display_if_none(tbl, "initial_leverage"),
                            ),
                        ],
                        className="row mb-0",
                    ),
                ]
            ),
            dbc.Col(
                [
                    html.Dl(
                        [
                            html.Dt(
                                html.P(
                                    "Current Leverage",
                                ),
                                className="col-sm-8 pr-0",
                                style=no_display_if_none(tbl, "current_leverage"),
                            ),
                            html.Dd(
                                html.P(
                                    "x" + str(round(tbl.get("current_leverage"), 2))
                                    if tbl.get("current_leverage") is not None
                                    else "",
                                    id="minifut-current-leverage-label",
                                    style={"width": "50px"},
                                ),
                                className="col-sm-4 pr-1 pl-1",
                                style=no_display_if_none(tbl, "current_leverage"),
                            ),
                        ],
                        className="row mb-0",
                    ),
                    dbc.Tooltip(
                        [
                            dbc.Row(
                                [
                                    dbc.Col(
                                        [
                                            html.P(
                                                "Last / (Last - Strike)"
                                                if data.get("type") == "BULL"
                                                else "Last / (Strike - Last)",
                                                className="m-0",
                                            )
                                        ]
                                    )
                                ],
                                className="p-2",
                            )
                        ],
                        target="minifut-current-leverage-label",
                        style={"width": "500px"},
                        placement="bottom",
                    ),
                ]
            ),
        ]
    )

    return [card_title("Details"), data]


@app.callback(
    Output("minifut-rolls", "children"),
    Input("minifut-page-trigger", "children"),
    State("data-api", "data"),
)
def check_minifut_rolls(t, details):

    data = details["content"][0]
    df = display_rolls(data)

    if df.empty:
        return ""

    table = data_table(
        df,
        id="home-table-coupons",
        style_table={
            "maxHeight": "150px",
            "overflowY": "auto",
        },
    )

    return dbc.Row(
        dbc.Col(
            [card_title("Roll"), table],
            className="px-0",
        ),
        className="borded-card p-4 m-1",
    )


@app.callback(
    Output("minifut-underlyings-details", "children"),
    Input("minifut-page-trigger", "children"),
    State("data-api", "data"),
)
def check_minifut_underlyings_details(t, details):

    d = details["content"][0]
    df = display_minifut_underlyings_details(d)

    # Formating columns
    dic_cln = {
        "ticker": "Ticker",
        "name": "Name",
        "ccy": "Ccy",
        "last": "Last",
        "strike": "Strike",
        "perf": "Perf",
        "opinion": "BNPP",
        "upside": "Upside",
        "spot": "Spot",
        "stop_loss": "Stop Loss",
        "stop_loss_dist": "Stop Loss Dist",
    }
    percentage_col = [
        "Perf",
        "Upside",
        "Stop Loss Dist",
    ]
    d = {
        x: {"type": "numeric", "format": FormatTemplate.percentage(2)}
        for x in percentage_col
    }
    columns = [{"name": dic_cln[i], "id": i} for i in df.columns]
    columns = [{**c, **d.get(c["name"], {})} for c in columns]

    style_data_conditional = [
        {
            "if": {
                "column_id": "perf",
                "filter_query": "{perf} >= 0",
            },
            "color": "green",
        },
        {
            "if": {
                "column_id": "perf",
                "filter_query": "{perf} < 0",
            },
            "color": "tomato",
        },
        {
            "if": {
                "column_id": "upside",
                "filter_query": "{upside} >= 0",
            },
            "color": "green",
        },
        {
            "if": {
                "column_id": "upside",
                "filter_query": "{upside} < 0",
            },
            "color": "tomato",
        },
        {
            "if": {
                "column_id": "stop_loss_dist",
                "filter_query": "{stop_loss_dist} >= 0",
            },
            "color": "green",
        },
        {
            "if": {
                "column_id": "stop_loss_dist",
                "filter_query": "{stop_loss_dist} < 0",
            },
            "color": "tomato",
        },
    ]

    table = data_table(
        df,
        columns=columns,
        style_data_conditional=style_data_conditional,
        style_data={
            "maxHeight": "150px",
            "overflowY": "auto",
        },
    )

    return [card_title("Underlyings"), table]


@app.callback(
    Output("minifut-graph-perf", "children"),
    Input("minifut-page-trigger", "children"),
    State("data-api", "data"),
)
def check_minifut_graph_perf(t, details):

    data = details["content"][0]
    graph = graph_minifut(data)

    if graph is not None:
        return [card_title("Performances"), graph]

    return ""

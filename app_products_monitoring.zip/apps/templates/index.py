import pandas as pd
from dash.dash_table import DataTable
from dash.dash_table.Format import Format, Scheme
import dash.dash_table.FormatTemplate as FormatTemplate
from dash.dependencies import Input, Output, State
from utils.components import *
import utils.sql as sql
import dash_extensions as de
from dash import dcc
from dash.exceptions import PreventUpdate

from utils.basics import dt_today
from urllib.parse import parse_qs
from dash_extensions.snippets import send_data_frame
import plotly.graph_objects as go


def serve_layout_index(cfin):

    result = sql.index_and_composition_full_for_cfin(cfin)

    if result:

        df = result["data"]

        if not df.empty:

            df = df.drop(columns=["Date"])

            percentage = FormatTemplate.percentage(2)

            columns_with_types = {
                "Name": {
                    "name": "Name",
                    "id": "Name",
                    "type": "text",
                },
                "Weight": {
                    "name": "Weight",
                    "id": "Weight",
                    "type": "numeric",
                    "format": percentage,
                },
                "Quantity": {
                    "name": "Quantity",
                    "id": "Quantity",
                    "type": "numeric",
                    "format": Format(precision=3, scheme=Scheme.fixed),
                },
                "Close at Entry": {
                    "name": "Close at Entry",
                    "id": "Close at Entry",
                    "type": "numeric",
                    "format": Format(precision=2, scheme=Scheme.fixed),
                },
                "Close": {
                    "name": "Close",
                    "id": "Close",
                    "type": "numeric",
                    "format": Format(precision=2, scheme=Scheme.fixed),
                },
                "Perf since Entry": {
                    "name": "Perf since Entry",
                    "id": "Perf since Entry",
                    "type": "numeric",
                    "format": percentage,
                    "hideable": True,
                },
                "Perf 1 Month": {
                    "name": "Perf 1 Month",
                    "id": "Perf 1 Month",
                    "type": "numeric",
                    "format": percentage,
                    "hideable": True,
                },
                "Perf YTD": {
                    "name": "Perf YTD",
                    "id": "Perf YTD",
                    "type": "numeric",
                    "format": percentage,
                    "hideable": True,
                },
            }

            columns = [
                columns_with_types.get(x, {"name": x, "id": x}) for x in df.columns
            ]

            tab_style_cell_conditional = [
                {"if": {"column_id": "Entry Date"}, "width": "75px"},
                {
                    "if": {"column_id": "Cfin"},
                    "width": "75px",
                    "marginLeft": "15px",
                },
                {"if": {"column_id": "Ticker"}, "maxWidth": "100px"},
                {
                    "if": {"column_id": "Name"},
                    "maxWidth": "200px",
                    "textAlign": "left",
                },
                {"if": {"column_id": "Type"}, "textAlign": "left"},
                {"if": {"column_id": "Sector"}, "textAlign": "left"},
                {"if": {"column_id": "Country"}, "textAlign": "left"},
                {"if": {"column_id": "Ccy"}, "textAlign": "left"},
                {
                    "if": {"state": "active"},  # 'active' | 'selected'
                    "backgroundColor": "transparent",
                    "border": "none",
                    "color": "rgb(44, 62, 80)",
                    "border-top": "1px solid rgb(236, 240, 241)",
                    "border-bottom": "1px solid rgb(236, 240, 241)",
                },
                {
                    "if": {"state": "selected"},
                    "backgroundColor": "transparent",
                    "border-top": "1px solid rgb(236, 240, 241)",
                    "border-bottom": "1px solid rgb(236, 240, 241)",
                },
            ]

            table = DataTable(
                id="datatable-composition",
                columns=columns,
                hidden_columns=["Perf 1 Month", "Perf YTD"],
                data=df.to_dict(orient="records"),
                style_as_list_view=True,
                cell_selectable=True,
                row_deletable=True,
                editable=True,
                row_selectable="multi",
                filter_action="native",
                sort_action="native",
                style_header={
                    "backgroundColor": "white",
                    "fontWeight": "bold",
                    "text-align": "left",
                },
                style_cell={
                    "overflow": "hidden",
                    "textOverflow": "ellipsis",
                    "max-width": "250px",
                    "fontFamily": "Roboto",
                    "backgroundColor": "transparent",
                    "font-size": "small",
                    "border-top": "1px solid rgb(236, 240, 241)",
                    "border-bottom": "1px solid rgb(236, 240, 241)",
                    "border-right": " 0px",
                    "border-left": "0px",
                    "padding-left": "10px",
                    "padding-right": "10px",
                },
                style_cell_conditional=tab_style_cell_conditional,
            )

            return dbc.Row(
                dbc.Col(
                    [
                        dbc.Row(
                            [
                                dbc.Col(card_title("Composition"), width=6),
                                dbc.Col(
                                    [
                                        dbc.Row(
                                            [
                                                dbc.Col(
                                                    html.Div(
                                                        [
                                                            de.Lottie(
                                                                options=dict(
                                                                    loop=False,
                                                                    autoplay=False,
                                                                    rendererSettings=dict(
                                                                        preserveAspectRatio="xMidYMid slice"
                                                                    ),
                                                                ),
                                                                width="65%",
                                                                height="65%",
                                                                id="home-lottie-eye",
                                                                url="/lottie/script-eye.json",
                                                            )
                                                        ],
                                                        style={
                                                            "maxHeight": "38px",
                                                            "maxWidth": "38px",
                                                            "align": "center",
                                                        },
                                                        n_clicks=0,
                                                        id="home-button-composition-eye",
                                                    ),
                                                    width=1,
                                                ),
                                                dbc.Col(
                                                    html.Div(
                                                        [
                                                            html.A(
                                                                html.I(
                                                                    className="fas fa-download dark-grey",
                                                                    style={
                                                                        "fontSize": "1.2rem"
                                                                    },
                                                                ),
                                                                target="_blank",
                                                            ),
                                                        ],
                                                        n_clicks=0,
                                                        id="home-button-composition-download",
                                                    ),
                                                    width=1,
                                                ),
                                            ],
                                            justify="end",
                                            align="center",
                                        ),
                                        dbc.Tooltip(
                                            children="Display the Composition",
                                            target="home-button-composition-eye",
                                            # autohide=False,
                                            delay={"show": 250, "hide": 250},
                                            placement="bottom",
                                            class_name="p-2",
                                        ),
                                        dbc.Tooltip(
                                            children="Download the Composition",
                                            target="home-button-composition-download",
                                            # autohide=False,
                                            delay={"show": 250, "hide": 250},
                                            placement="bottom",
                                            class_name="p-2",
                                        ),
                                        de.Download(id="home-download-composition"),
                                    ],
                                    width=6,
                                ),
                            ]
                        ),
                        dbc.Row(
                            dbc.Col(
                                card_subtitle(
                                    f"{result['index']['cfin']} - {result['index']['name']}"
                                ),
                            )
                            if not result["is_index"]
                            else None
                        ),
                        dbc.Row(
                            dbc.Col(
                                html.P(
                                    f"{result['index']['email']}",
                                    style={
                                        "fontFamily": "Roboto-Bold",
                                        "textAlign": "left",
                                        "fontSize": "0.85rem",
                                        "lineHeight": "1rem",
                                        "color": "rgba(0, 0, 0, 0.54)",
                                    },
                                ),
                                className="mb-2",
                            )
                            if not result["is_index"]
                            else None
                        ),
                        dbc.Row(
                            [
                                dbc.Col(
                                    [
                                        dbc.Row(
                                            dbc.Col(
                                                [
                                                    html.Div(
                                                        html.Div(
                                                            table,
                                                            id="home-composition-content",
                                                            style={
                                                                "fontSize": "0.7rem",
                                                                "lineHeight": "1rem",
                                                                "maxHeight": "300px",
                                                                "maxWidth": "100%",
                                                            },
                                                            className="overflow-auto scrollable-div",
                                                        ),
                                                        className="p-2",
                                                    ),
                                                    dbc.Spinner(
                                                        html.Div(
                                                            id="composition-graphs-performance",
                                                        ),
                                                        type="grow",
                                                        color="primary",
                                                    ),
                                                    dbc.Spinner(
                                                        html.Div(
                                                            id="composition-graphs-breakdown",
                                                        ),
                                                        type="grow",
                                                        color="primary",
                                                    ),
                                                ],
                                            )
                                        ),
                                    ],
                                    width=12,
                                ),
                            ],
                        ),
                    ],
                    className="borded-card p-4 m-1",
                ),
            )


@app.callback(
    Output("composition-graphs-breakdown", "children"),
    Input("datatable-composition", "derived_virtual_data"),
    Input("datatable-composition", "derived_virtual_selected_rows"),
)
def breakdown_graphs(rows, derived_virtual_selected_rows):
    # When the table is first rendered, `derived_virtual_data` and
    # `derived_virtual_selected_rows` will be `None`. This is due to an
    # idiosyncrasy in Dash (unsupplied properties are always None and Dash
    # calls the dependent callbacks when the component is first rendered).
    # So, if `rows` is `None`, then the component was just rendered
    # and its value will be the same as the component's dataframe.
    # Instead of setting `None` in here, you could also set
    # `derived_virtual_data=df.to_rows('dict')` when you initialize
    # the component.
    if derived_virtual_selected_rows is None:
        derived_virtual_selected_rows = []

    if rows:

        colors = [
            "#007a88",
            "#007f8b",
            "#00858e",
            "#008a90",
            "#008f93",
            "#009494",
            "#009a96",
            "#089f97",
            "#424242",
            "#696969",
            "#929292",
            "#bdbdbd",
            "#ebebeb",
        ]

        # Prepare Pie Charts of Sectors and currencies exposures
        df = pd.DataFrame(rows)

        pie_charts = []
        for labels in ["Sector", "Ccy", "Country", "Type"]:
            dff = df[[labels, "Weight"]].groupby(labels).sum()

            # Filter on weights above 0.1%
            dff = dff[dff.Weight > 0.001]

            figure = go.Figure(
                data=[
                    go.Pie(
                        labels=list(dff.index),
                        values=list(dff.Weight),
                        hole=0.4,
                        marker={
                            "colors": colors,
                            "line": {"color": "#f5f5f7", "width": 1},
                        },
                    )
                ],
            )
            figure.update_layout(
                title={
                    "text": f"{labels.replace('Ccy', 'Currencies')} Breakdown",
                    "font": {"family": "Roboto-Bold", "color": "rgba(0, 0, 0, 0.54)"},
                    "y": 0.9,
                    "x": 0.5,
                    "xanchor": "center",
                    "yanchor": "top",
                },
                height=400,
                showlegend=False,
            )
            figure.update_traces(
                hoverinfo="label+percent",
                textinfo="label+percent",
            )
            pie_charts.append(
                dbc.Col(
                    dcc.Graph(
                        id=labels,
                        figure=figure,
                        config={
                            "displaylogo": False,
                            "displayModeBar": False,
                        },
                    ),
                    width=6,
                )
            )

        return dbc.Row(pie_charts)


@app.callback(
    Output("composition-graphs-performance", "children"),
    Input("datatable-composition", "derived_virtual_data"),
    Input("datatable-composition", "derived_virtual_selected_rows"),
)
def performances_graphs(rows, derived_virtual_selected_rows):
    # When the table is first rendered, `derived_virtual_data` and
    # `derived_virtual_selected_rows` will be `None`. This is due to an
    # idiosyncrasy in Dash (unsupplied properties are always None and Dash
    # calls the dependent callbacks when the component is first rendered).
    # So, if `rows` is `None`, then the component was just rendered
    # and its value will be the same as the component's dataframe.
    # Instead of setting `None` in here, you could also set
    # `derived_virtual_data=df.to_rows('dict')` when you initialize
    # the component.
    if derived_virtual_selected_rows is None:
        derived_virtual_selected_rows = []

    if rows:

        # Prepare Pie Charts of Sectors and currencies exposures
        dff = pd.DataFrame(rows)

        colors = [
            "#515151" if i in derived_virtual_selected_rows else "#00a6aa"
            for i in range(len(dff))
        ]

        return dbc.Row(
            [
                dbc.Col(
                    dcc.Graph(
                        id=column,
                        figure={
                            "data": [
                                {
                                    "x": [
                                        f"{x[:25]}..." if len(x) > 25 else x
                                        for x in dff.Name
                                    ],
                                    "y": dff[column],
                                    "type": "bar",
                                    "marker": {"color": colors},
                                }
                            ],
                            "layout": {
                                "xaxis": {
                                    "automargin": True,
                                    "tickfont": {
                                        "size": 11,
                                    },
                                    "tickangle": 45,
                                },
                                "yaxis": {
                                    "automargin": True,
                                    "title": {"text": column},
                                    "tickformat": ",.2%",
                                },
                                "height": 350,
                                "margin": {"t": 10, "l": 10, "r": 10},
                            },
                        },
                        config={
                            "displaylogo": False,
                            "displayModeBar": False,
                        },
                    ),
                    width=6,
                    className="p-4",
                )
                # check if column exists - user may have deleted it
                # If `column.deletable=False`, then you don't
                # need to do this check.
                for column in [
                    "Weight",
                    "Perf since Entry",
                    "Perf 1 Month",
                    "Perf YTD",
                ]
                if column in dff
            ]
        )


@app.callback(
    Output("home-composition-content", "style"),
    Input("home-button-composition-eye", "n_clicks"),
    State("home-composition-content", "style"),
)
def display_composition_button(n_clicks, style):
    if (n_clicks % 2) != 0:
        style.pop("maxHeight", None)
        return style
    style["maxHeight"] = "300px"
    return style


@app.callback(
    Output("home-download-composition", "data"),
    Input("home-button-composition-download", "n_clicks"),
    State("datatable-composition", "data"),
    State({"type": "url", "page": "home"}, "search"),
)
def download_script_button(n_clicks, data, search):
    if n_clicks and data:

        df = pd.DataFrame(data)

        if not df.empty:
            cfin = parse_qs(search[1:]).get("cfin")[0]
            today = dt_today("string_figures")
            filename = f"composition_{cfin}_{today}.xlsx"
            return send_data_frame(df.to_excel, filename)

    raise PreventUpdate


@app.callback(
    Output("datatable-composition", "data"),
    Input("datatable-composition", "data_timestamp"),
    State("datatable-composition", "data"),
)
def set_performance_since_entry(timestamp, rows):
    for row in rows:
        try:
            row["Perf since Entry"] = (
                float(row["Close"]) / float(row["Close at Entry"]) - 1.0
            )
        except:
            row["output-data"] = None
    return rows

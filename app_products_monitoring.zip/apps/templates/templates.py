import dash_bootstrap_components as dbc
from dash import html

from utils.sql import *


def display_margins(cfin):
    margin = margin_details(cfin, format="dict")

    data = [
        dbc.Row(
            [
                dbc.Col(
                    [
                        html.H6(
                            f"{x.get('amortized_bid', 'N/A')}% {x['type'].title()} over {date_range_to_string(x['start_date'], x['end_date'])}",
                            className="p-0 mt-1 mb-1",
                        ),
                        html.P(
                            f"{dt.strftime(x['start_date'], '%b %d, %y')} to {dt.strftime(x['end_date'], '%b %d, %y')}",
                            className="p-0 mb-1",
                        ),
                    ],
                    width=8,
                    className="pr-0",
                    style={"text-align": "left"},
                ),
                dbc.Col(
                    [
                        html.P(
                            f"Bid {x.get('start_level_bid_margin', 'N/A')} to {x.get('end_level_bid_margin', 'N/A')}",
                            className="mt-1 mb-1",
                        ),
                        html.P(
                            f"Ask {x.get('start_level_ask_margin', 'N/A')} to {x.get('end_level_ask_margin', 'N/A')}",
                            className="mb-1",
                        ),
                    ],
                    width=4,
                    className="pl-0",
                    style={"text-align": "right"},
                ),
            ],
            className="p-1",
        )
        for x in margin
    ]

    if not data:
        data = [
            dbc.Row(
                [
                    dbc.Col(
                        [
                            html.H6(
                                "No margin amortization", className="p-0 mt-1 mb-1"
                            ),
                        ],
                        className="pr-0",
                        style={"text-align": "center"},
                    ),
                ]
            )
        ]

    return data

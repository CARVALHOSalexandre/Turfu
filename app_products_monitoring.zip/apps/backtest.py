from app import app, db, cache
from dash import callback_context
from dash import dcc
from dash import html
import dash_bootstrap_components as dbc
import pandas as pd
from models.storing import cached_products_histo
from utils.basics import dt_today, prev_bday
from dash.dependencies import Input, Output, State, ALL, MATCH
from dash.exceptions import PreventUpdate
from datetime import datetime as dt
from utils.graphs import graph_backtest, pre_graph_backtest
from utils.sql import names_products
import json

colors_options = [
    {"label": "Theme Black-Gold - Black", "value": "#181510"},
    {"label": "Theme Black-Gold - Brown", "value": "#785F37"},
    {"label": "Theme Black-Gold - Glitter", "value": "#A08c5B"},
    {"label": "Theme Black-Gold - Sand", "value": "#CBB682"},
    {"label": "Theme Black-Gold - Vanilla", "value": "#E9DBBD"},
]

labels_barriers = {
    "atk_value": "Autocall Barrier",
    "cpn_value": "Coupon Barrier",
    "prot_value": "Protection Barrier",
}


def serve_layout():
    location = dcc.Location(id={"type": "url", "page": "graphs"}, refresh=False)
    body_to_be_sent = dbc.Container(
        [
            dbc.Row(  # Row of the title
                [
                    dbc.Col(
                        [
                            dbc.Row(dbc.Col([html.H1("Backtest")]), className="mb-2"),
                            dbc.Row(
                                dbc.Col(
                                    [
                                        dcc.DatePickerRange(
                                            id="graphs-datepicker",
                                            display_format="DD/MM/YYYY",
                                            min_date_allowed=dt(1990, 1, 1),
                                            max_date_allowed=prev_bday(1),
                                            start_date_placeholder_text="Start Period",
                                            end_date_placeholder_text="End Period",
                                            start_date=prev_bday(1).replace(
                                                year=prev_bday(1).year - 1
                                            ),
                                            end_date=prev_bday(1),
                                            first_day_of_week=1,
                                            # with_portal=True,
                                            style={"fontSize": "0.75rem"},
                                        )
                                    ]
                                ),
                                className="mb-3",
                            ),
                            dbc.Row(
                                dbc.Col([html.H3("Underlyings")]), className="mb-2"
                            ),
                            dbc.Row(
                                [
                                    dbc.Col(
                                        [
                                            dcc.Dropdown(
                                                id="graph-options",
                                                options=[],
                                                multi=True,
                                                value=[],
                                            )
                                        ],
                                        className="mb-2",
                                    ),
                                ]
                            ),
                            dbc.Row(
                                [
                                    dbc.Col(
                                        [
                                            dbc.CardHeader(
                                                dbc.Row(
                                                    [
                                                        dbc.Col(
                                                            [
                                                                html.H2(
                                                                    dbc.Button(
                                                                        "+",
                                                                        color="black",
                                                                        id=f"group-1-toggle",
                                                                    )
                                                                )
                                                            ],
                                                            width="auto",
                                                        ),
                                                        dbc.Col(
                                                            [html.H3("Barriers")],
                                                            align="center",
                                                        ),
                                                    ]
                                                )
                                            ),
                                            dbc.Collapse(
                                                dbc.CardBody(
                                                    [
                                                        dbc.Row(
                                                            [
                                                                dbc.Label(
                                                                    "Protection Barrier",
                                                                    html_for="protection-barrier-row",
                                                                    width=4,
                                                                ),
                                                                dbc.Col(
                                                                    dbc.Input(
                                                                        type="protection-barrier",
                                                                        id="protection-barrier-row",
                                                                        placeholder="Ex: 70",
                                                                        debounce=True,
                                                                    ),
                                                                    width=8,
                                                                ),
                                                            ],
                                                        ),
                                                        dbc.Row(
                                                            [
                                                                dbc.Label(
                                                                    "Coupon Barrier",
                                                                    html_for="coupon-barrier-row",
                                                                    width=4,
                                                                ),
                                                                dbc.Col(
                                                                    dbc.Input(
                                                                        type="coupon-barrier",
                                                                        id="coupon-barrier-row",
                                                                        placeholder="Ex: 70",
                                                                        debounce=True,
                                                                    ),
                                                                    width=8,
                                                                ),
                                                            ],
                                                        ),
                                                        dbc.Row(
                                                            [
                                                                dbc.Label(
                                                                    "Autocall Barrier",
                                                                    html_for="autocall-barrier-row",
                                                                    width=4,
                                                                ),
                                                                dbc.Col(
                                                                    dbc.Input(
                                                                        type="autocall-barrier",
                                                                        id="autocall-barrier-row",
                                                                        placeholder="Ex: 100",
                                                                        debounce=True,
                                                                    ),
                                                                    width=8,
                                                                ),
                                                            ],
                                                        ),
                                                    ]
                                                ),
                                                id=f"collapse-1",
                                            ),
                                        ]
                                    )
                                ],
                                className="mb-3",
                            ),
                            dbc.Row(
                                [
                                    dbc.Col(
                                        [
                                            dbc.CardHeader(
                                                dbc.Row(
                                                    [
                                                        dbc.Col(
                                                            [
                                                                html.H2(
                                                                    dbc.Button(
                                                                        "+",
                                                                        color="black",
                                                                        id=f"group-2-toggle",
                                                                    )
                                                                )
                                                            ],
                                                            width="auto",
                                                        ),
                                                        dbc.Col(
                                                            [html.H3("Colors")],
                                                            align="center",
                                                        ),
                                                    ]
                                                )
                                            ),
                                            dbc.Collapse(
                                                dbc.CardBody(
                                                    [html.Div(id="color-pickers")]
                                                ),
                                                id=f"collapse-2",
                                            ),
                                        ]
                                    )
                                ]
                            ),
                        ],
                        width=6,
                    ),
                    dbc.Col(
                        [
                            dbc.Row(
                                dbc.Col(
                                    [
                                        html.Div(
                                            [pre_graph_backtest], id="graph-backtest"
                                        ),
                                    ]
                                ),
                                className="mb-3",
                            ),
                            # dbc.Row(
                            #     dbc.Col(
                            #         [
                            #             html.Div(
                            #                 [
                            #                     html.A(
                            #                         html.I(
                            #                             className="fas fa-download dark-grey",
                            #                             style={"fontSize": "1.2rem"},
                            #                         ),
                            #                         target="_blank",
                            #                     ),
                            #                 ],
                            #                 n_clicks=0,
                            #                 id="graph-button-download",
                            #             ),
                            #             de.Download(id="graph-download"),
                            #         ]
                            #     ),
                            #     className="mb-3",
                            # ),
                        ],
                        align="center",
                        width=6,
                    ),
                ],
                className="mb-4",
            ),
        ],
        style={"maxWidth": "80%"},
        className="borded-card p-5 mt-3 mb-5 container-fluid",
    )

    return location, body_to_be_sent


@app.callback(
    Output("graph-options", "options"),
    Input({"type": "url", "page": "graphs"}, "href"),
    Input("graph-options", "search_value"),
    State("graph-options", "value"),
    # State("graph-options", "options"),
)
@cache.memoize(timeout=86400)
def load_options_and_columns(href, search_value, value):
    # if options:
    if not search_value:
        raise PreventUpdate

    df = pd.DataFrame(cached_products_histo())
    df.Cfin = df.Cfin.apply(str)

    # Options for the dropdown
    options = [
        {"label": f"{x[0]} - {x[1]} - {x[2]} - {x[3]}", "value": x[0]}
        for x in zip(df.Cfin, df.Isin, df.Ticker, df.Name)
    ]

    filtered_options = [
        o
        for o in options
        if search_value.upper() in o["label"].upper() or o["value"] in (value or [])
    ]

    return filtered_options


@app.callback(
    Output("graph-backtest", "children"),
    Input("graph-options", "value"),
    Input("graphs-datepicker", "start_date"),
    Input("graphs-datepicker", "end_date"),
    Input({"type": "color_items", "index": ALL}, "value"),
    State({"type": "color_items", "index": ALL}, "id"),
    State("autocall-barrier-row", "value"),
    State("coupon-barrier-row", "value"),
    State("protection-barrier-row", "value"),
)
def graph_histo(
    cfins,
    start_date,
    end_date,
    colors,
    cfins_colors,
    atk_value,
    cpn_value,
    prot_value,
):

    if not cfins:
        raise PreventUpdate

    list_cfins_colors = [x["index"] for x in cfins_colors]

    data_colors = {
        list_cfins_colors[i]: colors[i] for i in range(len(list_cfins_colors))
    }

    data_barriers = {
        "atk_value": atk_value,
        "cpn_value": cpn_value,
        "prot_value": prot_value,
    }

    s_date = dt.strptime(start_date, "%Y-%m-%d")
    e_date = dt.strptime(end_date, "%Y-%m-%d")

    fig = graph_backtest(cfins, s_date, e_date, data_colors, data_barriers)

    return [fig]


@app.callback(
    Output("color-pickers", "children"),
    Input("graph-options", "value"),
    Input("autocall-barrier-row", "value"),
    Input("coupon-barrier-row", "value"),
    Input("protection-barrier-row", "value"),
    Input({"type": "color_items", "index": ALL}, "value"),
    State({"type": "color_items", "index": ALL}, "id"),
)
def color_pickers(cfins, atk_value, cpn_value, prot_value, colors, cfins_colors):

    if not cfins:
        raise PreventUpdate

    list_cfins_colors = [x["index"] for x in cfins_colors]

    data_colors = {
        list_cfins_colors[i]: colors[i] for i in range(len(list_cfins_colors))
    }

    body = []
    names = names_products(cfins)

    # Check which input triggered the callback
    ctx = callback_context
    triggered = ctx.triggered[0]["prop_id"].split(".")[0]

    data_barriers = {
        "atk_value": atk_value,
        "cpn_value": cpn_value,
        "prot_value": prot_value,
    }

    ### Generate the color pickers part ###

    # Add the lines for the cfins that already had a color
    if data_colors:
        for x in data_colors:
            if x in cfins:
                body.append(
                    dbc.Row(
                        [
                            dbc.Label(
                                names[int(x)],
                                html_for=f"color_item_{x}",
                                width=4,
                            ),
                            dbc.Col(
                                dcc.Dropdown(
                                    id={"type": "color_items", "index": x},
                                    options=colors_options,
                                    multi=False,
                                    value=data_colors[x],
                                ),
                                width=8,
                            ),
                        ],
                        id=x,
                    )
                )

    # Add the lines for the cfins with no colors
    for x in cfins:
        if x not in data_colors:
            body.append(
                dbc.Row(
                    [
                        dbc.Label(
                            names[int(x)],
                            html_for=f"color_item_{x}",
                            width=4,
                        ),
                        dbc.Col(
                            dcc.Dropdown(
                                id={"type": "color_items", "index": x},
                                options=colors_options,
                                multi=False,
                            ),
                            width=8,
                        ),
                    ],
                    id=x,
                )
            )
    # Handle the color picking for identical barriers( e.g one line with same color)
    already_used_barriers = []
    for x in data_barriers:
        if x not in already_used_barriers:
            identical_barriers = [
                y
                for y in data_barriers
                if data_barriers[x] == data_barriers[y] and data_barriers[x] != None
            ]
            if len(identical_barriers) > 1:
                for bar in identical_barriers:
                    if triggered[0] == "{":
                        barrier = json.loads(triggered).get("index")
                        if barrier in identical_barriers:
                            # Case callback triggered by color change in barrier that have an identical one --> change all barriers colors
                            for z in identical_barriers:
                                body.append(
                                    dbc.Row(
                                        [
                                            dbc.Label(
                                                labels_barriers[z],
                                                html_for=f"color_item_{z}",
                                                width=4,
                                            ),
                                            dbc.Col(
                                                dcc.Dropdown(
                                                    id={
                                                        "type": "color_items",
                                                        "index": z,
                                                    },
                                                    options=colors_options,
                                                    multi=False,
                                                    value=data_colors[barrier],
                                                ),
                                                width=8,
                                            ),
                                        ],
                                        id=z,
                                    )
                                )
                            already_used_barriers = identical_barriers
                            break

                    elif data_colors.get(bar):
                        for z in identical_barriers:
                            body.append(
                                dbc.Row(
                                    [
                                        dbc.Label(
                                            labels_barriers[z],
                                            html_for=f"color_item_{z}",
                                            width=4,
                                        ),
                                        dbc.Col(
                                            dcc.Dropdown(
                                                id={"type": "color_items", "index": z},
                                                options=colors_options,
                                                multi=False,
                                                value=data_colors[bar],
                                            ),
                                            width=8,
                                        ),
                                    ],
                                    id=z,
                                )
                            )
                        already_used_barriers = identical_barriers
                        break

    # Add barriers that don't have an identical one
    for x in ["atk_value", "cpn_value", "prot_value"]:
        if x not in already_used_barriers:
            if locals()[x]:
                body.append(
                    dbc.Row(
                        [
                            dbc.Label(
                                labels_barriers[x],
                                html_for=f"color_item_{x}",
                                width=4,
                            ),
                            dbc.Col(
                                dcc.Dropdown(
                                    id={"type": "color_items", "index": x},
                                    options=colors_options,
                                    multi=False,
                                    value=data_colors.get(x),
                                ),
                                width=8,
                            ),
                        ],
                        id=x,
                    )
                )

    return body

    # list_cfins_colors = [x["index"] for x in cfins_colors]
    #
    # data_colors = {
    #     list_cfins_colors[i]: colors[i] for i in range(len(list_cfins_colors))
    # }


@app.callback(
    [Output(f"collapse-{i}", "is_open") for i in range(1, 3)],
    [Input(f"group-{i}-toggle", "n_clicks") for i in range(1, 3)],
    [State(f"collapse-{i}", "is_open") for i in range(1, 3)],
)
def toggle_accordion(
    n1,
    n2,
    is_open1,
    is_open2,
):
    ctx = callback_context

    if not ctx.triggered:
        return False, False
    else:
        button_id = ctx.triggered[0]["prop_id"].split(".")[0]

    if button_id == "group-1-toggle" and n1:
        return (
            not is_open1,
            False,
        )
    elif button_id == "group-2-toggle" and n2:
        return (
            False,
            not is_open2,
        )

    return False, False

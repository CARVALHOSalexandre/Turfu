from dash import html
import dash_extensions as de
import dash_bootstrap_components as dbc

url = "https://assets3.lottiefiles.com/datafiles/OzG1c5GtuAvq10U/data.json"
options = dict(
    loop=True,
    autoplay=True,
    rendererSettings=dict(preserveAspectRatio="xMidYMid slice"),
)
layout = dbc.Container(
    dbc.Row(
        dbc.Col(de.Lottie(options=options, width="90%", height="90%", url=url)),
        justify="center",
        className="mt-4",
    )
)

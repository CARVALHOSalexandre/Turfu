from flask_apscheduler.api import *
from dash import html
import dash_bootstrap_components as dbc
from dash.exceptions import PreventUpdate
from dash.dependencies import Input, Output, State, MATCH

from app import app, server

scheduler_options = {
    0: ["Inactive", "danger", "Resume"],
    1: ["Active", "success", "Pause"],
}

name_dates = {
    "mon": "Monday",
    "tue": "Tuesday",
    "wed": "Wednesday",
    "thu": "Thursday",
    "fri": "Friday",
    "sat": "Saturday",
    "sun": "Sunday",
}


def job_frequency(d):
    if d["trigger"] == "cron":
        day_of_week = d.get("day_of_week", "Every day").split("-")
        day_of_week = [name_dates.get(x, x) for x in day_of_week]
        day_of_week = " to ".join(day_of_week)
        hours = d.get("hour").split(",")
        if d.get("minute") == "0-59":
            start_hour = d.get("hour").split("-")[0]
            last_hour = d.get("hour").split("-")[1]
            return f"Every {day_of_week} - Every min from {start_hour}H to {last_hour}H"
        else:
            minutes = d.get("minute").split(",")
            hours_minutes = ", ".join(
                [
                    f"{x}h0{y}" if str(y).isnumeric() and int(y) < 10 else f"{x}h{y}"
                    for x in hours
                    for y in minutes
                ]
            )
            return f"Every {day_of_week} at {hours_minutes}"

    l = [f"{d.get(x)} {x}" for x in ["hours", "minutes", "seconds"] if d.get(x)]
    t = ", ".join(l)
    return f"Every {t}"


def serve_layout():

    jobs = get_jobs().json

    scheduler_info = get_scheduler_info().json

    sched_status = scheduler_options.get(scheduler_info["running"], "Inactive")

    return dbc.Container(
        [
            dbc.Row(
                [
                    dbc.Col(
                        [
                            dbc.Row(
                                [
                                    dbc.Col(
                                        [
                                            html.H3(
                                                job["name"].replace("_", " ").title(),
                                                className="mb-0",
                                            ),
                                        ],
                                        width=6,
                                    ),
                                    dbc.Col(
                                        html.Div(
                                            dbc.Checklist(
                                                options=[{"label": "", "value": 1}],
                                                value=[1]
                                                if job["next_run_time"]
                                                else [],
                                                id={
                                                    "type": "checklist-scheduler-status",
                                                    "id_job": job["id"],
                                                },
                                                switch=True,
                                            ),
                                            id={
                                                "type": "div-scheduler-status",
                                                "id_job": job["id"],
                                            },
                                            className="mt-3",
                                        ),
                                        width=4,
                                    ),
                                    dbc.Col(
                                        [
                                            dbc.Button(
                                                dbc.Spinner(
                                                    html.Div(
                                                        "Run",
                                                        id={
                                                            "type": "button-scheduler-spinner",
                                                            "id_job": job["id"],
                                                        },
                                                    ),
                                                    size="sm",
                                                    type="grow",
                                                    color="primary",
                                                ),
                                                id={
                                                    "type": "button-scheduler-run",
                                                    "id_job": job["id"],
                                                },
                                                color="secondary",
                                                className=" btn btn-primary my-2",
                                            ),
                                            dbc.Toast(
                                                id={
                                                    "type": "feedback-scheduler-run",
                                                    "id_job": job["id"],
                                                },
                                                header=job["name"]
                                                .replace("_", " ")
                                                .title(),
                                                is_open=False,
                                                duration=2000,
                                                style={
                                                    "position": "fixed",
                                                    "top": 105,
                                                    "right": 20,
                                                    "width": 350,
                                                },
                                            ),
                                        ],
                                        style={"textAlign": "center"},
                                        width=2,
                                    ),
                                ],
                                className="p-2 mb-2 borded-card",
                                align="center",
                                justify="between",
                            )
                            for job in jobs
                        ],
                        width=8,
                    ),
                    dbc.Col(  # Scheduler Status
                        [
                            dbc.Row(
                                [
                                    dbc.Col(
                                        [
                                            html.H3(
                                                [
                                                    "Scheduler Status",
                                                    dbc.Badge(
                                                        sched_status[0],
                                                        id="badge-scheduler-status",
                                                        color=sched_status[1],
                                                        pill=True,
                                                        className="ml-3",
                                                    ),
                                                ],
                                                className="mb-2",
                                            ),
                                            html.H5(
                                                f"Hostname: {scheduler_info.get('current_host', 'Turfu').upper()}",
                                                className="mt-3",
                                            ),
                                        ]
                                    ),
                                ],
                                className="borded-card p-4 mb-5",
                            )
                        ],
                        width=3,
                    ),
                ],
                align="start",
                justify="between",
            ),
        ],
        fluid=True,
        className="w-75 mt-5",
    )


@app.callback(
    Output({"type": "button-scheduler-spinner", "id_job": MATCH}, "children"),
    Output({"type": "feedback-scheduler-run", "id_job": MATCH}, "children"),
    Output({"type": "feedback-scheduler-run", "id_job": MATCH}, "icon"),
    Output({"type": "feedback-scheduler-run", "id_job": MATCH}, "is_open"),
    Input({"type": "button-scheduler-run", "id_job": MATCH}, "n_clicks"),
    State({"type": "button-scheduler-run", "id_job": MATCH}, "id"),
)
def scheduler_job_run(n, id):
    if n:
        run = run_job(id["id_job"])
        if run.status_code == 200:
            return "Run", "Executed successfully !", "success", True
        else:
            return (
                "Run",
                f"Issue executing the job. Error: {run.status}",
                "danger",
                True,
            )
    raise PreventUpdate


@app.callback(
    Output({"type": "checklist-scheduler-status", "id_job": MATCH}, "options"),
    Input({"type": "checklist-scheduler-status", "id_job": MATCH}, "value"),
    State({"type": "checklist-scheduler-status", "id_job": MATCH}, "id"),
)
def scheduler_job_run(value, id):
    if value == [1]:
        resume_job(id["id_job"])
        freq = job_frequency(get_job(id["id_job"]).json)
        return [{"label": freq, "value": 1}]
    pause_job(id["id_job"])
    return [{"label": "Inactive", "value": 1}]

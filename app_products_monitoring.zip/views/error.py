from dash import html

layout = html.Div(
    html.Iframe(
        src="../assets/index404.html",
        style={
            "width": "100%",
            "height": "100%",
            "position": "absolute",
            "border": "none",
        },
    )
)

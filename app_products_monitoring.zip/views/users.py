from app import User
from dash import html
import dash_bootstrap_components as dbc


def serve_layout():

    users = User.query.with_entities(
        User.id,
        User.username,
        User.displayname,
        User.email,
        User.title,
        User.department,
        User.department_id,
    ).all()

    return dbc.Container(
        [
            dbc.Col(
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                html.H3(user.displayname),
                                html.P(
                                    f"{user.username} - {user.email}", className="mb-0"
                                ),
                            ],
                            width=6,
                        ),
                        dbc.Col(
                            html.P(
                                [
                                    f"{user.department_id} - {user.department}",
                                    html.Br(),
                                    f"{user.title}",
                                ],
                                className="mb-0",
                            ),
                            width=6,
                            align="center",
                        ),
                    ],
                    className="borded-card p-3 m-2",
                )
            )
            for user in users[::-1]
        ],
    )

from app import app
from dash import dcc
from dash import html
import dash_bootstrap_components as dbc
from dash.dependencies import Input, Output

colors = {"red": "#c0392b", "green": "#16a085", "orange": "#800080"}


def log_style(x, input):
    if "WARNING" in x:
        return {"color": colors.get("red")}
    if input and input.lower() in x.lower():
        return {"color": colors.get("orange"), "font-size": 17}


def serve_layout():
    interval = dcc.Interval(id="interval-logs", interval=1000, n_intervals=0,)
    body = dbc.Container(
        [
            dbc.Row(
                [
                    dbc.Col(
                        [
                            dbc.Form(
                                html.Div(
                                    [
                                        dbc.Checklist(
                                            options=[
                                                {"label": "INFO", "value": 1},
                                                {"label": "WARNING", "value": 2},
                                                {"label": "ERROR", "value": 3},
                                            ],
                                            value=[1, 2, 3],
                                            id="switches-logs",
                                            inline=True,
                                            switch=True,
                                        ),
                                    ],
                                    className="my-2",
                                ),
                            ),
                        ],
                        width=4.5,
                        className="borded-card my-2 py-3 px-5",
                    ),
                    dbc.Col(
                        [
                            dbc.Form(
                                html.Div(
                                    [
                                        dbc.Input(
                                            placeholder="Search in logs...",
                                            type="text",
                                            id="input-logs",
                                        ),
                                    ],
                                    className="my-1",
                                ),
                            ),
                        ],
                        width=3,
                        className="borded-card my-4 py-1 px-4",
                    ),
                ],
                align="center",
                justify="between",
            ),
            dbc.Row(
                dbc.Col(
                    id="logs-data",
                    style={"maxHeight": "520px", "overflow-y": "scroll"},
                ),
                className="borded-card p-5 mt-2",
            ),
        ],
        style={"maxWidth": "80%"},
        fluid=True,
    )
    return [interval, body]


@app.callback(
    Output("logs-data", "children"),
    Input("interval-logs", "n_intervals"),
    Input("switches-logs", "value"),
    Input("input-logs", "value"),
)
def display_log_files(n, values, input):
    with open("logs/turfu.log") as logs:
        f = logs.readlines()

    if 1 not in values:
        f = [x for x in f if "INFO" not in x]

    if 2 not in values:
        f = [x for x in f if "WARNING" not in x]

    if 3 not in values:
        f = [x for x in f if "ERROR" not in x]

    return [
        html.P(x, className="m-0", style=log_style(x, input)) for x in f[-500:][::-1]
    ]

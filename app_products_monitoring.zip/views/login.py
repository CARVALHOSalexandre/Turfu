from app import app, User, ldap_manager
from flask_login import current_user, login_user
from dash import html
from dash import dcc
import dash_bootstrap_components as dbc
import dash_extensions as de

from dash.exceptions import PreventUpdate
from dash.dependencies import Input, Output, State, MATCH

from local_db_mgt import add_ldap_user

options = dict(
    loop=True,
    autoplay=True,
    rendererSettings=dict(preserveAspectRatio="xMidYMid slice"),
)

# url = "https://assets3.lottiefiles.com/private_files/lf30_4bVja9.json"

layout = dbc.Container(
    [
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Row(
                            dbc.Col(
                                [
                                    html.H1(
                                        "WELCOME ON",
                                        style={
                                            "fontWeight": 600,
                                            "letterSpacing": "-0.05em",
                                            "fontSize": "80px",
                                        },
                                    ),
                                    html.H1(
                                        "Exane's Structuring Toolbox",
                                        style={"fontWeight": 300, "fontSize": "50px",},
                                    ),
                                ],
                                className="px-5",
                            ),
                            className="mb-5",
                        ),
                        de.Lottie(
                            options=options,
                            width="65%",
                            height="65%",
                            url="/lottie/login_people.json",
                        ),
                    ],
                    width=6,
                    className="mt-5",
                ),
                dbc.Col(
                    dbc.Row(
                        dbc.Col(
                            dbc.Form(
                                [
                                    html.Img(
                                        src="../assets/images/logo_turfu.svg",
                                        height="30px",
                                        className="m-3",
                                    ),
                                    dbc.Input(
                                        type="text",
                                        placeholder="Login",
                                        id="login",
                                        autoFocus=True,
                                        className="form-control-lg my-3",
                                    ),
                                    dbc.Input(
                                        type="password",
                                        placeholder="Password",
                                        debounce=True,
                                        id="password",
                                        className="form-control-lg my-3",
                                    ),
                                    dbc.FormText("Exane Login and Password"),
                                    dbc.Button(
                                        dbc.Spinner(
                                            html.Div(
                                                "Submit", id="spinner-login-button",
                                            ),
                                            size="sm",
                                            type="grow",
                                            color="primary",
                                        ),
                                        id="login-button",
                                        className=" btn btn-primary my-3",
                                    ),
                                    dbc.Toast(
                                        "Incorrect login or password",
                                        id="output-state",
                                        header="Login Error",
                                        is_open=False,
                                        dismissable=True,
                                        duration=4000,
                                        icon="danger",
                                        # top: 66 positions the toast below the navbar
                                        style={
                                            "position": "fixed",
                                            "top": 75,
                                            "right": 10,
                                            "width": 300,
                                        },
                                    ),
                                ],
                                className="form-signin text-center",
                            ),
                            className="borded-card p-5",
                            style={"maxWidth": "300px"},
                        ),
                        justify="center",
                        align="center",
                    ),
                    width=6,
                ),
                dcc.Store(data="not_logged", id="logged_or_not"),
            ],
            justify="center",
            align="center",
        ),
    ],
    fluid=True,
    style={"maxWidth": "75%"},
)


@app.callback(
    Output("url", "pathname"), Input("logged_or_not", "data"), State("url", "pathname"),
)
def redirect_if_logged(value, pn):
    if not current_user:
        raise PreventUpdate
    if value == "logged_in" or current_user.is_authenticated:
        return pn
    raise PreventUpdate


@app.callback(
    Output("spinner-login-button", "children"),
    Output("logged_or_not", "data"),
    Input("login-button", "n_clicks"),
    Input("password", "value"),
    State("login", "value"),
)
def update_output(n_clicks, password, username):
    if n_clicks or password:

        # Check user login and password
        ldap_result = ldap_manager.authenticate_search_bind(username, password)

        if ldap_result.status.name == "success":

            user = None
            try:
                # Check if user already in Turfu database
                user = User.query.filter_by(username=username).first()
            except:
                pass

            if not user:
                # Add user in Turfu database
                r = add_ldap_user(ldap_result)
                if r.status_code != 200:
                    return True, "not_logged"

                user = User.query.filter_by(username=username).first()

            login_user(user, remember=True)
            app.logger.info(f"{username} logged in successfully")

            return "Correct", "logged_in"
        else:
            app.logger.info(f"User: {username} gave a wrong password")
            return True, "not_logged"
    return "Login", "not_logged"

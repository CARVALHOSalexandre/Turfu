blue_shades = ["#007685", "#3592A2", "#57B0BF", "#77CEDE", "#96EDFD"]

exane_colors = {
    "dark_blue": "#007685",
    "blue": "#00a6aa",
    "green": "#8db09e",
    "teal": "#a7d5c2",
    "brown": "#575756",
    "light_brown": "#bca38d",
    "pink": "#d3998a",
    "yellow": "#d9bb6f",
    "violet": "#a9a1e4",
    "grey": "#99aebc",
}

if (!window.dash_clientside) {
    window.dash_clientside = {};
}

window.dash_clientside.ui = {

    // this function should be used in the callback whenever the table viewport has changed
    replaceWithLinks_table_products_products: function(trigger) {
        // find all dash-table cells that are in column 0

        // Delete Link and TS headers
        document.getElementById("products-products-table").getElementsByTagName("th")[0].innerHTML ='';
        document.getElementById("products-products-table").getElementsByTagName("th")[1].innerHTML ='';
        document.getElementById("products-products-table").getElementsByTagName("th")[2].innerHTML ='';

        var table = document.getElementById("products-products-table").getElementsByTagName("table")[0];

        for (var i = 2, row ;row = table.rows[i]; i++) {
           cfin = row.cells[3].innerText;
           status = row.cells[1].innerText;
            if (status == "Alive"){
                row.cells[0].innerHTML = '<a href="/home?cfin=' + cfin + '" style="text-decoration: none; color: green; target="_blank"><i class="fas fa-info-circle"></i></a>'
            }
            else {
                row.cells[0].innerHTML = '<a href="/home?cfin=' + cfin + '" style="text-decoration: none; color: red; target="_blank"><i class="fas fa-info-circle"></i></a>'
            }
           row.cells[2].innerHTML =
            '<a href="https://webderdoc/webdedoc/document/termsheet/' + cfin + '" style="text-decoration: none; color: #e74c3c" target="_blank"><i class="far fa-file-pdf"></i></a>'
        }
        return true;
    },

    // this function should be used in the callback whenever the table viewport has changed
    replaceWithLinks_table_products_trades: function(trigger) {
        // find all dash-table cells that are in column 0

        // Delete Link and TS headers
        document.getElementById("products-trades-table").getElementsByTagName("th")[0].innerHTML ='';
        document.getElementById("products-trades-table").getElementsByTagName("th")[1].innerHTML ='';
        document.getElementById("products-trades-table").getElementsByTagName("th")[2].innerHTML ='';

        var table = document.getElementById("products-trades-table").getElementsByTagName("table")[0];

        for (var i = 2, row ;row = table.rows[i]; i++) {
           cfin = row.cells[3].innerText;
           status = row.cells[1].innerText;
            if (status == "Alive"){
                row.cells[0].innerHTML = '<a href="/home?cfin=' + cfin + '" style="text-decoration: none; color: green; target="_blank"><i class="fas fa-info-circle"></i></a>'
            }
            else {
                row.cells[0].innerHTML = '<a href="/home?cfin=' + cfin + '" style="text-decoration: none; color: red; target="_blank"><i class="fas fa-info-circle"></i></a>'
            }
           row.cells[2].innerHTML =
            '<a href="https://webderdoc/webdedoc/document/termsheet/' + cfin + '" style="text-decoration: none; color: #e74c3c" target="_blank"><i class="far fa-file-pdf"></i></a>'
        }
        return true;
    },

    replaceWithLinks_table_trades_primary: function(trigger) {

        var table = document.getElementById("table-primary").getElementsByTagName("table")[0];

        //Delete Link and TS headers
        document.getElementById("table-primary").getElementsByTagName("th")[0].innerHTML ='';
        document.getElementById("table-primary").getElementsByTagName("th")[1].innerHTML ='';

        for (var i = 1, row ;row = table.rows[i]; i++) {
           cfin = row.cells[2].innerText;
           row.cells[0].innerHTML =
            '<a href="/home?cfin=' + cfin + '" style="text-decoration: none; color: #3498db" target="_blank"> <i class="fas fa-info-circle"></i> </a>'

            row.cells[1].innerHTML =
            '<a href="https://webderdoc/webdedoc/document/termsheet/' + cfin + '" style="text-decoration: none; color: #e74c3c" target="_blank"> <i class="far fa-file-pdf"></i> </a>'
        }
        return true;
    },
    replaceWithLinks_table_trades_secondary: function(trigger) {

        table = document.getElementById("table-secondary").getElementsByTagName("table")[0];
        //Delete Link and TS headers
        document.getElementById("table-secondary").getElementsByTagName("th")[0].innerHTML ='';
        document.getElementById("table-secondary").getElementsByTagName("th")[1].innerHTML ='';

        for (var i = 1, row ;row = table.rows[i]; i++) {
           cfin = row.cells[2].innerText;
           row.cells[0].innerHTML =
            '<a href="/home?cfin=' + cfin + '" style="text-decoration: none; color: #3498db" target="_blank"> <i class="fas fa-info-circle"></i></a>'

            row.cells[1].innerHTML =
            '<a href="https://webderdoc/webdedoc/document/termsheet/' + cfin + '" style="text-decoration: none; color: #e74c3c" target="_blank"><i class="far fa-file-pdf"></i></a>'
        }
        return true;
    },
    replaceWithLinks_table_trades_losing: function(trigger) {
        table = document.getElementById("table-losing").getElementsByTagName("table")[0];
                //Delete Link and TS headers
        document.getElementById("table-losing").getElementsByTagName("th")[0].innerHTML ='';
        document.getElementById("table-losing").getElementsByTagName("th")[1].innerHTML ='';
        for (var i = 1, row ;row = table.rows[i]; i++) {
           cfin = row.cells[2].innerText;
           row.cells[0].innerHTML =
            '<a href="/home?cfin=' + cfin + '" style="text-decoration: none; color: #3498db" target="_blank"><i class="fas fa-info-circle"></i></a>'

            row.cells[1].innerHTML =
            '<a href="https://webderdoc/webdedoc/document/termsheet/' + cfin + '" style="text-decoration: none; color: #e74c3c" target="_blank"><i class="far fa-file-pdf"></i></a>'
        }
        return true;
    },
}

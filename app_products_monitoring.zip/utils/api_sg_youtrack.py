import json
import requests
import pandas as pd
from app import PATH
from datetime import datetime as dt
from tqdm import tqdm


STRATEGIES_URL = "{}/strategies/api/v1/"
REWEIGHT_URL = "{}/reweight/api/v1/"


class YoutrackApi:
    """https://youtrack.sgmarkets.com/api/swagger-ui/index.html?configUrl=/api-docs/swagger-config"""

    URL = "https://youtrack.sgmarkets.com/api"
    SCOPE = "api.youtrack-public.v1"

    # Pierre Bichon's client ID and Secret
    CLIENT_ID = "f0a507f0-9a84-4311-a18d-e3cd8676bbcc"
    CLIENT_SECRET = "2fci7gl5gh530hbcgh20abh73b3fb"

    def __init__(self):
        self._proxies = {}

    def set_proxies(self, proxies):
        self._proxies = proxies

    def get_universe(self, id):
        """
        :param id: Id number of the strategy Or Bloomberg Code
        :return: dict
        """
        universe_url = STRATEGIES_URL.format(self.URL) + f"{id}/universe"
        return self.__request("GET", universe_url)

    def get_composition(self, id, date):
        """
        :param id: Id number of the strategy Or Bloomberg Code
        :param date: Date of the composition - format yyy-MM-dd
        :return: dict
        """
        compo_url = STRATEGIES_URL.format(self.URL) + f"{id}/composition/{date}"
        data = self.__request("GET", compo_url)

        if data:

            df = pd.DataFrame(data)

            # Select only a subset of the available columns
            df = df[
                [
                    "bloomberg",
                    "isin",
                    "name",
                    "category",
                    "countryName",
                    "sector",
                    "currency",
                    "spot",
                    "fx2Strat",
                    "quantity",
                    "weight",
                ]
            ]

            # Rename columns
            df.columns = [
                "Bloomberg",
                "ISIN",
                "Name",
                "Category",
                "Country",
                "Sector",
                "Ccy",
                "Spot",
                "Change",
                "Quantity",
                "Weight",
            ]

            # Add date at first postiion in the DataFrame
            df.insert(loc=0, column="Date", value=pd.to_datetime(date))

            return df

    def get_impacted_corporate_action(self, id, start_date, end_date):
        """
        :param id: Id number of the strategy Or Bloomberg Code
        :param start_date: Start Date - format yyy-MM-dd
        :param end_date: End Date - format yyy-MM-dd
        :return: dict
        """
        calmpacted_url = (
            STRATEGIES_URL.format(self.URL) + f"{id}/calmpacted/{start_date}/{end_date}"
        )
        return self.__request("GET", calmpacted_url)

    def get_upcoming_corporate_action(self, id, start_date, end_date):
        """
        :param id: Id number of the strategy Or Bloomberg Code
        :param start_date: Start Date - format yyy-MM-dd
        :param end_date: End Date - format yyy-MM-dd
        :return: dict
        """
        caupcoming_url = (
            STRATEGIES_URL.format(self.URL) + f"{id}/caupcoming/{start_date}/{end_date}"
        )
        return self.__request("GET", caupcoming_url)

    def get_reshuffles(self, id, start_date, end_date):
        """
        :param id: Id number of the strategy Or Bloomberg Code
        :param start_date: Start Date - format yyy-MM-dd
        :param end_date: End Date - format yyy-MM-dd
        :return: dict
        """
        reshuffles_url = (
            STRATEGIES_URL.format(self.URL) + f"{id}/reshuffles/{start_date}/{end_date}"
        )
        return self.__request("GET", reshuffles_url)

    def get_historical_prices(self, id, start_date, end_date):
        """
        :param id: Id number of the strategy Or Bloomberg Code
        :param start_date: Start Date - format yyy-MM-dd
        :param end_date: End Date - format yyy-MM-dd
        :return: dict
        """

        if type(start_date) != str:
            start_date = start_date.strftime("%Y-%m-%d")

        if type(end_date) != str:
            end_date = end_date.strftime("%Y-%m-%d")

        historical_price_url = (
            STRATEGIES_URL.format(self.URL)
            + f"{id}/priceHistory/{start_date}/{end_date}"
        )

        data = self.__request("GET", historical_price_url)

        if data:
            df = pd.DataFrame.from_dict(
                data=data.get("strategy"),
                orient="index",
                columns=["Published Level"],
            )
            if not df.empty:
                # Add column with the daily returns
                df["Published Level Returns"] = df.pct_change()

                df.index = pd.to_datetime(df.index)

                return df

    def get_contributions(self, id, start_date, end_date):
        """
        :param id: Id number of the strategy Or Bloomberg Code
        :param start_date: Start Date - format yyy-MM-dd
        :param end_date: End Date - format yyy-MM-dd
        :return: dict
        """
        contributions_url = (
            STRATEGIES_URL.format(self.URL)
            + f"{id}/contributions/{start_date}/{end_date}"
        )
        return self.__request("GET", contributions_url)

    def get_reweights(
        self, ids=None, start_date=None, end_date=None, statuses=None, active_only=False
    ):
        """
        :param ids: List of Strategy Id number Or Bloomberg Code, search for all if None
        :param start_date: Start Date - format yyy-MM-dd, search for all dates if none
        :param end_date: End Date - format yyy-MM-dd, search for all dates if none
        :param statuses: list of str, possible values:[DRAFT, EXECUTED, TO_VALIDATE, REQUESTED_CLIENT, REVIEWED_SG, SENT, ACKED, TRD_EXECUTED, ACKED_CA, WAIT_TO_CANCEL, CANCEL, REJECTED], return all value by default
        :param active_only: Boolean
        :return: dict
        """
        reweighs_url = REWEIGHT_URL.format(self.URL)
        params = {
            "strategyIds": ids,
            "startDate": start_date,
            "endDate": end_date,
            "statuses": statuses,
            "activeOnly": active_only,
        }
        return self.__request("GET", reweighs_url, params)

    def get_reweight(self, id):
        """
        :param id: reweigh id
        :return: dict
        """
        reweighs_url = REWEIGHT_URL.format(self.URL) + f"/{id}"
        return self.__request("GET", reweighs_url)

    def post_reweight(self, reweigh_dict):
        """
        :param reweigh_dict: {
                       "strategyTicker": "SGBTESTAPI",
                       "reweightDate": "2020-01-25",
                       "reason": "PAST_OR_FUTURE_PERFORMANCE",
                       "positions": [
                           {
                               "ticker": "CASH US",
                               "type": "LONG",
                               "target": 10
                           },
                           {
                               "ticker": "STOCK TEST API",
                               "type": "SHORT",
                               "target": -1.5,
                               "executionMode": "VWAP",
                               "executionStart": "2020-01-25T12:00:00Z",
                               "executionEnd": "2020-01-25T14:00:00Z"
                           }
                       ],
                       "parameters": {
                           "PARAM_KEY_1": "2020-01-25",
                           "PARAM_KEY_2": "87%"
                       }
                    }
        :return: dict
        """
        reweighs_url = REWEIGHT_URL.format(self.URL)
        return self.__request("POST", reweighs_url, payload=reweigh_dict)

    def __get_header(self):
        token = self.get_sg_connect_token()
        return {"Authorization": f"Bearer {token}"}

    def __request(self, method, url, params=None, payload=None):
        try:
            response = requests.request(
                method,
                url,
                params=params,
                json=payload,
                headers=self.__get_header(),
                verify=True,
                proxies=self._proxies,
            )

            response.raise_for_status()
            return json.loads(response.content)
        except requests.exceptions.HTTPError as e:
            print(f"{self.__handle_status_code(e.response.status_code)}: {e}")
        except requests.exceptions.Timeout as e:
            print(f"Timeout: {e}")
        except Exception as e:
            print(f"Unknown: {e}")

    @staticmethod
    def __handle_status_code(status_code):
        status_code_error = {
            "404": "Not Found Error",
            "403": "Client Forbidden",
            "500": "Internal Server Error",
            "400": "Bad Request",
            "502": "Bad gateway",
            "407": "Authentification Required",
        }
        return status_code_error.get(status_code, "Unknown Error")

    @staticmethod
    def __get_url():
        return

    def get_sg_connect_token(self):
        """
        get SG Connect token
        """
        response = requests.post(
            f"https://sso.sgmarkets.com/sgconnect/oauth2/access_token?grant_type=client_credentials&scope={self.SCOPE}",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            auth=(self.CLIENT_ID, self.CLIENT_SECRET),
            proxies=self._proxies,
        )
        return json.loads(response.content)["access_token"]


class DataAmcSG(YoutrackApi):
    def __init__(self, ticker, ccy, start_date, end_date):
        super().__init__()
        self.ticker = ticker
        self.ccy = ccy
        self.start_date = start_date
        self.end_date = end_date
        self.df_raw = self._get_raw_data()
        self.df_agg = self._create_aggregated_data()

    @property
    def _values(self):
        return [
            "Spot",
            f"Spot {self.ccy}",
            "Contribution",
            "Returns",
            "Change",
            "Quantity",
            "Weight",
        ]

    def _get_raw_data(self):
        df = pd.DataFrame()
        for date in tqdm(pd.bdate_range(self.start_date, self.end_date)):
            df_temp = self.get_composition(
                id=self.ticker, date=date.strftime("%Y-%m-%d")
            )
            df = pd.concat([df, df_temp])

        # Rebase weights
        df["Weight"] = df["Weight"] / 100

        # Add columns for Returns and Spot with Change
        df[f"Spot {self.ccy}"] = 0
        df["Returns"] = 0
        df["Contribution"] = 0

        return df

    def _create_aggregated_data(self):

        columns = [
            "Bloomberg",
            "ISIN",
            "Name",
            "Category",
            "Country",
            "Sector",
            "Ccy",
        ]

        # Fill columns name with NaN values
        self.df_raw[columns] = self.df_raw[columns].fillna("N/A")

        # Copy the raw data DataFrame as df
        df = self.df_raw.copy()

        # Drop useless columns in df_raw
        self.df_raw = self.df_raw.drop(
            columns=[f"Spot {self.ccy}", "Contribution", "Returns"]
        )

        dff = df.pivot(index="Date", columns=columns, values=self._values)

        dff["Returns"] = dff["Spot"].pct_change()
        dff[f"Spot {self.ccy}"] = dff["Spot"] * dff["Change"]
        dff["Contribution"] = dff["Spot"] * dff["Change"] * dff["Quantity"]

        return dff

    def save_data_in_excel(self):

        df = self.df_raw.copy()
        dff = self.df_agg.copy()

        start_date = self.start_date.strftime("%Y%m%d")
        end_date = self.end_date.strftime("%Y%m%d")

        path = PATH / f"data_{ticker}_{start_date}_to_{end_date}.xlsx"

        with pd.ExcelWriter(path, "xlsxwriter", datetime_format="dd/mm/yyyy") as writer:

            # Add sheet with the raw data
            sheet_name = "Raw Data"
            df.to_excel(writer, sheet_name=sheet_name)

            # DataFrame with index computed levels vs SG
            df_index = self.get_historical_prices(
                self.ticker, self.start_date, self.end_date
            )
            df_index_levels = pd.DataFrame(
                dff["Contribution"].sum(axis=1), columns=["Computed Levels"]
            )
            df_index["Computed Level"] = df_index_levels
            df_index["Computed Level Returns"] = df_index["Computed Level"].pct_change()
            df_index.to_excel(writer, sheet_name="Index Level")

            # Create one sheet per specific value
            for value in self._values:
                dff[value].to_excel(writer, sheet_name=value)

            # Auto-adjust columns' width
            for column in df:
                column_width = (
                    max(df[column].astype(str).map(len).max(), len(column)) + 3
                )
                col_idx = df.columns.get_loc(column) + 1
                writer.sheets[sheet_name].set_column(col_idx, col_idx, column_width)

            # Specify cell formatting.
            workbook = writer.book
            format_large = workbook.add_format({"num_format": "#,##0.00"})
            format_small = workbook.add_format({"num_format": "#,##0.0000"})
            format_pct = workbook.add_format({"num_format": "0.00%"})

            worksheet = writer.sheets[sheet_name]
            format_cols = {
                "J": format_large,
                "K": format_small,
                "L": format_small,
                "M": format_pct,
            }
            for k, value in format_cols.items():
                worksheet.set_column(f"{k}:{k}", 11, value)


if __name__ == "__main__":

    # Display more columns when printing a Pandas DataFrame
    pd.options.display.width = 800
    pd.set_option("max_rows", 35)
    pd.set_option("max_columns", 15)

    ticker = "SGBCHAMC"
    ccy = "USD"
    start_date = dt(2021, 9, 1)
    end_date = dt(2021, 9, 30)

    # yt = YoutrackApi()
    # df = yt.get_historical_prices(ticker, start_date, end_date)

    data_amc = DataAmcSG(ticker, ccy, start_date, end_date)

    data_amc.save_data_in_excel()

import os
from dotenv import load_dotenv
from utils.sql import *
from utils.basics import *
import requests as rq
from utils.exceptions import ApiPricingConnectionError
from app import app
from requests.auth import HTTPBasicAuth
from utils.api_sg import SGPricer

dico_barclays = {
    "frequency": {
        "1M": "1M",
        "2M": "2M",
        "3M": "3M",
        "6M": "6M",
        "12M": "12M",
    },
    "barrier_type": {
        "European": "AtMaturity",
        "US Intraday": "Intraday",
        "US Close": "CloseOnly",
        "None": "AtMaturity",
    },
    "cpn_type": {
        "Memory": "fixedConditional",
        "Fixed": "fixedCoupon",
        "At Risk": "",
    },
}


class BarclaysPricer(rq.Session):
    BASE_URL = "https://livews.barcap.com/COMET"

    frequencies = {
        "OnePerYear": {"coeff": 1, "name": "12M"},
        "TwoPerYear": {"coeff": 2, "name": "6M"},
        "FourPerYear": {"coeff": 4, "name": "3M"},
        "OnePerMonth": {"coeff": 12, "name": "1M"},
        "SixPerYear": {"coeff": 6, "name": "2M"},
        "TwelvePerYear": {"coeff": 12, "name": "1M"},
    }

    barrier_observability = {
        "European": "AtMaturity",
        "US Intraday": "Intraday",
        "Us Close": "CloseOnly",
        "None": "AtMaturity",
    }

    def __init__(self):
        load_dotenv()

        self.client_id = self._get_env_client_id()
        self.client_secret = self._get_env_client_secret()
        self.counterparty_code = self._get_env_counterpary_code()

        self.pricing_results = []
        self.df_tickers = pd.DataFrame()

        super().__init__()

        # self._health_check()

        # Set default pricing parameters
        self.params = self._default_pricing_parameters()

    @staticmethod
    def _default_pricing_parameters():
        """Set default pricing parameters"""
        return {
            "wrapper": "Note",
            "notional": 250000,
            "reoffer": 98.5,
            "strike": 100,
            "maturity_in_months": 36,
            "frequency": "FourPerYear",
            "barrier_type": "European",
            "ki_barrier": 60,
            "cpn_type": "Guaranteed",
            "cpn_barrier": 0,
            "atk_barrier": 100,
            "atk_start_period": [4],
            "airbag_effect": False,
        }

    @staticmethod
    def _get_env_client_id():
        val = os.environ.get("BARCLAYS_API_ID")
        if not val:
            raise ApiPricingConnectionError("missing client_id")
        return val

    @staticmethod
    def _get_env_client_secret():
        val = os.environ.get("BARCLAYS_API_PASS")
        if not val:
            raise ApiPricingConnectionError("missing client_secret")
        return val

    @staticmethod
    def _get_env_counterpary_code():
        val = os.environ.get("BARCLAYS_API_COUNTERPARTY_CODE")
        if not val:
            raise ApiPricingConnectionError("missing counterpary_code")
        return val

    def _heath_check(self):

        r = self.get(
            self.BASE_URL + "/healthchecks",
            auth=HTTPBasicAuth(self.client_id, self.client_secret),
        )

        r.raise_for_status()

        content = r.json()
        if content["Status"] != "ok":
            app.logger.warning("Barclays API | Health Check Issue")

    def _downside_params(self, parameters, performance_type):

        if parameters.get("barrier_type") == "None":

            downside = {
                "capitalBase": {"unit": "pct", "value": "100"},
                "option": {
                    "type": "Put",
                    "performanceType": performance_type,
                    "strike": {"unit": "pct", "value": f"{parameters.get('strike')}"},
                    "leveraged": "true",
                },
            }

        else:

            downside = {
                "capitalBase": {"unit": "pct", "value": "100"},
                "option": {
                    "type": "KIPut",
                    "performanceType": performance_type,
                    "strike": {"unit": "pct", "value": f"{parameters.get('strike')}"},
                    "leveraged": "true" if parameters.get("strike") < 100 else "false",
                    "knockin": {
                        "barrier": {
                            "unit": "pct",
                            "value": f"{parameters.get('ki_barrier')}",
                        },
                        "observationType": self.barrier_observability.get(
                            parameters.get("barrier_type")
                        ),
                        "performanceType": performance_type,
                    },
                },
            }

        return downside

    def _coupon_params(self, parameters, performance_type):

        if parameters.get("cpn_type") in ["Memory", "Digit"]:

            coupon = {
                "type": "FixedConditional",
                "fixedConditional": {
                    "couponHigh": {"unit": "pct", "value": "SolveFor"},
                    "barrierHigh": {
                        "unit": "pct",
                        "value": f"{parameters.get('cpn_barrier')}",
                    },
                    "dayCountBasis": "PerPeriod",
                    "frequency": self.frequencies.get(parameters.get("frequency")).get(
                        "name"
                    ),
                    "performanceType": performance_type,
                    "observationType": f"{self.barrier_observability.get(parameters.get('barrier_type'))}",
                    "isMemory": "true"
                    if parameters.get("cpn_type") == "Memory"
                    else "false",
                },
            }

        elif parameters.get("cpn_type") == "Snowball":

            coupon = {
                "type": "FixedConditional",
                "fixedConditional": {
                    "couponHigh": {"unit": "pct", "value": "SolveFor"},
                    "barrierHigh": {
                        "unit": "pct",
                        "value": f"{parameters.get('atk_barrier')}",
                    },
                    "dayCountBasis": "PerPeriod",
                    "frequency": self.frequencies.get(parameters.get("frequency")).get(
                        "name"
                    ),
                    "performanceType": performance_type,
                    "observationType": "AtMaturity",
                    "isMemory": "true",
                },
            }

        else:

            coupon = {
                "type": "FixedCoupon",
                "fixedCoupon": {
                    "coupon": {"unit": "pct", "value": "SolveFor"},
                    "dayCountBasis": "PerPeriod",
                    "frequency": self.frequencies.get(parameters.get("frequency")).get(
                        "name"
                    ),
                },
            }

        return coupon

    def corresponding_tickers(self, tickers: list):
        """Correspondences between user's ticker and SG's are made through Reuters codes"""

        # Extend search to all tickers extensions
        exchanges = {
            "usa": ["UN", "US", "UW", "UQ"],
            "spain": ["SM", "SQ"],
            "germany": ["GY", "GR"],
            "switzerland": ["SE", "SW"],
        }

        all_tickers = [(x, x) for x in tickers]

        for ticker in tickers:
            split = ticker.split(" ")
            if len(split) == 2:
                for cntry in exchanges:
                    if split[1] in exchanges[cntry]:
                        other_extensions = [f"{split[0]} {x}" for x in exchanges[cntry]]
                        tickers = [(ticker, x) for x in other_extensions if x != ticker]
                        all_tickers.extend(tickers)

        df = pd.DataFrame(all_tickers, columns=["ticker", "ticker_sg"])

        # Get underlying universe from SG's server
        df_sg = SGPricer().underlying_universe(formatting="df")
        if not isinstance(df_sg, pd.DataFrame):
            df_sg = pd.DataFrame(df_sg["EquityUnderlyings"])
        df_sg = df_sg[["BloombergTickerCode", "ReutersCode", "Name", "Type"]]
        df_sg.columns = ["ticker_sg", "ticker_ric", "name_sg", "type_sg"]

        dff = pd.merge(df, df_sg, on="ticker_sg")

        # Corresponding RIC in Barclays pricer
        barx_extensions_tickers = {
            "OQ": "O",
        }

        for i in range(len(dff)):
            raw_ticker = dff.loc[i, "ticker_ric"]
            split = raw_ticker.split(".")
            if len(split) == 2:
                if split[1] in barx_extensions_tickers.keys():
                    extension = barx_extensions_tickers.get(split[1])
                    dff.loc[i, "ticker_ric"] = split[0] + "." + extension

        d_types = {
            "IndexEquity": "Index",
            "ShareOrdinary": "Share",
        }

        # Change SG's terminology for types
        dff["type_sg"] = dff["type_sg"].apply(lambda x: d_types.get(x, x))

        # Put each first letter as capital if type Share
        cap_first_char = (
            lambda x: x["name_sg"].title() if x["type_sg"] == "Share" else x["name_sg"]
        )
        dff["name_sg"] = dff.apply(cap_first_char, axis=1)

        return dff

    def description_payoff(self, payoffs, **kwargs):

        d = {**self.params, **kwargs}

        frequency = self.frequencies.get(d["frequency"]).get("name")

        d_str = {
            "frequency": f"{frequency} Obs",
            "wrapper": f"{d['wrapper']}",
            "reoffer": f"Reoffer {d['reoffer'] / 100:.2%}",
            "notional": f"Size {d['notional']:,}",
            "maturity": f"{d['maturity_in_months']} months",
            "barrier": f"{d['barrier_type']} Barrier {d['ki_barrier'] / 100:.0%}",
            "cpn_type": f"{d['cpn_type']}",
            "cpn_barrier": f"Cpn Barrier {d['cpn_barrier'] / 100:.0%}",
            "autocall": f"{d['atk_barrier'] / 100:.0%} from {frequency[0]}{d['atk_start_period']}",
            "comment": "Coupons are p.a.",
        }

        details = {
            "Autocall": ["cpn_type", "frequency", "autocall", "cpn_barrier", "barrier"],
            "Reverse": ["frequency", "barrier"],
            "Format": ["wrapper", "maturity", "reoffer", "notional", "comment"],
        }

        result = {"Format": ", ".join([d_str[x] for x in details["Format"]])}

        for name in [x.capitalize() for x in payoffs]:
            result[name] = name + " : " + ", ".join([d_str[x] for x in details[name]])

        return result

    @staticmethod
    def description_request(data):
        wrapper = data["legalForm"]["wrapper"]
        maturity = data["product"]["tenor"]
        payoff = data["product"]["payoff"]
        ccy = data["product"]["currency"]
        underlyings = ", ".join([x["id"] for x in data["product"]["assets"]])
        return f"{wrapper} - {maturity} {payoff} in {ccy} on {underlyings}"

    def api_waiting(self, wait_time, data):
        description = self.description_request(data)
        app.logger.info(f"Waiting {wait_time}s - Next request: {description}")
        time.sleep(int(wait_time) + 1)
        app.logger.info(" - Done waiting")

    def post_price_request(self, data, retry=1):
        r = self.post(
            self.BASE_URL + "/quotes",
            json=data,
            auth=HTTPBasicAuth(self.client_id, self.client_secret),
        )

        if r.status_code == 200:
            description = self.description_request(data)
            msg = f"Barclays API | {data['pricing_id']} - Post Sent: Quote ID {r.json()['quoteId']} - Details: {description}"
            app.logger.info(msg)
            return [r.json()["quoteId"], None]

        if r.status_code == 404:
            msg = f"Barclays API | Retry {retry}: Url Not found "
            app.logger.info(msg)
            time.sleep(20)

        if r.status_code == 400:
            if r.json().get("error") == "Bad Request":
                if r.json().get("errors")[0].get("field") == "product.assets[].id":
                    msg = f"Barclays API | {r.json().get('errors')[0].get('rejectedValue')} ticker not supported"
                    app.logger.info(msg)
                    return [
                        None,
                        f"Ticker {r.json().get('errors')[0].get('rejectedValue')} ticker not supported",
                    ]
            app.logger.exception(r.json())

        if retry < 20:
            retry = retry + 1
            self.api_waiting(5, data)
            return self.post_price_request(data, retry=retry)

        else:
            raise Exception(f"Barclays API | Too much retry | Skip")

        raise Exception(f"API response: {r.status_code()}")

    def get_price(self, quote_id, time_sent):

        # Control if at least 10 sec elapsed since pricing was sent
        seconds_elapsed = (dt.now() - time_sent).seconds
        if seconds_elapsed < 20:
            time.sleep(20 - seconds_elapsed)

        r = self.get(
            self.BASE_URL + f"/quotes?quoteId={quote_id}",
            auth=HTTPBasicAuth(self.client_id, self.client_secret),
        )

        if r.status_code == 200:
            if r.json().get("quoteStatus") == "success":
                msg = f"Barclays API | Quote ID: {r.json()['quoteId']} - Result: {r.json()['solveForValue']}% p.p"
                app.logger.info(msg)
                return r.json()

            if r.json().get("quoteStatus") == "fail":
                msg = f"Barclays API | Quote ID: {r.json()['quoteId']} - Pricing Issue: {r.json().get('errorMessage')}"
                app.logger.info(msg)
                return

            time.sleep(20)

            return self.get_price(quote_id, time_sent)

        # If Quote ID not found yet
        if r.status_code == 404:
            msg = (
                f"Barclays API | Quote ID: {quote_id} - Quote unavailable: waiting 10s"
            )
            app.logger.info(msg)
            time.sleep(10)
            return self.get_price(quote_id, time_sent)

        msg = f"API response: {r.status_code} - {r.content}"
        app.logger.warning(msg)
        raise Exception(f"API response: {r.status_code}")

    def send_pricing_requests(self, templates):

        df = self.df_tickers

        for x in templates:

            lst_underlyings = [y["id"] for y in x["product"]["assets"]]

            if "ticker_ric" in df.columns:
                # if not any("." in s for s in lst_underlyings):
                lst_underlyings = [
                    df[df["ticker_ric"] == y].iat[0, 0] for y in lst_underlyings
                ]
            underlyings = ", ".join(lst_underlyings)
            try:
                barclays_pricing_id = self.post_price_request(x)[0]
                data = {
                    "quote_details": x,
                    "quote_id": barclays_pricing_id,
                    "underlying": underlyings,
                    "result": None,
                    "time_sent": dt.now(),
                    "pricing_id": x["pricing_id"],
                }
                self.pricing_results.append(data)
            except Exception as e:
                msg = "Issue in Post Request"
                app.logger.exception(msg)

    def get_pricing_results(self):
        for x in self.pricing_results:
            if not x["result"]:
                x["result"] = self.get_price(x["quote_id"], x["time_sent"])

    @staticmethod
    def worst_of_combinations(tickers: list, number: int):
        assert len(tickers) >= number, "there should be more tickers than number"
        return list(itertools.combinations(tickers, number))

    def template_autocall(self, tickers, ccy, **kwargs):

        params = {**self.params, **kwargs}

        if not isinstance(tickers, (list, tuple)):
            tickers = [tickers]

        performance_type = "WorstOf" if len(tickers) > 1 else "SingleAsset"
        frequency = self.frequencies.get(params.get("frequency")).get("coeff")
        num_period = int(params.get("maturity_in_months") * frequency / 12)

        underlyings = [
            {
                "id": ticker,
                "type": "ric",
                "orderType": "MarketOnClose",
                "strikeDate": dt_today().strftime("%Y-%m-%d"),
            }
            for ticker in tickers
        ]

        downside = self._downside_params(params, performance_type)
        coupon = self._coupon_params(params, performance_type)

        if params.get("airbag_effect") == True:

            atk_barriers = {
                "barrier": [
                    {"unit": "pct", "value": f"{params.get('atk_barrier')}"}
                    for x in range(0, num_period - 1)
                ]
                + [({"unit": "pct", "value": f"{params.get('ki_barrier')}"})]
            }
        else:
            atk_barriers = {
                "barrier": [
                    {"unit": "pct", "value": f"{params.get('atk_barrier')+1}"}
                    for x in range(0, num_period)
                ],
            }

        data = {
            "metaData": {
                "quoteType": "Indicative",
                "barclaysApiVersion": "1.3",
                "clientAppName": "Exane Derivatives Staging",
                "requestUser": self.client_id,
                "clientQuoteId": "Integration",
                "requestDateTime": dt_today("string_timestamp"),
                "callbackURL": None,
            },
            "product": {
                "payoff": "Autocall",
                "currency": ccy,
                "tenor": f"{params['maturity_in_months']}M",
                "assets": underlyings,
                "settlementType": "cash",
            },
            "keyDates": {
                "strikeDate": dt_today().strftime("%Y-%m-%d"),
                "issueDate": (dt_today() + pd.tseries.offsets.BDay(5)).strftime(
                    "%Y-%m-%d"
                ),
                "feePaymentDate": (dt_today() + pd.tseries.offsets.BDay(5)).strftime(
                    "%Y-%m-%d"
                ),
            },
            "legalForm": {
                "wrapper": params.get("wrapper"),
                "tradingMethod": "Percentage",
                "issueSize": {"value": params.get("notional"), "currency": ccy},
                "denomination": {"value": 1000, "currency": ccy},
                "minTradeAmount": {"currency": ccy, "value": 10000},
                "jurisdictions": [
                    {
                        "countryCode": "FR",
                        "offerType": "PrivatePlacement",
                        "kidLanguages": ["FR"],
                    }
                ],
            },
            "pricing": {
                "fee": {"unit": "pct", "value": f"{100 - params.get('reoffer') }"},
                "reOffer": {"unit": "pct", "value": f"{params.get('reoffer')}"},
            },
            "bookingCenter": {
                "primaryCounterpartyCode": self._get_env_counterpary_code(),
                "issuePrice": {"unit": "pct", "value": "100"},
                "notional": {"value": params.get("notional"), "currency": ccy},
            },
            "callEvent": {
                "type": "Autocall",
                "frequency": self.frequencies.get(params.get("frequency")).get("name"),
                "deferral": params.get("atk_start_period") - 1,
                "autocall": {
                    **atk_barriers,
                    "performanceType": performance_type,
                    "observationType": "AtMaturity",
                },
                "rebate": [
                    {"unit": "pct", "value": "100"} for x in range(0, num_period)
                ],
            },
            "downside": {**downside},
            "coupon": {**coupon},
            "pricing_id": params.get("pricing_id"),
        }
        return data

    def get_template(self, payoff):

        d_payoffs = {
            "autocall": self.template_autocall,
        }

        return d_payoffs.get(payoff)

    def coupon_pa(self, x, **kwargs):
        """Returns per anum coupon for a given price result"""

        params = {**self.params, **kwargs}

        # In case quote is rejected return None
        if not x["result"]:
            return None

        barclays_frequency = params.get("frequency")
        frequency = self.frequencies.get(barclays_frequency).get("coeff")
        coupon = x["result"].get("solveForValue")

        return coupon * frequency

    def names_payoffs(self, quote):

        payoff = quote["product"]["payoff"]
        cpn = quote["coupon"]["type"]
        memory = quote["coupon"].get("isMemory") == "true"
        cpn_str = ""

        if cpn == "FixedCoupon":
            cpn_str = "Guaranteed"
        elif cpn == "FixedConditional" and memory == "true":
            cpn_str = "Memory"

        return f"{payoff} {cpn_str}"

    def _generate_templates(self, combinations, currencies, payoffs, **kwargs):
        # Generate a list of templates
        templates = []
        for tickers in combinations:
            for ccy in currencies:
                for payoff in payoffs:
                    templates.append(self.get_template(payoff)(tickers, ccy, **kwargs))
        return templates

    @timeit
    def get_prices_combinations(
        self,
        tickers,
        currencies,
        nb_ul=1,
        payoffs=None,
        changing_params={},
        **kwargs,
    ):

        params = {**self.params, **kwargs}

        if not payoffs:
            payoffs = ["autocall"]

        if not isinstance(params.get("atk_start_period"), list):
            params["atk_start_period"] = [params.get("atk_start_period")]

        # Create list of combinations
        templates = []
        combinations = self.worst_of_combinations(tickers, nb_ul)
        for start_period in params["atk_start_period"]:
            x = {"atk_start_period": start_period}

            self.params = {**self.params, **kwargs, **x}
            templates = templates + self._generate_templates(
                combinations, currencies, payoffs, **kwargs
            )

        # Send price requests to SG's servers
        try:
            self.send_pricing_requests(templates)
        except Exception as e:
            app.logger.info(repr(e))

        # Get the pricing results from the Quote IDs
        self.get_pricing_results()

        results = [
            {
                "type": self.names_payoffs(x["quote_details"]),
                "ccy": x["quote_details"]["product"]["currency"],
                "underlyings": x["underlying"],
                "coupon": self.coupon_pa(x, **kwargs),
                **{},
            }
            for x in self.pricing_results
        ]

        df = pd.DataFrame(results)

        # Reset list of pricing details in case user needs more runs
        self.pricing_results = []

        df = df.pivot_table(
            index="underlyings", columns=["type", "ccy"], values="coupon"
        )

        df = df.sort_values(by="underlyings")

        details = {
            "payoffs": [x.capitalize() for x in payoffs],
            "currencies": currencies,
            "descriptions": self.description_payoff(payoffs, **kwargs),
            "underlyings": df,
        }
        return df, details

    @timeit
    def pricing_run_with_details(
        self, currencies=None, tickers=None, theme=None, tickers_type="BBG", **kwargs
    ):

        msg = "Give at least a list tickers or a thematic"
        assert tickers is not None or theme is not None, msg

        if not currencies:
            currencies = ["EUR", "USD"]

        df_input = pd.DataFrame(data=tickers, columns=["ticker"])

        if theme == "bnpp_opinions":
            # Get Exane last opinions: Outperform
            df_input = last_opinions_bnpp()

        if theme == "apollo":
            df_input = amc_composition(cfin=42048123)

        if tickers_type == "BBG":
            df_tickers = self.corresponding_tickers(df_input.ticker)

            df = pd.merge(df_input, df_tickers, on="ticker")

            # df = df.head(25)

            # Prepare list of payoff template
            # Selection is made on the top 10 Exane opinions with best volatilities
            tickers = df[["ticker", "ticker_ric"]]
            tickers_ric = df["ticker_ric"]
            self.df_tickers = tickers

        if tickers_type == "RIC":
            tickers_ric = tickers

            self.df_tickers = tickers

        # Get prices from Barclays servers
        df_result, details = self.get_prices_combinations(
            tickers_ric, currencies, **kwargs
        )

        # Try to find the maximum combinations from a range of coupons
        # df2 = df[(df["coupon"] >= 7) & (df["coupon"] <= 9)]
        # listcomb = [x.split(", ") for x in df2["underlyings"]]
        # for i in range(len(listcomb)):

        # To copy_paste on clipboard
        # df_temp = pd.merge(df_result, df, left_on="underlyings", right_on="ticker_ric")

        # df_temp.to_clipboard(sep=";")
        # print("Paste to clipboard")

        # Add Volatilities, Dividends and Upside to pricing results
        for col in ["IV_12M_100%", "next_div_yield", "upside"]:
            d_names = {
                "IV_12M_100%": "IV 12m",
                "next_div_yield": "Div 12m",
                "upside": "Upside 12m",
            }
            if col in df.columns:
                df_result.loc[:, d_names.get(col)] = df[col]

        return df_result, details


if __name__ == "__main__":
    # Display more columns when printing a Pandas DataFrame
    pd.options.display.width = 800
    pd.set_option("max_rows", 35)
    pd.set_option("max_columns", 15)

    from app import server

    with server.app_context():
        # barclays = BarclaysPricer()

        # params = {
        #     "tickers": ["AMZN US"],
        #     "currencies": ["USD"],
        #     "payoffs": ["autocall"],
        #     "reoffer": 99,
        #     "maturity_in_months": 36,
        #     "cpn_barrier": 60,
        #     "ki_barrier": 60,
        # }
        # x = barclays.corresponding_tickers(["UKX", "CAC", ""])
        # where black
        # quote = barclays.template_autocall([".FTSE", ".FCHI"], "USD")
        # res = barclays.post_price_request(quote)
        # r = barclays.get_price(res, dt.now())
        # print(r.json())
        # SGPricer().description_payoff(**parameters)

        prices = BarclaysPricer().pricing_run_with_details(
            tickers=[
                "ALB US",
                "JD.O",
                "PHG.AS ",
                "SYK US",
                "TMO US",
                "UMG NA",
                "VIV FP",
                "FP fp",
                "ALB US",
                "JD.O",
                "PHG.AS ",
                "SYK US",
                "TMO US",
                "UMG NA",
                "VIV FP",
                "FP fp",
            ],
            tickers_type="BBG",
            payoffs=["autocall"],
            currencies=["EUR"],
            nb_ul=1,
        )

        print(prices)
        # d = sg.pricing_run_with_details(currencies=currencies, theme="bnpp_opinions")

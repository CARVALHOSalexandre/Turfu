import uuid

from dotenv import load_dotenv
from utils.sql import *
from utils.basics import *
import urllib3
import requests as rq
from utils.exceptions import ApiPricingConnectionError
from utils.api_sg import SGPricer
from app import app
from pprint import pprint

test_template = {
    "variationParameters": {
        "productFamily": "Autocall",
        "commercialName": "AutocallAdvanced1650",
        "basket": {
            "compo": [{"bbgCode": "AAPL UW", "strikeType": "On close"}],
            "type": "",
        },
        "structureDetails": {"nominal": "500000", "premiumCurrency": "EUR"},
        "datesConfig": {
            "delays": {"maturityTenor": "1Y"},
            "dates": {
                "strikingDate": "2021-08-26",
                "maturityDate": "2022-08-26",
            },
        },
        "finalOption": {
            "optionType": "put",
            "optionStrike": "100",
            "barrier": "Yes",
            "knockInLevel": "85",
            "useGearing": "No",
            "barrierStartDate": "2022-08-26",
            "knockInMonitoring": "At Maturity",
        },
        "couponDetails": {
            "conditionalCoupon": "1",
            "conditionalCouponBarrier": "70",
            "isFixedCoupon": "No",
            "couponType": "snowball",
        },
        "earlyRedemptionBlock": {
            "exitRateCalculation": "includeNonObservedPeriods",
            "triggerLevelER": "100",
            "frequency": "3M",
            "hasKnockOutStartDate": "No",
            "exitRate": "0",
            "exitRateMode": "Arithmetic",
            "noKnockOutBefore": "3M",
        },
        "deliveryDetails": {"delivery": "Physical"},
        "wrappingDetails": {"wrappingMode": "CE"},
    },
    "pricing_id": str(uuid.uuid4()),
}


class BNPPricer(rq.Session):
    BASE_URL = "https://api.sandbox.cib.bnpparibas.com/gm-smart-derivatives-beta/v1/"
    TOKEN_ENDPOINT = "https://api.sandbox.cib.bnpparibas.com/oauth2/v1/token"
    SCOPES = ["contractRead", "contractWrite"]

    def __init__(self):
        load_dotenv()

        self.client_id = self._get_env_client_id()
        self.client_secret = self._get_env_client_secret()

        self.pricing_results = []

        self.access_token = None
        self.access_token_start_time = None
        self.access_token_valid_time = None

        super(BNPPricer, self).__init__()

        self._get_access_token()

    @staticmethod
    def _get_env_client_id():
        val = os.environ.get("BNP_API_ID")
        if not val:
            raise ApiPricingConnectionError("missing client_id")
        return val

    @staticmethod
    def _get_env_client_secret():
        val = os.environ.get("BNP_API_PASS")
        if not val:
            raise ApiPricingConnectionError("missing client_secret")
        return val

    def _get_access_token(self):

        # Disable Certificate Verification Warning
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        r = rq.post(
            self.TOKEN_ENDPOINT,
            verify=False,
            auth=(self.client_id, self.client_secret),
            data={"grant_type": "client_credentials", "scope": " ".join(self.SCOPES)},
        )

        r.raise_for_status()
        content = r.json()

        assert content[
            "access_token"
        ], "No access_token returned by BNP Smart Derivatives"

        now = dt.now()
        self.access_token = content["access_token"]
        self.access_token_start_time = now
        self.access_token_valid_time = now + datetime.timedelta(
            seconds=content["expires_in"]
        )

        self.headers = {"Authorization": f"Bearer {self.access_token}"}

    def _refresh_access_token(self, force=False, seconds_before_valid_time=30):
        if force:
            app.logger.info("force refresh access_token")
            self._get_access_token()
            return

        now = dt.now()

        # seconds_before_valid_time cannot be negative and is set to zero
        if seconds_before_valid_time < 0:
            seconds_before_valid_time = 0

        if now > self.access_token_valid_time - timedelta(
            seconds=seconds_before_valid_time
        ):
            nb_sec_before_valid_time = (self.access_token_valid_time - now).seconds
            msg = f"Refresh access_token {nb_sec_before_valid_time}s before valid time"
            app.logger.info(msg)
            self._get_access_token()

    @staticmethod
    def description_request(data):
        d = data["variationParameters"]
        wrapper = d["wrappingDetails"]["wrappingMode"]
        maturity = d["datesConfig"]["delays"]["maturityTenor"]
        payoff = d["productFamily"]
        ccy = d["structureDetails"]["premiumCurrency"]
        underlyings = ", ".join([x["bbgCode"] for x in d["basket"]["compo"]])
        return f"{wrapper} - {maturity}m {payoff} in {ccy} on {underlyings}"

    def api_waiting(self, seconds_wait_time, data):
        description = self.description_request(data)
        app.logger.info(f"Waiting {seconds_wait_time}s - Next request: {description}")
        time.sleep(int(seconds_wait_time) + 1)
        app.logger.info(" - Done waiting")

    def corresponding_tickers(self, tickers_list):
        return SGPricer().corresponding_tickers(tickers_list)

    def get_price_request(self, ids):
        pricing_r = self.get(
            self.BASE_URL + f"contracts/{ids[0]}/solvings/{ids[1]}",
        )
        pprint(pricing_r.json(), indent=2)

    def post_price_request(self, data):
        r = self.post(
            self.BASE_URL + "contracts/",
            json=data["variationParameters"],
        )

        if r.status_code == 200:

            contract_id = str(r.json().get("contractId"))
            solving_params = {"solveFor": "conditionalCoupon", "targetPrice": 98}

            solving_r = self.post(
                self.BASE_URL + f"contracts/{contract_id}/solvings/",
                json=solving_params,
            )
            solving_id = str(solving_r.json().get("solvingId"))

            description = self.description_request(data)
            msg = f"BNP API | {data['pricing_id']} - Post Sent: Contract ID {contract_id} - Solve ID {solving_id} - Details: {description}"
            app.logger.info(msg)
            return [[contract_id, solving_id], None]

        if r.status_code == 429:
            wait_time = r.headers["retry-after"]
            self.api_waiting(wait_time, data)
            return self.post_price_request(data)

        if r.status_code == 500:
            msg = f"BNP API | {r.json().get('error')}"
            app.logger.info(msg)
            return [None, r.json()]

        if r.status_code in [502, 504]:  # Bad Gateway & Gateway Timeout
            self.api_waiting(15, data)
            return self.post_price_request(data)

        # 401 Error - Not authorized, refresh the token
        if r.status_code == 401:
            self._refresh_access_token()
            return self.post_price_request(data)

        raise Exception(f"API response: {r.status_code}")


if __name__ == "__main__":
    # Display more columns when printing a Pandas DataFrame
    pd.options.display.width = 800
    pd.set_option("max_rows", 35)
    pd.set_option("max_columns", 15)

    from app import server

    with server.app_context():
        pricer = BNPPricer()
        ids = pricer.post_price_request(test_template)
        pprint(
            ids,
            indent=2,
        )
        pprint(
            pricer.get_price_request(
                ids,
            ),
            indent=2,
        )

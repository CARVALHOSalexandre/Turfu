import pandas as pd
from dash import html
from dash.dash_table import DataTable
import dash_bootstrap_components as dbc

from app import app


def turfu_spinner(**kwargs):
    return dbc.Spinner(
        **kwargs,
        spinner_style={
            "width": "3rem",
            "height": "3rem",
            "margin-top": "5rem",
            "color": "#006266",
        },
    )


def data_table(df, **kwargs):
    if not isinstance(df, pd.DataFrame):
        raise TypeError("df must be of type DataFrame")

    # Set default values for columns
    try:
        if "columns" not in kwargs:
            kwargs["columns"] = [{"name": x, "id": x} for x in df.columns]
    except Exception as e:
        print(repr(e))

    # Set default values for Header
    if "style_header" not in kwargs:
        kwargs["style_header"] = {
            "backgroundColor": "white",
            "fontWeight": "bold",
        }

    # Set default values for Cells
    if "style_cell" not in kwargs:
        kwargs["style_cell"] = {
            "overflow": "hidden",
            "textOverflow": "ellipsis",
            "fontFamily": "Roboto",
            "backgroundColor": "transparent",
            "font-size": "small",
            "text-align": "left",
            "border-top": "1px solid rgb(236, 240, 241)",
            "border-bottom": "1px solid rgb(236, 240, 241)",
            "border-right": " 0px",
            "border-left": "0px",
        }

    return DataTable(
        data=df.to_dict(orient="records"),
        style_as_list_view=True,
        cell_selectable=False,
        export_headers="display",
        **kwargs,
    )


def products_products_table():
    tab_style_cell = {
        "overflow": "hidden",
        "textOverflow": "ellipsis",
        "padding": "5px",
        "font-family": "Roboto",
        "font-size": "12px",
        "text-align": "left",
        "backgroundColor": "transparent",
        "padding-top": "10px",
        "padding-bottom": "10px",
        "border-top": "0.1px solid rgb(240, 240, 240)",
        "border-bottom": "0.1px solid rgb(240, 240, 240)",
        "border-right": " 0px",
        "border-left": "0px",
        "maxWidth": 0,
    }

    tab_style_header = {
        "backgroundColor": "white",
        "fontWeight": "bold",
        "textAlign": "left",
        "color": "black",
    }

    tab_style_data = {
        "maxHeight": "500px",
        "overflowY": "auto",
    }

    tab_style_cell_conditional = [
        # Width Params
        {"if": {"column_id": "L"}, "width": "2%"},
        {"if": {"column_id": "Status"}, "width": "0.1%"},
        {"if": {"column_id": "TS"}, "width": "2%"},
        {"if": {"column_id": "Cfin"}, "width": "5%"},
        {"if": {"column_id": "ISIN"}, "width": "7%"},
        {"if": {"column_id": "Issue"}, "width": "6%"},
        {"if": {"column_id": "Maturity"}, "width": "6%"},
        {"if": {"column_id": "Issuer"}, "width": "7%"},
        {"if": {"column_id": "Issuer OTC"}, "width": "6%"},
        {"if": {"column_id": "Market"}, "width": "5%"},
        {"if": {"column_id": "Nominal"}, "width": "5%"},
        {"if": {"column_id": "Position"}, "width": "6%"},
        {"if": {"column_id": "Sales"}, "width": "6%"},
        {"if": {"column_id": "Ccy"}, "width": "3%"},
        {"if": {"column_id": "Bid"}, "width": "5%"},
        {"if": {"column_id": "Perf. 3M"}, "width": "5%"},
        {"if": {"column_id": "Bid Margin"}, "width": "6%"},
        {"if": {"column_id": "Last"}, "width": "6%"},
        # Perf. Cells
        {
            "if": {
                "filter_query": "{Perf. 3M} > 0",
                "column_id": "Perf. 3M",
            },
            "color": "green",
        },
        {
            "if": {
                "filter_query": "{Perf. 3M} < 0",
                "column_id": "Perf. 3M",
            },
            "color": "red",
        },
        # Hidden Columns
        {"if": {"column_id": "Status"}, "color": "white"},
        # Text Align Params
        {"if": {"column_id": "Nominal"}, "textAlign": "right"},
        {"if": {"column_id": "Position"}, "textAlign": "right"},
        {"if": {"column_id": "Bid"}, "textAlign": "right"},
        {"if": {"column_id": "Bid Margin"}, "textAlign": "right"},
        {"if": {"column_id": "Ask"}, "textAlign": "right"},
        {"if": {"column_id": "Perf. 3M"}, "textAlign": "right"},
        # Cell Selected
        {
            "if": {"state": "active"},  # 'active' | 'selected'
            "backgroundColor": "transparent",
            "border": "none",
            "color": "rgb(44, 62, 80)",
            "border-top": "1px solid rgb(236, 240, 241)",
            "border-bottom": "1px solid rgb(236, 240, 241)",
        },
        {
            "if": {"state": "selected"},
            "backgroundColor": "transparent",
            "border-top": "1px solid rgb(236, 240, 241)",
            "border-bottom": "1px solid rgb(236, 240, 241)",
        },
    ]

    table = dbc.Spinner(
        DataTable(
            id="products-products-table",
            sort_action="native",
            filter_action="custom",
            filter_query="",
            style_as_list_view=True,
            style_table=tab_style_data,
            style_header=tab_style_header,
            style_cell=tab_style_cell,
            style_cell_conditional=tab_style_cell_conditional,
        ),
        size="lg",
        type="grow",
        color="primary",
    )

    return table


def products_trades_table():
    tab_style_cell = {
        "overflow": "hidden",
        "textOverflow": "ellipsis",
        "padding": "5px",
        "font-family": "Roboto",
        "font-size": "12px",
        "text-align": "left",
        "backgroundColor": "transparent",
        "padding-top": "10px",
        "padding-bottom": "10px",
        "border-top": "0.1px solid rgb(240, 240, 240)",
        "border-bottom": "0.1px solid rgb(240, 240, 240)",
        "border-right": " 0px",
        "border-left": "0px",
        "maxWidth": 0,
    }

    tab_style_header = {
        "backgroundColor": "white",
        "fontWeight": "bold",
        "textAlign": "left",
    }

    tab_style_data = {
        "maxHeight": "500px",
        "overflowY": "auto",
    }

    tab_style_cell_conditional = [
        # Width Params
        {"if": {"column_id": "L"}, "width": "2%"},
        {"if": {"column_id": "Status"}, "width": "0.1%"},
        {"if": {"column_id": "TS"}, "width": "2%"},
        {"if": {"column_id": "Cfin"}, "width": "5%"},
        {"if": {"column_id": "ISIN"}, "width": "7%"},
        {"if": {"column_id": "Issuer"}, "width": "8%"},
        {"if": {"column_id": "Trade"}, "width": "6%"},
        {"if": {"column_id": "Maturity"}, "width": "6%"},
        {"if": {"column_id": "Type"}, "width": "5%"},
        {"if": {"column_id": "Sales"}, "width": "6%"},
        {"if": {"column_id": "Nb Trd"}, "width": "5%"},
        {"if": {"column_id": "Ccy"}, "width": "4%"},
        {"if": {"column_id": "Margin (€)"}, "width": "6%"},
        {"if": {"column_id": "Size Traded"}, "width": "7%"},
        # Hidden Columns
        {"if": {"column_id": "Status"}, "color": "white"},
        # Text Align Params
        {"if": {"column_id": "Nb Trd"}, "textAlign": "right"},
        {"if": {"column_id": "Margin (€)"}, "textAlign": "right"},
        {"if": {"column_id": "Size Traded"}, "textAlign": "right"},
        {
            "if": {"state": "active"},  # 'active' | 'selected'
            "backgroundColor": "transparent",
            "border": "none",
            "color": "rgb(44, 62, 80)",
            "border-top": "1px solid rgb(236, 240, 241)",
            "border-bottom": "1px solid rgb(236, 240, 241)",
        },
        {
            "if": {"state": "selected"},
            "backgroundColor": "transparent",
            "border-top": "1px solid rgb(236, 240, 241)",
            "border-bottom": "1px solid rgb(236, 240, 241)",
        },
    ]

    table = dbc.Spinner(
        DataTable(
            id="products-trades-table",
            sort_action="native",
            filter_action="custom",
            filter_query="",
            style_as_list_view=True,
            style_table=tab_style_data,
            style_header=tab_style_header,
            style_cell=tab_style_cell,
            style_cell_conditional=tab_style_cell_conditional,
        ),
        size="lg",
        type="grow",
        color="primary",
    )

    return table


def trades_table(component_id):
    tab_style_cell = {
        "overflow": "hidden",
        "textOverflow": "ellipsis",
        "minWidth": "0px",
        "maxWidth": "150px",
        "padding": "5px",
        "font-family": "Roboto",
        "font-size": "12px",
        "text-align": "left",
        "backgroundColor": "transparent",
        "padding-top": "10px",
        "padding-bottom": "10px",
        "border-top": "0.1px solid rgb(240, 240, 240)",
        "border-bottom": "0.1px solid rgb(240, 240, 240)",
        "border-right": " 0px",
        "border-left": "0px",
    }

    tab_style_header = {
        "backgroundColor": "white",
        "fontWeight": "bold",
    }

    tab_style_data = {
        "maxHeight": "400px",
        "overflowY": "auto",
    }

    tab_style_cell_conditional = [
        {"if": {"column_id": "L"}, "width": "25px"},
        {"if": {"column_id": "TS"}, "width": "20px"},
        {"if": {"column_id": "Name"}, "maxWidth": "280px"},
        {"if": {"column_id": "Issuer"}, "maxWidth": "120px"},
        {"if": {"column_id": "Sales"}, "maxWidth": "120px"},
        {"if": {"column_id": "Type"}, "textAlign": "right"},
        {"if": {"column_id": "Nb Trd"}, "textAlign": "right"},
        {"if": {"column_id": "Ccy"}, "textAlign": "right"},
        {"if": {"column_id": "Margin"}, "textAlign": "right"},
        {"if": {"column_id": "Cash Traded"}, "textAlign": "right"},
        {"if": {"column_id": "Size Traded"}, "textAlign": "right"},
        {
            "if": {"state": "active"},  # 'active' | 'selected'
            "backgroundColor": "transparent",
            "border": "none",
            "color": "rgb(44, 62, 80)",
            "border-top": "1px solid rgb(236, 240, 241)",
            "border-bottom": "1px solid rgb(236, 240, 241)",
        },
        {
            "if": {"state": "selected"},
            "backgroundColor": "transparent",
            "border-top": "1px solid rgb(236, 240, 241)",
            "border-bottom": "1px solid rgb(236, 240, 241)",
        },
    ]

    table = dbc.Spinner(
        DataTable(
            id=component_id,
            sort_action="native",
            style_as_list_view=True,
            style_table=tab_style_data,
            style_header=tab_style_header,
            style_cell=tab_style_cell,
            style_cell_conditional=tab_style_cell_conditional,
        ),
        spinner_style={
            "width": "3rem",
            "height": "3rem",
            "color": "#006266",
            "margin-top": "5rem",
        },
    )

    return table


def toast(header, data, **kwargs):
    params = {
        "header_style": {
            "fontWeight": 800,
            "fontFamily": "Roboto",
            "color": "#2c3e50",
            "fontSize": "1.75rem",
            "borderStyle": "none",
        },
        "style": {"font-family": "Roboto"},
        "className": "shadow-none p-2 mw-100 border-0",
        **kwargs,
    }

    toast = dbc.Toast(header=header, children=data, **params)

    return toast


def icon_termsheet(cfin, searched=False, **kwargs):

    if searched:
        cfin = f"{cfin}-checked"

    return dbc.Col(
        [
            html.Div(
                [
                    html.A(
                        html.I(className="far fa-file-pdf"),
                        target="_blank",
                        style={"color": "red"},
                        id={"type": "icon-ts", "cfin": cfin},
                    ),
                ],
                id=f"button-ts-{cfin}",
            ),
            dbc.Popover(
                dbc.PopoverBody(
                    id={"type": "popover-termsheets-body", "cfin": cfin},
                ),
                id={"type": "popover-termsheets", "cfin": cfin},
                target=f"button-ts-{cfin}",
                trigger="legacy",
                placement="bottom",
                is_open=False,
                class_name="px-3 pt-3",
            ),
        ],
        width="auto",
        **kwargs,
    )


def icon_reuters(cfin, ric, **kwargs):
    icon_path = app.get_asset_url("images/reuters-icon.svg")

    result = dbc.Col(  # Button TermSheet
        [
            html.Div(
                [
                    html.A(
                        html.Img(
                            src=icon_path, style={"height": "23px", "width": "23px"}
                        ),
                        href=f"https://emea1.apps.cp.thomsonreuters.com/web/apps/quotewebapi?s={ric}&st=RIC",
                        target="_blank",
                    ),
                ],
                id=f"button-reuters-{cfin}",
                style={"paddingTop": "6px"},
            ),
            dbc.Tooltip(
                "Open Reuters Page", target=f"button-reuters-{cfin}", placement="bottom"
            ),
        ],
        width="auto",
        **kwargs,
    )

    return result


def convert_table_data(df):
    to_str_date = lambda x: pd.to_datetime(x).strftime("%b %d, %Y") if x else " - "
    to_str_price = lambda x: "{:,.2f}".format(x) if x else " - "
    to_str_quantity = lambda x: "{:,.0f}".format(x) if x else " - "
    to_str_percent = lambda x: "{:,.2%}".format(x) if x else " - "
    to_str_decimal = lambda x: "{:,.5f}".format(float(x)) if x else None
    to_str_decimal_percent = lambda x: "{:,.2f}%".format(float(x)) if x else " - "

    func_convert = {
        "Date": to_str_date,
        "Trade": to_str_date,
        "Settlement": to_str_date,
        "Size": to_str_quantity,
        "Price": to_str_price,
        "EUR Margin": to_str_quantity,
        "Quantity": to_str_quantity,
        "Amount": to_str_quantity,
        "Payoff Price": to_str_price,
        "Disc. Factor": to_str_percent,
        "Correlation Sensi": to_str_percent,
    }

    greeks = {
        "DELTA": to_str_decimal,
        "GAMMA": to_str_decimal,
        "DECAY": to_str_decimal,
        "THETA": to_str_decimal,
        "VEGA": to_str_decimal,
        "Rho": to_str_decimal,
        "REPO": to_str_decimal,
        "SPOT": to_str_quantity,
        "VOLATILITE": to_str_decimal_percent,
    }

    for field in df.columns:
        if field in func_convert.keys():
            try:
                df[field] = df[field].apply(func_convert[field])
            except:
                pass
        else:
            for greek in greeks:
                if greek in field:
                    try:
                        df[field] = df[field].apply(to_str_decimal)
                    except:
                        pass
    return df


def scrollable_table(df, id=None, **kwargs):
    dff = convert_table_data(df)

    table_header = html.Thead(html.Tr([html.Th(x) for x in dff.columns]))

    rows = [html.Tr([html.Td(dff.at[x, y]) for y in dff.columns]) for x in dff.index]

    table_body = html.Tbody(rows)

    return html.Div(
        dbc.Table(
            [table_header, table_body],
            bordered=False,
            hover=True,
        ),
        className="table-responsive overflow-auto",
        style=kwargs,
        id=id if id else "scrollable-table",
    )


def card_title(name=None, id=None, **kwargs):
    return html.P(
        name,
        style={
            "fontFamily": "Roboto-Bold",
            "textAlign": "left",
            "fontSize": "1.50rem",
            "lineHeight": "1.75rem",
            "color": "rgba(0, 0, 0, 0.87)",
            "marginBottom": "1rem",
        },
        **kwargs,
    )


def card_subtitle(name=None, id=None):
    return html.P(
        name,
        style={
            "fontFamily": "Roboto-Bold",
            "textAlign": "left",
            "fontSize": "1.2rem",
            "lineHeight": "2rem",
            "color": "rgba(0, 0, 0, 0.54)",
            "marginTop": "1rem",
            "marginBottom": "0.5rem",
        },
    )

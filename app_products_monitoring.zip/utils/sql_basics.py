from sqlalchemy.orm import aliased
from sqlalchemy import func, and_, or_, case
from utils.basics import dt_today
from models.base import *
from datetime import datetime as dt


def sub_last():
    AlienContrib = aliased(Alien)
    LastContrib = aliased(Last)

    bid_contrib_if_exists = case(
        [(LastContrib.labid != None, LastContrib.labid)], else_=Last.labid
    )

    ask_contrib_if_exists = case(
        [(LastContrib.laask != None, LastContrib.laask)], else_=Last.laask
    )

    date_contrib_if_exists = case(
        [(LastContrib.ladate != None, LastContrib.ladate)], else_=Last.ladate
    )

    return (
        db.session.query(
            Last.lacfin.label("cfin"),
            AlienContrib.alsjac.label("cfin_contrib"),
            bid_contrib_if_exists.label("bid"),
            ask_contrib_if_exists.label("ask"),
            date_contrib_if_exists.label("date"),
        )
        .outerjoin(
            (
                AlienContrib,
                and_(AlienContrib.alsjac == Last.lacfin, AlienContrib.altype == 14),
            ),
            (LastContrib, LastContrib.lacfin == AlienContrib.alcfin),
        )
        .subquery()
    )


def sub_products():
    TiersOTC = aliased(Tier)
    AlienOTC = aliased(Alien)
    AlienContrib = aliased(Alien)

    return (
        db.session.query(
            Instrument.ifcfin.label("cfin"),
            Codes.cfcode.label("isin"),
            Instrument.ifnom.label("name"),
            Tier.tinom.label("issuer"),
            Devise.dvcodeiso.label("currency"),
            Emission.emnominal.label("nominal"),
            Emission.emprix.label("issue_price"),
            AlienOTC.alcfin.label("cfin_otc"),
            TiersOTC.tinom.label("issuer_otc"),
            AlienContrib.alcfin.label("cfin_contrib"),
            Emission.emdatestrike.label("strike_date"),
            Emission.empaiement.label("issue_date"),
            Contrats.ctmaturite.label("last_obs_date"),
            Emission.emmaturite.label("maturity_date"),
        )
        .select_from(Instrument)
        .join(
            (Emission, Emission.emcfin == Instrument.ifcfin),
            (Produit, Produit.prcfin == Instrument.ifcfin),
            (Contrats, Contrats.ctcfin == Instrument.ifcfin),
            (Devise, Devise.dvcfin == Produit.prdev),
        )
        .outerjoin(
            (Tier, Tier.ticode == Emission.emissuer),
            (
                Codes,
                and_(
                    Codes.cfcfin == Instrument.ifcfin,
                    Codes.cfsource == 6,
                ),
            ),
            (Instrumentcomplement, Instrumentcomplement.iccfin == Instrument.ifcfin),
            (Typeetatdevie, Typeetatdevie.tvcode == Instrumentcomplement.icetatdevie),
            (
                AlienOTC,
                and_(
                    AlienOTC.alsjac == Instrument.ifcfin,
                    AlienOTC.altype == 53,
                ),
            ),
            (
                AlienContrib,
                and_(
                    AlienContrib.alsjac == Instrument.ifcfin,
                    AlienContrib.altype == 14,
                ),
            ),
            (Contratotcs, Contratotcs.cocfin == AlienOTC.alcfin),
            (TiersOTC, TiersOTC.ticode == Contratotcs.coreceveur),
        )
        .filter(
            or_(
                and_(Instrument.iftypofo >= 35000, Instrument.iftypofo < 36000),
                Instrument.iftype.in_([122, 211]),
            ),
            ~Instrument.ifstatut.in_([7, 22]),
            ~Instrument.ifnom.like("Contrib %"),
            Instrument.ifcontrat == 1,
            Typeetatdevie.tvcode == 1,
            Emission.empaiement > dt(1900, 1, 1),
            # Contrats.ctmaturite > dt_today(),
        )
        .subquery()
    )


def sub_positions():
    return (
        db.session.query(
            Rkoperation.opcfin.label("cfin"),
            Rkdefbigbook.dbbigbook.label("book_from"),
            Rkbigbook.bbnom.label("book_name"),
            func.sum(Rkoperation.opquantite).label("position"),
        )
        .select_from(Rkoperation)
        .join(
            (Rkdefbigbook, Rkdefbigbook.dbbook == Rkoperation.opbook),
            (Rkbigbook, Rkbigbook.bbbigbook == Rkdefbigbook.dbbigbook),
        )
        .filter(
            Rkoperation.opotype.in_([51]),
            Rkoperation.opflag != 3,
            Rkoperation.opannule == None,
        )
        .group_by(
            Rkoperation.opcfin,
            Rkdefbigbook.dbbigbook,
            Rkbigbook.bbnom,
        )
        .order_by(Rkoperation.opcfin)
        .subquery()
    )

import os
import pysftp

from utils import sql, api_exane
from app import server, PATH


class Server:
    def __init__(self):
        # Host Address & User Id
        self.host = "sftp-minotore.minotore.com"
        self.user = "exane"
        self.password = "auyka859ezahpnm"
        self.sftp = None

        # Connect to host
        self.connect_to_host()

    def connect_to_host(self):
        """
        Connect to host on default port i.e 21
        """
        cnopts = pysftp.CnOpts()
        cnopts.hostkeys = None
        try:
            self.sftp = pysftp.Connection(
                host=self.host,
                username=self.user,
                password=self.password,
                cnopts=cnopts,
            )
        except TimeoutError:
            msg = f"Connection failed with host: {self.host}"
            server.logger.exception(msg)

    def download_file(self, filename, filepath):
        """
        Download file from host
        """

        # If the connection to the host was successful
        if self.sftp:

            # Change directory if needed
            if "productsData" in self.sftp.listdir():
                self.sftp.chdir("productsData")

            # Download file
            self.sftp.get(filename, filepath)
            msg = f"Downloaded file: {filename}"
            server.logger.info(msg)

    def upload_file(self, filepath, filename):
        """
        Upload file to host
        """

        # If the connection to the host was successful
        if self.sftp:

            # Change directory if needed
            if "productsData" in self.sftp.listdir():
                self.sftp.chdir("productsData")

            # Compute PATH (filepath + filename) of uploaded file
            file_path = os.path.join(filepath, filename)

            # Put file on server
            self.sftp.put(file_path)
            msg = f"Uploaded {filename} to {self.host}"
            server.logger.info(msg)


def update_diffusion_typos(cfins):
    # Load Service Instruments Class
    instruments = api_exane.ExaneInstruments()

    # Update Typologies
    try:
        for cfin in cfins:
            instruments.update_typo(cfin, 16509, 16510)
        msg = "Updated Listed Products Diffusion Typologies"
        server.logger.info(msg)
    except Exception as e:
        server.logger.exception(e)


def website_update():
    # Execute Requests
    df_indices = sql.execute_sql_query("indices", bind="exane_analyse_structuration")
    df_listed_positions = sql.execute_sql_query(
        "positions_website", bind="exane_analyse_structuration"
    )

    # Drop Unwanted Products (not diffusable products)
    df_listed_positions = df_listed_positions[df_listed_positions.Diffusion == "All"]
    df_listed_positions = df_listed_positions.drop(columns=["Diffusion"])

    # Update Cfin's Diffusion Typologie
    update_diffusion_typos(df_listed_positions["Cfin"])

    # Drop Unwanted Indices (not diffusable indices)
    df_indices = df_indices[df_indices.Diffusion == "All"]
    df_indices = df_indices.drop(columns=["Diffusion"])

    # Drop Unwanted Positions Data (category & sub_category columns)
    df_listed_positions.drop(columns=["Category", "Sub Category"])

    # Parse The Dataframes
    df_access = df_indices[(df_indices["Category"] == "Exane Access Index")]
    df_thematic = df_indices[(df_indices["Category"] == "Exane Thematic Index")]

    # Drop Category Columns
    df_access = df_access.drop(columns=["Category"])
    df_thematic = df_thematic.drop(columns=["Category"])

    # Path To Export
    path = os.path.join(PATH, "assets", "temp")
    access_indices_filename = "Indices_Access.csv"
    thematic_indices_filename = "Indices_Thematics.csv"
    listed_positions_filename = "Listed_Positions.csv"

    # Create "temp" Directory if doesn't exists
    if not os.path.exists(path):
        os.makedirs(path)

    # Export Dataframes To CSV Files
    df_access.to_csv(os.path.join(path, access_indices_filename), sep=";", index=False)
    df_thematic.to_csv(
        os.path.join(path, thematic_indices_filename), sep=";", index=False
    )
    df_listed_positions.to_csv(
        os.path.join(path, listed_positions_filename), sep=";", index=False
    )

    # Upload CSV Files to Server
    ftp_server = Server()
    ftp_server.upload_file(filepath=path, filename=access_indices_filename)
    ftp_server.upload_file(filepath=path, filename=thematic_indices_filename)
    ftp_server.upload_file(filepath=path, filename=listed_positions_filename)


def website_download():
    # Path To Export
    path = os.path.join(PATH, "assets", "temp", "downloads")
    access_indices_filename = "Indices_Access.csv"
    thematic_indices_filename = "Indices_Thematics.csv"
    listed_positions_filename = "Listed_Positions.csv"

    # Create "temp" Directory if doesn't exists
    if not os.path.exists(path):
        os.makedirs(path)

    # Download Files from Server
    ftp_server = Server()
    ftp_server.download_file(
        filepath=os.path.join(path, access_indices_filename),
        filename=access_indices_filename,
    )
    ftp_server.download_file(
        filepath=os.path.join(path, thematic_indices_filename),
        filename=thematic_indices_filename,
    )
    ftp_server.download_file(
        filepath=os.path.join(path, listed_positions_filename),
        filename=listed_positions_filename,
    )


if __name__ == "__main__":
    with server.app_context():
        website_update()
        # website_download()

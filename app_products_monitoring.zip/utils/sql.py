import datetime
import os
import itertools
import decimal
from math import isnan

import numpy as np
from pandas.core.common import SettingWithCopyWarning
import warnings
from utils.dictionnaries import issuers_dict
from utils.basics import *
from utils.data_sg import sg_implied_volatilites
from utils.api_open_positions import OpenPositions
from utils.termsheets import get_termsheets
from utils.api_contrib import ContribHisto
from models.base import *

from dateutil import parser

from sqlalchemy.orm import aliased
from sqlalchemy import (
    case,
    func,
    not_,
    and_,
    or_,
    cast,
    INTEGER,
)
from flask import jsonify
from datetime import timedelta
from datetime import datetime as dt
from utils.basics import try_parsing_date
from utils.sql_basics import sub_products, sub_positions, sub_last
from utils.sql_write import insert_or_update_code
from utils.api_book_positions import Positions

import re
import pandas as pd
from pandas.tseries.offsets import BDay
from app import server, cache, PATH

warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)


def date_range_to_string(date_f, date_l):
    t_delta = date_l - date_f

    if t_delta > timedelta(21):
        return f"{'{:,.3g}'.format(round(t_delta.days / timedelta(weeks=4).days * 2) / 2)} months"

    if t_delta > timedelta(7):
        return f"{round(t_delta.days / timedelta(weeks=1).days)} weeks"

    return f"{round(t_delta.days / timedelta(1).days)} days"


def reuters_different_than_exane_date(x):
    last_date = x["last_date"]
    if pd.isna(last_date):
        return True

    last_reuters_date = x["last_reuters_date"]
    if pd.isna(last_reuters_date):
        return True

    if last_date != last_reuters_date:
        return True

    if last_date < prev_bday(3):
        return True

    return False


def cause_issues_contrib(x):
    # if isnan(x["price_start_value"]):
    #     if "OTC" in x["issuer"]:
    #         return "Start Value Missing"

    if x["days_late"] < 0:
        return "Not Issued"

    if x["days_late"] == 0:
        return "Issuing Today"

    if x["maturity_date"] and x["maturity_date"] < dt_today():
        return "Product Has Matured"

    # if x["position"] + x["position_amc"] == 0:
    #     return "No Position Left"

    # if x["stddev_bid"] == 0 and x["days_late"] > 7:
    #     return "Reuters Feed Frozen or Maturity Coming"

    if (
        isnan(x["last_reuters"])
        or pd.isnull(x["last_reuters_date"])
        or x["last_reuters_old"] == True
    ):
        return "Reuters Feed Missing"

    if isnan(x["last_schredder"]) or pd.isnull(x["last_schredder_date"]):
        return "Closer Issue"

    if not isnan(x["bid_too_low"]) and x["bid_too_low"]:
        return "Bid Too Low"

    if x["last_reuters_date"] >= prev_bday(5):
        return "Shredder Issue"

    return "Other Issue"


def tip_for_cause(cause):
    d_tips = {
        "Issuing Today": "Check Reuters page and feed",
        "Product Has Matured": "Update Product's Status in Simbad",
        "No Position Left": "Update Product's Status in Simbad",
        "Start Value Missing": "Check Start Value in Excalibur",
        "Reuters Feed Frozen or Maturity Coming": "We keep retrieving the same level",
        "Reuters Feed Missing": "No Reuters feed or wrong RIC or IT issue",
        "Closer Issue": "Check Excalibur or contact ITD Support",
        "Bid Too Low": "We don't contribute negative prices",
        "Shredder Issue": "Reuters contribution stopped. If not, contact ITD Support",
    }
    return d_tips.get(cause)


def colors_highlights_for_cause(cause):
    result = {
        "settlement": "black",
        "exane": "black",
        "reuters": "black",
    }

    d_fields = {
        "Not Issued": ["settlement"],
        "Issuing Today": ["settlement"],
        "Start Value Missing": ["settlement"],
        "Reuters Feed Frozen or Maturity Coming": ["reuters"],
        "Reuters Feed Missing": ["reuters"],
        "Closer Issue": ["reuters", "exane"],
        "Bid Too Low": ["exane"],
        "Shredder Issue": ["reuters"],
    }

    fields = d_fields.get(cause)

    if fields:
        for field in fields:
            result[field] = "#e74c3c"

    return result


books = {
    # 262 - Warrant
    "amc": [63, 142, 247, 249, 355],
    "structured_products": [181, 350, 353],  # 350 listing italy
    "minifut": [322, 323],
    "options": [27],
    "rates": [161],
    # "fixed_income": [247],
    # "funds": [142],
    "others": [93, 262, 307, 308, 337, 338, 339, 340, 349, 355],
    # 349 = New Mini Fut book => Equity, Commo
    # 322 does not exist anymore
}


def concat_strings(s):
    s = s.dropna()
    if s.empty:
        return np.NaN
    return ", ".join(set(s))


def convert_columns(df, types_cols):
    """Given a DataFrame and a dict of categories and column names from the df
    this function returns a DataFrame with modified types

    Ex: types_cols = {"string": ["ISIN"], "category": ["Sales", "Trade Type"]}

    :parameter df : Pandas DataFrame
    :parameter types_cols : Dictionary of the types and columns

    """
    for type_col in types_cols.keys():
        cols = types_cols[type_col]
        try:
            if type_col == "date_string":
                df[cols] = df[cols].apply(
                    pd.to_datetime, errors="coerce", format="%Y-%m-%d"
                )
                for col in cols:
                    df[col] = df[col].apply(lambda x: dt.strftime(x, "%Y-%m-%d"))
            elif type_col == "datetime":
                df[cols] = df[cols].apply(
                    pd.to_datetime, errors="coerce", format="%Y-%m-%d"
                )
            elif type_col == "numeric":
                df[cols] = df[cols].apply(pd.to_numeric, errors="coerce")
            elif type_col == "string":
                df[cols] = df[cols].astype(pd.StringDtype())
            elif type_col == "category":
                df[cols] = df[cols].astype("category")
        except Exception as e:
            print(f"Error updating the column types: {e}")
            continue
    return df


issuers_short_names = {
    "Credit Suisse": "CS",
    "JP Morgan": "JPM",
    "Morgan Stanley": "MS",
    "Goldman Sachs": "GS",
    "Societe Generale": "SG",
    "Credit Agricole": "CACIB",
    "Leonteq": " LTQ",
}


def issuer_rename(issuer=None, issuer_hedge=None, type="OTC", short=False):
    data = {
        "BBVA Global Markets B.V.": ["BBVA", "BBVA"],
        "BBVA": ["BBVA", "BBVA"],
        "BNP Paribas": ["BNP", "BNP"],
        "BNP Paribas Arbitrage": ["BNP", "BNP"],
        "BNP Paribas Issuance BV": ["BNP", "BNP"],
        "BNP Paribas Emissions- und Handelsgesellschaft mbH": ["BNP", "BNP"],
        "Barclays PLC": ["Barclays", "Barclays"],
        "Barclays Bank PLC": ["Barclays", "Barclays"],
        "Barclays Bank Ireland PLC": ["Barclays", "Barclays"],
        "CIC": ["CIC", "CIC"],
        "Citigroup Global Markets Funding Luxembourg SCA": ["Citi", "Citi"],
        "Canadian Imperial Bank of Commerce": ["CIBC", "CIBC"],
        "CREDIT SUISSE AG": ["Credit Suisse", "CS"],
        "CREDIT SUISSE SECURITIES": ["Credit Suisse", "CS"],
        "CREDIT SUISSE BANK (EUROPE) S.A.": ["Credit Suisse", "CS"],
        "CREDIT SUISSE SECURITIES SOCIEDAD DE VALORES S.A.": ["Credit Suisse", "CS"],
        "CREDIT SUISSE SECURITIES, SOCIEDAD DE VALORES, S.A.": ["Credit Suisse", "CS"],
        "Compagnie de Financement Foncier": ["CFF", "CFF"],
        "Exane Finance": ["Exane", "Exane"],
        "Exane Finance gagé": ["Exane Pledged", "Exane"],
        "Exane Solutions (Luxembourg)": ["Exane Lux", "Exane"],
        "Exane Solutions (Luxembourg) Gage": ["Exane Lux Pledged", "Exane"],
        "Exane Solutions (Luxembourg) Gagé": ["Exane Lux Pledged", "Exane"],
        "J.P.Morgan AG": ["JP Morgan", "JPM"],
        "JP Morgan Chase & Co.": ["JP Morgan", "JPM"],
        "JP Morgan Structured Products BV": ["JP Morgan", "JPM"],
        "JP Morgan Securities plc": ["JP Morgan", "JPM"],
        "Luzerner Kantonalbank AG": ["LKB", "LKB"],
        "Morgan Stanley BV": ["Morgan Stanley", "MS"],
        "Morgan Stanley Europe SE": ["Morgan Stanley", "MS"],
        "Morgan Stanley and Co International plc": ["Morgan Stanley", "MS"],
        "NEXITY": ["Nexity", "Nexity"],
        "Nomura International Funding Pte Ltd": ["Nomura", "Nomura"],
        "Nomura Bank International PLC": ["Nomura", "Nomura"],
        "Nomura Financial Products Europe GmbH": ["Nomura", "Nomura"],
        "Royal Bank of Scotland Group PLC": ["RBS", "RBS"],
        "SG Issuer SA": ["Societe Generale", "SG"],
        "Societe Generale SA": ["Societe Generale", "SG"],
        "SOCIETE GENERALE ACCEPTANCE NV": ["Societe Generale", "SG"],
        "SOCIETE GENERALE CORPORATE & INVESTIMENT": ["Societe Generale", "SG"],
        "UBS AG Jersey Branch": ["UBS", "UBS"],
        "Leonteq Securities AG": ["Leonteq", "LTQ"],
        "Leonteq Securities AG/Guernsey": ["Leonteq", "LTQ"],
        "EFG International Finance (Guernsey) Limited": ["EFG", "EFG"],
        "Julius Baer Group Ltd": ["Julius Baer", "JB"],
        "Raiffeisen Switzerland B.V.": ["Raiffeisen", "Raiffeisen"],
        "CREDIT AGRICOLE CORPORATE AND INVESTMENT BANK": ["Credit Agricole", "CACIB",],
        "Goldman Sachs International Ltd": ["Goldman Sachs", "GS",],
        "Goldman Sachs Finance Corp International Ltd": ["Goldman Sachs", "GS",],
        "Marex Financial Limited": ["Marex", "Marex",],
        "Vontobel Financial Products Ltd": ["Vontobel", "VTB",],
    }

    if not issuer or issuer == "None":
        issuer_hedge = data.get(issuer_hedge, ["", issuer_hedge])[1]
        if not issuer_hedge:
            issuer_hedge = "Exane"
        return f"{type} {issuer_hedge}"

    issuer_values = data.get(issuer)
    if issuer_values:
        issuer = issuer_values[0 if not short else 1]

    if issuer and "Exane" in issuer:
        if issuer_hedge:
            otc_cpt = data.get(issuer_hedge, ["", issuer_hedge])[1]
            return f"{issuer}, {type} {otc_cpt}"

    return issuer


def get_ric_code(cfin):
    r = (
        db.session.query(ExternalInstrument.ric)
        .filter(ExternalInstrument.instrument_cfin == cfin)
        .first()
    )
    return r._asdict()["ric"] if r else None


def api_date_to_string(ts, label=False):
    d = parser.parse(ts).date()
    if label:
        return d.strftime("%b %d, %Y")
    return d


def anything_to_cfin(code_init):
    code = str(code_init).strip()

    # Check if code is too short
    if len(code) < 5:
        return jsonify(error_message="Too short, min 5 characters", status=404)

    if "Cfin:" in code:
        cfin = code.partition("Cfin: ")[2].partition(" ")[0]
        if cfin:
            return anything_to_cfin(cfin)
        return jsonify(error_message="Cfin not valid", status=404)

    # Check if the code is an ISIN
    is_isin = len(code) == 12
    if is_isin:
        r = Codif.query.filter(Codif.cfcode == code).all()
        if r:
            return anything_to_cfin(r[0].cfcfin)

    # Check if the code is a RIC Contribution Code
    is_ric_code = re.findall("=[A-Z]{4}$", code)
    if is_ric_code:
        r = ExternalInstrument.query.filter(ExternalInstrument.ric == code).all()
        if r:
            return anything_to_cfin(r[0].instrument_cfin)

    # Check if the code is a an External Ref
    r = Codif.query.filter(Codif.cfcode == code, Codif.cfsource == 335).first()
    if r:
        return anything_to_cfin(r.cfcfin)

    # Check if only characters
    if not code.isdigit():
        return jsonify(error_message="Not Valid", status=404)

    # Check if is a Position Cfin
    r = (
        db.session.query(Alien.alcfin, Alien.alsjac, Alien.altype, Instrument.iftype)
        .join(Instrument, Instrument.ifcfin == Alien.alsjac)
        .filter(
            and_(or_(Alien.alsjac == code, Alien.alcfin == code), Alien.altype == 14,)
        )
        .all()
    )
    if r:
        return jsonify(
            cfin=r[0].alsjac,
            cfin_contrib=r[0].alcfin,
            alien=r[0].altype,
            type=r[0].iftype,
            status=200,
        )

    # Check if it is the Cfin of an OTC Swap
    r = (
        db.session.query(Alien.alcfin, Alien.alsjac, Alien.altype, Instrument.iftype)
        .join(Instrument, Instrument.ifcfin == Alien.alsjac)
        .filter(and_(Alien.alcfin == code, Alien.altype == 53))
        .all()
    )
    if r:
        return jsonify(
            cfin=r[0].alsjac,
            cfin_otc=r[0].alcfin,
            alien=r[0].altype,
            type=r[0].iftype,
            status=200,
        )

    # Check if code is an existing cfin
    r = Instrument.query.filter_by(ifcfin=code).first()
    if r:
        return jsonify(cfin=int(r.ifcfin), type=r.iftype, status=200)

    return jsonify(error_message="Not a valid code", status=404)


@timeit
def amc_composition(cfin):
    codes_isin = aliased(Codes)
    codes_ticker = aliased(Codes)

    r = (
        db.session.query(
            Instrument.ifcfin.label("cfin"),
            Instrument.ifnom.label("name"),
            codes_isin.cfcode.label("isin"),
            codes_ticker.cfcode.label("ticker"),
            Composition.cppoids.label("weight"),
            Composition.cpquantite.label("quantity"),
            Devise.dvcodeiso.label("ccy"),
            Last.lapriclos.label("close"),
        )
        .select_from(Instrument)
        .join(
            (Composition, Composition.cpsjac == Instrument.ifcfin),
            (Produit, Produit.prcfin == Instrument.ifcfin),
            (Devise, Devise.dvcfin == Produit.prdev),
        )
        .outerjoin(
            (
                codes_isin,
                and_(codes_isin.cfcfin == Composition.cpsjac, codes_isin.cfsource == 6),
            ),
            (
                codes_ticker,
                and_(
                    codes_ticker.cfcfin == Composition.cpsjac,
                    codes_ticker.cfsource == 11,
                ),
            ),
            (
                Last,
                and_(
                    Last.lacfin == Composition.cpsjac,
                    Last.lamarche == Produit.prmarche,
                ),
            ),
        )
        .filter(
            Composition.cpcfin == cfin,
            or_(~codes_ticker.cfcode.like("% EU"), codes_ticker.cfcode == None),
        )
        .order_by(Composition.cppoids.desc())
        .distinct(Instrument.ifcfin)
    )

    df = pd.DataFrame(r)

    return df


def cfin_amc_from_cfin_certif(cfin_certif):
    """AMC's cfin from the certificate's

    select alcfin
    from exane.alien
    where
        altype = 46 and
        alsjac = (
            select cpsjac
            from exane.composition, instruments
            where
                ifcfin = cpsjac and
                iftypofo = 2000 and
                cpcfin = (
                    select desjac
                    from exane.derives
                    where decfin = <cfin>
                )
            )

    :param cfin_certif: integer
    :return: cfin: integer
    """

    # Check first if alien 56 exists, A pour certificat
    r = (
        db.session.query(Alien.alcfin.label("cfin"), Instrument.ifnom.label("name"))
        .join(Instrument, Instrument.ifcfin == Alien.alcfin)
        .filter(Alien.alsjac == cfin_certif, Alien.altype == 56)
        .first()
    )
    if r:
        return r._asdict()

    cfin_basket_certif = (
        db.session.query(Derives.desjac).filter(Derives.decfin == cfin_certif).first()
    )
    if cfin_basket_certif:
        r = Instrument.query.filter_by(ifcfin=cfin_basket_certif.desjac).first()
        if r:
            if r.typeinstrument.tynom == "Panier":
                return {"cfin": r.ifcfin, "name": r.ifnom}

    cfin_ie = (
        db.session.query(
            Composition.cpsjac.label("cfin"),
            Instrument.ifnom.label("name"),
            Typeinstrument.tyname.label("type"),
        )
        .join(
            (Instrument, Instrument.ifcfin == Composition.cpsjac),
            (Typeinstrument, Typeinstrument.tycode == Instrument.iftype),
        )
        .filter(
            Instrument.iftypofo.in_([2000, 3000]),
            Composition.cpcfin == cfin_basket_certif.desjac,
        )
    ).all()

    for result in cfin_ie:
        if result.type == "Basket":
            return result._asdict()

    cfin_ie = cfin_ie[0].cfin

    codes_amc = aliased(Codes)
    codes_certif = aliased(Codes)

    result = (
        db.session.query(
            Alien.alcfin.label("cfin"),
            Instrument.ifnom.label("name"),
            codes_amc.cfcode.label("ticker"),
            codes_certif.cfcode.label("isin"),
        )
        .join(Instrument, Instrument.ifcfin == Alien.alcfin)
        .outerjoin(
            codes_amc, and_(codes_amc.cfcfin == Alien.alcfin, codes_amc.cfsource == 11)
        )
        .outerjoin(
            codes_certif,
            and_(codes_certif.cfcfin == cfin_certif, codes_certif.cfsource == 6),
        )
        .filter(
            Alien.altype == 46,
            Alien.alsjac == (cfin_ie.cpsjac or cfin_basket_certif.desjac),
        )
    ).first()

    if result:
        return result._asdict()


def compo_full(cfin):
    r = (
        db.session.query(Composition_h.cphdate)
        .filter(Composition_h.cphcfin == cfin)
        .order_by(Composition_h.cphdate.desc())
    ).first()

    if r:
        start_date = end_date = r.cphdate

        return execute_sql_query(
            "compo_full",
            index_cfin=cfin,
            start_date=start_date.strftime("%d/%m/%Y"),
            end_date=end_date.strftime("%d/%m/%Y"),
        )


def index_and_composition_full_for_cfin(cfin):
    """Returns a DataFrame of the components if relevant

    :param cfin:
    :return:
    """

    # Check first if cfin of an index
    r = Instrument.query.filter_by(ifcfin=cfin).first()
    if r and r.typepayoff.tflnom in ["INDICE", "INDICES"]:
        return {"is_index": True, "data": compo_full(cfin)}

    # Check if is the of a structured product
    underlying = cfin_amc_from_cfin_certif(cfin)
    underlying["email"] = get_email_from_cfin_amc(underlying.get("cfin"))
    if underlying:
        return {
            "is_index": False,
            "index": underlying,
            "data": compo_full(underlying.get("cfin")),
        }


def performance(cfin, start_date, end_date):
    r = (
        db.session.query(Historiques.hoclose, Historiques.hodate)
        .filter(
            Historiques.hocfin == cfin,
            Historiques.hodate >= start_date,
            Historiques.hodate <= end_date,
        )
        .order_by(Historiques.hodate.desc())
        .all()
    )
    if r:
        return r[0].hoclose / r[-1].hoclose - 1


def amc_composition_histo(cfin, start_date, end_date=None):

    if not end_date:
        end_date = dt_today()

    codes_isin = aliased(Codes)
    codes_ticker = aliased(Codes)

    modified_country = case([(Pays.paabrege == "#NA", ""),], else_=Pays.paabrege,)
    modified_type = case(
        [(Instrument.ifnom.like("%monetary index"), "Cash"),],
        else_=Typeinstrument.tyname,
    )
    modified_class = case(
        [(Instrument.ifnom.like("%monetary index"), "Cash"),], else_=Typepayoff.tflnom,
    )

    Produit_ul = aliased(Produit)
    Produit_fx = aliased(Produit)

    Instrument_fx = aliased(Instrument)

    r = (
        db.session.query(
            Historiques.hodate.label("date"),
            Instrument.ifcfin.label("cfin"),
            Instrument.ifnom.label("name"),
            codes_isin.cfcode.label("isin"),
            codes_ticker.cfcode.label("ticker"),
            modified_country.label("country"),
            modified_type.label("type"),
            modified_class.label("class"),
            Composition_h.cphpoids.label("weight"),
            Composition_h.cphquantite.label("quantity"),
            Devise.dvcodeiso.label("ccy"),
            Historiques.hoclose.label("close"),
            Crosshistorique.chvaleur.label("fx"),
        )
        .select_from(Instrument)
        .join(
            (Composition_h, Composition_h.cphsjac == Instrument.ifcfin),
            (Produit_ul, Produit_ul.prcfin == Instrument.ifcfin),
            (Devise, Devise.dvcfin == Produit_ul.prdev),
            (
                Produit_fx,
                and_(
                    Produit_fx.prdev == Produit_ul.prdev,
                    Produit_fx.prdevnominal == -26,
                ),
            ),
            (
                Instrument_fx,
                and_(
                    Instrument_fx.ifcfin == Produit_fx.prcfin,
                    Instrument_fx.iftype == 200,
                ),
            ),
            (
                Crosshistorique,
                and_(
                    Crosshistorique.chcfin == Instrument_fx.ifcfin,
                    Crosshistorique.chdate == Composition_h.cphdate,
                    Crosshistorique.chtype == 3,
                ),
            ),
        )
        .outerjoin(
            (
                Historiques,
                and_(
                    Historiques.hocfin == Composition_h.cphsjac,
                    Historiques.hodate == Composition_h.cphdate,
                    Historiques.homarche == Produit_ul.prmarche,
                ),
            ),
            (Typeinstrument, Typeinstrument.tycode == Instrument.iftype),
            (Typepayoff, Typepayoff.tflcode == Instrument.ifpayoff),
            (
                codes_isin,
                and_(
                    codes_isin.cfcfin == Composition_h.cphsjac, codes_isin.cfsource == 6
                ),
            ),
            (
                codes_ticker,
                and_(
                    codes_ticker.cfcfin == Composition_h.cphsjac,
                    codes_ticker.cfsource == 11,
                ),
            ),
            (Emission, Emission.emcfin == Instrument.ifcfin),
            (Pays, Pays.pacode == Produit_ul.prpays),
        )
        .filter(
            Composition_h.cphcfin == cfin,
            Composition_h.cphdate >= start_date,
            Composition_h.cphdate <= end_date,
            or_(~codes_ticker.cfcode.like("% EU"), codes_ticker.cfcode == None),
        )
        .order_by(Historiques.hodate.desc(), Composition_h.cphpoids.desc())
        .distinct(Instrument.ifcfin)
    )

    df = pd.DataFrame(r)

    # df[df.date == dt(2021, 2, 22).date()].to_clipboard()

    if not df.empty:

        # Check if the weights are 100% at each date
        control = df.groupby("date")["weight"].sum()
        if any(abs(x - 100) > 0.001 for x in control):
            raise ValueError(f"Weights different than 100% for {cfin}")

        return df


def amc_bond_coupons(cfin, start_date, end_date):
    session_id = (
        db.session.query(
            func.max(IdxauditIndexEvent.idasessionid).label("id"),
            IdxauditIndexEvent.idavaluedate.label("date"),
        )
        .filter(
            IdxauditIndexEvent.idacfin == cfin, IdxauditIndexEvent.idaeventype == -11
        )
        .group_by(IdxauditIndexEvent.idavaluedate)
        # .all()
        .subquery()
    )

    modified_amount = case(
        [
            (
                Modecot.monom == "% Nominal",
                100 * IdxauditIndexEvent.idamontant / Emission.emnominal,
            ),
        ],
        else_=IdxauditIndexEvent.idamontant,
    )

    r = (
        db.session.query(
            IdxauditIndexEvent.idavaluedate.label("date"),
            IdxauditIndexEvent.idacfinsource.label("cfin"),
            modified_amount.label("value"),
        )
        .join(
            (
                session_id,
                and_(
                    IdxauditIndexEvent.idasessionid == session_id.c.id,
                    IdxauditIndexEvent.idavaluedate == session_id.c.date,
                ),
            ),
            (Emission, Emission.ifcfin == IdxauditIndexEvent.idacfinsource),
            (Produit, Produit.prcfin == IdxauditIndexEvent.idacfinsource),
            (Modecot, Modecot.mocode == Produit.prmodecot),
        )
        .filter(
            IdxauditIndexEvent.idacfin == cfin,
            IdxauditIndexEvent.idaeventype == -11,
            IdxauditIndexEvent.idavaluedate > start_date,
            IdxauditIndexEvent.idavaluedate <= end_date,
        )
        .all()
    )

    if r:
        return [x._asdict() for x in r]


def amc_rebalancing_fees(cfin, start_date, end_date):
    r = (
        db.session.query(func.sum(Idxoperation.xomontant).label("result"))
        .filter(
            Idxoperation.xocfin == cfin,
            Idxoperation.xodate >= start_date,
            Idxoperation.xodate <= end_date,
            Idxoperation.xotype == 8,
        )
        .first()
    )
    if r and r.result:
        return r.result / 100.0


def audit_epix(cfin, start_date, end_date):
    r = (
        db.session.query(
            IdxauditUdl.idusessionid.label("ID Epix"),
            IdxauditUdl.iducfin.label("Cfin"),
            IdxauditUdl.iducfinssj.label("Cfin udl"),
            IdxauditUdl.iduvaluedate.label("Value Date"),
            IdxauditUdl.iduspotdate.label("Spot Date Used"),
            IdxauditUdl.iduspot.label("Spot"),
            IdxauditUdl.iducoupon.label("Cash-Flows"),
        )
        .select_from(IdxauditUdl)
        .filter(
            IdxauditUdl.iducfin == cfin,
            IdxauditUdl.iduvaluedate >= start_date,
            IdxauditUdl.iduvaluedate <= end_date,
        )
        .order_by(IdxauditUdl.iduvaluedate.desc())
    )

    df = pd.DataFrame(r)

    return df


def trades_summary(cfin):
    # Create dico of cfins
    cfins = {int(cfin): "Titre"}

    # Check if alien 53 exists - OTC Microhedge
    alien_otc_ext = alien(cfin, with_issuer=True).get(53)
    if alien_otc_ext:
        for _ in alien_otc_ext:
            cfins[_["cfin"]] = f"{_['type']} {_['issuer']}"

    # Check if alien 35 exists - OTC to security
    alien_otc_der = (
        db.session.query(Alien.alcfin)
        .filter(and_(Alien.alsjac == cfin, Alien.altype == 35))
        .first()
    )
    if alien_otc_der:
        cfins[alien_otc_der.alcfin] = "OTC Der"

    order_type = case([(Rkoperation.opquantite < 0, "Sell")], else_="Buy")

    result = (
        db.session.query(
            Rkoperation.opcfin.label("cfin"),
            Rkoperation.opdatenego.label("trade_date"),
            Rkoperation.opdaterl.label("settlement_date"),
            order_type.label("order_type"),
            Rktypeop.tolibelle.label("trade_type"),
            Devise.dvcodeiso.label("ccy"),
            Emission.emnominal.label("nominal"),
            (Emission.emnominal * Rkoperation.opquantite).label("size_traded"),
            Rkoperation.opcours.label("price"),
            Rkoperation.opmargevendeur.label("margin"),
            Rkvendeurcircus.vcnom.label("sales"),
            Rkdefbigbook.dbbigbook.label("book_from"),
            Rkoperation.opportef.label("book_to"),
        )
        .select_from(Rkoperation)
        .join(
            (Rktypeop, Rktypeop.tootype == Rkoperation.opotype),
            (Rkdefbigbook, Rkdefbigbook.dbbook == Rkoperation.opbook),
            (Emission, Emission.emcfin == Rkoperation.opcfin),
            (Devise, Devise.dvcfin == Rkoperation.opdev),
        )
        .outerjoin(
            (Rkvendeurcircus, Rkvendeurcircus.vccode == Rkoperation.opvendeur),
            (Rkuser, Rkuser.ususer == Rkoperation.opinitialfrontoperator),
        )
        .filter(
            and_(
                Rkoperation.opcfin.in_(list(cfins.keys())),
                Rkoperation.opflag != 3,
                Rkoperation.opannule == None,
                not_(Rkoperation.opinformation.in_([1, 4, 6])),
                or_(
                    Rkuser.usadnom == None, Rkuser.usadnom != "DOUCEMENT"
                ),  # Severin books book transfers in PoTT
                # Rkoperation.opprovenance != "I",  # Trading book transfers
                Rkoperation.opportef != 355,  # 355 is a transition book
                Rkdefbigbook.dbbigbook == Rkoperation.opgenerateur,
            ),
        )
    ).all()

    if not result:
        return "", "", 404

    df = pd.DataFrame(result)

    inv_cfins = {v: k for k, v in cfins.items()}

    nominal = df[df.cfin == inv_cfins.get("Titre")].nominal.max()

    # Get the Positions of the Note from the API
    positions = Positions().positions_for_cfin(inv_cfins.get("Titre"))
    lst_pose = []
    lst_issued = []
    for position in positions:
        book_id = position.get("bookId")
        issued_details = position.get("issueDetails")
        if issued_details:

            invested = issued_details.get("investedPosition")
            if invested != 0:
                if nominal and nominal != 0:
                    lst_pose.append(f"{- invested * float(nominal):,.0f} in {book_id}")
                else:
                    lst_pose.append(f"{- invested:,.0f} units in {book_id}")

            issued = issued_details.get("issuedPosition")
            if issued:
                if nominal and nominal != 0:
                    lst_issued.append(f"{issued * float(nominal):,.0f} in {book_id}")
                else:
                    lst_issued.append(f"{issued:,.0f} units in {book_id}")

    text_positions = ", ".join(lst_pose) if lst_pose else "0"
    text_issued = ", ".join(lst_issued) if lst_issued else "0"

    # Get the Positions of the OTC from the API
    lst_pose = []
    cfin_otc = inv_cfins.get("OTC Ext")
    if cfin_otc:
        positions = Positions().positions_for_cfin(cfin_otc)
        for position in positions:
            book_id = position.get("bookId")
            issued_details = position.get("issueDetails")
            if issued_details:
                invested = issued_details.get("investedPosition")
                if invested != 0:
                    lst_pose.append(f"{invested * float(nominal):,.0f} in {book_id}")

    text_positions_otc = ", ".join(lst_pose) if lst_pose else "0"

    details = {
        "sales": ", ".join(df.dropna().sales.unique()),
        "ccy": df.ccy.unique()[0],
        "nominal": df.nominal.unique()[0],
        "total_margin": "{:,.0f}".format(df.margin.sum()),
        "positions": text_positions,
        "positions_otc": text_positions_otc,
        "issued": text_issued,
    }

    df["description"] = df.apply(
        lambda x: f"Transfer to {x['book_to']}"
        if x["book_to"] != -1
        else f"{x['book_from']} {x['order_type']}s",
        axis=1,
    )

    # Convert columns types to DateTime, String or Category
    types_cols = {
        "datetime": ["trade_date", "settlement_date"],
        "numeric": ["size_traded", "price"],
        "string": ["sales", "description"],
        "category": ["order_type", "ccy"],
    }
    df = convert_columns(df, types_cols)

    df = df.drop(columns=["nominal", "book_from", "book_to"])

    df.columns = [
        "Format",
        "Trade",
        "Settlement",
        "Order",
        "Type",
        "Ccy",
        "Size",
        "Price",
        "EUR Margin",
        "Sales",
        "Description",
    ]

    df.Format = df.Format.apply(lambda x: cfins.get(x))

    # Sort by the Trade Date
    df = df.sort_values(
        by=["Format", "Trade", "Type", "Size", "Order"],
        ascending=[False, False, True, False, True],
    )

    # Clean NaN values
    df.Sales = df.Sales.fillna("-")
    df.Size = df.Size.fillna("-")

    #  Filter Commission Trades
    df = df[df["Type"] != "Commission"]

    return df.head(100), details, 200


def positions_details(cfin, date=None):
    # Create dico of cfins
    cfins = {int(cfin): "Note"}

    # Check if alien 53 exists - OTC Microhedge
    alien_otc_ext = (
        db.session.query(Alien.alcfin)
        .filter(and_(Alien.alsjac == cfin, Alien.altype == 53))
        .first()
    )
    if alien_otc_ext:
        cfins[alien_otc_ext.alcfin] = "OTC Ext"

    # Check if alien 35 exists - OTC to security
    alien_otc_der = (
        db.session.query(Alien.alcfin)
        .filter(and_(Alien.alsjac == cfin, Alien.altype == 35))
        .first()
    )
    if alien_otc_der:
        cfins[alien_otc_der.alcfin] = "OTC Der"

    order_type = case([(Rkoperation.opquantite < 0, "Sell")], else_="Buy")

    result = (
        db.session.query(
            Rkoperation.opcfin.label("cfin"),
            Rkoperation.opdatenego.label("trade_date"),
            Rkoperation.opdaterl.label("settlement_date"),
            order_type.label("order_type"),
            Rktypeop.tolibelle.label("trade_type"),
            Devise.dvcodeiso.label("ccy"),
            Emission.emnominal.label("nominal"),
            (Emission.emnominal * Rkoperation.opquantite).label("size_traded"),
            Rkoperation.opcours.label("price"),
            Rkoperation.opmargevendeur.label("margin"),
            Rkvendeurcircus.vcnom.label("sales"),
            Rkdefbigbook.dbbigbook.label("book_from"),
            Rkoperation.opportef.label("book_to"),
        )
        .select_from(Rkoperation)
        .join(
            (Rktypeop, Rktypeop.tootype == Rkoperation.opotype),
            (Rkdefbigbook, Rkdefbigbook.dbbook == Rkoperation.opbook),
            (Emission, Emission.emcfin == Rkoperation.opcfin),
            (Devise, Devise.dvcfin == Rkoperation.opdev),
        )
        .outerjoin(
            (Rkvendeurcircus, Rkvendeurcircus.vccode == Rkoperation.opvendeur),
            (Rkuser, Rkuser.ususer == Rkoperation.opinitialfrontoperator),
        )
        .filter(
            and_(
                Rkoperation.opcfin.in_(list(cfins.keys())),
                Rkoperation.opflag != 3,
                Rkoperation.opdatenego <= date,
                Rkoperation.opannule == None,
                not_(Rkoperation.opinformation.in_([1, 4, 6])),
                or_(
                    Rkuser.usadnom == None, Rkuser.usadnom != "DOUCEMENT"
                ),  # Severin books book transfers in PoTT
                # Rkoperation.opprovenance != "I",  # Trading book transfers
                Rkoperation.opportef != 355,  # 355 is a transition book
                Rkdefbigbook.dbbigbook == Rkoperation.opgenerateur,
            ),
        )
    )

    if not result:
        return {}

    df = pd.DataFrame(result)

    if df.empty:
        return {}

    inv_cfins = {v: k for k, v in cfins.items()}

    nominal = df[df.cfin == inv_cfins.get("Note")].nominal.max()
    nominal = float(nominal)

    # Get the Positions from the API one day before the observation date
    positions = Positions().positions_for_cfin(inv_cfins.get("Note"), date - BDay(1))
    lst_pose = 0
    lst_pose_amc = 0
    for position in positions:
        issued_details = position.get("issueDetails")
        if issued_details:
            invested = issued_details.get("investedPosition")
            if invested < 0:
                lst_pose += -invested * nominal
            if invested > 0:
                lst_pose_amc += invested * nominal
        else:
            position = position.get("position").get("position")
            lst_pose_amc += position * nominal

    return {
        "sales": ", ".join(df.dropna().sales.unique()),
        "ccy": df.ccy.unique()[0],
        "total_margin": "{:,.0f}".format(df.margin.sum()),
        "positions": lst_pose,
        "positions_amc": lst_pose_amc,
    }


def get_email_from_cfin_amc(cfin):
    r = (
        db.session.query(Idxattributs.xavaleurstring.label("email")).filter(
            and_(Idxattributs.xacfin == cfin, Idxattributs.xatypeattribut == 71),
        )
    ).first()

    return r[0] if r else ""


def ric_code_and_last_reuters(cfin):
    last_date_reuters = (
        db.session.query(
            ExternalInstrumentClose.cfin,
            func.max(ExternalInstrumentClose.timestamp).label("last_date"),
        )
        .group_by(ExternalInstrumentClose.cfin)
        .subquery()
    )

    r = (
        db.session.query(
            ExternalInstrument.instrument_cfin.label("cfin"),
            ExternalInstrument.ric.label("ric"),
            ExternalInstrumentClose.last.label("last_reuters"),
            ExternalInstrumentClose.timestamp.label("last_reuters_date"),
        )
        .outerjoin(
            (
                last_date_reuters,
                last_date_reuters.c.cfin == ExternalInstrument.instrument_cfin,
            ),
            (
                ExternalInstrumentClose,
                and_(
                    ExternalInstrumentClose.cfin == ExternalInstrument.instrument_cfin,
                    ExternalInstrumentClose.timestamp == last_date_reuters.c.last_date,
                ),
            ),
        )
        .filter(ExternalInstrument.instrument_cfin == cfin)
    )

    d = [x._asdict() for x in r]

    return d


@timeit
def trades(start_date, end_date=dt_today(), cfin=None):
    order_type = case(
        [(Rkoperation.opquantite + Rkoperation.opquantitebroker > 0, "Sell")],
        else_="Buy",
    )

    size_traded = func.abs(Emission.emnominal * Rkoperation.opquantite)

    tiers_otc, tiers_hedge = aliased(Tier), aliased(Tier)
    emission_hedge = aliased(Emission)

    calc_start_date = start_date - BDay(4)

    issuer_hedge = case(
        [(tiers_otc.tinom != None, tiers_otc.tinom)], else_=tiers_hedge.tinom
    )

    type_hedge = case([(tiers_otc.tinom != None, "OTC")], else_="Note")

    result = (
        db.session.query(
            Rkoperation.opnumero.label("trade_id"),
            Rkoperation.opnumechange.label("trade_link"),
            Rkoperation.opdatenego.label("trade_date"),
            Rkoperation.opdaterl.label("settlement_date"),
            Emission.emdate.label("initial_date"),
            Emission.empaiement.label("payment_date"),
            Emission.emmaturite.label("maturity_date"),
            Devise.dvcodeiso.label("currency"),
            Rkoperation.opchange.label("change"),
            Rkoperation.opcfin.label("cfin"),
            Codif.cfcode.label("isin"),
            Tier.tinom.label("issuer"),
            issuer_hedge.label("issuer_hedge"),
            type_hedge.label("type_hedge"),
            Instrument.ifnom.label("name"),
            order_type.label("type_order"),
            Rkoperation.opquantite.label("quantity"),
            Emission.emnominal.label("nominal"),
            size_traded.label("size_traded"),
            Rkoperation.opmontant.label("cash_traded"),
            Rkoperation.opmargevendeur.label("margin"),
            Rkvendeurcircus.vcnom.label("sales"),
            Rkdefbigbook.dbbigbook.label("book_from"),
            # Rkbigbook.bbnom.label("book_from_name"),
            Rkoperation.opportef.label("book_to"),
        )
        .select_from(Rkoperation)
        .join(
            (
                Instrument,
                and_(
                    Instrument.ifcfin == Rkoperation.opcfin,
                    Instrument.ifcontrat == 1,
                    not_(
                        Instrument.iftype.in_([3, 31, 213])
                    ),  # 3 --> Cvt/Act - 31 --> Obligation - 213 --> Commission Echelon
                    or_(
                        and_(Instrument.iftypofo >= 35000, Instrument.iftypofo < 36000),
                        Instrument.iftype.in_([52, 122, 211]),
                    ),
                ),
            ),
            (Typeinstrument, Typeinstrument.tycode == Instrument.iftype),
            (Emission, Emission.emcfin == Rkoperation.opcfin),
            (
                Rkdefbigbook,
                and_(
                    Rkdefbigbook.dbbook == Rkoperation.opbook,
                    # Rkdefbigbook.dbbigbook.in_(book_scopes),  # ATTENTION
                ),
            ),
            (
                Rkbigbook,
                and_(
                    Rkbigbook.bbbigbook == Rkdefbigbook.dbbigbook,
                    Rkbigbook.bbtype != 0,
                ),
            ),
        )
        .outerjoin(
            (Alien, and_(Alien.alsjac == Rkoperation.opcfin, Alien.altype == 53)),
            (emission_hedge, emission_hedge.emcfin == Alien.alcfin),
            (tiers_hedge, tiers_hedge.ticode == emission_hedge.emissuer),
            (Contratotcs, Contratotcs.cocfin == Alien.alcfin),
            (tiers_otc, tiers_otc.ticode == Contratotcs.coreceveur),
            (Produit, Produit.prcfin == Rkoperation.opcfin),
            (Devise, Devise.dvcfin == Produit.prdev),
            (Tier, Tier.ticode == Emission.emissuer),
            (Rkvendeurcircus, Rkvendeurcircus.vccode == Rkoperation.opvendeur),
            (Rkuser, Rkuser.ususer == Rkoperation.opinitialfrontoperator),
            (Typepayoff, Typepayoff.tflcode == Instrument.ifpayoff),
            (Codif, and_(Codif.cfcfin == Rkoperation.opcfin, Codif.cfsource == 6)),
        )
        .filter(
            and_(
                Rkoperation.opdatenego >= calc_start_date,
                Rkoperation.opdatenego <= end_date,
                Rkoperation.opannule == None,
                Rkoperation.opflag != 3,
                not_(Rkoperation.opinformation.in_([1, 4, 6])),
                Rkoperation.opotype == 51,  # Type Flux
                or_(
                    not_(Rkvendeurcircus.vccode.in_([-1])),
                    Rkvendeurcircus.vccode == None,
                ),
                or_(
                    Rkuser.usadnom != "DOUCEMENT", Rkuser.usadnom == None
                ),  # Severin books book transfers in PoTT
                # Rkoperation.opprovenance != "I",  # Trading book transfers
                Rkoperation.opportef != 355,  # 355 is a transition book
                Rkdefbigbook.dbbigbook == Rkoperation.opgenerateur,
            ),
        )
    )

    # Option to filter on a specific Cfin for debug purposes
    if cfin:
        result = result.filter(Rkoperation.opcfin == cfin)

    df = pd.DataFrame(result)

    if df.empty:
        return

    df = df.set_index("trade_id")

    # Assign - if ISIN is missing
    df["isin"] = df["isin"].fillna(" - ")

    # Convert columns types to DateTime, String or Category
    types_cols = {
        "datetime": [
            "trade_date",
            "settlement_date",
            "initial_date",
            "payment_date",
            "maturity_date",
        ],
        "numeric": [
            "quantity",
            "size_traded",
            "cash_traded",
            "margin",
            "nominal",
            "change",
        ],
        "string": ["isin", "name"],
        "category": ["issuer", "currency", "type_order"],
    }
    df = convert_columns(df, types_cols)

    # Add Correct Margin for trades
    keys_dates = ["cfin", "trade_date", "type_order"]
    dff = df[(df.margin == 0) | (df.cash_traded == 0)]
    dff_dates = (
        dff.groupby(keys_dates)
        .agg(
            margin=("margin", "sum"),
            change=("change", "max"),
            cash_traded=("cash_traded", "sum"),
            sales=("sales", concat_strings),
        )
        .reset_index()
    )
    dff_dates = dff_dates.dropna()
    dff_dates = dff_dates[dff_dates.cash_traded != 0]
    if not dff_dates.empty:
        dff_dates = dff_dates[(dff_dates.margin != 0) & (dff_dates.cash_traded != 0)]
        dff_dates = (
            dff.reset_index().merge(dff_dates, on=keys_dates).set_index("trade_id")
        )
        df.loc[dff_dates.index, "sales"] = dff_dates.sales_y
        df.loc[dff_dates.index, "change"] = dff_dates.change_y
        df.loc[dff_dates.index, "margin"] = dff_dates.apply(
            lambda x: x["margin_y"] * x["cash_traded_x"] / x["cash_traded_y"]
            if x["cash_traded_y"] != 0
            else x["margin_x"],
            axis=1,
        )
        df = df[(df.margin != 0.0) | (df.size_traded != 0)]

    keys_types = ["cfin", "type_order"]
    dff = df[(df.margin == 0) | (df.cash_traded == 0)]
    if not dff.empty:
        dff_types = (
            dff.groupby(keys_types)
            .agg(
                margin=("margin", "sum"),
                change=("change", "max"),
                cash_traded=("cash_traded", "sum"),
                sales=("sales", concat_strings),
            )
            .reset_index()
        )
        dff_types = dff_types.dropna()
        dff_types = dff_types[dff_types.margin != 0]
        if not dff_types.empty:
            dff_types = (
                dff.reset_index().merge(dff_types, on=keys_types).set_index("trade_id")
            )
            df.loc[dff_types.index, "sales"] = dff_types.sales_y
            df.loc[dff_types.index, "change"] = dff_types.change_y
            df.loc[dff_types.index, "margin"] = dff_types.apply(
                lambda x: x["margin_y"] * x["cash_traded_x"] / x["cash_traded_y"]
                if (x["margin_y"] != 0 and x["cash_traded_y"] != 0)
                else x["margin_x"],
                axis=1,
            )

        df = df[df.margin != 0]

    # Flag trades as Primary even if they were booked a day after the strike date
    df["is_primary"] = False
    calc_start_date = pd.to_datetime(calc_start_date)
    dff = df[(df.initial_date >= calc_start_date) & (df.trade_date <= df.payment_date)]
    dff = dff.groupby("cfin")["trade_date"].min().reset_index()
    dff = df.reset_index().merge(dff, on=["cfin", "trade_date"]).set_index("trade_id")
    df.loc[dff.index, "is_primary"] = True

    # Change issuers' name
    df.issuer = df.apply(
        lambda x: issuer_rename(x["issuer"], x["issuer_hedge"], x["type_hedge"]), axis=1
    )

    df = df[df.trade_date >= pd.to_datetime(start_date)]

    # Convert dates to strings
    for c in [
        "maturity_date",
        "payment_date",
        "initial_date",
        "settlement_date",
        "trade_date",
    ]:
        df.loc[:, c] = pd.to_datetime(df.loc[:, c], errors="coerce").dt.strftime(
            "%Y-%m-%d"
        )

    # Add default values for Maturity Date
    df.maturity_date = df.maturity_date.fillna("-")

    # Merge rows with duplicated trade_id, multi hedging
    duplicated_ids = list(df[df.index.duplicated()].index)
    if duplicated_ids:
        for trade_id in duplicated_ids:
            dff = df[df.index == trade_id]
            issuers = [x.split(", ") for x in list(dff.issuer)]
            issuer = f"{issuers[0][0]}, " + ", ".join([x[1] for x in issuers])
            df.loc[trade_id, "issuer"] = issuer
        df = df[~df.index.duplicated(keep="first")]
    return df


@timeit
def last_trades(n=15, listed=False):
    order_type = case(
        [(Rkoperation.opquantite + Rkoperation.opquantitebroker > 0, "Sell")],
        else_="Buy",
    )

    size_traded = func.abs(Emission.emnominal * Rkoperation.opquantite)

    tiers_otc = aliased(Tier)

    # Define scope of books
    book_scopes = [y for x in books.values() for y in x]

    result = (
        db.session.query(
            Rkoperation.opticket.label("trade_id"),
            Rkoperation.opdatemodif.label("op_timestamp"),
            Rkoperation.opdatenego.label("trade_date"),
            Rkoperation.opdaterl.label("settlement_date"),
            Emission.emdate.label("initial_date"),
            Emission.empaiement.label("payment_date"),
            Emission.emmaturite.label("maturity_date"),
            Devise.dvcodeiso.label("currency"),
            Rkoperation.opcfin.label("cfin"),
            Codif.cfcode.label("isin"),
            Tier.tinom.label("issuer"),
            tiers_otc.tinom.label("issuer_otc"),
            Instrument.ifnom.label("name"),
            order_type.label("type_order"),
            Rkoperation.opquantite.label("quantity"),
            Emission.emnominal.label("nominal"),
            size_traded.label("size_traded"),
            Rkoperation.opmontant.label("cash_traded"),
            Rkoperation.opmargevendeur.label("margin"),
            Rkvendeurcircus.vcnom.label("sales"),
            Rkdefbigbook.dbbigbook.label("book_from"),
            Rkoperation.opportef.label("book_to"),
        )
        .select_from(Rkoperation)
        .join(
            (
                Instrument,
                and_(
                    Instrument.ifcfin == Rkoperation.opcfin,
                    Instrument.ifcontrat == 1,
                    not_(
                        Instrument.iftype.in_([3, 31, 213])
                    ),  # 213 - Commission Echelon
                    or_(
                        and_(Instrument.iftypofo >= 35000, Instrument.iftypofo < 36000),
                        Instrument.iftype.in_([52, 122, 211]),
                    ),
                ),
            ),
            (Typeinstrument, Typeinstrument.tycode == Instrument.iftype),
            (Emission, Emission.emcfin == Rkoperation.opcfin),
            (
                Rkdefbigbook,
                and_(
                    Rkdefbigbook.dbbook == Rkoperation.opbook,
                    # Rkdefbigbook.dbbigbook.in_(book_scopes),   # ATTENTION
                ),
            ),
            (
                Rkbigbook,
                and_(
                    Rkbigbook.bbbigbook == Rkdefbigbook.dbbigbook,
                    Rkbigbook.bbtype != 0,
                ),
            ),
        )
        .outerjoin(
            (Alien, and_(Alien.alsjac == Rkoperation.opcfin, Alien.altype == 53)),
            (Contratotcs, Contratotcs.cocfin == Alien.alcfin),
            (tiers_otc, tiers_otc.ticode == Contratotcs.coreceveur),
            (Produit, Produit.prcfin == Rkoperation.opcfin),
            (Devise, Devise.dvcfin == Produit.prdev),
            (Tier, Tier.ticode == Emission.emissuer),
            (Rkvendeurcircus, Rkvendeurcircus.vccode == Rkoperation.opvendeur),
            (Codif, and_(Codif.cfcfin == Rkoperation.opcfin, Codif.cfsource == 6)),
        )
        .filter(
            and_(
                Rkoperation.opannule == None,
                Rkoperation.opdatemodif != None,
                Rkoperation.opflag != 3,
                not_(Rkoperation.opinformation.in_([1, 4, 6])),
                Rkoperation.opotype == 51,  # Type Flux
                or_(Rkvendeurcircus.vccode != -1, Rkvendeurcircus.vccode == None,),
            ),
        )
        .order_by(Rkoperation.opdatemodif.desc())
        .limit(n)
    )

    df = pd.DataFrame(result)

    # Correct margin level to display as commercial margin
    # 2x for OTC, 1x for External
    df.margin = df.apply(
        lambda x: 2 * x["margin"] if x["issuer_otc"] else x["margin"], axis=1
    )

    df = df.set_index("trade_id")

    # Assign - if ISIN is missing
    df["isin"] = df["isin"].fillna(" - ")

    return df


def category_trade(row):
    try:
        if "MINI FUT" in row.get("product_type", ""):
            return "Mini Future"
        elif row.issuer in [
            "Exane Finance",
            "Exane Finance gagé",
            "Ixios Gold Fund",
        ]:
            return row.issuer
        else:
            return "External"
    except Exception as e:
        print(
            f'Cfin: {row.get("cfin")} - {row.get("name")} - Type: {row.get("product_type")} - {e}'
        )
        return "Missing"


def historical_prices_exane_and_reuters(cfin, formatting=False):
    # Check if alien 14 exists
    cfin_contrib = Alien.query.filter(Alien.alsjac == cfin, Alien.altype == 14).first()
    if cfin_contrib:
        cfin = cfin_contrib.alcfin

    # First get results from Exane historical database
    query_exane = db.session.query(
        Historiques.hodate.label("date"),
        func.round(Historiques.hobid, 2).label("bid"),
        func.round(Historiques.hoask, 2).label("ask"),
    ).filter(Historiques.hocfin == cfin)
    df_exane = pd.DataFrame(query_exane, columns=["date", "bid", "ask"])

    # Get results from ContribNext database to get what we receive from Reuters
    query_reuters = db.session.query(
        HwarDrEx.hxdate.label("date"),
        func.round(HwarDrEx.hxbid, 2).label("bid"),
        func.round(HwarDrEx.hxtheo, 2).label("theo"),
        func.round(HwarDrEx.hxmargebid_v, 3).label("bid_margin"),
        func.round(HwarDrEx.hxmargeask_v, 3).label("ask_margin"),
    ).filter(HwarDrEx.hxcfin == cfin)
    df_reuters = pd.DataFrame(query_reuters)

    if df_exane.empty and df_reuters.empty:
        return df_exane

    if df_reuters.empty:
        df = df_exane
    else:
        df_exane.date = pd.to_datetime(df_exane.date)
        df = pd.merge(df_exane, df_reuters, how="left", on=["date", "bid"])

    df = df.sort_values(by="date", ascending=False)

    df = df.dropna(subset=["bid"])

    if formatting:
        df.date = df.date.apply(to_str_date)
        df.columns = [x.title().replace("_", " ") for x in df.columns]

    return df


def histo_prices(cfins, start_date=None, end_date=None):
    """This method returns a DataFrame of the Historical Values of "close" of given Cfins

    cfins: List of Strings
    start_date: Date as Datetime
    end_date: Date as Datetime
    """

    if not isinstance(cfins, list):
        cfins = [cfins]

    if not start_date:
        start_date = dt(2000, 1, 1)

    if isinstance(start_date, str):
        start_date = try_parsing_date(start_date)

    if not end_date:
        end_date = dt_today()

    elif isinstance(end_date, str):
        end_date = try_parsing_date(end_date)

    r = (
        db.session.query(
            Historiques.hocfin.label("Cfin"),
            Instrument.ifnom.label("Name"),
            Historiques.hodate.label("Date"),
            Historiques.hoclose.label("Close"),
            Historiques.hobid.label("Bid"),
        )
        .select_from(Historiques)
        .join(
            (Instrument, Instrument.ifcfin == Historiques.hocfin),
            (Produit, Produit.prcfin == Instrument.ifcfin),
        )
        .filter(
            (Historiques.hocfin.in_(cfins)),
            (Historiques.hodate >= start_date),
            (Historiques.hodate <= end_date),
            (Historiques.homarche == Produit.prmarche),
        )
        .order_by(Historiques.hodate)
    )

    return pd.DataFrame(r)


def margin_bid(cfin, start_date=None, end_date=None):
    if not start_date:
        start_date = dt(2000, 1, 1)

    if isinstance(start_date, str):
        start_date = dt.strptime(start_date, "%Y%m%d")

    if not end_date:
        end_date = dt_today()
    elif isinstance(end_date, str):
        end_date = dt.strptime(end_date, "%Y%m%d")

    result = (
        db.session.query(
            VCfinMarges.cfin.label("Cfin"),
            VCfinMarges.marge_bid_vente.label("margin_bid"),
            VCfinMarges.date_cours.label("Date"),
        )
        .filter(VCfinMarges.cfin == (cfin))
        .filter(VCfinMarges.date_cours >= start_date)
        .filter(VCfinMarges.date_cours <= end_date)
    )

    df = pd.DataFrame(result)
    if not df.empty:
        return df.sort_values(by="Date")
    return df

    # if not df.empty:
    #     dff = pd.pivot(df, index="Date", columns="Cfin", values="Close")
    #     dff = dff.sort_values(by="Date", ascending=False)
    #     dff.fillna(method='bfill', inplace=True)
    #     return dff
    # else:
    #     return df


# @timeit
# def margin_details(cfin):
#
#     min_date = (
#         db.session.query(func.min(VCfinMarges.date_cours).label("Date"))
#         .filter(VCfinMarges.cfin == (cfin), VCfinMarges.marge_bid_vente != None,)
#         .subquery()
#     )
#     max_date = (
#         db.session.query(func.max(VCfinMarges.date_cours).label("Date"))
#         .filter(VCfinMarges.cfin == (cfin), VCfinMarges.marge_bid_vente != None,)
#         .subquery()
#     )
#
#     result = db.session.query(
#         VCfinMarges.cfin.label("cfin"),
#         VCfinMarges.date_cours.label("date"),
#         VCfinMarges.marge_bid_vente.label("marginBid"),
#         VCfinMarges.marge_ask_vente.label("marginAsk"),
#     ).filter(
#         VCfinMarges.cfin == (cfin),
#         or_(VCfinMarges.date_cours == min_date, VCfinMarges.date_cours == max_date,),
#     )
#
#     df = pd.DataFrame(result)
#     if not df.empty:
#         return df.sort_values(by="date")
#     return df
#
#     # if not df.empty:
#     #     dff = pd.pivot(df, index="Date", columns="Cfin", values="Close")
#     #     dff = dff.sort_values(by="Date", ascending=False)
#     #     dff.fillna(method='bfill', inplace=True)
#     #     return dff
#     # else:
#     #     return df


def margin_details(cfin, format=None):
    result = (
        db.session.query(
            Margin.START_DATE.label("start_date"),
            Margin.END_DATE.label("end_date"),
            Margin.TYPE.label("type"),
            BidMargin.start_value.label("bid_start_margin"),
            BidMargin.end_value.label("bid_end_margin"),
            BidMargin.named_type.label("bid_amort_type"),
            Ask_margin.start_value.label("ask_start_margin"),
            Ask_margin.end_value.label("ask_end_margin"),
            Ask_margin.named_type.label("ask_amort_type"),
            Emission.emprix.label("issue_price"),
        )
        .join(
            (
                BidMargin,
                and_(
                    BidMargin.cfin == Margin.CFIN,
                    BidMargin.margin_profile == Margin.MARGIN_PROFILE,
                    BidMargin.order == Margin.order,
                ),
            ),
            (
                Ask_margin,
                and_(
                    Ask_margin.cfin == Margin.CFIN,
                    Ask_margin.margin_profile == Margin.MARGIN_PROFILE,
                    Ask_margin.order == Margin.order,
                ),
            ),
            (Emission, Emission.emcfin == Margin.CFIN),
        )
        .filter(
            and_(
                Margin.CFIN == cfin,
                Margin.MARGIN_PROFILE == "SALES_PROFILE",
                Margin.START_DATE != datetime.date(1900, 1, 1),
            )
        )
    )
    df = pd.DataFrame(result)
    if not df.empty:
        df = df.sort_values(by="start_date")

        df.issue_price = df.issue_price.apply(lambda x: float(x))

        init_bid_margin = sum(df["bid_start_margin"]) / df["issue_price"] * 100
        init_ask_margin = sum(df["ask_start_margin"]) / df["issue_price"] * 100

        # Calculate decreasing levels of bid margin
        df["amortized_bid"] = (
            (df["bid_start_margin"] - df["bid_end_margin"]) / df["issue_price"] * 100
        ).round(2)
        df["end_level_bid_margin"] = (
            init_bid_margin - df["amortized_bid"].cumsum()
        ).round(2)
        df["start_level_bid_margin"] = (
            df["end_level_bid_margin"] + df["amortized_bid"]
        ).round(2)

        # Calculate decreasing levels of ask margin
        df["amortized_ask"] = (
            (df["ask_start_margin"] - df["ask_end_margin"]) / df["issue_price"] * 100
        ).round(2)
        df["end_level_ask_margin"] = (
            init_ask_margin - df["amortized_ask"].cumsum()
        ).round(2)
        df["start_level_ask_margin"] = (
            df["end_level_ask_margin"] + df["amortized_ask"]
        ).round(2)

    if format == "dict":
        return df.to_dict(orient="records")

    return df


def levels_margins(cfin):

    max_date = (
        db.session.query(func.max(HwarDrEx.hxdate).label("Date"))
        .filter(HwarDrEx.hxcfin == cfin)
        .subquery()
    )

    margin_last = (
        db.session.query(
            HwarDrEx.hxmargebid_v.label("bid_margin"),
            HwarDrEx.hxmargeask_v.label("ask_margin"),
            HwarDrEx.hxcfin.label("cfin"),
        )
        .filter(and_(HwarDrEx.hxdate == max_date, HwarDrEx.hxcfin == cfin))
        .subquery()
    )

    margin_init = (
        db.session.query(
            VMargesInitiales.date_maj_marge_ask.label("date_maj_ask"),
            VMargesInitiales.marge_initiale_ask.label("margin_ask_init"),
            VMargesInitiales.date_maj_marge_bid.label("date_maj_bid"),
            VMargesInitiales.marge_initiale_bid.label("margin_bid_init"),
            VMargesInitiales.cfin,
        )
        .filter(and_(VMargesInitiales.cfin == cfin))
        .subquery()
    )

    result = (
        db.session.query(
            margin_last.c.bid_margin,
            margin_last.c.ask_margin,
            Emission.emcfin.label("cfin"),
            margin_init.c.date_maj_ask,
            margin_init.c.margin_ask_init,
            margin_init.c.date_maj_bid,
            margin_init.c.margin_bid_init,
            Last.labid.label("last_bid"),
            Last.laask.label("last_ask"),
            Last.ladate.label("last_date"),
            Emission.emprix.label("issue_price"),
        )
        .select_from(margin_last)
        .outerjoin(
            (margin_init, margin_init.c.cfin == margin_last.c.cfin),
            (Emission, Emission.emcfin == margin_last.c.cfin),
            (Last, Last.lacfin == margin_last.c.cfin),
        )
    )

    df = pd.DataFrame(result)

    # Add last Bid and Ask levels from the Contrib service
    df_contrib = ContribHisto().intraday_last([cfin])
    if isinstance(df_contrib, pd.DataFrame) and not df_contrib.empty:
        # Keep only the last value
        df_contrib = df_contrib[df_contrib.index == max(df_contrib.index)]

        # Merge with the existing data
        if not df.empty:
            df = pd.merge(df, df_contrib, on="cfin", how="left")
        else:
            df = df_contrib.copy()

    if not df.empty:

        float_columns = [
            "bid",
            "last_bid",
            "ask",
            "last_ask",
            "bid_margin",
            "ask_margin",
            "margin_bid_init",
            "margin_ask_init",
        ]
        for col in float_columns:
            if col in df.columns:
                try:
                    df[col] = round(float(df[col]), 2)
                except:
                    pass

        dates = ["date_maj_bid", "date_maj_ask", "last_date"]
        for col in dates:
            if col in df.columns:
                df[dates] = df[dates].applymap(to_str_date)

        if "timestamp" in df.columns:
            df["timestamp"] = df["timestamp"].map(
                lambda x: to_str_date(x, "%b %d, %Y at %Hh%M")
            )

        return df.to_dict(orient="records")[0]

    # In case the product is not contributed by our systems, just take the Last values
    result = (
        db.session.query(
            Last.ladate.label("last_date"), Last.lapriclos.label("last_close")
        )
        .filter(Last.lacfin == cfin)
        .first()
    )

    if result:
        return {
            "cfin": cfin,
            "last_date": to_str_date(result.last_date, "%b %d, %Y at %Hh%M"),
            "last_bid": result.last_close - 0.5,
            "last_ask": result.last_close + 0.5,
        }

    return {}


@timeit
def category_for_cfins(cfins):
    result = (
        db.session.query(
            Instrument.ifcfin.label("Cfin"),
            VTypofoLibelle.libelle_deduit.label("Category"),
        )
        .select_from(Instrument)
        .outerjoin(VTypofoLibelle, VTypofoLibelle.code_typo == Instrument.iftypofo)
        .filter(Instrument.ifcfin.in_(cfins))
    )
    if result:
        return pd.DataFrame(result)


@timeit
def live_contrib_for_cfins(cfins):
    last_intra = (
        db.session.query(
            IntradayDer.iddcfin.label("cfin"),
            func.max(IntradayDer.iddstamp).label("timestamp"),
        )
        .filter(IntradayDer.iddcfin.in_(cfins))
        .group_by(IntradayDer.iddcfin)
        # .all()
        .subquery()
    )

    result = (
        db.session.query(
            last_intra.c.cfin,
            IntradayDer.iddbid.label("bid"),
            IntradayDer.iddask.label("ask"),
            IntradayDer.iddstamp.label("timestamp"),
        )
        .join(
            IntradayDer,
            and_(
                IntradayDer.iddcfin == last_intra.c.cfin,
                IntradayDer.iddstamp == last_intra.c.timestamp,
            ),
        )
        .all()
    )

    return {
        x.cfin: {"bid": x.bid, "ask": x.ask, "timestamp": x.timestamp,} for x in result
    }


@timeit
def prices_reuters(cfins):
    result = db.session.query(
        ExternalInstrumentClose.timestamp.label("date"),
        ExternalInstrumentClose.last.label("close_reuters"),
    ).filter(ExternalInstrumentClose.cfin.in_(cfins))
    df = pd.DataFrame(result)

    if not df.empty:
        df = df.sort_values(by="date", ascending=False)

    return df


@timeit
def contrib_and_margins(cfins, with_reuters=False):
    if not isinstance(cfins, list):
        cfins = [cfins]

    result = (
        db.session.query(
            VCfinMarges.date_cours.label("date"),
            Historiques.hobid.label("bid"),
            Historiques.hoask.label("ask"),
            VCfinMarges.marge_bid_vente.label("margin_bid"),
            VCfinMarges.marge_ask_vente.label("margin_ask"),
        )
        .join(
            Historiques,
            and_(
                Historiques.hodate == VCfinMarges.date_cours,
                Historiques.hocfin == VCfinMarges.cfin,
            ),
        )
        .filter(VCfinMarges.cfin.in_(cfins), VCfinMarges.event == "C")
    ).all()

    df = pd.DataFrame(result)

    if not df.empty:
        df = df.drop_duplicates(subset="date", keep="first")
        df = df.sort_values(by="date")
        df = df.reset_index()

    if with_reuters:
        df_reuters = prices_reuters(cfins)
        if not df_reuters.empty:
            df = df.merge(df_reuters, how="left")
        else:
            df["close_reuters"] = np.NaN

    return df


@timeit
def implied_vol(cfins, nb_days=None, start_date=None, end_date=None):
    if not isinstance(cfins, list):
        cfins = [cfins]

    if not nb_days:
        nb_days = 30

    if not start_date:
        start_date = dt(2000, 1, 1)

    if isinstance(start_date, str):
        start_date = dt.strptime(start_date, "%Y%m%d")

    if not end_date:
        end_date = dt_today()
    elif isinstance(end_date, str):
        end_date = dt.strptime(end_date, "%Y%m%d")

    result = (
        db.session.query(
            Hsmiles.smcfin.label("Cfin"),
            Hsmiles.smdate.label("Strike Date"),
            Hsmiles.smdatematu.label("Maturity Date"),
            Hsmiles.smforward.label("Forward"),
            Hsmiles.smvatm.label("ATM IV"),
            Hsmiles.smsmile.label("Smile"),
            Hsmiles.smcurve.label("Curve"),
            Hsmiles.smerreur.label("Error"),
        )
        .filter(Hsmiles.smcfin.in_(cfins))
        .filter(Hsmiles.smflag_etat == 3)
        .filter(Hsmiles.smnbjours == nb_days)
        .filter(Hsmiles.smdate <= end_date)
        .filter(Hsmiles.smdate >= start_date)
        .order_by(Hsmiles.smdate.desc())
    )

    return pd.DataFrame(result)


@timeit
def implied_vol_live(cfins, nb_days=None, fields=None):
    """Returns the volatility for a given Cfin and a number of days

    If the number of days is not mentioned, the function returns a DataFrame of all the maturities
    available in the Database

    The possible values for Fields are datematu, nbjours, forward, vatm, smile, curve, erreur

    :parameter cfins : List of Integers
    :parameter nb_days : Integer (Optional)
    :parameter fields : List of Strings
    """

    if not isinstance(cfins, list):
        cfins = [cfins]

    if not isinstance(nb_days, list):
        nb_days = [nb_days]

    if isinstance(fields, str):
        fields = [fields]

    if fields is None:
        fields = [
            "datematu",
            "nbjours",
            "forward",
            "vatm",
            "smile",
            "curve",
            "erreur",
        ]

    query_fields = [Hsmiles.__dict__[f"sm{k}"] for k in fields]

    result = db.session.query(Hsmiles.smcfin, *query_fields).filter(
        and_(
            Hsmiles.smcfin.in_(cfins),
            Hsmiles.smflag_etat == 2,
            Hsmiles.smdatematu >= dt_today(),
        )
    )

    # Filter if you need only a specific maturity in days
    if nb_days:
        result = result.filter(Hsmiles.smnbjours.in_(nb_days))

    df = pd.DataFrame(result)

    # Drop duplicates
    df = df.drop_duplicates(subset="smcfin", keep="first")

    names = {
        "smcfin": "Cfin",
        "smdatematu": "Maturity Date",
        "smnbjours": "Nb Days",
        "smforward": "Forward",
        "smvatm": "Implied Vol",
        "smsmile": "Smile",
        "smcurve": "Curve",
        "smerreur": "Error",
    }

    # Replace column names with understandable names
    df.columns = [names.get(x, x) for x in df.columns]

    return df


@timeit
def opinions_stocks():
    date = dt_today()

    converted_opinion_stocks = case(
        [
            (Afsociete.soopinionvaleur == 1, "Underperform"),
            (Afsociete.soopinionvaleur == 2, "Neutral"),
            (Afsociete.soopinionvaleur == 4, "Outperform"),
        ],
        else_="No Opinion",
    )

    converted_opinion_sectors = case(
        [
            (Afstoxx_sectors.opinion == 1, "Underperform"),
            (Afstoxx_sectors.opinion == 2, "Neutral"),
            (Afstoxx_sectors.opinion == 4, "Outperform"),
        ],
        else_="No Opinion",
    )

    # Change the currency GBP to GBp (Research Team gives values in Pence)
    adjusted_currency = case(
        [(Devise.dvcodeiso == "GBP", "GBp")], else_=Devise.dvcodeiso,
    )

    # Convert historical value to pence
    adjusted_close = case(
        [(Devise.dvcodeiso == "GBP", Historiques.hoclose * 100.0),],
        else_=Historiques.hoclose,
    )

    # Query to get the sectors' reco
    result = (
        db.session.query(
            Instrument.ifcfin.label("Cfin"),
            Collection.cldatein.label("Covered Since"),
            Codes.cfcode.label("Ticker"),
            Instrument.ifnom.label("Name"),
            Pays.paabrege.label("Country"),
            converted_opinion_stocks.label("Opinion"),
            Afsecteur.senomanglais.label("Sector"),
            converted_opinion_sectors.label("Opinion Sector"),
            adjusted_currency.label("Crncy"),
            Baction.acmktcap.label("MCap EURm"),
            adjusted_close.label("Last"),
            Afsociete.soobjhaut.label("12m Target"),
            Afsociete.soobjhaut.label("Performance"),
            Baction.acrdtbrutdiv_next.label("Next Div Yield"),
        )
        .select_from(Instrument)
        .join(
            (
                Codes,
                and_(
                    Codes.cfcfin == Instrument.ifcfin,
                    Codes.cfsource == 11,
                    not_(Codes.cfmarche.in_([0, 909, 920])),
                ),
            ),
            (
                Collection,
                and_(
                    Collection.clsjac == Codes.cfcfin,
                    Collection.cldatein <= date,
                    Collection.cldateout >= date,
                ),
            ),
            (Afsociete, Afsociete.socfin == Collection.clsjac),
            (Afsecteur, Afsecteur.secfin == Collection.clcollect),
            (Produit, Produit.prcfin == Collection.clsjac),
            (Devise, Devise.dvcfin == Produit.prdev),
            (Pays, Pays.pacode == Produit.prpays),
        )
        .outerjoin(
            (
                Afstoxx_sectors_link,
                and_(
                    Afstoxx_sectors_link.codeexane == Afsecteur.secfin,
                    Afstoxx_sectors_link.enddate == None,
                ),
            ),
            (Afstoxx_sectors, Afstoxx_sectors.code == Afstoxx_sectors_link.codestoxx,),
            (Baction, Baction.accfin == Collection.clsjac),
            (
                Historiques,
                and_(
                    Historiques.hocfin == Collection.clsjac,
                    Historiques.hodate == prev_bday(),
                ),
            ),
        )
        # .filter(Instruments.ifcfin == 59)
    )

    df = pd.DataFrame(result)

    # Expected performance
    df["Performance"] = df["12m Target"] / df["Last"] - 1.0

    # Convert columns types to DateTime, String or Category
    df[["Ticker", "Name", "Country", "Crncy"]] = df[
        ["Ticker", "Name", "Country", "Crncy"]
    ].astype(pd.StringDtype())
    df[["Opinion", "Sector", "Opinion Sector"]] = df[
        ["Opinion", "Sector", "Opinion Sector"]
    ].astype("category")

    # Format Market Cap in millions
    df["MCap EURm"] = df["MCap EURm"] / 1000000

    # Sort values by their performances
    df = df.sort_values(by="Performance", ascending=False)

    return df


def contributions(cfin, one_value=True):
    """This method returns a DataFrame of the Historical Values of given Cfins of External Structured Products

    The possible values for Fields are

    Every day at 7:31 p.m., and subject to the availability of these fields,
    an end-of-day cut-off is made in the following table
    CONTRIBNEXT.EXTERNAL_INSTRUMENT_CLOSE

    Then, a calculation module of the closing prices will retrieve the last recorded, the backup date,
    apply any margins that may have been defined, and publish/save the bid/ask
    that may have been marked with the value date corresponding to that of the record, in the following tables
    EXANE.LAST and EXANE.HISTORIQUES

    :parameter
    cfins: List of Strings of Cfins of External Structured Products
    start_date: Date as Datetime
    end_date: Date as Datetime
    fields: String or List of Strings
    """

    lien_otc, lien_position = aliased(Alien), aliased(Alien)
    tiers_otc, tiers_titre = aliased(Tier), aliased(Tier)

    last_date_update = (
        db.session.query(Last.lacfin, func.max(Last.ladate).label("last_date"))
        .group_by(Last.lacfin)
        .subquery()
    )

    result = (
        db.session.query(
            Instrument.ifcfin.label("cfin"),
            Codif.cfcode.label("isin"),
            tiers_titre.tinom.label("issuer"),
            tiers_otc.tinom.label("issuer_otc"),
            Instrument.ifnom.label("name"),
            Emission.emdate.label("initial_date"),
            Emission.empaiement.label("payment_date"),
            Emission.emmaturite.label("maturity_date"),
            Last.ladate.label("last_date"),
            Last.labid.label("last_bid"),
            Last.ladatepr.label("last_prev_date"),
            Last.labidpr.label("last_prev_bid"),
            lien_otc.alcfin.label("cfin_otc"),
            lien_position.alsjac.label("cfin_position"),
            Typestatut.tstnom.label("status"),
            Typeetatdevie.tvlibelle.label("etat_vie_lib"),
            Typeetatdevie.tvcode.label("etat_vie_code"),
        )
        .select_from(Instrument)
        .outerjoin(
            (Typestatut, Typestatut.tstcode == Instrument.ifstatut),
            (Emission, Emission.emcfin == Instrument.ifcfin),
            (Instrumentcomplement, Instrumentcomplement.iccfin == Instrument.ifcfin,),
            (Typeetatdevie, Typeetatdevie.tvcode == Instrumentcomplement.icetatdevie,),
            (Codif, and_(Codif.cfcfin == Instrument.ifcfin, Codif.cfsource == 6)),
            (last_date_update, last_date_update.c.lacfin == Instrument.ifcfin),
            (
                Last,
                and_(
                    Last.lacfin == Instrument.ifcfin,
                    Last.ladate == last_date_update.c.last_date,
                ),
            ),
            (
                lien_otc,
                and_(lien_otc.alsjac == Instrument.ifcfin, lien_otc.altype == 53),
            ),
            (
                lien_position,
                and_(
                    lien_position.alcfin == Instrument.ifcfin,
                    lien_position.altype == 14,
                ),
            ),
            (Contratotcs, Contratotcs.cocfin == lien_otc.alcfin),
            (tiers_titre, tiers_titre.ticode == Emission.emissuer),
            (tiers_otc, tiers_otc.ticode == Contratotcs.coreceveur),
        )
        .filter(Instrument.ifcfin == cfin)
    ).first()

    d = result._asdict()

    d["issuer"] = issuer_rename(d["issuer"], d["issuer_otc"])

    d["ric"] = get_ric_code(cfin)

    d["days_late"] = np.busday_count(d["payment_date"], dt_today())

    to_str_date = lambda x: x.strftime("%b %d, %Y") if x else "N/A"
    to_str_price = lambda x: "{:,.2f}".format(x) if x else "N/A"

    func_convert = {
        "initial_date": to_str_date,
        "payment_date": to_str_date,
        "maturity_date": to_str_date,
        "last_date": to_str_date,
        "last_prev_date": to_str_date,
        "last_bid": to_str_price,
        "last_prev_bid": to_str_price,
    }

    for field in func_convert:
        d[field] = func_convert[field](d[field])

    return d


def position_in_and_out_amc(cfins):
    # Get the Trading Positions
    trading_positions = Positions().book_positions(cfins)
    positions = {}
    for position in trading_positions:
        cfin = position["cfin"]
        book_id = position["bookId"]
        issued_details = position.get("issueDetails")
        if issued_details:
            invested = issued_details.get("investedPosition")
            if invested != 0:
                # Check if product is a mini fut or not, if yes display in units
                if cfin not in positions:
                    positions[cfin] = -invested
                else:
                    positions[cfin] += abs(invested)

    # Get the Client Positions
    client_positions = OpenPositions().positions_for_cfins(cfins, result_type="units")
    if client_positions:
        for cfin in client_positions.keys():
            if cfin in positions:
                positions[cfin] = max(positions[cfin], client_positions[cfin])
            else:
                positions[cfin] = client_positions[cfin]

    df = pd.DataFrame.from_dict(positions, orient="index").reset_index()

    if not df.empty:
        df.columns = ["cfin", "position"]
        return df
    return pd.DataFrame()


def standard_dev_last_reuters(cfins):
    query = (
        db.session.query(
            ExternalInstrumentClose.cfin,
            func.stddev(ExternalInstrumentClose.bid).label("stddev_bid"),
        )
        .filter(
            ExternalInstrumentClose.cfin.in_(cfins),
            ExternalInstrumentClose.timestamp > prev_bday(5),
        )
        .group_by(ExternalInstrumentClose.cfin)
        .subquery()
    )

    df = pd.DataFrame(query)

    return df


@timeit
def cube_calculations_issues():

    df = contribution_issues(all=True)

    # Add last Cube calculation date
    r = (
        db.session.query(
            Rkcube.cucfinproduit.label("cfin"),
            func.max(Rkcube.cudatecalcul).label("last_calc_date"),
        ).filter(Rkcube.cucfinproduit.in_(list(df.cfin)))
        # .filter(Rkpricing.prcfin == 38141771)
        .group_by(Rkcube.cucfinproduit)
    )

    df_cube = pd.DataFrame(r)

    dff = pd.merge(df, df_cube, on="cfin", how="outer")

    return dff[dff.last_calc_date.isna()]


@timeit
def contribution_issues(format=None, all=False):

    tiers_otc, tiers_titre = aliased(Tier), aliased(Tier)

    CodesRic = aliased(Codes)
    CodesExternalRef = aliased(Codes)

    last_date_reuters = (
        db.session.query(
            ExternalInstrumentClose.cfin,
            func.max(ExternalInstrumentClose.timestamp).label("last_date"),
        )
        .group_by(ExternalInstrumentClose.cfin)
        .subquery()
    )

    last_date_shredder = (
        db.session.query(
            Closer_shredder_h.instrument_cfin,
            func.max(Closer_shredder_h.price_timestamp).label("last_date"),
        )
        .group_by(Closer_shredder_h.instrument_cfin)
        .subquery()
    )

    # First get all cfins that are being contributed and previous Bday value
    r = (
        db.session.query(
            ExternalInstrument.instrument_cfin.label("cfin"),
            Alien.alcfin.label("cfin_otc"),
            Codif.cfcode.label("isin"),
            ExternalInstrument.ric.label("ric"),
            CodesRic.cfcode.label("external_ric"),
            CodesExternalRef.cfcode.label("external_ref"),
            tiers_titre.tinom.label("issuer"),
            tiers_otc.tinom.label("issuer_otc"),
            Instrument.ifnom.label("name"),
            Emission.emprix.label("issue_price"),
            Emission.emdate.label("initial_date"),
            Emission.empaiement.label("payment_date"),
            Emission.emmaturite.label("maturity_date"),
            ExternalInstrumentClose.last.label("last_reuters"),
            ExternalInstrumentClose.timestamp.label("last_reuters_date"),
            Closer_shredder_h.bid.label("last_schredder"),
            Closer_shredder_h.instrument_valuedate.label("last_schredder_date"),
        )
        .select_from(ExternalInstrument)
        .join(
            (Instrument, Instrument.ifcfin == ExternalInstrument.instrument_cfin),
            (Emission, Emission.emcfin == Instrument.ifcfin),
            (Produit, Produit.prcfin == Instrument.ifcfin),
            (Instrumentcomplement, Instrumentcomplement.iccfin == Instrument.ifcfin,),
            (Typestatut, Typestatut.tstcode == Instrument.ifstatut),
            (Typeetatdevie, Typeetatdevie.tvcode == Instrumentcomplement.icetatdevie,),
        )
        .outerjoin(
            (last_date_reuters, last_date_reuters.c.cfin == Instrument.ifcfin),
            (
                ExternalInstrumentClose,
                and_(
                    ExternalInstrumentClose.cfin == ExternalInstrument.instrument_cfin,
                    ExternalInstrumentClose.timestamp == last_date_reuters.c.last_date,
                ),
            ),
            (Codif, and_(Codif.cfcfin == Instrument.ifcfin, Codif.cfsource == 6)),
            (
                CodesRic,
                and_(CodesRic.cfcfin == Instrument.ifcfin, CodesRic.cfsource == 334),
            ),
            (
                CodesExternalRef,
                and_(
                    CodesExternalRef.cfcfin == ExternalInstrument.instrument_cfin,
                    CodesExternalRef.cfsource == 335,
                ),
            ),
            (
                last_date_shredder,
                last_date_shredder.c.instrument_cfin == Instrument.ifcfin,
            ),
            (
                Closer_shredder_h,
                and_(
                    Closer_shredder_h.instrument_cfin == Instrument.ifcfin,
                    Closer_shredder_h.price_timestamp == last_date_shredder.c.last_date,
                ),
            ),
            (Alien, and_(Alien.alsjac == Instrument.ifcfin, Alien.altype == 53),),
            (Contratotcs, Contratotcs.cocfin == Alien.alcfin),
            (tiers_titre, tiers_titre.ticode == Emission.emissuer),
            (tiers_otc, tiers_otc.ticode == Contratotcs.coreceveur),
            (
                Ask_margin,
                and_(
                    Ask_margin.cfin == Instrument.ifcfin,
                    Ask_margin.margin_profile == "TRADING_PROFILE",
                    Ask_margin.named_type == "CONSTANT",
                    Ask_margin.order == 0,
                ),
            ),
        )
        .filter(
            not_(ExternalInstrument.ric.like("%EXAP")),
            not_(Instrument.ifstatut.in_([7, 22])),
            Typeetatdevie.tvcode == 1,
            Emission.emissuer != 0,  # Issuer not None
            Instrument.ifcontrat != 2,
            or_(
                and_(Instrument.iftypofo >= 35000, Instrument.iftypofo < 36000),
                Instrument.iftype.in_([122, 211]),
            ),
            or_(Emission.emmaturite >= prev_bday(), Emission.emmaturite == None),
            # Filter if field "Mode de cotation" set to "Non Cote" in Simbad
            or_(CodesRic.cfmodecot != 0, CodesRic.cfmodecot == None),
            # Instrument.ifcfin == 43692875,
        )
    )

    df = pd.DataFrame(r)

    if all:
        return df

    # Get the contrib levels from the dedicated service
    df_contrib = ContribHisto().intraday_last(list(df.cfin))
    if not df_contrib.empty:
        df = pd.merge(df, df_contrib, on="cfin", how="left")

    # Don't consider products that are feeding correctly
    # Keep only if a or b or c
    #   a - Last Price is missing
    #   b - Last Date older than n business days
    #   c - Last Reuters Date different than Last Date

    a = df.bid.isna()
    b = df.timestamp < prev_bday(2, "datetime")
    c = df.last_reuters_date > df.timestamp.dt.date

    dff = df[a | b | c]

    if dff.empty:
        return dff

    dff.issuer = dff.apply(
        lambda x: issuer_rename(x["issuer"], x["issuer_otc"]), axis=1
    )

    dff.loc[df.payment_date == dt_today(), "issuing_today"] = True

    # Price considered too low if below 2%
    dff.loc[dff.bid / dff.issue_price < 0.02, "bid_too_low"] = True

    dff.loc[dff.bid.isna(), "last_exane_missing"] = True

    dff.loc[
        dff.timestamp.fillna(dt_today()).values.astype("datetime64[D]") < prev_bday(2),
        "last_reuters_old",
    ] = True

    dff.loc[
        dff.timestamp.fillna(dt_today()).values.astype("datetime64[D]") < prev_bday(),
        "last_exane_old",
    ] = True

    dff.loc[dff.last_reuters.isna(), "last_reuters_missing"] = True

    # dff.loc[dff.stddev_bid == 0.0, "same_last_reuters_values"] = True

    dff = dff.dropna(
        how="all",
        subset=[
            "bid_too_low",
            "issuing_today",
            "last_exane_missing",
            "last_reuters_missing",
            "last_reuters_old",
            "last_exane_old",
        ],
    )

    dff.loc[:, "days_late"] = np.busday_count(
        dff["payment_date"].fillna(dt(1970, 1, 1)).values.astype("datetime64[D]"),
        dt_today(),
    )

    dff = dff.sort_values(by="days_late", ascending=False)

    # Add positions of products
    df_pos = position_in_and_out_amc(dff.cfin.to_list())
    if not df_pos.empty:
        dff = pd.merge(dff, df_pos, on="cfin", how="left")

    dff["cause"] = dff.apply(cause_issues_contrib, axis=1)

    to_str_date = lambda x: x.strftime("%b %d, %Y")
    to_str_datetime = lambda x: x.strftime("%b %d, %Y at %Hh%M")
    to_str_price = lambda x: "{:,.2f}".format(x)

    func_convert = {
        "initial_date": to_str_date,
        "payment_date": to_str_date,
        "maturity_date": to_str_date,
        "last_date": to_str_datetime,
        # "last_prev_date": to_str_date,
        "bid": to_str_price,
        # "last_prev_bid": to_str_price,
        "last_reuters_date": to_str_date,
        "last_reuters": "{:,.2f}".format,
    }

    for col in func_convert:
        if col in dff.columns:
            dff[col] = dff[col].map(func_convert[col], na_action="ignore").fillna("N/A")

    # Get links to termsheets
    termsheets = {}
    for cfin in dff.cfin:
        ts = {}
        ts_data = get_termsheets(cfin)
        k = 1
        for key, value in ts_data.items():
            if key != "Exane":
                ts[f"Hedge {k}"] = value
            else:
                ts["Exane"] = value
        termsheets[cfin] = ts

    df_t = pd.DataFrame.from_dict(termsheets, orient="index").reset_index()
    dff = dff.merge(df_t, left_on="cfin", right_on="index")
    dff = dff.drop(columns="index")

    if format == "dict":
        return dff.to_dict("records")

    return dff


def alien(cfin, product_type="cfin", with_issuer=False):

    if cfin != "None":

        tiers_otc, tiers_hedge = aliased(Tier), aliased(Tier)

        issuer = case(
            [(tiers_otc.tinom != None, tiers_otc.tinom)], else_=tiers_hedge.tinom
        )

        type_hedge = case([(tiers_otc.tinom != None, "OTC")], else_="Note")

        result = (
            db.session.query(
                Alien.alcfin.label("cfin"),
                Instrument.ifnom.label("name"),
                Alien.alsjac.label("sjac"),
                Alien.altype.label("type"),
                Typelien.tlnom.label("type_name"),
                issuer.label("issuer_hedge"),
                type_hedge.label("type_hedge"),
            )
            .join(
                (Typelien, Typelien.tlcode == Alien.altype),
                (Instrument, Instrument.ifcfin == Alien.alcfin),
            )
            .outerjoin(
                (Emission, Emission.emcfin == Alien.alcfin),
                (tiers_hedge, tiers_hedge.ticode == Emission.emissuer),
                (Contratotcs, Contratotcs.cocfin == Alien.alcfin),
                (tiers_otc, tiers_otc.ticode == Contratotcs.coreceveur),
            )
            .filter(or_(Alien.alsjac == cfin, Alien.alcfin == cfin))
        ).all()

        l = [x._asdict() for x in result]

        data = {}

        if with_issuer:

            for val in l:

                issuer = issuer_rename(val["issuer_hedge"], short=True)

                d = {
                    "cfin": val[product_type],
                    "issuer": issuer,
                    "type": val["type_hedge"],
                }

                if val["type"] not in data:
                    data[val["type"]] = [d]
                else:
                    data[val["type"]].append(d)
        else:

            for val in l:
                if val["type"] not in data:
                    data[val["type"]] = [val[product_type]]
                else:
                    data[val["type"]].append(val[product_type])

        return data


def status_for_cfin(cfin):
    r = Instrument.query.filter_by(ifcfin=cfin).first()
    if r:
        return r.typestatut.tstnom


def components(cfin):
    result = (
        db.session.query(
            Composition.cpsjac.label("cfin"), Instrument.iftype.label("type"),
        )
        .join(Instrument, Instrument.ifcfin == Composition.cpsjac)
        .filter(Composition.cpcfin == cfin)
    ).all()

    l = [x._asdict() for x in result]

    d = {}
    for x in l:
        if x["type"] not in d:
            d[x["type"]] = x["cfin"]

    return d


@timeit
def data_flex():
    r = (
        db.session.query(
            Instrument.ifcfin.label("cfin"),
            Instrument.ifnom.label("name"),
            Codes.cfcode.label("isin"),
        )
        .select_from(Instrument)
        .join(
            (Emission, Emission.emcfin == Instrument.ifcfin),
            (Instrumentcomplement, Instrumentcomplement.iccfin == Instrument.ifcfin,),
            (Codes, and_(Codes.cfcfin == Instrument.ifcfin, Codes.cfsource == 11)),
        )
        .filter(
            Emission.emissuer == 144191,  # Corresponds to Exane Indice Flex
            Instrumentcomplement.icetatdevie == 1,
        )
    ).all()
    d = [x._asdict() for x in r]
    return d


@timeit
def reuters_histo(code):
    cfin = code if isinstance(code, int) else code.get("cfin")

    result = db.session.query(
        ExternalInstrumentClose.timestamp.label("Date"),
        ExternalInstrumentClose.last.label("Level"),
    ).filter(ExternalInstrumentClose.cfin == cfin)
    df = pd.DataFrame(result)

    if not df.empty:
        df = df.sort_values(by="Date", ascending=False)

    return df


@timeit
def last_updated_opinions(
    opinions=None, for_mailing=True, start_date=None, end_date=None
):
    if not opinions:
        opinions = [4]

    if not start_date:
        start_date = dt_today() - timedelta(days=7 + dt_today().weekday())

    if not end_date:
        end_date = dt_today()

    # Convert historical value to pence
    adjusted_close = case(
        [
            (Devise.dvcodeiso == "GBp", Last.lapriclos * 100.0),
            (Devise.dvcodeiso == "EUr", Last.lapriclos * 100.0),
        ],
        else_=Last.lapriclos,
    )

    # Change the currency GBP to GBp (Research Team gives values in Pence)
    adjusted_currency = case(
        [(Devise.dvcodeiso == "GBP", "GBp"), (Devise.dvcodeiso == "EUr", "EUR")],
        else_=Devise.dvcodeiso,
    )

    last_date_update = (
        db.session.query(Last.lacfin, func.max(Last.ladate).label("last_date"))
        .group_by(Last.lacfin)
        .subquery()
    )

    AfopinionsStock = aliased(Afopinion)
    AfopinionsSector = aliased(Afopinion)

    # Query to get the sectors' reco
    result = (
        db.session.query(
            Afsociete.socfin.label("cfin"),
            Afsociete.sodatedernieresereingue.label("last_modif"),
            AfopinionsStock.oplibellegb.label("stock_opinion"),
            Codes.cfcode.label("ticker"),
            Afsociete.sopdesc.label("name"),
            Pays.paabrege.label("country"),
            Secteur.sename.label("sector"),
            Collection.clcollect.label("sector_cfin"),
            AfopinionsSector.oplibellegb.label("sector_opinion"),
            adjusted_close.label("last"),
            adjusted_currency.label("ccy"),
            Afsociete.soobjhaut.label("target_price"),
            Baction.acrdtbrutdiv_next.label("next_div_yield"),
        )
        .select_from(Afsociete)
        .join(
            (
                Codes,
                and_(
                    Codes.cfcfin == Afsociete.socfin,
                    Codes.cfsource == 11,
                    Codes.cftype == 1,  # Type sous secteur
                ),
            ),
            (Afsecteur, Afsecteur.seordre == Afsociete.sotypesociete),
            (Devise, Devise.dvcfin == Afsociete.sodevise),
            (Pays, Pays.pacode == Afsociete.sopays),
            (
                Collection,
                and_(
                    Collection.clsjac == Afsociete.socfin,
                    or_(
                        Collection.cldateout >= dt_today(), Collection.cldateout == None
                    ),
                ),
            ),
            (
                Instrument,
                and_(
                    Instrument.ifcfin == Collection.clcollect, Instrument.iftype == 111,
                ),
            ),
            (
                Afstoxx_sectors_link,
                and_(
                    Afstoxx_sectors_link.codeexane == Collection.clcollect,
                    Afstoxx_sectors_link.enddate == None,
                ),
            ),
            (Afstoxx_sectors, Afstoxx_sectors.code == Afstoxx_sectors_link.codestoxx,),
            (AfopinionsStock, AfopinionsStock.opcode == Afsociete.soopinionvaleur),
            (AfopinionsSector, AfopinionsSector.opcode == Afstoxx_sectors.opinion),
            (Baction, Baction.accfin == Afsociete.socfin),
            (last_date_update, last_date_update.c.lacfin == Afsociete.socfin),
            (
                Last,
                and_(
                    Last.lacfin == Afsociete.socfin,
                    Last.ladate == last_date_update.c.last_date,
                ),
            ),
        )
        .outerjoin(
            (Emission, Emission.emcfin == Afsociete.socfin),
            (
                Hsectorisation,
                and_(
                    Hsectorisation.hstiers == Emission.emissuer,
                    Hsectorisation.hsdatein <= dt_today(),
                    or_(
                        Hsectorisation.hsdateout == None,
                        Hsectorisation.hsdateout > dt_today(),
                    ),
                ),
            ),
            (Secteur, and_(Secteur.secode == Hsectorisation.hscode,),),
        )
        .filter(
            and_(
                Afsociete.sodatedernieresereingue >= start_date,
                Afsociete.sodatedernieresereingue <= end_date,
                Afsociete.soopinionvaleur.in_(opinions),
                Secteur.setype == 5,
            )
        )
    )

    df = pd.DataFrame(result)

    df = df.drop_duplicates(subset=["ticker"])

    if not df.empty:

        # Add volatilities from SG Database
        df_vol = sg_implied_volatilites(df.ticker)
        if not df_vol.empty:
            df = pd.merge(df, df_vol, on="ticker", how="outer")

        df["upside"] = df.apply(
            lambda x: float(x["target_price"]) / float(x["last"]) - 1.0, axis=1
        )
        df = df.sort_values(by="upside", ascending=False)

        if for_mailing:
            short_name = lambda x: f"{x[:20]} ..." if len(x) > 20 else x
            short_sector = lambda x: f"{x[:17]} ..." if len(x) > 17 else x
            upside = lambda x: f"+{x:.2%}" if x > 0 else f"{x:.2%}"
            vol = lambda x: f"{x:.2%}" if not pd.isnull(x) else " - "

            d_format = {
                "name": short_name,
                "sector": short_sector,
                "upside": upside,
                "IV_12M_100%": vol,
            }

            for col in df.columns:
                if col in d_format.keys():
                    try:
                        df[col] = df[col].apply(d_format[col])
                    except Exception as e:
                        print(repr(e))

            # df_vol = implied_vol_live(cfins=list(df.Cfin), nb_days=180, fields="vatm")

            df.name = (
                df.name.str.normalize("NFKD")
                .str.encode("ascii", errors="ignore")
                .str.decode("utf-8")
            )

        return df.set_index("cfin").T.to_dict()


@timeit
# @cache.cached(timeout=86400, key_prefix="bnpp")
def last_opinions_bnpp(types_opinion=None, bdays=5, vol_sg=True, formatting=False):
    # Define list of opinions to filter

    if types_opinion is None:
        types_opinion = ["Outperform"]

    all_types_opinion = {
        "Not rated": 0,
        "Underperform": 1,
        "Neutral": 2,
        "Outperform": 4,
        "Restricted": 8,
    }

    if not types_opinion:
        # Consider all kind of recommendations
        indices_opinions = list(all_types_opinion.values())
    else:
        # List of indices of selected recommendations
        indices_opinions = [all_types_opinion[x] for x in types_opinion]

    # Convert historical value to pence
    adjusted_close = case(
        [(Devise.dvcodeiso.in_(["GBp", "EUr"]), Last.lapriclos * 100.0),],
        else_=Last.lapriclos,
    )

    # Change the currency GBP to GBp (Research Team gives values in Pence)
    adjusted_currency = case(
        [(Devise.dvcodeiso == "GBP", "GBp"), (Devise.dvcodeiso == "EUr", "EUR")],
        else_=Devise.dvcodeiso,
    )

    last_date_update = (
        db.session.query(Last.lacfin, func.max(Last.ladate).label("last_date"))
        .group_by(Last.lacfin)
        .subquery()
    )

    afopi_stock = aliased(Afopinion)
    afopi_sector = aliased(Afopinion)

    # Query to get the sectors' reco
    result = (
        db.session.query(
            func.distinct(Afsociete.socfin).label("cfin"),
            Afsociete.sodatedernieresereingue.label("last_modif"),
            Codes.cfcode.label("ticker"),
            Afsociete.sopdesc.label("name"),
            Pays.paabrege.label("country"),
            Baction.acmktcap.label("mcap_eurm"),
            afopi_stock.oplibellegb.label("opinion"),
            Afstoxx_sectors.longlabel.label("sector"),
            Afstoxx_sectors_link.codestoxx.label("sector_cfin"),
            afopi_sector.oplibellegb.label("sector_opinion"),
            adjusted_close.label("last"),
            adjusted_currency.label("ccy"),
            Afsociete.soobjhaut.label("target_price"),
            Baction.acrdtbrutdiv_next.label("next_div_yield"),
        )
        .select_from(Afsociete)
        .join(
            (
                Codes,
                and_(
                    Codes.cfcfin == Afsociete.socfin,
                    Codes.cfsource == 11,
                    Codes.cftype == 1,  # Type sous secteur
                ),
            ),
            (Afsecteur, Afsecteur.seordre == Afsociete.sotypesociete),
            (Devise, Devise.dvcfin == Afsociete.sodevise),
            (Pays, Pays.pacode == Afsociete.sopays),
            (
                Collection,
                and_(
                    Collection.clsjac == Afsociete.socfin,
                    Collection.cldateout >= dt_today(),
                ),
            ),
            (
                Instrument,
                and_(
                    Instrument.ifcfin == Collection.clcollect, Instrument.iftype == 111,
                ),
            ),
            (
                Afstoxx_sectors_link,
                and_(
                    Afstoxx_sectors_link.codeexane == Collection.clcollect,
                    Afstoxx_sectors_link.enddate == None,
                ),
            ),
            (Afstoxx_sectors, Afstoxx_sectors.code == Afstoxx_sectors_link.codestoxx,),
            (afopi_sector, afopi_sector.opcode == Afstoxx_sectors.opinion),
            (afopi_stock, afopi_stock.opcode == Afsociete.soopinionvaleur),
            (Baction, Baction.accfin == Afsociete.socfin),
            (last_date_update, last_date_update.c.lacfin == Afsociete.socfin),
            (
                Last,
                and_(
                    Last.lacfin == Afsociete.socfin,
                    Last.ladate == last_date_update.c.last_date,
                ),
            ),
        )
        .filter(
            and_(
                Afsociete.sodatedernieresereingue >= prev_bday(bdays),
                Afsociete.soopinionvaleur.in_(indices_opinions),
                # Afsociete.socfin == 100814
            )
        )
    )

    df = pd.DataFrame(result)

    df["upside"] = (df["target_price"] / df["last"] - 1.0) * 100
    df["mcap_eurm"] = df["mcap_eurm"].div(1000000)
    df["next_div_yield"] = df["next_div_yield"].div(100)

    if vol_sg:
        # Add volatilities from SG Database
        df_vol = sg_implied_volatilites(df.ticker)
        df = pd.merge(df, df_vol, on="ticker", how="outer")

    df["upside"] = df.apply(lambda x: x["target_price"] / x["last"] - 1.0, axis=1)
    df = df.sort_values(by="upside", ascending=False).reset_index(drop=True)

    if formatting:
        upside = lambda x: f"+{x:.2%}" if x > 0 else f"{x:.2%}"
        mcap = lambda x: f"{int(x):,}".replace(",", " ") if x else " - "
        vol = lambda x: f"{x:.2%}" if not pd.isnull(x) else " - "

        d_format = {
            "mcap_eurm": mcap,
            "upside": upside,
            "IV_12M_100%": vol,
        }

        for col in d_format:
            if col in df.columns:
                df[col] = df[col].apply(d_format[col])

        # Encode characters for mails
        df.name = (
            df.name.str.normalize("NFKD")
            .str.encode("ascii", errors="ignore")
            .str.decode("utf-8")
        )

    return df


@timeit
def app_products():
    products = sub_products()
    last = sub_last()
    positions = sub_positions()

    products_details = (
        db.session.query(
            products.c.cfin,
            products.c.isin,
            products.c.name,
            products.c.issuer,
            products.c.issuer_otc,
            products.c.currency,
            products.c.nominal,
            products.c.issue_date,
            products.c.maturity_date,
            last.c.bid,
            last.c.ask,
            last.c.date,
        ).outerjoin(last, last.c.cfin == products.c.cfin)
        # .filter(products.c.cfin == 27008074)
    )

    df_details = pd.DataFrame(products_details)
    # df_details.T

    products_positions = (
        db.session.query(
            positions.c.cfin,
            func.listagg(positions.c.book_from, ", ")
            .within_group(positions.c.book_from)
            .label("book"),
            func.listagg(positions.c.book_name, ", ")
            .within_group(positions.c.book_name)
            .label("book_name"),
            (-func.sum(positions.c.position)).label("position"),
        )
        .join(products, products.c.cfin == positions.c.cfin)
        .filter(positions.c.position < 0)
        # .filter(positions.c.cfin == 43692875)
        .group_by(positions.c.cfin)
    )

    df_positions = pd.DataFrame(products_positions)
    # df_positions.T

    df = pd.merge(df_details, df_positions, on="cfin", how="left")

    df.issuer = df.apply(lambda x: issuer_rename(x["issuer"], x["issuer_otc"]), axis=1)

    df = df.drop(columns=["issuer_otc"])

    col_names = {
        "isin": "ISIN",
        "issue_date": "Issue",
        "maturity_date": "Maturity",
        "date": "Last",
        "book_name": "Book Name",
    }

    all_columns = [col_names.get(x, x.title()) for x in df.columns]
    df.columns = all_columns

    # Add columns for TS and links
    df["TS"] = ""
    df["L"] = ""
    all_columns.insert(0, "L")
    all_columns.insert(1, "TS")

    # Reorder column names
    df = df[all_columns]

    # Convert dates to strings
    for c in ["Issue", "Maturity", "Last"]:
        df[c] = df[c].apply(lambda x: to_str_date(x, "%Y-%m-%d"))

    df = df.sort_values(by="Issue", ascending=False)

    return df


def underlyings_details(d, last_date=None):
    if not d:
        return []

    adjusted_opinion = case(
        [(Devise.dvcodeiso == "GBP", Afsociete.soobjhaut / 100.0)],
        else_=Afsociete.soobjhaut,
    )

    last_close = case(
        [(Historiques.hodate < Last.ladate, Historiques.hoclose)], else_=Last.lapriclos,
    )

    result = (
        db.session.query(
            Instrument.ifcfin.label("cfin"),
            Codes.cfcode.label("ticker"),
            Instrument.ifnom.label("name"),
            Devise.dvcodeiso.label("ccy"),
            Afopinion.oplibellecourtgb.label("opinion"),
            adjusted_opinion.label("upside"),
            last_close.label("last"),
            # Last.ladate.label("Last Date"),
            # Historiques.hobid.label("last_fixing_close"),
            # Historiques.hodate.label("last_fixing_date"),
        )
        .select_from(Instrument)
        .outerjoin(
            (Codes, and_(Codes.cfcfin == Instrument.ifcfin, Codes.cfsource == 11),),
            (Produit, Produit.prcfin == Instrument.ifcfin),
            (Devise, Devise.dvcfin == Produit.prdev),
            (Last, Last.lacfin == Instrument.ifcfin),
            (
                Historiques,
                and_(
                    Historiques.hocfin == Instrument.ifcfin,
                    Historiques.hodate == last_date,
                ),
            ),
            (Afsociete, Afsociete.socfin == Instrument.ifcfin),
            (Afopinion, Afopinion.opcode == Afsociete.soopinionvaleur),
        )
        .filter(
            and_(
                Instrument.ifcfin.in_(d),
                Last.lamarche == Produit.prmarche,
                Codes.cfmarche == Produit.prmarche,
                or_(~Codes.cfcode.like("% EU"), Codes.cfcode == None,),
            )
        )
    )

    df = pd.DataFrame(result)

    df.upside = pd.to_numeric(df.upside)

    return df


def cube_cpns_paid(cfin):
    last_date_update = (
        db.session.query(func.max(Rkscriptindicateur.sidate).label("date"))
        .filter(Rkscriptindicateur.sicfin == cfin)
        .subquery()
    )

    result = (
        db.session.query(
            func.regexp_replace(Rkscriptindicateur.sicle, "[^0-9]", "").label("id"),
            Rkscriptindicateur.sivaleur.label("paid"),
            Emission.emnominal.label("nominal"),
        )
        .join(
            (last_date_update, Rkscriptindicateur.sidate == last_date_update.c.date),
            (Emission, Emission.emcfin == Rkscriptindicateur.sicfin),
        )
        .filter(
            Rkscriptindicateur.sicfin == cfin,
            Rkscriptindicateur.sicle.like("CV_CouponDejaPaye%"),
        )
    )

    df = pd.DataFrame(result, columns=["id", "paid", "nominal"])
    df.id = df.id.astype(int)
    df = df.sort_values(by="id").reset_index(drop=True)

    return df


def main_details_for_cfin(cfin):
    # Alias
    lien_hedge, lien_position = aliased(Alien), aliased(Alien)
    tiers_otc, tiers_titre, tiers_hedge = aliased(Tier), aliased(Tier), aliased(Tier)
    emission_titre, emission_hedge = aliased(Emission), aliased(Emission)
    codif_isin = aliased(Codif)
    codif_ric = aliased(Codif)
    codif_external_ref = aliased(Codif)
    codif_external_ric = aliased(Codif)
    codif_external_isin = aliased(Codif)

    issuer_hedge = case(
        [(tiers_otc.tinom != None, tiers_otc.tinom)], else_=tiers_hedge.tinom
    )

    external_ref = case(
        [(codif_external_ref.cfcode != None, codif_external_ref.cfcode)],
        else_=codif_external_isin.cfcode,
    )

    type_hedge = case([(tiers_otc.tinom != None, "OTC")], else_="Note")

    df = pd.DataFrame(
        db.session.query(
            Instrument.ifcfin.label("cfin"),
            codif_isin.cfcode.label("isin"),
            codif_ric.cfcode.label("ric"),
            external_ref.label("external_ref"),
            codif_external_ric.cfcode.label("ric_code"),
            tiers_titre.tinom.label("issuer"),
            issuer_hedge.label("issuer_hedge"),
            type_hedge.label("type_hedge"),
            Instrument.ifnom.label("name"),
            emission_titre.emnominal.label("nominal"),
            emission_titre.emcapiinit.label("issue_size"),
            emission_titre.emprix.label("issue_price"),
            Devise.dvcodeiso.label("ccy"),
            emission_titre.emdatestrike.label("trade_date"),
            emission_titre.empaiement.label("issue_date"),
            emission_titre.emmaturite.label("maturity_date"),
            Contrats.ctmaturite.label("redemption_date"),
            lien_hedge.alcfin.label("cfin_hedge"),
            lien_position.alsjac.label("cfin_position"),
            Derives.dereg.label("redemption_type"),
            Typestatut.tstnom.label("status"),
            Typeetatdevie.tvlibelle.label("state_life_label"),
            Typeetatdevie.tvcode.label("state_life_code"),
            Typediffusion.tdlibelle.label("etat_diff"),
            VTypofoLibelle.libelle_deduit.label("inst_type"),
            Produit.prmarche.label("market"),
        )
        .select_from(Instrument)
        .join(
            (Typestatut, Typestatut.tstcode == Instrument.ifstatut),
            (Produit, Produit.prcfin == Instrument.ifcfin),
            (Devise, Devise.dvcfin == Produit.prdev),
        )
        .outerjoin(
            (emission_titre, emission_titre.emcfin == Instrument.ifcfin),
            (
                codif_isin,
                and_(codif_isin.cfcfin == Instrument.ifcfin, codif_isin.cfsource == 6,),
            ),
            (
                codif_ric,
                and_(codif_ric.cfcfin == Instrument.ifcfin, codif_ric.cfsource == 334,),
            ),
            (Produit, Produit.prcfin == Instrument.ifcfin),
            (Last, Last.lacfin == Instrument.ifcfin),
            (
                lien_hedge,
                and_(lien_hedge.alsjac == Instrument.ifcfin, lien_hedge.altype == 53),
            ),
            (emission_hedge, emission_hedge.emcfin == lien_hedge.alcfin),
            (
                lien_position,
                and_(
                    lien_position.alcfin == Instrument.ifcfin,
                    lien_position.altype == 14,
                ),
            ),
            (
                codif_external_ref,
                and_(
                    codif_external_ref.cfcfin == lien_hedge.alcfin,
                    codif_external_ref.cfsource == 335,
                ),
            ),
            (
                codif_external_ric,
                and_(
                    codif_external_ric.cfcfin == lien_hedge.alcfin,
                    codif_external_ric.cfsource == 334,
                ),
            ),
            (
                codif_external_isin,
                and_(
                    codif_external_isin.cfcfin == lien_hedge.alcfin,
                    codif_external_isin.cfsource == 6,
                ),
            ),
            (Emisstructuree, Emisstructuree.escfin == Instrument.ifcfin),
            (Instrumentcomplement, Instrumentcomplement.iccfin == Instrument.ifcfin),
            (Typeetatdevie, Typeetatdevie.tvcode == Instrumentcomplement.icetatdevie),
            (Typediffusion, Typediffusion.tdcode == Instrumentcomplement.icdiffusion),
            (Contrats, Contrats.ctcfin == Instrument.ifcfin),
            (Derives, Derives.decfin == Instrument.ifcfin),
            (Contratotcs, Contratotcs.cocfin == lien_hedge.alcfin),
            (tiers_titre, tiers_titre.ticode == emission_titre.emissuer),
            (tiers_otc, tiers_otc.ticode == Contratotcs.coreceveur),
            (tiers_hedge, tiers_hedge.ticode == emission_hedge.emissuer),
            (VTypofoLibelle, VTypofoLibelle.code_typo == Instrument.iftypofo),
        )
        .filter(Instrument.ifcfin == cfin)
        .all()
    )

    df_titre = df[
        [
            "cfin",
            "isin",
            "ric",
            "issuer",
            "name",
            "nominal",
            "issue_size",
            "issue_price",
            "ccy",
            "trade_date",
            "issue_date",
            "maturity_date",
            "redemption_date",
            "cfin_position",
            "redemption_type",
            "status",
            "state_life_label",
            "state_life_code",
            "etat_diff",
            "inst_type",
            "market",
        ]
    ]

    d_titre = df_titre.iloc[0].to_dict()

    df_hedge = df[
        ["issuer_hedge", "type_hedge", "cfin_hedge", "external_ref", "ric_code"]
    ]
    df_hedge.dropna(subset=["cfin_hedge"], inplace=True)

    d_hedge = df_hedge.to_dict("records")

    d = {"main": d_titre, "hedge": d_hedge}

    # Replace the name of the listed market
    listed_market = {
        38: "Euronext",
        184: "SED",
        218: "SIX",
        919: "TLX",
    }
    d["main"]["market"] = listed_market.get(d["main"]["market"])

    # Update issuer if product is hedged
    for k, hedge in enumerate(d["hedge"]):
        if hedge["issuer_hedge"]:
            hedge["issuer"] = (
                hedge["type_hedge"] + " " + issuer_rename(hedge["issuer_hedge"])
            )

        # Check if the external RIC code exists in the Contrib Schema
        if k == 0 and not hedge["ric_code"]:
            ric_code = get_ric_code(cfin)

            if ric_code:
                hedge["ric_code"] = ric_code

                # Insert the code in the table exane.codes on the Hedge Cfin
                # insert_or_update_code(hedge["cfin_hedge"], ric_code, kind="issuer_ric")

    # Update the delivery mode with readable content
    delivery_mode = {
        None: None,
        "C": "Cash",
        "F": "Future",
        "M": "Monep",
        "R": "RM",
        "T": "Title",
    }
    d["main"]["redemption_type"] = delivery_mode[d["main"]["redemption_type"]]

    # Convert cfin to string as str needed as ID for components
    d["main"]["cfin"] = str(d["main"]["cfin"])

    return d


def cfin_details(cfin):
    Codes_isin = aliased(Codes)
    Codes_ticker = aliased(Codes)

    modified_country = case([(Pays.paabrege == "#NA", ""),], else_=Pays.paabrege,)
    modified_type = case(
        [(Instrument.ifnom.like("%monetary index"), "Cash"),],
        else_=Typeinstrument.tyname,
    )
    modified_class = case(
        [(Instrument.ifnom.like("%monetary index"), "Cash"),], else_=Typepayoff.tflnom,
    )

    r = (
        db.session.query(
            Instrument.ifcfin.label("cfin"),
            Instrument.ifnom.label("name"),
            Codes_isin.cfcode.label("isin"),
            Codes_ticker.cfcode.label("ticker"),
            modified_country.label("country"),
            Devise.dvcodeiso.label("ccy"),
            modified_type.label("type"),
            modified_class.label("class"),
        )
        .select_from(Instrument)
        .join(
            (Produit, Produit.prcfin == Instrument.ifcfin),
            (Devise, Devise.dvcfin == Produit.prdev),
        )
        .outerjoin(
            (Pays, Pays.pacode == Produit.prpays),
            (Typeinstrument, Typeinstrument.tycode == Instrument.iftype),
            (Typepayoff, Typepayoff.tflcode == Instrument.ifpayoff),
            (
                Codes_isin,
                and_(Codes_isin.cfcfin == Instrument.ifcfin, Codes_isin.cfsource == 6),
            ),
            (
                Codes_ticker,
                and_(
                    Codes_ticker.cfcfin == Instrument.ifcfin,
                    Codes_ticker.cfsource == 11,
                ),
            ),
        )
        .filter(Instrument.ifcfin == cfin)
    ).first()

    if r:
        return r._asdict()


def issuers_for_cfins(cfins):
    # Alias for Product and OTC's issuers
    tiers_otc, tiers_titre = aliased(Tier), aliased(Tier)

    query = (
        db.session.query(
            Instrument.ifcfin.label("cfin"),
            tiers_titre.tinom.label("issuer"),
            tiers_otc.tinom.label("issuer_otc"),
        )
        .select_from(Instrument)
        .outerjoin(
            (Emission, Emission.emcfin == Instrument.ifcfin),
            (Alien, and_(Alien.alsjac == Instrument.ifcfin, Alien.altype == 53),),
            (Contratotcs, Contratotcs.cocfin == Alien.alcfin),
            (tiers_titre, tiers_titre.ticode == Emission.emissuer),
            (tiers_otc, tiers_otc.ticode == Contratotcs.coreceveur),
        )
        .filter(Instrument.ifcfin.in_(cfins))
    )

    df = pd.DataFrame(query)

    if not df.empty:
        df.issuer = df.apply(
            lambda x: issuer_rename(x["issuer"], x["issuer_otc"]), axis=1
        )
        d = {df.loc[x, "cfin"]: df.loc[x, "issuer"] for x in df.index}
        return d


def isins_for_cfins(cfins):
    query = (
        db.session.query(Instrument.ifcfin.label("cfin"), Codes.cfcode.label("isin"))
        .outerjoin(
            (Codes, and_(Codes.cfcfin == Instrument.ifcfin, Codes.cfsource == 6))
        )
        .filter(Instrument.ifcfin.in_(cfins))
    )

    df = pd.DataFrame(query)
    if not df.empty:
        d = {df.loc[x, "cfin"]: df.loc[x, "isin"] for x in df.index}
        return d


def pose_certif(cfin, end_date=dt_today()):
    query = (
        db.session.query(
            Rkoperation.opcfin.label("cfin"),
            func.sum(-Rkoperation.opquantite).label("pose"),
        )
        .filter(
            Rkoperation.opflag != 3,
            Rkoperation.opannule == None,
            Rkoperation.opotype == 51,
            ~Rkoperation.opinformation.in_([1, 4, 6]),
            Rkoperation.opcfin == cfin,
            Rkoperation.opdatenego <= end_date,
        )
        .group_by(Rkoperation.opcfin)
    ).first()

    return query.pose


@timeit
def positions_for_cfins(cfins):
    result = (
        db.session.query(
            Rkoperation.opcfin.label("cfin"),
            Rkvendeurcircus.vcnom.label("sales"),
            func.sum(-Rkoperation.opquantite).label("pose"),
        )
        .select_from(Rkoperation)
        .filter(
            Rkoperation.opvendeur == Rkvendeurcircus.vccode,
            Rkoperation.opflag != 3,
            Rkoperation.opannule == None,
            ~Rkoperation.opinformation.in_([1, 4, 6]),
            Rkoperation.opcfin.in_(cfins),
        )
        .group_by(Rkoperation.opcfin, Rkvendeurcircus.vcnom)
    )
    df = pd.DataFrame(result)
    d = (
        df.groupby("cfin")[["sales", "pose"]]
        .apply(lambda x: x.set_index(["sales"])["pose"].to_dict())
        .to_dict()
    )
    return d


@timeit
def autocall_proba(proba=0.75, bdays=10):
    calc_day = prev_bday(1)

    product = (
        db.session.query(
            Rkscriptindicateur.sicfin.label("cfin"),
            func.regexp_replace(Rkscriptindicateur.sicle, "[^A-Za-z]", "").label(
                "name_field"
            ),
            cast(
                func.regexp_replace(Rkscriptindicateur.sicle, "[^0-9]", ""), INTEGER
            ).label("id_date"),
            Rkscriptindicateur.sivaleur,
        )
        .filter(
            Rkscriptindicateur.sicle.like("CV_DateConstat%"),
            Rkscriptindicateur.sidate == calc_day,
            Rkscriptindicateur.sivaleur > 1,
        )
        .subquery()
    )

    index_min_date = (
        db.session.query(
            Rkscriptindicateur.sicfin.label("cfin"),
            func.min(
                cast(
                    func.regexp_replace(Rkscriptindicateur.sicle, "[^0-9]", ""),
                    INTEGER,
                )
            ).label("first_date"),
        )
        .filter(
            Rkscriptindicateur.sicle.like("TV_probaRappel%"),
            Rkscriptindicateur.sidate == calc_day,
            Rkscriptindicateur.sivaleur > 0,
        )
        .group_by(Rkscriptindicateur.sicfin)
        .subquery()
    )

    proba_atk = (
        db.session.query(
            Rkscriptindicateur.sicfin.label("cfin"),
            cast(
                func.regexp_replace(Rkscriptindicateur.sicle, "[^0-9]", ""), INTEGER
            ).label("id_date_2"),
            Rkscriptindicateur.sivaleur.label("proba_atk"),
        )
        .filter(
            Rkscriptindicateur.sicle.like("TV_probaRappel%"),
            Rkscriptindicateur.sidate == calc_day,
            Rkscriptindicateur.sivaleur > 0,
        )
        .subquery()
    )

    last_date_update = (
        db.session.query(Last.lacfin, func.max(Last.ladate).label("last_date"))
        .group_by(Last.lacfin)
        .subquery()
    )

    proba_atk_all = (
        db.session.query(
            product.c.cfin.label("cfin"),
            func.to_date(product.c.sivaleur, "J").label("date_next"),
            proba_atk.c.proba_atk,
        )
        .join(
            (
                index_min_date,
                and_(
                    index_min_date.c.cfin == product.c.cfin,
                    index_min_date.c.first_date <= product.c.id_date,
                ),
            ),
            (
                proba_atk,
                and_(
                    proba_atk.c.cfin == index_min_date.c.cfin,
                    proba_atk.c.id_date_2 == product.c.id_date,
                ),
            ),
        )
        .subquery()
    )

    tiers_otc, tiers_titre = aliased(Tier), aliased(Tier)
    lien_otc, lien_position = aliased(Alien), aliased(Alien)

    result = (
        db.session.query(
            Instrument.ifcfin.label("cfin"),
            Codes.cfcode.label("isin"),
            tiers_titre.tinom.label("issuer"),
            tiers_otc.tinom.label("issuer_otc"),
            Instrument.ifnom.label("name"),
            Last.ladate.label("last_date"),
            proba_atk_all.c.date_next.label("next_obs"),
            proba_atk_all.c.proba_atk.label("proba_atk"),
        )
        .select_from(Instrument)
        .join(
            (Emission, Emission.emcfin == Instrument.ifcfin),
            (Codes, and_(Codes.cfcfin == Instrument.ifcfin, Codes.cfsource == 6)),
            (last_date_update, last_date_update.c.lacfin == Instrument.ifcfin),
            (
                Last,
                and_(
                    Last.lacfin == Instrument.ifcfin,
                    Last.ladate == last_date_update.c.last_date,
                ),
            ),
            (Produit, Produit.prcfin == Instrument.ifcfin),
            (proba_atk_all, proba_atk_all.c.cfin == Instrument.ifcfin),
        )
        .outerjoin(
            (
                lien_otc,
                and_(lien_otc.alsjac == Instrument.ifcfin, lien_otc.altype == 53),
            ),
            (
                lien_position,
                and_(
                    lien_position.alcfin == Instrument.ifcfin,
                    lien_position.altype == 14,
                ),
            ),
            (Contratotcs, Contratotcs.cocfin == lien_otc.alcfin),
            (tiers_titre, tiers_titre.ticode == Emission.emissuer),
            (tiers_otc, tiers_otc.ticode == Contratotcs.coreceveur),
        )
        .filter(
            Last.lamarche == Produit.prmarche,
            ~Instrument.ifstatut.in_([7, 22]),
            Instrument.iftypofo >= 35000,
            Instrument.iftypofo < 36000,
            Instrument.ifcontrat == 1,
            proba_atk_all.c.proba_atk > proba,
            # Instruments.ifcfin == 42357479,  # To comment in production
        )
        .order_by(proba_atk_all.c.date_next, proba_atk_all.c.proba_atk)
    )

    df = pd.DataFrame(result)

    if df.empty:
        return

    # Group by cfin to get the next observation date
    df = df.loc[df[df.next_obs >= dt_today("dt")].groupby("cfin")["next_obs"].idxmin()]
    df = df.sort_values(by="next_obs")

    # Adapt issuers' column
    df.loc[:, "issuer"] = df.apply(
        lambda x: issuer_rename(x["issuer"], x["issuer_otc"]), axis=1
    )

    df.loc[:, "next_obs"] = pd.to_datetime(df.next_obs)

    # Select only trades between today and in bdays business days
    today = dt_today()
    end_date = today + BDay(bdays)
    df = df[(df.next_obs.dt.date >= today) & (df.next_obs.dt.date <= end_date)]

    to_str_date = lambda x: x.strftime("%b %d, %Y")
    to_str_percent = lambda x: f"{x:,.2%}"

    func_convert = {
        "last_date": to_str_date,
        "next_obs": to_str_date,
        "proba_atk": to_str_percent,
    }

    for field in func_convert:
        df.loc[:, field] = df[field].apply(func_convert[field])

    # Delete column with the OTC counterparts
    del df["issuer_otc"]

    return df.set_index("cfin").T.to_dict()


def to_eur(x):
    quantity = x.get("quantity")
    if quantity == 0:
        return 0

    nominal = x.get("nominal")
    bid = x.get("bid")

    if not nominal or not bid:
        if not x.get("spot"):
            return 0
        cash = quantity * x.get("spot")
    else:
        issue_price = x.get("issue_price")
        if issue_price == 0:
            return 0
        if not issue_price:
            issue_price = 100
        cash = quantity * float(nominal) * bid / issue_price

    ccy = x.get("ccy", "EUR")
    if ccy == "EUR":
        return cash

    ccy_code = x.get("ccy_code")

    result = (
        db.session.query(Crosshistorique.chvaleur.label("value"),)
        .join(
            (
                Instrument,
                and_(
                    Instrument.ifcfin == Crosshistorique.chcfin,
                    Instrument.iftype == 200,  # Type Cross
                ),
            ),
            (
                Produit,
                and_(
                    Produit.prcfin == Instrument.ifcfin,
                    Produit.prdev == -26,
                    Produit.prdevnominal == ccy_code,
                ),
            ),
        )
        .filter(
            Crosshistorique.chdate == prev_bday(),
            Crosshistorique.chtype == 3,  # Type WMCO
        )
    ).first()

    fx_rate = float(result[0])

    return cash / fx_rate


def autocall_distances(cfins):
    from utils.osiris import instruments_details

    d = instruments_details(cfins)

    if d:

        details = {
            x["instrumentId"]: {
                "underlyings": {
                    y["technicalCfin"]: y["initRefValue"] / y["weight"]
                    for y in x["underlyings"]
                },
                "next_atk_barrier": [
                    (
                        min(
                            filter(
                                lambda x: x is not None,
                                [
                                    y.get("earlyRedemptionBarrier"),
                                    x.get("earlyRedemptionBarrier"),
                                ],
                            )
                        ),
                        api_date_to_string(y["fixingDate"]),
                    )
                    for y in x["fixingDates"]
                    if y["callable"]
                    and api_date_to_string(y["fixingDate"]) >= dt_today()
                ][0],
            }
            for x in d
        }

        for cfin in details.keys():
            d = details[cfin]
            cfins = d["underlyings"].keys()
            result = (
                db.session.query(
                    Instrument.ifcfin.label("cfin"),
                    Instrument.ifnom.label("name"),
                    Codes.cfcode.label("ticker"),
                    Last.lapriclos.label("last"),
                )
                .select_from(Instrument)
                .outerjoin(
                    (Produit, Produit.prcfin == Instrument.ifcfin),
                    (Last, Last.lacfin == Instrument.ifcfin),
                    (
                        Codes,
                        and_(Codes.cfcfin == Instrument.ifcfin, Codes.cfsource == 11),
                    ),
                )
                .filter(
                    and_(
                        ~Codes.cfcode.like("% EU"),
                        Instrument.ifcfin.in_(cfins),
                        Last.lamarche == Produit.prmarche,
                        Last.lamarche == Codes.cfmarche,
                    )
                )
            ).all()

            perfs = []

            for c in result:
                values = {
                    "name": c.name,
                    "ticker": c.ticker,
                    "strike": d["underlyings"][c.cfin],
                    "last": c.last,
                    "perf": c.last / d["underlyings"][c.cfin] - 1.0,
                    "dist_atk_barrier": c.last / d["underlyings"][c.cfin]
                    - d["next_atk_barrier"][0],
                }

                d["underlyings"][c.cfin] = values

                perfs.append((c.cfin, values["dist_atk_barrier"]))

            perfs.sort(key=lambda x: x[1])

            d["worst"] = perfs[0][0]

        result = {
            x: {
                "cfin": details[x]["worst"],
                **details[x]["underlyings"][details[x]["worst"]],
            }
            for x in details.keys()
        }

        return result


def sales_involved(cfins):
    result = (
        db.session.query(
            Rkoperation.opcfin.label("cfin"), Rkvendeurcircus.vcnom.label("sales"),
        )
        .join(Rkvendeurcircus, Rkvendeurcircus.vccode == Rkoperation.opvendeur)
        .filter(
            and_(
                Rkoperation.opflag != 3,
                Rkoperation.opannule == None,
                Rkvendeurcircus.vccode != 2817,  # MO Structures
                not_(Rkoperation.opinformation.in_([1, 4, 6])),
                Rkoperation.opcfin.in_(cfins),
            ),
        )
    ).all()

    d = {}
    for x, y in set(result):
        d.setdefault(y, []).append(x)

    return d


def username_sales_involved(cfins):
    result = (
        db.session.query(
            Rkoperation.opcfin.distinct().label("cfin"),
            Rkvendeurcircus.vcloginad.label("username"),
            Rkvendeurcircus.vcnom.label("sales"),
            Rkvendeurcircus.vcflag.label("active_flag"),
        )
        .select_from(Rkoperation)
        .outerjoin(
            Rkvendeurcircus,
            and_(
                Rkvendeurcircus.vccode == Rkoperation.opvendeur,
                Rkvendeurcircus.vccode != 2817,  # MO Structures
            ),
        )
        .filter(
            and_(
                Rkoperation.opflag != 3,
                Rkoperation.opannule == None,
                Rkoperation.opotype == 51,
                not_(Rkoperation.opinformation.in_([1, 4, 6])),
                Rkoperation.opcfin.in_(cfins),
            ),
        )
    ).all()

    # Dict of sales by cfin
    d_by_cfin = {}

    for cfin, username, sales, flag in set(result):
        sales = sales if (sales and flag == 1) else "No Sales Assigned"
        if sales not in d_by_cfin.setdefault(cfin, []):
            d_by_cfin.setdefault(cfin, []).append(sales)

    # Suppress 'Sales Unknown' if there is already a sales for the product
    for cfin in d_by_cfin:
        l = d_by_cfin[cfin]
        if l.__len__() > 1 and "No Sales Assigned" in l:
            d_by_cfin[cfin].remove("No Sales Assigned")

    # Reorder dict by Sales
    d_by_sales = {}
    for x, y, z, flag in set(result):
        y = y if y else "No Sales Assigned"
        z = z if z else "No Sales Assigned"
        if z in d_by_cfin[x]:
            d_by_sales.setdefault((z, y), []).append(x)

    return d_by_sales


def all_sales_alive():
    return pd.DataFrame(
        db.session.query(
            Rkvendeurcircus.vccode.label("sales_code"),
            Rkvendeurcircus.vcnom.label("sales_name"),
            Rkvendeurcircus.vcprenom.label("sales_first_name"),
        ).filter(and_(Rkvendeurcircus.vcflag == 1, Rkvendeurcircus.vcloginad != None,),)
    )


def all_currencies():
    result = (
        db.session.query(Devise.dvcodeiso.label("ccy")).filter(
            Devise.dvlibelle != None,
        )
    ).all()

    return pd.DataFrame(result)


def nominal_for_cfin(cfin):
    r = Emission.query.filter_by(emcfin=cfin).first()
    if r and r.emnominal:
        return float(r.emnominal)


def script_for_cfin(cfin):
    query = db.session.query(Script.scscript).filter(Script.sccfin == cfin).first()
    if query:
        return query.scscript


def greeks_from_pricing_results(cfin):
    # cube_ids = (
    #     db.session.query(Rkpricing.prnumero.label("cube_id"))
    #     .filter(
    #         and_(
    #             Rkpricing.prparent == cfin,
    #             Rkpricing.prcfin == cfin,
    #             Rkpricing.prflag == 1,
    #             Rkpricing.prmode == 0,  # Mode Full (vs Light)
    #             Rkpricing.prprofil == 1004,
    #         )
    #     )
    #     .order_by(Rkpricing.prdate.desc())
    #     .all()
    # )

    cube_ids = (
        db.session.query(
            Rkpricing.prnumero.label("cube_id"),
            Rkpricing.prdate,
            Rkpricing.prflag,
            Rkpricing.prmode,
            Rkpricing.prprofil,
        )
        .filter(
            and_(
                Rkpricing.prparent == cfin,
                Rkpricing.prcfin == cfin,
                Rkpricing.prflag == 1,
                Rkpricing.prmode == 0,  # Mode Full (vs Light)
                Rkpricing.prprofil == 1004,
            )
        )
        .order_by(Rkpricing.prdate.desc())
        .all()
    )[:5]

    cube_ids = [x.cube_id for x in cube_ids]

    result = (
        db.session.query(
            Rkpricing.prdate.label("date"),
            Rkpricing.prprofil.label("profil"),
            Rkpricingresultat.praxe1.label("cfin"),
            Codes.cfcode.label("ticker"),
            Instrument.ifnom.label("name"),
            Devise.dvcodeiso.label("ccy"),
            Rkpricingresultat.prvaleur.label("value"),
            Rktypeindicateur.tilibelle.label("indicator"),
        )
        .select_from(Rkpricing)
        .join(
            (
                Rkpricingresultat,
                and_(
                    Rkpricingresultat.prnumero == Rkpricing.prnumero,
                    Rkpricingresultat.prnumero.in_(cube_ids[:15]),
                ),
            ),
            (
                Rktypeindicateur,
                Rktypeindicateur.ticode == Rkpricingresultat.prindicateur,
            ),
        )
        .outerjoin(
            (Instrument, Instrument.ifcfin == Rkpricingresultat.praxe1),
            (Produit, Produit.prcfin == Rkpricingresultat.praxe1),
            (Devise, Devise.dvcfin == Produit.prdev),
            (
                Codes,
                and_(
                    Codes.cfcfin == Rkpricingresultat.praxe1,
                    Codes.cfsource == 11,
                    Codes.cfmarche == Produit.prmarche,
                    ~Codes.cfcode.like("% EU"),
                ),
            ),
        )
        # .filter(Instruments.ifcfin == 885)
    )

    df = pd.DataFrame(result)

    if df.empty:
        return df

    dff = df[df.date == df.date.max()]
    dff = dff.dropna(subset=["cfin"])

    # Pivot to keep underlyings only
    dfp = pd.pivot_table(
        dff,
        index=["cfin", "ticker", "name", "ccy"],
        columns="indicator",
        values="value",
        aggfunc=np.sum,
    )

    if dfp.empty:
        return dfp

    to_str_spot = lambda x: f"{x:,.3f}" if x != 0.0 else " - "
    to_str_vol_spot = lambda x: f"{x:.2f}%" if x != 0.0 else " - "
    to_str_percent = lambda x: f"{x:.2%}" if x != 0.0 else " - "

    relevant_columns = {
        "cfin": {"name": "Cfin", "formatting": None},
        "ticker": {"name": "Ticker", "formatting": None},
        "name": {"name": "Name", "formatting": None},
        "ccy": {"name": "Ccy", "formatting": None},
        "SPOT": {"name": "Spot", "formatting": to_str_spot},
        "VOLATILITE SPOT": {"name": "Vol Spot", "formatting": to_str_vol_spot},
        "DELTA": {"name": "Delta", "formatting": to_str_percent},
        "GAMMA": {"name": "Gamma", "formatting": to_str_percent},
        "VEGA": {"name": "Vega", "formatting": to_str_percent},
        "VEGA PONDERE": {"name": "Weighted Vega", "formatting": to_str_percent},
        # "DECAY": {"name": "Decay", "formatting": to_str_spot},
    }

    dfp = dfp[[x for x in relevant_columns if x in dfp.columns]]
    dfp = dfp.dropna(
        subset=[x for x in relevant_columns if x in dfp.columns], axis=0, how="all"
    )
    dfp = dfp.fillna(0.0)
    dfp = dfp.astype("float")

    nominal = nominal_for_cfin(cfin)

    if nominal:
        for col in ["DELTA", "GAMMA", "DECAY"]:
            if col in dfp.columns:
                dfp[col] = dfp[col] * dfp["SPOT"] / nominal

        for col in ["VEGA", "VEGA PONDERE"]:
            if col in dfp.columns:
                dfp[col] = dfp[col] / nominal

    # Sort columns by deltas if relevant
    if "DELTA" in dfp.columns:
        dfp = dfp.sort_values(by="DELTA", ascending=False)

    dfp = dfp.reset_index()

    # Reformat columns
    for col in dfp.columns:
        formatting = relevant_columns[col].get("formatting")
        if formatting:
            dfp[col] = dfp[col].apply(formatting)

    # Rename columns
    names = [relevant_columns[x]["name"] for x in relevant_columns if x in dfp.columns]
    dfp.columns = names

    return dfp


def products_events():
    today = dt_today()
    yesterday_julian = prev_bday(1, "julian")

    # Get all Cfins for which there has been an event yesterday
    events = (
        db.session.query(
            Rkscriptindicateur.sicfin.label("cfin"),
            func.substr(Rkscriptindicateur.sicle, 15, 6).label("nb_cpn"),
        )
        .join((Instrument, Instrument.ifcfin == Rkscriptindicateur.sicfin),)
        .filter(
            and_(
                Rkscriptindicateur.sicle.like("CV_DateConstat%"),
                Rkscriptindicateur.sidate == today,
                ~Rkscriptindicateur.sicle.like("CV_DateConstat_Est_Elle_Passee%"),
                Rkscriptindicateur.sivaleur == yesterday_julian,
                Instrument.iftypofo >= 35000,
                Instrument.iftypofo < 36000,
                Instrument.ifstatut != 22,
            ),
        )
        .subquery()
    )

    # Get all coupons and dates for each cfin
    cpns = (
        db.session.query(
            Rkscriptindicateur.sicfin.label("cfin"),
            func.substr(Rkscriptindicateur.sicle, 18, 6).label("nb_cpn"),
            Rkscriptindicateur.sivaleur.label("cpn"),
        )
        .filter(
            and_(
                Rkscriptindicateur.sicle.like("CV_CouponDejaPaye%"),
                Rkscriptindicateur.sidate == today,
            ),
        )
        .subquery()
    )

    result = (
        db.session.query(events.c.cfin, cpns.c.cpn)
        .outerjoin(
            (
                cpns,
                and_(events.c.cfin == cpns.c.cfin, events.c.nb_cpn == cpns.c.nb_cpn),
            )
        )
        .filter(cpns.c.cpn > 0)
    )

    d = {r[0]: {"percent_paid": r[1] / 100} for r in result.all()}

    return d


def events_cpns_or_autocalls(events_date=None):
    if events_date is None:
        events_constat_date = dt_today()
        julian_events_date = prev_bday(1, "julian")
    else:
        events_constat_date = (events_date + BDay(1)).date()
        julian_events_date = (
            events_date + BDay(0) + timedelta(hours=12)
        ).to_julian_date()

    products = sub_products()

    # Get all Cfins for which there has been an event one business day ago
    events = (
        db.session.query(
            Rkscriptindicateur.sicfin.label("cfin"),
            func.substr(Rkscriptindicateur.sicle, 15, 6).label("nb_cpn"),
        )
        .join(Instrument, Instrument.ifcfin == Rkscriptindicateur.sicfin)
        .filter(
            and_(
                Rkscriptindicateur.sicle.like("CV_DateConstat%"),
                ~Rkscriptindicateur.sicle.like("CV_DateConstat_Est_Elle_Passee%"),
                Rkscriptindicateur.sidate == dt_today(),
                Rkscriptindicateur.sivaleur == julian_events_date,
                Instrument.iftypofo >= 35000,
                Instrument.iftypofo < 36000,
                Instrument.ifstatut != 22,
            ),
        )
        .subquery()
    )

    # Get all coupons and dates for each cfin
    cpns = (
        db.session.query(
            Rkscriptindicateur.sicfin.label("cfin"),
            func.substr(Rkscriptindicateur.sicle, 18, 6).label("nb_cpn"),
            Rkscriptindicateur.sivaleur.label("cpn"),
        )
        .join(Instrument, Instrument.ifcfin == Rkscriptindicateur.sicfin)
        .filter(
            and_(
                Rkscriptindicateur.sicle.like("CV_CouponDejaPaye%"),
                Rkscriptindicateur.sidate == dt_today(),
                Instrument.iftypofo >= 35000,
                Instrument.iftypofo < 36000,
                Instrument.ifstatut != 22,
            ),
        )
        .subquery()
    )

    # Get payment dates for each cfin
    pay_date = (
        db.session.query(
            Rkscriptindicateur.sicfin.label("cfin"),
            func.substr(Rkscriptindicateur.sicle, 5, 6).label("nb_cpn"),
            Rkscriptindicateur.sivaleur.label("date"),
        )
        .filter(
            and_(
                Rkscriptindicateur.sicle.like("#PAY%"),
                Rkscriptindicateur.sidate == dt_today(),
            ),
        )
        .subquery()
    )

    result = (
        db.session.query(
            events.c.cfin.label("cfin"),
            products.c.isin.label("isin"),
            products.c.name.label("name"),
            products.c.issuer.label("issuer"),
            products.c.currency.label("currency"),
            products.c.nominal.label("nominal"),
            products.c.issue_price.label("issue_price"),
            Produit.prmodecot.label("quotation_mode"),
            products.c.cfin_otc.label("cfin_otc"),
            products.c.issuer_otc.label("issuer_otc"),
            products.c.cfin_contrib.label("cfin_contrib"),
            products.c.strike_date.label("strike_date"),
            products.c.issue_date.label("issue_date"),
            products.c.last_obs_date.label("last_obs_date"),
            products.c.maturity_date.label("maturity_date"),
            pay_date.c.date.label("payment_date"),
            cpns.c.cpn.label("percent_paid"),
        )
        .join((Produit, Produit.prcfin == events.c.cfin),)
        .outerjoin(
            (
                cpns,
                and_(events.c.cfin == cpns.c.cfin, events.c.nb_cpn == cpns.c.nb_cpn),
            ),
            (
                pay_date,
                and_(
                    events.c.cfin == pay_date.c.cfin,
                    events.c.nb_cpn == pay_date.c.nb_cpn,
                ),
            ),
            (products, products.c.cfin == events.c.cfin),
        )
        .filter(cpns.c.cpn > 0)
    )

    # d = {r[0]: {"percent_paid": r[1] / 100} for r in result.all()}

    df = pd.DataFrame(result)

    if df.empty:
        return []

    df.payment_date = pd.to_datetime(df.payment_date, unit="D", origin="julian")
    df["event_type"] = df.apply(
        lambda x: "autocall"
        if (
            x["quotation_mode"] == 1
            and float(x["percent_paid"])
            >= float(x["issue_price"]) / float(x["nominal"]) * 100
        )
        or (
            x["quotation_mode"] == 2
            and float(x["percent_paid"]) >= float(x["issue_price"])
        )
        else "coupon",
        axis=1,
    )
    df["observation_date"] = to_str_date(events_date)
    df.payment_date = df.payment_date.apply(to_str_date)

    return df.to_dict("records")


def events_maturity(events_date=None):
    if events_date is None:
        events_date = prev_bday(1)

    products = sub_products()

    result = db.session.query(
        products.c.cfin.label("cfin"),
        products.c.isin.label("isin"),
        products.c.name.label("name"),
        products.c.issuer.label("issuer"),
        products.c.currency.label("currency"),
        products.c.nominal.label("nominal"),
        products.c.issue_price.label("issue_price"),
        products.c.cfin_otc.label("cfin_otc"),
        products.c.issuer_otc.label("issuer_otc"),
        products.c.cfin_contrib.label("cfin_contrib"),
        products.c.strike_date.label("strike_date"),
        products.c.issue_date.label("issue_date"),
        products.c.last_obs_date.label("last_obs_date"),
        products.c.maturity_date.label("maturity_date"),
        products.c.last_obs_date.label("payment_date"),
        products.c.maturity_date.label("observation_date"),
    ).filter(products.c.maturity_date == events_date)

    df = pd.DataFrame(result)

    if df.empty:
        return []

    df["payment_date"] = df["payment_date"].apply(to_str_date)
    df["observation_date"] = df["observation_date"].apply(to_str_date)
    df["event_type"] = "maturity"
    df["percent_paid"] = "TBD"

    return df.to_dict("records")


def bloomberg_to_reuters(tickers):
    d_end_tickers = {
        "usa": ["UN", "US", "UW", "UQ"],
        "spain": ["SM", "SQ"],
        "germany": ["GY", "GR"],
        "switzerland": ["SE", "SW"],
    }

    all_tickers = {x: [x] for x in tickers}

    for ticker in tickers:
        splitted = ticker.split(" ")
        if len(splitted) == 2:
            for country in d_end_tickers:
                if splitted[1] in d_end_tickers[country]:
                    possibilities = [
                        f"{splitted[0]} {x}" for x in d_end_tickers[country]
                    ]
                    all_tickers[ticker] = possibilities

    list_tickers = list(itertools.chain(*all_tickers.values()))

    codes_bloomberg = aliased(Codes)
    codes_reuters = aliased(Codes)

    result = (
        db.session.query(
            codes_bloomberg.cfcode.label("bloomberg"),
            codes_reuters.cfcode.label("reuters"),
        )
        .join(
            codes_reuters,
            and_(
                codes_reuters.cfcfin == codes_bloomberg.cfcfin,
                codes_reuters.cfsource == 3,
            ),
        )
        .filter(
            and_(
                codes_bloomberg.cfcode.in_(list_tickers), codes_bloomberg.cfsource == 11
            )
        )
        .distinct(codes_reuters.cfcode)
    )

    df = pd.DataFrame(result)

    assert len(df.bloomberg) == len(tickers), "Some tickers were not found"

    return df


def names_products(cfins):

    r = db.session.query(
        Instrument.ifcfin.label("cfin"), Instrument.ifnom.label("name"),
    ).filter(Instrument.ifcfin.in_(cfins))

    return dict(r.all())


def cube_calendar(cfin):
    last_calc_date = (
        db.session.query(func.max(Rkscriptindicateur.sidate).label("last_date"),)
        .filter(Rkscriptindicateur.sicfin == cfin)
        .subquery()
    )

    result = (
        db.session.query(Rkscriptindicateur.sicle, Rkscriptindicateur.sivaleur,)
        .join(last_calc_date, Rkscriptindicateur.sidate == last_calc_date.c.last_date,)
        .filter(
            Rkscriptindicateur.sicfin == cfin,
            or_(
                Rkscriptindicateur.sicle.like("CV_CouponDeja%"),
                Rkscriptindicateur.sicle.like("CV_DateConstat%"),
                Rkscriptindicateur.sicle.like("#PAY%"),
                Rkscriptindicateur.sicle.like("TV_probaRappel%"),
            ),
            ~Rkscriptindicateur.sicle.like("CV_DateConstat_Est_Elle_Passee%"),
        )
    )

    df = pd.DataFrame(result, columns=["type", "value"])

    if df.empty:
        return df

    r = re.compile(r"(\D+)(\d+)")
    df["compiled"] = df.apply(
        lambda x: list(r.match(x["type"]).groups()) + [x["value"]], axis=1
    )

    dff = df.compiled.apply(pd.Series)
    dff.columns = ["name", "id", "value"]

    # Convert data types
    dff.value = pd.to_numeric(dff.value)

    df_pivot = dff.pivot_table(columns="name", index="id", values="value")

    col_names = {
        "CV_DateConstat": "fixing_date",
        "#PAY": "payment_date",
        "CV_CouponDejaPaye": "paid",
        "TV_probaRappel": "autocall_proba",
    }

    df_pivot.columns = [col_names[x] for x in df_pivot.columns if x in col_names]
    df_pivot = df_pivot[[x for x in col_names.values() if x in df_pivot.columns]]

    df_pivot.index = df_pivot.index.astype(int)
    df_pivot = df_pivot.sort_values(by="id")

    for col in ["fixing_date", "payment_date"]:
        if col in df_pivot.columns:
            df_pivot[col] = pd.to_datetime(df_pivot[col], unit="D", origin="julian")
            df_pivot[col] = df_pivot[col] - timedelta(hours=12)
            df_pivot[col] = df_pivot[col].dt.tz_localize("Europe/Paris")

    # Shift Fixing Dates by one date if relevant
    first_fixing_date = df_pivot.loc[1, "fixing_date"]
    first_payment_date = None
    if "payment_date" in df_pivot.columns:
        first_payment_date = df_pivot.loc[1, "payment_date"]
    if pd.isna(first_fixing_date) and not pd.isna(first_payment_date):
        df_pivot.payment_date = df_pivot.payment_date.shift(1)

    df_pivot = df_pivot.dropna(subset=["fixing_date"])

    if "payment_date" in df_pivot.columns:
        df_pivot.payment_date = list(df_pivot.payment_date.sort_values(ascending=True))

    return df_pivot.reset_index(drop=True)


def currency_to_cfin(currency):
    r = (
        db.session.query(Produit.prcfin.label("cfin"), Devise.dvcodeiso.label("ccy"))
        .join(Produit, Produit.prdev == Devise.dvcfin)
        .filter(Devise.dvcodeiso == currency)
    ).first()
    result = str(r.cfin) if r else "N/A"
    return result


def xccy_benchmark_vs_cfins(cfins: list, cfin_benchmark: int, date, type_cross="WMCO"):
    """
    Returns the exchange rate between two cfins at a specific date

    First, it sets the currency pairs between the benchmark and the cfins
    If cfin_benchmark is in EUR and one cfin is in USD then the pair is EUR/USD

    Then, it looks into the historical cross db to select the value

    :param cfin_benchmark: Int
    :param cfins: List of Int
    :param date: Date or DateTime
    :param type_cross: Str
    """

    cross_values = ["WMCO", "BCE", "EOD"]

    if type_cross not in cross_values:
        raise ValueError(f"{type_cross} has be in {cross_values}")

    r = (
        db.session.query(Produit.prcfin.label("cfin"), Devise.dvcodeiso.label("ccy"))
        .join(Produit, Produit.prdev == Devise.dvcfin)
        .filter(Produit.prcfin.in_(cfins + [cfin_benchmark]))
    ).all()

    currencies = {x.cfin: x.ccy for x in r}

    result = [
        {
            "cfin": cfin,
            "ccy": currencies[cfin],
            "pair": f"{currencies[cfin_benchmark]}/{currencies[cfin]}",
        }
        for cfin in cfins
    ]

    currency_pairs = [x["pair"] for x in result]

    r = (
        db.session.query(
            Instrument.ifnom.label("pair"), Crosshistorique.chvaleur.label("value")
        )
        .join(
            (Instrument, Instrument.ifcfin == Crosshistorique.chcfin),
            (Typecross, Typecross.tccode == Crosshistorique.chtype),
        )
        .filter(
            Instrument.ifnom.in_(set(currency_pairs)),
            Crosshistorique.chdate == date,
            Typecross.tclibelle == type_cross,
        )
        # .all()
    )

    values = {x.pair: x.value for x in r}

    for x in result:
        x["value"] = values[x["pair"]]

    return result


def products_histo():

    codes_isin = aliased(Codes)
    codes_ticker = aliased(Codes)

    return (
        db.session.query(
            Historiques.hocfin.label("Cfin"),
            Instrument.ifnom.label("Name"),
            codes_ticker.cfcode.label("Ticker"),
            codes_isin.cfcode.label("Isin"),
        )
        .select_from(Historiques)
        .join(
            (Instrument, Instrument.ifcfin == Historiques.hocfin),
            (
                codes_ticker,
                and_(
                    codes_ticker.cfcfin == Historiques.hocfin,
                    codes_ticker.cfsource == 11,
                    not_(codes_ticker.cfmarche.in_([0, 909, 920])),
                ),
            ),
            (
                codes_isin,
                and_(
                    codes_isin.cfcfin == Historiques.hocfin, codes_isin.cfsource == 6,
                ),
            ),
        )
        .filter(Historiques.hodate == prev_bday(1))
    ).all()


def product_from_name(name):
    codes_ticker = aliased(Codes)

    return (
        db.session.query(
            Historiques.hocfin.label("Cfin"),
            Instrument.ifnom.label("Name"),
            codes_ticker.cfcode.label("Ticker"),
        )
        .select_from(Historiques)
        .join(
            (Last, Last.lacfin == Instrument.ifcfin),
            (Instrument, Instrument.ifcfin == Historiques.hocfin),
            (
                codes_ticker,
                and_(
                    codes_ticker.cfcfin == Historiques.hocfin,
                    codes_ticker.cfsource == 11,
                    not_(codes_ticker.cfmarche.in_([0, 909, 920])),
                ),
            ),
        )
        .filter(
            func.lower(Instrument.ifnom).like(f"%{name.lower()}%"),
            func.lower(codes_ticker.cfcode).like(f"%{name.lower()}%"),
            Instrument.iftype.in_([1, 160, 33, 21]),
            ~Instrument.ifstatut.in_([7, 22]),
            Last.ladate >= prev_bday(4),
        )
    ).all()


def ul_certif(cfin):
    r = (
        db.session.query(Rkpricingresultat.praxe1)
        .join(
            (Rkpricing, Rkpricing.prnumero == Rkpricingresultat.prnumero),
            # (Instrument, Instrument.ifcfin == Rkpricingresultat.praxe1),
        )
        .filter(
            Rkpricing.prcfin == cfin,
            Rkpricingresultat.prindicateur == 3,
            # ~Instrument.ifnom.like("IE%"),
        )
        .order_by(Rkpricingresultat.prnumero.desc())
        .first()
    )
    if r:
        return r.praxe1


@cache.memoize(timeout=3000)
def execute_sql_query(query_name=None, bind="exane_analyse", **kwargs):

    df = pd.DataFrame()

    # Open and read the file as a single buffer
    path_sql_query = kwargs.get(
        "path_sql_query", os.path.join(PATH, f"utils/sql/{query_name}.sql")
    )

    with open(path_sql_query, "r") as fd:
        query = fd.read()
        query = query.replace("\n", " ").replace("\t", " ")
        if kwargs:
            for key, value in kwargs.items():
                query = query.replace(key, str(value))

    session = db.create_scoped_session({"bind": db.get_engine(server, bind)})
    r = session.execute(query)
    session.close()

    if r:
        df = pd.DataFrame(r, columns=r.keys())

        # Format Columns
        for col in df.columns:
            if "date" in col.lower():
                df[col] = df[col].apply(
                    lambda x: x.strftime("%d/%m/%Y") if not pd.isna(x) else ""
                )

        df = df.applymap(lambda x: float(x) if isinstance(x, decimal.Decimal) else x)

    return df


def books_for_cfins_flex(cfins):

    df = pd.DataFrame(cfins, columns=["Cfin"])

    # Check if the indices have aliens of type 46: IdxProp_SJFictif
    r = db.session.query(
        Alien.alsjac.label("alter_cfin"), Alien.alcfin.label("Cfin")
    ).filter(Alien.alcfin.in_(cfins), Alien.altype == 46)

    if r:
        dff = pd.DataFrame(r)
        df = df.merge(dff, on="Cfin", how="left")
        df.alter_cfin = df.alter_cfin.fillna(df.Cfin)

    r = (
        db.session.query(
            Rkpricingresultat.praxe1.label("alter_cfin"),
            func.min(Rkpricing.prprofil).label("Book"),
        )
        .join(Rkpricing, Rkpricing.prnumero == Rkpricingresultat.prnumero)
        .filter(
            Rkpricingresultat.praxe1.in_(list(int(x) for x in df.alter_cfin)),
            Rkpricingresultat.prindicateur == 3,
            Rkpricing.prprofil < 1000,
            Rkpricingresultat.prdate >= prev_bday(2),
        )
        .group_by(Rkpricingresultat.praxe1)
    )
    if r:
        dff = pd.DataFrame(r)
        df = df.merge(dff, on="alter_cfin", how="left")
        return df.drop(columns=["alter_cfin"]).set_index("Cfin")


@timeit
def trades_and_products(start_date, end_date):
    # SQL Query Filters
    filter_sales = ""
    filter_alive = ""
    filter_market = ""
    filter_back_to_back = ""
    filter_traded = ""
    start_date = pd.to_datetime(start_date).strftime("%Y-%m-%d")
    end_date = pd.to_datetime(end_date).strftime("%Y-%m-%d")

    # SQL Request
    df = execute_sql_query(
        "trades",
        "exane_risque",
        min_date=start_date,
        max_date=end_date,
        filter_sales=filter_sales,
        filter_alive=filter_alive,
        filter_market=filter_market,
        filter_back_to_back=filter_back_to_back,
        filter_traded=filter_traded,
    )

    # Reformat Columns
    df["isin"] = df["isin"].fillna(" - ")
    df[df["com_name"].notnull()]["ifnom"] = df[df["com_name"].notnull()]["com_name"]
    df["opdatenego"] = pd.to_datetime(
        df["opdatenego"], format="%d/%m/%Y", errors="coerce"
    )
    df["issue_date"] = pd.to_datetime(
        df["issue_date"], format="%d/%m/%Y", errors="coerce"
    )
    df["opmargevendeur"] = pd.to_numeric(df["opmargevendeur"])
    df["opquantite"] = pd.to_numeric(df["opquantite"])
    df["nominal"] = pd.to_numeric(df["nominal"])
    df["bid"] = pd.to_numeric(df["bid"])
    df["marge_bid_vente"] = pd.to_numeric(df["marge_bid_vente"])
    df["ask"] = pd.to_numeric(df["ask"])
    df["marge_ask_vente"] = pd.to_numeric(df["marge_ask_vente"])
    df["Perf. 3M"] = pd.to_numeric(df["Perf. 3M"])
    df["prmarche"] = df["prmarche"].apply(
        lambda x: "SED"
        if x == 184
        else "SIX"
        if x == 218
        else "TLX"
        if x == 919
        else "Not Listed"
    )

    # Add New Columns
    df["nb_trades"] = 1

    # Group By Product & Trade Date
    keys = [
        "cfin_product",
        "opdatenego",
        "nominal",
        "vcnom",
        "isin",
        "ifnom",
        "ifstatut",
        "issue_date",
        "maturity_date",
        "issuer",
        "issuer_otc",
        "prmarche",
        "currency",
        "date_cours",
        "bid",
        "marge_bid_vente",
        "ask",
        "marge_ask_vente",
        "Perf. 3M",
    ]
    df = (
        df.groupby(keys, dropna=False)
        .agg(
            opmargevendeur=("opmargevendeur", "sum"),
            opquantite=("opquantite", "sum"),
            nb_trades=("nb_trades", "sum"),
        )
        .reset_index(drop=False)
    )

    # Create Product Dataframe To Compute Product Margin
    df_products = df[["cfin_product", "opmargevendeur"]]
    df_products = (
        df_products.groupby(["cfin_product"], dropna=False)
        .agg(product_margin=("opmargevendeur", "sum"),)
        .reset_index(drop=False)
    )

    # Merge the 2 DataFrames
    df = df.merge(df_products, how="left", on=["cfin_product", "cfin_product"])

    # Set Issuer Type Column
    df.loc[df["issuer_otc"].notnull(), "issuer_type"] = "Back to Back"
    df.loc[
        (df["issuer_otc"].isnull())
        & (df["issuer"].str.lower().str.contains("exane") == 1),
        "issuer_type",
    ] = "Exane"
    df.loc[
        (df["issuer_otc"].isnull())
        & (df["issuer"].str.lower().str.contains("exane") == 0),
        "issuer_type",
    ] = "External"

    # Add Win / Loss Columns
    df["win"] = df["opmargevendeur"]
    df["loss"] = df["opmargevendeur"]
    df.loc[df["opmargevendeur"] < 0, "win"] = 0
    df.loc[df["opmargevendeur"] >= 0, "loss"] = 0

    # Reformat Status Columns
    df["ifstatut"] = df["ifstatut"].apply(lambda x: "Dead" if x in [7, 22] else "Alive")

    # Add Primary / Secondary Trades
    df["is_primary"] = False
    df.loc[df["opdatenego"] <= df["issue_date"], "is_primary"] = True

    # Add Side & Size Traded
    df["size_traded"] = df["opquantite"] * df["nominal"]
    df["trade_side"] = df["size_traded"].apply(lambda x: "Buy" if x > 0 else "Sell")

    # Oder By Descending Margin Depending On Issuer Dict
    df["issuer"] = df["issuer"].map(issuers_dict).fillna(df["issuer"])
    df["issuer_otc"] = df["issuer_otc"].map(issuers_dict).fillna(df["issuer_otc"])

    # Oder By Descending Margin
    df = df.sort_values(by="opmargevendeur", ascending=False)
    df = df.reset_index(drop=True)

    return df.rename(
        columns={
            "opdatenego": "Trade Date",
            "ifstatut": "Status",
            "opquantite": "Quantity",
            "nb_trades": "Nb Trd",
            "trade_side": "Trade Side",
            "vcnom": "Sales",
            "win": "Win Margin",
            "loss": "Loss Margin",
            "isin": "ISIN",
            "issuer": "Issuer",
            "issuer_otc": "Issuer OTC",
            "cfin_product": "Cfin",
            "ifnom": "Name",
            "issue_date": "Issue Date",
            "maturity_date": "Maturity Date",
            "size_traded": "Size Traded",
            "opmargevendeur": "Trade Margin",
            "prmarche": "Market",
            "currency": "Ccy",
            "nominal": "Nominal",
            "date_cours": "Last",
            "bid": "Bid",
            "ask": "Ask",
            "count": "Count",
            "issuer_type": "Issuer Type",
            "product_margin": "Product Margin",
            "is_primary": "Primary",
            "marge_bid_vente": "Bid Margin",
            "marge_ask_vente": "Ask Margin",
        }
    )


def bid_ask_rubbers(cfins):

    result = db.session.query(
        ContribInstrument.instrument_cfin.label("cfin"),
        ContribInstrument.rubbish_bid.label("bid"),
        ContribInstrument.rubbish_ask.label("ask"),
    ).filter(ContribInstrument.instrument_cfin.in_(cfins))

    return pd.DataFrame(result)


def get_underlying_tickers(cfin: int):

    df = pd.DataFrame(
        db.session.query(Rkpricing.prnumero.label("numero"))
        .select_from(Rkpricing)
        .filter(Rkpricing.prflag == 1)
        .filter(Rkpricing.prmode == 0)
        .filter(Rkpricing.prprofil == 1004)
        .filter(Rkpricing.prcfin == cfin)
        .all()
    )

    if df.empty:
        return []
    else:
        numero = int(df["numero"].max())
        df = pd.DataFrame(
            db.session.query(
                Rkpricingresultat.praxe1.label("cfin_ul"), Codes.cfcode.label("BBG"),
            )
            .select_from(Rkpricingresultat)
            .join(Codes, Codes.cfcfin == Rkpricingresultat.praxe1)
            .filter(Codes.cfsource == 11)
            .filter(~Codes.cfcode.like("% EU"))
            .filter(Rkpricingresultat.prindicateur == 3)
            .filter(Rkpricingresultat.prnumero == numero)
            .all()
        )

        if df.empty:
            return []
        else:
            return list(df["BBG"])


def traded_ul(start_date=prev_bday(10), end_date=datetime.datetime.now()):
    from models.storing import cached_ytd_trades

    df = cached_ytd_trades()
    df = df[
        (df["is_primary"] == True)
        & (pd.to_datetime(df["trade_date"]) >= pd.to_datetime(start_date))
        & (pd.to_datetime(df["trade_date"]) <= pd.to_datetime(end_date))
    ]
    df = df.groupby("cfin").first().reset_index()

    ul_list = []
    for i in range(0, len(df.index)):
        ul_list = ul_list + get_underlying_tickers(int(df.iloc[i].loc["cfin"]))

    return list(set(ul_list))


if __name__ == "__main__":
    # Display more columns when printing a Pandas DataFrame
    pd.options.display.width = 800
    pd.set_option("max_rows", 35)
    pd.set_option("max_columns", 50)

    with server.app_context():

        start_date = dt(2021, 8, 30).date()
        end_date = dt(2021, 8, 30).date()

        trades(dt(2021, 12, 19), dt(2021, 12, 21), cfin=48959725)

        df = execute_sql_query(
            "compo_full",
            index_cfin=39217985,
            start_date=start_date.strftime("%d/%m/%Y"),
            end_date=end_date.strftime("%d/%m/%Y"),
        )

        start_date = dt(2021, 9, 1)
        end_date = dt(2021, 9, 10)
        df = trades_and_products(start_date, end_date)
        # script = script_for_cfin(cfin=42190046)
        # levels_margins(34000990)
        # index_and_composition_full_for_cfin(37184025)

        # books_for_cfins_flex([43012527, 37630015, 36479077])

        # contribution_issues()

        # autocall_proba()
        #
        # amc_composition_histo(44130188, dt(2021, 2, 22), dt(2021, 2, 22))
        #
        # xccy_benchmark_vs_cfins(44130188, [44111638], dt(2021, 3, 30))
        #
        # performance(31519442, dt(2021, 1, 1), dt(2021, 3, 1))
        # x = products_histo()

        # greeks_from_pricing_results(45931025)

        # d = events_cpns_or_autocalls(events_date=dt(2021, 1, 25))

        # df = trades_and_products(start_date="2021-01-01", end_date="2021-06-04")
        # df = trades(start_date=dt(2021, 1, 1), end_date=dt(2021, 5, 17))
        # df.to_excel("test.xlsx")

        # df_calendar = events_cpns_or_autocalls()

        print(traded_ul())

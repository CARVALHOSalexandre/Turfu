import requests as rq
from requests import Session
import xmltodict
import json
import pandas as pd
import time


class Snapshot(rq.Session):
    BASE_URL = "http://vpw-coo-104:8010/api/Snapshot"

    def __init__(self):
        super().__init__()
        self.headers = {"Content-type": "application/json"}

    def data_for_cfins(self, cfins: list):
        r = self.post(self.BASE_URL, json=cfins)
        r.raise_for_status()
        if r.status_code == 200:
            return r.json()


url_contrib = "http://vpw-coo-104:8101/WSPo/WSPOContrib.asmx/"


def contrib_for_cfin(cfin):
    r = rq.post(url_contrib + "getContribForCfin", data={"cfin": cfin}, timeout=1)
    r.raise_for_status()
    x = xmltodict.parse(r.content).get("CContribDynaData")
    if x.get("UpdateTime"):
        return {
            "cfin": cfin,
            "bid": x.get("Bid"),
            "ask": x.get("Ask"),
            "mbid": x.get("MBid"),
            "mask": x.get("MAsk"),
            "datetime": pd.to_datetime(x.get("UpdateTime"), utc=True).tz_convert(
                "Europe/Paris"
            ),
        }


def contrib_for_cfins(cfins):
    n_try = 0
    while n_try < 5:
        try:
            url = url_contrib + "getContribForListCfin"
            r = rq.post(url, data={"cfins": cfins}, timeout=1)
            r.raise_for_status()
            data = (
                xmltodict.parse(r.content)
                .get("ArrayOfCContribDynaData")
                .get("CContribDynaData")
            )

            if not isinstance(data, list):
                data = [data]

            result = {}

            for x in data:
                # if x.get("UpdateTime") and bool(x.get("IsValid")):
                result[int(x.get("Cfin"))] = {
                    "bid": float(x.get("Bid")),
                    "ask": float(x.get("Ask")),
                    "mbid": float(x.get("MBid")),
                    "mask": float(x.get("MAsk")),
                    "datetime": x.get("UpdateTimeStr"),
                }
            return result

        except Exception as e:
            print(n_try)
            n_try += 1
            time.sleep(1)


if __name__ == "__main__":
    from pprint import pprint

    cfins = [305712, 536]

    contrib_for_cfins(cfins)

    live = Snapshot()
    pprint(live.data_for_cfins(cfins=cfins))

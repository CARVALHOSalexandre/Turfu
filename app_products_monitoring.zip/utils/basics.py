import re
import time
import datetime
import pandas as pd
from zeep.helpers import serialize_object
from pandas.tseries.offsets import BDay
from datetime import timedelta
from datetime import datetime as dt
from xlrd import xldate_as_tuple
from dateutil.parser import parse


def timeit(method):
    def timed(*args, **kw):
        ts = time.time()
        result = method(*args, **kw)
        te = time.time()
        if "log_time" in kw:
            name = kw.get("log_name", method.__name__.upper())
            kw["log_time"][name] = int((te - ts) * 1000)
        else:
            print("%r  %2.2f ms" % (method.__name__, (te - ts) * 1000))
        return result

    return timed


def try_parsing_date(text):
    for fmt in ("%d-%m-%Y", "%Y%m%d", "%d.%m.%Y", "%d/%m/%Y"):
        try:
            return dt.strptime(text, fmt)
        except ValueError:
            pass
    raise ValueError("no valid date format found")


def is_isin(code):
    length = len(code) == 12
    return length
    # two_letters = re.match("^[A-Z]{2}[0-9]{10}$", code)
    # five_letters = re.match("^[A-Z]{5}[0-9]{7}$", code)
    # return length and (two_letters or five_letters)


def to_str_percent(x):
    if not x:
        return "-"
    if pd.isna(x):
        return "-"
    return f"{x:.2%}"


def to_str_float(x, decimal_nb):
    if not x:
        return "-"
    if pd.isna(x):
        return "-"
    return f"{x:.{decimal_nb}f}"


def to_str_date(x, formatting=None):
    try:
        if not x:
            return "-"
        if pd.isna(x):
            return "-"
        if formatting:
            return pd.to_datetime(x).strftime(formatting)
        return pd.to_datetime(x).strftime("%b %d, %Y")
    except Exception as e:
        print(repr(e))


def capitalize_name(name):
    return " ".join([x.capitalize() for x in name.split(" ")])


def dt_today(formatting=None):
    today = datetime.datetime.today()

    if formatting == "string_date":
        return today.date().strftime("%b %d, %Y")

    if formatting == "string_datetime":
        return today.strftime("%b %d, %Y at %H:%M:%S")

    if formatting == "string_figures":
        return today.date().strftime("%Y%m%d")

    if formatting == "string_timestamp":
        return today.strftime("%Y-%m-%dT%H:%M:%S")

    if formatting == "julian":
        return (today.date() + timedelta(hours=12) + BDay(0)).to_julian_date()

    if formatting == "dt":
        return today

    return today.date()


def prev_bday(d=1, formatting=None):
    last_bday = dt_today() - pd.tseries.offsets.BDay(d)

    if formatting == "datetime":
        return last_bday

    if formatting == "string_date":
        return last_bday.strftime("%b %d, %Y")

    if formatting == "string_timestamp":
        return last_bday.strftime("%Y-%m-%dT%H:%M:%S")

    if formatting == "string_datetime":
        return last_bday.strftime("%b %d, %Y at %H:%M:%S")

    if formatting == "string_figures":
        return last_bday.strftime("%Y%m%d")

    if formatting == "julian":
        return (last_bday + datetime.timedelta(hours=12)).to_julian_date()

    return last_bday.date()


def next_bday(d=1, formatting=None):
    return prev_bday(-d, formatting)


def is_date(string, fuzzy=False):
    """
    Return whether the string can be interpreted as a date.

    :param string: str, string to check for date
    :param fuzzy: bool, ignore unknown tokens in string if True
    """
    try:
        parse(string, fuzzy=fuzzy)
        return True

    except ValueError:
        return False


def excel_to_date(excel_date):
    try:
        # In case the string as an Excel date format like 44258
        if excel_date.isnumeric():
            if 50000 > int(excel_date) > 10000:
                date = dt(*xldate_as_tuple(int(excel_date), 0))
                date = date.date()

        # In case the string as date format like "26/02/2021"
        if is_date(excel_date):
            date = parse(excel_date)
            date = date.date()
    except:
        pass
    return date


# @timeit
def serialize_api_result(data, zeep_serialization=False):
    """Serialize zeep objects to dictionaries

    :param zeep_serialization: Boolean if user wants original serialization from Zeep, can be slow
    :param data: results from request to SOAP services
    :return: list of dictionaries with relevant fields
    """
    if not data:
        return []

    if zeep_serialization:
        return serialize_object(data)

    result, valid_fields = [], []
    d = serialize_object(data[0])

    # Create list of valid fields, where value is not None
    for field, value in d.items():
        if value:
            valid_fields.append(field)

    # Create the list of results selecting valid values only
    for d in data:
        result.append({f: d[f] for f in valid_fields})

    return result

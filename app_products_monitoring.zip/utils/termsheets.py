import os
import urllib3
import requests as rq
import pandas as pd
from tqdm import tqdm


def link_termsheet(cfin, url_only=True, kind="exane"):
    # Disable warning InsecureRequestWarning
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    urls = {
        "exane": "https://webderdoc/webdedoc/api/rest/termsheets",
        "otc": "https://webderdoc/webdedoc/api/rest/termsheets-otc",
        "issuer": "https://webderdoc/webdedoc/api/rest/termsheets-issuer",
    }

    json = {"cfins": [cfin]}

    try:
        kind = kind.lower()

        r = rq.post(urls.get(kind), json=json, verify=False)
        r.raise_for_status()

        j = r.json().get("results")

        ts = j[0].get("termsheet")

        if ts:
            if url_only:
                return ts.get("url")
            return ts
    except Exception as e:
        pass


def get_termsheets(cfin):
    from utils.sql import alien

    if cfin != "None":

        termsheets = {
            "Exane": link_termsheet(cfin, kind="exane"),
            "Issuer": link_termsheet(cfin, kind="issuer"),
        }

        cfin_hedge = alien(cfin, with_issuer=True).get(53)

        if cfin_hedge:
            k = 1
            for value in cfin_hedge:
                kind = "OTC" if value["type"] == "OTC" else "issuer"
                link = link_termsheet(value["cfin"], kind=kind)
                name = f"{value['type']} {value['issuer']}"
                termsheets[name] = link
                k += 1

        return termsheets


if __name__ == "__main__":
    from app import server

    path = "T:/SD/termsheets/OTC"

    df = pd.read_clipboard()

    data = df.to_dict("records")

    with server.app_context():

        issues = []
        for d in tqdm(data):

            # folder = d["folder"].replace(" ", "")
            try:
                os.makedirs(f"{path}")
                # os.makedirs(f"{path}/{folder}")
            except FileExistsError:
                # directory already exists
                pass

            try:

                ts = link_termsheet(d["cfin"], url_only=True, kind="OTC")
                r = rq.get(ts, verify=False)
                with open(path + f"/{d['cfin']}.pdf", "wb") as f:
                    # with open(path + f"/{folder}/{d['cfin']}.pdf", "wb") as f:
                    f.write(r.content)
            except:
                issues.append(d["cfin"])

    print(get_termsheets(44941614))

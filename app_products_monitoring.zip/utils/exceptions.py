from app import app


class ApiPricingConnectionError(ConnectionError):
    def __init__(self, message):
        self.message = message
        super().__init__(self.message)
        app.logger.warning(self.message)

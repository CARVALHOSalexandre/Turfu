from datetime import datetime as dt
from datetime import timedelta

from requests import Session
from zeep import Client
from zeep.transports import Transport


class Crm(Session, Client):
    WSDL = "http://crm-ws:8080/crmWS/{}WS?wsdl"

    def __init__(self):
        super(Crm, self).__init__()
        super(Session, self).__init__(
            self.wsdl_url,
            transport=Transport(session=self),
        )

    @property
    def wsdl_url(self):
        service_name = self.name[3:].lower()
        return self.WSDL.format(service_name)

    @property
    def name(self):
        return self.__class__.__name__

    @property
    def service(self):
        return super().service


class CrmPersonne(Crm):
    pass


if __name__ == "__main__":
    personne = CrmPersonne()
    print(personne.service.getDataPersonneFromIdCRM(133620))

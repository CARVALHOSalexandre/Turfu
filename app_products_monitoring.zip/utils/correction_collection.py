from app import server
import utils.sql as sql
import utils.sql_amc as sql_amc
from utils.sql_write import delete_lines_in_collection, insert_line_in_collection
import pandas as pd
from datetime import datetime as dt
import numpy as np


def flex_order_type(data):
    if data["Qp1 (t-1)"] == 0:
        return "in"

    if data["Qp1 (t)"] == 0:
        return "out"

    if data["Qp1 (t-1)"] < data["Qp1 (t)"]:
        return "upsize"

    if data["Qp1 (t-1)"] > data["Qp1 (t)"]:
        return "downsize"


def amc_historical_data(cfin, start_date=None, end_date=None):

    if not start_date:
        start_date = dt(1900, 1, 1)

    if not end_date:
        end_date = dt.today()

    # Get raw data from Exane Database
    return sql.execute_sql_query(
        "compo",
        index_cfin=cfin,
        start_date=start_date.strftime("%d/%m/%Y"),
        end_date=end_date.strftime("%d/%m/%Y"),
    )


def amc_historical_orders(cfin, start_date=None, end_date=None):

    df_raw = amc_historical_data(cfin, start_date, end_date)

    df_raw.Date = pd.to_datetime(df_raw.Date, format="%d/%m/%Y")
    df_raw.sort_values(by="Date", inplace=True)
    df_qp1 = df_raw.pivot(index="Date", columns="Cfin", values="Qp1").sort_index(
        ascending=True
    )
    df_close = df_raw.pivot(index="Date", columns="Cfin", values="Close").sort_index(
        ascending=True
    )

    # Cleaning the Qp1 data
    df_qp1 = df_qp1.abs()
    df_normalize = df_qp1 / df_qp1
    df_normalize.fillna(0.0, inplace=True)

    # Initiate what this function returns
    result = {}

    for cfin_sjac in df_qp1.columns:

        # Create a DataFrame with Qp1 and previous Qp1
        s_qp1 = df_qp1[cfin_sjac].fillna(0.0)
        shifted_dates = s_qp1.reset_index().shift(1).Date
        data = np.array([shifted_dates, s_qp1.shift(1).fillna(0.0), s_qp1])
        dfc = pd.DataFrame(
            data=data.transpose(),
            columns=["t-1", "Qp1 (t-1)", "Qp1 (t)"],
            index=s_qp1.index,
        )
        dfc["Qp1 (t)"] = dfc["Qp1 (t)"].apply(pd.to_numeric)
        dfc["Qp1 (t-1)"] = dfc["Qp1 (t-1)"].apply(pd.to_numeric)
        dfc["t-1"] = dfc["t-1"].apply(pd.to_datetime)
        dfc = dfc[dfc["Qp1 (t-1)"].round(3) != dfc["Qp1 (t)"].round(3)]

        dfc["Issues"] = (dfc["Qp1 (t)"] != 0) & (
            dfc["Qp1 (t)"] == dfc["Qp1 (t)"].shift(2).fillna(0.0)
        )

        # Add the previous rows as issues
        dfc["Issues"] = dfc["Issues"] | dfc["Issues"].shift(-1)

        # Filter columns with issues
        dfc = dfc[~dfc.Issues][["t-1", "Qp1 (t-1)", "Qp1 (t)"]]

        # Attribute a type of order to each date
        dfc["Type"] = dfc.apply(flex_order_type, axis=1)

        d = list(dfc[dfc.Type.isin(["in", "out"])].index)
        result[cfin_sjac] = [
            {"date_in": x, "date_out": y} for x, y in zip(d[::2], d[1::2] + [None])
        ]

    # Get the execution level at each date

    return result


def rebuild_amc_collection(cfin, orders):

    collection = sql_amc.get_cfin_collection_from_cfin_amc(cfin)

    delete_lines_in_collection(collection)

    for cfin_sjac, dates_in_n_out in orders.items():

        for d in dates_in_n_out:
            insert_line_in_collection(
                cfin_collection=collection,
                cfin_sjac=cfin_sjac,
                date_in=d["date_in"],
                date_out=d["date_out"],
            )


if __name__ == "__main__":
    from pprint import pprint

    with server.app_context():

        cfin = 726910

        orders = amc_historical_orders(cfin)

        # Print underlyings with several operations
        for key, values in orders.items():
            if len(values) > 1:
                pprint(key)
                pprint(values)

        rebuild_amc_collection(cfin, orders)

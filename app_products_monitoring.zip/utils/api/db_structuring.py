import pprint
import re
import io
import decimal
import datetime
import time
from operator import itemgetter
from datetime import datetime as dt
import os
from flask import send_file
import numpy as np
import pandas as pd
from app import api, server, cache, PATH
from models.base import *
from sqlalchemy import create_engine
from config import Config

# from utils.certif_delta import CertifDeltas
from utils.basics import dt_today, prev_bday, excel_to_date, timedelta
from utils.osiris import (
    Osiris,
    coupon_freq,
    instrument_details,
    autocall_underlyings_details,
)
from flask_restx import Resource, reqparse
import utils.sql as sql
from utils.api_open_positions import OpenPositions
from utils.api_crm import CrmPersonne
from utils.api_contrib import ContribHisto, ContribInstrument
from utils.api_live import Snapshot, contrib_for_cfins
from utils.api_sg import SGPricer, cached_sg_underlying_universe
from utils.api_exane import ExaneInstruments
from utils.performance_attribution import return_analysis
from emails.mail_sender import MailNotification
from utils.graphs import graph_backtest
from utils.api_book_positions import Positions
from utils.api_sg_youtrack import YoutrackApi
from utils.certif_delta import get_certif_deltas
from pandas.tseries.offsets import BDay
from utils.sql_amc import structured_products_coupons
from local_db_mgt import PricingSources, IssuerRename
from xlrd import xldate_as_tuple
from xlrd.xldate import xldate_from_date_tuple, xldate_from_datetime_tuple
from dateutil.parser import parse

from sqlalchemy.orm import aliased
from sqlalchemy.sql import functions as sql_fcts
from sqlalchemy import (
    case,
    func,
    not_,
    and_,
    or_,
    cast,
    INTEGER,
)


def to_osiris_name(parameter):

    if parameter[:2] == "sp":
        parameter = parameter[3:]

    components = parameter.split("_")

    # We capitalize the first letter of each component except the first one
    # with the 'title' method and join them together.
    return components[0] + "".join(x.title() for x in components[1:])


def xldate_as_datetime(xldate, datemode=0):
    """Returns a DateTime for a given Excel Date

    :param xldate: Int - Date in Excel Format
    :param datemode: Int - 0 for 1900-based, 1 for 1904-based
    :return: DateTime
    """
    return datetime.datetime(1899, 12, 30) + datetime.timedelta(
        days=int(xldate) + 1462 * datemode
    )


def code_to_cfin_or_cfins(code: str, parameter: str, multi=False):

    if code == "#N/A" or "Loading" in code:
        return

    if multi:
        return [code_to_cfin_or_cfins(x, parameter) for x in code.split(",")]

    code = code.strip()

    if code == "SPX":
        return 312787

    if code == "SX5E":
        return 304392

    if code == "OMX":
        return 457240

    if code == "NKY":
        return 437259

    if parameter == "cfin_lib":
        r = Instrument.query.filter_by(ifnom=code).first()
        if r:
            return r.ifcfin

    if parameter == "cfin_ccy":
        r = Devise.query.filter_by(dvcodeiso=code).first()
        if r:
            return r.dvcfin

    if parameter in ["find_ticker", "find ticker", "search_ticker", "search ticker"]:
        # Look for all the Stocks, Alive with a name near user's value

        # Do not consider "Inc" in the code
        code = (
            code.lower()
            .replace(" inc", "")
            .replace("/the", "")
            .replace(" corp", "")
            .replace(" co", "")
            .replace("'s", "")
        )

        # First check with the full name
        r = (
            Instrument.query.filter(
                Instrument.iftype == 1,
                ~Instrument.ifstatut.in_([7, 22]),
                func.lower(Instrument.ifnom).like(f"{code}%"),
            )
            .order_by(Instrument.ifcfin.asc())
            .all()
        )
        if r:
            if len(r) == 1:
                return r[0].ifcfin
            return [x.ifcfin for x in r]

        # If no first result check with the first 10 characters
        r = (
            Instrument.query.filter(
                Instrument.iftype == 1,
                ~Instrument.ifstatut.in_([7, 22]),
                func.lower(Instrument.ifnom).like(f"{code[:10]}%"),
            )
            .order_by(Instrument.ifcfin.asc())
            .all()
        )
        if r:
            if len(r) == 1:
                return r[0].ifcfin
            return [x.ifcfin for x in r]

        # Still no result check with the first 5 characters
        r = (
            Instrument.query.filter(
                Instrument.iftype == 1,
                ~Instrument.ifstatut.in_([7, 22]),
                func.lower(Instrument.ifnom).like(f"{code[:5]}%"),
            )
            .order_by(Instrument.ifcfin.asc())
            .all()
        )
        if r:
            if len(r) == 1:
                return r[0].ifcfin
            return [x.ifcfin for x in r]

        return

    # Check if the code is a low number cfin (Stocks, Bonds, ...)
    if code.isdigit() and len(code) < 5:
        return code

    # Check if the code is an ISIN
    is_isin = re.findall("^[A-Z]{2}[0-9]{10}$|^[A-Z]{5}[0-9]{7}$", code)
    if is_isin:
        r = Codes.query.filter_by(cfcode=code).order_by(Codes.cfcfin).first()
        if r:
            return code_to_cfin_or_cfins(str(r.cfcfin), "")

    # Check if the code is an External RIC
    is_ric_code = re.findall("=[A-Z]{4}$", code)
    if is_ric_code:
        r = ExternalInstrument.query.filter_by(ric=code).first()
        if r:
            return r.instrument_cfin

    # Check if the code is a Position Cfin
    try:
        r = (
            db.session.query(
                Alien.alcfin, Alien.alsjac, Alien.altype, Instrument.iftype
            )
            .join(Instrument, Instrument.ifcfin == Alien.alsjac)
            .filter(
                and_(
                    or_(Alien.alsjac == code, Alien.alcfin == code), Alien.altype == 14,
                )
            )
            .all()
        )
        if r:
            return r[0].alsjac
    except:
        pass

    # Check if the code is a Cfin
    if code.isdigit():
        return code

    # Lastly, check if the code is in exane.codes
    code = code.upper().replace(" EQUITY", "").replace(" INDEX", "")
    r = Codes.query.filter_by(cfcode=code).order_by(Codes.cfcfin).first()
    if r:
        return r.cfcfin

    return "#N/A"


def cfin_contrib_for_cfin(cfin):

    if isinstance(cfin, list):
        return [cfin_contrib_for_cfin(x) or x for x in cfin]

    if isinstance(cfin, list):
        return

    if cfin == "#N/A":
        return

    r = Alien.query.filter(
        # or_(Alien.alsjac == cfin, Alien.alcfin == cfin), Alien.altype == 14
        or_(Alien.alsjac == cfin),
        Alien.altype == 14,
    ).first()

    if r:
        return r.alsjac if str(r.alcfin) == cfin else r.alcfin


def is_date(string, fuzzy=False):
    """
    Return whether the string can be interpreted as a date.

    :param string: str, string to check for date
    :param fuzzy: bool, ignore unknown tokens in string if True
    """
    try:
        parse(string, fuzzy=fuzzy)
        return True

    except ValueError:
        return False


@api.route("/api/edp")
class ExaneDataPoint(Resource):
    def get(self):

        # Add arguments parser
        parser = reqparse.RequestParser()
        parser.add_argument("parameter", type=str, help="Looking for parameter")
        parser.add_argument("code", help="Code of the product")
        parser.add_argument("option", help="Optional parameter")
        parser.add_argument("option2", help="Optional parameter")
        parser.add_argument("UserName", location="headers")
        parser.add_argument("Machine", location="headers")
        args = parser.parse_args()

        code = args.get("code") or "#N/A"

        # Check if user tried EDP on an empty cell
        if any(x in code for x in ["ExcelEmpty", "Loading"]):
            return

        parameter = args.get("parameter") or "cfin"
        parameter = parameter.lower()

        option = args.get("option")
        if option:
            option = option.lower()

        multi = option == "multi"

        option2 = args.get("option2")
        if option2:
            option2 = option2.lower()

        # Check if option or option2 is a date and convert it
        date = prev_bday()
        if parameter != "alien":
            for value in [option, option2]:
                if value:

                    if isinstance(value, str):

                        try:
                            # In case the string as an Excel date format like 44258
                            if value.isnumeric():
                                if 50000 > int(value) > 10000:
                                    date = dt(*xldate_as_tuple(int(value), 0))
                                    date = date.date()

                            # In case the string as date format like "26/02/2021"
                            if is_date(value):
                                date = parse(value, dayfirst=True)
                                date = date.date()

                        except:
                            pass

        # Prepare log message with the details
        msg = f"Call EDP on {args.get('Machine')} by {args.get('UserName')}"

        result = "#N/A"
        result_type = "string"

        try:

            cfin = code_to_cfin_or_cfins(code, parameter, multi)
            assert cfin is not None, "No Cfin Found"

            # Check if the product has a contrib Cfin
            cfin_contrib = cfin_contrib_for_cfin(cfin)

            if parameter in ["cfin", "cfin_ccy", "cfin_lib"]:
                result = cfin
                result_type = "int"

            elif parameter == "name":
                r = Instrument.query.filter_by(ifcfin=cfin).first()
                result = r.ifnom if r else result

            elif parameter in ["find_ticker", "ticker"]:
                if not isinstance(cfin, list):
                    cfin = [cfin]
                r = Codes.query.filter(
                    Codes.cfcfin.in_(cfin), Codes.cfsource == 11
                ).all()
                if r:
                    result = [x.cfcode for x in r]
                    if not option:
                        option = 1
                    result = result[: int(option)]

            elif parameter == "isin":
                r = Codes.query.filter(
                    Codes.cfcfin == cfin, Codes.cfsource == 6
                ).first()
                result = r.cfcode if r else result

            elif parameter == "figi":
                r = Codes.query.filter(
                    Codes.cfcfin == cfin, Codes.cfsource == 15
                ).first()
                result = r.cfcode if r else result

            elif parameter in ["ric", "reuters"]:
                r = Codes.query.filter(
                    Codes.cfcfin == cfin, Codes.cfsource == 3
                ).first()
                result = r.cfcode if r else result

            elif parameter in ["issuer_ref", "external_ref"]:
                r = Codes.query.filter(
                    Codes.cfcfin == cfin, Codes.cfsource == 335
                ).first()
                result = r.cfcode if r else result

            elif parameter in ["external_ric", "issuer_ric"]:
                if not isinstance(cfin, list):
                    cfin = [cfin]
                r = Codes.query.filter(
                    Codes.cfcfin.in_(cfin), Codes.cfsource == 334
                ).all()
                if r:
                    result = [x.cfcode for x in r]

                # Check in the ContribNext schema if missing previously
                r = ExternalInstrument.query.filter(
                    ExternalInstrument.instrument_cfin.in_(cfin)
                ).all()
                if r:
                    result = [x.ric for x in r if x.ric not in result]

            elif parameter == "valoren":
                r = Codes.query.filter(
                    Codes.cfcfin == cfin, Codes.cfsource == 7
                ).first()
                result = r.cfcode if r else result

            elif parameter in ["wmco", "wmco_cross"]:
                if not date:
                    date = prev_bday()
                option = option.upper()
                if option in [
                    "EUR",
                    "GBP",
                    "USD",
                    "CHF",
                    "RUB",
                    "JPY",
                    "CAD",
                    "AUD",
                    "NOK",
                    "DKK",
                ]:
                    option = sql.currency_to_cfin(option)
                cfin2 = code_to_cfin_or_cfins(option, parameter)
                r = sql.xccy_benchmark_vs_cfins([int(cfin)], int(cfin2), date)
                if r:
                    result = r[0].get("value")

            elif parameter == "product_status":
                r = Instrumentcomplement.query.filter_by(iccfin=cfin).first()
                result = r.typeetatdevie.tvlibelle if r else result

            elif parameter == "alien":
                r = Alien.query.filter(
                    or_(Alien.alcfin == cfin, Alien.alsjac == cfin),
                    Alien.altype == option,
                ).first()
                if r:
                    if cfin == str(r.alcfin):
                        result = r.alsjac
                    else:
                        result = r.alcfin

            elif parameter in ["ccy", "currency"]:
                r = Produit.query.filter_by(prcfin=cfin).first()
                result = r.devise.dvcodeiso if r else result

            elif parameter == "currency_cfin":
                r = Produit.query.filter_by(prcfin=cfin).first()
                ccy = r.devise.dvcodeiso if r else result
                result = code_to_cfin_or_cfins(ccy, "cfin_ccy")

            elif parameter in ["marche", "quotation_market"]:
                r = Produit.query.filter_by(prcfin=cfin).first()
                result = r.marche.manom if r else result

            elif parameter in ["quotation"]:
                r = Produit.query.filter_by(prcfin=cfin).first()
                result = r.modecot.monom if r else result

            elif parameter == "pays":
                r = Produit.query.filter_by(prcfin=cfin).first()
                result = r.pays.panomfr if r else result

            elif parameter == "country":
                r = Produit.query.filter_by(prcfin=cfin).first()
                result = r.pays.panom if r else result

            elif parameter == "sector":
                r = (
                    Hsectorisation.query.join(
                        Emission, Hsectorisation.hstiers == Emission.emissuer
                    )
                    .filter_by(emcfin=cfin)
                    .first()
                )
                result = r.secteur.sename if r else result

            elif parameter == "secteur":
                r = (
                    Hsectorisation.query.join(
                        Emission, Hsectorisation.hstiers == Emission.emissuer
                    )
                    .filter_by(emcfin=cfin)
                    .first()
                )
                result = r.secteur.senom if r else result

            elif parameter == "issuer":
                r = Emission.query.filter_by(emcfin=cfin).first()
                result = r.tier.tinom if r else result

            elif parameter == "renamed_issuer":
                r = Emission.query.filter_by(emcfin=cfin).first()
                if r:
                    name = r.tier.tinom
                    r = IssuerRename.query.filter_by(weird_name=name).first()
                result = r.name if r else result

            elif parameter == "renamed_issuer_otc":
                r = (
                    db.session.query(
                        Instrument.ifcfin.label("cfin"), Tier.tinom.label("issuer"),
                    )
                    .select_from(Instrument)
                    .outerjoin(
                        (Emission, Emission.emcfin == Instrument.ifcfin),
                        (
                            Alien,
                            and_(Alien.alsjac == Instrument.ifcfin, Alien.altype == 53),
                        ),
                        (Contratotcs, Contratotcs.cocfin == Alien.alcfin),
                        (Tier, Tier.ticode == Contratotcs.coreceveur),
                    )
                    .filter(Instrument.ifcfin == cfin)
                ).first()
                if r:
                    name = r.issuer
                    r = IssuerRename.query.filter_by(weird_name=name).first()
                result = r.name if r else result

            elif parameter == "issuer_full":
                r = Emission.query.filter_by(emcfin=cfin).first()
                result = r.tier.tinom if r else result

                # Check if product is hedged
                data = sql.alien(cfin, with_issuer=True).get(53)
                if data:
                    for d in data:
                        issuer_hedge = (
                            f"{d.get('type')} {d.get('issuer')} ({d['cfin']})"
                        )
                        result += ", " + issuer_hedge

            elif parameter == "issuer_code":
                r = Emission.query.filter_by(emcfin=cfin).first()
                result = r.tier.ticode if r else result

            elif parameter == "trade_date":
                r = Emission.query.filter_by(emcfin=cfin).first()
                result = r.emdate if r else result

            elif parameter == "strike_date":
                r = Emission.query.filter_by(emcfin=cfin).first()
                result = r.emdatestrike if r else result

            elif parameter == "issue_date":
                r = Emission.query.filter_by(emcfin=cfin).first()
                result = r.empaiement if r else result

            elif parameter == "maturity_date":
                r = Emission.query.filter_by(emcfin=cfin).first()
                if not r.emmaturite:
                    r = Contrats.query.filter_by(ctcfin=cfin).first()
                    result = r.ctmaturite if r else result
                else:
                    result = r.emmaturite if r else result

            elif parameter == "nominal":
                r = Emission.query.filter_by(emcfin=cfin).first()
                result = r.emnominal if r else result

            elif parameter == "issue_price":
                r = Emission.query.filter_by(emcfin=cfin).first()
                result = r.emprix if r else result

            elif parameter == "point_value":
                r = Emission.query.filter_by(emcfin=cfin).first()
                result = r.emprixpoint if r else result

            elif parameter == "issue_size":
                df_pott, details, status = sql.trades_summary(cfin)
                result = "Not Found"
                result_type = "string"
                if (
                    details.get("issued")
                    and float(details.get("issued").split(" ")[0].replace(",", "")) != 0
                ):
                    result = float(details.get("issued").split(" ")[0].replace(",", ""))
                    result_type = "float"
                else:
                    r = Emission.query.filter_by(emcfin=cfin).first()
                    if r:
                        result = r.emcapiinit
                        result_type = "float"

            elif parameter in ["close_hrix", "close hrix"]:
                r = (
                    db.session.query(Hrix.hixclose)
                    .filter(
                        Hrix.hixcfin == (cfin_contrib or cfin), Hrix.hixdate == date,
                    )
                    .order_by(Hrix.hixdate.desc())
                    .first()
                )
                result = r.hixclose if r else result

            elif parameter in ["close"]:
                r = (
                    db.session.query(Historiques.hoclose)
                    .filter(
                        Historiques.hocfin == (cfin_contrib or cfin),
                        Historiques.hodate == date,
                    )
                    .order_by(Historiques.hodate.desc())
                    .first()
                )
                result = r.hoclose if r else result

            elif parameter in ["close_brut", "close brut"]:
                r = (
                    db.session.query(Historiques.hoclosbrut)
                    .filter(
                        Historiques.hocfin == (cfin_contrib or cfin),
                        Historiques.hodate == date,
                    )
                    .order_by(Historiques.hodate.desc())
                    .first()
                )
                result = r.hoclosbrut if r else result

            elif parameter in ["open"]:
                r = (
                    db.session.query(Historiques.hoopen)
                    .filter(
                        Historiques.hocfin == (cfin_contrib or cfin),
                        Historiques.hodate == date,
                    )
                    .order_by(Historiques.hodate.desc())
                    .first()
                )
                result = r.hoopen if r else result

            elif parameter in ["last_close", "last close"]:
                r = (
                    db.session.query(Historiques.hoclose)
                    .filter(
                        Historiques.hocfin == (cfin_contrib or cfin),
                        Historiques.hodate <= date,
                    )
                    .order_by(Historiques.hodate.desc())
                    .first()
                )
                result = r.hoclose if r else result

            elif parameter in ["last_close_hrix", "last close hrix"]:
                r = (
                    db.session.query(Hrix.hixclose)
                    .filter(
                        Hrix.hixcfin == (cfin_contrib or cfin), Hrix.hixdate <= date,
                    )
                    .order_by(Hrix.hixdate.desc())
                    .first()
                )
                result = r.hixclose if r else result

            elif parameter in ["last_open", "last open"]:
                r = (
                    db.session.query(Historiques.hoopen)
                    .filter(
                        Historiques.hocfin == (cfin_contrib or cfin),
                        Historiques.hodate <= date,
                    )
                    .order_by(Historiques.hodate.desc())
                    .first()
                )
                result = r.hoopen if r else result

            elif parameter in ["bid", "last_bid", "last bid"]:
                r = (
                    db.session.query(Historiques.hobid)
                    .filter(
                        Historiques.hocfin == (cfin_contrib or cfin),
                        Historiques.hodate <= date,
                    )
                    .order_by(Historiques.hodate.desc())
                    .first()
                )
                result = r.hobid if r else result

            elif parameter in ["ask", "last_ask", "last ask"]:
                r = (
                    db.session.query(Historiques.hoask)
                    .filter(
                        Historiques.hocfin == (cfin_contrib or cfin),
                        Historiques.hodate <= date,
                    )
                    .order_by(Historiques.hodate.desc())
                    .first()
                )
                result = r.hoask if r else result

            elif parameter in ["last_date", "date_last", "last date"]:
                r = (
                    db.session.query(Historiques.hodate)
                    .filter(
                        Historiques.hocfin == (cfin_contrib or cfin),
                        Historiques.hodate <= date,
                    )
                    .order_by(Historiques.hodate.desc())
                    .first()
                )
                result = r.hodate if r else result

            elif parameter == "contrib_bid":
                df = ContribHisto().intraday_last([cfin])
                if not df.empty:
                    result = float(df.iloc[-1, 2])

            elif parameter == "contrib_ask":
                df = ContribHisto().intraday_last([cfin])
                if not df.empty:
                    result = float(df.iloc[-1, 3])

            elif parameter == "contrib_datetime":
                df = ContribHisto().intraday_last([cfin])
                if not df.empty:
                    result = df.iloc[-1, 1]
                    result = result.strftime("%Y-%m-%d %H:%M:%S")

            elif parameter == "contrib_trading_bid_margin":
                data = ContribHisto().trading_margins(cfin)
                if data:
                    trading_margin = data.get("tradingBidMarginsDetails")
                    if trading_margin:
                        margin_details = [
                            x for x in trading_margin if x["marginType"] == "MARGIN"
                        ]
                        result = margin_details[0].get("marginValue")

            elif parameter in ["live_bid", "bid_live"]:
                r = (
                    IntradayDer.query.filter_by(iddcfin=(cfin_contrib or cfin))
                    .order_by(IntradayDer.iddstamp.desc())
                    .first()
                )
                result = r.iddbid if r else result

            elif parameter in ["live_ask", "ask_live"]:
                r = (
                    IntradayDer.query.filter_by(iddcfin=(cfin_contrib or cfin))
                    .order_by(IntradayDer.iddstamp.desc())
                    .first()
                )
                result = r.iddask if r else result

            elif parameter in ["product_ul", "product ul"]:
                inst_ul = aliased(Instrument)
                inst_base = aliased(Instrument)
                r = (
                    db.session.query(inst_ul.ifcfin.label("Cfin"),)
                    .select_from(inst_base)
                    .join(Derives, Derives.decfin == inst_base.ifcfin)
                    .join(inst_ul, inst_ul.ifcfin == Derives.desjac)
                    .filter(inst_base.ifcfin == cfin)
                    .first()
                )
                result = r[0] if r else result

            elif parameter in ["time_live", "live_time", "live time"]:
                r = (
                    IntradayDer.query.filter_by(iddcfin=(cfin_contrib or cfin))
                    .order_by(IntradayDer.iddstamp.desc())
                    .first()
                )
                if r:
                    result = r.iddstamp
                    result = result.strftime("%Y-%m-%dT%H:%M:%S.%f%z")

            elif parameter == "bid_margin":
                r = (
                    HwarDrEx.query.filter_by(hxcfin=(cfin_contrib or cfin))
                    .order_by(HwarDrEx.hxdate.desc())
                    .first()
                )
                result = r.hxmargebid_v if r else result

            elif parameter == "ask_margin":
                r = (
                    HwarDrEx.query.filter_by(hxcfin=(cfin_contrib or cfin))
                    .order_by(HwarDrEx.hxdate.desc())
                    .first()
                )
                result = r.hxmargeask_v if r else result

            elif parameter in ["product_type", "type_product"]:
                r = Instrument.query.filter_by(ifcfin=cfin).first()
                result = r.typecontrat.tctnom if r else result

            elif parameter in ["instrument_type", "type_instrument"]:
                r = Instrument.query.filter_by(ifcfin=cfin).first()
                result = r.typeinstrument.tynom if r else result

            elif parameter in ["payoff_type"]:
                r = Instrument.query.filter_by(ifcfin=cfin).first()
                result = r.typepayoff.tflnom if r else result

            elif parameter == "cpn_per_period":
                r = Emisstructuree.query.filter_by(escfin=cfin).first()
                result = r.esmontantcoupon / 100 if r else result

            elif parameter == "bond_next_cpn_date":
                r = (
                    Scriptcoupon.query.filter(
                        Scriptcoupon.sccfin == cfin, Scriptcoupon.scdate >= dt_today(),
                    )
                    .order_by(Scriptcoupon.scdate.desc())
                    .first()
                )
                result = r.scdate if r else result

            elif parameter in ["clean_dirty", "cleandirty", "clean dirty"]:
                r = Amort.query.filter(Amort.amcfin == cfin,).first()
                result = r.amclean if r else result

            elif parameter == "last_obs_date":
                r = (
                    Scriptcoupon.query.filter_by(sccfin=cfin)
                    .order_by(Scriptcoupon.scdate)
                    .first()
                )
                result = r.scdate if r else result

            elif parameter == "opinion":
                r = Afsociete.query.filter_by(socfin=cfin).first()
                result = r.opinion.oplibellegb if r else result

            elif parameter == "opinion_update":
                r = Afsociete.query.filter_by(socfin=cfin).first()
                result = r.sodatemodif if r else result

            elif parameter == "target_price":
                r = Afsociete.query.filter_by(socfin=cfin).first()
                result = r.soobjhaut if r else result

            elif parameter == "quotite":
                r = Produit.query.filter_by(prcfin=cfin).first()
                result = r.prquotite if r else result

            elif parameter == "typo_front":
                r = (
                    db.session.query(VTypofoLibelle.libelle_deduit)
                    .join(Instrument, Instrument.iftypofo == VTypofoLibelle.code_typo,)
                    .filter(Instrument.ifcfin == cfin)
                    .first()
                )
                result = r.libelle_deduit if r else result

            elif parameter == "typo_front_group":
                r = Instrument.query.filter_by(ifcfin=cfin).first()
                result = (
                    r.typofoinstrumentsautorisee.typofoinstrument.tilibelle
                    if r
                    else result
                )

            elif parameter in ["keyword", "keywords"]:
                r = (
                    db.session.query(VTypologie.libelle_typologie)
                    .filter(
                        VTypologie.flag_typologie != 3,
                        VTypologie.code_famille_typologie == 32,
                        VTypologie.code_valeur_typee == cfin,
                    )
                    .all()
                )
                if r:
                    result = " - ".join([r.libelle_typologie for r in r])

            elif parameter == "typo_montage":
                r = (
                    db.session.query(VTypologie.libelle_typologie)
                    .filter(
                        VTypologie.flag_typologie != 3,
                        VTypologie.code_famille_typologie == 9,
                        VTypologie.code_valeur_typee == cfin,
                    )
                    .first()
                )
                result = r.libelle_typologie if r else result

            elif parameter in ["typo_vestr", "typo vestr"]:
                r = (
                    db.session.query(VTypologie.libelle_typologie)
                    .filter(
                        VTypologie.flag_typologie != 3,
                        VTypologie.code_famille_typologie == 86,
                        VTypologie.code_valeur_typee == cfin,
                    )
                    .first()
                )
                result = r.libelle_typologie if r else result

            elif parameter in ["type_ul", "ul_type"]:
                r = Emisstructuree.query.filter_by(escfin=cfin).first()
                result = r.typesjcemisstructuree.tselibelle if r else result

            elif parameter in ["type_client", "client_type"]:
                r = Emisstructuree.query.filter_by(escfin=cfin).first()
                result = r.typeclient.tclibelle if r else result

            elif parameter in [
                "email_flex",
                "email flex",
                "mail_flex",
                "mail flex",
                "flex_email",
                "flex email",
                "flex_mail",
                "flex mail",
            ]:
                r = (
                    db.session.query(Idxattributs.xavaleurstring.label("email")).filter(
                        Idxattributs.xacfin == cfin, Idxattributs.xatypeattribut == 71,
                    )
                ).first()
                result = r.email if r else result

            elif parameter in [
                "last_cube_calc",
                "last_cube_date",
                "last_cube_calc_date",
            ]:
                r = (
                    Rkscriptindicateur.query.filter_by(sicfin=cfin)
                    .order_by(Rkscriptindicateur.sidate.desc())
                    .first()
                )
                result = r.sidate if r else result

            elif parameter in ["ul_o", "underlying_option", "ul_option"]:
                r = Derives.query.filter_by(decfin=cfin).first()
                result = r if r else result

            elif parameter in ["sale", "sales", "vendeur", "vendeurs"]:
                r = Rkoperation.query.filter_by(opcfin=cfin).all()
                result = (
                    ", ".join(set([x.sales.vcnom for x in r if x.sales]))
                    if r
                    else result
                )

            elif parameter in ["operator", "operators"]:
                r = Rkoperation.query.filter_by(opcfin=cfin).all()
                operators = set([x.user.usnom.capitalize() for x in r if x.opuser])
                if operators:
                    result = ", ".join(operators) if r else result

            elif parameter in ["pose", "position", "client_pose", "pose_client"]:
                result = OpenPositions().historical_position_for_cfin(
                    cfin, max_date=date, client=option2
                )
                result_type = "float"
                if not result:
                    if cfin_contrib is not None:
                        result = OpenPositions().historical_position_for_cfin(
                            cfin_contrib, max_date=date
                        )
                        result_type = "float"
                    else:
                        result = "Not Found"
                        result_type = "string"

            elif parameter in ["pose_book"]:
                r = Positions().positions_for_cfin(cfin)
                if r:
                    result = sum([x["position"]["position"] for x in r])

            elif parameter in ["pose_book_details"]:
                r = Positions().positions_for_cfin(cfin)
                if r:
                    nominal = sql.nominal_for_cfin(cfin)
                    positions = [x for x in r if x["issueDetails"]["investedPosition"]]
                    result = "; ".join(
                        [
                            f"{-nominal * x['issueDetails']['investedPosition']:,.0f} in {x['bookId']}"
                            for x in positions
                        ]
                    )

            elif parameter in ["pose_amc", "position amc", "pose amc"]:
                summary = sql.positions_details(cfin, date)
                result_type = "float"
                if summary.get("positions_amc"):
                    result = summary.get("positions_amc")
                else:
                    result = 0

            elif parameter == "maturity_payoff":
                r = (
                    db.session.query(Rkpricingresultat.prvaleur)
                    .join(Rkpricing, Rkpricing.prnumero == Rkpricingresultat.prnumero)
                    .filter(
                        Rkpricing.prcfin == cfin, Rkpricingresultat.prindicateur == 39,
                    )
                    .order_by(Rkpricingresultat.prnumero.desc())
                    .first()
                )
                result = r.prvaleur / 100 if r else result
                result_type = "float"

            elif parameter == "ul_certif":
                value = sql.ul_certif(cfin)
                result = int(value) if value else result
                result_type = "int"

            elif parameter == "delta_certif":
                if not date:
                    r = (
                        db.session.query(func.max(Rkpricing.prdate)).filter(
                            Rkpricing.prcfin == cfin, Rkpricing.prmode == 1  # Mode Full
                        )
                    ).first()
                    if r:
                        date = r[0]

                df = sql.execute_sql_query(
                    "delta_certif",
                    "exane_risque",
                    input_cfin=cfin,
                    input_date=date.strftime("%d/%m/%Y"),
                )
                if not df.empty:
                    result = df["delta_agg"].iloc[0]
                result_type = "float"

            elif parameter in ["type_osiris", "type osiris"]:
                result = Osiris().field_for_cfin(cfin, "type")

            elif parameter in ["osiris_id", "osiris id"]:
                result = Osiris().field_for_cfin(cfin, "id")

            elif parameter in ["osiris_book", "osiris book"]:
                result = Osiris().field_for_cfin(cfin, "bookId")

            elif parameter in ["next_call_date", "sp_next_call_date"]:
                r = Osiris().cfin_details(cfin)
                if r:
                    dates = r.get("fixingDates")
                    last_bday = prev_bday(1, "string_timestamp")
                    next_dates_details = [
                        x
                        for x in dates
                        if x["fixingDate"] > last_bday and x["callable"]
                    ]
                    nearest_date = next_dates_details[0].get("fixingDate")
                    nearest_date = pd.to_datetime(nearest_date, utc=True)
                    nearest_date = nearest_date.tz_convert("Europe/Paris")
                    result = nearest_date.date()
                    result_type = "date"

            elif parameter in [
                "next_cpn_date",
                "next_coupon_date",
                "next cpn date",
                "next coupon date",
            ]:
                r = Osiris().cfin_details(cfin)
                if r:
                    dates = r.get("fixingDates")
                    last_bday = prev_bday(1, "string_timestamp")
                    next_dates_details = [
                        x for x in dates if x["fixingDate"] > last_bday
                    ]
                    nearest_date = next_dates_details[0].get("fixingDate")
                    nearest_date = pd.to_datetime(nearest_date, utc=True)
                    nearest_date = nearest_date.tz_convert("Europe/Paris")
                    result = nearest_date.date()
                    result_type = "date"

            elif parameter in [
                "autocall",
                "autocall_barrier",
                "autocall_trigger",
                "next_call_barrier",
                "sp_next_call_barrier",
            ]:
                r = Osiris().cfin_details(cfin)
                if r:
                    if r["earlyRedemptionBarrierNonConstant"]:
                        dates = r.get("fixingDates")
                        last_bday = prev_bday(1, "string_timestamp")
                        next_dates_details = [
                            x
                            for x in dates
                            if x["fixingDate"] > last_bday and x["callable"]
                        ]
                        result = next_dates_details[0].get("earlyRedemptionBarrier")
                    else:
                        result = r["earlyRedemptionBarrier"]

                    result_type = "float"

            elif parameter in ["sp_maturity", "maturity_month", "maturity_months"]:
                r = Osiris().cfin_details(cfin)
                result = r.get("termToMaturity") if r else result

            elif parameter in ["is_issuer_callable", "sp_is_issuer_callable"]:
                r = Osiris().cfin_details(cfin)
                result = r.get("issuerCallable") if r else result
                result_type = "bool"

            elif parameter in ["frequency", "sp_frequency"]:
                r = Osiris().cfin_details(cfin)
                if r:
                    periodicity = r["fixingScheduleParameters"].get("periodicity")
                    result = coupon_freq.get(periodicity)

            elif parameter in [
                "cpn_barrier",
                "coupon_barrier",
                "sp_coupon_barrier",
                "protection_barrier",
                "sp_protection_barrier",
                "protection_barrier_type",
                "sp_protection_barrier_type",
                "sp_coupon",
            ]:
                r = Osiris().cfin_details(cfin)
                if r:
                    result = r.get(to_osiris_name(parameter)) or "None"

            elif parameter in ["client", "clients"]:
                r = OpenPositions().clients_for_cfin(cfin)
                result = r if r else result

            elif parameter in ["contact", "contacts"]:
                r = OpenPositions().contacts_for_cfin(cfin)
                result = r if r else result

            elif parameter == "advisor":
                i = ExaneInstruments()
                r = i.service.getPersonIdFromCfin(cfin)
                result = "Not Found"
                if r:
                    ids = [x["id"] for x in r if not x["toDelete"]]
                    crm = CrmPersonne()
                    contact_details = crm.service.getDataPersonneFromIdCRM(ids[0])
                    if contact_details:
                        result = contact_details["institutionName"]

            elif parameter in [
                "coupon_paid_between_dates",
                "cpn_paid_between_dates",
                "coupon paid between dates",
                "cpn paid between dates",
            ]:

                if option:
                    start_date = excel_to_date(option)
                    if option2:
                        end_date = excel_to_date(option2)
                    else:
                        end_date = dt.today()

                    sub_query = (
                        db.session.query(
                            Emission.empaiement,
                            Echeancier.ecdateex,
                            Echeancier.ecdate,
                            (Echeancier.ecmontant / Emission.emnominal).label("cpns"),
                            Amort.amcouponrule,
                        )
                        .select_from(Echeancier)
                        .join(Emission, Emission.emcfin == Echeancier.eccfin)
                        .join(Amort, Amort.amcfin == Echeancier.eccfin)
                        .filter(Echeancier.eccfin == cfin)
                        .filter(Echeancier.ecdateex >= start_date)
                        .filter(Echeancier.ecdateex <= end_date)
                        .subquery()
                    )

                    r = (
                        db.session.query(
                            sql_fcts.coalesce(100 * sql_fcts.sum(sub_query.c.cpns), 0)
                        )
                        .select_from(sub_query)
                        .first()
                    )

                    result = r[0] if r else result

            elif parameter in [
                "redemption_date",
                "redemption date",
            ]:
                """Returns a date, the minimum between the followings:
                - Autocall Date (if relevant)
                - Maturity Date
                - Change of status Date in Simbad
                """

                # Set the Maturity Date
                maturity_date = None
                r = Emission.query.filter_by(emcfin=cfin).first()
                if not r.emmaturite:
                    r = Contrats.query.filter_by(ctcfin=cfin).first()
                    maturity_date = r.ctmaturite
                else:
                    maturity_date = r.emmaturite

                # Set the autocall date if relevant
                r = Osiris().cfin_details(cfin)
                if r:
                    dates = r.get("fixingDates")
                    past_autocall_dates = [
                        x
                        for x in dates
                        if x["fixingDate"] <= dt_today("string_timestamp")
                        and x.get("callable")
                    ]
                    nearest_date = past_autocall_dates[0].get("fixingDate")
                    nearest_date = pd.to_datetime(nearest_date, utc=True)
                    nearest_date = nearest_date.tz_convert("Europe/Paris")
                    result = nearest_date.date()
                    result_type = "date"

            elif parameter in [
                "accrued_coupon",
                "accrued_coupons",
                "accrued coupon",
                "accrued coupons",
                "accrued_cpn",
                "accrued cpn",
            ]:

                r = (
                    db.session.query(VTypologie.code_valeur_typologie)
                    .select_from(VTypologie)
                    .filter(
                        (VTypologie.flag_typologie == 1),
                        (VTypologie.code_famille_typologie == 24),
                        (VTypologie.code_valeur_typee == cfin),
                    )
                    .first()
                )

                if r:

                    # If user passed date as option argument
                    if isinstance(option, str) and option != "":
                        d = date
                    else:
                        d = dt_today() + BDay(2)

                    dd = d + BDay(2)
                    date = dd.strftime("%Y-%m-%d")

                    # If perpetual bond
                    if r[0] == 8858:
                        df = sql.execute_sql_query(
                            "accrued_cpn_perpetual",
                            "exane_risque",
                            dd=date,
                            cfin_bis=cfin,
                        )
                    else:
                        df = sql.execute_sql_query(
                            "accrued_cpn", "exane_risque", dd=date, cfin_bis=cfin
                        )

                    current_date = pd.to_datetime(df.iloc[0, 0], format="%d/%m/%Y")
                    next_date = pd.to_datetime(df.iloc[0, 1], format="%d/%m/%Y")
                    prev_date = pd.to_datetime(df.iloc[0, 2], format="%d/%m/%Y")
                    coupon = df.iloc[0, 3]

                    if coupon < 0:
                        accrued_coupon = 0
                    else:
                        nb_days_period = prev_date - next_date
                        nb_days = prev_date - current_date
                        accrued_coupon = coupon * (nb_days / nb_days_period)

                    result = accrued_coupon
                    result_type = "float"

                else:
                    result = 0
                    result_type = "float"

            else:
                result = f"{parameter} is not a valid parameter"

            if isinstance(result, list):
                result = ", ".join(result)

            if isinstance(result, (datetime.date, datetime.datetime)):
                result = result.strftime("%Y-%m-%d")
                result_type = "date"

            if isinstance(result, decimal.Decimal):
                result = float(result)

            msg += f" - Getting {parameter} for {code}"
            if option:
                msg += f" - Optional value '{option}'"
            if option2:
                msg += f" - 2nd Optional value '{option2}'"
            if date:
                msg += f" - Date {date}"
            msg += f" - Result: {result}"

        except AssertionError as e:
            msg += f" - No Cfin found for {code}"
            if parameter and code:
                msg += f" - Getting {parameter} for {code}"
            if option:
                msg += f" - Optional value '{option}'"
            if option2:
                msg += f" - 2nd Optional value '{option2}'"
            if date:
                msg += f" - Date {date}"
            server.logger.exception(e)

        except Exception as e:
            msg += " - issue using the API"
            if parameter and code:
                msg += f" - Getting {parameter} for {code}"
            if option:
                msg += f" - Optional value '{option}'"
            if option2:
                msg += f" - 2nd Optional value '{option2}'"
            if date:
                msg += f" - Date {date}"
            server.logger.exception(e)

        finally:
            server.logger.info(msg)
            return {"code": code, "value": result, "type": result_type}


@api.route("/api/edh")
class ExaneDataHistory(Resource):
    def get(self):

        # Add arguments parser
        parser = reqparse.RequestParser()
        parser.add_argument("parameter", type=str, help="Looking for parameter")
        parser.add_argument("code", help="Code of the product")
        parser.add_argument("start_date", help="Code of the product")
        parser.add_argument("end_date", help="Code of the product")
        parser.add_argument("option", help="Optional parameter")
        parser.add_argument("convert_dates", help="Optional parameter")
        parser.add_argument("UserName", location="headers")
        parser.add_argument("Machine", location="headers")
        args = parser.parse_args()

        code = args.get("code") or "#N/A"
        code = code.lower()
        parameter = args.get("parameter") or "cfin"
        parameter = parameter.lower()
        option = args.get("option")

        if option:
            option = option.lower()

        multi = "multi" in option

        # Prepare the dates
        start_date = args.get("start_date") or prev_bday(5)
        if isinstance(start_date, str):
            start_date = pd.to_datetime(start_date, format="%d/%m/%Y").date()

        end_date = args.get("end_date") or dt_today()
        if isinstance(end_date, str):
            end_date = pd.to_datetime(end_date, format="%d/%m/%Y").date()

        # Prepare log message with the details
        msg = f"Call EDH on {args.get('Machine')} by {args.get('UserName')}"

        result = "#N/A"
        result_type = ["string"]

        try:

            df = pd.DataFrame()

            # If code is not a cfin
            if code in [
                "position",
                "positions",
            ]:

                filter_sales = ""
                filter_alive = ""
                filter_market = ""
                filter_back_to_back = ""
                filter_traded = ""

                if "minifut" not in parameter:

                    filters = [str(x).strip() for x in parameter.split(";")]

                    for filter in filters:

                        if "listed" in filter:
                            filter_market = "AND prmarche in (38, 184, 218, 919)"

                        if any(
                            x in filter
                            for x in [
                                "b2b",
                                "btb",
                                "backtoback",
                                "back to back",
                                "back_to_back",
                            ]
                        ):
                            filter_back_to_back = "AND alien_otc.alcfin IS NOT NULL"

                        if "external" in filters:
                            filter_back_to_back = "AND alien_otc.alcfin IS NULL AND tiers_product.tinom NOT LIKE 'Exane%'"

                        if "alive" in filters:
                            filter_alive = "AND ifstatut NOT IN (7, 22)"

                        if "traded" in filters:
                            filter_traded = "AND opmargevendeur IS NOT NULL"

                        if "sales" in filter:
                            sales = filter.split("=")[1]
                            sales = [f"'{x.capitalize()}'" for x in sales.split(",")]
                            filter_sales = f"AND vcnom in ({', '.join(sales)})"

                        if "all" in filter:
                            start_date = dt(2000, 1, 1).date()

                    df = sql.execute_sql_query(
                        "positions",
                        "exane_risque",
                        min_date=start_date,
                        max_date=end_date,
                        filter_sales=filter_sales,
                        filter_alive=filter_alive,
                        filter_market=filter_market,
                        filter_back_to_back=filter_back_to_back,
                        filter_traded=filter_traded,
                    )

                    # Add column that mentions if products are bid only
                    if "bid_only" in filter:
                        ci = ContribInstrument()
                        data = ci.multi_ask_disabled(list(df.Cfin))
                        df["Bid Only"] = df.Cfin.apply(lambda x: data.get(x, False))

                    try:
                        cfins = df["Cfin"].unique().tolist()

                        if len(cfins) < 200:

                            # Add the issued positions from internal service
                            positions = Positions().positions_for_cfins(cfins)

                            d_issued = {}
                            for data in positions:
                                issued_details = data.get("issueDetails")

                                if issued_details:

                                    issued = issued_details.get("issuedPosition")
                                    if issued != 0:

                                        cfin = data.get("cfin")

                                        if cfin not in d_issued.keys():
                                            d_issued[cfin] = 0

                                        d_issued[cfin] += issued

                            df_issued = pd.DataFrame.from_dict(d_issued, orient="index")
                            df_issued = df_issued.reset_index()
                            df_issued.columns = ["Cfin", "Units Issued"]

                            df = df.merge(df_issued, on="Cfin", how="left")

                            # data = contrib_for_cfins(list(df["Cfin"]))

                            # df["Bid"] = df.apply(
                            #     lambda x: data.get(x["Cfin"]).get("bid") or x["Bid"]
                            #     if data.get(x["Cfin"])
                            #     else x["Bid"],
                            #     axis=1,
                            # )
                            # df["Ask"] = df.apply(
                            #     lambda x: data.get(x["Cfin"]).get("ask") or x["Ask"]
                            #     if data.get(x["Cfin"])
                            #     else x["Ask"],
                            #     axis=1,
                            # )
                            # df["Datetime"] = df.apply(
                            #     lambda x: data.get(x["Cfin"]).get("datetime")
                            #     if data.get(x["Cfin"])
                            #     and data.get(x["Cfin"]).get("ask") != 0
                            #     else x["Datetime"],
                            #     axis=1,
                            # )

                    except Exception as e:
                        print(e)

                elif parameter in ["minifutures", "minifut", "minifuts"]:
                    df = sql.execute_sql_query("minifut_positions", bind="exane_risque")

                    if not df.empty:
                        try:

                            # Replace column of UL close with live stock data
                            bids = {}

                            s = Snapshot()
                            cfins = [int(x) for x in list(df["UL Cfin"].dropna())]
                            data = s.data_for_cfins(cfins)

                            for x in data:

                                # if x["cfin"] in [311540]:
                                #     print(x)

                                if x["status"] != "UnknownCfin":

                                    bid = x["bidPrice"] or x["lastTradePrice"]
                                    timestamp = x["priceTimestamp"] or 0

                                    if x["instrumentStatus"] == "StatusOff":
                                        bid = x["closePrice"] or bid

                                    if x["type"] == "Index":
                                        bid = x["lastTradePrice"] or bid

                                    try:
                                        bids[x["cfin"]] = {
                                            "bid": bid,
                                            "timestamp": dt.fromtimestamp(
                                                timestamp / 1000
                                            ).strftime("%d/%m/%Y %H:%M:%S"),
                                        }
                                    except Exception as e:
                                        print(e)

                            df["UL Last Bid"] = df.apply(
                                lambda x: bids.get(x["UL Cfin"]).get("bid")
                                if bids.get(x["UL Cfin"])
                                else x["UL Last Bid"],
                                axis=1,
                            )
                            df["UL Last Bid Date"] = df.apply(
                                lambda x: bids.get(x["UL Cfin"]).get("timestamp")
                                if bids.get(x["UL Cfin"])
                                else x["UL Last Bid Date"],
                                axis=1,
                            )

                            # Replace column of product's close with live values
                            cfins = [
                                int(x)
                                for x in df["Cfin Contrib"].dropna().tolist()
                                + df["Cfin"].dropna().tolist()
                            ]
                            if len(cfins) < 200:
                                bids = sql.live_contrib_for_cfins(cfins)
                                df["Last Bid"] = df.apply(
                                    lambda x: bids.get(x["Cfin"]).get("bid")
                                    if bids.get(x["Cfin"])
                                    else bids.get(x["Cfin Contrib"]).get("bid")
                                    if bids.get(x["Cfin Contrib"])
                                    else x["Last Bid"],
                                    axis=1,
                                )
                                df["Last Bid Date"] = df.apply(
                                    lambda x: bids.get(x["Cfin"])
                                    .get("timestamp")
                                    .strftime("%d/%m/%Y %H:%M:%S")
                                    if bids.get(x["Cfin"])
                                    else bids.get(x["Cfin Contrib"])
                                    .get("timestamp")
                                    .strftime("%d/%m/%Y %H:%M:%S")
                                    if bids.get(x["Cfin Contrib"])
                                    else x["Last Bid Date"],
                                    axis=1,
                                )

                        except Exception as e:
                            msg = "API | Issue setting live data in Minifut Positions"
                            server.logger.exception(msg)

            elif code in ["opinions", "opinion"]:
                data = sql.last_updated_opinions(
                    for_mailing=False, start_date=start_date, end_date=end_date
                )
                df = pd.DataFrame.from_dict(data, orient="index")
                if isinstance(parameter, str):
                    opinion = parameter.lower().capitalize()
                    if opinion.capitalize() in [
                        "Outperform",
                        "Neutral",
                        "Underperform",
                    ]:
                        df = df[df["stock_opinion"] == opinion]
                sg = SGPricer()
                dff = sg.corresponding_tickers(df["ticker"].tolist())
                df = df[df["ticker"].isin(list(dff["ticker"]))]
                df.last_modif = df.last_modif.apply(lambda x: x.strftime("%d-%m-%Y"))
                df.last_modif = df.last_modif.astype(str)
                df.index.name = "cfin"
                df = df[
                    [
                        "last_modif",
                        "stock_opinion",
                        "ticker",
                        "name",
                        "country",
                        "sector",
                        "sector_opinion",
                        "ccy",
                        "last",
                        "upside",
                        "next_div_yield",
                        "IV_12M_100%",
                    ]
                ]
                if not df.empty:
                    result = df.reset_index().fillna("").to_dict("split")

            # Else code is a cfin
            else:
                cfins = code_to_cfin_or_cfins(code, parameter, multi)
                assert cfins is not None, "No Cfin Found"

                if not isinstance(cfins, list):
                    cfins = [cfins]

                # Check if the product has a contrib Cfin
                cfin_contrib = cfin_contrib_for_cfin(cfins)

                if parameter in ["close_hrix"]:
                    df = pd.DataFrame(
                        db.session.query(
                            Hrix.hixdate.label("Date"), Hrix.hixclose.label("Close"),
                        ).filter(
                            Hrix.hixcfin.in_(cfin_contrib),
                            Hrix.hixdate >= start_date,
                            Hrix.hixdate <= end_date,
                        )
                    )

                elif parameter in ["close", "px_last"]:
                    CodesTicker = aliased(Codes)
                    CodesIsin = aliased(Codes)

                    df = pd.DataFrame(
                        db.session.query(
                            Historiques.hocfin.label("Cfin"),
                            Instrument.ifnom.label("Name"),
                            CodesIsin.cfcode.label("Isin"),
                            CodesTicker.cfcode.label("Ticker"),
                            Historiques.hodate.label("Date"),
                            Historiques.hoclose.label("Close"),
                        )
                        .outerjoin(
                            (Instrument, Instrument.ifcfin == Historiques.hocfin),
                            (
                                CodesIsin,
                                and_(
                                    CodesIsin.cfcfin == Historiques.hocfin,
                                    CodesIsin.cfsource == 6,
                                ),
                            ),
                            (
                                CodesTicker,
                                and_(
                                    CodesTicker.cfcfin == Historiques.hocfin,
                                    CodesTicker.cfsource == 11,
                                ),
                            ),
                        )
                        .filter(
                            Historiques.hocfin.in_(cfin_contrib),
                            Historiques.hodate >= start_date,
                            Historiques.hodate <= end_date,
                        )
                    )

                    if len(cfins) == 1:
                        df = df[["Date", "Close"]]

                    else:

                        # In case ISIN or Ticker is missing
                        for col_name in ["Ticker", "Isin"]:
                            df[col_name] = df.apply(
                                lambda x: f"{x['Cfin']} (Missing {col_name})"
                                if pd.isna(x[col_name])
                                else x[col_name],
                                axis=1,
                            )

                        column = "Cfin"
                        if "column" in option:
                            column = option.split(";")[1][7:]
                        column = str(column).capitalize()
                        df = df.pivot_table(
                            index="Date", columns=[column], values="Close"
                        )
                        df.reset_index(inplace=True)

                elif parameter in ["close_brut", "close brut"]:
                    df = pd.DataFrame(
                        db.session.query(
                            Historiques.hodate.label("Date"),
                            Historiques.hoclosbrut.label("Close Brut"),
                        ).filter(
                            Historiques.hocfin.in_(cfins or cfin_contrib),
                            Historiques.hodate >= start_date,
                            Historiques.hodate <= end_date,
                        )
                    )

                elif parameter in ["open", "px_open"]:

                    df = pd.DataFrame(
                        db.session.query(
                            Historiques.hodate.label("Date"),
                            Historiques.hoopen.label("Open"),
                        )
                        .filter(
                            Historiques.hocfin.in_(cfin_contrib),
                            Historiques.hodate >= start_date,
                            Historiques.hodate <= end_date,
                        )
                        .all()
                    )

                elif parameter in ["bid", "px_bid"]:
                    df = pd.DataFrame(
                        db.session.query(
                            Historiques.hodate.label("Date"),
                            Historiques.hobid.label("Bid"),
                        )
                        .filter(
                            Historiques.hocfin.in_(cfin_contrib),
                            Historiques.hodate >= start_date,
                            Historiques.hodate <= end_date,
                        )
                        .all()
                    )

                elif parameter in ["ask", "px_ask"]:
                    df = pd.DataFrame(
                        db.session.query(
                            Historiques.hodate.label("Date"),
                            Historiques.hoask.label("Ask"),
                        )
                        .filter(
                            Historiques.hocfin.in_(cfin_contrib),
                            Historiques.hodate >= start_date,
                            Historiques.hodate <= end_date,
                        )
                        .all()
                    )

                elif parameter in ["upper"]:
                    df = pd.DataFrame(
                        db.session.query(
                            Historiques.hodate.label("Date"),
                            Historiques.houpper.label("Upper"),
                        )
                        .filter(
                            Historiques.hocfin.in_(cfin_contrib),
                            Historiques.hodate >= start_date,
                            Historiques.hodate <= end_date,
                        )
                        .all()
                    )

                elif parameter in [
                    "return_analysis",
                    "return analysis",
                    "performance_attribution",
                    "performance attribution",
                ]:
                    cfin = cfins[0]

                    if any(
                        x in option for x in ["debug", "error", "unexplained", "diff"]
                    ):
                        df = return_analysis(
                            cfin, start_date, end_date, return_errors=True
                        )
                    else:
                        df = return_analysis(
                            cfin, start_date, end_date, group_by=option
                        )

                elif parameter == "calendar":
                    cfin = cfins[0]

                    df = sql.execute_sql_query(
                        "calendar", "exane_risque", cfin_product=cfin,
                    )

                elif parameter in [
                    "compo",
                    "composition",
                ]:
                    cfin = cfins[0]

                    # Define start date as last calculation date if user does no precise the dates
                    if not args.get("start_date"):
                        r = (
                            db.session.query(Composition_h.cphdate)
                            .filter(Composition_h.cphcfin == cfin)
                            .order_by(Composition_h.cphdate.desc())
                        ).first()
                        if r:
                            start_date = end_date = r.cphdate

                    df = sql.execute_sql_query(
                        "compo",
                        index_cfin=cfin,
                        start_date=start_date.strftime("%d/%m/%Y"),
                        end_date=end_date.strftime("%d/%m/%Y"),
                    )

                    # Alert our team if the sum of Weights if different that 100%
                    if not df.empty:
                        sum_weights = df[["Date", "Weight"]].groupby("Date").sum()
                        if any(abs(x - 1.0) > 0.001 for x in sum_weights["Weight"]):
                            issue = {
                                "cfin": cfin,
                                "Sum weights": sum_weights,
                                "Machine": args.get("Machine"),
                                "UserName": args.get("UserName"),
                            }
                            MailNotification(
                                f"Error - Sum Weights {sum_weights:.2%} for {cfin}",
                                issue,
                            )

                elif parameter in [
                    "rebal_fees",
                    "rebal fees",
                    "rebalancing_fees",
                    "rebalancing fees",
                ]:

                    cfin = cfins[0]

                    filter = ""

                    # If user specifies a Cfin, filter on this specific value
                    if code != "flex":
                        filter = f"AND xdfcfinindex = {cfin}"

                    df = sql.execute_sql_query(
                        "rebal_fees",
                        bind="exane_derives",
                        filter=filter,
                        start_date=start_date.strftime("%d/%m/%Y"),
                        end_date=end_date.strftime("%d/%m/%Y"),
                    )

                    # Add books from RISQUE schema using the Delta if Book is missing
                    if not df[df.Book.isna()].empty:
                        cfins = list(set(df[df.Book.isna()].Cfin))
                        df_books = sql.books_for_cfins_flex(cfins)
                        if not df_books.empty:
                            df.Book = df.apply(
                                lambda x: df_books["Book"][x["Cfin"]]
                                if pd.isna(x["Book"])
                                else x["Book"],
                                axis=1,
                            )

                elif parameter in [
                    "compo_certif",
                    "compo certif",
                    "composition_certif",
                    "composition certif",
                ]:
                    values = sql.index_and_composition_full_for_cfin(cfins[0])
                    if values:
                        df = values["data"]

                elif parameter in [
                    "compo_full",
                    "composition_full",
                    "compo full",
                    "composition full",
                ]:

                    cfin = cfins[0]

                    # Define last calculation date
                    last_calculation_date = dt_today()
                    r = (
                        db.session.query(IdxauditUdl.iduvaluedate)
                        .filter(IdxauditUdl.iducfin == cfin)
                        .order_by(IdxauditUdl.iduvaluedate.desc())
                    ).first()
                    if r:
                        last_calculation_date = r.iduvaluedate.date()

                    if not args.get("start_date"):
                        start_date = end_date = last_calculation_date

                    # Return error message if date not available
                    if start_date > last_calculation_date:
                        error = "Error: Change your inputs"
                        msg = f'Min date: {last_calculation_date.strftime("%b %d, %Y")}'
                        df = pd.DataFrame(columns=[error], data=[msg])

                    else:
                        df = sql.execute_sql_query(
                            "compo_full",
                            index_cfin=cfin,
                            start_date=start_date.strftime("%d/%m/%Y"),
                            end_date=end_date.strftime("%d/%m/%Y"),
                        )

                        # Get Structured Products Coupons
                        cfins_ul = list(df.Cfin.unique())
                        df_cpns = structured_products_coupons(
                            cfins_ul, return_dataframe=True
                        )
                        if not df_cpns.empty:
                            df_cpns = df_cpns[
                                (df_cpns.category == "coupon")
                                & (df_cpns.settlement_date.dt.date >= start_date)
                                & (df_cpns.settlement_date.dt.date <= end_date)
                            ]
                            if not df_cpns.empty:
                                df_cpns = df_cpns[
                                    ["cfin", "settlement_date", "cpn_or_autocall"]
                                ]
                                df_cpns = df_cpns.rename(
                                    columns={
                                        "cfin": "Cfin",
                                        "settlement_date": "Date",
                                        "cpn_or_autocall": "Coupon SP",
                                    }
                                )
                                df.Date = pd.to_datetime(
                                    df.Date, format="%d/%m/%Y", errors="coerce"
                                )
                                df = df.merge(df_cpns, on=["Cfin", "Date"], how="left")

                            if "Coupon SP" not in df:
                                df["Coupon SP"] = np.NaN

                            cols = [x for x in df.columns if x != "Coupon SP"]
                            cols = cols[:-5] + ["Coupon SP"] + cols[-5:]
                            df = df[cols]

                            # Alert our team if the sum of Weights if different that 100%
                            if not df.empty:
                                sum_weights = (
                                    df[["Date", "Weight"]].groupby("Date").sum()
                                )
                                if any(
                                    abs(x - 1.0) > 0.001 for x in sum_weights["Weight"]
                                ):
                                    issue = {
                                        "cfin": cfin,
                                        "Sum weights": sum_weights,
                                        "Machine": args.get("Machine"),
                                        "UserName": args.get("UserName"),
                                    }
                                    MailNotification(
                                        f"Error - Sum Weights {sum_weights:.2%} for {cfin}",
                                        issue,
                                    )

                        # Filter on the columns if mentioned in the options
                        filters = option.split(";")
                        for filter in filters:
                            if "columns" in filter:
                                columns = filter[8:].split(", ")

                                # Strip elements to delete unwanted whitespaces
                                columns = [str(x).strip() for x in columns]

                                # Check if the columns are indeed in the df
                                d_current_cols = {str(x).lower(): x for x in df}
                                new_columns = [
                                    d_current_cols.get(x)
                                    for x in columns
                                    if d_current_cols.get(x)
                                ]
                                df = df[new_columns]

                elif parameter in ["attrib_sg", "attrib sg"]:
                    index_id = str(code).upper()

                    yt = YoutrackApi()
                    data = yt.get_contributions(
                        id=index_id,
                        start_date=start_date.strftime("%Y-%m-%d"),
                        end_date=end_date.strftime("%Y-%m-%d"),
                    )
                    d = {}
                    for company in data:
                        name = company["bloomberg"] or company["bbgLoc"]
                        d[name] = company["contribs"]

                    df = pd.DataFrame(d)
                    df.index.name = "Date"
                    df = df.reset_index()

                elif parameter in [
                    "operation",
                    "operations",
                ]:
                    df = sql.execute_sql_query(
                        query_name="operations",
                        bind="exane_derives",
                        index_cfin=cfins[0],
                        start_date=start_date.strftime("%d/%m/%Y"),
                        end_date=end_date.strftime("%d/%m/%Y"),
                    )

            if not df.empty:
                convert_dates = args.get("convert_dates") or "excel"
                for column in df.columns:
                    if column:
                        date_in_column = False

                        if isinstance(column, tuple):
                            date_in_column = any(
                                "date" in str(x).lower() for x in column
                            )

                        if isinstance(column, str):
                            date_in_column = "date" in str(column).lower()

                        if date_in_column:

                            df[column] = pd.to_datetime(
                                df[column], format="%Y-%m-%d", errors="coerce"
                            ).fillna(
                                pd.to_datetime(
                                    df[column], format="%d/%m/%Y", errors="coerce"
                                )
                            )
                            if convert_dates == "excel":
                                df[column] = df[column].apply(
                                    lambda x: xldate_from_datetime_tuple(
                                        (
                                            x.year,
                                            x.month,
                                            x.day,
                                            x.hour,
                                            x.minute,
                                            x.second,
                                        ),
                                        datemode=0,
                                    )
                                    if not pd.isnull(x) and x > dt(1903, 1, 3)
                                    else ""
                                )
                            else:
                                df[column] = df[column].apply(
                                    lambda x: x.strftime(convert_dates)
                                    if not pd.isnull(x)
                                    else ""
                                )

            result = df.fillna("").to_dict("split")

            msg += f" - Getting historical {parameter} for {code}"
            msg += f" - From: {start_date} to {end_date}"

        except AssertionError as e:
            msg += f" - No Cfin found for {code}"
            if parameter and code:
                msg += f" - Getting historical {parameter} for {code}"
            if start_date and end_date:
                msg += f" - From: {start_date} to {end_date}"
            server.logger.exception(e)

        except Exception as e:
            msg += " - issue using the API"
            if parameter and code:
                msg += f" - Getting historical {parameter} for {code}"
            if start_date and end_date:
                msg += f" - From: {start_date} to {end_date}"
            server.logger.exception(e)

        finally:
            server.logger.info(msg)
            return {"code": code, "value": result, "type": result_type}


last_logs = {}


@api.route("/api/eds")
class ExaneDataSet(Resource):
    def get(self):

        # Add arguments parser
        parser = reqparse.RequestParser()
        parser.add_argument("parameter", type=str, help="Looking for parameter")
        parser.add_argument("code", help="Code of the product")
        parser.add_argument("start_date", help="Code of the product")
        parser.add_argument("end_date", help="Code of the product")
        parser.add_argument("option", help="Optional parameter")
        parser.add_argument("UserName", location="headers")
        parser.add_argument("Machine", location="headers")
        args = parser.parse_args()

        # Set argument variables
        code = args.get("code") or "#N/A"
        code = code.lower()

        parameter = args.get("parameter")
        if parameter:
            parameter = parameter.lower()

        option = args.get("option")
        if option:
            option = option.lower()

        # Prepare log message with the details
        msg = f"Call EDS on {args.get('Machine')} by {args.get('UserName')}"

        result = "#N/A"
        result_type = ["string"]

        try:

            df = pd.DataFrame()

            if parameter in ["nominal"]:
                cfins = code.split(",")
                r = (
                    db.session.query(
                        Emission.emcfin.label("cfin"),
                        Emission.emnominal.label("nominal"),
                    )
                    .filter(Emission.emcfin.in_(cfins))
                    .all()
                )
                if r:
                    df = pd.DataFrame(r)

            elif code in ["pricing_sources", "pricing sources"]:
                engine = create_engine(Config.SQLALCHEMY_DATABASE_URI)
                df = pd.read_sql(PricingSources.query.statement, engine)
                df.drop(columns=["id"], inplace=True)

            elif code in ["issuer_rename", "issuer rename"]:
                engine = create_engine(Config.SQLALCHEMY_DATABASE_URI)
                df = pd.read_sql(IssuerRename.query.statement, engine)
                df.drop(columns=["id"], inplace=True)

            elif code in [
                "listed_position",
                "listed_positions",
                "listed positions",
                "listed position",
            ]:
                start_date = dt(2000, 1, 1).date()
                end_date = dt_today()

                filter_sales = ""
                filter_alive = "AND ifstatut NOT IN (7, 22)"
                filter_market = "AND prmarche in (184, 218, 919)"
                filter_back_to_back = ""
                filter_traded = ""

                df = sql.execute_sql_query(
                    "positions",
                    "exane_risque",
                    min_date=start_date,
                    max_date=end_date,
                    filter_sales=filter_sales,
                    filter_alive=filter_alive,
                    filter_market=filter_market,
                    filter_back_to_back=filter_back_to_back,
                    filter_traded=filter_traded,
                )

                try:
                    # data = contrib_for_cfins(list(df["Cfin"]))

                    df["Bid"] = df.apply(
                        lambda x: data.get(x["Cfin"]).get("bid") or x["Bid"]
                        if data.get(x["Cfin"])
                        else x["Bid"],
                        axis=1,
                    )
                    df["Ask"] = df.apply(
                        lambda x: data.get(x["Cfin"]).get("ask") or x["Ask"]
                        if data.get(x["Cfin"])
                        else x["Ask"],
                        axis=1,
                    )
                    df["Datetime"] = df.apply(
                        lambda x: data.get(x["Cfin"]).get("datetime")
                        if data.get(x["Cfin"]) and data.get(x["Cfin"]).get("ask") != 0
                        else x["Datetime"],
                        axis=1,
                    )

                except Exception as e:
                    print(e)

                if not df.empty:
                    result = df.fillna("").to_dict("split")

            if code in [
                "expiring_positions",
                "expiring positions",
            ]:
                df = sql.execute_sql_query("expiring_positions", "exane_risque")
                if not df.empty:
                    result = df.fillna("").to_dict("split")

            elif code in [
                "indices",
                "indice",
            ]:
                df = sql.execute_sql_query(
                    "indices", bind="exane_analyse_structuration"
                )
                df = df.drop(columns=["Hash"])

                if parameter in ["access", "acces", "acess"]:
                    df = df[(df["Category"] == "Exane Access Index")]
                    df = df.drop(columns=["Category"])

                elif parameter in [
                    "thematic",
                    "thematics",
                ]:
                    df = df[(df["Category"] == "Exane Thematic Index")]

                elif parameter in [
                    "flex",
                    "flexs",
                    "amc",
                    "amcs",
                ]:
                    df = df[(df["Category"] == "Exane Indices Flex")]
                    df = df.drop(columns=["Category"])

                # Check if user is asking for all results, even hidden indices
                # If "all" not in the option then display "Diffusable" indices only
                if option.lower() != "all" and parameter.lower() != "all":
                    df = df[df.Diffusion == "All"]
                    df = df.drop(columns=["Diffusion"])

            elif code in [
                "minifuts_position",
                "minifuts_positions",
                "minifuts position",
                "minifuts positions",
                "minifut_position",
                "minifut_positions",
                "minifut position",
                "minifut positions",
            ]:
                df = sql.execute_sql_query("minifut_positions", bind="exane_risque")

                if not df.empty:
                    try:

                        # Replace column of UL close with live stock data
                        bids = {}

                        s = Snapshot()
                        cfins = [int(x) for x in list(df["UL Cfin"].dropna())]
                        data = s.data_for_cfins(cfins)

                        for x in data:

                            # if x["cfin"] in [311540]:
                            #     print(x)

                            if x["status"] != "UnknownCfin":

                                bid = x["bidPrice"] or x["lastTradePrice"]
                                timestamp = x["priceTimestamp"] or 0

                                if x["instrumentStatus"] == "StatusOff":
                                    bid = x["closePrice"] or bid

                                if x["type"] == "Index":
                                    bid = x["lastTradePrice"] or bid

                                try:
                                    bids[x["cfin"]] = {
                                        "bid": bid,
                                        "timestamp": dt.fromtimestamp(
                                            timestamp / 1000
                                        ).strftime("%d/%m/%Y %H:%M:%S"),
                                    }
                                except Exception as e:
                                    print(e)

                        df["UL Last Bid"] = df.apply(
                            lambda x: bids.get(x["UL Cfin"]).get("bid")
                            if bids.get(x["UL Cfin"])
                            else x["UL Last Bid"],
                            axis=1,
                        )
                        df["UL Last Bid Date"] = df.apply(
                            lambda x: bids.get(x["UL Cfin"]).get("timestamp")
                            if bids.get(x["UL Cfin"])
                            else x["UL Last Bid Date"],
                            axis=1,
                        )

                        # Replace column of product's close with live values
                        cfins = [
                            int(x)
                            for x in df["Cfin Contrib"].dropna().tolist()
                            + df["Cfin"].dropna().tolist()
                        ]
                        bids = sql.live_contrib_for_cfins(cfins)
                        df["Last Bid"] = df.apply(
                            lambda x: bids.get(x["Cfin"]).get("bid")
                            if bids.get(x["Cfin"])
                            else bids.get(x["Cfin Contrib"]).get("bid")
                            if bids.get(x["Cfin Contrib"])
                            else x["Last Bid"],
                            axis=1,
                        )
                        df["Last Bid Date"] = df.apply(
                            lambda x: bids.get(x["Cfin"])
                            .get("timestamp")
                            .strftime("%d/%m/%Y %H:%M:%S")
                            if bids.get(x["Cfin"])
                            else bids.get(x["Cfin Contrib"])
                            .get("timestamp")
                            .strftime("%d/%m/%Y %H:%M:%S")
                            if bids.get(x["Cfin Contrib"])
                            else x["Last Bid Date"],
                            axis=1,
                        )

                    except Exception as e:
                        msg = "API | Issue setting live data in Minifut Positions"
                        server.logger.exception(msg)
                    result = df.fillna("").to_dict("split")

            elif code in ["size_delta_certif"]:
                df = get_certif_deltas()
                server.logger.info(df.info())
                df = pd.DataFrame.from_dict({"size_df": [df.size]})

            elif code in [
                "sg_underyings",
                "sg underyings",
                "sg_ul",
                "sg ul",
                "sg_stocks",
                "sg stocks",
                "sg_stock",
                "sg stock",
                "sg_universe",
                "sg universe",
            ]:
                data = cached_sg_underlying_universe()
                df = pd.DataFrame(data.get("EquityUnderlyings"))
                result = df.fillna("").to_dict("split")

            elif code in ["opinion", "opinions", "research", "bnpp"]:
                df = sql.execute_sql_query("opinions", "exane_analyse")
                if isinstance(parameter, str):
                    opinion = parameter.lower().capitalize()
                    if opinion in ["Outperform", "Neutral", "Underperform"]:
                        df = df[df["Opinion Stock"] == opinion]
                if not df.empty:
                    result = df.fillna("").to_dict("split")

            elif code in ["last_week_opinions", "last_week_opinion"]:
                data = sql.last_updated_opinions(for_mailing=False)
                df = pd.DataFrame.from_dict(data, orient="index")
                if isinstance(parameter, str) and parameter.lower() == "sg":
                    sg = SGPricer()
                    dff = sg.corresponding_tickers(df.ticker.tolist())
                    df = df[df.ticker.isin(list(dff.ticker))]
                df.last_modif = df.last_modif.apply(lambda x: x.strftime("%d-%m-%Y"))
                df.last_modif = df.last_modif.astype(str)
                df.index.name = "cfin"
                if not df.empty:
                    result = df.reset_index().fillna("").to_dict("split")

            # Code is a security
            else:
                # Code is an ISIN or a TICKER
                if parameter in ["cfins_from_code"]:
                    df = pd.DataFrame(
                        db.session.query(Codes.cfcfin.label("Cfin"))
                        .select_from(Codes)
                        .join(Instrument, Instrument.ifcfin == Codes.cfcfin)
                        .filter(
                            Codes.cfcode == code.upper(),
                            Instrument.ifstatut.notin_([7, 22]),
                        )
                        .order_by(Codes.cfcfin)
                        .all()
                    )

                # Code is a CFIN
                else:
                    cfin = code_to_cfin_or_cfins(code, parameter)
                    assert cfin is not None, "No Cfin Found"

                    if parameter in [
                        "compo_sg_full",
                        "compo sg full",
                    ]:

                        index_id = str(code).upper()
                        date = args.get("option") or dt_today()

                        # In case the string as an Excel date format like 44258
                        if isinstance(date, str):
                            if date.isnumeric():
                                if 50000 > int(date) > 10000:
                                    date = dt(*xldate_as_tuple(int(date), 0))
                                    date = date.date()

                            # In case the string as date format like "26/02/2021"
                            elif is_date(date):
                                date = parse(date, dayfirst=True)
                                date = date.date()

                        date = date.strftime("%Y-%m-%d")

                        yt = YoutrackApi()
                        df = yt.get_composition(id=index_id, date=date)

                        # Find AMC Issue Date
                        if index_id == "SGBCHAMC":
                            cfin = 47186496
                        elif index_id == "SGBEAST":
                            cfin = 47168962
                        else:
                            cfin = None

                        issue_date = None
                        r = Emission.query.filter_by(emcfin=cfin).first()
                        if r:
                            issue_date = r.empaiement

                        # Find Components Entry Date
                        reschuffles = yt.get_reshuffles(
                            id=index_id,
                            start_date=issue_date.strftime("%Y-%m-%d"),
                            end_date=date,
                        )
                        df["Entry Date"] = issue_date
                        if len(reschuffles) > 0:
                            dff = df
                            for reschuffle in reschuffles:
                                df_shuffle = yt.get_composition(
                                    id=index_id, date=reschuffle.get("exDate")
                                )
                                df_shuffle["Entry Date"] = reschuffle.get("exDate")
                                dff.append(
                                    df_shuffle, ignore_index=True,
                                )
                            dff = (
                                dff.groupby("ISIN")
                                .agg({"Entry Date": "min"})
                                .reset_index()
                            )
                            df = df.drop(columns=["Entry Date"])
                            df = pd.merge(df, dff, on="ISIN", how="left")

                        # Create Functions
                        def isin_to_cfin(isin, ccy):
                            if ccy == "CNH":
                                ccy = "CNY"
                            try:
                                r = (
                                    db.session.query(Codes.cfcfin)
                                    .join(
                                        (Produit, Produit.prcfin == Codes.cfcfin),
                                        (Devise, Devise.dvcfin == Produit.prdev),
                                        (
                                            Instrument,
                                            Instrument.ifcfin == Produit.prdev,
                                        ),
                                    )
                                    .filter(
                                        Codes.cfcode == isin,
                                        Devise.dvcodeiso == ccy,
                                        Instrument.ifstatut.notin_([7, 22]),
                                    )
                                    .first()
                                )
                                return r[0]
                            except Exception as e:
                                print(e)
                                return None

                        def get_price(cfin, date):
                            try:
                                return (
                                    db.session.query(Historiques.hoclose)
                                    .filter(
                                        Historiques.hocfin == cfin,
                                        Historiques.hodate <= date,
                                    )
                                    .order_by(Historiques.hodate.desc())
                                    .first()
                                    .hoclose
                                )
                            except:
                                return None

                        def compute_perf(new_price, old_price):
                            try:
                                return (new_price - old_price) / old_price
                            except:
                                return None

                        df["cfin"] = df.apply(
                            lambda x: isin_to_cfin(x["ISIN"], x["Ccy"]), axis=1
                        )
                        df["Close at Entry"] = df.apply(
                            lambda x: get_price(x["cfin"], x["Entry Date"]), axis=1
                        )
                        df["Perf since Entry"] = df.apply(
                            lambda x: compute_perf(
                                new_price=x["Spot"], old_price=x["Close at Entry"]
                            ),
                            axis=1,
                        )
                        df["1M_price"] = df["cfin"].apply(
                            lambda x: get_price(
                                x, pd.to_datetime(date) - timedelta(days=30)
                            )
                        )
                        df["Perf 1M"] = df.apply(
                            lambda x: compute_perf(
                                new_price=x["Spot"], old_price=x["1M_price"]
                            ),
                            axis=1,
                        )
                        df["YTD_price"] = df["cfin"].apply(
                            lambda x: get_price(x, dt(2021, 1, 1))
                        )
                        df["Perf YTD"] = df.apply(
                            lambda x: compute_perf(
                                new_price=x["Spot"], old_price=x["YTD_price"]
                            ),
                            axis=1,
                        )
                        df = df.drop(columns=["1M_price", "YTD_price"])

                    elif parameter == "alien":
                        df = pd.DataFrame(
                            db.session.query(
                                Alien.alcfin.label("Cfin"),
                                Alien.alsjac.label("Sjac"),
                                Alien.altype.label("Type"),
                            )
                            .select_from(Alien)
                            .filter(or_(Alien.alcfin == cfin, Alien.alsjac == cfin))
                            .all()
                        )

                    elif parameter == "alien_children":
                        df = pd.DataFrame(
                            db.session.query(
                                Alien.alcfin.label("Cfin"),
                                Alien.alsjac.label("Children"),
                                Alien.altype.label("Type"),
                            )
                            .select_from(Alien)
                            .filter(Alien.alcfin == cfin)
                            .all()
                        )

                    elif parameter == "alien_parent":
                        df = pd.DataFrame(
                            db.session.query(
                                Alien.alsjac.label("Cfin"),
                                Alien.alcfin.label("Parent"),
                                Alien.altype.label("Type"),
                            )
                            .select_from(Alien)
                            .filter(Alien.alsjac == cfin)
                            .all()
                        )

                    elif parameter in ["underlyings"]:
                        data = instrument_details(cfin)
                        if data:
                            df = autocall_underlyings_details(data.json["content"][0])

                    elif parameter in [
                        "sg_compo",
                        "sg compo",
                        "compo_sg",
                        "compo sg",
                        "compo_youtrack",
                        "compo youtrack",
                        "youtrack",
                    ]:

                        index_id = str(code).upper()
                        date = args.get("option") or dt_today()

                        # In case the string as an Excel date format like 44258
                        if isinstance(date, str):
                            if date.isnumeric():
                                if 50000 > int(date) > 10000:
                                    date = dt(*xldate_as_tuple(int(date), 0))
                                    date = date.date()

                            # In case the string as date format like "26/02/2021"
                            elif is_date(date):
                                date = parse(date, dayfirst=True)
                                date = date.date()

                        date = date.strftime("%Y-%m-%d")

                        yt = YoutrackApi()
                        df = yt.get_composition(id=index_id, date=date)

                    elif parameter in [
                        "search_in_compo",
                        "search in compo",
                        "product_in_compo",
                        "product in compo",
                    ]:
                        inst_sjac = aliased(Instrument)
                        inst_compo = aliased(Instrument)

                        df = pd.DataFrame(
                            db.session.query(
                                inst_sjac.ifcfin,
                                Codes.cfcode,
                                inst_sjac.ifnom,
                                Composition.cpcfin,
                                inst_compo.ifnom,
                            )
                            .select_from(inst_sjac)
                            .join(
                                (
                                    Codes,
                                    and_(
                                        Codes.cfcfin == inst_sjac.ifcfin,
                                        Codes.cfsource == 6,
                                    ),
                                ),
                                (Composition, Composition.cpsjac == inst_sjac.ifcfin),
                                (inst_compo, inst_compo.ifcfin == Composition.cpcfin),
                            )
                            .filter(inst_sjac.ifcfin == cfin,)
                            .all()
                        )

                    elif parameter in [
                        "find_epix_cfin_from_certificates",
                        "find_epix_cfin_from_certificate",
                        "find expic cfin from certificates",
                        "find epix cfin from certificate",
                    ]:

                        # Get Cfin Retro
                        r = Alien.query.filter(
                            or_(Alien.alcfin == cfin, Alien.alsjac == cfin),
                            Alien.altype == 51,
                        ).first()
                        if r:
                            if cfin == str(r.alcfin):
                                cfin_retro = r.alsjac
                            else:
                                cfin_retro = r.alcfin
                        else:
                            cfin_retro = cfin

                        # Get Epix Cfin
                        r = Alien.query.filter(
                            or_(Alien.alcfin == cfin, Alien.alsjac == cfin),
                            Alien.altype == 56,
                        ).first()
                        if r:
                            if cfin == str(r.alcfin):
                                cfin_epix = r.alsjac
                            else:
                                cfin_epix = r.alcfin
                        else:
                            cfin_epix = cfin_retro

                        data = [{"Cfin Epix": cfin_epix,}]
                        df = pd.DataFrame.from_records(data)

                    elif parameter in [
                        "find_certificates",
                        "find_certificate",
                        "find certificates",
                        "find certificate",
                    ]:

                        # Get ISIN Certificate
                        r = Alien.query.filter(
                            or_(Alien.alcfin == cfin, Alien.alsjac == cfin),
                            Alien.altype == 56,
                        ).first()
                        if r:
                            if cfin == str(r.alcfin):
                                cfin_certificate = r.alsjac
                            else:
                                cfin_certificate = r.alcfin
                        else:
                            cfin_certificate = cfin

                        # Get ISIN Certificate
                        isin_certificate = (
                            Codes.query.filter(
                                and_(
                                    Codes.cfcfin == cfin_certificate,
                                    Codes.cfsource == 6,
                                )
                            )
                            .first()
                            .cfcode
                        )

                        # Get Devise Certificate
                        currency_code_certificate = (
                            Produit.query.filter(Produit.prcfin == cfin_certificate,)
                            .first()
                            .prdev
                        )
                        currency = (
                            Devise.query.filter(
                                Devise.dvcfin == currency_code_certificate,
                            )
                            .first()
                            .dvcodeiso
                        )

                        # Get Name Certificate
                        name_certificate = (
                            Instrument.query.filter(
                                Instrument.ifcfin == cfin_certificate
                            )
                            .first()
                            .ifnom
                        )

                        # Get Pose Certificate
                        position = OpenPositions().position_for_cfin(cfin_certificate)

                        # Get Cfin Retro
                        r = Alien.query.filter(
                            or_(Alien.alcfin == cfin, Alien.alsjac == cfin_certificate),
                            Alien.altype == 51,
                        ).first()
                        if r:
                            if cfin == str(r.alcfin):
                                cfin_retro = r.alsjac
                            else:
                                cfin_retro = r.alcfin
                        else:
                            cfin_retro = cfin_certificate

                        # Get Name Retro
                        name_retro = (
                            Instrument.query.filter(Instrument.ifcfin == cfin_retro)
                            .first()
                            .ifnom
                        )

                        data = [
                            {
                                "Retro Cfin": cfin_retro,
                                "Retro Lib": name_retro,
                                "Certificate Cfin": cfin_certificate,
                                "Certificate ISIN": isin_certificate,
                                "Certificate Lib": name_certificate,
                                "Ccy": currency,
                                "Position": position,
                            }
                        ]
                        df = pd.DataFrame.from_records(data)

                    elif parameter in [
                        "search_in_portfolio",
                        "search in portfolio",
                        "search_in_portfolios",
                        "search in portfolios",
                    ]:

                        instru_index = aliased(Instrument)
                        instru_collection = aliased(Instrument)

                        df = pd.DataFrame(
                            db.session.query(
                                Instrument.ifcfin.label("Cfin"),
                                Codes.cfcode.label("ISIN"),
                                Instrument.ifnom.label("Name"),
                                Collection.clcollect.label("Cfin Collection"),
                                instru_index.ifnom.label("Name Collection"),
                                Pdtcompo.pccfin.label("Cfin Index"),
                                instru_collection.ifnom.label("Name Index"),
                                Collection.cldatein.label("Date In"),
                                Collection.cldateout.label("Date Out"),
                            )
                            .select_from(Instrument)
                            .join(
                                (Collection, Collection.clsjac == Instrument.ifcfin),
                                (Pdtcompo, Pdtcompo.pccollect == Collection.clcollect),
                                (
                                    Codes,
                                    and_(
                                        Codes.cfcfin == Instrument.ifcfin,
                                        Codes.cfsource == 6,
                                    ),
                                ),
                                (
                                    instru_index,
                                    instru_index.ifcfin == Collection.clcollect,
                                ),
                                (
                                    instru_collection,
                                    instru_collection.ifcfin == Pdtcompo.pccfin,
                                ),
                            )
                            .filter(Instrument.ifcfin == cfin,)
                            .all()
                        )

            if not df.empty:
                for column in df.columns:
                    if "date" in column.lower():
                        df[column] = pd.to_datetime(
                            df[column], format="%Y-%m-%d", errors="coerce"
                        ).fillna(
                            pd.to_datetime(
                                df[column], format="%d/%m/%Y", errors="coerce"
                            )
                        )
                        df[column] = df[column].apply(
                            lambda x: xldate_from_datetime_tuple(
                                (x.year, x.month, x.day, x.hour, x.minute, x.second),
                                datemode=0,
                            )
                            if not pd.isnull(x) and x > dt(1903, 1, 3)
                            else ""
                        )

                result = df.fillna("").to_dict("split")

            msg += f" - Getting {code} data"

        except AssertionError:
            msg += f" - No Cfin found for {code}"
            if code:
                msg += f" - Getting {code} data"

        except Exception as e:
            msg += " - issue using the API"
            if code:
                msg += f" - Getting {code} data"
            server.logger.exception(e)

        finally:
            # Check if same msg was already logged in the last 3s
            if msg in last_logs:
                last_time = max([last_logs[key] for key in last_logs])
                if last_time < dt.now() - datetime.timedelta(seconds=3):
                    key = [k for k, v in last_logs.items() if v == last_time]
                    last_logs[key[0]] = dt.now()
                    server.logger.info(msg)
            else:
                last_logs[msg] = dt.now()
                server.logger.info(msg)

            # Delete Older Log
            if len(last_logs) > 10:
                del last_logs[list(last_logs.keys())[0]]
            return {"code": code, "value": result, "type": result_type}


@api.route("/api/graph")
class ExaneGraph(Resource):
    def post(self):

        # Add arguments parser
        parser = reqparse.RequestParser()

        for argument in [
            "start_date",
            "end_date",
            "codes",
            "autocall_barrier",
            "protection_barrier",
            "coupon_barrier",
        ]:
            parser.add_argument(argument)

        parser.add_argument("UserName", location="headers")
        parser.add_argument("Machine", location="headers")

        args = parser.parse_args()

        codes = args.get("codes")
        start_date = args.get("start_date") or prev_bday(252 * 1)
        end_date = args.get("end_date") or dt_today()

        data_barriers = {
            "atk_value": None
            if not args.get("autocall_barrier")
            else float(args.get("autocall_barrier")),
            "cpn_value": None
            if not args.get("coupon_barrier")
            else float(args.get("coupon_barrier")),
            "prot_value": None
            if not args.get("protection_barrier")
            else float(args.get("protection_barrier")),
        }

        # Prepare log message with the details
        msg = f"Getting Graph on {args.get('Machine')} by {args.get('UserName')}"

        if codes:
            msg += f" - Codes {codes}"
        if start_date:
            msg += f" - Start Date {start_date}"
        if end_date:
            msg += f" - End Date {end_date}"

        try:
            assert codes is not None, "No Codes Found"

            codes = [str(x).strip() for x in codes.split(",")]

            data_colors = {x: None for x in codes}

            cfins = [str(code_to_cfin_or_cfins(code, "cfin")) for code in codes]

            g = graph_backtest(
                cfins=cfins,
                start_date=start_date,
                end_date=end_date,
                data_barriers=data_barriers,
                data_colors=data_colors,
                to_image=True,
                width=500,
                height=400,
                font_size=12,
            )

            server.logger.exception(msg)
            return send_file(io.BytesIO(g), mimetype="image/png")

        except Exception as e:
            server.logger.exception(e)
            msg += " - issue using the API"
            server.logger.exception(msg)

import pandas as pd
from collections import OrderedDict

from app import app, cache
from utils.basics import timeit, serialize_api_result
from utils.api_exane import Exane


class OpenPositions(Exane):
    WSDL = "http://simbadsvc:8080/po-srv/services/xml/po?wsdl"

    def _get_data(self, query, aggregation=False, zeep_serialization=False):

        # Control if the service is active
        if self.service:

            if aggregation:
                request = self.service.requestAggregation(query)
            else:
                request = self.service.requestDetails(query)

            data = request[0]

            if data.hasErrors:
                error = data.errorMessage
                msg = f"OpenPositions | Error: {error} - Query: {query}"
                app.logger.warning(msg)
                raise Exception(error)

            if data.results:
                # Change results to a list of dictionaries
                return serialize_api_result(data.results, zeep_serialization)

    def trades_for_cfin(self, cfin, max_date=None):

        from utils.basics import prev_bday

        max_date = max_date or prev_bday()
        max_date = max_date.strftime("%d/%m/%y")

        query = [
            {
                "cube": "false",
                "id": 1,
                "select": [
                    "VENDEURREPRENEUR",
                    "ETATDUVENDEUR",
                    "INSTITUTION",
                    "CONTACT",
                    "PO_ORDRE",
                    "PO_QUANTITE",
                    "NOMINAL",
                    "PO_PRIX",
                    "PO_MONTANT",
                    "PO_DATE_TRADE",
                ],
                "where": [
                    {"field": "CFIN", "operator": "EQUAL", "value": cfin},
                    {
                        "field": "PO_DATE_TRADE",
                        "operator": "INFEQUAL",
                        "value": max_date,
                    },
                ],
            }
        ]

        return self._get_data(query)

    def formatted_trades_for_cfin(self, cfin):

        d = OrderedDict(
            [
                ("poDateTrade", "Date"),
                ("vendeurRepreneur", "Sales"),
                ("etatDuVendeur", "Sales Status"),
                ("institution", "Client"),
                ("contact", "Contact"),
                ("poMontant", "Amount"),
                ("poOrdre", "Type"),
                ("poPrix", "Price"),
                ("poQuantite", "Quantity"),
            ]
        )

        data = self.trades_for_cfin(cfin)

        if data:

            df = pd.DataFrame(data)

            # Convert trade dates and set correct timezone
            df.poDateTrade = pd.to_datetime(df.poDateTrade, utc=True)
            df.poDateTrade = df.poDateTrade.dt.tz_convert("Europe/Paris")

            # Select only specific columns, rename & reorder
            df = df[df.columns & d.keys()]
            df.columns = [d.get(x, x) for x in df.columns]
            df = df[[x for x in list(d.values()) if x in df.columns]]

            # Sort results by Trade Date
            df = df.sort_values(by="Date", ascending=False)

            return df

        return pd.DataFrame()

    @timeit
    def details_for_cfins(self, cfins):
        query = [
            {
                "cube": "false",
                "id": 1,
                "select": [
                    "CFIN",
                    "ISIN",
                    "INSTRUMENTLIBELLE",
                    "DEVISE",
                    "ETATDEVIE",
                    "VENDEURREPRENEUR",
                    "VENDEURREPRENEURID",
                    "INSTITUTION",
                    "CONTACT",
                    "VENDEURINITIAL",
                    "PO_ORDRE",
                    "PO_QUANTITE",
                    "PO_PRIX",
                    "PO_MONTANT",
                ],
                "where": [
                    {
                        "field": "CFIN",
                        "operator": "IN",
                        "value": [", ".join([str(x) for x in cfins])],
                    }
                ],
            }
        ]

        return self._get_data(query)

    @timeit
    def clients_for_cfins(self, cfins):
        query = [
            {
                "cube": "false",
                "id": 1,
                "select": [
                    "CFIN",
                    "ISIN",
                    "PO_DATE_TRADE",
                    "INSTRUMENTLIBELLE",
                    "DEVISE",
                    "ETATDEVIE",
                    "VENDEURREPRENEUR",
                    "VENDEURREPRENEURID",
                    "INSTITUTION",
                    "CONTACT",
                    "VENDEURINITIAL",
                    "PO_ORDRE",
                    "PO_QUANTITE",
                    "PO_PRIX",
                    "PO_MONTANT",
                ],
                "where": [
                    {
                        "field": "CFIN",
                        "operator": "IN",
                        "value": [", ".join([str(x) for x in cfins])],
                    }
                ],
            }
        ]

        return self._get_data(query)

    @timeit
    def trades_for_sales(self, sales):
        query = [
            {
                "cube": "false",
                "id": 1,
                "select": [
                    "CFIN",
                    "ISIN",
                    "INSTRUMENTLIBELLE",
                    "ETATDEVIE",
                    "INSTITUTION",
                    "PO_ORDRE",
                    "PO_QUANTITE",
                    "PO_PRIX",
                    "PO_MONTANT",
                ],
                "where": [
                    {"field": "VENDEURREPRENEUR", "operator": "IN", "value": [sales]}
                ],
            }
        ]

        return self._get_data(query)

    @timeit
    @cache.memoize(timeout=3600)
    def trades_for_account(self, account):

        query = [
            {
                "cube": "false",
                "id": 1,
                "select": [
                    "CFIN",
                    "ISIN",
                    "INSTRUMENTLIBELLE",
                    "DEVISE",
                    "CODE_DEVISE",
                    "PRIXEMISSION",
                    "NOMINAL",
                    "VENDEURREPRENEUR",
                    "VENDEURREPRENEURID",
                    "INSTITUTION",
                    "CONTACT",
                    "CONTACTID",
                    "BID",
                    "ASK",
                    "SPOT",
                    "MODE_COTATION",
                    "MODE_COTATION_ID",
                    "MASK",
                    "MBID",
                    "MARGINSALEBIDINITIAL",
                    "AMORTIBIDSTARTDATE",
                    "AMORTIBIDENDDATE",
                    "FXRATE",
                    "NOMINAL_POSE_EUR",
                    "MONTANTCOUPON",
                    "FREQUENCECOUPON",
                    "RISKBIDEURO",
                    "DATEFIXINGINITIAL",
                    "DATE_EMISSION",
                    "DATEFIXINGFINAL",
                    "MATURITE",
                    "FLUXPERFONEWEEK",
                    # "POSETITRE",
                ],
                "where": [
                    {"field": "INSTITUTION", "operator": "EQUAL", "value": [account],},
                    {"field": "ETATDEVIE", "operator": "EQUAL", "value": ["Actif"]},
                    {"field": "ISIN", "operator": "ISNOTNULL"},
                ],
                "agg": [{"field": "POSETITRE", "function": "SUM"}],
                "having": [{"field": "POSETITRE", "operator": "DIFF", "value": ["0"]}],
                "order": [{"field": "CONTACT", "order": "ASC"}],
            }
        ]

        return self._get_data(query, aggregation=True, zeep_serialization=True)

    @timeit
    @cache.cached(timeout=0, key_prefix="all_accounts_and_contacts")
    def all_accounts_and_contacts(self):
        """Returns list of all Clients, Contacts and associated Sales"""
        query = {
            "cube": "false",
            "id": 1,
            "select": [
                "VENDEURREPRENEUR",
                "VENDEURREPRENEURID",
                "INSTITUTION",
                "CONTACT",
                "CONTACTID",
                # "POSETITRE",
            ],
            "where": [
                {"field": "ETATDEVIEID", "operator": "EQUAL", "value": ["1"]},
                {"field": "INSTITUTIONID", "operator": "DIFF", "value": ["0"]},
            ],
            "agg": [{"field": "POSETITRE", "function": "SUM"}],
            "having": [{"field": "POSETITRE", "operator": "DIFF", "value": ["0"]}],
            "order": [{"field": "CONTACT", "order": "ASC"}],
        }

        return self._get_data(query, aggregation=True)

    @timeit
    @cache.cached(timeout=0, key_prefix="all_accounts")
    def all_accounts(self):
        """Returns list of all Clients, Contacts and associated Sales"""
        query = {
            "cube": "false",
            "id": 1,
            "select": ["INSTITUTION", "INSTITUTIONID"],
            "where": [
                {"field": "ETATDEVIEID", "operator": "EQUAL", "value": ["1"]},
                {"field": "INSTITUTIONID", "operator": "DIFF", "value": ["0"]},
            ],
            "agg": [{"field": "POSETITRE", "function": "SUM"}],
            "having": [{"field": "POSETITRE", "operator": "DIFF", "value": ["0"]}],
            "order": [{"field": "INSTITUTION", "order": "ASC"}],
        }

        return self._get_data(query, aggregation=True)

    @timeit
    @cache.cached(timeout=0, key_prefix="all_clients")
    def all_clients(self):
        """Returns list of all Clients"""
        query = {
            "cube": "false",
            "id": 1,
            "select": ["INSTITUTION",],
            "where": [
                {"field": "ETATDEVIEID", "operator": "EQUAL", "value": ["1"]},
                {"field": "INSTITUTIONID", "operator": "DIFF", "value": ["0"]},
            ],
            "agg": [{"field": "POSETITRE", "function": "SUM"}],
            "having": [{"field": "POSETITRE", "operator": "DIFF", "value": ["0"]}],
            "order": [{"field": "INSTITUTION", "order": "ASC"}],
        }

        return self._get_data(query, aggregation=True)

    @timeit
    def risk_bid(self):
        """Returns the sum of euros at risk on existing positions

        Select all the products alive with a positive bid margin and return the sum of the product of
        the position in euros and the bid margin as percentages
        """

        query = {
            "cube": "false",
            "id": 1,
            "select": [
                "CFIN",
                "ISIN",
                "INSTRUMENTLIBELLE",
                "MBID",
                "NOMINAL",
                "MODE_COTATION",
                # "NOMINAL_POSE_EUR",
            ],
            "where": [
                {"field": "ETATDEVIEID", "operator": "EQUAL", "value": ["1"]},
                # {"field": "MBID", "operator": "DIFF", "value": ["0"]},
                {"field": "MBID", "operator": "ISNOTNULL"},
            ],
            "agg": [{"field": "NOMINAL_POSE_EUR", "function": "SUM"}],
            "having": [
                {"field": "NOMINAL_POSE_EUR", "operator": "SUP", "value": ["0"]}
            ],
        }

        data = self._get_data(query, aggregation=True)

        df = pd.DataFrame(data)

        df["ModifiedBid"] = df.apply(
            lambda x: x["MBid"] / x["nominal"]
            if x["modeCotation"] == "Devise"
            else x["MBid"] / 100,
            axis=1,
        )

        df["risk_bid"] = df.apply(
            lambda x: x["nominalPoseEur"] * x["ModifiedBid"], axis=1,
        )

        df = df.sort_values(by="risk_bid", ascending=False)

        return df.risk_bid.sum()

    def position_for_cfin(self, cfin):
        """Returns the position amount for a given cfin"""

        query = {
            "cube": "false",
            "id": 1,
            "select": ["CFIN", "NOMINAL"],
            "where": [{"field": "CFIN", "operator": "EQUAL", "value": [str(cfin)]},],
            "agg": [{"field": "POSETITRE", "function": "SUM"},],
        }

        data = self._get_data(query, aggregation=True)

        if data:
            return data[0].get("poseTitre", 0) * data[0].get("nominal", 0)

    def historical_position_for_cfin(self, cfin, max_date=None, client=None):
        """Returns the position amount for a given cfin before a specific date"""

        data = self.trades_for_cfin(cfin, max_date)

        if data:

            if client:
                data = [x for x in data if client in str(x["institution"]).lower()]

            nominal = data[0].get("nominal")
            units = sum(
                [
                    x["poQuantite"] if x["poOrdre"] == "Buy" else -x["poQuantite"]
                    for x in data
                ]
            )
            return nominal * units

    def positions_for_cfins(self, cfins, result_type="cash"):
        """Returns the position amount for given cfins"""

        query = {
            "cube": "false",
            "id": 1,
            "select": ["CFIN", "NOMINAL"],
            "where": [
                {"field": "CFIN", "operator": "IN", "value": [str(x) for x in cfins]}
            ],
            "agg": [{"field": "POSETITRE", "function": "SUM"},],
        }

        data = self._get_data(query, aggregation=True)

        if data:

            if result_type == "units":
                return {x["cfin"]: x.get("poseTitre", 0.0) for x in data}

            return {x["cfin"]: x["nominal"] * x["poseTitre"] for x in data}

    def clients_for_cfin(self, cfin):
        """Returns the clients and amounts for a given cfin"""

        query = {
            "cube": "false",
            "id": 1,
            "select": ["INSTITUTION", "NOMINAL"],
            "where": [{"field": "CFIN", "operator": "EQUAL", "value": [str(cfin)]}],
            "agg": [{"field": "POSETITRE", "function": "SUM"},],
        }

        data = self._get_data(query, aggregation=True)

        if data:
            result = [
                f"{x['institution']} ({x.get('poseTitre', 0.0):,.0f} units)"
                for x in data
            ]
            return ", ".join(result)

    def contacts_for_cfin(self, cfin):
        """Returns the clients and amounts for a given cfin"""

        query = {
            "cube": "false",
            "id": 1,
            "select": ["INSTITUTION", "CONTACT", "NOMINAL"],
            "where": [{"field": "CFIN", "operator": "EQUAL", "value": [str(cfin)]}],
            "agg": [{"field": "POSETITRE", "function": "SUM"},],
        }

        data = self._get_data(query, aggregation=True)

        if data:
            result = [
                f"{x['contact']} | {x['institution']} ({x.get('poseTitre', 0.0):,.0f} units)"
                for x in data
            ]
            return ", ".join(result)


if __name__ == "__main__":
    # Display more columns when printing a Pandas DataFrame
    pd.options.display.width = 800
    pd.set_option("max_rows", 35)
    pd.set_option("max_columns", 15)

    from app import server

    with server.app_context():
        pass
        op = OpenPositions()
        # df = op.all_accounts()
        # position = op.contacts_for_cfin(45096792)

        j = op.historical_position_for_cfin(36941260)

        # df_clients = op.clients_and_contacts()
        # df_test1 = op.client_trades_for_contact_and_company("IKO CAPITAL")
        # df_test2 = op.client_trades_for_contact_and_company(
        #     "JAR GENEVA SA", "RAPPOPORT Nicolas"
        # )
        # trades_sales = op.trades_for_sales("ARNEODO Adrien")

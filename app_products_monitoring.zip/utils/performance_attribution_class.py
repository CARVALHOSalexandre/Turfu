from app import server
from typing import Union
import pandas as pd
from datetime import datetime as dt, timedelta
import utils.sql as sql
from utils.basics import timeit
from utils.api_sg_youtrack import DataAmcSG


@timeit
class PerformanceAttribution:
    """
    This class aims at decomposing the performance of AMCs (i.e, indices) by each of their components:
    both in term of underlying and FX performances
    """

    def __init__(
        self,
        cfin_index: Union[str, int],
        start_date_init: dt.date,
        end_date_init: dt.date,
        group_by: str,
        return_unexplained: bool,
        id_sg_china: str,
    ):
        self.cfin = cfin_index
        self.start_date_init = start_date_init
        self.end_date_init = end_date_init
        self.group_by = group_by
        self.return_unexplained = return_unexplained
        self.id_sg_china = id_sg_china
        self.index_levels = pd.DataFrame()
        self.df_compo = pd.DataFrame()
        self.start_date = self._set_start_dates()
        self.end_date = self._set_end_dates()

    def get_index_levels(self) -> pd.DataFrame:
        if self.id_sg_china:
            data = DataAmcSG(
                self.id_sg_china, "USD", self.start_date_init, self.end_date_init
            )
            if self.index_levels.empty:
                self.index_levels = data.get_historical_prices(
                    self.id_sg_china, self.start_date_init, self.end_date_init
                )
                self.index_levels = self.index_levels.reset_index()
                self.index_levels = self.index_levels[
                    ["index", "Published Level"]
                ].rename(columns={"Published Level": "Close", "index": "Date"})
        else:
            if self.index_levels.empty:
                self.index_levels = sql.histo_prices(
                    self.cfin, self.start_date_init, self.end_date_init
                )
                self.index_levels.Date = pd.to_datetime(self.index_levels.Date)

        return self.index_levels

    def _set_start_dates(self) -> dt.date:
        """Set the start date to match last available value for the index"""
        index_levels = self.get_index_levels()
        return max(self.start_date_init, min(index_levels.Date))

    def _set_end_dates(self) -> dt.date:
        """Set the end date to match last available value for the index"""
        index_levels = self.get_index_levels()
        return min(self.end_date_init, max(index_levels.Date))

    def compute_index_perf(self) -> float:
        index_levels = self.get_index_levels()
        index_perf = (
            index_levels[index_levels.Date == self.end_date].Close.iloc[0]
            / index_levels[index_levels.Date == self.start_date].Close.iloc[0]
            - 1
        )
        return index_perf

    def get_data_composition(self) -> pd.DataFrame:
        """Create a Dataframe from SQL query 'compo_full' which is the raw data"""
        if self.id_sg_china:
            data = DataAmcSG(self.id_sg_china, "USD", self.start_date, self.end_date)
            self.df_compo = data.df_raw.rename(
                columns={
                    "Quantity": "Qp1",
                    "ISIN": "Cfin",
                    "Spot": "Close",
                    "Bloomberg": "Ticker",
                }
            )
            self.df_compo["Flows"] = 0
        else:
            if self.df_compo.empty:
                self.df_compo = sql.execute_sql_query(
                    "compo_full",
                    index_cfin=cfin,
                    start_date=self.start_date.strftime("%d/%m/%Y"),
                    end_date=self.end_date.strftime("%d/%m/%Y"),
                )
                # Change closes column names for consistency, considering audit as correct data
                self.df_compo = self.df_compo.rename(
                    columns={
                        "Close": "Close Histo.",
                        "Close Epix": "Close",  # "Close Unadjusted"
                        "Change": "Change Histo.",
                        "Change Epix": "Change",
                    },
                )
                self.df_compo.Date = pd.to_datetime(
                    self.df_compo.Date, format="%d/%m/%Y"
                )
                self.df_compo = self.df_compo.sort_values(by="Date")

                # Testing when using dirty prices : uncomment here, change "Close" above into
                # "Close Unadjusted" and drop Flows in computations
                # self.df_compo.insert(
                #     25,
                #     "Close",
                #     self.df_compo["Close Unadjusted"] - self.df_compo["Accrued Coupon"],
                # )
                # self.df_compo["Close"].fillna(
                #     self.df_compo["Close Unadjusted"], inplace=True
                # )

                self.df_compo["Flows"] = (
                    self.df_compo[["Net Div. in Cash", "Coupon"]].fillna(0).sum(axis=1)
                )

                # Fill missing historical closes with Issue Price if relevant
                if "Issue Price" in self.df_compo.columns:
                    if "Entry Date" in self.df_compo.columns:
                        self.df_compo["Issue Date"] = pd.to_datetime(
                            self.df_compo["Issue Date"]
                        )
                        self.df_compo["Close Histo."] = self.df_compo.apply(
                            lambda x: x["Issue Price"]
                            if pd.isna(x["Close Histo."])
                            and x["Date"] <= x["Issue Date"]
                            else x["Close Histo."],
                            axis=1,
                        )
                # /!\
                # Forward fill for empty closes when not done in the original database, it is Exane's procedure.
                # It happens when closes are not filled in the original DB by EPIX.
                # There is the exact same error for Change EPIX. However, this creates NA (or (Null) in SQL) also
                # for specific Close EPIX because of the division by a (Null) with the FX or Change conversion.
                # Hence, the forward fill method will create a (theoretically negligible: delta_t = 1 day) gap.
                # Indeed, the Close EPIX F-filled would consider both the change and the close of t-1
                # whereas we know the EPIX close in t.
                # How to address it ? Make the Forward Fill in SQL for Changes EPIX, not that trivial ...
                if "Close" in self.df_compo:
                    self.df_compo = self.df_compo.sort_values(["Cfin", "Date"])
                    self.df_compo.Close.fillna(method="ffill", inplace=True)
                    self.df_compo["Close Histo."].fillna(method="ffill", inplace=True)
                    self.df_compo["Change"].fillna(method="ffill", inplace=True)

        return self.df_compo

    def get_df_check(self):
        # go further
        """
        Compare data actually used (audit, used by Epix) and data from history by converting in %
        NB: audit is the table contains the real levels used for computations when history
        contains only historical data
        """

        df_compo_modified = self.get_data_composition()
        df_compo_modified["Nominal Amount"].fillna(
            100, inplace=True
        )  # only needed for computation
        df_compo_modified["Close"] = (
            df_compo_modified["Close"] / df_compo_modified["Nominal Amount"] * 100
        )
        df_compo_modified["Accrued Coupon"] = (
            df_compo_modified["Accrued Coupon"]
            / df_compo_modified["Nominal Amount"]
            * 100
        )
        df_compo_modified["Coupon"] = (
            df_compo_modified["Coupon"] / df_compo_modified["Nominal Amount"] * 100
        )
        df_compo_modified["Flows"] = (
            df_compo_modified["Flows"] / df_compo_modified["Nominal Amount"] * 100
        )
        df_compo_modified["Closes Differences"] = (
            df_compo_modified["Close"]
            - df_compo_modified["Accrued Coupon"]
            - df_compo_modified["Close Histo."]
        )
        df_compo_modified["Returns"] = df_compo_modified.groupby("Cfin")[
            "Close"
        ].pct_change()

        df_compo_modified["Closes Differences"].fillna(0, inplace=True)
        df_compo_modified["Changes Differences"] = (
            df_compo_modified["Change"] - df_compo_modified["Change Histo."]
        )

        df_check = df_compo_modified[
            [
                "Date",
                "Cfin",
                "Close",
                "Closes Differences",
                "Changes Differences",
                "Returns",
            ]
        ]
        results = df_check[abs(df_check["Closes Differences"]) > 0.001]
        # results = df_check[df_check["Returns"]>df_check["Returns"].mean()]

        return results.to_clipboard()

    def get_df_pivot(self) -> pd.DataFrame:
        df_compo = self.get_data_composition()
        _values = ["Weight", "Close", "Flows", "Change", "Qp1"]
        df_pivot = df_compo.pivot(index="Date", columns="Cfin", values=_values)
        df_pivot = df_pivot.loc[df_pivot.Close.dropna(how="all").index]
        return df_pivot

    def get_df_orders(self) -> pd.DataFrame:
        df_orders = sql.execute_sql_query(
            "amc_orders_and_fees",
            bind="exane_analyse_structuration",
            index_cfin=self.cfin,
            start_date=self.start_date.strftime("%d/%m/%Y"),
            end_date=self.end_date.strftime("%d/%m/%Y"),
        )

        df_orders = pd.DataFrame(df_orders)
        return df_orders

    def get_df_pivot_adjusted(self) -> pd.DataFrame:
        """Adapt closing prices with levels from "Order and Fees" if any"""

        df_orders = self.get_df_orders()
        df_pivot = self.get_df_pivot()

        if not df_orders.empty:
            df_orders.Change.fillna(1.0, inplace=True)
            df_orders.Date = pd.to_datetime(df_orders.Date, format="%d/%m/%Y")

            for d in df_orders.to_dict("records"):
                if d["Cfin"] in df_pivot.Close:
                    df_pivot.Close.loc[d["Date"], d["Cfin"]] = d["Close"]
                    df_pivot.Change.loc[d["Date"], d["Cfin"]] = d["Change"]

                if d["Cfin Contrib"] in df_pivot.Close:
                    df_pivot.Close.loc[d["Date"], d["Cfin Contrib"]] = d["Close"]
                    df_pivot.Change.loc[d["Date"], d["Cfin Contrib"]] = d["Change"]

                if d["Cfin IE"] in df_pivot.Close:
                    df_pivot.Close.loc[d["Date"], d["Cfin IE"]] = d["Close"]
                    df_pivot.Change.loc[d["Date"], d["Cfin IE"]] = d["Change"]

        df_pivot_adjusted = df_pivot

        return df_pivot_adjusted

    def get_rebalancing_dates(self) -> list:
        """Find rebalancing dates including the first and last date"""

        df_pivot_adjusted = self.get_df_pivot_adjusted()

        rebal_begin_dates = list(
            df_pivot_adjusted.Qp1.drop_duplicates(keep="first").index
        )
        rebal_end_dates = list(df_pivot_adjusted.Qp1.drop_duplicates(keep="last").index)

        dates = []

        if rebal_begin_dates == rebal_end_dates:
            # Considering a subset of two consecutive dates, i.e when the portfolio is rebalanced everyday
            for k, date in enumerate(rebal_end_dates[:-1]):
                dates.append((date, rebal_end_dates[k + 1]))
        else:
            for begin, end in zip(rebal_begin_dates, rebal_end_dates):
                if dates:
                    # Append previous one day rebalancing period
                    period = (dates[-1][1], begin)
                    dates.append(period)
                if begin != end:
                    dates.append((begin, end))

        return dates

    # def get_rebalancing_dates(self):
    # To continue
    #     """Find rebalancing dates including the first and last date"""
    #     rebalancing_dates = sql.execute_sql_query(
    #         "rebal_dates_orders_and_fees",
    #         bind="exane_analyse_structuration",
    #         index_cfin=self.cfin,
    #     )
    #     rebalancing_dates["Rebalancing Dates"] = pd.to_datetime(
    #         rebalancing_dates["Rebalancing Dates"]
    #     )
    #
    #     df_pivot_adjusted = self.get_df_pivot_adjusted()
    #
    #     dates_initial = list(df_pivot_adjusted.Qp1.drop_duplicates(keep="first").index)
    #
    #     mask = (rebalancing_dates["Rebalancing Dates"] > self.start_date) & (
    #         rebalancing_dates["Rebalancing Dates"] <= self.end_date
    #     )
    #     rebalancing_dates = rebalancing_dates.loc[mask].drop_duplicates()
    #
    #     rebalancing_dates = rebalancing_dates["Rebalancing Dates"].to_list()
    #     # dates["Rebalancing Dates"].loc[mask].drop_duplicates().to_list
    #     # dates = dates[self.start_date <= dates["Rebalancing Dates"] <= self.end_date]
    #
    #     return rebalancing_dates

    def initiate_df_results(self) -> pd.DataFrame:
        df_compo = self.get_data_composition()

        columns = [
            "Entry Date",
            "Cfin",
            "Name",
            "Isin",
            "Ticker",
            "Type",
            "Sector",
            "Country",
            "Ccy",
        ]
        columns = [x for x in columns if x in df_compo.columns]

        df_results = df_compo[columns].drop_duplicates(subset=["Cfin"], keep="last")
        df_results.set_index("Cfin", inplace=True)

        # Fill with Other or N/A the "group_by" columns
        if "Type" in df_compo.columns:
            df_results.Type.fillna("Other", inplace=True)
        if "Sector" in df_compo.columns:
            df_results.Sector.fillna("N/A", inplace=True)
        if "Country" in df_compo.columns:
            df_results.Country.fillna("N/A", inplace=True)

        # Initiate columns of the attribution results
        df_results["FX Attr."] = 1.0
        df_results["UL Attr."] = 1.0

        return df_results

    def compute_df_results(self) -> pd.DataFrame:
        """
        Compute performances' decomposition and return three different Dataframes:
        1. df_results: line by line decomposition of the index's performance
        2. df_unexplained: unexplained performances
        3. df_results_grouped : a group by DataFrame, i.e: Sector, Country, etc.
        """

        dates = self.get_rebalancing_dates()
        df_pivot_adjusted = self.get_df_pivot_adjusted()
        df_results = self.initiate_df_results()
        index_levels = self.get_index_levels()
        index_perf = self.compute_index_perf()

        # Start Version 2

        udl_returns = df_pivot_adjusted.Close.pct_change()

        # Compute flows contribution to return
        flows_contribution_to_returns = (
            df_pivot_adjusted.Flows
            * df_pivot_adjusted.Change.shift(1)
            / df_pivot_adjusted.Change
        ) / df_pivot_adjusted.Close

        # Compute underlying contribution to return

        udl_attrib_by_cfin = df_pivot_adjusted.Weight.shift(1) * (
            udl_returns + flows_contribution_to_returns
        )
        udl_attrib_by_cfin = 1 + udl_attrib_by_cfin.iloc[1:, :]
        udl_attrib_by_cfin = udl_attrib_by_cfin.prod() - 1

        udl_attrib_perf = udl_attrib_by_cfin.sum()

        udl_attrib_by_date = df_pivot_adjusted.Weight.shift(1) * (
            udl_returns + flows_contribution_to_returns
        )
        udl_date = udl_attrib_by_date
        udl_attrib_by_date = udl_attrib_by_date.T.sum()

        # Compute Fx contribution to return
        fx_attrib_by_cfin = (
            df_pivot_adjusted.Weight.shift(1)
            * (df_pivot_adjusted.Close.shift(1) / df_pivot_adjusted.Close)
            * df_pivot_adjusted.Change.pct_change()
        )
        fx_attrib_by_cfin = 1 + fx_attrib_by_cfin.iloc[1:, :]
        fx_attrib_by_cfin = fx_attrib_by_cfin.prod() - 1

        fx_attrib_perf = fx_attrib_by_cfin.sum()

        fx_attrib_by_date = (
            df_pivot_adjusted.Weight.shift(1) * df_pivot_adjusted.Change.pct_change()
        )
        fx_date = fx_attrib_by_date
        fx_attrib_by_date = fx_attrib_by_date.T.sum()

        matrice_date = udl_date + fx_date

        index_levels.set_index("Date", inplace=True)
        index_returns = index_levels.Close.pct_change()
        index_performance = 1 + index_returns[1:]
        index_performance = index_performance.prod() - 1

        unexplained_theo = index_returns - udl_attrib_by_date - fx_attrib_by_date

        diff_global = index_performance - udl_attrib_perf - fx_attrib_perf

        df_results["FX Attr."] = fx_attrib_by_cfin
        df_results["UL Attr."] = udl_attrib_by_cfin

        df_unexplained = pd.DataFrame(unexplained_theo)
        if self.return_unexplained:
            return df_unexplained

        # End Version 2

        # Start Version 1

        # unexplained = []
        #
        # for date, next_date in dates:
        #
        #     # Slicing original DataFrame between rebalancing dates
        #     df = df_pivot_adjusted[
        #         (df_pivot_adjusted.index >= date)
        #         & (df_pivot_adjusted.index <= next_date)
        #     ]
        #
        #     ul_results = df.Weight.iloc[0] * (
        #         (
        #             df.Close.iloc[-1]
        #             - df.Close.iloc[0]
        #             + df.Flows.sum() * df.Change.iloc[-1] / df.Change.iloc[0]
        #         )
        #         / df.Close.iloc[0]
        #     )
        #     if any(x > 10 for x in ul_results):
        #         msg = (
        #             f"Some performances are too high: {ul_results[ul_results > 10]}, could be an error from "
        #             f"Exane's Database"
        #         )
        #         raise ValueError(msg)
        #
        #     ul_attribution = ul_results.sum()
        #
        #     fx_results = (
        #         df.Weight.iloc[0]
        #         * (df.Close.iloc[-1] / df.Close.iloc[0])
        #         * (df.Change.iloc[-1] / df.Change.iloc[0] - 1)
        #     )
        #     fx_attribution = fx_results.sum()
        #
        #     index_perf_period = (
        #         index_levels[index_levels.Date == next_date].Close.iloc[0]
        #         / index_levels[index_levels.Date == date].Close.iloc[0]
        #         - 1
        #     )
        #
        #     # Difference between theoretical performance and decomposed computed performance
        #     diff = index_perf_period - fx_attribution - ul_attribution
        #     unexplained.append(
        #         {
        #             "start": date.date(),
        #             "end": next_date.date(),
        #             "diff": diff,
        #             "index": index_perf_period,
        #             "fx": fx_attribution,
        #             "ul": ul_attribution,
        #         }
        #     )
        #
        #     if abs(diff) > 0.001:
        #         print(
        #             f"Difference of {diff:.3%} is coming from the following period: {date} - {next_date}"
        #         )
        #
        #     df_results["FX Attr."] *= 1 + fx_results.fillna(0.0)
        #     df_results["UL Attr."] *= 1 + ul_results.fillna(0.0)
        #
        # df_results["FX Attr."] -= 1.0
        # df_results["UL Attr."] -= 1.0
        #
        # df_unexplained = pd.DataFrame(unexplained)
        # if self.return_unexplained:
        #     df_unexplained.rename(
        #         {"start": "Start Date", "end": "End Date"}, axis=1, inplace=True
        #     )
        #     return df_unexplained

        # end Version 1

        df_results["Perf."] = df_results[["FX Attr.", "UL Attr."]].sum(axis=1)
        df_results = df_results.sort_values(by="Perf.", ascending=False)
        df_results.reset_index(inplace=True)

        # drop cash when present, maybe need to add some cfin for other currency
        list_cash = [
            23200284,
            23200290,
            484646,
            588454,  # dollar
            634394,  # euro
            23200285,  # gbp
            779245,
            23200286,
            23200287,
            23200283,
        ]
        df_results.drop(df_results[df_results.Cfin.isin(list_cash)].index, inplace=True)

        index_details = sql.cfin_details(cfin)
        df_index = pd.DataFrame.from_dict(index_details, orient="index")
        df_index = df_index.dropna().T.drop(columns=["type", "class"])
        df_index.columns = [x.capitalize() for x in df_index.columns]
        df_index[
            "UL Attr."
        ] = udl_attrib_perf  # df_results["UL Attr."].sum() # to modify in fct of Version
        df_index[
            "FX Attr."
        ] = fx_attrib_perf  # df_results["FX Attr."].sum() # to modify in fct of Version
        df_index["Perf."] = index_perf

        if self.group_by:

            columns = ["FX Attr.", "UL Attr.", "Perf."]
            group_by = self.group_by.capitalize()
            dfff = df_results.groupby(group_by)[columns].sum()
            dfff.reset_index(inplace=True)
            dfff = dfff[dfff["Perf."] != 0]
            dfff = dfff.sort_values(by="Perf.", ascending=False)
            df_index = df_index.rename({"Name": group_by}, axis=1)
            df_index = df_index[[group_by] + columns]
            df_final_grouped = pd.concat([df_index, dfff])
            return df_final_grouped

        else:
            # Displaying convenient DataFrame
            df_final = pd.concat([df_index, df_results])
            columns = [
                "Cfin",
                "Name",
                "Ticker",
                "Isin",
                "Ccy",
                "Entry Date",
                "Type",
                "Sector",
                "Country",
                "Change at Entry",
                "Change",
                "Close at Entry",
                "Close Date",
                "Perf since Entry",
                "Perf 1 Month",
                "Perf YTD",
                "FX Attr.",
                "UL Attr.",
                "Perf.",
            ]
            columns = [x for x in columns if x in df_final.columns]
            df_final = df_final[columns]

        return df_final


if __name__ == "__main__":
    with server.app_context():

        cfin = 39217985
        start_date = dt(2018, 8, 31)
        end_date = dt(2021, 12, 8)

        perf_attr = PerformanceAttribution(
            cfin,
            start_date,
            end_date,
            group_by="",
            return_unexplained=False,
            id_sg_china="",
        )

        df_perf_attr = perf_attr.compute_df_results()
        print(df_perf_attr)

        # Special AMC China  --> Works fine !!!
        # id_sg_china="SGBCHAMC"
        # cfin = 47012175

        # cfin = 39217985  # WOFI USD
        # cfin = 36908977  # Antler sur dt(2021, 6, 30) dt(2019, 12, 16) regarder les options
        # cfin = 46748830  # Bordier Green Climate Bond, type action alors que bond... problème avec le 39295917:Brookfield Finance 4.625% $ 20/80
        # cfin = 44130188  # Bordier Sustainable Hybrid
        # cfin = 37183962  # Global Gate --> full structured product
        # cfin = 47012175  # US Infrastructure New Cycle Dynamic
        # cfin = 39295917 # Athenee Mercury --> OST 29/09 split regroupement sur dassault et aston martin le 14/12/2020
        # cfin = 39643027 # BES Credit Opportunities

        # Problem to solve:
        # cfin = 37183962, 39295917
        # start_date = dt(2021, 1, 1)
        # end_date = dt(2021, 10, 5)
        # both problem with dates for this one, certainly duplicates in Index
        # Problem with certain stock and certain structured products

        # 42756447
        # Sogelac
        # Equity
        # USD
        # Delta: 14500 au 20 / 10 / 2020
        # Fees: derives.idxfraisponctuels
        # Pas encore de lien de méthodo
        # --> Problem with mini futures

        # To do, investigate on the two previous commented block

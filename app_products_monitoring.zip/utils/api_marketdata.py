import os
import requests as rq
import urllib.parse as urlparse
from urllib.parse import urlencode


class MarketData(rq.Session):
    BASE_URL = "http://api.marketstack.com/v1/"
    ACCESS_KEY = "6ea201b808a3bd3653cd75d331570c24"

    def __init__(self):
        super(MarketData, self).__init__()
        # Set proxies
        try:
            self.proxies = self._set_proxies()
        except:
            pass

    @staticmethod
    def _set_proxies():
        user = os.environ["USERNAME"]
        password = "Exane123456789"

        # set proxies
        proxy_dict = {
            "http": f"http://{user}:{password}@proxy.ad.exane.com:8080",
            "https": f"https://{user}:{password}@proxy.ad.exane.com:8080",
        }

        return proxy_dict

    def eod(self, symbols):
        params = {"access_key": self.ACCESS_KEY, "symbols": symbols}
        url = self.BASE_URL + "eod"
        r = self.get(url, params=params)
        r.raise_for_status()
        if r:
            return r.json()


if __name__ == "__main__":
    symbols = "AAPL"
    r = MarketData().eod(symbols)

from app import server


def send_notif(
    header,
    children,
    icon="info",
    duration=10000,
    dismissable=True,
    fade=False,
    showed=False,
    is_open=True,
    broadcast=True,
    dpt_id="ALL",
):
    notif = {
        "dpt_id": dpt_id,
        "header": header,
        "children": children,
        "icon": icon,
        "duration": duration,
        "dismissable": dismissable,
        "fade": fade,
        "showed": showed,
        "is_open": is_open,
    }
    msg = f"{header} - {children} - {dpt_id}"
    if broadcast:
        socket_pool.broadcast(str(notif))
        server.logger.info(f"Broadcasting: {msg}")
    else:
        socket_pool.send(str(notif))
        server.logger.info(f"Sending: {msg}")


if __name__ == "__main__":
    with server.app_context():
        send_notif(
            header="Test",
            children="This is a test notification",
        )

from utils.sql import *

import numpy as np
import pandas as pd
import requests as rq
from flask import jsonify
from dateutil import parser
from urllib.parse import urlencode
from datetime import datetime as dt

from app import server, app
import utils.sql as sql
from utils.basics import dt_today

structured_products_templates = [
    "CRESCENDO_TEMPLATE",
    "BACKED_TEMPLATE",
    "EXTERNAL_TEMPLATE",
    "SWEET_REVERSE_TEMPLATE",
    "CRESCENDO_SWAP_TEMPLATE",
]

coupon_freq = {
    1: "Monthly",
    2: "Bimonthly",
    3: "Quarterly",
    4: "Triannual",
    6: "Semiannual",
    12: "Annual",
    None: None,
}


def instrument_details(cfin):
    """Swagger: http://pott:8002/swagger-ui/"""

    if not isinstance(cfin, dict):
        cfin = {"cfin": cfin}

    if cfin.get("status", 200) != 200:
        return jsonify(error_message=cfin.get("error_message"), status=400)

    base_url = "http://pott:8002/osiris/getInstrumentTemplate"
    try:
        r = rq.post(
            base_url + f"?cfins={cfin.get('cfin')}",
            headers={"Content-type": "application/json"},
        )
    except Exception as e:
        return jsonify(error_message=str(e), status=504)

    if r.status_code == 200:
        if not r.json():
            # Try to get the data on the "Autre alien"
            cfin_rebooking = sql.alien(cfin["cfin"]).get(21)
            if cfin_rebooking:
                return instrument_details({"cfin": cfin_rebooking[0], "status": 200})
            return jsonify(error_message="No content", status=400)

        return jsonify(content=r.json(), status=200)

    else:
        res = r.json()
        return jsonify(error_message=res["error"], status=res["status"])


def instruments_details(cfins):
    params = [("cfins", str(x)) for x in cfins]

    base_url = "http://pott:8002/osiris/getInstrumentTemplate"
    try:
        r = rq.post(
            base_url + "?" + urlencode(params),
            headers={"Content-type": "application/json"},
        )
    except:
        return

    if r.status_code == 200:
        return r.json()


def display_calendar(data):
    df = pd.DataFrame(data["fixingDates"])

    filtered_cols = [
        "fixingDate",
        "exDate",
        "paymentDate",
        "earlyRedemptionBarrier",
        "callable",
        "redemptionAmount",
    ]

    df = df[[x for x in filtered_cols if x in df.columns]]

    # Add Autocall Barrier if is constant
    if not data["earlyRedemptionBarrierNonConstant"]:
        df["earlyRedemptionBarrier"] = data.get("earlyRedemptionBarrier")

    # Formating of %
    str_percent = lambda x: f"{x:,.3%}".replace("0%", "%") if x else x

    # Set Autocall to - if not applicable
    def callable(x):
        if not x["callable"]:
            return "-"
        return str_percent(x["earlyRedemptionBarrier"])

    df.earlyRedemptionBarrier = df.apply(callable, axis=1)

    # Add Redemption Amount if is constant
    if not data["redemptionAmountNonConstant"]:
        df["redemptionAmount"] = data["redemptionAmount"]

    df.redemptionAmount = df.redemptionAmount.apply(lambda x: str_percent(x))

    # Convert Fixing and Payment Dates to datetime
    df.fixingDate = pd.to_datetime(df.fixingDate)
    payment_rule = data["fixingScheduleParameters"].get("paymentRule", 5)

    if "exDate" not in df:
        df["exDate"] = df.fixingDate + BDay(payment_rule)
    df.exDate = pd.to_datetime(df.exDate)

    if "paymentDate" not in df:
        df["paymentDate"] = df.fixingDate + BDay(payment_rule)
    df.paymentDate = pd.to_datetime(df.paymentDate)

    # Coupon always constant
    df.loc[:, "coupon"] = data["coupon"]

    # Amount Paid or not with Formatting
    df_cube = cube_calendar(data["instrumentId"])
    if df_cube.empty:
        df.loc[:, "paid"] = 0.0
    else:
        diff_size = df.index.size - df_cube.index.size
        df = df.drop(range(0, diff_size))
        df = df.reset_index(drop=True)
        df.fixingDate = df_cube.fixing_date
        df.paymentDate = df_cube.payment_date
        if "paid" in df_cube.columns:
            df.loc[:, "paid"] = df_cube.paid
        if "autocall_proba" in df_cube.columns:
            df.loc[:, "proba"] = df_cube.autocall_proba

    today = pd.to_datetime(dt_today())
    today = today.tz_localize("Europe/Paris")

    # Adjust coupon level if script has a different amount
    df.coupon = df.apply(
        lambda x: x["paid"] / 100
        if (x["paid"] not in [x["coupon"], 0.0, "-"])
        else x["coupon"],
        axis=1,
    )

    # Format column Coupon and set to - if not relevant
    df.coupon = df.coupon.apply(lambda x: str_percent(x))
    if "proba" in df.columns:
        df.proba = df.proba.apply(
            lambda x: "-" if (not x or pd.isna(x)) else f"{x:.0%}"
        )

    # Format column Paid and set to - if not relevant
    format_paid = (
        lambda x: "{:,.3f}%".format(x["paid"]).replace("0%", "%")
        if x["fixingDate"] < today
        else "-"
    )
    df.paid = df.apply(format_paid, axis=1)

    # Convert Fixing and Payment Dates to strings
    df.fixingDate = df.fixingDate.apply(lambda x: x.strftime("%b %d, %Y"))
    df.exDate = df.exDate.apply(
        lambda x: x.strftime("%b %d, %Y") if not pd.isna(x) else np.NaN
    )
    df.paymentDate = df.paymentDate.apply(
        lambda x: x.strftime("%b %d, %Y") if not pd.isna(x) else np.NaN
    )

    col_names = {
        "fixingDate": "Fixing",
        "exDate": "Ex",
        "paymentDate": "Payment",
        "coupon": "Coupon",
        "paid": "Paid",
        "earlyRedemptionBarrier": "Autocall",
        "proba": "Proba",
        "redemptionAmount": "Redemption",
    }

    # Select relevant columns
    df = df[[x for x in col_names if x in df.columns]]

    # Rename columns
    df.columns = [col_names[x] for x in df.columns]

    # Drop Redemption column if constant and 1
    if not data["redemptionAmountNonConstant"] and data["redemptionAmount"] == 1:
        df = df.drop(columns=["Redemption"])

    return df


def display_rolls(data):
    if not data.get("futures") or not len(data.get("futures")) > 0:
        return pd.DataFrame()

    df = pd.DataFrame(data["futures"])

    if df.roll.any() == False:
        return pd.DataFrame()

    df = df[
        ["noDriftCfin", "name", "maturityDate", "adjustedBarrier", "adjustedStrike",]
    ]

    # Replace Nan values to initial values
    df["adjustedBarrier"][0] = data["protectionBarrier"]
    df["adjustedStrike"][0] = data["strike"]

    df.maturityDate = pd.to_datetime(df.maturityDate, utc=True)
    df.maturityDate = df.maturityDate.dt.strftime("%b %d, %Y")

    # Rename columns
    df.columns = ["Cfin", "Name", "Maturity", "Stop Loss", "Strike"]

    return df


def display_minifut_details(data):
    df = display_minifut_underlyings_details(data)

    return {
        "initial_leverage": data.get("underlyings", {})[0].get("initRefValue")
        / abs(
            data.get("underlyings", {})[0].get("initRefValue") - df["strike"].iloc[0]
        ),
        "current_leverage": df["last"].iloc[0]
        / abs(df["last"].iloc[0] - df["strike"].iloc[0])
        if df["last"].iloc[0] is not None
        else None,
    }


def display_minifut_underlyings_details(data):
    underlyings = {x["technicalCfin"]: x["initRefValue"] for x in data["underlyings"]}

    df = underlyings_details(underlyings)

    # Add Spot Initial and perf
    spotInitial = lambda x: round(underlyings[x.cfin], 2)
    df["spot"] = df.apply(spotInitial, axis=1)
    df["perf"] = df["last"] / df["spot"] - 1

    # Distance to Barriers
    dist = lambda x, y: df["last"] / x - 1 if y == "BULL" else x / df["last"] - 1

    # Get rolls information
    if data.get("futures") and len(data.get("futures")) > 1:
        f = data.get("futures")[-1]
        df["strike"] = f.get("adjustedStrike")
        df["stop_loss"] = f.get("adjustedBarrier")
        df["stop_loss_dist"] = dist(f.get("adjustedBarrier"), data.get("contractType"))

    else:
        if data["underlyings"][0]["currencyIsoName"] == "GBP":
            df["strike"] = round(
                data.get("strike") / data.get("proportionUnderlying"), 2
            )
            df["stop_loss"] = round(
                data.get("protectionBarrier") / data.get("proportionUnderlying"), 2
            )
            df["stop_loss_dist"] = dist(
                data.get("protectionBarrier") / data.get("proportionUnderlying"),
                data.get("contractType"),
            )
        else:
            df["strike"] = round(data.get("strike"), 2)
            df["stop_loss"] = round(data.get("protectionBarrier"), 2)
            df["stop_loss_dist"] = dist(
                data.get("protectionBarrier"), data.get("contractType"),
            )

    del df["cfin"]

    if df["upside"].isnull().all():
        del df["opinion"]
        del df["upside"]

    else:
        df["upside"] = df["upside"] / df["last"] - 1

    return df


def autocall_underlyings_details(data):
    # Get every underlying with Spot values
    underlyings = {
        x["technicalCfin"]: x["initRefValue"] / x["weight"] for x in data["underlyings"]
    }

    last_fixing_date = data["lastFixingDate"].get("fixingDate")
    last_fixing_date = pd.to_datetime(last_fixing_date, utc=True)
    last_fixing_date = last_fixing_date.tz_convert("Europe/Paris")
    last_fixing_date = last_fixing_date.date()

    df = underlyings_details(underlyings, last_date=last_fixing_date)

    df_atk = pd.DataFrame(data["fixingDates"])
    filtered_cols = ["fixingDate", "earlyRedemptionBarrier", "callable"]
    df_atk = df_atk[[x for x in filtered_cols if x in df_atk.columns]]

    # Add Autocall Barrier if is constant
    if not data["earlyRedemptionBarrierNonConstant"]:
        df_atk["earlyRedemptionBarrier"] = data.get("earlyRedemptionBarrier")

    # Convert Fixing to datetime
    df_atk.fixingDate = pd.to_datetime(df_atk.fixingDate, utc=True)
    df_atk.fixingDate = df_atk.fixingDate.dt.tz_convert("Europe/Paris")

    # Convert Fixing to strings
    df_atk.fixingDate = df_atk.fixingDate.dt.strftime("%b %d, %Y")

    # Find next Autocall Observation
    df_atk.fixingDate = pd.to_datetime(df_atk.fixingDate, format="%b %d, %Y")
    today = pd.to_datetime(dt.today().date())
    next_atk = df_atk[df_atk["callable"] & (df_atk.fixingDate >= today)]

    # Add Spot Initial and perf
    strike = df.apply(lambda x: round(underlyings[x.cfin], 2), axis=1)
    df.insert(3, "strike", strike)
    df["perf"] = df["last"] / df["strike"] - 1

    # Add calculated Distances
    if not next_atk.empty:
        df["autocallDist"] = (
            df["last"] / df["strike"] - next_atk["earlyRedemptionBarrier"].iloc[0]
        )
    if data.get("couponBarrier"):
        df["couponDist"] = df["last"] / df["strike"] - data["couponBarrier"]
    if data["protectionBarrier"]:
        df["capitalDist"] = df["last"] / df["strike"] - data["protectionBarrier"]

    del df["cfin"]

    if df["upside"].isnull().all():
        del df["opinion"]
        del df["upside"]

    else:
        df["upside"] = df["upside"] / df["last"] - 1

    return df


def display_levels_margins(cfin):
    alien = anything_to_cfin(cfin)
    cfin_margin = alien.json.get("cfin_contrib", cfin)
    return levels_margins(cfin_margin)


def instruments_calendars(cfins):
    base_url = "http://pott:8002/osiris/getInstrumentTemplate"
    params = [("cfins", str(x)) for x in cfins]

    r = rq.post(
        base_url + "?" + urlencode(params),
        headers={"Content-type": "application/json"},
    )

    data = r.json()

    if data:

        def dates(x):

            dates = x.get("fixingDates")

            if not dates:
                return pd.DataFrame()

            df = pd.DataFrame(dates)
            df = df[["fixingDate", "exDate", "paymentDate"]]  # Select relevant data

            # Convert Fixing and Payment Dates to datetime
            # df.fixingDate = pd.to_datetime(df.fixingDate)
            # df.exDate = pd.to_datetime(df.exDate)
            # df.paymentDate = pd.to_datetime(df.paymentDate)

            # Convert columns to date
            df = df.applymap(lambda x: parser.parse(x).date().strftime("%Y-%m-%d"))

            df.columns = ["fixing", "ex", "settlement"]  # Change columns names

            df = df.applymap(pd.to_datetime)

            return df

        result = {
            x["instrumentId"]: {"dates": dates(x), "issue_price": x["issuePrice"]}
            for x in data
        }

        return result


class Osiris(rq.Session):
    BASE_URL = "http://pott:8002/osiris/getInstrumentTemplate"

    def __init__(self):
        super().__init__()

    def field_for_cfin(self, cfin, field="type"):
        result = ""
        r = self.post(self.BASE_URL, params={"cfins": [cfin]})
        if r.status_code == 200:
            if r.json():
                result = r.json()[0].get(field, "")
        return result

    def cfins_details(self, cfins):
        r = self.post(self.BASE_URL, params={"cfins": cfins})
        if r.status_code == 200:
            return r.json()
        msg = f"Osiris API | Issue for {cfins} - {r.json()}"
        app.logger.warning(msg)

    def cfin_details(self, cfin):
        value = self.cfins_details([cfin])
        if value:
            return value[0]


def structured_product_details_from_osiris_data(data):

    if data["type"] not in structured_products_templates:
        return

    barrier_types = {
        "EUROPEAN": "Eur Barrier",
        "LEVERAGED_PUT": "Leveraged Put",
        "AMERICAN_INTRADAY": "US Intraday Barrier",
        "AMERICAN_AT_CLOSE": "US Close Barrier",
    }

    str_percent = lambda x: f"{x:.2%}".replace(".00%", "%")

    result = []

    # Get details of the Next Observation
    # if data.get("fixingDates"):
    next_obs = {}
    for date in data.get("fixingDates"):
        if date["fixingDate"] > dt_today("string_timestamp"):
            next_obs = date
            break

    if next_obs:
        next_obs_date = pd.to_datetime(next_obs.get("fixingDate"))
        result.append(("Next Obs", next_obs_date.date()))
    else:
        result.append(("Next Obs", "N/A"))

    # Add product Maturity
    data_maturity = data.get("termToMaturity")
    if data_maturity:
        if data_maturity % 12 == 0:
            maturity = f"{data_maturity // 12}Y"
        else:
            maturity = f"{data_maturity}m"
        result.append(("Maturity", maturity))

    # Add Coupon Frequency
    data_frequency = data["fixingScheduleParameters"]["periodicity"]
    frequency = coupon_freq.get(data_frequency, f"{data_frequency}M")
    result.append(("Frequency", frequency))

    # Check if autocallable and add relevant information if any
    if next_obs.get("callable"):
        autocall_barrier = next_obs.get("earlyRedemptionBarrier")
        if not autocall_barrier:
            autocall_barrier = data["earlyRedemptionBarrier"]
        result.append(("Autocall Barrier", str_percent(autocall_barrier)))

    # Define Coupon Type
    coupon_type = "Coupon"
    if data.get("couponEffect"):
        coupon_type = "Fixed Cpn"
    elif data.get("crescendoType") in ["TEMPO", "CLASSIC"]:
        coupon_type = "Memory Cpn"

    # Define Coupon
    coupon = data["coupon"] * 12 / data_frequency

    # Add Coupon Type and Coupon
    result.append((coupon_type, str_percent(coupon) + " p.a."))

    # Add Coupon Barrier
    data_cpn_barrier = data.get("couponBarrier")
    if data_cpn_barrier:
        result.append(("Coupon Barrier", str_percent(data_cpn_barrier)))

    # Add Capital Barrier
    data_barrier_name = data["protectionBarrierType"]
    barrier_name = barrier_types.get(data_barrier_name)
    barrier = str_percent(data["protectionBarrier"])
    result.append((barrier_name, barrier))

    return result


def display_autocall_details(data):
    # Format maturity
    maturity = (
        lambda x: None if not x else str(x // 12) + "Y" if x % 12 == 0 else str(x) + "M"
    )

    # Format percentage
    percentage_formating = (
        lambda x: None
        if not x
        else f"{int(x * 100)}%"
        if x * 100 == int(x * 100)
        else f"{round(float('{:,.4g}'.format(x * 100)), 2)}%"
    )

    barrier_types = {
        "EUROPEAN": "Eur Barrier",
        "LEVERAGED_PUT": "Leveraged Put",
        "AMERICAN_INTRADAY": "US Intraday Barrier",
        "AMERICAN_AT_CLOSE": "US Close Barrier",
    }

    tbl = {
        "coupon_type": f"{data.get('couponEffect').lower().capitalize()} "
        if not data.get("couponEffect") is None
        else "Memory "
        if data.get("crescendoType") == "TEMPO"
        else "",
        "coupon_freq": coupon_freq.get(
            data["fixingScheduleParameters"]["periodicity"],
            f"{data['fixingScheduleParameters']['periodicity']}M",
        ),
        "coupon_period": percentage_formating(data["coupon"]),
        "coupon_annualized": percentage_formating(
            data["coupon"] * (12 / data["fixingScheduleParameters"]["periodicity"])
        )
        if data["coupon"]
        else None,
        "coupon_barrier": percentage_formating(data["couponBarrier"]),
        "capital_barrier_type": barrier_types[data["protectionBarrierType"]],
        "capital_barrier": percentage_formating(data["protectionBarrier"]),
        "maturity": maturity(data.get("termToMaturity")),
    }

    df = pd.DataFrame(data["fixingDates"])

    df = df[["fixingDate", "earlyRedemptionBarrier", "callable", "redemptionAmount"]]

    # Add Autocall Barrier if is constant
    if not data["earlyRedemptionBarrierNonConstant"]:
        df["earlyRedemptionBarrier"] = data["earlyRedemptionBarrier"]

    # Add Redemption Amount if is constant
    if not data["redemptionAmountNonConstant"]:
        df["redemptionAmount"] = data["redemptionAmount"]

    # Convert Fixing to datetime
    df.fixingDate = pd.to_datetime(df.fixingDate, utc=True)

    # Convert Fixing and Payment Dates to strings
    df.fixingDate = df.fixingDate.dt.strftime("%b %d, %Y")

    # Find next Observation Date
    df.fixingDate = pd.to_datetime(df.fixingDate, format="%b %d, %Y")
    next_autocall = df[(df.callable == True) & (df.fixingDate >= dt.today())]

    if not next_autocall.empty:
        tbl.update(
            {
                "autocall_barrier": percentage_formating(
                    next_autocall["earlyRedemptionBarrier"].iloc[0]
                ),
                "redemption_amount": percentage_formating(
                    next_autocall["redemptionAmount"].iloc[0]
                ),
            }
        )

    return tbl


if __name__ == "__main__":
    # Display more columns when printing a Pandas DataFrame
    pd.options.display.width = 800
    pd.set_option("max_rows", 35)
    pd.set_option("max_columns", 15)

    # Test the class SQLDeals
    with server.app_context():
        pass
        osiris = Osiris()
        cfin = 38141550
        # cfin = 37997397  # Decreasing
        # cfin = 37997080  # Autocall reaching maturity
        # cfin = 40675795  # Autocall with lots of memo coupons
        data = Osiris().cfins_details(cfins)
        data = osiris.cfin_details(cfin)
        # d = display_autocall_underlyings_details(data)
        # d = display_autocall_details(data)
        #
        # cfin = 37630012
        # details = osiris.cfin_details(cfin)
        # dates = details["fixingDates"]
        #
        # # Get details of the Next Observation
        # next_obs_details = {}
        # for date in dates:
        #     if date["fixingDate"] > dt_today("string_timestamp"):
        #         next_obs_details = date
        #         break

        # Get underlying details

        # cfins = [38696827]

        # c = instruments_calendars(cfins)

        # data = instrument_details({"cfin": 38696827, "status": 200})
        # cal = display_calendar(data.json["content"][0])
        # cfin = 28400824
        # r = rq.post(f"http://pott:8002/osiris/getInstrumentTemplate?cfins={cfin}")
        # c = display_calendar(r.json()[0])

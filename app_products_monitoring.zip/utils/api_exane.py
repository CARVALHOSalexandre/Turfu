from datetime import datetime as dt
from datetime import timedelta

from requests import Session
from zeep import Client
from zeep.transports import Transport

from app import app


class Exane(Session, Client):
    """List of Functions Available : http://simbadsvc:8080/simbad-srv/services"""

    SIMBAD_BASE_URL = "http://simbadsvc:8080/simbad-srv/services/json/"
    WSDL = "http://simbadsvc:8080/simbad-srv/services/xml/service{}?wsdl"

    def __init__(self):
        super(Exane, self).__init__()

        try:
            super(Session, self).__init__(
                self.wsdl_url, transport=Transport(session=self),
            )
        except Exception:
            msg = "Stix Services | Connection Issue"
            app.logger.exception(msg)

        self.access_token_valid_time = None
        self.access_token_start_time = None

        self.client_id = "bichon_p"
        self.client_secret = "Ostr0gradsll"

    @property
    def wsdl_url(self):
        service_name = self.name[5:]
        return self.WSDL.format(service_name)

    @property
    def name(self):
        return self.__class__.__name__

    @property
    def service(self):

        if not self.access_token_valid_time:
            # msg = f"{self.name} | Getting first access_token"
            # app.logger.info(msg)
            self.set_authorization_token()

        if self.access_token_valid_time:
            now = dt.now()
            if now > self.access_token_valid_time - timedelta(minutes=3):
                nb_sec_before_valid_time = (self.access_token_valid_time - now).seconds
                msg = "{} | Refresh access_token {}s before valid time".format(
                    self.name, nb_sec_before_valid_time
                )
                app.logger.info(msg)
                self.set_authorization_token()

            return super().service

    def set_authorization_token(self):
        try:
            params = {
                "userName": self.client_id,
                "password": self.client_secret,
            }

            r = self.post(self.SIMBAD_BASE_URL + "serviceUsers/auth", json=params)
            r.raise_for_status()

            self.access_token_start_time = dt.now()
            self.access_token_valid_time = dt.now() + timedelta(minutes=5)

            auth_token = r.content.decode()

            self.headers["Authorization"] = "Bearer " + auth_token

        except Exception as e:
            msg = f"{self.name} | Error setting Exane Auth Token"
            app.logger.error(msg)


class ExaneHelpValues(Exane):
    pass


class ExaneInstruments(Exane):
    def update_typo(self, cfin, code_valeur, old_code_valeur=None):
        if old_code_valeur is not None:
            try:
                self.service.saveTypo(cfin, code_valeur)
            except:
                self.service.removeTypo(cfin, old_code_valeur)
                self.service.saveTypo(cfin, code_valeur)
        else:
            self.service.saveTypo(cfin, code_valeur)


class ExaneTiers(Exane):
    pass


class ExaneTools(Exane):
    pass


class ExaneUsers(Exane):
    pass


class ExaneSearchInstruments(Exane):
    pass


if __name__ == "__main__":
    users = ExaneUsers()
    instruments = ExaneInstruments()

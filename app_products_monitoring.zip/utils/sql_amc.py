import pandas as pd

from utils.osiris import instruments_calendars
import plotly.graph_objects as go
import utils.sql as sql
from utils.sql import *
from utils.basics import timeit
from models.base import *
from sqlalchemy import (
    case,
    func,
    not_,
    and_,
    or_,
    cast,
    INTEGER,
)
from datetime import datetime as dt
from sqlalchemy.orm import aliased
from pandas.tseries.offsets import BDay


def amc_underlyings_and_dates(cfin_amc):
    """All cfins involved in an AMC with min and max dates

    :parameter cfins_ul: list
    :return: df: DataFrame of all the underlyings that were part of the AMC
    """

    result = (
        db.session.query(
            Composition_h.cphsjac.distinct().label("cfin"),
            Instrument.ifnom.label("name"),
            Emission.emnominal.label("denom"),
            Codes.cfcode.label("isin"),
        )
        .join(
            (Instrument, Instrument.ifcfin == Composition_h.cphsjac),
            (Emission, Emission.emcfin == Instrument.ifcfin),
        )
        .outerjoin(Codes, and_(Codes.cfcfin == Instrument.ifcfin, Codes.cfsource == 6))
        .filter(Composition_h.cphcfin == cfin_amc)
    )

    return pd.DataFrame(result)


def underlyings_flux_nominal(df_cfins):
    """All transactions from Rkoperatoion from given cfins
    Filter on type Flux, opotype 51
    Filter if AMC's books are concerned dbbigbook in [63, 142, 249, 247]

    columns result = [cfin, trade_date, settlement_date, ccy, quantity, amount, price]

    :parameter df_cfins: DataFrame of the tickers
    :return: dff: DataFrame with columns described above
    """

    cfins = df_cfins.cfin.to_list()

    result = (
        db.session.query(
            Rkoperation.opcfin.label("cfin"),
            Rkoperation.opdatenego.label("trade_date"),
            Rkoperation.opdaterl.label("settlement_date"),
            Devise.dvcodeiso.label("ccy"),
            Rkoperation.opmontant.label("amount"),
            Rkoperation.opcours.label("price"),
        )
        .outerjoin(
            (Instrument, Instrument.ifcfin == Rkoperation.opcfin),
            (Rkdefbigbook, Rkdefbigbook.dbbook == Rkoperation.opbook),
            (Devise, Devise.dvcfin == Rkoperation.opdev),
        )
        .filter(
            and_(
                Rkdefbigbook.dbbigbook == 249,
                Rkoperation.opannule == None,
                Rkoperation.opflag != 3,
                Rkoperation.opotype == 51,  # Type flux
                Rkoperation.opcfin.in_(cfins),
                or_(
                    and_(Instrument.iftypofo >= 35000, Instrument.iftypofo < 36000),
                    Instrument.iftype.in_([52, 122, 211]),
                ),
            )
        )
    )

    df = pd.DataFrame(result)

    dff = pd.merge(df_cfins, df, on="cfin", how="left")

    dff["price"] = dff["price"] / 100

    dff["quantity"] = -(dff.amount / dff.denom) / dff.price

    dff["category"] = dff.amount.apply(lambda x: "buy" if x < 0 else "sell")

    return dff.sort_values(by="trade_date")


@timeit
def structured_products_coupons(cfins, return_dataframe=False):
    """All coupons for a given list of Structured Notes cfins
    Include Redemptions
    Data comes from Cube calculations

    :parameter cfins: List of Cfins
    :return: df: DataFrame of transactions
    """

    df = pd.DataFrame()

    calendars = instruments_calendars(cfins)

    result = {}

    if calendars:

        for cfin in calendars:
            calendar = calendars[cfin]
            paid_cpns = sql.cube_cpns_paid(cfin)
            df = calendar["dates"]
            df["paid"] = paid_cpns.paid
            df["nominal"] = paid_cpns.nominal
            df["autocalled"] = df["paid"] >= calendar["issue_price"]
            df["category"] = df.autocalled.apply(
                lambda x: "autocall" if x else "coupon"
            )

            # Filter date above any autocall event
            id_autocall = df.index[df.autocalled]
            if not id_autocall.empty:
                df = df[df.index <= id_autocall[0]]
            df = df.drop(columns=["autocalled"])

            # Filter dates without any coupons to be paid
            if not df.empty:
                df = df[(df.paid != 0) & (df.fixing < dt.now())]

                # Convert coupons format to float
                df.paid = pd.to_numeric(df.paid)

                result[cfin] = df.to_dict("records")

        # Convert the results to a DataFrame
        if return_dataframe:
            final = []

            for cfin in result:
                for cpn in result[cfin]:
                    final.append(
                        {
                            "cfin": cfin,
                            "nominal": cpn["nominal"],
                            "trade_date": cpn["fixing"],
                            "settlement_date": cpn["settlement"],
                            "cpn_or_autocall": cpn["paid"],
                            "category": cpn["category"],
                        }
                    )

            df = pd.DataFrame(final)

            if not df.empty:
                df = df.sort_values(by="trade_date")

    if return_dataframe:
        return df

    return result


def underlyings_memory_coupons(df_ul):
    """All coupons for a given list of Structured Notes
    Include Redemptions
    Data comes from Cube calculations

    :parameter df_ul: DataFrame of the Cfins and their names
    :return: df: DataFrame of transactions
    """

    cfins_ul = df_ul.cfin.to_list()

    calendars = instruments_calendars(cfins_ul)

    result = {}

    for cfin in calendars:
        calendar = calendars[cfin]
        paid_cpns = sql.cube_cpns_paid(cfin)
        df = calendar["dates"]
        df["paid"] = paid_cpns["paid"]
        df["autocalled"] = df["paid"] >= 100.0
        df["category"] = df.autocalled.apply(lambda x: "autocall" if x else "coupon")

        # Filter date above any autocall event
        id_autocall = df.index[df.autocalled]
        if not id_autocall.empty:
            df = df[df.index <= id_autocall[0]]
        df = df.drop(columns=["autocalled"])

        # Filter dates without any coupons to be paid
        # df_max_payment = df[df.paid != 0].copy()
        # if not df_max_payment.empty:
        #     df = df[df.index > max(df_max_payment.index)]
        # df = df[(df.paid == 0) & (df.fixing <= dt.now().date())]

        # Convert coupons format to float
        df.paid = pd.to_numeric(df.paid)

        if not df.empty:
            result[cfin] = df.to_dict("records")

    return result


def cfin_amc_from_cfin_certif(cfin_certif):
    """AMC's cfin from the certificate's

    select alcfin
    from exane.alien
    where
        altype = 46 and
        alsjac = (
            select cpsjac
            from exane.composition, instruments
            where
                ifcfin = cpsjac and
                iftypofo = 2000 and
                cpcfin = (
                    select desjac
                    from exane.derives
                    where decfin = <cfin>
                )
            )

    :param cfin_certif: integer
    :return: cfin: integer
    """
    cfin_basket_certif = (
        db.session.query(Derives.desjac)
        .filter(Derives.decfin == cfin_certif)
        .subquery()
    )

    cfin_ie = (
        db.session.query(Composition.cpsjac)
        .join(Instrument, Instrument.ifcfin == Composition.cpsjac)
        .filter(Instrument.iftypofo == 2000, Composition.cpcfin == cfin_basket_certif)
    ).subquery()

    codes_amc = aliased(Codes)
    codes_certif = aliased(Codes)

    result = (
        db.session.query(
            Alien.alcfin.label("cfin"),
            Instrument.ifnom.label("name"),
            codes_amc.cfcode.label("ticker"),
            codes_certif.cfcode.label("isin"),
        )
        .join(Instrument, Instrument.ifcfin == Alien.alcfin)
        .outerjoin(
            codes_amc, and_(codes_amc.cfcfin == Alien.alcfin, codes_amc.cfsource == 11)
        )
        .outerjoin(
            codes_certif,
            and_(codes_certif.cfcfin == cfin_certif, codes_certif.cfsource == 6),
        )
        .filter(Alien.altype == 46, Alien.alsjac == cfin_ie)
    ).first()

    return result._asdict()


def cfins_amc_from_cfin_underlying(cfin_product, date=None):
    """AMC's cfins from one of the underlyings

    :param cfin_product: integer
    :return: cfin: integer
    """
    inst = aliased(Instrument)
    inst_index = aliased(Instrument)
    inst_ul = aliased(Instrument)
    inst_collection = aliased(Instrument)

    if not date:
        date = prev_bday()

    d1 = []

    cfin_contrib = sql.alien(cfin_product).get(14)
    if cfin_contrib:

        alien_ie = (
            db.session.query(
                inst.ifcfin.label("cfin"),
                case([(Alien.alsjac == None, inst.ifcfin)], else_=Alien.alsjac).label(
                    "sjac"
                ),
            )
            .join(Alien, Alien.alcfin == inst.ifcfin)
            .filter(inst.ifcfin.in_([cfin_contrib[0], cfin_product]))
            .subquery()
        )

        result = (
            db.session.query(
                alien_ie.c.cfin.label("cfin_ul"),
                inst_index.ifcfin.label("cfin_index"),
                Codes.cfcode.label("ticker_index"),
                inst_index.ifnom.label("name_index"),
            )
            .join(
                (Collection, Collection.clsjac == alien_ie.c.sjac),
                (Pdtcompo, Pdtcompo.pccollect == Collection.clcollect),
                (inst_collection, inst_collection.ifcfin == Collection.clcollect),
                (inst_index, inst_index.ifcfin == Pdtcompo.pccfin),
            )
            .outerjoin(
                (Codes, and_(Codes.cfcfin == inst_index.ifcfin, Codes.cfsource == 11)),
            )
            .filter(
                and_(
                    inst_ul.ifcfin.in_([cfin_product]),
                    ~inst_index.ifnom.like(f"[SJ Tech] %"),
                    or_(Collection.cldateout == None, Collection.cldateout >= date),
                    ~inst_index.ifstatut.in_([7, 22]),
                    Collection.clcollect != 259501,  # Corresponds to "DR Issues"
                )
            )
        ).all()

        d1 = [x._asdict() for x in result]

    result_2 = (
        db.session.query(
            inst_ul.ifcfin.distinct().label("cfin_ul"),
            inst_index.ifcfin.label("cfin_index"),
            Codes.cfcode.label("ticker_index"),
            inst_index.ifnom.label("name_index"),
        )
        .join(
            (Collection, Collection.clsjac == inst_ul.ifcfin),
            (Pdtcompo, Pdtcompo.pccollect == Collection.clcollect),
            (inst_collection, inst_collection.ifcfin == Collection.clcollect),
            (inst_index, inst_index.ifcfin == Pdtcompo.pccfin),
        )
        .outerjoin(
            (Codes, and_(Codes.cfcfin == inst_index.ifcfin, Codes.cfsource == 11)),
        )
        .filter(
            and_(
                inst_ul.ifcfin == cfin_product,
                ~inst_index.ifnom.like(f"[SJ Tech] %"),
                or_(Collection.cldateout == None, Collection.cldateout >= date),
                ~inst_index.ifstatut.in_([7, 22]),
            )
        )
    ).all()

    d2 = [x._asdict() for x in result_2]

    return d1 + d2


def structured_products_cash_per_cpns(df_ul):
    df_flux = underlyings_flux_nominal(df_ul)

    cfin_ul = df_ul.cfin.to_list()
    cpns_per_cfin = structured_products_coupons(cfin_ul)

    result = []

    for cfin in cpns_per_cfin:
        for cpn in cpns_per_cfin[cfin]:
            dff = df_flux[df_flux.cfin == cfin]
            dff = dff[dff.trade_date.dt.date <= cpn["fixing"]]
            denom = list(dff.loc[:, "denom"])[0]
            nominal = dff.quantity.sum() * denom
            cash_cpn = cpn["paid"] * nominal / 100
            result.append(
                {
                    "cfin": cfin,
                    "isin": dff["isin"].iloc[0],
                    "name": dff.name.iloc[0],
                    "trade_date": cpn["fixing"],
                    "settlement_date": cpn["settlement"],
                    "denom": denom,
                    "ccy": dff.ccy.iloc[0],
                    "nominal": nominal,
                    "cpn_or_autocall": cpn["paid"],
                    "amount": cash_cpn,
                    "category": cpn["category"],
                }
            )

    df = pd.DataFrame(result)

    df = df.sort_values(by="trade_date")

    dff = pd.concat([df, df_flux], keys="cfin")

    return dff.reset_index(drop=True)


def memory_cash_per_cpns(df_ul):
    df_flux = underlyings_flux_nominal(df_ul)
    cpns_per_cfin = underlyings_memory_coupons(df_ul)

    result = []

    for cfin in cpns_per_cfin:
        for cpn in cpns_per_cfin[cfin]:
            dff = df_flux[df_flux.cfin == cfin]
            dff = dff[dff.trade_date.dt.date <= cpn["fixing"]]
            denom = dff.denom.max()
            nominal = dff.quantity.sum() * denom
            cash_cpn = cpn["paid"] * nominal / 100
            result.append(
                {
                    "cfin": cfin,
                    "isin": dff["isin"].iloc[0],
                    "name": dff.name.iloc[0],
                    "trade_date": cpn["fixing"],
                    "settlement_date": cpn["settlement"],
                    "denom": denom,
                    "ccy": dff.ccy.iloc[0],
                    "nominal": nominal,
                    "cpn_or_autocall": cpn["paid"],
                    "amount": cash_cpn,
                    "category": cpn["category"],
                }
            )

    df = pd.DataFrame(result)

    df = df.sort_values(by="trade_date")

    dff = pd.concat([df, df_flux], keys="cfin")

    return dff.reset_index(drop=True)


def cash_and_dividends_certif(cfin_certif):
    """All cash flows between client and certif
    From Rkoperations with types Flux and Tombee Coupon / Div

    :param cfin_certif: integer
    :return: df: DataFrame of transactions
    """

    result = (
        db.session.query(
            Rkoperation.opcfin.label("cfin"),
            Codes.cfcode.label("isin"),
            Instrument.ifnom.label("name"),
            Rkoperation.opdatenego.label("trade_date"),
            Rkoperation.opdaterl.label("settlement_date"),
            Emission.emnominal.label("denom"),
            Devise.dvcodeiso.label("ccy"),
            Rkoperation.opmontant.label("amount"),
            Rkoperation.opquantite.label("quantity"),
            Rkoperation.opcours.label("price"),
            Rkoperation.opotype.label("category"),
            # Rktypeop.tolibelle.label("type"),
        )
        .select_from(Rkoperation)
        .join(
            (Instrument, Instrument.ifcfin == Rkoperation.opcfin),
            (Emission, Emission.emcfin == Rkoperation.opcfin),
            # (Rktypeop, Rktypeop.tootype == Rkoperation.opotype),
            (Rkdefbigbook, Rkdefbigbook.dbbook == Rkoperation.opbook),
            (Devise, Devise.dvcfin == Rkoperation.opdev),
        )
        .outerjoin(Codes, and_(Codes.cfcfin == Rkoperation.opcfin, Codes.cfsource == 6))
        .filter(
            and_(
                Rkdefbigbook.dbbigbook == 249,
                Rkoperation.opannule == None,
                Rkoperation.opflag != 3,
                Rkoperation.opmontant != 0,
                Rkoperation.opotype.in_([51, 44]),
                Rkoperation.opcfin == cfin_certif,
            )
        )
        .order_by(Rkoperation.opdatenego)
    )

    df = pd.DataFrame(result)

    if not df.empty:

        df.price = df.apply(
            lambda x: x["price"] / 100 if x["quantity"] != 0 else np.NaN, axis=1
        )

        def certif_flux_categories(x):
            if x["category"] == 44:
                return "div"
            if x["quantity"] < 0:
                return "cash in"
            return "cash out"

        df["category"] = df.apply(certif_flux_categories, axis=1)

    return df


def concat_transactions(*df, keys="cfin", order_by="trade_date"):
    dff = pd.concat([*df], keys=keys)
    dff = dff.reset_index(drop=True)
    dff = dff.sort_values(by=order_by)
    return dff


def get_cfin_collection_from_cfin_amc(cfin):
    r = Composition_h.query.filter_by(cphcfin=cfin).first()
    if r:
        return r.cphcollect

    r = Pdtcompo.query.filter_by(pccollect=cfin).first()
    if r:
        return r.pccollect


@timeit
def report_from_certif(cfin_certif, cfin_amc=None, format=False):
    """Certificate performances and cash details

    :param cfin_certif: AMC's cfin as integer
    :return: Dictionnary of details
    """

    details_amc = cfin_amc_from_cfin_certif(cfin_certif)

    if not cfin_amc:
        cfin_amc = details_amc.get("cfin")

    # AMC's underlyings that have been once in the composition
    df_ul = amc_underlyings_and_dates(cfin_amc)

    # Coupons and Redemptions of AMC's underlyings
    cash_cpns = structured_products_cash_per_cpns(df_ul)

    # Cash added, withdrawals and Dividends to client
    certif_cash_and_divs = cash_and_dividends_certif(cfin_certif)

    # Concatenate all transactions in one DataFrame
    df_transac = concat_transactions(cash_cpns, certif_cash_and_divs)

    today = dt.now().date()
    last_week = today - BDay(5)

    # Get histo compositions and compute weekly performance
    df_compo = sql.execute_sql_query(
        "compo_full",
        index_cfin=cfin_amc,
        start_date=prev_bday(1).strftime("%d/%m/%Y"),
        end_date=prev_bday(1).strftime("%d/%m/%Y"),
    )

    # Calculate previous and new amounts of Cash
    cfin_monetary = 24215954
    prev_nb_certif = pose_certif(cfin_certif, end_date=last_week)
    prev_cash_qp1 = df_compo[df_compo.Cfin == cfin_monetary].Qp1.iloc[0]
    prev_cash_close = df_compo[df_compo.Cfin == cfin_monetary].Close.iloc[0]
    prev_cash = prev_nb_certif * prev_cash_qp1 * prev_cash_close

    new_nb_certif = pose_certif(cfin_certif, end_date=today)
    cash_qp1 = df_compo[df_compo.Cfin == cfin_monetary].Qp1.iloc[0]
    cash_close = df_compo[df_compo.Cfin == cfin_monetary].Close.iloc[0]
    new_cash = new_nb_certif * cash_qp1 * cash_close

    # Levels of Index and Best/Worst Performers
    cfin_contrib = alien(cfin_certif).get(14)
    df_histo_certif = histo_prices(cfin_contrib, last_week, last_week + BDay(4))
    prev_price = df_histo_certif.iloc[0, 4]
    new_price = df_histo_certif.iloc[df_histo_certif.index.max(), 4]
    index_perf = new_price / prev_price - 1

    # Set best and worst performer among the components
    # Don't consider Monetary indices for the performers
    dff_compo = df_compo[~df_compo.Name.str.contains("onetary")]
    best_performer = dict(dff_compo.iloc[0])
    worst_performer = dict(dff_compo.iloc[-1])

    capitalize = lambda x: x.capitalize()
    to_short_name = lambda x: f"{x[:25]}..."
    to_str_date = (
        lambda x: pd.to_datetime(x).strftime("%b %d, %Y") if not pd.isna(x) else ""
    )
    to_str_decimal = lambda x: "{:,.2f}".format(x) if not pd.isna(x) else ""
    to_str_percent = lambda x: "{:,.2%}".format(x) if not pd.isna(x) else ""
    to_str_percent_2 = lambda x: "{:,.2f}%".format(x) if not pd.isna(x) else ""
    to_str_quantity = lambda x: "{:,.0f}".format(x) if not pd.isna(x) else ""

    # Operations over last week
    dff_transac = df_transac[df_transac.trade_date >= last_week].copy()

    if format:

        # Don't show the 40 bps fees for new product
        dff_transac.loc[dff_transac.price == 1.004, "price"] = 1.0

        # Format DataFrame of the operations
        d_format = {
            "category": capitalize,
            "name": to_short_name,
            "trade_date": to_str_date,
            "settlement_date": to_str_date,
            "nominal": to_str_quantity,
            "quantity": to_str_quantity,
            "price": to_str_percent,
            "cpn_or_autocall": to_str_percent_2,
        }

        for col in d_format:
            dff_transac.loc[:, col] = dff_transac[col].apply(d_format[col])

    return {
        "amc": details_amc,
        "index": {
            "prev_price": f"{prev_price:.2f}%",
            "new_price": f"{new_price:.2f}%",
            "performance": f"{index_perf:.2%}",
            "best_performer": best_performer,
            "worst_performer": worst_performer,
        },
        "cash": {
            "prev_amount": f"USD {prev_cash:,.0f}",
            "new_amount": f"USD {new_cash:,.0f}",
            "delta_cash": f"USD {new_cash - prev_cash:,.0f}",
        },
        "operations": dff_transac.to_dict("records"),
    }


def show_waterfall_graph(cfin_certif):
    details_amc = cfin_amc_from_cfin_certif(cfin_certif)

    cfin_amc = details_amc.get("cfin")

    # AMC's underlyings and their names / denom
    df_ul = amc_underlyings_and_dates(cfin_amc)

    # Coupons and Redemptions of AMC's underlyings
    # cash_cpns = memory_cash_per_cpns(df_ul)
    cash_cpns = structured_products_cash_per_cpns(df_ul)

    # Cash added, withdrawals and Dividends to client
    certif_cash_and_divs = cash_and_dividends_certif(cfin_certif)
    certif_cash_and_divs.to_clipboard()

    # Concatenate all transactions in one DataFrame
    df = concat_transactions(cash_cpns, certif_cash_and_divs)

    df["measure"] = "relative"

    fig = go.Figure(
        go.Waterfall(
            x=df.trade_date.to_list(),
            measure=df.measure.to_list(),
            text=df.name.to_list(),
            y=df.amount.to_list(),
            base=0,
            decreasing={
                "marker": {"color": "#c0392b", "line": {"color": "#e74c3c", "width": 1}}
            },
            increasing={
                "marker": {"color": "#16a085", "line": {"color": "#1abc9c", "width": 1}}
            },
            totals={
                "marker": {
                    "color": "deep sky blue",
                    "line": {"color": "blue", "width": 3},
                }
            },
        )
    )

    fig.update_layout(title="AMCs Cash Flows", plot_bgcolor="#ecf0f1", waterfallgap=0.1)

    fig.show()


if __name__ == "__main__":
    # Display more columns when printing a Pandas DataFrame
    pd.options.display.width = 800
    pd.set_option("max_rows", 35)
    pd.set_option("max_columns", 15)

    from app import server

    with server.app_context():
        # 37183962 - Global Gate AMC - Structured Products Opportunities
        # 37184025 - Certficate EXDMGGSP 05-12-2022

        test = cash_and_dividends_certif(39217985)

        details = report_from_certif(cfin_certif=37184025)

        # Display waterfall graph of cash flows in browser
        show_waterfall_graph(37184025)

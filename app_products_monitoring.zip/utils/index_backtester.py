from app import server
import utils.performance_attribution as pa
from typing import Union, Dict, Any
import utils.sql as sql
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime as dt
from functools import reduce


# ----------------- To do -----------------------
# 1/Consider rebalancing frequency for drifted weights
# 2/Add fees
# 3/Add case of futures and rolling futures
# -----------------------------------------------


class IndexBacktester:
    """This class is a backtester which computes index levels for a dict of weight and cfin, and for a selected period
    of time"""

    def __init__(
        self,
        composition_to_backtest: Dict[
            Union[str, int], float
        ],  # dictionary of cfin which could be str or int, and its weight which is a float
        start_date: dt.date,
        end_date: dt.date,
        rebalancing_frequency: int,
        fees: None,
    ):
        self.composition_to_backtest = composition_to_backtest
        self.start_date = start_date
        self.end_date = end_date

    def load_underlying_prices(self) -> pd.DataFrame:
        query = sql.histo_prices(
            list(self.composition_to_backtest.keys()), self.start_date, self.end_date
        )
        df_prices_udl = query.pivot(index="Date", columns="Cfin", values="Close")
        return df_prices_udl

    def compute_returns(self) -> pd.DataFrame:
        return self.load_underlying_prices().pct_change()[1:]

    def compute_weighted_returns(self) -> pd.DataFrame:
        """Compute the weighted returns considering drifted weights"""
        returns = self.compute_returns()
        returns.index.name = "Dates"
        theoretical_weights = pd.DataFrame(
            self.composition_to_backtest.values(),
            index=returns.columns,
        )

        # init
        returns_t0 = pd.DataFrame(returns.iloc[0])
        weighted_returns_t0 = theoretical_weights.values * returns_t0.values

        # set dataframes
        drifted_weights = np.ones(len(returns)) * theoretical_weights.values
        df_drifted_weights = pd.DataFrame(drifted_weights).T.set_index(returns.index)

        df_weighted_returns = pd.DataFrame().reindex_like(returns)
        df_weighted_returns.iloc[0] = weighted_returns_t0.T

        data_frames = [returns, df_drifted_weights, df_weighted_returns]
        df_final = reduce(
            lambda left, right: pd.merge(left, right, on="Dates", how="outer"),
            data_frames,
        )

        # loop to compute drifted weights, no better way to do so far
        _number_of_udl = len(theoretical_weights)
        _numbers_of_columns = _number_of_udl * len(data_frames)
        for i in range(len(df_final) - 1):
            for j in range(_number_of_udl):
                df_final.iloc[i + 1, j + _number_of_udl] = (
                    df_final.iloc[i, j + _number_of_udl]
                    * (1 + df_final.iloc[i, j])
                    / (
                        1
                        + df_final.iloc[i, _numbers_of_columns - _number_of_udl :].sum()
                    )
                )
                df_final.iloc[i + 1, j + _numbers_of_columns - _number_of_udl] = (
                    df_final.iloc[i + 1, j] * df_final.iloc[i + 1, j + _number_of_udl]
                )

        return df_final

    def compute_index_returns(self) -> pd.DataFrame:
        index_weighted_returns = self.compute_weighted_returns().iloc[
            :, -int(self.compute_weighted_returns().shape[1] / 3) :
        ]  # three will always be fixed, number of merged dataframes
        index_returns = index_weighted_returns.sum(axis=1)
        return pd.DataFrame(index_returns, index=index_returns.index)

    def compute_index_levels(self) -> pd.DataFrame:
        """Compute all levels over the period"""
        index_returns = self.compute_index_returns()
        index_levels = pd.DataFrame(
            [
                np.prod(1 + index_returns.iloc[:i].values)
                for i in range(len(index_returns) + 1)
            ]
        )
        index_levels.set_index(self.load_underlying_prices().index, inplace=True)
        return index_levels

    def compute_final_index_level(self) -> float:
        """Compute the final levels of the index"""
        index_returns = self.compute_index_returns()
        return np.prod(1 + index_returns.values)[0]

    def plot_graph_backtest(self):
        """Plot graph of index with base 1000"""
        df = self.compute_index_levels()
        results = df[0] * 1000
        plt.style.use("ggplot")
        plt.figure(figsize=(14, 7))
        plt.xticks(rotation=40)
        plt.xlabel("Date")
        plt.ylabel("Index level")
        plt.plot(df.index, results)
        plt.show()


if __name__ == "__main__":
    with server.app_context():

        composition = {"351": 0.6, "2151": 0.4}
        # Danone, cfin : 351
        # Total E, cfin : 2151

        start_date = dt(2016, 9, 1)
        end_date = dt(2021, 9, 30)

        x = IndexBacktester(
            composition, start_date, end_date, rebalancing_frequency=0, fees=None
        )
        x.plot_graph_backtest()

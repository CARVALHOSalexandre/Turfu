from app import server
import pandas as pd
from datetime import datetime as dt
import utils.sql as sql
from tqdm import tqdm
from utils.basics import timeit
from utils.sql_amc import structured_products_coupons
from utils.api_sg_youtrack import DataAmcSG
from pprint import pprint


@timeit
def return_analysis(
    cfin,
    start_date,
    end_date,
    df_compo=pd.DataFrame(),
    index_levels=pd.DataFrame(),
    group_by=None,
    return_errors=False,
):
    start_date = pd.to_datetime(start_date)
    end_date = pd.to_datetime(end_date)

    if index_levels.empty:
        # Get indices levels
        index_levels = sql.histo_prices(cfin, start_date, end_date)
        index_levels.Date = pd.to_datetime(index_levels.Date)

    # Change the start and end date to match last available value for the index
    start_date = max(start_date, min(index_levels.Date))
    end_date = min(end_date, max(index_levels.Date))

    if df_compo.empty:
        df_compo = sql.execute_sql_query(
            "compo_full",
            index_cfin=cfin,
            start_date=start_date.strftime("%d/%m/%Y"),
            end_date=end_date.strftime("%d/%m/%Y"),
        )
        df_compo.Date = pd.to_datetime(df_compo.Date, format="%d/%m/%Y")
        df_compo = df_compo.sort_values(by="Date")

        # Get Structured Products Coupons
        cfins_ul = list(df_compo.Cfin.unique())
        df_cpns = structured_products_coupons(cfins_ul, return_dataframe=True)
        if not df_cpns.empty:
            df_cpns = df_cpns[
                (df_cpns.category == "coupon")
                & (df_cpns.trade_date >= start_date)
                & (df_cpns.trade_date <= end_date)
            ]
            df_cpns["cpn_or_autocall"] *= df_cpns["nominal"] / 100
            if not df_cpns.empty:
                df_cpns = df_cpns[["cfin", "trade_date", "cpn_or_autocall"]]
                df_cpns = df_cpns.rename(
                    columns={
                        "cfin": "Cfin",
                        "trade_date": "Date",
                        "cpn_or_autocall": "SP Coupon",
                    }
                )
                df_compo = df_compo.merge(df_cpns, on=["Cfin", "Date"], how="left")
                # df_compo["SP Coupon"] = df_compo["SP Coupon"] * df_compo["Issue Price"] / 100

        cols = [x for x in ["Net Div. in Cash", "Coupon", "SP Coupon"] if x in df_compo]
        df_compo["Flows"] = df_compo[cols].fillna(0).sum(axis=1)

    # Fill missing closes with Issue Price if relevant
    if "Issue Price" in df_compo.columns:
        if "Entry Date" in df_compo.columns:
            df_compo["Issue Date"] = pd.to_datetime(df_compo["Issue Date"])
            df_compo.Close = df_compo.apply(
                lambda x: x["Issue Price"]
                if pd.isna(x["Close"]) and x["Date"] <= x["Issue Date"]
                else x["Close"],
                axis=1,
            )

    if "Close Epix" in df_compo:
        df_compo.Close = df_compo["Close Epix"]

    if "Change Epix" in df_compo:
        df_compo.Change = df_compo["Change Epix"]

    values = ["Weight", "Close", "Flows", "Change", "Qp1"]
    df_pivot = df_compo.pivot(index="Date", columns="Cfin", values=values)

    # Drop rows where the Closing Levels are missing for all underlyings
    df_pivot = df_pivot.loc[df_pivot.Close.dropna(how="all").index]

    # Adapt closing prices with levels from "Order and Fees"
    df_orders = sql.execute_sql_query(
        "amc_orders_and_fees",
        bind="exane_analyse_structuration",
        index_cfin=cfin,
        start_date=start_date.strftime("%d/%m/%Y"),
        end_date=end_date.strftime("%d/%m/%Y"),
    )
    # df_orders = pd.DataFrame()
    if not df_orders.empty:
        df_orders.Change.fillna(1.0, inplace=True)
        df_orders.Date = pd.to_datetime(df_orders.Date, format="%d/%m/%Y")

        for d in df_orders.to_dict("records"):

            if d["Cfin"] in df_pivot.Close and d["Close"] != 0:
                close = d["Close"]
                if d["Quotation Mode"] == "% Nominal":
                    close = d["Clean Close"] * d["Nominal"] / 100
                else:
                    print(close)
                df_pivot.Close.loc[d["Date"], d["Cfin"]] = close
                df_pivot.Change.loc[d["Date"], d["Cfin"]] = d["Change"]

                if pd.isna(df_pivot.Qp1.loc[d["Date"], d["Cfin"]]):
                    # Find previous date
                    idx = df_pivot.index.get_loc(d["Date"])
                    prev_date = df_pivot.index[idx - 1]
                    df_pivot.Qp1.loc[d["Date"], d["Cfin"]] = df_pivot.Qp1.loc[
                        prev_date, d["Cfin"]
                    ]
                    df_pivot.Weight.loc[d["Date"], d["Cfin"]] = df_pivot.Weight.loc[
                        prev_date, d["Cfin"]
                    ]

            if d["Cfin Contrib"] in df_pivot.Close:
                df_pivot.Close.loc[d["Date"], d["Cfin Contrib"]] = d["Close"]
                df_pivot.Change.loc[d["Date"], d["Cfin Contrib"]] = d["Change"]

            if d["Cfin IE"] in df_pivot.Close:
                df_pivot.Close.loc[d["Date"], d["Cfin IE"]] = d["Close"]
                df_pivot.Change.loc[d["Date"], d["Cfin IE"]] = d["Change"]

    # Find rebalancing dates including the first and last date
    rebal_begin_dates = list(df_pivot.Qp1.drop_duplicates(keep="first").index)
    rebal_end_dates = list(df_pivot.Qp1.drop_duplicates(keep="last").index)
    dates = []

    if rebal_begin_dates == rebal_end_dates:
        # If you consider a subset of two consecutive dates
        for k, date in enumerate(rebal_end_dates[:-1]):
            dates.append((date, rebal_end_dates[k + 1]))
    else:
        for begin, end in zip(rebal_begin_dates, rebal_end_dates):
            if dates:
                # Append previous one day reshuffle period
                period = (dates[-1][1], begin)
                dates.append(period)
            if begin != end:
                dates.append((begin, end))

    columns = [
        "Entry Date",
        "Cfin",
        "Name",
        "Isin",
        "Ticker",
        "Type",
        "Sector",
        "Country",
        "Ccy",
    ]
    columns = [x for x in columns if x in df_compo.columns]

    # Initiate DataFrame of the results
    df_results = df_compo[columns].drop_duplicates(subset=["Cfin"], keep="last")
    df_results.set_index("Cfin", inplace=True)

    # Fill with Other or N/A the "group_by" columns
    if "Type" in df_compo.columns:
        df_results.Type.fillna("Other", inplace=True)
    if "Sector" in df_compo.columns:
        df_results.Sector.fillna("N/A", inplace=True)
    if "Country" in df_compo.columns:
        df_results.Country.fillna("N/A", inplace=True)

    # Initiate columns of the attribution results
    df_results["FX Attr."] = 1.0
    df_results["UL Attr."] = 1.0

    unexplained = []

    for date, next_date in tqdm(dates):

        # Slice original DataFrame between rebal dates
        df = df_pivot[(df_pivot.index >= date) & (df_pivot.index <= next_date)]

        ul_results = df.Weight.iloc[0] * (
            (
                df.Close.iloc[-1]
                - df.Close.iloc[0]
                # + df.Flows.sum() * df.Change.iloc[-1] / df.Change.iloc[0]
            )
            / df.Close.iloc[0]
        )

        ul_attribution = ul_results.sum()

        fx_results = (
            df.Weight.iloc[0]
            * (df.Close.iloc[-1] / df.Close.iloc[0])
            * (df.Change.iloc[-1] / df.Change.iloc[0] - 1)
        )
        fx_attribution = fx_results.sum()

        index_perf = (
            index_levels[index_levels.Date == next_date].Close.iloc[0]
            / index_levels[index_levels.Date == date].Close.iloc[0]
            - 1
        )

        # Testing for difference in theoretical perf and decomposed computed performance
        diff = index_perf - fx_attribution - ul_attribution
        unexplained.append(
            {
                "start": date.date(),
                "end": next_date.date(),
                "diff": diff,
                "index": index_perf,
                "fx": fx_attribution,
                "ul": ul_attribution,
            }
        )

        # if abs(diff) > 0.001:
        #     df.Qp1.iloc[[0, -1]].dropna(how="all", axis=1).to_clipboard()
        #     df.Close.iloc[[0, -1]].dropna(how="all", axis=1).to_clipboard()
        #     df.Change.iloc[[0, -1]].dropna(how="all", axis=1).to_clipboard()
        #     df.Weight.iloc[[0, -1]].dropna(how="all", axis=1).to_clipboard()
        #     df.Flows.iloc[[0, -1]].dropna(how="all", axis=1).to_clipboard()
        #     df_orders[df_orders.Date == next_date].to_clipboard()

        df_results["FX Attr."] *= 1 + fx_results.fillna(0.0)
        df_results["UL Attr."] *= 1 + ul_results.fillna(0.0)

    df_un = pd.DataFrame(unexplained)
    df_un.to_clipboard()

    if return_errors:
        df_un.rename({"start": "Start Date", "end": "End Date"}, axis=1, inplace=True)
        return df_un

    index_perf = (
        index_levels[index_levels.Date == end_date].Close.iloc[0]
        / index_levels[index_levels.Date == start_date].Close.iloc[0]
        - 1
    )

    # Initiate columns of the results
    df_results["FX Attr."] -= 1.0
    df_results["UL Attr."] -= 1.0
    df_results["Perf."] = df_results[["FX Attr.", "UL Attr."]].sum(axis=1)
    df_results = df_results.sort_values(by="Perf.", ascending=False)
    df_results.reset_index(inplace=True)

    # If user wants to have a perfect match in the results
    # if adjusted_results:
    #     # Correct for infinitesimal gap
    #     diff = index_perf - (df_results["Perf."] + 1).cumprod() - 1
    #     df_results["Perf."] = df_results["Perf."].apply(lambda x: x + diff * abs(x) / abs(cumprod).sum())

    df_results.to_clipboard()

    # Insert a row with Index details
    index_details = sql.cfin_details(cfin)
    df_index = pd.DataFrame.from_dict(index_details, orient="index")
    df_index = df_index.dropna().T.drop(columns=["type", "class"])
    df_index.columns = [x.capitalize() for x in df_index.columns]
    df_index["FX Attr."] = df_results["FX Attr."].sum()
    df_index["UL Attr."] = df_results["UL Attr."].sum()
    df_index["Perf."] = index_perf

    if group_by:
        columns = ["FX Attr.", "UL Attr.", "Perf."]
        group_by = str(group_by).capitalize()
        dfff = df_results.groupby(group_by)[columns].sum()
        dfff.reset_index(inplace=True)
        dfff = dfff[dfff["Perf."] != 0]
        dfff = dfff.sort_values(by="Perf.", ascending=False)
        df_index = df_index.rename({"Name": group_by}, axis=1)
        df_index = df_index[[group_by] + columns]
        return pd.concat([df_index, dfff])

    # Displaying convenient DataFrame
    df_final = pd.concat([df_index, df_results])

    columns = [
        "Cfin",
        "Name",
        "Ticker",
        "Isin",
        "Ccy",
        "Entry Date",
        "Type",
        "Sector",
        "Country",
        "Change at Entry",
        "Change",
        "Close at Entry",
        "Close Date",
        "Perf since Entry",
        "Perf 1 Month",
        "Perf YTD",
        "FX Attr.",
        "UL Attr.",
        "Perf.",
    ]
    columns = [x for x in columns if x in df_final.columns]

    return df_final[columns]


if __name__ == "__main__":
    import matplotlib as plt

    with server.app_context():
        # cfin = 39217985  # WOFI USD
        # cfin = 36908977  # Antler
        # cfin = 46748830  # Bordier Green Climate Bond
        # cfin = 44130188  # Bordier Sustainable Hybrid
        # cfin = 37183962  # Global Gate
        # cfin = 47012175  # US Infrastructure New Cycle Dynamic
        # cfin = 37183962  # Global Gate
        cfin = 39643027  # exdmesco - BES Credit Opportunities

        start_date = dt(2021, 1, 1)
        end_date = dt(2021, 9, 11)

        df = return_analysis(cfin, start_date, end_date)

        df = return_analysis(cfin, dt(2021, 5, 28), dt(2021, 6, 4))

        # Special AMC China
        # id = "SGBCHAMC"
        # data = DataAmcSG(id, "USD", start_date, end_date)
        # df_compo = data.df_raw.rename(
        #     columns={
        #         "Quantity": "Qp1",
        #         "ISIN": "Cfin",
        #         "Spot": "Close",
        #         "Bloomberg": "Ticker",
        #     }
        # )

        # df_compo["Flows"] = 0

        # index_levels = data.get_historical_prices(id, start_date, end_date)
        # index_levels = index_levels.reset_index()
        # index_levels = index_levels[["index", "Published Level"]].rename(
        #     columns={"Published Level": "Close", "index": "Date"}
        # )

        # df = return_analysis(
        #     cfin, start_date, end_date, df_compo=df_compo, index_levels=index_levels
        # )
        df.to_clipboard()
        print(df)

import pandas as pd

from app import app
from utils.sql import *
import utils.sql as sql
import utils.sql_amc as sql_amc
from utils.osiris import display_rolls
from utils.basics import timeit
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.graph_objects as go
from dash import dcc
import numpy as np


def basis_graph_structured_product():

    figure = make_subplots(specs=[[{"secondary_y": True}]])

    # figure = px.line(
    #     x="Date",
    #     y="Price",
    #     color="Name",
    #     color_discrete_sequence=[
    #         "#007685",
    #         "#3592A2",
    #         "#57B0BF",
    #         "#77CEDE",
    #         "#96EDFD",
    #     ],
    # )

    figure.update_layout(
        legend=dict(
            title="",
            orientation="h",
            y=1.2,
        ),
        xaxis=dict(
            title="<b>Date</b>",
            showgrid=False,
            showspikes=True,
            spikecolor="rgb(153,174,188)",
            spikethickness=1,
            spikedash="solid",
        ),
        yaxis=dict(title="<b>Bid</b> Levels", automargin=True, tickformat=",.2%"),
        yaxis2=dict(title="<b>Bid</b> Margin", automargin=True),
        hovermode="x",
        template="plotly_white",
        margin=dict(l=0, r=0, b=0, t=0, pad=0),
    )

    config = {
        "displaylogo": False,
        "displayModeBar": False,
    }

    return dcc.Graph(
        figure=figure, config=config, id="autocall-graph-perf", className="main-graph"
    )


pre_graph_structured_product = basis_graph_structured_product()


def data_graph_structured_product(data):

    product = {data["instrumentId"]: data.get("issuePrice")}
    underlyings = {
        x["technicalCfin"]: x.get("initRefValue") / x.get("weight")
        for x in data["underlyings"]
    }

    start_date = api_date_to_string(data["initialFixingDate"])

    df_ul = histo_prices(list(underlyings.keys()), start_date=start_date)

    # Check if the product has been rebooked
    cfin = list(product.keys())[0]
    cfin_rebooked = sql.alien(cfin, product_type="sjac").get(21)
    if cfin_rebooked:
        cfin = cfin_rebooked[0]

    df_product = histo_prices(cfin, start_date=start_date)

    if df_ul.empty and df_product.empty:
        return

    # Replace first values with strike values
    # Useful in case of live strike
    for cfin_ul in underlyings:
        index = df_ul[df_ul.Cfin == cfin_ul].index[0]
        df_ul.at[index, "Close"] = underlyings[cfin_ul]

    if not df_ul.empty:
        df_ul["Price"] = df_ul.apply(
            lambda x: x["Close"] / underlyings[x["Cfin"]], axis=1
        )

    if not df_product.empty and not df_product[["Bid"]].isna().all().bool():
        df_product["Price"] = df_product.Close / data.get("issuePrice", 1.0)

    # Add first point of 100 if no initial price for autocall
    # Check if product is not a swap
    if not data["swap"]:
        if not df_product.empty and df_product[df_product["Date"] == start_date].empty:
            df_product = df_product.append(
                {
                    "Cfin": data["instrumentId"],
                    "Date": start_date,
                    "Name": df_product["Name"].iloc[0],
                    "Price": 1,
                },
                ignore_index=True,
            )

    df = pd.concat([df_ul, df_product])
    df = df.sort_values(by="Date")
    df.Date = pd.to_datetime(df.Date)

    fig = px.line(
        df,
        x="Date",
        y="Price",
        color="Name",
        hover_data=["Close"],
        color_discrete_sequence=[
            "#007685",
            "#3592A2",
            "#57B0BF",
            "#77CEDE",
            "#96EDFD",
        ],
    )

    margin = margin_bid(cfin, start_date)

    if not margin.empty:
        fig2 = px.line(
            margin,
            x="Date",
            y="margin_bid",
            color_discrete_sequence=["#d75c1d"],
        )
        fig2.update_traces(
            yaxis="y2",
            legendgroup="Margin",
            name="Margin",
            showlegend=True,
        )

        subfig = make_subplots(specs=[[{"secondary_y": True}]])
        subfig.add_traces(fig.data + fig2.data)

    else:
        subfig = fig

    for x in subfig["data"]:

        # Set the data as percentages if not a Margin
        if x["name"] != "Margin":
            x["hovertemplate"] = "%{y:,.2%}" + "<br>Close: %{customdata[0]:.2f}"
        else:
            x["hovertemplate"] = "%{y:,.2f}%"

        if not df_product.empty:
            if x["legendgroup"] != df_product["Name"].iloc[0]:
                x["visible"] = "legendonly"
            else:
                x["line"]["color"] = "#004553"
        else:
            x["visible"] = "legendonly"

    return subfig["data"]


@timeit
def graph_structured_product(data):

    product = {data["instrumentId"]: data.get("issuePrice")}
    underlyings = {
        x["technicalCfin"]: x["initRefValue"] / x["weight"] for x in data["underlyings"]
    }

    start_date = api_date_to_string(data["initialFixingDate"])

    df_ul = histo_prices(list(underlyings.keys()), start_date=start_date)
    df_product = histo_prices(list(product.keys()), start_date=start_date)

    if df_ul.empty and df_product.empty:
        return

    if not df_ul.empty:
        df_ul["Price"] = df_ul.apply(
            lambda x: x["Close"] / underlyings[x["Cfin"]] * 100, axis=1
        )

    if not df_product.empty and not df_product[["Bid"]].isna().all().bool():
        df_product["Price"] = df_product.Close

    # Add first point of 100 if no initial price for autocall
    # Check if product is not a swap
    if not data["swap"]:
        if not df_product.empty and df_product[df_product["Date"] == start_date].empty:
            df_product = df_product.append(
                {
                    "Cfin": data["instrumentId"],
                    "Date": start_date,
                    "Name": df_product["Name"].iloc[0],
                    "Price": 100,
                },
                ignore_index=True,
            )

    df = pd.concat([df_ul, df_product])
    df = df.sort_values(by="Date")
    df.Date = pd.to_datetime(df.Date)

    fig = px.line(
        df,
        x="Date",
        y="Price",
        color="Name",
        hover_data="Close",
        color_discrete_sequence=[
            "#007685",
            "#3592A2",
            "#57B0BF",
            "#77CEDE",
            "#96EDFD",
        ],
    )

    margin = margin_bid(data["instrumentId"], start_date)

    if not margin.empty:
        fig2 = px.line(
            margin,
            x="Date",
            y="margin_bid",
            color_discrete_sequence=["#d75c1d"],
        )
        fig2.update_traces(
            yaxis="y2",
            legendgroup="Margin",
            name="Margin",
            showlegend=True,
        )

        subfig = make_subplots(specs=[[{"secondary_y": True}]])
        subfig.add_traces(fig.data + fig2.data)

    else:
        subfig = fig

    subfig.update_layout(
        legend=dict(
            title="",
            orientation="h",
            y=1.2,
        ),
        xaxis=dict(
            title="<b>Date</b>",
            showgrid=False,
            showspikes=True,
            spikecolor="rgb(153,174,188)",
            spikethickness=1,
            spikedash="solid",
        ),
        yaxis=dict(title="<b>Bid</b> Levels", automargin=True),
        yaxis2=dict(title="<b>Bid</b> Margin", automargin=True),
        hovermode="x",
        template="plotly_white",
        margin=dict(l=0, r=0, b=0, t=0, pad=0),
    )

    for x in subfig["data"]:
        x["hovertemplate"] = "%{y:.2f}%" + "<br>Close: %{customdata[0]:.2f}"
        if not df_product.empty:
            if x["legendgroup"] != df_product["Name"].iloc[0]:
                x["visible"] = "legendonly"
            else:
                x["line"]["color"] = "#004553"
        else:
            x["visible"] = "legendonly"

    config = {
        "displaylogo": False,
        "displayModeBar": False,
    }

    return dcc.Graph(figure=subfig, config=config)


@timeit
def graph_common_product(data):

    cfin = data.get("cfin")

    # Check if alien 14 exists
    cfin_contrib = Alien.query.filter(Alien.alsjac == cfin, Alien.altype == 14).first()
    if cfin_contrib:
        cfin = cfin_contrib.alcfin

    df = histo_prices(cfin)

    if df.empty:
        return None

    df = df.sort_values(by="Date")
    df.Date = pd.to_datetime(df.Date)
    df.Name = "Certificate"

    # Check if Alien 56 exist for Nav
    cfin_index = sql.alien(data.get("cfin")).get(56)
    if cfin_index:
        df_index = histo_prices(cfin_index[0])
    else:
        df_index = pd.DataFrame()

    fig = px.line(
        df,
        x="Date",
        y="Close",
        color="Name",
        color_discrete_sequence=[
            "#007685",
            "#3592A2",
            "#57B0BF",
            "#77CEDE",
            "#96EDFD",
        ],
    )

    if not df_index.empty:
        df_index.Date = pd.to_datetime(df_index.Date)
        df_index.Name = "Index"
        df_index = df_index[df_index.Date >= df.Date[0]]
        df_custom_data = pd.DataFrame(df_index.Close)

        selection_modecot_ratio = round(df.Close.iloc[0] / df_index.Close.iloc[0])
        if selection_modecot_ratio != 1:
            df_index.Close = (
                df_index.Close
                / Emission.query.filter_by(emcfin=cfin).first().emnominal
                * 100
            )

        fig.add_trace(
            go.Scatter(
                x=df_index.Date,
                y=df_index.Close,
                name="Index",
                line=dict(color="#16a085"),
                customdata=df_custom_data,
            ),
        )

    # Create sub fig here 47398285
    subfig = make_subplots(specs=[[{"secondary_y": True}]])

    # Add Events to graph if any
    dff = sql_amc.cash_and_dividends_certif(data.get("cfin"))

    if not dff.empty:
        dff.rename(columns={"trade_date": "Date"}, inplace=True)
        dff.Date = pd.to_datetime(dff.Date)
        dff = dff.sort_values(by="Date")

        # considering from client point of view
        dff.replace(
            ["cash in", "cash out", "div"],
            ["Buy Order", "Sell Order", "Dividend"],
            inplace=True,
        )

        dff_merged = df.merge(dff, on="Date")

        # filter
        list_columns = ["ccy", "quantity", "category", "amount", "price"]

        # Add Buy order
        x_buy_order = dff_merged[dff_merged.category == "Buy Order"].Date
        y_buy_order = dff_merged[dff_merged.category == "Buy Order"].Close
        df_buy_order_info = dff_merged[dff_merged.category == "Buy Order"][list_columns]
        df_buy_order_info["price"] = df_buy_order_info["price"] * 100
        df_buy_order_info[["quantity", "amount"]] = df_buy_order_info[
            ["quantity", "amount"]
        ].abs()
        fig.add_trace(
            go.Scatter(
                x=x_buy_order,
                y=y_buy_order,
                marker=dict(
                    color="#27ae60",
                    size=10,
                    symbol="circle",
                    line_color="#27ae60",
                    line_width=1,
                ),
                mode="markers",
                name="Buy Order",
                customdata=df_buy_order_info,
                # hoverlabel=dict(bgcolor="rgba(39, 174, 96,0.50)"),
            ),
        )

        # Add Sell order
        x_sell_order = dff_merged[dff_merged.category == "Sell Order"].Date
        y_sell_order = dff_merged[dff_merged.category == "Sell Order"].Close
        df_sell_order_info = dff_merged[dff_merged.category == "Sell Order"][
            list_columns
        ]
        df_sell_order_info["price"] = df_sell_order_info["price"] * 100
        df_sell_order_info[["quantity", "amount"]] = df_sell_order_info[
            ["quantity", "amount"]
        ].abs()
        fig.add_trace(
            go.Scatter(
                x=x_sell_order,
                y=y_sell_order,
                marker=dict(
                    color="#c0392b",
                    size=10,
                    symbol="circle",
                    line_color="#c0392b",
                    line_width=1,
                ),
                mode="markers",
                name="Sell Order",
                customdata=df_sell_order_info,
                # hoverlabel=dict(bgcolor="rgba(192, 57, 43,0.50)"),
            ),
        )
        # Add Div
        x_div = dff_merged[dff_merged.category == "Dividend"].Date
        y_div = dff_merged[dff_merged.category == "Dividend"].Close
        df_div_info = dff_merged[dff_merged.category == "Dividend"][list_columns]
        df_div_info[["quantity", "amount"]] = df_div_info[["quantity", "amount"]].abs()
        fig.add_trace(
            go.Scatter(
                x=x_div,
                y=y_div,
                marker=dict(
                    color="#2980b9",
                    size=10,
                    symbol="triangle-down",
                    line_color="#2980b9",
                    line_width=1,
                ),
                mode="markers",
                name="Dividend",
                customdata=df_div_info,
                # hoverlabel=dict(bgcolor="rgba(41, 128, 185,0.50)"),
            ),
        )

    margin = margin_bid(cfin)

    if not margin.empty:
        fig2 = px.line(
            margin,
            x="Date",
            y="margin_bid",
            color_discrete_sequence=["#d75c1d"],
        )
        fig2.update_traces(
            yaxis="y2",
            legendgroup="Margin",
            name="Margin",
            showlegend=True,
        )
        subfig.add_traces(fig.data + fig2.data)
    else:
        subfig.add_traces(fig.data)

    subfig.update_layout(
        legend=dict(
            title="",
            orientation="h",
            y=1.2,
        ),
        xaxis=dict(
            title="<b>Date</b>",
            showgrid=False,
            showspikes=True,
            spikecolor="rgb(153,174,188)",
            spikethickness=1,
            spikedash="solid",
        ),
        yaxis=dict(title="<b>Bid</b> Levels", automargin=True),
        yaxis2=dict(title="<b>Bid</b> Margin", automargin=True),
        hovermode="x unified",  # "x"
        template="plotly_white",
        hoverlabel=dict(font_family="Roboto", bordercolor="white"),
        hoverdistance=1,
        margin=dict(l=0, r=0, b=0, t=0, pad=0),
    )

    config = {
        "displaylogo": False,
        "displayModeBar": False,
    }

    for x in subfig["data"]:

        # Set the data as percentages if not a Margin
        if x["name"] == "Certificate":
            x["hovertemplate"] = "%{y:,.2f}"

        elif x["name"] == "Margin":
            x["hovertemplate"] = "%{y:,.2f}%"
            x["visible"] = "legendonly"

        elif x["name"] == "Dividend":
            x["hovertemplate"] = (
                "<b>%{customdata[2]}</b><br>"
                "Trade Date: %{x}<br>"
                "Cash: %{customdata[0]} %{customdata[3]:,.2r} <extra></extra>"
            )

        elif x["name"] == "Buy Order":
            x["hovertemplate"] = (
                "<b>%{customdata[2]}</b> <br>"
                "Trade Date: %{x}<br>"
                "Units: %{customdata[1]:,.2r}, Price: %{customdata[4]:,.2f}<br>"
                "Cash: %{customdata[0]} %{customdata[3]:,.2r} <extra></extra>"
            )

        elif x["name"] == "Sell Order":
            x["hovertemplate"] = (
                "<b>%{customdata[2]}</b> <br>"
                "Trade Date: %{x}<br>"
                "Units: %{customdata[1]:,.2r}, Price: %{customdata[4]:,.2f}<br>"
                "Cash: %{customdata[0]} %{customdata[3]:,.2r} <extra></extra>"
            )

        else:
            x["hovertemplate"] = "%{customdata[0]:,.6r} "
            x["visible"] = "legendonly"

    return dcc.Graph(figure=subfig, config=config)


def basis_graph_backtest():

    fig = make_subplots()

    fig.update_layout(
        legend=dict(title="", orientation="h", y=1.2),
        font=dict(size=15),
        xaxis=dict(
            # title="<b>Date</b>",
            title=None,
            showgrid=False,
            showspikes=True,
            spikecolor="rgb(153,174,188)",
            spikethickness=1,
            spikedash="solid",
        ),
        yaxis=dict(
            title="<b>Close</b> Levels", automargin=True, ticksuffix=" %", side="right"
        ),
        hovermode="x",
        template="plotly_white",
        margin=dict(l=0, r=0, b=1, t=0, pad=10),
    )
    config = {
        "displaylogo": False,
        "modeBarButtonsToRemove": [
            "hoverClosestGl2d",
            "hoverClosestPie",
            "toggleHover",
            "resetViews",
            "sendDataToCloud",
            "toggleSpikelines",
            "resetViewMapbox",
            "zoom2d",
            "pan2d",
            "select2d",
            "lasso2d",
            "zoomIn2d",
            "zoomOut2d",
            "autoScale2d",
            "resetScale2d",
            "hoverClosestCartesian",
            "hoverCompareCartesian",
        ],
        "toImageButtonOptions": {
            "format": "jpeg",
            "filename": "graph_histo_barriers",
            "scale": 5,
        },
    }

    return dcc.Graph(
        figure=fig, config=config, id="backtest-graph", className="main-graph"
    )


pre_graph_backtest = basis_graph_backtest()


@timeit
def graph_backtest(
    cfins: list, start_date, end_date, data_colors=None, data_barriers=None, **kwargs
):

    df_ul = histo_prices(cfins, start_date=start_date, end_date=end_date)

    if df_ul.empty:
        return

    # Add levels to rebase prices in %
    init_levels = {}
    for ul in cfins:
        init_levels[ul] = df_ul[df_ul["Cfin"] == int(ul)].iloc[-1]["Close"]

    # Rebase levels to 100% based on end date
    df_ul["Price"] = df_ul.apply(
        lambda x: x["Close"] / init_levels[str(x["Cfin"])] * 100, axis=1
    )

    # Labels corresponding of variables
    labels_barriers = {
        "atk_value": "Autocall Barrier",
        "cpn_value": "Coupon Barrier",
        "prot_value": "Protection Barrier",
    }

    df = df_ul.sort_values(by="Date")
    df.Date = pd.to_datetime(df.Date)

    fig = px.line(
        df,
        x="Date",
        y="Price",
        color="Name",
        hover_data=["Close"],
        color_discrete_sequence=[
            "#007685",
            "#3592A2",
            "#57B0BF",
            "#77CEDE",
            "#96EDFD",
        ],
        render_mode="svg",
    )

    already_used_barriers = []

    if data_colors:

        # Add a line for every barrier
        for x in ["atk_value", "cpn_value", "prot_value"]:

            if x not in already_used_barriers:

                identical_barriers = [
                    y
                    for y in data_barriers
                    if data_barriers[x] == data_barriers[y] and data_barriers[x] != None
                ]
                if len(identical_barriers) > 1:
                    already_used_barriers += identical_barriers
                    level_barrier = data_barriers.get(x)
                    text = " = ".join(
                        [labels_barriers[bar] for bar in identical_barriers]
                    )

                    fig.add_hline(
                        y=int(level_barrier),
                        line_color=data_colors.get(x)
                        if data_colors.get(x) != None
                        else "black",
                        annotation_text=text,
                        annotation_position="bottom left",
                    )
                else:
                    level_barrier = data_barriers.get(x)
                    if level_barrier:

                        fig.add_hline(
                            y=int(level_barrier),
                            line_color=data_colors.get(x)
                            if data_colors.get(x) != None
                            else "black",
                            annotation_text=labels_barriers.get(x),
                            annotation_position="bottom left",
                        )

    fig.update_layout(
        legend=dict(title="", orientation="h", y=1.2),
        font=dict(size=kwargs.get("font_size") if kwargs.get("font_size") else 15),
        xaxis=dict(
            # title="<b>Date</b>",
            title=None,
            showgrid=False,
            showspikes=True,
            spikecolor="rgb(153,174,188)",
            spikethickness=1,
            spikedash="solid",
        ),
        yaxis=dict(
            title="<b>Close</b> Levels", automargin=True, ticksuffix=" %", side="right"
        ),
        hovermode="x",
        template="plotly_white",
        margin=dict(l=0, r=0, b=1, t=0, pad=10),
    )

    for x in fig["data"]:
        x["hovertemplate"] = "%{y:.2f}%" + "<br>Close: %{customdata[0]:.2f}"

        cfin = np.unique(df[df["Name"] == x["name"]]["Cfin"])[0]
        if data_colors and data_colors.get(str(cfin)):
            x["line"]["color"] = data_colors.get(str(cfin))

    ul_text = "_".join(list(set(df["Name"])))

    config = {
        "displaylogo": False,
        "modeBarButtonsToRemove": [
            "hoverClosestGl2d",
            "hoverClosestPie",
            "toggleHover",
            "resetViews",
            "sendDataToCloud",
            "toggleSpikelines",
            "resetViewMapbox",
            "zoom2d",
            "pan2d",
            "select2d",
            "lasso2d",
            "zoomIn2d",
            "zoomOut2d",
            "autoScale2d",
            "resetScale2d",
            "hoverClosestCartesian",
            "hoverCompareCartesian",
        ],
        "toImageButtonOptions": {
            "format": "png",
            "filename": "Graph_hist_" + ul_text,
            "scale": 2.5,
        },
    }

    if kwargs.get("to_image"):
        return fig.to_image(
            format="png",
            width=kwargs.get("width"),
            height=kwargs.get("height"),
            scale=kwargs.get("scale"),
        )

    return dcc.Graph(figure=fig, config=config)


@timeit
def graph_minifut(data):

    try:

        date = api_date_to_string(data["tradeDate"])
        rolls = display_rolls(data)

        if not rolls.empty:

            rolls = rolls.to_dict(orient="records")
            df_histo = pd.DataFrame()

            for x in rolls:
                cfin = x["Cfin"]
                end_date = dt.strptime(x["Maturity"], "%b %d, %Y")

                # Get histo for each roll and add stoploss, strike and payoff
                histo_roll = histo_prices(cfin, date, end_date)
                histo_roll["Stop Loss"] = x["Stop Loss"]
                histo_roll["Strike"] = x["Strike"]
                histo_roll["Payoff"] = (
                    histo_roll["Close"] - histo_roll["Strike"]
                    if data.get("contractType") == "BULL"
                    else histo_roll["Strike"] - histo_roll["Close"]
                )
                df_histo = pd.concat([df_histo, histo_roll])
                date = end_date + timedelta(1)

            # Add Names for graphs groupings
            df_histo["Name"] = "Rolling Futures"
            df_histo["name_sl"] = "StopLoss"
            df_histo["name_payoff"] = "Payoff"

        else:
            all_inst = {
                x["technicalCfin"]: x["initRefValue"] for x in data["underlyings"]
            }

            # Get histo for each roll and add stoploss, strike and payoff
            df_histo = histo_prices([*all_inst], start_date=date)
            df_histo = df_histo[["Date", "Close", "Name"]]
            df_histo["Strike"] = round(
                data.get("strike") / data.get("proportionUnderlying"), 2
            )
            df_histo["Stop Loss"] = round(
                data.get("protectionBarrier") / data.get("proportionUnderlying"), 2
            )
            df_histo["Payoff"] = (
                df_histo["Close"] - df_histo["Strike"]
                if data.get("contractType") == "BULL"
                else df_histo["Strike"] - df_histo["Close"]
            )
            # Add Names for graphs groupings
            df_histo["name_sl"] = "StopLoss"
            df_histo["name_payoff"] = "Payoff"

        if df_histo.empty:
            return

        # Figure of underlying close
        fig = px.line(
            df_histo,
            x="Date",
            y="Close",
            color="Name",
            color_discrete_sequence=[
                "#007685",
                "#3592A2",
                "#57B0BF",
                "#77CEDE",
                "#96EDFD",
            ],
        )

        # Figure of Stop Loss
        fig2 = px.line(
            df_histo,
            x="Date",
            y="Stop Loss",
            color="name_sl",
            color_discrete_sequence=["#d75c1d"],
        )
        fig2.update_traces(
            yaxis="y",
            showlegend=False,
            visible=True,
        )

        # Figure of Payoff
        fig3 = px.line(
            df_histo,
            x="Date",
            y="Payoff",
            color="name_payoff",
            color_discrete_sequence=["#004553"],
        )
        fig3.update_traces(
            yaxis="y2",
            showlegend=True,
            visible=True,
        )
        subfig = make_subplots(specs=[[{"secondary_y": True}]])
        subfig.add_traces(fig.data + fig2.data + fig3.data)

        subfig.update_layout(
            legend=dict(
                title="",
                orientation="h",
                y=1.2,
            ),
            xaxis=dict(
                title="<b>Date</b>",
                showgrid=False,
                showspikes=True,
                spikecolor="rgb(153,174,188)",
                spikethickness=1,
                spikedash="solid",
            ),
            yaxis=dict(title="<b>Bid</b> Levels", automargin=True),
            yaxis2=dict(title="<b>Payoff</b>", automargin=True),
            hovermode="x",
            template="plotly_white",
            margin=dict(l=0, r=0, b=0, t=0, pad=0),
        )

        for x in subfig["data"]:
            x["hovertemplate"] = "%{y:.2f}"

        config = {"displaylogo": False, "displayModeBar": False}

        return dcc.Graph(figure=subfig, config=config)

    except Exception as e:
        msg = "Graph | Issue generating a SP graph"
        app.logger.exception(msg)

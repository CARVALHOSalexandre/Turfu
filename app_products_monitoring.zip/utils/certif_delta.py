from sqlalchemy import or_
from sqlalchemy import Column, Integer, Float, DateTime
from utils.basics import *
from local_db_mgt import db


CFIN_LIST = [
    44514872,
    27575335,
    35278748,
    42756448,
    39217950,
    39217942,
    45096946,
    45888188,
    36479076,
    41881008,
    33153555,
    46399149,
    37563192,
    37563193,
    39217947,
    34799911,
    34799912,
    37630015,
    43625991,
    37997121,
    23383382,
    44352460,
    39295917,
    38121604,
    32433898,
    32433897,
    32433899,
    866790,
    23439035,
    44352454,
    34617976,
    35278753,
    43955589,
    44554606,
    31439171,
    42756447,
    43155971,
    47012175,
    44693575,
    39217936,
    27000588,
    31952524,
    31813332,
    27904855,
    40095952,
    46451407,
    34213255,
    46399132,
    43748788,
    43012527,
    43505440,
    38189838,
    38588742,
    45096799,
    44935045,
    44826351,
    723035,
    799130,
    855248,
    19301447,
    18973221,
    19049096,
    25303824,
    25904288,
    27754915,
    27754763,
    31044362,
    31290570,
    31535830,
    31519442,
    31989138,
    32447477,
    32885127,
    33527285,
    33748708,
    34213241,
    33711169,
    34246031,
    34444470,
    34612536,
    34612717,
    34612898,
    34630743,
    34667013,
    35953388,
    35207200,
    35731566,
    35630713,
    36161059,
    37137756,
    36908977,
    36908983,
    36909143,
    37173088,
    37183962,
    37324147,
    37277821,
    37938296,
    38189822,
    38194289,
    38813643,
    39217956,
    39217961,
    39217971,
    39217978,
    39217985,
    39217990,
    39217994,
    39217998,
    39643027,
    39766648,
    39953463,
    40319455,
    40388886,
    40388906,
    40435183,
    41115915,
    41019384,
    41085245,
    41308389,
    41561942,
    42844138,
    42398252,
    42115078,
    42829366,
    42756643,
    42756706,
    43603462,
    43187110,
    43275673,
    43417458,
    43849026,
    43892160,
    43938498,
    44142051,
    44144049,
    44130188,
    44364500,
    44588110,
    45093724,
    46044525,
    46408616,
    46508337,
    25178837,
    25178838,
    25178891,
    31519441,
    38553617,
    40741888,
    42493635,
]


class CertifDeltas(db.Model):
    __tablename__ = "deltas_certif"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, autoincrement=True)
    cfin = Column(Integer, nullable=True)
    cfin_ie = Column(Integer, nullable=True)
    date = Column(DateTime, nullable=True)
    delta = Column(Float, nullable=True)


def insert_delta(cfin, cfin_ie, date, delta):
    new_line = CertifDeltas(cfin=cfin, cfin_ie=cfin_ie, date=date, delta=delta)
    db.session.add(new_line)
    db.session.commit()


def get_certif_deltas():
    return pd.DataFrame(
        db.session.query(
            CertifDeltas.id,
            CertifDeltas.cfin,
            CertifDeltas.cfin_ie,
            CertifDeltas.date,
            CertifDeltas.delta,
        ).all()
    )


def get_issue_date(cfin):
    from models.base import Emission

    r = Emission.query.filter_by(emcfin=cfin).first()
    return r.emdate if r else None


def get_maturity_date(cfin):
    from models.base import Emission

    r = Emission.query.filter_by(emcfin=cfin).first()
    return r.emmaturite if r else None


def get_ie(cfin):
    from models.base import Alien

    r = Alien.query.filter(
        or_(Alien.alcfin == cfin),
        Alien.altype == 46,
    ).first()
    if r:
        return r.alsjac
    else:
        return cfin


def compute_delta(cfin_ie, date):
    from utils.sql import execute_sql_query

    df = execute_sql_query(
        "delta_certif",
        "exane_risque",
        input_cfin=cfin_ie,
        input_date=date.strftime("%d/%m/%Y"),
    )
    if not df.empty:
        return df["delta_agg"].iloc[0]


def update_deltas():
    from app import server

    with server.app_context():
        server.logger.info(f"Updating certificate's deltas")
        end_date = datetime.datetime.now() - datetime.timedelta(days=1)
        for cfin in CFIN_LIST:
            r = (
                CertifDeltas.query.filter(CertifDeltas.cfin == cfin)
                .order_by(CertifDeltas.date.desc())
                .first()
            )
            if r:
                start_date = pd.to_datetime(r.date + datetime.timedelta(days=1))
            else:
                start_date = get_issue_date(cfin)
            if start_date is None or start_date < dt(2021, 1, 1):
                date = dt(2021, 1, 1)
            else:
                date = start_date
            maturity_date = get_maturity_date(cfin)
            if maturity_date and maturity_date < end_date:
                end_date = maturity_date
            cfin_ie = get_ie(cfin)
            while date <= end_date:
                if date.weekday() < 5:
                    delta = compute_delta(cfin_ie, date)
                    print(f"{cfin} - {cfin_ie} - {date} - {delta}")
                    insert_delta(cfin, cfin_ie, date, delta)
                date += datetime.timedelta(days=1)

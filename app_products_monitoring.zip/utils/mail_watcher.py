import datetime

from sqlalchemy import Column, Integer, String, DateTime, and_
from utils.basics import *
from app import db, server

# from utils.notifs import send_notif
from utils.api_sg import SGPricer
from utils.api_bnp import BNPPricer
from utils.api_barclays import BarclaysPricer
from emails.mail_reader import SharedAccount
from requests.auth import HTTPBasicAuth

from multipricer.models.base_multipricer import (
    SolveFor,
    PricingResults,
    PricingRequests,
    Frequencies,
)
from local_db_mgt import Issuers
from multipricer.issuers import (
    jp_morgan,
    leonteq,
    morgan_stanley,
    bbva,
    goldman_sachs,
    cacib,
    bnp_mail,
)


class mailRFQ(db.Model):
    __tablename__ = "mail_rfq"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, autoincrement=True)
    object = Column(String, nullable=True)
    author = Column(String, nullable=True)
    tags = Column(String, nullable=True)
    datetime = Column(DateTime, nullable=True)
    last_datetime = Column(DateTime, nullable=True)
    type = Column(String, nullable=True)
    count = Column(Integer, nullable=True)
    body = Column(String, nullable=True)


def get_mails_rfq_db():
    df_requests = pd.DataFrame(
        db.session.query(
            mailRFQ.id,
            mailRFQ.object,
            mailRFQ.author,
            mailRFQ.last_datetime,
            mailRFQ.datetime,
            mailRFQ.tags,
            mailRFQ.type,
            mailRFQ.body,
        )
        .filter(mailRFQ.last_datetime >= dt.today() - timedelta(days=3))
        .all()
    )
    if not df_requests.empty:
        df_requests = df_requests.sort_values(by="last_datetime", ascending=False)
    return df_requests.to_dict(orient="records")


def add_mail_rfq(object, author, tags, datetime, last_datetime, type, count, body):
    new_mail_rfq = mailRFQ(
        object=object,
        author=author,
        tags=tags,
        datetime=datetime,
        last_datetime=last_datetime,
        type=type,
        count=count,
        body=body,
    )
    db.session.add(new_mail_rfq)
    db.session.commit()


def update_mail_rfq(object, tags, last_datetime, type, count, body):
    db.session.query(mailRFQ).filter(mailRFQ.object == object).update(
        {
            "tags": tags,
            "last_datetime": last_datetime,
            "type": type,
            "count": count,
            "body": body,
        }
    )
    db.session.commit()


def untag_mail_rfq(email):
    sa = SharedAccount()
    update_mail_rfq(
        object=email.get("object"),
        tags="",
        last_datetime=pd.to_datetime(email.get("last_datetime")),
        type=email.get("type"),
        count=email.get("count"),
        body=email.get("body"),
    )
    sa.tag_email(email.get("object"), tags="")


def tag_mail_rfq(email, user, body):
    sa = SharedAccount()
    update_mail_rfq(
        object=email.get("object"),
        tags=user,
        last_datetime=pd.to_datetime(email.get("last_datetime")),
        type=email.get("type"),
        count=email.get("count"),
        body=email.get("body"),
    )
    sa.tag_email(email.get("object"), tags=user)
    sa.reply_email(subject=email.get("object"), body=body)


def mail_rfq_monitoring():
    with server.app_context():
        sa = SharedAccount()
        df_requests = sa.sales_requests(dt.today() - timedelta(days=14), dt.today())
        df_requests = df_requests.reset_index()
        df_requests = df_requests.rename(columns={"Type": "type"})
        df_requests = df_requests.sort_values(by="last_datetime", ascending=False)
        data = df_requests.to_dict(orient="records")
        for email in data:
            # IF New RFQ
            df = pd.DataFrame(
                db.session.query(mailRFQ.object)
                .filter_by(object=email.get("subject"))
                .all()
            )
            if df.empty:
                # Add RFQ Email To DataBase
                add_mail_rfq(
                    object=email.get("subject"),
                    author=email.get("author"),
                    tags=email.get("tags"),
                    datetime=pd.to_datetime(email.get("datetime")),
                    last_datetime=pd.to_datetime(email.get("last_datetime")),
                    type=email.get("type"),
                    count=email.get("count"),
                    body=email.get("body"),
                )
            # ELSE Old RFQ
            else:
                # Update RFQ Email To DataBase
                update_mail_rfq(
                    object=email.get("subject"),
                    tags=email.get("tags"),
                    last_datetime=pd.to_datetime(email.get("last_datetime")),
                    type=email.get("type"),
                    count=email.get("count"),
                    body=email.get("body"),
                )


def get_pricing_result(id_request_email, id_issuer, id_solve_for):
    # Connect to Exchange
    sa = SharedAccount()

    # Retrieve Solve For's code
    df = pd.DataFrame(db.session.query(SolveFor.id, SolveFor.code).all())
    solve_for = df[df["id"] == id_solve_for]["code"].values[0]

    # Retrieve Issuer's short_name
    df = pd.DataFrame(db.session.query(Issuers.id, Issuers.short_name).all())
    issuer = df[df["id"] == id_issuer]["short_name"].values[0]

    # Retrieve Frequency Nb Months
    df_freq = pd.DataFrame(
        db.session.query(Frequencies.id, Frequencies.nb_months).all()
    )

    # Get Number of Obsv. per year
    df_bis = pd.DataFrame(
        db.session.query(
            PricingRequests.id_issuer,
            PricingRequests.id_request_email,
            PricingRequests.id_frequency,
        ).all()
    )
    df_bis = df_bis[
        (df_bis["id_issuer"].astype(int) == id_issuer)
        & (df_bis["id_request_email"] == id_request_email)
    ]
    df_bis["nb_per_year"] = df_bis["id_frequency"].apply(
        lambda x: int(12 / int(df_freq[df_freq["id"] == x]["nb_months"].values[0]))
    )
    nb_per_year = df_bis["nb_per_year"].values

    # Retrieve Corresponding Mail
    df_requests = sa.external_issuers(id_request_email, issuer)

    if df_requests is not None:
        # Get Issuer Pricer Format
        pricer = None
        if id_issuer == 2:
            pricer = bbva.MailPricingBBVA()
        if id_issuer == 8:
            pricer = goldman_sachs.MailPricingGS()
        elif id_issuer == 9:
            pricer = jp_morgan.MailPricingJPM()
        elif id_issuer == 10:
            pricer = leonteq.MailPricingLTQ()
        elif id_issuer == 12:
            pricer = morgan_stanley.MailPricingMS()
        elif id_issuer == 4:
            pricer = cacib.MailPricingCACIB()
        elif id_issuer == 3:
            pricer = bnp_mail.MailPricingBNP()

        # Parse Results
        try:
            results, is_error, id_quote = pricer.load_issuer_format(
                df_requests.iloc[0].loc["body"], solve_for, nb_per_year
            )
            timestamp = df_requests.iloc[0].loc["datetime"]
            return results, timestamp, is_error, id_quote
        except Exception as e:
            server.logger.exception(f"Error parsing external requests results | {e}")
            return None, None, False, None

    else:
        return None, None, False, None


def update_pricing_results_db():
    # Retrieve All Empty Results
    df_empty_results = pd.DataFrame(
        db.session.query(
            PricingResults.id_issuer,
            PricingResults.id_quote,
            PricingResults.id_request,
            PricingResults.id_request_email,
            PricingResults.id_solve_for,
            PricingResults.timestamp_sent,
        )
        .filter(PricingResults.result == None)
        .filter(
            PricingResults.timestamp_sent
            <= datetime.datetime.now() - timedelta(minutes=1)
        )
        .all()
    )

    for i in range(0, min(50, len(df_empty_results.index))):
        # If 1H deadline has passed mark error (timeout exception)
        if df_empty_results.iloc[i].loc[
            "timestamp_sent"
        ] < datetime.datetime.now() - timedelta(minutes=60):
            db.session.query(PricingResults).filter(
                PricingResults.id_request == df_empty_results.iloc[i].loc["id_request"]
            ).update(
                {
                    "timestamp_received": datetime.datetime.now(),
                    "result": "Timeout exception",
                    "is_best_result": False,
                    "is_error": True,
                }
            )
            db.session.commit()

        # If issuer has mail pricer
        if df_empty_results.iloc[i].loc["id_issuer"] in [2, 3, 4, 8, 9, 10, 12]:

            # Retrieve Results
            try:
                results, timestamp, is_error, id_quote = get_pricing_result(
                    df_empty_results.iloc[i].loc["id_request_email"],
                    df_empty_results.iloc[i].loc["id_issuer"],
                    df_empty_results.iloc[i].loc["id_solve_for"],
                )
            except Exception as e:
                server.logger.exception(
                    f"Error parsing email request result {df_empty_results.iloc[i].loc['id_request_email']} - {df_empty_results.iloc[i].loc['id_issuer']} | {e}"
                )
                results = None

            if results is not None:

                # Find All Requests for this mail
                df_results_bis = pd.DataFrame(
                    db.session.query(
                        PricingResults.id_issuer,
                        PricingResults.id_quote,
                        PricingResults.id_request,
                        PricingResults.id_request_email,
                        PricingResults.id_solve_for,
                    )
                    .select_from(PricingResults)
                    .filter(
                        PricingResults.id_request_email
                        == df_empty_results.iloc[i].loc["id_request_email"]
                    )
                    .all()
                )

                df_results_bis = df_results_bis[
                    df_results_bis["id_issuer"]
                    == df_empty_results.iloc[i].loc["id_issuer"]
                ]

                # Find & Update All Requests for this mail
                for j in range(0, len(df_results_bis)):
                    db.session.query(PricingResults).filter(
                        PricingResults.id_request
                        == df_results_bis.iloc[j].loc["id_request"]
                    ).update(
                        {
                            "timestamp_received": timestamp,
                            "result": results[j],
                            "is_best_result": False,
                            "is_error": is_error[j],
                            "id_quote": id_quote[j],
                        }
                    )
                    db.session.commit()

        # ELSE Issuer has api pricer
        else:

            df_price_requests = pd.DataFrame(
                db.session.query(
                    PricingRequests.id_frequency,
                    PricingRequests.id_request,
                    PricingRequests.id_solve_for,
                )
                .filter(
                    PricingRequests.id_request
                    == df_empty_results.iloc[i].loc["id_request"]
                )
                .all()
            )

            # Retrieve Solve For's code
            try:
                if not df_price_requests.empty:
                    df = pd.DataFrame(
                        db.session.query(SolveFor.id, SolveFor.code).all()
                    )
                    solve_for = df[
                        df["id"] == df_price_requests.iloc[0].loc["id_solve_for"]
                    ]["code"].values[0]

                    # Retrieve Request Observations Frequency
                    df = pd.DataFrame(
                        db.session.query(Frequencies.id, Frequencies.nb_months).all()
                    )
                    nb_months = df[
                        df["id"] == df_price_requests.iloc[0].loc["id_frequency"]
                    ]["nb_months"].values[0]
                    nb_obs_per_year = 12 / nb_months

                    # If issuer is Barclays
                    if df_empty_results.iloc[i].loc["id_issuer"] == 1:
                        if df_empty_results.iloc[i].loc["id_quote"] is not None:
                            pricer = BarclaysPricer()
                            r = pricer.get(
                                pricer.BASE_URL
                                + f"/quotes?quoteId={df_empty_results.iloc[i].loc['id_quote']}",
                                auth=HTTPBasicAuth(
                                    pricer.client_id, pricer.client_secret
                                ),
                            )

                            if r.status_code == 200:
                                if r.json().get("quoteStatus") == "success":
                                    result = r.json()["solveForValue"]
                                    if solve_for == "Coupon":
                                        result = round(result * nb_obs_per_year, 2)
                                    result = f"{result}%"
                                    timestamp = dt.now()
                                    is_error = False
                                elif r.json().get("quoteStatus") == "fail":
                                    result = r.json().get("errorMessage")
                                    timestamp = dt.now()
                                    is_error = True
                                else:
                                    result = None
                                    timestamp = None
                                    is_error = False

                                db.session.query(PricingResults).filter(
                                    PricingResults.id_request
                                    == df_empty_results.iloc[i].loc["id_request"]
                                ).update(
                                    {
                                        "timestamp_received": timestamp,
                                        "result": result,
                                        "is_best_result": False,
                                        "is_error": is_error,
                                    }
                                )
                                db.session.commit()

                    # # If issuer is BNP
                    # elif df_empty_results.iloc[i].loc["id_issuer"] == 3:
                    #     if df_empty_results.iloc[i].loc["id_quote"] is not None:
                    #         pricer = BNPPricer()
                    #         # Check For Lost Quote
                    #         r = pricer.get(
                    #             pricer.BASE_URL
                    #             + f"contracts/{df_empty_results.iloc[i].loc['id_quote'][0]}"
                    #         )
                    #         if r.status_code == 404:
                    #             db.session.query(PricingResults).filter(
                    #                 PricingResults.id_request
                    #                 == df_empty_results.iloc[i].loc["id_request"]
                    #             ).update(
                    #                 {
                    #                     "timestamp_received": dt.now(),
                    #                     "result": "Error processing quote (lost quote)",
                    #                     "is_error": True,
                    #                 }
                    #             )
                    #             db.session.commit()
                    #
                    #         else:
                    #             # Retrieve Quote Price
                    #             r = pricer.get(
                    #                 pricer.BASE_URL
                    #                 + f"contracts/{df_empty_results.iloc[i].loc['id_quote'][0]}/solvings/{df_empty_results.iloc[i].loc['id_quote'][1]}",
                    #             )
                    #             if r.status_code == 200:

                    # If issuer is SG
                    elif df_empty_results.iloc[i].loc["id_issuer"] == 15:
                        if df_empty_results.iloc[i].loc["id_quote"] is not None:
                            pricer = SGPricer()
                            # Check For Lost Quote
                            r = pricer.get(
                                pricer.BASE_URL
                                + f"quote-request/{df_empty_results.iloc[i].loc['id_quote']}"
                            )
                            if r.status_code == 404:
                                db.session.query(PricingResults).filter(
                                    PricingResults.id_request
                                    == df_empty_results.iloc[i].loc["id_request"]
                                ).update(
                                    {
                                        "timestamp_received": dt.now(),
                                        "result": "Error processing quote",
                                        "is_error": True,
                                    }
                                )
                                db.session.commit()

                            else:
                                # Retrieve Quote Price
                                r = pricer.get(
                                    pricer.BASE_URL
                                    + f"quote/{df_empty_results.iloc[i].loc['id_quote']}"
                                )

                                if r.status_code == 200:
                                    if r.json().get("Status") == "Quoted":
                                        result = round(
                                            r.json()["Data"]["SolveResult"], 2
                                        )
                                        if solve_for == "Coupon":
                                            result = round(result * nb_obs_per_year, 2)
                                        result = f"{result}%"
                                        timestamp = dt.now()
                                        is_error = False
                                    elif (
                                        r.json().get("Status") == "Accepted"
                                        or r.json().get("Data") is None
                                    ):
                                        result = None
                                        timestamp = None
                                        is_error = False
                                    else:
                                        result = (
                                            r.json()
                                            .get("Data")
                                            .get("rejectionMessages")[0]
                                        )
                                        timestamp = dt.now()
                                        is_error = True

                                    db.session.query(PricingResults).filter(
                                        PricingResults.id_request
                                        == df_empty_results.iloc[i].loc["id_request"]
                                    ).update(
                                        {
                                            "timestamp_received": timestamp,
                                            "result": result,
                                            "is_best_result": False,
                                            "is_error": is_error,
                                        }
                                    )
                                    db.session.commit()
            except Exception as e:
                server.logger.exception(
                    f"Error parsing API request result {df_empty_results.iloc[i].loc['id_request_email']} - {df_empty_results.iloc[i].loc['id_issuer']} | {e}"
                )

    # Update Is Best Result (las 1 bday only)
    df_results = pd.DataFrame(
        db.session.query(
            PricingResults.id_issuer,
            PricingResults.id_request,
            PricingResults.id_line,
            PricingResults.id_request_email,
            PricingResults.id_solve_for,
            PricingResults.result,
        )
        .filter(PricingResults.is_error == 0)
        .filter(PricingResults.result is not None)
        .filter(PricingResults.timestamp_received > prev_bday(1))
        .all()
    )
    try:
        if not df_results.empty:
            df_results["solve_for"] = df_results["id_solve_for"].apply(
                lambda x: SolveFor.query.filter(SolveFor.id == x).first().code
            )
            df_results["result"] = df_results["result"].apply(
                lambda x: float(x[0:-1]) if x else x
            )
            all_requests = df_results["id_request_email"].unique()
            for request in all_requests:
                dff = df_results[df_results["id_request_email"] == request]
                lines_array = dff["id_line"].unique()
                for line in lines_array:
                    dff_line = dff[dff["id_line"] == line]
                    dff_line = dff_line.reset_index(drop=True)
                    if dff_line.iloc[0].loc["solve_for"] in ["Coupon", "Upfront"]:
                        best_index = dff_line["result"].idxmax()
                    else:
                        best_index = dff_line["result"].idxmin()
                    for i in range(0, len(dff_line.index)):
                        if i == best_index:
                            db.session.query(PricingResults).filter(
                                PricingResults.id_request
                                == dff_line.iloc[i].loc["id_request"]
                            ).update({"is_best_result": True})
                            db.session.commit()
                        else:
                            db.session.query(PricingResults).filter(
                                PricingResults.id_request
                                == dff_line.iloc[i].loc["id_request"]
                            ).update({"is_best_result": False})
                            db.session.commit()
    except Exception as e:
        server.logger.exception(f"Error setting request is best result | {e}")


if __name__ == "__main__":
    with server.app_context():
        update_pricing_results_db()

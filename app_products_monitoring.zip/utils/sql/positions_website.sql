SELECT DISTINCT
     isin AS "ISIN"
    ,ifcfin AS "Cfin"
    ,alien_contrib.alcfin AS "Cfin Contrib"
    ,alien_otc.alcfin AS "Cfin OTC"
    ,tiers_product.tinom AS "Issuer"
    ,tiers_otc.tinom AS "Issuer OTC"
    ,ric as "RIC"
    ,CASE
        WHEN com_name IS NULL THEN ifnom
        ELSE com_name
	END AS "Name"
    ,CASE
        WHEN prmarche = 919 THEN 'TLX'
        WHEN prmarche = 184 THEN 'SED'
        WHEN prmarche = 218 THEN 'SIX'
        ELSE NULL
     END AS "Market"
    ,emission_product.emdatestrike AS "Strike Date"
	,emission_product.empaiement AS "Issue Date"
	,ctmaturite AS "Maturity Date"
	,dvcodeiso AS "Ccy"
	,emission_product.emnominal AS "Nominal"
	,monom AS "Quote Mode"
	,date_cours AS "Datetime"
	,prix_theorique AS "Theo Price"
	,bid AS "Bid"
	,ask AS "Ask"
    ,typo_category.libelle_typologie AS "Category"
    ,typo_sub_category.libelle_typologie AS "Sub Category"
    ,web_url.hash_ispremium AS "Hash"
    ,CASE
		WHEN icdiffusion = 2
			THEN 'All'
		WHEN icdiffusion = 3
			THEN 'Exane'
		WHEN icdiffusion = 10
			THEN 'All (no price)'
		ELSE 'No'
    END AS "Diffusion"
    FROM  EXANE.instruments
    LEFT JOIN EXANE.emission emission_product ON emission_product.emcfin = ifcfin
    LEFT JOIN EXANE.contrats ON ctcfin = ifcfin
	LEFT JOIN EXANE.produits ON prcfin = ifcfin
    LEFT JOIN EXAWEB.vue_urlhash web_url ON web_url.cfin = ifcfin
    LEFT JOIN EXANE.modecot ON mocode = prmodecot
	LEFT JOIN EXANE.devise ON dvcfin = prdev
	LEFT JOIN EXANE.typeinstrument ON EXANE.typeinstrument.tycode = iftype
    LEFT JOIN exane.instrumentcomplement ON iccfin = ifcfin
    LEFT JOIN (SELECT cfcfin cfin_com_name, cfdesc com_name, MAX(cfhorodate) date_com_name
                FROM EXANE.codes
                WHERE cfsource = 101
                GROUP BY cfcfin, cfdesc
            )ON cfin_com_name = ifcfin
    LEFT JOIN (SELECT cfcfin cfinISIN, cfcode isin, MAX(cfhorodate) date_isin
                FROM EXANE.codes
                WHERE cfsource = 6
                GROUP BY cfcfin, cfcode
            ) ON cfinISIN = ifcfin
    LEFT JOIN (SELECT cfcfin cfinRIC, cfcode ric, MAX(cfhorodate) date_ric
                FROM EXANE.codes
                WHERE cfsource = 334
                GROUP BY cfcfin, cfcode
            ) ON cfinRIC = ifcfin
	LEFT JOIN EXANE.alien alien_contrib ON alien_contrib.alsjac = ifcfin AND alien_contrib.altype = 14
	LEFT JOIN EXANE.alien alien_contrib_inverse ON alien_contrib_inverse.alcfin = ifcfin AND alien_contrib_inverse.altype = 14
	LEFT JOIN EXANE.alien alien_otc ON alien_otc.alsjac = ifcfin AND alien_otc.altype = 53
    LEFT JOIN EXANE.contratotcs ON cocfin = alien_otc.alcfin
	LEFT JOIN EXANE.tiers tiers_product ON tiers_product.ticode = emission_product.emissuer
	LEFT JOIN EXANE.tiers tiers_otc ON tiers_otc.ticode = coreceveur
    LEFT JOIN EXANE.nolast last_contrib ON last_contrib.lacfin = alien_contrib.alcfin
    LEFT JOIN EXANE.nolast last_cfin ON last_cfin.lacfin = ifcfin
    LEFT JOIN exane.v_typologie typo_category ON typo_category.code_valeur_typee = ifcfin
        AND typo_category.code_famille_typologie = 5
    LEFT JOIN exane.v_typologie typo_sub_category ON typo_sub_category.code_valeur_typee = ifcfin
        AND typo_sub_category.code_famille_typologie = 70
    LEFT JOIN
    (
        SELECT cfin as cfin_marges, bid, ask, prix_theorique, date_cours
        FROM
        (
            SELECT *
            FROM CRS.v_cfin_marges marges
        )
    ) ON cfin_marges = (
		CASE
			WHEN alien_contrib.alcfin IS NOT NULL
				THEN alien_contrib.alcfin
			ELSE ifcfin
			END
		)
	AND date_cours = (
		CASE
			WHEN alien_contrib.alcfin IS NOT NULL
				THEN last_contrib.ladate
			ELSE last_cfin.ladate
			END
		)
    WHERE ifcontrat = 1
        AND iftype NOT IN (31)
        AND alien_contrib_inverse.alcfin IS NULL
        AND (tyfamille NOT IN (1, 2, 6, 13) OR (iftypofo > 35000 AND iftypofo < 36000))
        AND ifstatut NOT IN (7, 22)
        AND prmarche in (184, 218, 919)

SELECT DISTINCT cfcfin "Cfin", sonom "Type", cfcode "Code"
FROM exane.codes
JOIN exane.source on socode = cfsource
WHERE
  cfcfin in (list_cfins)
  AND socode IN (3, 6, 11, 15)
  AND cfcode not like '%EU'
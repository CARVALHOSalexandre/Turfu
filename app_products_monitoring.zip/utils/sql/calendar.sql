SELECT to_date(obs_date, 'J') AS "Observation Date"
	,to_date(pay_date, 'J') AS "Payment Date"
	,round(paid_cpns, 2) AS "Paid Cpns"
	,round(proba_atk, 5) AS "Proba Autocall"
FROM (
	SELECT regexp_replace(sicle, '[^A-Za-z]', '') AS name_field
		,regexp_replace(sicle, '[^0-9]', '') AS id_date
		,sivaleur
	FROM risque.rkscriptindicateurs
	WHERE sicfin = cfin_product
		AND (
			sicle LIKE 'CV_CouponDeja%'
			OR sicle LIKE 'TV_probaRappel%'
			OR sicle LIKE 'CV_DateConstat%'
			OR sicle LIKE '#PAY%'
			)
		AND sidate = (
			SELECT max(sidate)
			FROM risque.rkscriptindicateurs
			WHERE sicfin = cfin_product
			)
	)
pivot(sum(sivaleur) FOR (name_field) IN (
			'CVDateConstat' AS obs_date
			,'PAY' AS pay_date
			,'CVCouponDejaPaye' AS paid_cpns
			,'TVprobaRappel' AS proba_atk
			))
WHERE obs_date IS NOT NULL
ORDER BY obs_date

SELECT DISTINCT xdfeffectivedate as "Date"
	,xdfcfinudl as "Cfin"
	,codes_isin.cfcode as "ISIN"
	,codes_ticker.cfcode as "Ticker"
	,ifnom as "Name"
	,dvcodeiso as "Ccy"
	,xdfamount as "Amount"
	,xdfquantity as "Quantity"
	,xdfdirtyprice as "Price"
	,xtflibelle as "Type"
	,xdfcomment as "Comment"
FROM derives.idxordersandfees
JOIN derives.idxtypeordersandfees ON xtfcode = xdfoperationtype
JOIN exane.instruments ON xdfcfinudl = ifcfin
LEFT JOIN exane.codes codes_isin ON codes_isin.cfcfin = ifcfin
	AND codes_isin.cfsource = 6
LEFT JOIN exane.codes codes_ticker ON codes_ticker.cfcfin = ifcfin
	AND codes_ticker.cfsource = 11
	AND codes_ticker.cfcode NOT LIKE '%EU'
JOIN exane.devise ON dvcfin = xdfcurrency
WHERE
    xtfcode != 3 AND
	xdfcfinindex = index_cfin
	AND xdfeffectivedate >= to_date('start_date', 'dd/mm/yyyy')
	AND xdfeffectivedate <= to_date('end_date', 'dd/mm/yyyy')
ORDER BY xdfeffectivedate DESC
	,xdfamount
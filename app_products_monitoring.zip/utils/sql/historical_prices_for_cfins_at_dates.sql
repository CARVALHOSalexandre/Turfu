SELECT DISTINCT hodate "Date", hocfin "Cfin", hoclose "Close"
FROM EXANE.historiques
WHERE
    hocfin IN (list_cfins)
    AND hodate IN (list_dates)
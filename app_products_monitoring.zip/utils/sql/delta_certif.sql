WITH PRICING AS
  (SELECT *
   FROM
     (SELECT prdate ,
             prprofil ,
             prparent ,
             ifnom ,
             praxe1 ,
             prindicateur ,
             prvaleur ,
             emnominal
      FROM risque.rkpricing
      INNER JOIN risque.rkpricingresultats ON risque.rkpricingresultats.prnumero = risque.rkpricing.prnumero
      INNER JOIN instruments ON ifcfin = prparent
      INNER JOIN emission ON emcfin = prparent
      WHERE prflag <> 3
        AND prmode = 0
        AND prprofil IN (93 ,
                         63 ,
                         142 ,
                         99 ,
                         246 ,
                         247 ,
                         249 ,
                         347)
        AND prindicateur IN (3, 37)
        AND prparent = prcfin
        AND prparent NOT IN
          (SELECT COCFIN
           FROM contratotcs,
                instruments
           WHERE COPAYEUR = CORECEVEUR
             AND copayeur = 74934
             AND ifcfin = cocfin )
        AND prparent <> praxe1
        AND prdate = to_date('input_date', 'dd/mm/yyyy')
        AND praxe1 = input_cfin
        AND substr(ifnom, 1, 4) <> 'Swap'
        AND substr(ifnom, 1, 4) <> 'swap'
      ORDER BY prdate ,
               prparent ,
               praxe1) pivot(avg(prvaleur)
                             FOR prindicateur IN (3 AS DELTA , 37 AS SPOT))) ,
     POSE AS
  (SELECT PRICING.* ,
          pose ,
          podev ,
          ifcfin
   FROM instruments
   INNER JOIN risque.rkdefbook ON dfcfin = ifcfin
   INNER JOIN risque.rkdefbigbook ON dbbook = dfbook
   INNER JOIN PRICING ON PRICING.PRPARENT = instruments.ifcfin
   AND PRICING.PRPROFIL = dbbigbook
   INNER JOIN
     (SELECT podate ,
             pobook ,
             pocfin ,
             podev ,
             sum(popos) * max(decode(poquotite, NULL, 1, poquotite)) pose
      FROM risque.rkposition
      WHERE podate =
          (SELECT max(prdate)
           FROM Pricing)
      GROUP BY podate ,
               pobook ,
               pocfin ,
               podev) ON pobook = dfbook
   AND dfcfin = pocfin
   ORDER BY ifcfin)
SELECT -sum(pose*Delta) as delta_agg
FROM POSE
INNER JOIN exane.devise ON exane.devise.dvcfin = POSE.podev
WITH
HISTORICAL AS(
    SELECT
        hocfin,
        hodate,
        hoclose
            FROM exane.historiques
                JOIN exane.emission ON emcfin = hocfin
                JOIN exane.instruments ON ifcfin = hocfin
                JOIN exane.instrumentcomplement ON iccfin = hocfin
                WHERE emissuer in (144201, 144202, 144191) AND icetatdevie = 1 AND ifstatut NOT IN (7, 22)
),
LAST_CLOSE_DATE AS(
    SELECT hocfin as hocfin_lcd, MAX(hodate) as last_close_date
        FROM HISTORICAL
        GROUP BY hocfin
),
LAST_CLOSE AS(
    SELECT hocfin as hocfin_lc, hoclose as last_close
        FROM LAST_CLOSE_DATE
        LEFT JOIN HISTORICAL on hocfin = hocfin_lcd and hodate = last_close_date
),
FIRST_CLOSE_DATE AS(
    SELECT hocfin as hocfin_fcd, MIN(hodate) as first_close_date
        FROM HISTORICAL
        GROUP BY hocfin
),
RETURNS AS(
            SELECT
                hocfin AS return_cfin
                ,hodate AS return_hodate
                ,last_close_date AS return_last_close_date
                ,first_close_date as return_first_close_date
                ,hoclose
                ,CASE
                    WHEN (lag(hoclose, 1) OVER (PARTITION BY hocfin ORDER BY hodate ASC)) = 0 THEN NULL
                    ELSE (hoclose / lag(hoclose, 1) OVER (PARTITION BY hocfin ORDER BY hodate ASC)) - 1
                    END AS daily_return
                FROM exane.historiques
                JOIN LAST_CLOSE_DATE ON hocfin_lcd = hocfin
                JOIN FIRST_CLOSE_DATE ON hocfin_fcd = hocfin
                JOIN exane.emission ON emcfin = hocfin
                JOIN exane.instruments ON ifcfin = hocfin
                JOIN exane.instrumentcomplement ON iccfin = hocfin
                WHERE emissuer IN (144201, 144202, 144191) AND icetatdevie = 1  AND ifstatut NOT IN (7, 22)
)
SELECT emcfin AS "Cfin"
    ,alcfin "Parent"
	,codes_isin.cfcode AS "ISIN"
	,codes_ticker.cfcode AS "Ticker"
	,ifnom AS "Name"
	,dvcodeiso AS "Ccy"
	,first_close_date AS "First Close Date"
	,last_close_date AS "Last Close Date"
	,last_close AS "Last Close"
	,ROUND((last_close - histo_1M) / histo_1M, 4) AS "Perf. 1M"
	,ROUND((last_close - histo_YTD) / histo_YTD, 4) AS "Perf. YTD"
	,ROUND((last_close - histo_1Y) / histo_1Y, 4) AS "Perf. 1Y"
	,ROUND((last_close - histo_3Y) / histo_3Y, 4) AS "Perf. 3Y"
	,ROUND((last_close - histo_5Y) / histo_5Y, 4) AS "Perf. 5Y"
	,ROUND(histo_std_1M, 4) AS "Vol. 1M"
	,ROUND(histo_std_YTD, 4) AS "Vol. YTD"
	,ROUND(histo_std_1Y, 4) AS "Vol. 1Y"
	,ROUND(histo_std_3Y, 4) AS "Vol. 3Y"
	,ROUND(histo_std_5Y, 4) AS "Vol. 5Y"
	,ROUND((histo_avg_1Y - 0.00) / histo_std_1Y, 2) AS "Sharpe 1Y"
	,ROUND((histo_avg_3Y - 0.00) / histo_std_3Y, 2) AS "Sharpe 3Y"
	,ROUND((histo_avg_5Y - 0.00) / histo_std_5Y, 2) AS "Sharpe 5Y"
	,typo_asset_class.libelle_typologie AS "Asset Class"
    ,typo_return.libelle_typologie as "Return"
    ,typo_esg.libelle_typologie as "ESG"
    ,typo_geography.libelle_typologie as "Geography"
    ,typo_hedge.libelle_typologie as "Hedge"
    ,typo_factor.libelle_typologie as "Factor"
    ,typo_other.libelle_typologie as "Other"
	,tinom AS "Category"
    ,web_url.hash_exaneindex AS "Hash"
	,CASE
		WHEN icdiffusion = 2
			THEN 'All'
		WHEN icdiffusion = 3
			THEN 'Exane'
		WHEN icdiffusion = 10
			THEN 'All (no price)'
		ELSE 'No'
		END AS "Diffusion"
FROM exane.emission
LEFT JOIN exane.instruments ON ifcfin = emcfin
LEFT JOIN EXAWEB.vue_urlhash web_url ON web_url.cfin = ifcfin
LEFT JOIN exane.codes codes_isin ON codes_isin.cfcfin = emcfin
	AND codes_isin.cfsource = 6
LEFT JOIN exane.codes codes_ticker ON codes_ticker.cfcfin = emcfin
	AND codes_ticker.cfsource = 11
LEFT JOIN exane.produits ON prcfin = emcfin
LEFT JOIN exane.devise ON dvcfin = prdev
JOIN LAST_CLOSE ON hocfin_lc = emcfin
JOIN LAST_CLOSE_DATE ON hocfin_lcd = emcfin
JOIN FIRST_CLOSE_DATE ON hocfin_fcd = emcfin
LEFT JOIN exane.contrats ON ctcfin = emcfin
LEFT JOIN exane.instrumentcomplement ON iccfin = emcfin
LEFT JOIN exane.tiers ON ticode = emissuer
LEFT JOIN exane.v_typologie typo_return ON typo_return.code_valeur_typee = emcfin
        AND typo_return.code_famille_typologie = 88 AND typo_return.flag_typologie != 3
LEFT JOIN exane.v_typologie typo_esg ON typo_esg.code_valeur_typee = emcfin
        AND typo_esg.code_famille_typologie = 89 AND typo_esg.flag_typologie != 3
LEFT JOIN exane.v_typologie typo_geography ON typo_geography.code_valeur_typee = emcfin
        AND typo_geography.code_famille_typologie = 90 AND typo_geography.flag_typologie != 3
LEFT JOIN exane.v_typologie typo_hedge ON typo_hedge.code_valeur_typee = emcfin
        AND typo_hedge.code_famille_typologie = 91 AND typo_hedge.flag_typologie != 3
LEFT JOIN exane.v_typologie typo_factor ON typo_factor.code_valeur_typee = emcfin
        AND typo_factor.code_famille_typologie = 92 AND typo_factor.flag_typologie != 3
LEFT JOIN exane.v_typologie typo_other ON typo_other.code_valeur_typee = emcfin
        AND typo_other.code_famille_typologie = 93 AND typo_other.flag_typologie != 3
LEFT JOIN exane.v_typologie typo_asset_class ON typo_asset_class.code_valeur_typee = emcfin
        AND typo_asset_class.code_famille_typologie = 64 AND typo_asset_class.flag_typologie != 3
LEFT JOIN (
	SELECT cfin_1M
		,hoclose AS histo_1M
	FROM (
		SELECT hocfin AS cfin_1M
			,MAX(hodate) AS max_date
		FROM HISTORICAL histo_1Mb
		LEFT JOIN exane.emission ON emcfin = histo_1Mb.hocfin
		LEFT JOIN LAST_CLOSE_DATE ON hocfin_lcd = histo_1Mb.hocfin
		WHERE histo_1Mb.hocfin = emcfin
			AND histo_1Mb.hodate <= ADD_MONTHS(last_close_date, - 1)
		GROUP BY histo_1Mb.hocfin
		)
	LEFT JOIN HISTORICAL ON (
			hocfin = cfin_1M
			AND hodate = max_date
			)
	) ON cfin_1M = emcfin
LEFT JOIN (
	SELECT cfin_1Y
		,hoclose AS histo_1Y
	FROM (
		SELECT hocfin AS cfin_1Y
			,MAX(hodate) AS max_date
		FROM HISTORICAL histo_1Yb
		LEFT JOIN exane.emission ON emcfin = histo_1Yb.hocfin
		LEFT JOIN LAST_CLOSE_DATE ON hocfin_lcd = histo_1Yb.hocfin
		WHERE histo_1Yb.hocfin = emcfin
			AND histo_1Yb.hodate <= ADD_MONTHS(last_close_date, - 1 * 12)
		GROUP BY histo_1Yb.hocfin
		)
	LEFT JOIN HISTORICAL ON (
			hocfin = cfin_1Y
			AND hodate = max_date
			)
	) ON cfin_1Y = emcfin
LEFT JOIN (
	SELECT cfin_3Y
		,hoclose AS histo_3Y
	FROM (
		SELECT hocfin AS cfin_3Y
			,MAX(hodate) AS max_date
		FROM HISTORICAL histo_3Yb
		LEFT JOIN exane.emission ON emcfin = histo_3Yb.hocfin
		LEFT JOIN LAST_CLOSE_DATE ON hocfin_lcd = histo_3Yb.hocfin
		WHERE histo_3Yb.hocfin = emcfin
			AND histo_3Yb.hodate <= ADD_MONTHS(last_close_date, - 3 * 12)
		GROUP BY histo_3Yb.hocfin
		)
	LEFT JOIN HISTORICAL ON (
			hocfin = cfin_3Y
			AND hodate = max_date
			)
	) ON cfin_3Y = emcfin
LEFT JOIN (
	SELECT cfin_5Y
		,hoclose AS histo_5Y
	FROM (
		SELECT hocfin AS cfin_5Y
			,MAX(hodate) AS max_date
		FROM HISTORICAL histo_5Yb
		LEFT JOIN exane.emission ON emcfin = histo_5Yb.hocfin
		LEFT JOIN LAST_CLOSE_DATE ON hocfin_lcd = histo_5Yb.hocfin
		WHERE histo_5Yb.hocfin = emcfin
			AND histo_5Yb.hodate <= ADD_MONTHS(last_close_date, - 5 * 12)
		GROUP BY histo_5Yb.hocfin
		)
	LEFT JOIN HISTORICAL ON (
			hocfin = cfin_5Y
			AND hodate = max_date
			)
	) ON cfin_5Y = emcfin
LEFT JOIN (
	SELECT cfin_YTD
		,hoclose AS histo_YTD
	FROM (
		SELECT hocfin AS cfin_YTD
			,MAX(hodate) AS max_date
		FROM HISTORICAL histo_YTD
		LEFT JOIN exane.emission ON emcfin = histo_YTD.hocfin
		LEFT JOIN LAST_CLOSE_DATE ON hocfin_lcd = histo_YTD.hocfin
		WHERE histo_YTD.hocfin = emcfin
			AND histo_YTD.hodate >= TRUNC(last_close_date, 'yyyy') - INTERVAL '1' YEAR
			AND histo_YTD.hodate < TRUNC(last_close_date, 'yyyy')
		GROUP BY histo_YTD.hocfin
		)
	LEFT JOIN HISTORICAL ON (
			hocfin = cfin_YTD
			AND hodate = max_date
			)
	) ON cfin_YTD = emcfin
LEFT JOIN (
	SELECT return_cfin AS cfin_histo_std_1M
		,STDDEV_SAMP(daily_return) * SQRT(252) AS histo_std_1M
		,AVG(daily_return) * 252 AS histo_avg_1M
	FROM
	RETURNS
	WHERE return_hodate >= ADD_MONTHS(return_last_close_date, - 1) AND return_first_close_date <= ADD_MONTHS(return_last_close_date, - 1)
	GROUP BY return_cfin
	) ON cfin_histo_std_1M = emcfin
LEFT JOIN (
	SELECT return_cfin AS cfin_histo_std_YTD
		,STDDEV_SAMP(daily_return) * SQRT(252) AS histo_std_YTD
		,AVG(daily_return) * 252 AS histo_avg_YTD
	FROM
	RETURNS
	WHERE TRUNC(return_hodate, 'yyyy') = TRUNC(return_last_close_date, 'yyyy') AND TRUNC(return_first_close_date, 'yyyy') < TRUNC(return_last_close_date, 'yyyy')
	GROUP BY return_cfin
	) ON cfin_histo_std_YTD = emcfin
LEFT JOIN (
	SELECT return_cfin AS cfin_histo_std_1Y
		,STDDEV_SAMP(daily_return) * SQRT(252) AS histo_std_1Y
		,AVG(daily_return) * 252 AS histo_avg_1Y
	FROM
	RETURNS
	WHERE return_hodate >= ADD_MONTHS(return_last_close_date, - 1 * 12) AND return_first_close_date <= ADD_MONTHS(return_last_close_date, - 1 * 12)
	GROUP BY return_cfin
	) ON cfin_histo_std_1Y = emcfin
LEFT JOIN (
	SELECT return_cfin AS cfin_histo_std_3Y
		,STDDEV_SAMP(daily_return) * SQRT(252) AS histo_std_3Y
		,AVG(daily_return) * 252 AS histo_avg_3Y
	FROM
	RETURNS
	WHERE return_hodate >= ADD_MONTHS(return_last_close_date, - 3 * 12) AND return_first_close_date <= ADD_MONTHS(return_last_close_date, - 3 * 12)
	GROUP BY return_cfin
	) ON cfin_histo_std_3Y = emcfin
LEFT JOIN (
	SELECT return_cfin AS cfin_histo_std_5Y
		,STDDEV_SAMP(daily_return) * SQRT(252) AS histo_std_5Y
		,AVG(daily_return) * 252 AS histo_avg_5Y
	FROM
	RETURNS
	WHERE return_hodate >= ADD_MONTHS(return_last_close_date, - 5 * 12) AND return_first_close_date <= ADD_MONTHS(return_last_close_date, - 5 * 12)
	GROUP BY return_cfin
	) ON cfin_histo_std_5Y = emcfin
LEFT JOIN exane.alien on ifcfin = alsjac and altype = 6
LEFT JOIN (
	SELECT alcfin cfin_index
		,alsjac cfin_doublon
	FROM exane.alien
	WHERE altype = 41
	) ON cfin_doublon = ifcfin
WHERE emissuer IN (
		144201
		,144202
		,144191
		)
	AND icetatdevie = 1
	AND ifstatut NOT IN (
		7
		,22
		)
	AND ifnom NOT LIKE '[%'
	AND cfin_index IS NULL
ORDER BY CASE
		WHEN first_close_date IS NULL
			THEN 1
		ELSE 0
		END
	,first_close_date DESC

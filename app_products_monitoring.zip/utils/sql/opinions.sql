SELECT sodatemodif as "Date"
	,socfin as "Cfin"
	,sopdesc as "Name"
	,cfcode as "Ticker"
	,opistock as "Opinion Stock"
	,denomcourtibes as "Ccy"
	,soobjhaut as "Target"
	,panomlonggb as "Country"
	,longlabel as "Sector"
	,opisector as "Opinion Sector"
FROM (
	SELECT DISTINCT sodatemodif
		,socfin
		,sopdesc
		,cfcode
		,opi_stock.oplibellegb opistock
		,denomcourtibes
		,soobjhaut
		,panomlonggb
		,longlabel
		,opi_sector.oplibellegb opisector
		,opi_stock.opcode
	FROM analyse.afsociete
	JOIN analyse.afpayszones ON pacode = sopays
	JOIN exane.codes ON cfsource = 11
		AND cfcode NOT LIKE '% EU'
		AND cfcfin = socfin
	JOIN analyse.afdevises ON decfin = sodevise
	JOIN exane.COLLECTION ON clsjac = socfin
		AND cldateout >= sysdate
	JOIN analyse.afstoxx_sectors_link ON codeexane = clcollect
	JOIN analyse.afstoxx_sectors ON code = codestoxx
		AND enddate IS NULL
	JOIN analyse.afopinions opi_sector ON opi_sector.opcode = opinion
	JOIN analyse.afopinions opi_stock ON opi_stock.opcode = soopinionvaleur
	WHERE opi_stock.oplibellegb NOT IN (
			'Not rated'
			,'Restricted'
			)
	ORDER BY opi_stock.opcode DESC
		,longlabel
		,panomlonggb
	)
SELECT cphdate AS "Date" ,
       CASE
           WHEN ifnom LIKE 'Contrib%' THEN product_cfin
           ELSE ifcfin
       END AS "Cfin",
       CASE
           WHEN ifnom LIKE 'Contrib%' THEN product_name
           ELSE ifnom
       END AS "Name" ,
       ul_cfcode_isin AS "Isin" ,
       ul_cfcode_ticker AS "Ticker" ,
       weights AS "Weight" ,
       cphquantite AS "Qp1" ,
       dvcodeiso AS "Ccy" ,
        CASE
            WHEN (prmodecot = 2 AND tyfamille != 6)
                THEN histo.hoclose * emnominal / 100
            ELSE histo.hoclose
        END AS "Close",
       xccy AS "Change"
FROM (
    SELECT  cphdate,
            cphsjac ,
            cphpoids / 100.0 AS weights ,
            cphquantite
   FROM exane.composition_h
   WHERE cphcfin = index_cfin
     AND cphdate >= to_date('start_date', 'dd/mm/yyyy')
     AND cphdate <= to_date('end_date', 'dd/mm/yyyy')
)
JOIN exane.instruments ON ifcfin = cphsjac
LEFT JOIN exane.typeinstrument ON tycode = iftype
LEFT JOIN
   (SELECT alsjac product_cfin, ifnom product_name, alcfin cfin_contrib
    FROM exane.alien
    JOIN exane.instruments ON ifcfin = alsjac
    WHERE altype = 14
   ) ON cfin_contrib = cphsjac
LEFT JOIN
  (SELECT ul_cfcfin_isin ,
          ul_cfcode_isin ,
          ul_cfmarche_isin
   FROM
     (SELECT cfcfin AS ul_cfcfin_isin ,
             cfcode AS ul_cfcode_isin ,
             cfmarche AS ul_cfmarche_isin ,
             Count(*) OVER (PARTITION BY cfcfin
                            ORDER BY cfhorodate ROWS UNBOUNDED preceding) Count_1
      FROM exane.codes
      WHERE cfsource = 6 )
   WHERE count_1 = 1 ) ON ul_cfcfin_isin = cphsjac
LEFT JOIN
  (SELECT ul_cfcfin_ticker ,
          ul_cfcode_ticker ,
          ul_cfmarche_ticker
   FROM
     (SELECT cfcfin AS ul_cfcfin_ticker ,
             cfcode AS ul_cfcode_ticker ,
             cfmarche AS ul_cfmarche_ticker ,
             Count(*) OVER (PARTITION BY cfcfin
                            ORDER BY cfhorodate ROWS UNBOUNDED preceding) Count_1
      FROM exane.codes
      WHERE cfsource = 11
        AND cfcode NOT LIKE '% EU' )
   WHERE count_1 = 1 ) ON ul_cfcfin_ticker = cphsjac
LEFT JOIN
  (SELECT ul_cfcfin_camelot ,
          ul_cfcode_camelot ,
          ul_cfmarche_camelot
   FROM
     (SELECT cfcfin AS ul_cfcfin_camelot ,
             cfcode AS ul_cfcode_camelot ,
             cfmarche AS ul_cfmarche_camelot ,
             Count(*) OVER (PARTITION BY cfcfin
                            ORDER BY cfhorodate ROWS UNBOUNDED preceding) Count_1
      FROM exane.codes
      WHERE cfsource = 311
        AND cfcode NOT LIKE '% EU' )
   WHERE count_1 = 1 ) ON ul_cfcfin_camelot = cphsjac
LEFT JOIN exane.historiques histo ON (histo.hocfin = cphsjac
                                      AND histo.homarche IN (
                                        0 ,
                                        ul_cfmarche_ticker ,
                                        ul_cfmarche_isin ,
                                        ul_cfmarche_camelot)
                                      AND histo.hodate = (
                                        SELECT max(hodate) FROM exane.historiques
                                        WHERE hocfin = cphsjac AND hodate <= cphdate
                                      )
)
LEFT JOIN exane.produits ON prcfin = cphsjac
LEFT JOIN exane.devise ON dvcfin = prdev
LEFT JOIN exane.emission ON ifcfin = emcfin
LEFT JOIN (
    SELECT chvaleur xccy, chdate date_xccy, prdev dev_ul from EXANE.crosshistorique
    JOIN exane.produits on prcfin = chcfin and prdevnominal = (SELECT prdev from exane.produits where prcfin = index_cfin)
    JOIN exane.instruments on
        ifcfin = chcfin and
        chtype = 3
) on date_xccy = cphdate and dev_ul = prdev
ORDER BY cphdate,
         weights DESC
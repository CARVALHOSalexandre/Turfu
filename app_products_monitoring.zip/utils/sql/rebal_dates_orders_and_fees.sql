SELECT xdfeffectivedate as "Rebalancing Dates"
FROM   derives.idxordersandfees
WHERE  xdfcfinindex = index_cfin
ORDER  BY xdfeffectivedate ASC
SELECT
        XDFEFFECTIVEDATE AS "Date",
        xdfcfinudl AS "Cfin",
        alien_ie.alcfin AS "Cfin IE",
        alien_contrib.alsjac AS "Cfin Contrib",
        XDFDIRTYPRICE AS "Close",
        XDFCLEANPRICE / 100 * emnominal AS "Clean Close",
        xdfcross AS "Change",
        xtflibelle AS "Type",
        emnominal AS "Nominal",
        monom as "Quotation Mode"
FROM derives.idxordersandfees
JOIN derives.idxtypeordersandfees on xtfcode = xdfoperationtype
LEFT JOIN exane.alien alien_ie ON alien_ie.alsjac = xdfcfinudl AND alien_ie.altype = 40
LEFT JOIN exane.alien alien_contrib ON alien_contrib.alcfin = alien_ie.alcfin AND alien_contrib.altype = 14
LEFT JOIN exane.emission ON emcfin = xdfcfinudl
LEFT JOIN EXANE.produits ON prcfin = emcfin
LEFT JOIN EXANE.modecot ON modecot.mocode = produits.prmodecot
WHERE xdfcfinindex = index_cfin
  AND XDFDIRTYPRICE IS NOT NULL
  AND xdfeffectivedate BETWEEN to_date('start_date', 'dd/mm/yyyy') AND to_date('end_date', 'dd/mm/yyyy')
  AND xtfcode in  (1, 2) --only orders without fees, otherwise use: not in (13, 15)
ORDER BY XDFEFFECTIVEDATE DESC
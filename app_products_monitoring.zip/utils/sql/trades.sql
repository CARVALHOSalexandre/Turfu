WITH
HISTORICAL AS(
    SELECT
        hocfin,
        hodate,
        hoclose
            FROM exane.historiques
                JOIN EXANE.emission ON emcfin = hocfin
                JOIN EXANE.instruments ON ifcfin = hocfin
                JOIN EXANE.instrumentcomplement ON iccfin = hocfin
                JOIN EXANE.typeinstrument ON EXANE.typeinstrument.tycode = iftype
                WHERE ifcontrat = 1
                    AND ifstatut NOT IN (22)
                    AND iftype NOT IN (31, 62)
                    AND (tyfamille NOT IN (1, 2, 6, 13) OR (iftypofo > 35000 AND iftypofo < 36000))
                    filter_alive
                    filter_market
                    filter_back_to_back
                    filter_sales
                    filter_traded
),
LAST_CLOSE_DATE AS(
    SELECT hocfin as hocfin_lcd, MAX(hodate) as last_close_date
        FROM HISTORICAL
        GROUP BY hocfin
),
LAST_CLOSE AS(
    SELECT hocfin as hocfin_lc, hoclose as last_close
        FROM LAST_CLOSE_DATE
        LEFT JOIN HISTORICAL on hocfin = hocfin_lcd and hodate = last_close_date
),
FIRST_CLOSE_DATE AS(
    SELECT hocfin as hocfin_fcd, MIN(hodate) as first_close_date
        FROM HISTORICAL
        GROUP BY hocfin
)

SELECT isin
    ,ifstatut
    ,ifcfin cfin_product
    ,alien_contrib.alcfin cfin_contrib
    ,alien_otc.alcfin cfin_otc
    ,tiers_product.tinom issuer
    ,tiers_otc.tinom issuer_otc
    ,ric
    ,ifnom
    ,com_name
    ,opdatenego
    ,opnumero
    ,opquantite
    ,opmontant
    ,opvendeur
    ,opmargevendeur
    ,opmargetrader
    ,opotype
    ,opflag
    ,opannule
    ,prmarche
    ,dvcodeiso currency
    ,emission_product.emnominal nominal
    ,monom cotationmode
    ,emission_product.emdatestrike strike_date
    ,emission_product.empaiement issue_date
    ,ctmaturite maturity_date
    ,last_cfin.ladate last_date
    ,alien_contrib_inverse.alcfin cfin_contrib_inverse
    ,last_contrib.ladate last_date_contrib
    ,vcnom
    ,date_cours
    ,prix_theorique
    ,bid
    ,ask
    ,marge_bid_vente
    ,marge_ask_vente
    ,ROUND((last_close - histo_3M) / histo_3M, 4) AS "Perf. 3M"
    FROM  EXANE.instruments
    JOIN RISQUE.rkoperation ON opcfin = ifcfin AND opotype = 51 AND opflag != 3 AND opvendeur != -1 AND opannule IS NULL
                                                    AND opdatenego >= TO_DATE('min_date', 'YYYY-MM-DD')
                                                    AND opdatenego <= TO_DATE('max_date', 'YYYY-MM-DD')
	LEFT JOIN EXANE.produits ON prcfin = ifcfin
    LEFT JOIN EXANE.modecot ON mocode = prmodecot
	LEFT JOIN EXANE.devise ON dvcfin = prdev
	LEFT JOIN EXANE.contrats ON ctcfin = ifcfin
    LEFT JOIN RISQUE.rkvendeurcircus ON vccode = opvendeur
    LEFT JOIN LAST_CLOSE ON hocfin_lc = ifcfin
    LEFT JOIN LAST_CLOSE_DATE ON hocfin_lcd = ifcfin
    LEFT JOIN FIRST_CLOSE_DATE ON hocfin_fcd = ifcfin
    LEFT JOIN (SELECT cfcfin cfin_com_name, cfdesc com_name, MAX(cfhorodate) date_com_name
                FROM EXANE.codes
                WHERE cfsource = 101
                GROUP BY cfcfin, cfdesc
            )ON cfin_com_name = ifcfin
    LEFT JOIN (SELECT cfcfin cfinISIN, cfcode isin, MAX(cfhorodate) date_isin
                FROM EXANE.codes
                WHERE cfsource = 6
                GROUP BY cfcfin, cfcode
            ) ON cfinISIN = ifcfin
    LEFT JOIN (SELECT cfcfin cfinRIC, cfcode ric, MAX(cfhorodate) date_ric
                FROM EXANE.codes
                WHERE cfsource = 334
                GROUP BY cfcfin, cfcode
            ) ON cfinRIC = ifcfin
    LEFT JOIN EXANE.emission emission_product ON emission_product.emcfin = ifcfin
	LEFT JOIN EXANE.typeinstrument ON EXANE.typeinstrument.tycode = iftype
	LEFT JOIN EXANE.alien alien_contrib ON alien_contrib.alsjac = ifcfin
		AND alien_contrib.altype = 14
	LEFT JOIN EXANE.alien alien_contrib_inverse ON alien_contrib_inverse.alcfin = ifcfin
		AND alien_contrib_inverse.altype = 14
	LEFT JOIN EXANE.alien alien_otc ON alien_otc.alsjac = ifcfin
		AND alien_otc.altype = 53
    LEFT JOIN EXANE.contratotcs ON cocfin = alien_otc.alcfin
	LEFT JOIN EXANE.tiers tiers_product ON tiers_product.ticode = emission_product.emissuer
	LEFT JOIN EXANE.tiers tiers_otc ON tiers_otc.ticode = coreceveur
    LEFT JOIN EXANE.nolast last_contrib ON last_contrib.lacfin = alien_contrib.alcfin
    LEFT JOIN EXANE.nolast last_cfin ON last_cfin.lacfin = ifcfin
    LEFT JOIN (
	SELECT *
	FROM CRS.v_cfin_marges
	) ON cfin = (
		CASE
			WHEN alien_contrib.alcfin IS NOT NULL
				THEN alien_contrib.alcfin
			ELSE ifcfin
			END
		)
    AND date_cours = (
		CASE
			WHEN alien_contrib.alcfin IS NOT NULL
				THEN last_contrib.ladate
			ELSE last_cfin.ladate
			END
		)
    LEFT JOIN (
        SELECT cfin_3M
            ,hoclose AS histo_3M
        FROM (
            SELECT hocfin AS cfin_3M
                ,MAX(hodate) AS m_date
            FROM HISTORICAL histo_3Mb
            LEFT JOIN exane.emission ON emcfin = histo_3Mb.hocfin
            LEFT JOIN LAST_CLOSE_DATE ON hocfin_lcd = histo_3Mb.hocfin
            WHERE histo_3Mb.hocfin = emcfin
                AND histo_3Mb.hodate <= ADD_MONTHS(last_close_date, - 3)
            GROUP BY histo_3Mb.hocfin
            )
        LEFT JOIN HISTORICAL ON (
                hocfin = cfin_3M
                AND hodate =  m_date
                )
        ) ON cfin_3M = emcfin
    WHERE ifcontrat = 1
        AND iftype NOT IN (31, 34, 62)
        AND alien_contrib_inverse.alcfin IS NULL
        AND (tyfamille NOT IN (1, 2, 6, 13) OR (iftypofo > 35000 AND iftypofo < 36000))
        filter_alive
        filter_market
        filter_back_to_back
        filter_sales
        filter_traded

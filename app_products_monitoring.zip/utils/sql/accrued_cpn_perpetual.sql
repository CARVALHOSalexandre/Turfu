SELECT
dd end_date,
start_date,
(((csvaleur*ammargemult)+ammargeadd)/100)/
( CASE
    WHEN amfreq = 'M' THEN 12
    WHEN amfreq = 'B' THEN 6
    WHEN amfreq = 'T' THEN 4
    WHEN amfreq = 'S' THEN 2
    ELSE 1
END),
ambase
FROM exane.amort
JOIN EXANE.constatation on cscfin = amcodetaux
JOIN (
    SELECT
        ecvcfin cfin,
        MIN(ecvdatefinint) end_date,
        MIN(ecvdatedebint) start_date,
        MIN(ecvdateconstat) constat_date
        FROM exane.echeancier_variable
        WHERE ecvcfin = cfin_bis
        AND  ecvdatepaiement > dd
        GROUP BY ecvcfin
    ) ON cfin = amcfin
WHERE amcfin = cfin_bis AND  csdate = constat_date
WITH main
AS (
	SELECT cfin_alive AS "Cfin"
		,emnominal
        ,codes_isin.cfcode "Isin"
		,alcfin AS "Cfin Contrib"
		,CASE
			WHEN last_ul.lapriclos * DELTA / emnominal < 0
				THEN 'Bear'
			ELSE 'Bull'
        END AS "Type"
		,instruments_alive.ifnom AS "Name"
		,dvcodeiso AS "Ccy"
		,CASE
			WHEN emdatestrike IS NULL
				THEN emdate
			ELSE emdatestrike
			END AS "Trade Date"
		,empaiement AS "Issue Date"
		,emmaturite AS "Valuation Date"
		,ctmaturite AS "Maturity Date"
        ,last_trade_date AS "Last Trade Date"
		,cfin_ul AS "UL Cfin"
		,CASE
			WHEN ul_cfcode IS NULL
				THEN 'Basket'
			ELSE ul_cfcode
			END AS "Ticker"
		,instruments_ul.ifnom AS "UL Name"
		,last_ul.lapriclos * DELTA / emnominal AS "UL Delta"
		,CASE
			WHEN ul_cfcode IS NULL
				THEN 1000
			WHEN hoclose IS NULL
				THEN (
						SELECT hoclose
						FROM exane.historiques
						WHERE hocfin = cfin_ul
							AND hodate = emdatestrike
						)
			ELSE hoclose
			END AS "UL Initial Bid"
		,last_ul.lapriclos AS "UL Last Bid"
		,last_ul.ladate AS "UL Last Bid Date"
		,CASE
			WHEN strike IS NULL
				THEN (
						SELECT sivaleur
						FROM risque.rkscriptindicateurs
						WHERE sicfin IN (
								cfin_alive
								,cfin_scripted
								)
							AND sicle LIKE 'RV_Strike'
							AND sidate = (
								SELECT Max(sidate)
								FROM risque.rkscriptindicateurs
								WHERE sicfin IN (
										cfin_alive
										,cfin_scripted
										)
								)
						)
			ELSE strike
			END AS "Strike"
		,CASE
			WHEN stop_loss IS NULL
				THEN (
						SELECT sivaleur
						FROM risque.rkscriptindicateurs
						WHERE sicfin IN (
								cfin_alive
								,cfin_scripted
								)
							AND sicle LIKE 'RV_Barrier'
							AND sidate = (
								SELECT Max(sidate)
								FROM risque.rkscriptindicateurs
								WHERE sicfin IN (
										cfin_alive
										,cfin_scripted
										)
								)
						)
			ELSE stop_loss
			END AS "Stop Loss"
		,units AS "Units"
		,prime AS "Prime"
		,CASE
			WHEN alcfin IS NULL
				THEN last_minifut.labid
			ELSE last_minifut_contrib.labid
			END "Last Bid"
		,CASE
			WHEN alcfin IS NULL
				THEN last_minifut.ladate
			ELSE last_minifut_contrib.ladate
			END "Last Bid Date"
		,sales_name AS "Sales"
		,sales_margin AS "Sales Margin"
	FROM (
		SELECT cfin_alive
			,units_alive
		FROM (
			SELECT opcfin cfin_alive
				,SUM(opquantite) units_alive
			FROM risque.rkbigbook
			JOIN risque.rkdefbigbook ON bbbigbook = dbbigbook
			JOIN risque.rkoperation ON dbbook = opbook
			JOIN exane.instruments ON ifcfin = opcfin
			JOIN exane.emission ON emcfin = opcfin
			WHERE bbbigbook IN (
					362
					,349
					)
				AND iftype IN (
					122
					,211
					)
				AND opflag != 3
				AND opotype = 51
				AND ifstatut != 22
			GROUP BY opcfin
			)

		)
	JOIN (
		SELECT opcfin cfin_prime
			,- SUM(opquantite) units
			,SUM(opmontant) prime
			,SUM(opmargevendeur) sales_eur_margin
            ,MAX(opdate) as last_trade_date
		FROM risque.rkbigbook
		JOIN risque.rkdefbigbook ON bbbigbook = dbbigbook
		JOIN risque.rkoperation ON dbbook = opbook
		JOIN exane.instruments ON ifcfin = opcfin
		JOIN exane.emission ON emcfin = opcfin
		WHERE bbbigbook IN (
				362
				,349
				)
			AND opotype = 51
			AND opflag != 3
		GROUP BY opcfin
		) ON cfin_prime = cfin_alive
	JOIN exane.emission ON emcfin = cfin_alive
	LEFT JOIN (
		SELECT prcfin cfin_pricing
			,Max(prnumero) numero
			,Min(prnumero) numero_ini
		FROM risque.rkpricing
		WHERE prflag = 1 and prmode = 0 and prprofil = 1004
		GROUP BY prcfin
		) ON cfin_pricing = cfin_alive
	LEFT JOIN (
		SELECT prnumero
			,prvaleur DELTA
			,praxe1 cfin_ul
		FROM risque.rkpricingresultats
		WHERE prindicateur = 3
		) ON prnumero = numero
	LEFT JOIN (
		SELECT opcfin cfin_margin
			,SUM(opmargevendeur) sales_margin
		FROM risque.rkbigbook
		JOIN risque.rkdefbigbook ON bbbigbook = dbbigbook
		JOIN risque.rkoperation ON dbbook = opbook
		JOIN exane.instruments ON ifcfin = opcfin
		JOIN exane.emission ON emcfin = opcfin
		WHERE opotype = 51
			AND opflag != 3
		GROUP BY opcfin
		) ON cfin_margin = cfin_alive
	JOIN exane.instruments instruments_alive ON instruments_alive.ifcfin = cfin_alive
	LEFT JOIN exane.instruments instruments_ul ON instruments_ul.ifcfin = cfin_ul
	LEFT JOIN exane.alien ON altype = 14
		AND alsjac = cfin_alive
	LEFT JOIN exane.codes codes_isin ON codes_isin.cfcfin = cfin_alive
		AND codes_isin.cfsource = 6
	LEFT JOIN (
		SELECT ul_cfcfin
			,ul_cfcode
		FROM (
			SELECT cfcfin AS ul_cfcfin
				,cfcode AS ul_cfcode
				,Count(*) OVER (
					PARTITION BY cfcfin ORDER BY cfhorodate ROWS unbounded preceding
					) Count_1
			FROM exane.codes
			WHERE cfsource = 11
				AND cfcode NOT LIKE '% EU'
			) codes_ul_ticker
		WHERE count_1 = 1
		) ON ul_cfcfin = cfin_ul
	LEFT JOIN (
		SELECT prnumero numero_delta_ini
			,praxe1 cfin_ul_ini
			,cfcode ticker_ul_ini
			,hodate
			,hoclose
			,ifpayoff ini_payoff
		FROM risque.rkpricingresultats
		JOIN exane.codes ON cfcfin = praxe1
			AND cfsource = 11
			AND cfcode NOT LIKE '% EU'
		JOIN exane.instrument ON ifcfin = praxe1
		JOIN exane.historiques ON hocfin = praxe1
		WHERE prindicateur = 3
			AND ifpayoff = 16
		) ON numero_delta_ini = numero_ini
		AND hodate = emdatestrike
		AND substr(ticker_ul_ini, 1, 2) = substr(ul_cfcode, 1, 2)
	LEFT JOIN exane.contrats ON ctcfin = cfin_alive
	LEFT JOIN exane.produits ON prcfin = cfin_alive
	LEFT JOIN exane.devise ON dvcfin = prdev
	LEFT JOIN exane.last last_minifut ON last_minifut.lacfin = cfin_alive
	LEFT JOIN exane.last last_minifut_contrib ON last_minifut_contrib.lacfin = alcfin
	LEFT JOIN exane.nolast last_ul ON last_ul.lacfin = cfin_ul
	LEFT JOIN (
		SELECT Listagg(vcnom, ', ') within
		GROUP (
				ORDER BY vcnom
				) sales_name
			,opcfin sales_cfin
		FROM (
			SELECT DISTINCT vcnom
				,opcfin
			FROM risque.rkoperation
			JOIN risque.rkvendeurcircus ON opvendeur = vccode
			WHERE vccode NOT IN (
					2817
					,5252
					)
			)
		GROUP BY opcfin
		) ON sales_cfin = cfin_alive
	LEFT JOIN (
		SELECT cpcfin cfin_product
			,cfin_scripted
			,CASE
				WHEN Lower(scscript) LIKE '%model local%'
					THEN To_number(Regexp_replace(Replace(Substr(scscript, Instr(scscript, 'vol', 1, 1) + 3, (Instr(scscript, 'model local', 1, 1) - (Instr(scscript, 'vol', 1, 1) + 14))), '!', ''), '(^[[:cntrl:]^\t]+)|([[:cntrl:]^\t]+$)', NULL))
				WHEN Lower(scscript) LIKE '%call%'
					AND Lower(scscript) NOT LIKE '%model local%'
					THEN To_number(Substr(scscript, Instr(scscript, 'CALL', 1, 1) + 5, (Instr(scscript, ' !', - 1) - 10) - (Instr(scscript, 'CALL', 1, 1) + 5)))
				WHEN Lower(scscript) LIKE '%put%'
					AND Lower(scscript) NOT LIKE '%model local%'
					THEN To_number(Substr(scscript, Instr(scscript, 'PUT', 1, 1) + 4, (Instr(scscript, ' !', - 1) - 10) - (Instr(scscript, 'PUT', 1, 1) + 4)))
				END strike
			,CASE
				WHEN Lower(scscript) LIKE '%call%'
					AND Lower(scscript) LIKE '%model local%'
					THEN To_number(Regexp_replace(Regexp_substr(Replace(Substr(scscript, Instr(scscript, 'limit down cst', 1, 1) + 14, Instr(scscript, 'rebate down cst', 1, 1) - Instr(scscript, 'limit down cst', 1, 1) - 14), '!', ''), '^[^/]+'), '(^[[:cntrl:]^\t]+)|([[:cntrl:]^\t]+$)', NULL))
				WHEN Lower(scscript) LIKE '%put%'
					AND Lower(scscript) LIKE '%model local%'
					THEN To_number(Regexp_replace(Regexp_substr(Replace(Substr(scscript, Instr(scscript, 'limit up cst', 1, 1) + 13, Instr(scscript, 'rebate up cst', 1, 1) - Instr(scscript, 'limit up cst', 1, 1) - 14), '!', ''), '^[^/]+'), '(^[[:cntrl:]^\t]+)|([[:cntrl:]^\t]+$)', NULL))
				WHEN Lower(scscript) NOT LIKE '%model local%'
					THEN To_number(Substr(scscript, Instr(scscript, ' !', - 1) + 11, Instr(scscript, ' ', - 1) - 2 - (Instr(scscript, ' !', - 1) + 11)))
				END stop_loss
		FROM exane.script
		JOIN (
			SELECT Min(cpsjac) cfin_scripted
				,cpcfin
			FROM exane.composition
			JOIN exane.instruments ON ifcfin = cpsjac
			WHERE iftype IN (
					122
					,241
					)
			GROUP BY cpcfin
			) ON cfin_scripted = sccfin
		) ON cfin_product = cfin_alive
	ORDER BY CASE
			WHEN units = 0
				THEN 1
			ELSE 0
			END
		,CASE
			WHEN strike IS NULL
				THEN 1
			ELSE 0
			END
		,emdatestrike DESC
	)
SELECT main.*
	,ROUND("UL Initial Bid" / ("UL Initial Bid" - "Strike"), 1) AS "Leverage Initial"
	,ROUND("UL Last Bid" / ("UL Last Bid" - "Strike"), 1) AS "Leverage"
	,abs("Units" * "Last Bid" * "UL Last Bid" / ("UL Last Bid" - "Strike")) AS "Exposure"
FROM main
WHERE emnominal != 0

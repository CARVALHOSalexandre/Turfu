SELECT xdfcfinindex as "Cfin"
	,ul_cfcode_ticker as "Ticker"
	,ifnom as "Name"
	,xdfeffectivedate as "Rebal Date"
	,dvcodeiso as "Ccy"
	,abs(xdfamount) as "Amount"
	,dbbigbook as "Book"
FROM DERIVES.idxordersandfees
JOIN EXANE.instruments ON ifcfin = xdfcfinindex
JOIN exane.devise ON dvcfin = xdfcurrency
LEFT JOIN (
	SELECT ul_cfcfin_ticker
		,ul_cfcode_ticker
	FROM (
		SELECT cfcfin AS ul_cfcfin_ticker
			,cfcode AS ul_cfcode_ticker
			,Count(*) OVER (
				PARTITION BY cfcfin ORDER BY cfhorodate ROWS unbounded preceding
				) Count_1
		FROM exane.codes
		WHERE cfsource = 11
		)
	WHERE count_1 = 1
	) ON ul_cfcfin_ticker = xdfcfinindex
LEFT JOIN RISQUE.rkdefbook on dfcfin = xdfcfinindex
LEFT JOIN RISQUE.rkdefbigbook on dbbook = dfbook
WHERE xdfoperationtype = 3
	AND xdfeffectivedate >= to_date('start_date', 'DD/MM/YYYY')
    AND xdfeffectivedate <= to_date('end_date', 'DD/MM/YYYY')
	AND xdfamount != 0
	filter
ORDER BY xdfeffectivedate
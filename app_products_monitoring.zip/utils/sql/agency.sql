WITH cfin_agency as (
    select unique opcfin cfin
    FROM risque.rkbigbook
    JOIN risque.rkdefbigbook ON bbbigbook = dbbigbook
    JOIN risque.rkoperation ON dbbook = opbook
    join exane.instruments on ifcfin = opcfin
    LEFT JOIN EXANE.typeinstrument ON EXANE.typeinstrument.tycode = iftype
    LEFT JOIN EXANE.alien alien_contrib_inverse ON alien_contrib_inverse.alcfin = ifcfin AND alien_contrib_inverse.altype = 14
    LEFT JOIN EXANE.alien alien_flex_inverse ON alien_flex_inverse.alsjac = ifcfin AND alien_flex_inverse.altype = 56
    WHERE ifcontrat = 1
        AND iftype IN (122, 211)
        AND alien_contrib_inverse.alcfin IS NULL
        AND alien_flex_inverse.alcfin IS NULL
        AND (tyfamille NOT IN (1, 2, 6, 13) OR (iftypofo > 35000 AND iftypofo < 36000))
        AND opflag != 3
        AND opotype in (1, 51)
        AND ifstatut NOT IN (7, 22)
        AND opannule IS NULL
)
SELECT
    ifcfin "Cfin",
    alcfin "Cfin Hedge",
    ul_cfcode_isin "Isin",
    ifnom "Name",
    dvcodeiso "Ccy",
    emission_titre.emdatestrike "Trade Date",
    emission_titre.empaiement "Issue Date",
    ctmaturite "Maturity Date",
    tiers_titre.tinom "Issuer",
    tiers_hedge.tinom "Issuer Hedge",
    emission_titre.emnominal "Nominal"
FROM exane.instruments
JOIN cfin_agency ON cfin = ifcfin
JOIN (
	SELECT ul_cfcfin_isin
		,ul_cfcode_isin
		,ul_cfmarche_isin
	FROM (
		SELECT cfcfin AS ul_cfcfin_isin
			,cfcode AS ul_cfcode_isin
			,cfmarche AS ul_cfmarche_isin
			,Count(*) OVER (
				PARTITION BY cfcfin ORDER BY cfhorodate ROWS unbounded preceding
				) Count_1
		FROM exane.codes
		WHERE cfsource = 6
		)
	WHERE count_1 = 1
	) ON ul_cfcfin_isin = ifcfin
LEFT JOIN exane.alien on alsjac = ifcfin and altype = 53
LEFT JOIN exane.emission ON emcfin = ifcfin
LEFT JOIN exane.emission emission_titre ON emission_titre.emcfin = ifcfin
LEFT JOIN EXANE.contrats ON ctcfin = ifcfin
LEFT JOIN exane.produits ON prcfin = ifcfin
LEFT JOIN EXANE.devise ON dvcfin = prdev
LEFT JOIN exane.tiers tiers_titre on tiers_titre.ticode = emission_titre.emissuer
LEFT JOIN EXANE.contratotcs ON cocfin = alcfin
LEFT JOIN EXANE.tiers tiers_hedge ON tiers_hedge.ticode = coreceveur

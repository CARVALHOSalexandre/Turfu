SELECT
TO_DATE('dd', 'YYYY-MM-DD'),
next_date,
CASE
    WHEN prev_date IS NULL THEN initiation_date
    ELSE prev_date
END,
coupon,
settle_days
FROM
(
    SELECT eccfin AS cfin, ecdate AS next_date, ecmontant/emnominal AS coupon, amcouponrule AS settle_days, empaiement AS initiation_date
    FROM exane.echeancier
    LEFT JOIN exane.emission ON emcfin=eccfin
    LEFT JOIN exane.amort ON amcfin=eccfin
    WHERE eccfin = cfin_bis
        AND ecdate =
            (SELECT min(ecdate)
                FROM exane.echeancier
                WHERE eccfin =  cfin_bis AND ecdate > TO_DATE('dd', 'YYYY-MM-DD'))
                )
                LEFT JOIN
                 (
                    SELECT eccfin, MAX(ecdate) AS prev_date
                    FROM exane.echeancier
                    WHERE eccfin = cfin_bis AND (ecdate <= TO_DATE('dd', 'YYYY-MM-DD'))
                    GROUP BY eccfin
                 ) ON eccfin = cfin_bis
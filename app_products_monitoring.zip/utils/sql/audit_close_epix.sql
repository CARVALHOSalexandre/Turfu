WITH audit_epix AS
  (SELECT iduvaluedate "Date",
          CASE
              WHEN alien_contrib.alsjac IS NOT NULL THEN alien_contrib.alsjac
              WHEN alien_ie.alcfin IS NOT NULL THEN alien_ie.alcfin
              ELSE iducfinssj
          END AS "Cfin",
          CASE
              WHEN alien_ie.alcfin IS NOT NULL THEN iducfinssj
              ELSE NULL
          END "Cfin IE",
          CASE
              WHEN alien_contrib.alsjac IS NOT NULL THEN alien_ie.alcfin
              ELSE NULL
          END "Cfin Contrib",
          COALESCE(iducross, 1.0) "Change",
          iduspot "Spot Epix",
          iducoupon "Coupon"
   FROM derives.idxaudit_udl
   JOIN exane.instruments inst_ssj ON inst_ssj.ifcfin = iducfinssj
   LEFT JOIN exane.alien alien_ie ON alien_ie.alsjac = iducfinssj AND alien_ie.altype = 40
   LEFT JOIN exane.alien alien_contrib ON alien_contrib.alcfin = alien_ie.alcfin AND alien_contrib.altype = 14
   WHERE iducfin = index_cfin
     AND iduid in
       (SELECT max(iduid)
        FROM derives.idxaudit_udl
        WHERE iducfin = index_cfin
          AND (iduvaluedate BETWEEN to_date('start_date', 'DD-MM-YYYY') AND to_date('end_date', 'DD-MM-YYYY'))
        GROUP BY iduvaluedate, iducfinssj)
   ORDER BY iduvaluedate DESC)
SELECT audit_epix."Date",
       audit_epix."Cfin",
       audit_epix."Cfin IE",
       audit_epix."Cfin Contrib",
       CASE
            WHEN emission.emnominal IS NOT NULL THEN round(audit_epix."Spot Epix" / audit_epix."Change" - audit_epix."Coupon", 4)/emission.emnominal*100
            ELSE round(audit_epix."Spot Epix" / audit_epix."Change", 4)
            END AS "Close Epix",
       histo_cfin.hoclose "Close",
       histo_ie.hoclose "Close IE",
       histo_contrib.hoclose "Close Contrib"
FROM audit_epix
LEFT JOIN exane.historiques histo_cfin ON histo_cfin.hocfin = audit_epix."Cfin" AND histo_cfin.hodate = audit_epix."Date"
LEFT JOIN exane.historiques histo_ie ON histo_ie.hocfin = audit_epix."Cfin IE" AND histo_ie.hodate = audit_epix."Date"
LEFT JOIN exane.historiques histo_contrib ON histo_contrib.hocfin = audit_epix."Cfin Contrib" AND histo_contrib.hodate = audit_epix."Date"
LEFT JOIN exane.emission emission ON emission.emcfin = audit_epix."Cfin"

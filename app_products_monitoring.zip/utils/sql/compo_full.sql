SELECT cphdate AS "Date"
	,cldatein AS "Entry Date"
	,empaiement AS "Issue Date"
	,CASE
        WHEN ifnom LIKE 'Contrib%' THEN product_cfin
		ELSE ifcfin
		END AS "Cfin"
	,CASE
		WHEN ifnom LIKE 'Contrib%' THEN product_name
		ELSE ifnom
		END AS "Name"
	,ul_cfcode_isin AS "Isin"
	,ul_cfcode_ticker AS "Ticker"
	,libelle_typo_instrument AS "Type"
	,CASE
		WHEN upper(ifnom) LIKE 'EXANE %M CAPITALIZED%'
			THEN 'FX Hedge'
		WHEN upper(ifnom) LIKE 'EXANE % CAPITALIZED%'
			THEN 'Cash'
		ELSE sename
		END AS "Sector"
	,CASE
		WHEN upper(ifnom) LIKE 'EXANE % CAPITALIZED%'
			THEN NULL
		WHEN upper(panom) = 'NO COUNTRY'
			THEN NULL
		WHEN length(panom) > 3
			THEN initcap(panom)
		ELSE panom
		END AS "Country"
	,weights AS "Weight"
	,cphquantite AS "Qp1"
	,emnominal AS "Nominal Amount"
	,dvcodeiso AS "Ccy"
	,entry_xccy AS "Change at Entry"
	,xccy AS "Change"
	,CASE
        WHEN prod_ssj.prdev=prod_indx.prdev
            THEN COALESCE("cross_epix", 1.0)
        ELSE
            "cross_epix"
    END AS "Change Epix"
	,CASE
		WHEN prod_ssj.prmodecot = 2 AND tyfamille != 6
			THEN emprix * emnominal / 100
		ELSE emprix
	END AS "Issue Price"
	,CASE
        WHEN epix_entry.iduspot IS NULL
            THEN CASE
                WHEN prod_ssj.prmodecot = 2 AND tyfamille != 6
                    THEN histo_entry.hoclose * emnominal / 100
                ELSE histo_entry.hoclose
                END
        ELSE epix_entry.iduspot / entry_xccy
    END AS "Close at Entry"
	,CASE
		WHEN prod_ssj.prmodecot = 2 AND tyfamille != 6
			THEN histo.hoclose * emnominal / 100
		ELSE histo.hoclose
	END AS "Close"
	,CASE
        WHEN prod_ssj.prmodecot = 2 AND tyfamille != 6 AND emnominal IS NOT NULL THEN "spot_epix" / "Change Epix" / emnominal * 100
        ELSE "spot_epix" / "Change Epix"
    END AS "Close Epix"
	,dimontantbrut AS "Gross Div. in Cash"
	,CASE WHEN tipays = 40 THEN dimontantbrut * 0.55 ELSE dimontant END "Net Div. in Cash"
	,CASE WHEN prod_ssj.prmodecot = 2 AND tyfamille != 6 THEN ecmontant / emnominal * 100 ELSE ecmontant END AS "Coupon"
	,CASE
	    WHEN prod_ssj.prmodecot = 2 AND tyfamille != 6 AND emnominal IS NOT NULL THEN "coupon_epix" / "Change Epix" / emnominal * 100
	    ELSE "coupon_epix" / "Change Epix"
	END AS "Accrued Coupon"
	,histo.hodate AS "Close Date"
	,CASE
		WHEN epix_entry.iduspot IS NULL
            THEN CASE
               WHEN histo_entry.hoclose IS NULL
                    THEN CASE
                        WHEN emdate = cldatein and emprix != 0
                            THEN histo.hoclose / emprix - 1
                        END
                WHEN histo_entry.hoclose != 0
                    THEN histo.hoclose / histo_entry.hoclose - 1
            END
        WHEN epix_entry.iduspot != 0
			THEN ("spot_epix" / "Change Epix") / (epix_entry.iduspot / entry_xccy) - 1
		ELSE NULL
    END AS "Perf since Entry"
	,CASE
		WHEN histo_monthly.hoclose != 0
			THEN histo.hoclose / histo_monthly.hoclose - 1
		ELSE NULL
		END AS "Perf 1 Month"
	,CASE
		WHEN histo_ytd.hoclose != 0
			THEN histo.hoclose / histo_ytd.hoclose - 1
		ELSE NULL
		END AS "Perf YTD"
FROM (
	SELECT cphdate
		,cldatein
		,cldateout
		,cphsjac
		,cphpoids / 100.0 AS weights
		,cphquantite
        ,cphcfin
        ,CASE
            WHEN prod_ssj.prdev=prod_indx.prdev
                THEN COALESCE(audit_epix.iducross, 1.0)
        ELSE
            audit_epix.iducross
        END AS "Change Epix"
        ,audit_epix.iducross "cross_epix"
        ,audit_epix.iduspot "spot_epix"
        ,audit_epix.iducoupon "coupon_epix"
	FROM exane.composition_h
    LEFT JOIN exane.produits prod_indx ON prod_indx.prcfin = cphcfin
    LEFT JOIN exane.produits prod_ssj ON prod_ssj.prcfin = cphsjac
	LEFT JOIN exane.alien ON alcfin = cphsjac AND altype = 14
	LEFT JOIN EXANE.pdtcompo on pccfin = cphcfin
	LEFT JOIN exane.collection ON
	    clcollect = COALESCE(cphcollect, pccollect)
		AND clsjac = COALESCE(alsjac, cphsjac)
		AND cldatein <= cphdate
		AND (
			cldateout IS NULL
			OR cldateout > cphdate
			)
    LEFT JOIN derives.idxaudit_udl audit_epix ON (
		iducfinssj = cphsjac
        AND iducfin = index_cfin
        AND iduvaluedate = cphdate
        		AND idusessionid = (
			SELECT max(idusessionid)
			FROM derives.idxaudit_udl
			WHERE iducfinssj = cphsjac
				AND iduvaluedate = cphdate
				AND iducfin = index_cfin
			))
	WHERE cphcfin = index_cfin
		AND cphdate >= to_date('start_date', 'dd/mm/yyyy')
		AND cphdate <= to_date('end_date', 'dd/mm/yyyy')
	)
JOIN exane.instruments ON ifcfin = cphsjac
LEFT JOIN exane.typeinstrument ON tycode = iftype
LEFT JOIN dividende ON
    dicfin = cphsjac
    AND diacompte <> 'X'
    AND didate = cphdate
LEFT JOIN exane.echeancier ON
    eccfin = cphsjac
    AND ecdate = cphdate
LEFT JOIN
   (SELECT alsjac product_cfin, ifnom product_name, alcfin cfin_contrib
    FROM exane.alien
    JOIN exane.instruments ON ifcfin = alsjac
    WHERE altype = 14
   ) ON cfin_contrib = cphsjac
LEFT JOIN exane.v_typofo_libelles ON code_typo = iftypofo
LEFT JOIN (
	SELECT ul_cfcfin_isin
		,ul_cfcode_isin
		,ul_cfmarche_isin
	FROM (
		SELECT cfcfin AS ul_cfcfin_isin
			,cfcode AS ul_cfcode_isin
			,cfmarche AS ul_cfmarche_isin
			,Count(*) OVER (
				PARTITION BY cfcfin ORDER BY cfhorodate ROWS unbounded preceding
				) Count_1
		FROM exane.codes
		WHERE cfsource = 6
		)
	WHERE count_1 = 1
	) ON ul_cfcfin_isin = cphsjac
LEFT JOIN (
	SELECT ul_cfcfin_ticker
		,ul_cfcode_ticker
		,ul_cfmarche_ticker
	FROM (
		SELECT cfcfin AS ul_cfcfin_ticker
			,cfcode AS ul_cfcode_ticker
			,cfmarche AS ul_cfmarche_ticker
			,Count(*) OVER (
				PARTITION BY cfcfin ORDER BY cfhorodate ROWS unbounded preceding
				) Count_1
		FROM exane.codes
		WHERE cfsource = 11
			AND cfcode NOT LIKE '% EU'
		)
	WHERE count_1 = 1
	) ON ul_cfcfin_ticker = cphsjac
LEFT JOIN (
	SELECT ul_cfcfin_camelot
		,ul_cfcode_camelot
		,ul_cfmarche_camelot
	FROM (
		SELECT cfcfin AS ul_cfcfin_camelot
			,cfcode AS ul_cfcode_camelot
			,cfmarche AS ul_cfmarche_camelot
			,Count(*) OVER (
				PARTITION BY cfcfin ORDER BY cfhorodate ROWS unbounded preceding
				) Count_1
		FROM exane.codes
		WHERE cfsource = 311
			AND cfcode NOT LIKE '% EU'
		)
	WHERE count_1 = 1
	) ON ul_cfcfin_camelot = cphsjac
LEFT JOIN exane.historiques histo ON (
		histo.hocfin = cphsjac
		AND histo.homarche IN (
			0
			,ul_cfmarche_ticker
			,ul_cfmarche_isin
			,ul_cfmarche_camelot
		)
		AND histo.hodate = (
			SELECT max(hodate)
			FROM exane.historiques
			WHERE hocfin = cphsjac
				AND hodate <= cphdate
		)
)
LEFT JOIN derives.idxaudit_udl epix_entry ON (
		iducfinssj = cphsjac
        AND iducfin = index_cfin
        AND iduvaluedate = cldatein
        AND idusessionid = (
			SELECT max(idusessionid)
			FROM derives.idxaudit_udl
			WHERE iducfinssj = cphsjac
				AND iduvaluedate = cldatein
				AND iducfin = index_cfin
		)
)
LEFT JOIN exane.historiques histo_entry ON (
		histo_entry.hocfin = cphsjac
		AND histo_entry.hodate = cldatein
		AND histo_entry.homarche IN (
			0
			,ul_cfmarche_ticker
			,ul_cfmarche_isin
			,ul_cfmarche_camelot
		)
)
LEFT JOIN exane.historiques histo_ytd ON (
		histo_ytd.hocfin = cphsjac
		AND histo_ytd.homarche IN (
			0
			,ul_cfmarche_ticker
			,ul_cfmarche_isin
			,ul_cfmarche_camelot
		)
		AND histo_ytd.hodate = (
			SELECT max(hodate)
			FROM exane.historiques
			WHERE hocfin = cphsjac
				AND hodate >= trunc(cphdate, 'yyyy') - interval '1' year
				AND hodate < trunc(cphdate, 'yyyy')
		)
)
LEFT JOIN exane.historiques histo_monthly ON (
		histo_monthly.hocfin = cphsjac
		AND histo_monthly.homarche IN (
			0
			,ul_cfmarche_ticker
			,ul_cfmarche_isin
			,ul_cfmarche_camelot
		)
		AND histo_monthly.hodate = (
			SELECT max(hodate) FROM exane.historiques
			WHERE hocfin = cphsjac AND hodate <= ADD_MONTHS(cphdate, - 1)
		)
)
LEFT JOIN exane.produits prod_ssj ON prod_ssj.prcfin = cphsjac
LEFT JOIN exane.devise ON dvcfin = prod_ssj.prdev
JOIN exane.pays ON pacode = prod_ssj.prpays
LEFT JOIN exane.emission ON emcfin = ifcfin
LEFT JOIN exane.tiers ON emissuer = ticode
LEFT JOIN (
    select chvaleur entry_xccy, chdate entry_date_xccy, prdev entry_dev_ul from EXANE.crosshistorique
    join exane.produits on prcfin = chcfin and prdevnominal = (select prdev from exane.produits where prcfin = index_cfin)
    join exane.instruments on
        ifcfin = chcfin and
        chtype = 3
) on entry_date_xccy = cldatein and entry_dev_ul = prod_ssj.prdev
LEFT JOIN (
    select chvaleur xccy, chdate date_xccy, prdev dev_ul from EXANE.crosshistorique
    join exane.produits on prcfin = chcfin and prdevnominal = (select prdev from exane.produits where prcfin = index_cfin)
    join exane.instruments on
        ifcfin = chcfin and
        chtype = 3
) on date_xccy = cphdate and dev_ul = prod_ssj.prdev
LEFT JOIN exane.produits prod_indx ON prod_indx.prcfin = cphcfin
LEFT JOIN (
	SELECT *
	FROM hsectorisation
	JOIN secteur ON (
			hscode = secode
			AND setype = 5
			)
	JOIN (
		SELECT emcfin cfin
			,max(hsdatein) max_date
		FROM exane.hsectorisation
			,secteur
			,emission
		WHERE hscode = secode
			AND setype = 5
			AND hstiers = emissuer
		GROUP BY emcfin
		) ON hsdatein = max_date
) ON (
    cfin = emcfin
    AND emissuer = hstiers
    AND hsdatein <= cphdate
    AND (hsdateout >= cphdate OR hsdateout IS NULL)
)
ORDER BY cphdate
	,"Perf since Entry" DESC
	,cldatein DESC
	,weights DESC
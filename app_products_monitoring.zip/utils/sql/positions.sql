WITH
OPERATIONS AS (
    SELECT isin
    ,ifcfin cfin_product
    ,alien_contrib.alcfin cfin_contrib
    ,alien_otc.alcfin cfin_otc
    ,tiers_product.tinom issuer
    ,tiers_otc.tinom issuer_otc
    ,ric
    ,ifnom
    ,com_name
    ,opdatenego
    ,opquantite
    ,opmontant
    ,opvendeur
    ,opmargevendeur
    ,opmargetrader
    ,opotype
    ,opflag
    ,opannule
    ,prmarche
    ,dvcodeiso currency
    ,emission_product.emnominal nominal
    ,monom cotationmode
    ,emission_product.emdatestrike strike_date
    ,emission_product.empaiement issue_date
    ,ctmaturite maturity_date
    ,last_cfin.ladate last_date
    ,alien_contrib_inverse.alcfin cfin_contrib_inverse
    ,last_contrib.ladate last_date_contrib
    FROM  EXANE.instruments
    LEFT JOIN RISQUE.rkoperation ON opcfin = ifcfin AND opotype = 51 AND opflag != 3 AND opvendeur != -1 AND opannule IS NULL AND opdatenego >= TO_DATE('min_date', 'YYYY-MM-DD') AND opdatenego <= TO_DATE('max_date', 'YYYY-MM-DD')
	LEFT JOIN EXANE.produits ON prcfin = ifcfin
    LEFT JOIN EXANE.modecot ON mocode = prmodecot
	LEFT JOIN EXANE.devise ON dvcfin = prdev
	LEFT JOIN EXANE.contrats ON ctcfin = ifcfin
    LEFT JOIN RISQUE.rkvendeurcircus ON vccode = opvendeur
    LEFT JOIN (SELECT cfcfin cfin_com_name, cfdesc com_name, MAX(cfhorodate) date_com_name
                FROM EXANE.codes
                WHERE cfsource = 101
                GROUP BY cfcfin, cfdesc
            )ON cfin_com_name = ifcfin
    LEFT JOIN (SELECT cfcfin cfinISIN, cfcode isin, MAX(cfhorodate) date_isin
                FROM EXANE.codes
                WHERE cfsource = 6
                GROUP BY cfcfin, cfcode
            ) ON cfinISIN = ifcfin
        LEFT JOIN (SELECT cfcfin cfinRIC, cfcode ric, MAX(cfhorodate) date_ric
                FROM EXANE.codes
                WHERE cfsource = 334
                GROUP BY cfcfin, cfcode
            ) ON cfinRIC = ifcfin
    LEFT JOIN EXANE.emission emission_product ON emission_product.emcfin = ifcfin
	LEFT JOIN EXANE.typeinstrument ON EXANE.typeinstrument.tycode = iftype
	LEFT JOIN EXANE.alien alien_contrib ON alien_contrib.alsjac = ifcfin
		AND alien_contrib.altype = 14
	LEFT JOIN EXANE.alien alien_contrib_inverse ON alien_contrib_inverse.alcfin = ifcfin
		AND alien_contrib_inverse.altype = 14
	LEFT JOIN EXANE.alien alien_otc ON alien_otc.alsjac = ifcfin
		AND alien_otc.altype = 53
    LEFT JOIN EXANE.contratotcs ON cocfin = alien_otc.alcfin
	LEFT JOIN EXANE.tiers tiers_product ON tiers_product.ticode = emission_product.emissuer
	LEFT JOIN EXANE.tiers tiers_otc ON tiers_otc.ticode = coreceveur
    LEFT JOIN EXANE.nolast last_contrib ON last_contrib.lacfin = alien_contrib.alcfin
    LEFT JOIN EXANE.nolast last_cfin ON last_cfin.lacfin = ifcfin
    WHERE ifcontrat = 1
        AND iftype NOT IN (31)
        AND alien_contrib_inverse.alcfin IS NULL
        AND (tyfamille NOT IN (1, 2, 6, 13) OR (iftypofo > 35000 AND iftypofo < 36000))
        filter_alive
        filter_market
        filter_back_to_back
        filter_sales
        filter_traded
)

SELECT DISTINCT isin AS "ISIN"
    ,cfin_product AS "Cfin"
	,cfin_contrib AS "Cfin Contrib"
    ,cfin_otc AS "Cfin OTC"
	,issuer AS "Issuer"
	,issuer_otc AS "Issuer OTC"
    ,ric as "RIC"
    ,CASE
        WHEN com_name IS NULL THEN ifnom
        ELSE com_name
	END AS "Name"
    ,CASE
        WHEN prmarche = 38 THEN 'Euronext'
        WHEN prmarche = 184 THEN 'SED'
        WHEN prmarche = 218 THEN 'SIX'
        WHEN prmarche = 919 THEN 'TLX'
        ELSE NULL
        END AS "Market"
	,strike_date AS "Strike Date"
	,issue_date AS "Issue Date"
	,maturity_date AS "Maturity Date"
	,currency AS "Ccy"
	,nominal AS "Nominal"
	,cotationmode AS "Quote Mode"
	,date_cours AS "Datetime"
	,prix_theorique AS "Theo Price"
	,bid AS "Bid"
	,ask AS "Ask"
	,marge_bid_vente AS "Bid Margin Sales"
	,marge_ask_vente AS "Ask Margin Sales"
	,marge_bid_cp AS "Bid Margin Trading"
	,marge_ask_cp AS "Ask Margin Trading"
	,units_today_sell AS "Units Today Sell"
	,units_today_buy AS "Units Today Buy"
	,units_one_day_sell AS "Units One Day Sell"
	,units_one_day_buy AS "Units One Day Buy"
	,units_one_week_sell AS "Units One Week Sell"
	,units_one_week_buy AS "Units One Week Buy"
	,units_one_month_sell AS "Units One Month Sell"
	,units_one_month_buy AS "Units One Month Buy"
	,units_three_month_sell AS "Units Three Month Sell"
	,units_three_month_buy AS "Units Three Month Buy"
    ,CASE WHEN cfin_otc IS NULL THEN sales_eur_margin
        ELSE otc_sales_eur_margin
    END AS "Total EUR Margin"
    ,CASE WHEN cfin_otc IS NULL THEN units_total
        ELSE otc_units
    END AS "Total Units"
FROM OPERATIONS
LEFT JOIN (
	SELECT *
	FROM CRS.v_cfin_marges
	) ON cfin = (
		CASE
			WHEN cfin_contrib IS NOT NULL
				THEN cfin_contrib
			ELSE cfin_product
			END
		)
	AND date_cours = (
		CASE
			WHEN cfin_contrib IS NOT NULL
				THEN last_date_contrib
			ELSE last_date
			END
		)
  LEFT JOIN (
	SELECT cfin_product cfin_units_margins
		,SUM(CASE
				WHEN opquantite > 0
					AND TRUNC(opdatenego) > TRUNC(SYSDATE) - 1
					THEN opquantite
				ELSE 0
				END) units_today_sell
		,- SUM(CASE
				WHEN opquantite < 0
					AND TRUNC(opdatenego) > TRUNC(SYSDATE) - 1
					THEN opquantite
				ELSE 0
				END) units_today_buy
		,SUM(CASE
				WHEN opquantite > 0
					AND TRUNC(opdatenego) = TRUNC(SYSDATE) - 1
					THEN opquantite
				ELSE 0
				END) units_one_day_sell
		,- SUM(CASE
				WHEN opquantite < 0
					AND TRUNC(opdatenego) = TRUNC(SYSDATE) - 1
					THEN opquantite
				ELSE 0
				END) units_one_day_buy
		,SUM(CASE
				WHEN opquantite > 0
					AND TRUNC(opdatenego) >= TRUNC(SYSDATE) - 7
					THEN opquantite
				ELSE 0
				END) units_one_week_sell
		,- SUM(CASE
				WHEN opquantite < 0
					AND TRUNC(opdatenego) >= TRUNC(SYSDATE) - 7
					THEN opquantite
				ELSE 0
				END) units_one_week_buy
		,SUM(CASE
				WHEN opquantite > 0
					AND TRUNC(opdatenego) >= add_months(TRUNC(SYSDATE), - 1)
					THEN opquantite
				ELSE 0
				END) units_one_month_sell
		,- SUM(CASE
				WHEN opquantite < 0
					AND TRUNC(opdatenego) >= add_months(TRUNC(SYSDATE), - 1)
					THEN opquantite
				ELSE 0
				END) units_one_month_buy
		,SUM(CASE
				WHEN opquantite > 0
					AND TRUNC(opdatenego) >= add_months(TRUNC(SYSDATE), - 3)
					THEN opquantite
				ELSE 0
				END) units_three_month_sell
		,- SUM(CASE
				WHEN opquantite < 0
					AND TRUNC(opdatenego) >= add_months(TRUNC(SYSDATE), - 3)
					THEN opquantite
				ELSE 0
				END) units_three_month_buy
        ,- SUM(opquantite) units_total
		,SUM(opmargevendeur) sales_eur_margin
	FROM OPERATIONS
    GROUP BY cfin_product
    ) ON cfin_units_margins = cfin_product
LEFT JOIN (SELECT cfin_otc cfin_otc_units, -SUM(opquantite) otc_units, SUM(opmargevendeur) otc_sales_eur_margin
    FROM OPERATIONS
    GROUP BY cfin_otc
) ON cfin_otc_units = cfin_otc
ORDER BY
    CASE
        WHEN "Total Units" IS NULL THEN 2
        WHEN "Total Units" = 0 THEN 1
        ELSE 0
    END

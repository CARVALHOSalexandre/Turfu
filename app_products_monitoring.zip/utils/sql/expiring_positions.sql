WITH
OPERATIONS AS (
    SELECT isin
    ,ifcfin cfin_product
    ,alien_contrib.alcfin cfin_contrib
    ,alien_otc.alcfin cfin_otc
    ,tiers_product.tinom issuer
    ,tiers_otc.tinom issuer_otc
    ,ric
    ,ifnom
    ,com_name
    ,opdatenego
    ,opquantite
    ,opmontant
    ,opvendeur
    ,opmargevendeur
    ,opmargetrader
    ,opotype
    ,opflag
    ,opannule
    ,prmarche
    ,dvcodeiso currency
    ,emission_product.emnominal nominal
    ,monom cotationmode
    ,emission_product.emdatestrike strike_date
    ,emission_product.empaiement issue_date
    ,ctmaturite maturity_date
    ,last_cfin.ladate last_date
    ,alien_contrib_inverse.alcfin cfin_contrib_inverse
    ,last_contrib.ladate last_date_contrib
    FROM  EXANE.instruments
    LEFT JOIN RISQUE.rkoperation ON opcfin = ifcfin AND opotype = 51 AND opflag != 3 AND opvendeur != -1 AND opannule IS NULL AND opdatenego >= TO_DATE('2000-01-01', 'YYYY-MM-DD') AND opdatenego <= sysdate
	LEFT JOIN EXANE.produits ON prcfin = ifcfin
    LEFT JOIN EXANE.modecot ON mocode = prmodecot
	LEFT JOIN EXANE.devise ON dvcfin = prdev
	LEFT JOIN EXANE.contrats ON ctcfin = ifcfin
    LEFT JOIN RISQUE.rkvendeurcircus ON vccode = opvendeur
    LEFT JOIN (SELECT cfcfin cfin_com_name, cfdesc com_name, MAX(cfhorodate) date_com_name
                FROM EXANE.codes
                WHERE cfsource = 101
                GROUP BY cfcfin, cfdesc
            )ON cfin_com_name = ifcfin
    LEFT JOIN (SELECT cfcfin cfinISIN, cfcode isin, MAX(cfhorodate) date_isin
                FROM EXANE.codes
                WHERE cfsource = 6
                GROUP BY cfcfin, cfcode
            ) ON cfinISIN = ifcfin
        LEFT JOIN (SELECT cfcfin cfinRIC, cfcode ric, MAX(cfhorodate) date_ric
                FROM EXANE.codes
                WHERE cfsource = 334
                GROUP BY cfcfin, cfcode
            ) ON cfinRIC = ifcfin
    LEFT JOIN EXANE.emission emission_product ON emission_product.emcfin = ifcfin
	LEFT JOIN EXANE.typeinstrument ON EXANE.typeinstrument.tycode = iftype
	LEFT JOIN EXANE.alien alien_contrib ON alien_contrib.alsjac = ifcfin
		AND alien_contrib.altype = 14
	LEFT JOIN EXANE.alien alien_contrib_inverse ON alien_contrib_inverse.alcfin = ifcfin
		AND alien_contrib_inverse.altype = 14
	LEFT JOIN EXANE.alien alien_otc ON alien_otc.alsjac = ifcfin
		AND alien_otc.altype = 53
    LEFT JOIN EXANE.contratotcs ON cocfin = alien_otc.alcfin
	LEFT JOIN EXANE.tiers tiers_product ON tiers_product.ticode = emission_product.emissuer
	LEFT JOIN EXANE.tiers tiers_otc ON tiers_otc.ticode = coreceveur
    LEFT JOIN EXANE.nolast last_contrib ON last_contrib.lacfin = alien_contrib.alcfin
    LEFT JOIN EXANE.nolast last_cfin ON last_cfin.lacfin = ifcfin
    WHERE ifcontrat = 1
        AND iftype NOT IN (31)
        AND alien_contrib_inverse.alcfin IS NULL
        AND (tyfamille NOT IN (1, 2, 6, 13) OR (iftypofo > 35000 AND iftypofo < 36000))
        AND ifstatut NOT IN (7, 22)
        AND opmargevendeur IS NOT NULL
        AND ctmaturite >= sysdate AND ctmaturite <= sysdate + 7
)

SELECT DISTINCT isin AS "ISIN"
    ,cfin_product AS "Cfin"
    ,CASE
        WHEN com_name IS NULL THEN ifnom
        ELSE com_name
	END AS "Name"
    ,issuer AS "Issuer"
    ,currency AS "Currency"
	,maturity_date AS "Maturity Date"
	,bid AS "Bid"
	,marge_bid_vente AS "Bid Margin Sales"
    ,CASE WHEN cfin_otc IS NULL THEN units_total * nominal
        ELSE otc_units * nominal
    END AS "Pose"
FROM OPERATIONS
LEFT JOIN (
	SELECT *
	FROM CRS.v_cfin_marges
	) ON cfin = (
		CASE
			WHEN cfin_contrib IS NOT NULL
				THEN cfin_contrib
			ELSE cfin_product
			END
		)
	AND date_cours = (
		CASE
			WHEN cfin_contrib IS NOT NULL
				THEN last_date_contrib
			ELSE last_date
			END
		)
  LEFT JOIN (
	SELECT cfin_product cfin_units_margins
        ,- SUM(opquantite) units_total
		,SUM(opmargevendeur) sales_eur_margin
	FROM OPERATIONS
    GROUP BY cfin_product
    ) ON cfin_units_margins = cfin_product
LEFT JOIN (SELECT cfin_otc cfin_otc_units, -SUM(opquantite) otc_units, SUM(opmargevendeur) otc_sales_eur_margin
    FROM OPERATIONS
    GROUP BY cfin_otc
) ON cfin_otc_units = cfin_otc
WHERE units_total !=0 or otc_units !=0
ORDER BY maturity_date

import json
import requests as rq
import pandas as pd
from pandas.tseries.offsets import BDay
from datetime import datetime as dt


class AnalyticsApiClient:
    """Client of Societe Generale's data API

    Access to Swagger
    https://analytics-api.sgmarkets.com/data/swagger/index.html

    """

    token = "vd1FpAL0Kq1bPbcFwpAal_k-MS4"  # SGMarkets token

    headers = {"Authorization": "Bearer " + token}

    proxies = dict()

    url = ""

    def __init__(self, api: str, version: int = 2):
        self.url = f"https://analytics-api.sgmarkets.com/{api}/v{version}"

    def get(self, endpoint, params=None):
        url = self.url + "/" + endpoint
        r = rq.get(url, headers=self.headers, params=params, proxies=self.proxies)
        if not r.ok:
            raise Exception(
                f"ERROR in API GET Request: code:{r.status_code} text:{r.text} for url {url}"
            )
        return r.json()

    def post(self, endpoint, params=None):
        url = self.url + "/" + endpoint
        r = rq.post(url, headers=self.headers, json=params, proxies=self.proxies)
        if not r.ok:
            raise Exception(
                f"ERROR in API POST Request: code:{r.status_code} text:{r.text} for url {url}"
            )
        return r.json()


def sg_implied_volatilites(tickers, maturities=None):
    client = AnalyticsApiClient("data", 2)

    if not maturities:
        maturities = ["12M"]

    indicators = [f"IV_{x}_100%" for x in maturities]

    start_date = end_date = (dt.today() - BDay(1)).strftime("%Y-%m-%d")

    bbg_tickers = {
        f"{x} EQUITY" if len(x.split()) == 2 else f"{x} INDEX": x for x in tickers
    }

    p = {
        "instruments": list(bbg_tickers.keys()),
        "fields": indicators,
        "type": "Undefined",
        "startDate": start_date,
        "endDate": end_date,
    }
    try:
        res = client.post("quotes", p)
        # print(json.dumps(res, indent=4))
    except Exception as e:
        print(repr(e))
        return pd.DataFrame()

    result = {}
    for r in res.get("quotes"):
        v = {}
        for x in r["fields"]["indicators"]:
            v[x["name"]] = x["values"][0]["value"] / 100.0
        result[r["instrument"]] = v

    df = pd.DataFrame(result)

    if df.empty:
        return df

    df = pd.DataFrame(result).T

    df = df.reindex(bbg_tickers.keys())

    df = df.reset_index()

    df.columns = ["ticker", *indicators]

    df.ticker = df.ticker.apply(lambda x: bbg_tickers.get(x))

    return df


if __name__ == "__main__":

    tickers = [
        "BLK US",
        "AWI US",
        "ERIC US",
        "NKE US",
        "MSCI US",
        "QCOM US",
        "OC US",
        "KMB US",
    ]

    df = sg_implied_volatilites(tickers)

import json
import pandas as pd
from requests import Session, exceptions
from utils.basics import dt_today, next_bday, prev_bday
from app import app, cache


class ContribInstrument(Session):
    """API connection to the Contrib Service

    Swagger: http://contrib/contrib-referential/swagger-ui.html

    """

    BASE_URL = "http://contrib/contrib-referential"

    def __init__(self):
        super().__init__()

        # Add elements in the header
        self.headers["username"] = "bichon_p"
        self.headers["Content-Type"] = "application/json"

    def ask_disabled(self, cfin):
        url = f"{self.BASE_URL}/instrument/{cfin}"
        try:
            r = self.get(url)
            r.raise_for_status()
            data = r.json()
            if data:
                return data["eraseAsk"]
        except:
            return False

    @cache.memoize(timeout=43200)
    def multi_ask_disabled(self, cfins):
        url = f"{self.BASE_URL}/instrument/getInstruments"
        try:
            r = self.post(url, data=json.dumps(cfins))
            r.raise_for_status()
            data = r.json()
            return {x["cfin"]: x.get("eraseAsk", False) for x in data}
        except:
            return {cfin: False for cfin in cfins}


class ContribHisto(Session):
    """API connection to the Contrib Service

    Swagger: http://contrib/contrib-histo/swagger-ui.html

    """

    BASE_URL = "http://contrib/contrib-histo/"

    def __init__(self):
        super().__init__()

        # Add elements in the header
        self.headers["username"] = "bichon_p"
        self.headers["Content-Type"] = "application/json"

    def intraday_history(self, cfin):
        url = f"{self.BASE_URL}/intraday-history/{cfin}"
        data = {
            "from": dt_today().strftime("%Y-%m-%d"),
            "to": next_bday(1).strftime("%Y-%m-%d"),
        }
        r = self.get(url, params=data)
        r.raise_for_status()

        data = r.json()
        if data:
            prices = data.get("intradayPriceHistories")

            if prices:
                df = pd.DataFrame(prices)

                # Filter if the level is publishable only
                df = df[df.publishable]

                # Convert column timestamp to datetime
                df.timestamp = pd.to_datetime(df.timestamp)

                # Return a subset of columns and renames the desired ones
                return df[["cfin", "timestamp", "bid", "ask", "theorical",]]

    def intraday_last(self, cfins, start_date=None, end_date=None):
        url = f"{self.BASE_URL}get-last-intraday-as-close"

        start_date = start_date or prev_bday()
        end_date = end_date or next_bday()

        params = {
            "from": start_date.strftime("%Y-%m-%d"),
            "to": end_date.strftime("%Y-%m-%d"),
        }

        df = pd.DataFrame()

        try:
            r = self.post(url, params=params, data=json.dumps(cfins))

            r.raise_for_status()

            data = r.json()
            if data:
                prices = data.get("lastIntradayAsCloses")

                if prices:
                    df = pd.DataFrame(prices)

                    # Convert column timestamp to datetime
                    df.timestamp = pd.to_datetime(df.timestamp)

                    # Return a subset of columns and renames the desired ones
                    columns = [
                        "cfin",
                        "timestamp",
                        "bid",
                        "ask",
                        "theo",
                    ]
                    df = df[columns]

        except exceptions.HTTPError:
            msg = f"Could not get the price contribution for {cfins}"
            app.logger.exception(msg)

        except (Exception,):
            msg = f"Issue getting live contrib for {cfins}"
            app.logger.exception(msg)

        finally:
            return df

    def trading_margins(self, cfin, value_date=None):
        url = f"{self.BASE_URL}/margin-details/{cfin}"

        value_date = value_date or prev_bday()

        params = {
            "value-date": value_date.strftime("%Y-%m-%d"),
        }

        try:
            r = self.get(url, params=params)
            r.raise_for_status()
            return r.json()

        except exceptions.HTTPError:
            msg = f"Could not get the margin details for {cfin}"
            app.logger.exception(msg)

        except (Exception,):
            msg = f"Issue getting margin details for {cfin}"
            app.logger.exception(msg)


if __name__ == "__main__":

    cfins = [38141550, 19779636, 48535971, 39766650, 659453, 37172323]

    with app.server.app_context():

        c = ContribInstrument()
        data = c.multi_ask_disabled(cfins)

        contrib = ContribHisto()
        contrib.trading_margins(cfin=49230822)
        contrib.intraday_last([550389, 550217])

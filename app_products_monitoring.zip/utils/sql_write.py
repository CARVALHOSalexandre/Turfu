import os
from app import server
from models.base import *
from sqlalchemy.exc import SQLAlchemyError
from flask_login import current_user
from utils.basics import dt_today
from datetime import datetime as dt


def user_is_structurer(func):
    def foo(*args, **kwargs):

        # If user is not logged then the function is used locally
        debug = False
        if not current_user:
            debug = True
            user = os.environ.get("USERNAME")

        else:
            user = current_user.username

        if (
            debug
            or "STR" in current_user.department_id
            or "DCO" in current_user.department_id
            or "TDS" in current_user.department_id
            or "TDO" in current_user.department_id
        ):
            func(*args, **kwargs)
            msg = f"User {user} made an update"
            if args:
                msg = msg + f" - Args: {args}"
            if kwargs:
                msg = msg + f" - Kwargs: {kwargs}"
            server.logger.info(msg)
            return True
        else:
            msg = f"User {user} tried an update"
            if args:
                msg = msg + f" - Args: {args}"
            if kwargs:
                msg = msg + f" - Kwargs: {kwargs}"
            server.logger.warning(msg)
            return False

    return foo


def db_safe_commit(func):
    @user_is_structurer
    def persist(*args, **kwargs):
        func(*args, **kwargs)
        try:
            db.session.commit()
            return True
        except SQLAlchemyError as e:
            server.logger.error(e.args)
            db.session.rollback()
            return False

    return persist


@user_is_structurer
def safe_commit():
    try:
        db.session.commit()
        return True
    except SQLAlchemyError as e:
        server.logger.error(e.args)
        db.session.rollback()
        return False


@db_safe_commit
def insert_or_update(table_object):
    return db.session.merge(table_object)


def insert_or_update_code(cfin, value, kind, market=None, quotation_mode=None):

    # Define the source of the code
    d_code = {"isin": 6, "ticker": 11, "issuer_ric": 334, "issuer_ref": 335}
    source = d_code[kind]

    # Check if a code exists for the source
    code = Codes.query.filter(Codes.cfcfin == cfin, Codes.cfsource == source).first()
    if code:
        code.cfcode = value
        return True

    # Check if the code is already given to another Cfin
    r = Codes.query.filter(Codes.cfcode == value, Codes.cfsource == source).first()
    if r:
        if cfin != r.cfcfin:
            # Delete the Code for the old cfin
            db.session.delete(r)
            db.session.commit()

    # Get the Market on which the product is quoting
    cotation = Cotation.query.filter_by(cotcfin=cfin).first()
    if cotation:
        market = cotation.cotmarche

    # Get the Quotation Mode of the product
    produit = Produit.query.filter_by(prcfin=cfin).first()
    if produit:
        quotation_mode = produit.prmodecot

    new_code = Codes(
        cfcfin=cfin,
        cfsource=source,
        cfcode=value,
        cfmarche=market,
        cfmodecot=quotation_mode,
        cftype=0,  # "Descriptif"
        cfrecup=0,  # "Automatic"
    )

    db.session.add(new_code)

    return safe_commit()


@db_safe_commit
def update_product_status(cfin, status="inactive"):
    d_status = {"inactive": 22, "autocall": 22, "active": 23}
    d_livestatus = {"inactive": 3, "autocall": 4, "active": 1}

    # Update field ifstatut in exane.instruments
    instrument = Instrument.query.filter_by(ifcfin=cfin).first()
    instrument.ifstatut = d_status[status]

    # Update field icetatdevie in exane.instrumentcomplement
    complement = Instrumentcomplement.query.filter_by(iccfin=cfin).first()
    complement.icetatdevie = d_livestatus[status]

    return True


@db_safe_commit
def update_alien(cfin_primary, cfin_secondary, type_alien):

    # Check is alien already exists
    r = Alien.query.filter(
        Alien.alsjac == cfin_primary,
        Alien.alcfin == cfin_secondary,
        Alien.altype == type_alien,
    ).all()
    if r:
        # Alien already exists away
        # No need to update
        return True

    # Update Alien
    db.session.query(Alien).filter(
        Alien.alsjac == cfin_primary, Alien.altype == type_alien
    ).update({"alcfin": cfin_secondary})

    return True


@db_safe_commit
def add_alien(cfin_primary, cfin_secondary, type_alien):
    alien = Alien(
        alcfin=cfin_secondary, alsjac=cfin_primary, altype=type_alien, almaj=dt_today()
    )
    db.session.add(alien)
    return True


@db_safe_commit
def delete_alien(cfin_primary, cfin_secondary, type_alien):
    alien = Alien(
        alcfin=cfin_secondary, alsjac=cfin_primary, altype=type_alien, almaj=dt_today()
    )
    db.session.delete(alien)
    return True


@db_safe_commit
def delete_lines_in_collection(cfin_collection):
    rows = Collection.query.filter_by(clcollect=cfin_collection).all()

    for row in rows:
        db.session.delete(row)

    return True


@db_safe_commit
def insert_line_in_collection(cfin_collection, cfin_sjac, date_in, date_out):

    data = Collection(
        clcollect=cfin_collection,
        clsjac=cfin_sjac,
        cldatein=date_in,
        cldateout=date_out,
        cldiviseur=1,
    )

    db.session.add(data)

    return True


if __name__ == "__main__":

    with server.app_context():

        cfin_collection = 37277820
        cfin_sjac = 37375386
        date_in = dt(2019, 12, 19)
        date_out = dt(2020, 4, 2)

        date_in = dt(2021, 1, 15)
        date_out = None

        insert_line_in_collection(cfin_collection, cfin_sjac, date_in, date_out)

        delete_line_in_collection(cfin_collection, cfin_sjac)

        cfin = 45011763

        instrument = Instrument.query.filter_by(ifcfin=cfin).first()
        complement = Instrumentcomplement.query.filter_by(iccfin=cfin).first()

        # update_product_status(cfin, status="active")

        insert_or_update_code(cfin, value="TEST", kind="issuer_ric")

        isin_details = (
            db.session.query(Codes.cfcode, Codes.cfmarche, Codes.cfmodecot)
            .filter(Codes.cfcfin == cfin, Codes.cfsource == 6)
            .first()
        )

        new_ref = Codes(
            cfcfin=cfin,
            cfsource=335,
            cfcode="test2",
            cfmarche=isin_details.cfmarche,
            cfmodecot=isin_details.cfmodecot,
            cftype=0,  # "Descriptif"
            cfrecup=0,  # "Automatic"
        )

        db.session.query(Codes).filter(
            Codes.cfcfin == cfin, Codes.cfsource == 335
        ).update({Codes.cfcode: "test12"})
        db.session.commit()

        insert_or_update(new_ref)

        print(
            db.session.query(Codes.cfcode)
            .filter(Codes.cfcfin == cfin, Codes.cfsource == 335)
            .first()
        )

        issuer_ric = (
            db.session.query(Codes.cfcode)
            .filter(Codes.cfcfin == cfin, Codes.cfsource == 334)
            .first()
        )

        if issuer_ric:
            code_ric = issuer_ric.cfcode

        issuer_ref = (
            db.session.query(Codes.cfcode)
            .filter(Codes.cfcfin == cfin, Codes.cfsource == 335)
            .first()
        )

        if issuer_ref:
            code_ref = issuer_ref.cfcode

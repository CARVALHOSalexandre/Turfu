import requests as rq
from app import cache


class Positions(rq.Session):
    BASE_URL = "http://pott:8070/book-security-positions"

    def __init__(self):
        super().__init__()

    def book_positions(self, cfins):
        r = self.post(self.BASE_URL, json={"instrumentIds": cfins})
        r.raise_for_status()
        j = r.json()
        if j:
            return j["bookSecurityPositions"]

    def positions_for_cfin(self, cfin, date=None):
        json = {"instrumentIds": [cfin]}
        if date:
            json["positionDate"] = date.strftime("%Y-%m-%d")
        r = self.post(self.BASE_URL, json=json)
        r.raise_for_status()
        j = r.json()
        if j:
            return j["bookSecurityPositions"]

    @cache.memoize(timeout=3600)
    def positions_for_cfins(self, cfins: list, date=None):
        json = {"instrumentIds": cfins}
        if date:
            json["positionDate"] = date.strftime("%Y-%m-%d")
        r = self.post(self.BASE_URL, json=json)
        r.raise_for_status()
        j = r.json()
        if j:
            return j["bookSecurityPositions"]


if __name__ == "__main__":
    cfins = [45336529]
    positions = Positions().book_positions(cfins)

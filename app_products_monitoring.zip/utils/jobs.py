from emails.mail_sender import *
from utils.ftp_upload import *
from models.storing import *

from utils.certif_delta import update_deltas
from utils.mail_watcher import mail_rfq_monitoring, update_pricing_results_db


def weekly_email_last_opinions():
    with server.app_context():
        try:
            MailLastOpinions()
        except Exception as e:
            msg = "Mail Sender | Last Opinions"
            app.logger.exception(msg)
            MailNotification(f"Error - Email Last Opinions", e)


def daily_email_contrib_issues():
    with server.app_context():
        try:
            MailContrib()
        except Exception as e:
            msg = "Mail Sender | Contrib Issues"
            app.logger.exception(msg)
            MailNotification(f"Error - Contrib Issues", e)


def daily_email_products_events():
    with server.app_context():
        try:
            MailEvents()
        except Exception as e:
            msg = "Mail Sender | Events"
            app.logger.exception(msg)
            MailNotification(f"Error - Mail Events", e)


def weekly_email_trades():
    with server.app_context():
        try:
            MailTrades()
        except Exception as e:
            msg = "Mail Sender | Trades Report"
            app.logger.exception(msg)
            MailNotification(f"Error - Email Trades", e)


def weekly_email_italian_listed_trades():
    with server.app_context():
        try:
            MailItalianListedMarket()
        except Exception as e:
            msg = "Mail Sender | Italian Listed Market"
            app.logger.exception(msg)
            MailNotification(f"Error - Email Italian Listed Market", e)


def weekly_email_autocall():
    with server.app_context():
        try:
            MailAutocall()
        except Exception as e:
            msg = "Mail Sender | Autocall Probabilities"
            app.logger.exception(msg)
            MailNotification(f"Error - Email Autocall", e)


def weekly_email_pricing_runs():
    with server.app_context():
        try:
            MailPricing()
        except Exception as e:
            msg = "Mail Sender | Pricing Runs"
            app.logger.exception(msg)
            MailNotification(f"Error - Email Pricing Runs", e)


def weekly_email_minifuts():
    with server.app_context():
        try:
            MailMiniFutures()
        except Exception as e:
            msg = "Mail Sender | MiniFutures Report"
            app.logger.exception(msg)
            MailNotification(f"Error - Email MiniFutures", e)


def daily_website_update():
    with server.app_context():
        try:
            website_update()
        except Exception as e:
            msg = "SFTP Request | Website Update"
            app.logger.exception(msg)
            MailNotification(f"Error - Website Update", e)


def weekly_email_rfq():
    with server.app_context():
        try:
            MailRFQ()
        except Exception as e:
            msg = "Mail Sender | RFQ Report"
            app.logger.exception(msg)
            MailNotification(f"Error - Email RFQ Report", e)


def daily_email_alert_listed_inventory():
    with server.app_context():
        try:
            MailControlListedInventory()
        except Exception as e:
            msg = "Mail Sender | Alert Listed Inventory"
            app.logger.exception(msg)
            MailNotification(f"Error - Email Alert Listed Inventory", e)


def daily_email_bnp_interactions():
    with server.app_context():
        try:
            MailBNPInteractions()
        except Exception as e:
            msg = "Mail Sender | BNP Interactions"
            app.logger.exception(msg)
            MailNotification(f"Error - Email BNP Interactions", e)


def daily_delta_certif_update():
    with server.app_context():
        try:
            update_deltas()
        except Exception as e:
            msg = "Delta Certificates Update"
            app.logger.exception(msg)
            MailNotification(f"Error - Delta Certificates Update", e)


def daily_email_cash_flex_orders():
    with server.app_context():
        try:
            MailAMCCashOrders()
        except Exception as e:
            msg = "Flex Orders vs Cash"
            app.logger.exception(msg)
            MailNotification(f"Error - Email Flex Orders vs Cash", e)


def live_monitoring():
    with server.app_context():
        try:
            mail_rfq_monitoring()
        except Exception as e:
            msg = f"Live RFQ Monitoring | {e}"
            app.logger.exception(msg)
        try:
            update_pricing_results_db()
        except Exception as e:
            msg = f"Live Pricing Result | {e}"
            app.logger.exception(msg)


def cache_reload():
    with server.app_context():

        feedback = {}

        try:
            cache.clear()
        except Exception as e:
            msg = "Cache Reload | Clearing Cache"
            app.logger.exception(msg)
            feedback["Clear Cache"] = str(e)

        try:
            cache.delete_memoized(cached_data_missing_contrib)
            cached_data_missing_contrib()
        except Exception as e:
            msg = "Cache Reload | Contrib Issues"
            app.logger.exception(msg)
            feedback["Contrib Issues"] = str(e)

        try:
            cache.delete_memoized(cached_ytd_trades)
            cached_ytd_trades()
        except Exception as e:
            msg = "Cache Reload | YTD Trades"
            app.logger.exception(msg)
            feedback["YTD Trades"] = str(e)

        try:
            cache.delete_memoized(cached_trades_and_products)
            cached_trades_and_products()
        except Exception as e:
            msg = "Cache Reload | Trades & Products"
            app.logger.exception(msg)
            feedback["Trades & Products"] = str(e)

        try:
            cache.delete_memoized(cached_products_histo)
            cached_products_histo()
        except Exception as e:
            msg = "Cache Reload | Backtest underlyings"
            app.logger.exception(msg)
            feedback["Backtest underlyings"] = str(e)

        # Send Notif if there are any errors
        if feedback:
            MailNotification("Cache Reload Issue", feedback)

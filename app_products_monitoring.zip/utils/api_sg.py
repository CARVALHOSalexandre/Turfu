from dotenv import load_dotenv
from utils.sql import *
from utils.basics import *
import urllib3
import requests as rq
from utils.exceptions import ApiPricingConnectionError
from app import app

dico_sg = {
    "frequency": {
        "1M": "OnePerMonth",
        "2M": "SixPerYear",
        "3M": "FourPerYear",
        "6M": "TwoPerYear",
        "12M": "OnePerYear",
    },
    "barrier_type": {
        "European": "European",
        "US Intraday": "USIntraday",
        "US Close": "USClose",
        "None": "None",
    },
    "cpn_type": {"Memory": "Memory", "Fixed": "Guaranteed", "At Risk": "Digit"},
}


@cache.cached(timeout=86400, key_prefix="sg")
def cached_sg_underlying_universe():
    app.logger.info("Caching SG Underlying Universe")
    return SGPricer().underlying_universe()


class SGPricer(rq.Session):
    BASE_URL = "https://sp-api.sgmarkets.com/api/v1/"
    TOKEN_ENDPOINT = "https://sso.sgmarkets.com/sgconnect/oauth2/access_token"
    SCOPES = [
        "openid",
        "profile",
        "api.sgmarkets-execution-structured-products.v1",
    ]

    frequencies = {
        "OnePerYear": {"coeff": 1, "name": "Annual"},
        "TwoPerYear": {"coeff": 2, "name": "Semi-Annual"},
        "FourPerYear": {"coeff": 4, "name": "Quarterly"},
        "OnePerMonth": {"coeff": 12, "name": "Monthly"},
        "SixPerYear": {"coeff": 6, "name": "Every Two Months"},
        "TwelvePerYear": {"coeff": 12, "name": "Monthly"},
    }

    names_payoffs = {
        "Autocall": "Autocall",
        "PhoenixPlus": "Autocall Memory",
        "ReverseConvertible": "Reverse",
        "BarrierReverseConvertible": "Reverse",
    }

    def __init__(self):
        load_dotenv()

        self.client_id = self._get_env_client_id()
        self.client_secret = self._get_env_client_secret()

        self.pricing_results = []

        self.access_token = None
        self.access_token_start_time = None
        self.access_token_valid_time = None

        super(SGPricer, self).__init__()

        # Set default pricing parameters
        self.params = self._default_pricing_parameters()

        self._get_access_token()

    @staticmethod
    def _default_pricing_parameters():
        """Set default pricing parameters"""
        return {
            "wrapper": "Note",
            "notional": 300000,
            "reoffer": 98.5,
            "strike": 100,
            "maturity_in_months": 36,
            "frequency": "FourPerYear",
            "barrier_type": "European",
            "ki_barrier": 60,
            "cpn_type": "Guaranteed",
            "cpn_barrier": 0,
            "atk_barrier": 100,
            "atk_start_period": 4,
        }

    @staticmethod
    def _get_env_client_id():
        val = os.environ.get("SG_API_ID")
        if not val:
            raise ApiPricingConnectionError("missing client_id")
        return val

    @staticmethod
    def _get_env_client_secret():
        val = os.environ.get("SG_API_PASS")
        if not val:
            raise ApiPricingConnectionError("missing client_secret")
        return val

    def _get_access_token(self):

        # Disable Certificate Verification Warning
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        r = rq.post(
            self.TOKEN_ENDPOINT,
            verify=False,
            auth=(self.client_id, self.client_secret),
            data={"grant_type": "client_credentials", "scope": " ".join(self.SCOPES)},
        )
        r.raise_for_status()
        content = r.json()
        assert content["access_token"], "No access_token returned by SG Connect"

        now = dt.now()
        self.access_token = content["access_token"]
        self.access_token_start_time = now
        self.access_token_valid_time = now + datetime.timedelta(
            seconds=content["expires_in"]
        )

        # msg = "SG API | New access_token valid until {}".format(
        #     self.access_token_valid_time.strftime("%H:%M:%S")
        # )
        # app.logger.info(msg)

        self.headers = {"Authorization": f"Bearer {self.access_token}"}

    def _refresh_access_token(self, force=False, seconds_before_valid_time=30):
        if force:
            app.logger.info("force refresh access_token")
            self._get_access_token()
            return

        now = dt.now()

        # seconds_before_valid_time cannot be negative and is set to zero
        if seconds_before_valid_time < 0:
            seconds_before_valid_time = 0

        if now > self.access_token_valid_time - timedelta(
            seconds=seconds_before_valid_time
        ):
            nb_sec_before_valid_time = (self.access_token_valid_time - now).seconds
            msg = f"Refresh access_token {nb_sec_before_valid_time}s before valid time"
            app.logger.info(msg)
            self._get_access_token()

    @staticmethod
    def _subtype(params):
        payoff = params.get("payoff", "Autocall")
        cpn_type = params.get("cpn_type", "Memory")
        d_subtype = {
            "Autocall": {
                "Memory": "PhoenixPlus",
                "Guaranteed": "PhoenixWithGuaranteedCoupons",
                "Digit": "Phoenix",
            },
            "Reverse": {
                "Guaranteed": "BarrierReverseConvertible",
                "Digit": "BarrierReverseWithConditionalCoupons",
            },
        }
        return d_subtype[payoff].get(cpn_type)

    @cache.memoize(timeout=86400)
    def underlying_universe(self, formatting=None):
        r = self.get(self.BASE_URL + "underlying-universe")

        if r.status_code == 200:
            j = r.json()
            if formatting == "df":
                return pd.DataFrame(j["EquityUnderlyings"])
            return j

        if r.status_code == 429:
            wait_time = int(r.headers["retry-after"])
            app.logger.info(f"Waiting: {wait_time}s")
            time.sleep(wait_time)
            app.logger.info("waited: " + str(wait_time) + "s")
            return self.underlying_universe()

        if r.status_code == 401:
            wait_time = 60
            app.logger.info(f"Waiting: {wait_time}s")
            time.sleep(wait_time)
            app.logger.info("waited: " + str(wait_time) + "s")
            return self.underlying_universe()

        app.logger.warning(r)
        raise ApiPricingConnectionError(f"API response: {r.status_code}")

    def corresponding_tickers(self, tickers: list):
        """Correspondences between user's ticker and SG's are made through Reuters codes"""

        # Extend search to all tickers extensions
        exchanges = {
            "usa": ["UN", "US", "UW", "UQ"],
            "spain": ["SM", "SQ"],
            "germany": ["GY", "GR"],
            "switzerland": ["SE", "SW"],
        }

        all_tickers = [(x, x) for x in tickers]

        for ticker in tickers:
            split = ticker.split(" ")
            if len(split) == 2:
                for cntry in exchanges:
                    if split[1] in exchanges[cntry]:
                        other_extensions = [f"{split[0]} {x}" for x in exchanges[cntry]]
                        tickers = [(ticker, x) for x in other_extensions if x != ticker]
                        all_tickers.extend(tickers)

        df = pd.DataFrame(all_tickers, columns=["ticker", "ticker_sg"])

        # Get underlying universe from SG's server
        data = cached_sg_underlying_universe()
        df_sg = pd.DataFrame(data["EquityUnderlyings"])
        if not isinstance(df_sg, pd.DataFrame):
            df_sg = pd.DataFrame(df_sg["EquityUnderlyings"])
        df_sg = df_sg[["BloombergTickerCode", "Name", "Type"]]
        df_sg.columns = ["ticker_sg", "name_sg", "type_sg"]

        dff = pd.merge(df, df_sg, on="ticker_sg")

        d_types = {
            "IndexEquity": "Index",
            "ShareOrdinary": "Share",
        }

        # Change SG's terminology for types
        dff["type_sg"] = dff["type_sg"].apply(lambda x: d_types.get(x, x))

        # Put each first letter as capital if type Share
        cap_first_char = (
            lambda x: x["name_sg"].title() if x["type_sg"] == "Share" else x["name_sg"]
        )
        dff["name_sg"] = dff.apply(cap_first_char, axis=1)

        return dff

    def description_payoff(self, payoffs, **kwargs):

        d = {**self.params, **kwargs}

        sg_frequency = dico_sg["frequency"].get(d["frequency"], d["frequency"])
        frequency = self.frequencies.get(sg_frequency).get("name")

        d_str = {
            "frequency": f"{frequency} Obs",
            "wrapper": f"{d['wrapper']}",
            "reoffer": f"Reoffer {d['reoffer'] / 100:.2%}",
            "notional": f"Size {d['notional']:,}",
            "maturity": f"{d['maturity_in_months']} months",
            "barrier": f"{d['barrier_type']} Barrier {d['ki_barrier'] / 100:.0%}",
            "cpn_type": f"{d['cpn_type']}",
            "cpn_barrier": f"Cpn Barrier {d['cpn_barrier'] / 100:.0%}",
            "autocall": f"{d['atk_barrier'] / 100:.0%} from {frequency[0]}{d['atk_start_period']}",
            "comment": "Coupons are p.a.",
        }

        details = {
            "Autocall": ["cpn_type", "frequency", "autocall", "cpn_barrier", "barrier"],
            "Reverse": ["frequency", "barrier"],
            "Format": ["wrapper", "maturity", "reoffer", "notional", "comment"],
        }

        result = {"Format": ", ".join([d_str[x] for x in details["Format"]])}

        for name in [x.capitalize() for x in payoffs]:
            result[name] = name + " : " + ", ".join([d_str[x] for x in details[name]])

        return result

    @staticmethod
    def description_request(data):
        d = data["variationParameters"]
        wrapper = d["wrapper"]
        maturity = d["maturityValue"]["currentValue"]["value"]
        payoff = d["productSubtype"]
        ccy = d["currency"]
        underlyings = ", ".join([x["id"] for x in d["underlying"]])
        return f"{wrapper} - {maturity}m {payoff} in {ccy} on {underlyings}"

    def api_waiting(self, seconds_wait_time, data):
        description = self.description_request(data)
        app.logger.info(f"Waiting {seconds_wait_time}s - Next request: {description}")
        time.sleep(int(seconds_wait_time) + 1)
        app.logger.info(" - Done waiting")

    def get_json_request(self, quote_id):
        r = self.get(self.BASE_URL + f"quote-request/{quote_id}")
        print(r.json())

    def post_price_request(self, data):
        r = self.post(self.BASE_URL + "quotes", json=data,)

        if r.status_code == 200:
            description = self.description_request(data)
            msg = f"SG API | {data['pricing_id']} - Post Sent: Quote ID {r.json()['QuoteId']} - Details: {description}"
            app.logger.info(msg)
            return [r.json()["QuoteId"], None]

        if r.status_code == 429:
            wait_time = r.headers["retry-after"]
            self.api_waiting(wait_time, data)
            return self.post_price_request(data)

        if r.status_code == 400:
            msg = f"SG API | {r.json()}"
            app.logger.info(msg)
            return [None, r.json()]

        if r.status_code in [502, 504]:  # Bad Gateway & Gateway Timeout
            self.api_waiting(15, data)
            return self.post_price_request(data)

        # 401 Error - Not authorized, refresh the token
        if r.status_code == 401:
            self._refresh_access_token()
            return self.post_price_request(data)

        raise Exception(f"API response: {r.status_code}")

    def get_price(self, quote_id, time_sent):

        # Control if at least 10 sec elapsed since pricing was sent
        seconds_elapsed = (dt.now() - time_sent).seconds
        if seconds_elapsed < 20:
            time.sleep(20 - seconds_elapsed)

        r = self.get(self.BASE_URL + f"quote/{quote_id}")

        if r.status_code == 200:
            if r.json().get("Status") == "Quoted":
                return r.json()["Data"]["SolveResult"]

            if r.json().get("Status") in ["Failed", "Rejected"]:
                return

            time.sleep(20)

            return self.get_price(quote_id, time_sent)

        if r.status_code == 429:
            wait_time = int(r.headers["retry-after"])
            app.logger.info(f"Waiting {wait_time}s")
            time.sleep(wait_time)
            app.logger.info(f"Done waiting")
            return self.get_price(quote_id, time_sent)

        # 404 Error - If Quote ID not found
        if r.status_code == 404:
            if f"{quote_id} not found" in r.json():
                time.sleep(5)
                return

        # 401 Error - Not authorized, refresh the token
        if r.status_code == 401:
            self._refresh_access_token()
            return
            # return self.get_price(quote_id, time_sent)

        # 503 Error - SG Service Down
        if r.status_code == 503:
            self._refresh_access_token()
            return self.get_price(quote_id, time_sent)

        msg = f"API response: {r.status_code} - {r.content}"
        app.logger.warning(msg)
        raise Exception(f"API response: {r.status_code}")

    def send_pricing_requests(self, templates):

        for x in templates:
            lst_underlyings = [y["id"] for y in x["variationParameters"]["underlying"]]
            underlyings = ", ".join(lst_underlyings)
            self._refresh_access_token()
            try:
                sg_pricing_id = self.post_price_request(x)[0]
                data = {
                    "quote_details": x["variationParameters"],
                    "quote_id": sg_pricing_id,
                    "underlying": underlyings,
                    "result": None,
                    "time_sent": dt.now(),
                    "pricing_id": x["pricing_id"],
                }
                self.pricing_results.append(data)
            except Exception as e:
                msg = "Issue in Post Request"
                app.logger.exception(msg)

    def get_pricing_results(self):
        for x in self.pricing_results:
            if not x["result"]:
                self._refresh_access_token()
                try:
                    x["result"] = self.get_price(x["quote_id"], x["time_sent"])
                    msg = f"SG API | Success to retrieve {x['quote_id']} - Sent {x['time_sent']}"
                    app.logger.info(msg)
                except Exception as e:
                    msg = f"SG API | Issue getting the price for {x['quote_id']} - Sent {x['time_sent']}"
                    app.logger.exception(msg)

    @staticmethod
    def worst_of_combinations(tickers: list, number: int):
        assert len(tickers) >= number, "there should be more tickers than number"
        return list(itertools.combinations(tickers, number))

    def template_autocall(self, tickers, ccy, **kwargs):

        params = {**self.params, **kwargs}

        if not isinstance(tickers, (list, tuple)):
            tickers = [tickers]

        underlyings = [{"id": ticker, "idType": "Bloomberg"} for ticker in tickers]

        data = {
            "variationParameters": {
                "underlying": underlyings,
                "optionType": params.get("option_type", "WorstOf"),
                "currency": ccy,
                "offerPrice": params["reoffer"],
                "productType": "Autocall",
                "productSubtype": params.get("sg_subtype", "PhoenixPlus"),
                "wrapper": params["wrapper"],
                "maturityValue": {
                    "currentValue": {
                        "value": params["maturity_in_months"],
                        "unit": "Month",
                    }
                },
                "solvingMode": "ConditionalAndRecallCoupons",
                "remunerationMode": "Reoffer",
                "settlementType": "Cash",
                "strikeMode": "Close",
                "issuePricePercent": 100,
                "notionalAmount": params["notional"],
                "strike": params["strike"],
                "kiBarrierType": params["barrier_type"],
                "kiBarrier": params["ki_barrier"],
                "couponType": params["cpn_type"],
                "couponFrequency": dico_sg["frequency"].get(
                    params["frequency"], params["frequency"]
                ),
                "couponBarrier": params["cpn_barrier"],
                "recallStartPeriod": params["atk_start_period"],
                "recallThreshold": params["atk_barrier"],
                "settlementOffset": 5,
                "scheduleDrivenBy": "ValuationDates",
                "scheduleGeneration": "Forward",
                "denomination": 1000,
                "issuePriceDefinition": "Percent",
                "priceType": "Dirty",
            },
            "pricing_id": params.get("pricing_id"),
        }
        return data

    def template_reverse(self, tickers: list, ccy: str, **kwargs):

        params = {**self.params, **kwargs}

        if not isinstance(tickers, (list, tuple)):
            tickers = [tickers]

        underlyings = [{"id": ticker, "idType": "Bloomberg"} for ticker in tickers]

        data = {
            "variationParameters": {
                "underlying": underlyings,
                "optionType": params.get("type", "Reverse"),
                "currency": ccy,
                "offerPrice": params["reoffer"],
                "productType": "ReverseConvertible",
                "productSubtype": "BarrierReverseConvertible",
                "wrapper": params["wrapper"],
                "maturityValue": {
                    "currentValue": {
                        "value": params["maturity_in_months"],
                        "unit": "Month",
                    }
                },
                "solvingMode": "CouponValue",
                "notionalAmount": params["notional"],
                "remunerationMode": "Reoffer",
                "strikeMode": "Close",
                "strike": params["strike"],
                "kiBarrierType": params["barrier_type"],
                "kiBarrier": params["ki_barrier"],
                "couponFrequency": dico_sg["frequency"].get(
                    params["frequency"], params["frequency"]
                ),
            },
            "pricing_id": params.get("pricing_id"),
        }
        return data

    def get_template(self, payoff):

        d_payoffs = {
            "autocall": self.template_autocall,
            "reverse": self.template_reverse,
        }

        return d_payoffs.get(payoff)

    def coupon_pa(self, x):
        """Returns per anum coupon for a given price result"""

        # In case quote is rejected return None
        if not x["result"]:
            return

        sg_frequency = x["quote_details"]["couponFrequency"]
        frequency = self.frequencies.get(sg_frequency).get("coeff")
        coupon = x["result"]

        return coupon * frequency

    @timeit
    def get_prices_pricer(self, parameters):
        templates = []
        for params in parameters:
            # Adapt params names with SG's names
            for field in params:
                if field in dico_sg:
                    value = params[field]
                    sg_value = dico_sg[field].get(value, value)
                    params[field] = sg_value
            params["sg_subtype"] = self._subtype(params)
            payoff = params["payoff"].lower()
            templates.append(self.get_template(payoff)(**params))

        # Send price requests to SG's servers
        try:
            self.send_pricing_requests(templates)
        except Exception as e:
            msg = "Issue sending templates to SG servers"
            app.logger.exception(msg)

        try:
            # Get the pricing results from the Quote IDs
            self.get_pricing_results()

            msg = f"SG API | Results " + ", ".join(
                [
                    f"{x['pricing_id']}, {x['quote_id']}, Result: {x['result']:.2f}%"
                    for x in self.pricing_results
                ]
            )
            app.logger.info(msg)

            return [
                {
                    "pricing_id": x["pricing_id"],
                    "sg_cpn_pa": self.coupon_pa(x),
                    "sg_id": x["quote_id"],
                    "sg_timestamp": dt.now(),
                }
                for x in self.pricing_results
            ]

        except Exception as e:
            msg = "Issue to get the prices from SG"
            app.logger.exception(msg)

    def _generate_templates(self, combinations, currencies, payoffs, **kwargs):
        # Generate a list of templates
        templates = []
        for tickers in combinations:
            for ccy in currencies:
                for payoff in payoffs:
                    templates.append(self.get_template(payoff)(tickers, ccy, **kwargs))
        return templates

    @timeit
    def get_prices_combinations(
        self, tickers, currencies, nb_ul=1, payoffs=None, **kwargs
    ):

        if not payoffs:
            payoffs = ["autocall", "reverse"]

        # Get corresponding SG's tickers
        df_tickers = self.corresponding_tickers(tickers)

        # Create list of combinations
        combinations = self.worst_of_combinations(df_tickers.ticker_sg, nb_ul)
        templates = self._generate_templates(
            combinations, currencies, payoffs, **kwargs
        )

        # Send price requests to SG's servers
        try:
            self.send_pricing_requests(templates)
        except Exception as e:
            app.logger.info(repr(e))

        # Get the pricing results from the Quote IDs
        try:
            self.get_pricing_results()
        except Exception as e:
            app.logger.info(repr(e))

        results = [
            {
                "type": self.names_payoffs.get(x["quote_details"]["productType"]),
                "ccy": x["quote_details"]["currency"],
                "underlyings": x["underlying"],
                "coupon": self.coupon_pa(x),
                "quote_id": x["quote_id"],
            }
            for x in self.pricing_results
        ]

        df = pd.DataFrame(results)

        # Reset list of pricing details in case user needs more runs
        self.pricing_results = []

        df_result = df.pivot_table(
            index="underlyings", columns=["type", "ccy"], values="coupon"
        )

        df_ids = df.pivot_table(
            index="underlyings",
            columns=["type", "ccy"],
            values="quote_id",
            aggfunc="first",
        )

        # Sort results by first payoff and first currency
        df_result = df_result.sort_values(by=df_result.columns[0], ascending=False)

        # Keep only tickers that are in the results and sort results
        df_tickers = df_tickers.loc[df_tickers.ticker.isin(df_result.index)]
        df_tickers = df_tickers.sort_values(by="ticker")

        details = {
            "payoffs": [x.capitalize() for x in payoffs],
            "currencies": currencies,
            "descriptions": self.description_payoff(payoffs, **kwargs),
            "underlyings": df_tickers,
        }

        return df_result, df_ids, details

    @timeit
    def pricing_run_with_details(
        self, currencies=None, tickers=None, theme=None, **kwargs
    ):

        msg = "Give at least a list tickers or a thematic"
        assert tickers is not None or theme is not None, msg

        if not currencies:
            currencies = ["EUR", "USD"]

        df_input = pd.DataFrame(data=tickers, columns=["ticker"])

        if theme == "bnpp_opinions":
            # Get Exane last opinions: Outperform
            df_input = last_opinions_bnpp(bdays=kwargs.get("bdays_of_bnpp_opinions", 5))

        elif theme == "apollo":
            df_input = amc_composition(cfin=42048123)

        df_tickers = self.corresponding_tickers(df_input.ticker)

        df = pd.merge(df_input, df_tickers, on="ticker")
        df = df.set_index("ticker_sg")

        # Prepare list of payoff template
        # Selection is made on the top 10 Exane opinions with best volatilities
        tickers = df.index

        # Get prices from SG's servers
        df_result, df_ids, details = self.get_prices_combinations(
            tickers, currencies, **kwargs
        )

        # Add Volatilities, Dividends and Upside to pricing results
        for col in ["IV_12M_100%", "next_div_yield", "upside"]:
            d_names = {
                "IV_12M_100%": "IV 12m",
                "next_div_yield": "Div 12m",
                "upside": "Upside 12m",
            }
            if col in df.columns:
                df_result.loc[:, d_names.get(col)] = df[col]

        return df_result, df_ids, details


if __name__ == "__main__":
    # Display more columns when printing a Pandas DataFrame
    pd.options.display.width = 800
    pd.set_option("max_rows", 35)
    pd.set_option("max_columns", 15)

    from app import server

    with server.app_context():
        pass

        # params = {
        #     "tickers": ["AMZN US"],
        #     "currencies": ["USD"],
        #     "payoffs": ["autocall"],
        #     "reoffer": 99,
        #     "maturity_in_months": 36,
        #     "cpn_barrier": 60,
        #     "ki_barrier": 60,
        # }

        # SGPricer().description_payoff(**parameters)

        df = SGPricer().underlying_universe()

        # prices = SGPricer().get_prices_combinations(**params)

        # d = SGPricer().pricing_run_with_details(
        #     currencies=["USD"], theme="bnpp_opinions"
        # )
        prices = SGPricer().pricing_run_with_details(
            tickers=[
                "ABI BB",
                "VIV FP",
                "AC FP",
                "VOW3 GY",
                "ADEN SW",
                "AMZN US",
                "ALO FP",
                "AMN US",
                "ASSAB SS",
                "BIIB US",
                "ATO FP",
                "BKNG US",
                "CA FP",
                "CHKP US",
                "DUFN SE",
                "GILD US",
                "EZJ LN",
                "INTC US",
                "ERICB SS",
                "MU US",
                "FER SM",
                "BABA US",
                "IFX GY",
                "BIDU US",
                "KONE AV",
                "GELYF US",
                "PHIA NA",
                "JD US",
                "PRX NA",
                "MPNGY US",
                "SAN SM",
                "NTES US",
                "SAP GY",
                "NIO US",
                "SIE GY",
                "PDD US",
                "STLA IM",
                "SMSN LI",
                "STM FP",
                "TTMT IN",
                "TUI1 GY",
                "TCEHY US",
                "UBI FP",
                "TME US",
                "ULVR LN",
                "TCOM US",
                "FR FP",
                "XIACF US",
            ],
            payoffs=["autocall"],
            currencies=["EUR"],
            nb_ul=1,
        )

        # SGPricer().get_json_request("SGM-00008264125")

import os
from app import app
from requests import Session
from urllib.parse import quote_plus
from utils.basics import dt_today, prev_bday


class LesEchos(Session):
    endpoint_api = "https://api.lesechos.fr/api/v1/auth/"
    endpoint_kiosque = "https://kiosque.lesechos.fr/"

    email = "pierre.bchn@gmail.com"
    password = ")KGhEGGs-L7-"

    def __init__(self):
        super().__init__()

        self.login_body = None

        self.last_edition_date = self._set_last_edition_date()
        self.filename = self.last_edition_date + ".pdf"

    @staticmethod
    def _set_last_edition_date():
        today = dt_today()
        if today.weekday() in [6, 7]:
            return prev_bday(1, "string_figures")
        return dt_today("string_figures")

    def _login(self):
        r = self.post(self.endpoint_api + "login", json=self._payload())
        self.login_body = r.json()

    def _pdf_cookies(self):
        cookies = self.login_body.get("cookies")
        result = {x["name"]: str(x["value"]) for x in cookies}
        result["authentication"] = quote_plus(str(self.login_body))
        return result

    def _my_profile(self):
        auth_token = self.login_body.get("token")
        headers = {"authorization": f"Bearer {auth_token}"}
        r = self.get(self.endpoint_api + "me", headers=headers)
        return r.json()

    @staticmethod
    def pdf_directory():
        working_dir = os.getcwd()
        if __name__ == "__main__":
            return os.path.join(working_dir, "files")
        return os.path.join(working_dir, "utils/other/files")

    def _payload(self):
        return {
            "email": self.email,
            "password": self.password,
        }

    def _delete_previous_editions_if_not_today(self):
        for f in os.listdir(self.pdf_directory()):
            if f != self.filename:
                path_f = os.path.join(self.pdf_directory(), f)
                os.remove(path_f)
                app.logger.info(f"Removed - Les Echos {f}")

    def update_pdf(self):

        for f in os.listdir(self.pdf_directory()):
            if self.filename == f:
                print("Les Echos: Already downloaded - " + self.last_edition_date)
                return

        self._login()

        try:
            url = self.endpoint_kiosque + "pdf.php"
            params = {"edition": self.last_edition_date + "_LEC.pdf"}
            cookies = self._pdf_cookies()
            pdf = self.get(url, params=params, cookies=cookies)

            # Save the PDF in the folder with the date as filename
            path = os.path.join(self.pdf_directory(), self.filename)
            with open(path, "wb") as doc:
                doc.write(pdf.content)
            app.logger.info(f"Downloaded - Les Echos {self.filename}")

            # Delete previous editions
            self._delete_previous_editions_if_not_today()
        except Exception as e:
            msg = f"Issue to save last version of Les Echos"
            app.logger.error(msg, exc_info=True)


if __name__ == "__main__":
    LesEchos().update_pdf()

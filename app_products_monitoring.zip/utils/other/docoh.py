import pandas as pd
import requests

from utils.api_sg import SGPricer


def trending_reddit_tickers():
    url = "https://docoh.com/social"
    header = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.75 Safari/537.36",
        "X-Requested-With": "XMLHttpRequest",
    }
    r = requests.get(url, headers=header)
    dfs = pd.read_html(r.text)

    tickers_list = []
    df_tickers_universe = SGPricer().underlying_universe(formatting="df")
    df_tickers_universe["ticker"] = df_tickers_universe["BloombergTickerCode"].apply(
        lambda x: x.split(" ")[0]
    )

    for df in dfs[1:5]:
        for i in range(0, 5):
            if df.iloc[i].loc["Stock"].split("  ")[0] in list(
                df_tickers_universe["ticker"]
            ):
                dff = df_tickers_universe[
                    df_tickers_universe["ticker"]
                    == df.iloc[i].loc["Stock"].split("  ")[0]
                ]
                if not dff.empty:
                    tickers_list.append(dff.iloc[0].loc["BloombergTickerCode"])

    return list(set(tickers_list))


if __name__ == "__main__":
    tickers = trending_reddit_tickers()
    print(tickers)

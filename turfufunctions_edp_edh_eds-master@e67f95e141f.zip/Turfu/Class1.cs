﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Runtime.Caching;
using ExcelDna.Integration;
using RestSharp;
using Newtonsoft.Json;
using System.Globalization;
using System.Diagnostics;

namespace Turfu
{

    public class jsonEDP
    {
        public string code { get; set; }
        public object value { get; set; }
        public string type { get; set; }
    }

    public class jsonEDH
    {
        public string code { get; set; }
        public Value value { get; set; }
        public List<string> type { get; set; }
    }

    public class Value
    {
        public List<int> index { get; set; }
        public List<string> columns { get; set; }
        public List<List<object>> data { get; set; }
    }

    public static class TurfuFunctions
    {
        [ExcelFunction(
            Description="EDP (Exane Data Point) is for static or real time current data. It returns data to a single cell in your Excel spreadsheet. This formula contains only one security and only one field.",
            IsVolatile = false
            )
        ]
        public static object EDP(
            [ExcelArgument(Name = "Security", Description = "A single valid Exane security identifier (Cfin, ISIN, Ticker, RIC Code, External Ref, ...)")] object[] codes, 
            [ExcelArgument(Name = "Parameter", Description = "The mnemonic representation of a field that Exane provides")]  string parameter, 
            [ExcelArgument(Name = "Option", Description = "Optional argument")] string option, 
            [ExcelArgument(Name = "Option2", Description = "Optional argument")] string option2, 
            [ExcelArgument(Name = "Debug", Description = "Default: False. Use local server API if True.")] bool debug
            )
        {

            // Concatenate elements given as first parameter
            string code = String.Join(", ", codes);

            // Suppose user is looking for a Cfin if parameter is missing
            if (string.IsNullOrEmpty(parameter)) parameter = "cfin";            
                
            // First check the cache, and return immediately 
            // if we found something.
            // (We also need a unique key to identify the cache item)
            string key = $"edpCachedAsync:{code}{parameter}{option}{debug}";
            ObjectCache cache = MemoryCache.Default;
            string cachedItem = cache[key] as string;
            if (cachedItem != null)
                return cachedItem;

            // Not in the cache - make the async call 
            // to retrieve the item. (The second parameter here should identify 
            // the function call, so would usually be an array of the input parameters, 
            // but here we have the identifying key already.)
            object asyncResult = ExcelAsyncUtil.Run("edpCachedAsync", key, () =>
            {
                // Here we fetch the data from far away....
                // This code will run on a ThreadPool thread.

                string endpoint = "http://turfu/api";

                // Set the endpoint as local to debug the API
                if (debug is true) endpoint = "http://127.0.0.1:5000/api";

                var client = new RestClient(endpoint);
                var request = new RestRequest("edp");

                // Add query elements
                request.AddParameter("parameter", parameter);
                request.AddParameter("code", code);
                request.AddParameter("option", option);
                request.AddParameter("option2", option2);

                // Add details about the user in the Header
                request.AddHeader("UserName", Environment.UserName).AddHeader("Machine", Environment.MachineName);

                var response = client.Get(request);

                try
                {

                    jsonEDP json = JsonConvert.DeserializeObject<jsonEDP>(response.Content);

                    // creating object of CultureInfo 
                    CultureInfo cultures = new CultureInfo("fr-FR");

                    switch (json.type)
                    {
                        case "int":
                            return Math.Round(Convert.ToDouble(json.value), 0);
                        case "float":
                            return Convert.ToDecimal(json.value, cultures);
                        case "date":
                            return Convert.ToDateTime(json.value);
                        case "bool":
                            return Convert.ToBoolean(json.value);
                        default:
                            return json.value;
                    }

                }
                catch (Exception e)
                {
                    Debug.Print($"Error {e}");
                    return "#N/A";
                }

            });

            // Check the asyncResult to see if we're still busy
            if (asyncResult.Equals(ExcelError.ExcelErrorNA))
                return "Loading " + parameter + " ...";

            // OK, we actually got the result this time.
            // Add to the cache and return
            // (keeping the cached entry valid for 1 minute)
            // Note that the function won't recalc automatically after 
            //    the cache expires. For this we need to go the 
            //    RxExcel route with an IObservable.
            cache.Add(key, asyncResult, DateTime.Now.AddMinutes(1), null);
            return asyncResult;
        }


        [ExcelFunction(
                Description = "EDH (Exane Data History) returns the historical data for a selected security",
                IsVolatile = false
            )
        ]
        public static object EDH(
            [ExcelArgument(Name = "Security", Description = "A single valid Exane security identifier (Cfin, ISIN, Ticker, RIC Code, External Ref, ...)")] string code, 
            [ExcelArgument(Name = "Parameter", Description = "The mnemonic representation of a field that Exane provides")] string parameter, 
            [ExcelArgument(Name = "Start Date", Description = "A current or historical date format applicable to Excel (for example, dd/mm/yyyy). You can also specify a Fiscal or Relative Date.")] int start_date, 
            [ExcelArgument(Name = "End Date", Description = "A valid date-format that's equal to, or later than the start date. This cannot be in the future. You can also specify a Fiscal or Relative Date.")] int end_date, 
            [ExcelArgument(Name = "Option", Description = "Optional argument")] string option, [ExcelArgument(Name = "Debug", Description = "Default: False. Use local server API if True.")] bool debug)
        {

            // Here we fetch the data from far away....
            // This code will run on a ThreadPool thread.

            string endpoint = "http://turfu/api";

            // Set the endpoint as local to debug the API
            if (debug is true) endpoint = "http://127.0.0.1:5000/api";

            var client = new RestClient(endpoint);
            var request = new RestRequest("edh");

            // Add query elements
            request.AddParameter("parameter", parameter).AddParameter("code", code).AddParameter("option", option);

            if (start_date != 0)
            {
                string str_start_date = DateTime.FromOADate(start_date).ToString("dd/MM/yyyy");
                request.AddParameter("start_date", str_start_date);
            }

            if (end_date != 0)
            {
                string str_end_date = DateTime.FromOADate(end_date).ToString("dd/MM/yyyy");
                request.AddParameter("end_date", str_end_date);
            }

            // Add details about the user in the Header
            request.AddHeader("UserName", Environment.UserName).AddHeader("Machine", Environment.MachineName);

            var response = client.Get(request);

            try
            {

                jsonEDH json = JsonConvert.DeserializeObject<jsonEDH>(response.Content);

                int nbRows = json.value.index.Count;
                int nbColumns = json.value.columns.Count;

                object[,] result = new object[nbRows + 1, nbColumns];

                for (int j = 0; j < nbColumns; j++)
                {
                    result[0, j] = json.value.columns[j];
                }
                for (int i = 0; i < nbRows; i++)
                {
                    for (int j = 0; j < nbColumns; j++)
                    {
                        result[i+1, j] = json.value.data[i][j];
                    }
                }

                return AsyncFunctions.ArrayResizer.Resize(result);
                    

            }
            catch (Exception e)
            {
                Debug.Print($"Error {e}");
                return "#N/A";
            }
        }


        [ExcelFunction(Description = "EDH (Exane Data History) returns the historical data for a selected security", IsVolatile = false)]
        public static object EDH_test(
            [ExcelArgument(Name = "Security", Description = "A single valid Exane security identifier (Cfin, ISIN, Ticker, RIC Code, External Ref, ...)")] string code,
            [ExcelArgument(Name = "Parameter", Description = "The mnemonic representation of a field that Exane provides")] string parameter,
            [ExcelArgument(Name = "Start Date", Description = "A current or historical date format applicable to Excel (for example, dd/mm/yyyy). You can also specify a Fiscal or Relative Date.")] int start_date,
            [ExcelArgument(Name = "End Date", Description = "A valid date-format that's equal to, or later than the start date. This cannot be in the future. You can also specify a Fiscal or Relative Date.")] int end_date,
            [ExcelArgument(Name = "Option", Description = "Optional argument")] string option, 
            [ExcelArgument(Name = "Debug", Description = "Default: False. Use local server API if True.")] bool debug)
        {

            // Here we fetch the data from far away....
            // This code will run on a ThreadPool thread.

            string endpoint = "http://turfu/api";

            // Set the endpoint as local to debug the API
            if (debug is true) endpoint = "http://127.0.0.1:5000/api";

            var client = new RestClient(endpoint);
            var request = new RestRequest("edh");

            // Add query elements
            request.AddParameter("parameter", parameter).AddParameter("code", code).AddParameter("option", option);

            if (start_date != 0)
            {
                string str_start_date = DateTime.FromOADate(start_date).ToString("dd/MM/yyyy");
                request.AddParameter("start_date", str_start_date);
            }

            if (end_date != 0)
            {
                string str_end_date = DateTime.FromOADate(end_date).ToString("dd/MM/yyyy");
                request.AddParameter("end_date", str_end_date);
            }

            // Add details about the user in the Header
            request.AddHeader("UserName", Environment.UserName).AddHeader("Machine", Environment.MachineName);

            var response = client.Get(request);

            try
            {

                var funcName = nameof(EDH_test);

                // First check the cache, and return immediately 
                // if we found something.
                // (We also need a unique key to identify the cache item)
                string key = $"edhCachedAsync:{code}{parameter}{option}{debug}";

                return ExcelAsyncUtil.Run(funcName, key, () =>
                {
                    jsonEDH json = JsonConvert.DeserializeObject<jsonEDH>(response.Content);

                    int nbRows = json.value.index.Count;
                    int nbColumns = json.value.columns.Count;

                    object[,] result = new object[nbRows + 1, nbColumns];

                    for (int j = 0; j < nbColumns; j++)
                    {
                        result[0, j] = json.value.columns[j];
                    }
                    for (int i = 0; i < nbRows; i++)
                    {
                        for (int j = 0; j < nbColumns; j++)
                        {
                            result[i + 1, j] = json.value.data[i][j];
                        }
                    }

                    return result;
                });

            }
            catch (Exception e)
            {
                Debug.Print($"Error {e}");
                return "#N/A";
            }
        }


        [ExcelFunction(Description = "EDS (Exane Data Set) returns multi-cell descriptive data to your Excel spreadsheet", IsVolatile = false)]
        public static object EDS([ExcelArgument(Name = "Security or Name", Description = "Valid Exane securities identifier or a dataset name")] object[] codes, [ExcelArgument(Name = "Parameter", Description = "Optional. The mnemonic representation of a field that Exane provides.")] string parameter, [ExcelArgument(Name = "Option", Description = "Optional argument")] string option, [ExcelArgument(Name = "Debug", Description = "Optional. Use local server API if True. Default: False.")] bool debug)
        {

            // Concatenate elements given as first parameter
            string code = String.Join(", ", codes);

            // Here we fetch the data from far away....
            // This code will run on a ThreadPool thread.

            string endpoint = "http://turfu/api";

            // Set the endpoint as local to debug the API
            if (debug is true) endpoint = "http://127.0.0.1:5000/api";

            var client = new RestClient(endpoint);
            var request = new RestRequest("eds");

            // Add query elements
            request.AddParameter("parameter", parameter).AddParameter("code", code).AddParameter("option", option);

            // Add details about the user in the Header
            request.AddHeader("UserName", Environment.UserName).AddHeader("Machine", Environment.MachineName);

            var response = client.Get(request);

            try
            {

                jsonEDH json = JsonConvert.DeserializeObject<jsonEDH>(response.Content);

                int nbRows = json.value.index.Count;
                int nbColumns = json.value.columns.Count;

                object[,] result = new object[nbRows + 1, nbColumns];

                for (int j = 0; j < nbColumns; j++)
                {
                    result[0, j] = json.value.columns[j];
                }
                for (int i = 0; i < nbRows; i++)
                {
                    for (int j = 0; j < nbColumns; j++)
                    {
                        result[i + 1, j] = json.value.data[i][j];
                    }
                }

                return AsyncFunctions.ArrayResizer.Resize(result);


            }
            catch (Exception e)
            {
                Debug.Print($"Error {e}");
                return "#N/A";
            }
        }


        [ExcelFunction(Description = "EDS (Exane Data Set) returns multi-cell descriptive data to your Excel spreadsheet", IsVolatile = false)]
        public static object EDS_test([ExcelArgument(Name = "Security or Name", Description = "Valid Exane securities identifier or a dataset name")] object[] codes, [ExcelArgument(Name = "Parameter", Description = "Optional. The mnemonic representation of a field that Exane provides.")] string parameter, [ExcelArgument(Name = "Option", Description = "Optional argument")] string option, [ExcelArgument(Name = "Debug", Description = "Optional. Use local server API if True. Default: False.")] bool debug)
        {

            // Concatenate elements given as first parameter
            string code = String.Join(", ", codes);

            // Here we fetch the data from far away....
            // This code will run on a ThreadPool thread.

            string endpoint = "http://turfu/api";

            // Set the endpoint as local to debug the API
            if (debug is true) endpoint = "http://127.0.0.1:5000/api";

            var client = new RestClient(endpoint);
            var request = new RestRequest("eds");

            // Add query elements
            request.AddParameter("parameter", parameter).AddParameter("code", code).AddParameter("option", option);

            // Add details about the user in the Header
            request.AddHeader("UserName", Environment.UserName).AddHeader("Machine", Environment.MachineName);

            var response = client.Get(request);

            try
            {

                // First check the cache, and return immediately 
                // if we found something.
                // (We also need a unique key to identify the cache item)
                string key = $"edsCachedAsync:{code}{parameter}{option}{debug}";


                var funcName = nameof(EDS_test);

                return ExcelAsyncUtil.Run(funcName, key, () =>
                {

                    jsonEDH json = JsonConvert.DeserializeObject<jsonEDH>(response.Content);

                    int nbRows = json.value.index.Count;
                    int nbColumns = json.value.columns.Count;

                    object[,] result = new object[nbRows + 1, nbColumns];

                    for (int j = 0; j < nbColumns; j++)
                    {
                        result[0, j] = json.value.columns[j];
                    }
                    for (int i = 0; i < nbRows; i++)
                    {
                        for (int j = 0; j < nbColumns; j++)
                        {
                            result[i + 1, j] = json.value.data[i][j];
                        }
                    }

                    return result;
                });
            
            }
            catch (Exception e)
            {
                Debug.Print($"Error {e}");
                return "#N/A";
            }
        }

        public static object dnaMakeArrayAsync(int delayMs, int rows, int cols)
        {
            var funcName = nameof(dnaMakeArrayAsync);
            var args = new object[] { delayMs, rows, cols };

            return ExcelAsyncUtil.Run(funcName, args, () =>
            {
                Thread.Sleep(delayMs);
                object[,] result = new object[rows, cols];
                for (int i = 0; i < rows; i++)
                {
                    for (int j = 0; j < cols; j++)
                    {
                        result[i, j] = $"{i}|{j}";
                    }
                }
                return result;
            });
        }

    }
}

namespace AsyncFunctions
{
    public class ArrayResizer
    {
        static Queue<ExcelReference> ResizeJobs = new Queue<ExcelReference>();

        // This function will run in the UDF context.
        public static object Resize(object[,] array)
        {
            ExcelReference caller = XlCall.Excel(XlCall.xlfCaller) as ExcelReference;
            return Resize(array, caller);
        }

        // THIS MAKES NO SENSE...?

        //internal static object ResizeObservable(object[,] array, ExcelReference caller)
        //{
        //    object callerAfter = XlCall.Excel(XlCall.xlfCaller);
        //    if (callerAfter == null)
        //    {
        //        // This is the good RTD array call
        //        return Resize(array, caller);
        //    }
        //    // Some spurious RTD call - just return.
        //    return array;
        //}

        public static object Resize(object[,] array, ExcelReference caller)
        {
            if (caller == null)
            {
                Debug.Print("Resize - Abandoning - No Caller");
                return array;
            }

            int rows = array.GetLength(0);
            int columns = array.GetLength(1);

            if ((caller.RowLast - caller.RowFirst + 1 != rows) ||
                (caller.ColumnLast - caller.ColumnFirst + 1 != columns))
            {
                // Size problem: enqueue job, call async update and return #N/A
                EnqueueResize(caller, rows, columns);
                ExcelAsyncUtil.QueueAsMacro(DoResizing);
            }

            // Size is already OK - just return result
            return array;
        }

        static void EnqueueResize(ExcelReference caller, int rows, int columns)
        {
            ExcelReference target = new ExcelReference(caller.RowFirst, caller.RowFirst + rows - 1, caller.ColumnFirst, caller.ColumnFirst + columns - 1, caller.SheetId);
            ResizeJobs.Enqueue(target);
        }

        static void DoResizing()
        {
            while (ResizeJobs.Count > 0)
            {
                DoResize(ResizeJobs.Dequeue());
            }
        }

        static void DoResize(ExcelReference target)
        {
            object oldEcho = XlCall.Excel(XlCall.xlfGetWorkspace, 40);
            object oldCalculationMode = XlCall.Excel(XlCall.xlfGetDocument, 14);
            try
            {
                // Get the current state for reset later
                XlCall.Excel(XlCall.xlcEcho, false);
                XlCall.Excel(XlCall.xlcOptionsCalculation, 3);

                // Get the formula in the first cell of the target
                string formula = (string)XlCall.Excel(XlCall.xlfGetCell, 41, target);
                ExcelReference firstCell = new ExcelReference(target.RowFirst, target.RowFirst, target.ColumnFirst, target.ColumnFirst, target.SheetId);

                bool isFormulaArray = (bool)XlCall.Excel(XlCall.xlfGetCell, 49, target);
                if (isFormulaArray)
                {
                    object oldSelectionOnActiveSheet = XlCall.Excel(XlCall.xlfSelection);
                    object oldActiveCell = XlCall.Excel(XlCall.xlfActiveCell);

                    // Remember old selection and select the first cell of the target
                    string firstCellSheet = (string)XlCall.Excel(XlCall.xlSheetNm, firstCell);
                    XlCall.Excel(XlCall.xlcWorkbookSelect, new object[] { firstCellSheet });
                    object oldSelectionOnArraySheet = XlCall.Excel(XlCall.xlfSelection);
                    XlCall.Excel(XlCall.xlcFormulaGoto, firstCell);

                    // Extend the selection to the whole array and clear
                    XlCall.Excel(XlCall.xlcSelectSpecial, 6);
                    ExcelReference oldArray = (ExcelReference)XlCall.Excel(XlCall.xlfSelection);

                    oldArray.SetValue(ExcelEmpty.Value);
                    XlCall.Excel(XlCall.xlcSelect, oldSelectionOnArraySheet);
                    XlCall.Excel(XlCall.xlcFormulaGoto, oldSelectionOnActiveSheet);
                }
                // Get the formula and convert to R1C1 mode
                bool isR1C1Mode = (bool)XlCall.Excel(XlCall.xlfGetWorkspace, 4);
                string formulaR1C1 = formula;
                if (!isR1C1Mode)
                {
                    // Set the formula into the whole target
                    formulaR1C1 = (string)XlCall.Excel(XlCall.xlfFormulaConvert, formula, true, false, ExcelMissing.Value, firstCell);
                }
                // Must be R1C1-style references
                object ignoredResult;
                //Debug.Print("Resizing START: " + target.RowLast);
                XlCall.XlReturn retval = XlCall.TryExcel(XlCall.xlcFormulaArray, out ignoredResult, formulaR1C1, target);
                //Debug.Print("Resizing FINISH");

                // TODO: Dummy action to clear the undo stack

                if (retval != XlCall.XlReturn.XlReturnSuccess)
                {
                    // TODO: Consider what to do now!?
                    // Might have failed due to array in the way.
                    firstCell.SetValue("'" + formula);
                }
            }
            finally
            {
                XlCall.Excel(XlCall.xlcEcho, oldEcho);
                XlCall.Excel(XlCall.xlcOptionsCalculation, oldCalculationMode);
            }
        }
    }
}
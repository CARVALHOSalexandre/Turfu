SELECT
    ifnom "Name"
    ,tinom "Issuer"
    ,ifcfin "Cfin"
    ,cfcode "Isin"
    ,ric "Ric"
FROM CONTRIBNEXT.external_instrument
JOIN EXANE.instruments on ifcfin = instrument_cfin
JOIN EXANE.emission on emcfin = ifcfin
JOIN EXANE.tiers on ticode = emissuer
JOIN EXANE.codes on cfcfin = ifcfin and cfsource = 6
WHERE
  ifstatut not in (7, 22)
  AND ric not like '%=EXAP'
  AND REGEXP_LIKE (ric, '^\w{1,12}=[A-Z]{4}$')
  AND tinom is not null
  AND empaiement < sysdate
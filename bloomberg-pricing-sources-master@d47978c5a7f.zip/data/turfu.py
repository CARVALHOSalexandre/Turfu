import requests as rq
import pandas as pd


def get_from_turfu_api(code, index):
    url = f"http://turfu/api/eds?code={code}"

    df = pd.DataFrame()

    try:
        r = rq.get(url)
        r.raise_for_status()

        data = r.json().get("value")

        df = pd.DataFrame(data["data"], data["index"], data["columns"])

        # Clean the short names
        df.short_name = df.short_name.apply(lambda x: x.replace("\r", ""))

        df.set_index(index, inplace=True)

    except Exception as e:
        print(e)

    finally:
        return df.to_dict("index")


if __name__ == "__main__":
    issuers_rename = get_from_turfu_api(code="issuer_rename", index="weird_name")

import pandas as pd
from cx_Oracle import connect, DatabaseError


def get_from_exane_db(name_query):

    user = "contribnext_read"
    password = "j0l1spr1x"

    df = pd.DataFrame()

    try:

        with connect(user, password, "DER_Flux_G", threaded=True) as con:
            with open(f"data/sql/{name_query}.sql", "r") as q:
                df = pd.read_sql(q.read(), con=con)

    except DatabaseError as e:
        print(e)

    return df


if __name__ == "__main__":
    d = get_from_exane_db("contributed_products")

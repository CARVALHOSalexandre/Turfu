import pandas as pd
from tqdm import tqdm
from pdblp import BCon
from data.exane import get_from_exane_db
from data.turfu import get_from_turfu_api

df = get_from_exane_db("contributed_products")

# Format the ISINs with the Bloomberg format
df["Ticker"] = df.Isin.apply(lambda x: f"/isin/{x}")

# Rename the issuers
issuers_rename = get_from_turfu_api(code="issuer_rename", index="weird_name")


def rename(name):
    data = issuers_rename.get(name)
    if data:
        return data.get("short_name")
    return "MISSING"


df["Issuer Short"] = df.apply(lambda x: rename(x["Issuer"]), axis=1)

# Read the Pricing Sources
pricing_sources = get_from_turfu_api(code="pricing_sources", index="short_name")

# Create an object which manages connection to the Bloomberg API session
con = BCon(timeout=2000)

# Initialize the missing contributions
missing = []
bbg_prices = []

try:

    # Start connection and initialize session services
    con.start()

    # df = df[df.Isin == "XS1689183991"]

    # Returns Historical data for given securities
    for row in tqdm(df.iterrows()):

        product = row[1]

        try:

            d_sources = pricing_sources.get(product["Issuer Short"])
            if d_sources:
                sources = ["EXAD"]
                sources.extend([x for x in d_sources.values() if x])

                if not sources:
                    msg = f"Issuer {product['issuer']} is missing in the Json file"
                    raise KeyError(msg)

                prices = []

                for source in sources:
                    dff = con.ref(
                        tickers=product.Ticker,
                        flds=["PX_LAST", "LAST_UPDATE_DT"],
                        ovrds=[("PRICING_SOURCE", source)],
                    )

                    dff.dropna(inplace=True)

                    if not dff.empty:
                        bbg_prices.append(
                            {
                                "cfin": product.Cfin,
                                "source": source,
                                "price": float(dff.value[0]),
                                "time": dff.value[1],
                            }
                        )

        except ValueError:
            isin = product.Isin
            msg = f"{isin} has no price contribution"
            missing.append(isin)

except Exception as e:
    print(e)

finally:
    con.stop()

df_bbg = pd.DataFrame(bbg_prices)
df_bbg = pd.pivot(df_bbg, index="source", columns="cfin", values=["price", "time"])

# We verify that the price we have are different and published the same day
# If a counterpart stopped its contribution, it will disappear from BBG in 5 bdays
df_results = pd.DataFrame(df_bbg.price.nunique(), columns=["nb_prices"])
df_results["nb_dates"] = df_bbg.time.nunique()
df_results["issues"] = df_results.apply(
    lambda x: (x["nb_prices"] > 1) & (x["nb_prices"] != x["nb_dates"]), axis=1
)
cfins = df_results[df_results.issues].index

dff = df_bbg.price[cfins].dropna(how="all").T.reset_index()

df = pd.merge(dff, df, left_on="cfin", right_on="Cfin", how="inner")
df = df.sort_values(by="Issuer")
df.to_clipboard()
